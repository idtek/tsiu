do
	local ptr
	
	-- player character file 
	local library = Animation.CharacterLibrary
	do
		local addAnim = function( character, objName, clipName )
			local playName = 'PLAY_' .. objName
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = playName
				obj.AddClip(clipName, false, 0)
			end
			do 
				local obj = CrossFade(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				obj.Name = objName
				obj.Playback = playName
				obj.Duration = 0.20 -- or 12 frames
				--obj.Duration = 0.05 -- or 3 frames
			end
		end
		local addEndLoopAnim = function( character, objName, clipName, loopClip )
			local playName = 'PLAY_' .. objName
			local offsetName = 'OFFSET_' .. objName
			local loopName = 'LOOP_' .. objName
			local sequentialName = 'SEQ_' .. objName
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = playName
				obj.AddClip(clipName, false, 0)
				obj.Cyclic = false
			end
			do
				local obj = InitialOffsetMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = offsetName
				obj.Playback = playName
				obj.Offset = ClipManager.GetStartTransform(clipName, false, 'Movement')
			end
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = loopName
				obj.AddClip(loopClip, false, 0)
			end
			do
				local obj = SequentialMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = sequentialName
				obj.Add('TalkMotion')
				obj.Add(offsetName)
				obj.Add('QuietMotion')
				obj.Add(loopName)
			end
			do 
				local obj = CrossFade(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				obj.Name = objName
				obj.Playback = sequentialName
				obj.Duration = 0.20 -- or 12 frames
				--obj.Duration = 0.05 -- or 3 frames
			end
		end
		local addEndLoopMultipleRandomAnim = function( character, objName, clipName, loopClip1, loopClip2, loopClip3 )
			local playName = 'PLAY_' .. objName
			local offsetName = 'OFFSET_' .. objName
			local randName = 'RANDMAIN_' .. objName
			local loopName1 = 'RAND1_' .. objName
			local loopName2 = 'RAND2_' .. objName
			local loopName3 = 'RAND3_' .. objName
			local sequentialName = 'SEQ_' .. objName
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = playName
				obj.AddClip(clipName, false, 0)
				obj.Cyclic = false
			end
			do
				local obj = InitialOffsetMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = offsetName
				obj.Playback = playName
				obj.Offset = ClipManager.GetStartTransform(clipName, false, 'Movement')
			end
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = loopName1
				obj.Cyclic = false
				obj.AddClip(loopClip1, false, 0)
			end
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = loopName2
				obj.Cyclic = false
				obj.AddClip(loopClip2, false, 0)
			end
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = loopName3
				obj.Cyclic = false
				obj.AddClip(loopClip3, false, 0)
			end
            do
				local obj = RandomCompositeMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)

				obj.Name = randName
				obj.Add(loopName1)
				obj.Add(loopName2)
				obj.Add(loopName3)
            end			
			do
				local obj = SequentialMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = sequentialName
				obj.Add('TalkMotion')
				obj.Add(offsetName)
				obj.Add('QuietMotion')
				obj.Add(randName)
			end
			do 
				local obj = CrossFade(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				obj.Name = objName
				obj.Playback = sequentialName
				obj.Duration = 0.20 -- or 12 frames
				--obj.Duration = 0.05 -- or 3 frames
			end
		end
		
		local character = Character(EHeapIndex.ANIM_HEAPINDEX)
		ptr = AutoPointerCharacter()
		ptr.Set(character)
		library.Characters.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
		
		character.Name = 'FEPlayer'
		character.SkeletonName = 'Player'
		character.IndividualType = 'TemperaryNISIndividual'
		
		do		
			do
			 	local obj = SpecifyMotionType(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'TalkMotion'
			 	obj.MotionType = EMotionType.NISFESpeechMotion
			 	obj.IsLoopable = false
			end 
			do
			 	local obj = SpecifyMotionType(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'QuietMotion'
			 	obj.MotionType = EMotionType.NISFEIdleMotion
			 	obj.IsLoopable = false
			end 
			do
			-- BEGIN FE conversation animations
				addEndLoopAnim( character, 'REC_CAT_Generic_A', 'REC_CAT_Generic_A', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B', 'REC_CAT_Generic_B', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_SlideIN', 'REC_CAT_Generic_SlideIN', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_SlideOUT', 'REC_CAT_Generic_SlideOUT', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B_NO', 'REC_CAT_Generic_B_NO', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B_YES', 'REC_CAT_Generic_B_YES', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B1', 'REC_CAT_Generic_B1', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B2', 'REC_CAT_Generic_B2', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B3', 'REC_CAT_Generic_B3', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_B4', 'REC_CAT_Generic_B4', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_C', 'REC_CAT_Generic_C', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_D', 'REC_CAT_Generic_D', 'REC_CAT_Generic_LOOP' )
				addAnim( character, 'REC_CAT_Generic_LOOP', 'REC_CAT_Generic_LOOP' )
				addAnim( character, 'REC_CAT_Generic_LOOP_B', 'REC_CAT_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_CAT_Generic_NO', 'REC_CAT_Generic_NO', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_CAT_Generic_YES', 'REC_CAT_Generic_YES', 'REC_CAT_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_DER_Generic_A', 'REC_DER_Generic_A', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A_NO', 'REC_DER_Generic_A_NO', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A_YES', 'REC_DER_Generic_A_YES', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A1', 'REC_DER_Generic_A1', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A2', 'REC_DER_Generic_A2', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A3', 'REC_DER_Generic_A3', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_A4', 'REC_DER_Generic_A4', 'REC_DER_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_DER_Generic_B', 'REC_DER_Generic_B', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B_NO', 'REC_DER_Generic_B_NO', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B_YES', 'REC_DER_Generic_B_YES', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B1', 'REC_DER_Generic_B1', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B2', 'REC_DER_Generic_B2', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B3', 'REC_DER_Generic_B3', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_DER_Generic_B4', 'REC_DER_Generic_B4', 'REC_DER_Generic_LOOP_B' )
				addAnim( character, 'REC_DER_Generic_LOOP_A', 'REC_DER_Generic_LOOP_A' )
				addAnim( character, 'REC_DER_Generic_LOOP_B', 'REC_DER_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A_NO', 'REC_Evil_Generic_A_NO', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A_YES', 'REC_Evil_Generic_A_YES', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A1', 'REC_Evil_Generic_A1', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A2', 'REC_Evil_Generic_A2', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A3', 'REC_Evil_Generic_A3', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A4', 'REC_Evil_Generic_A4', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A5', 'REC_Evil_Generic_A5', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Evil_Generic_A6', 'REC_Evil_Generic_A6', 'REC_Evil_Generic_LOOP_A' )
				addAnim( character, 'REC_Evil_Generic_LOOP_A', 'REC_Evil_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_A', 'REC_GOR_Generic_A', 'REC_GOR_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B', 'REC_GOR_Generic_B', 'REC_GOR_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_SlideIN_A', 'REC_GOR_Generic_SlideIN_A', 'REC_GOR_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_SlideOUT_A', 'REC_GOR_Generic_SlideOUT_A', 'REC_GOR_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B_NO', 'REC_GOR_Generic_B_NO', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B_YES', 'REC_GOR_Generic_B_YES', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B1', 'REC_GOR_Generic_B1', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B2', 'REC_GOR_Generic_B2', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_B3', 'REC_GOR_Generic_B3', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_C', 'REC_GOR_Generic_C', 'REC_GOR_Generic_LOOP_A' )
				addAnim( character, 'REC_GOR_Generic_LOOP_A', 'REC_GOR_Generic_LOOP_A' )
				addAnim( character, 'REC_GOR_Generic_LOOP_B', 'REC_GOR_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_GOR_Generic_NO', 'REC_GOR_Generic_NO', 'REC_GOR_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_GOR_Generic_YES', 'REC_GOR_Generic_YES', 'REC_GOR_Generic_LOOP_A' )
				addAnim( character, 'REC_Hamm_Generic_A_LOOP', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A_NO', 'REC_Hamm_Generic_A_NO', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A_YES', 'REC_Hamm_Generic_A_YES', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A1', 'REC_Hamm_Generic_A1', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A2', 'REC_Hamm_Generic_A2', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A3', 'REC_Hamm_Generic_A3', 'REC_Hamm_Generic_A_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_A4', 'REC_Hamm_Generic_A4', 'REC_Hamm_Generic_A_LOOP' )
				addAnim( character, 'REC_Hamm_Generic_B_LOOP', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B_NO', 'REC_Hamm_Generic_B_NO', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B_YES', 'REC_Hamm_Generic_B_YES', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B1', 'REC_Hamm_Generic_B1', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B2', 'REC_Hamm_Generic_B2', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B3', 'REC_Hamm_Generic_B3', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_Hamm_Generic_B4', 'REC_Hamm_Generic_B4', 'REC_Hamm_Generic_B_LOOP' )
				addEndLoopAnim( character, 'REC_HIP_Generic_A', 'REC_HIP_Generic_A', 'REC_HIP_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B', 'REC_HIP_Generic_B', 'REC_HIP_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B_NO', 'REC_HIP_Generic_B_NO', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B_YES', 'REC_HIP_Generic_B_YES', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B1', 'REC_HIP_Generic_B1', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B2', 'REC_HIP_Generic_B2', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B3', 'REC_HIP_Generic_B3', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_B4', 'REC_HIP_Generic_B4', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_C', 'REC_HIP_Generic_C', 'REC_HIP_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_HIP_Generic_D', 'REC_HIP_Generic_D', 'REC_HIP_Generic_LOOP' )
				addAnim( character, 'REC_HIP_Generic_LOOP', 'REC_HIP_Generic_LOOP' )
				addAnim( character, 'REC_HIP_Generic_LOOP_B', 'REC_HIP_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_HIP_Generic_NO', 'REC_HIP_Generic_NO', 'REC_HIP_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_HIP_Generic_YES', 'REC_HIP_Generic_YES', 'REC_HIP_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Pele_Generic_A', 'REC_Pele_Generic_A', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B', 'REC_Pele_Generic_B', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B_NO', 'REC_Pele_Generic_B_NO', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B_YES', 'REC_Pele_Generic_B_YES', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B1', 'REC_Pele_Generic_B1', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B2', 'REC_Pele_Generic_B2', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B3', 'REC_Pele_Generic_B3', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B4', 'REC_Pele_Generic_B4', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B5', 'REC_Pele_Generic_B5', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_B6', 'REC_Pele_Generic_B6', 'REC_Pele_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Pele_Generic_C', 'REC_Pele_Generic_C', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_D', 'REC_Pele_Generic_D', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_E', 'REC_Pele_Generic_E', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_F', 'REC_Pele_Generic_F', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_NO', 'REC_Pele_Generic_NO', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_Pele_Generic_YES', 'REC_Pele_Generic_YES', 'REC_Pele_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_PIG_Generic_A', 'REC_PIG_Generic_A', 'REC_PIG_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_PIG_Generic_B', 'REC_PIG_Generic_B', 'REC_PIG_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_PIG_Generic_B_NO', 'REC_PIG_Generic_B_NO', 'REC_PIG_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_PIG_Generic_B_YES', 'REC_PIG_Generic_B_YES', 'REC_PIG_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_PIG_Generic_B1', 'REC_PIG_Generic_B1', 'REC_PIG_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_PIG_Generic_B3', 'REC_PIG_Generic_B3', 'REC_PIG_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_PIG_Generic_C', 'REC_PIG_Generic_C', 'REC_PIG_Generic_LOOP' )
				addAnim( character, 'REC_PIG_Generic_LOOP', 'REC_PIG_Generic_LOOP' )
				addAnim( character, 'REC_PIG_Generic_LOOP_B', 'REC_PIG_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_PIG_Generic_NO', 'REC_PIG_Generic_NO', 'REC_PIG_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_PIG_Generic_YES', 'REC_PIG_Generic_YES', 'REC_PIG_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_A', 'REC_Shady_Generic_A', 'REC_Shady_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_B', 'REC_Shady_Generic_B', 'REC_Shady_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_C', 'REC_Shady_Generic_C', 'REC_Shady_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_D', 'REC_Shady_Generic_D', 'REC_Shady_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_E', 'REC_Shady_Generic_E', 'REC_Shady_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_F', 'REC_Shady_Generic_F', 'REC_Shady_Generic_LOOP' )
				addAnim( character, 'REC_Shady_Generic_LOOP', 'REC_Shady_Generic_LOOP' )
				addAnim( character, 'REC_Torres_B_LOOP_1', 'REC_Torres_B_LOOP_1' )
				addAnim( character, 'REC_Torres_B_LOOP_2', 'REC_Torres_B_LOOP_2' )
				addAnim( character, 'REC_Torres_B_LOOP_3', 'REC_Torres_B_LOOP_3' )
				addEndLoopAnim( character, 'REC_Torres_B_TALK_1', 'REC_Torres_B_TALK_1', 'REC_Torres_B_LOOP_1' )
				addEndLoopAnim( character, 'REC_Torres_B_TALK_2', 'REC_Torres_B_TALK_2', 'REC_Torres_B_LOOP_2' )
				addEndLoopAnim( character, 'REC_Torres_B_TALK_3', 'REC_Torres_B_TALK_3', 'REC_Torres_B_LOOP_3' )
				addAnim( character, 'REC_Torres_B_TALK_4', 'REC_Torres_B_TALK_4' )
				addEndLoopAnim( character, 'REC_Torres_Generic_A', 'REC_Torres_Generic_A', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Torres_Generic_B', 'REC_Torres_Generic_B', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Torres_Generic_C', 'REC_Torres_Generic_C', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Torres_Generic_D', 'REC_Torres_Generic_D', 'REC_Torres_Generic_LOOP' )
				addAnim( character, 'REC_Torres_Generic_LOOP', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Torres_Generic_NO', 'REC_Torres_Generic_NO', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Torres_Generic_YES', 'REC_Torres_Generic_YES', 'REC_Torres_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A', 'REC_WLF_Generic_A', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A_NO', 'REC_WLF_Generic_A_NO', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A_YES', 'REC_WLF_Generic_A_YES', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A1', 'REC_WLF_Generic_A1', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A2', 'REC_WLF_Generic_A2', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_A3', 'REC_WLF_Generic_A3', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_SlideOUT_A', 'REC_WLF_Generic_SlideOUT_A', 'REC_WLF_Generic_LOOP_A' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B', 'REC_WLF_Generic_B', 'REC_WLF_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B_NO', 'REC_WLF_Generic_B_NO', 'REC_WLF_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B_YES', 'REC_WLF_Generic_B_YES', 'REC_WLF_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B1', 'REC_WLF_Generic_B1', 'REC_WLF_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B2', 'REC_WLF_Generic_B2', 'REC_WLF_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_WLF_Generic_B3', 'REC_WLF_Generic_B3', 'REC_WLF_Generic_LOOP_B' )
				addAnim( character, 'REC_WLF_Generic_LOOP_A', 'REC_WLF_Generic_LOOP_A' )
				addAnim( character, 'REC_WLF_Generic_LOOP_B', 'REC_WLF_Generic_LOOP_B' )
				
				addEndLoopMultipleRandomAnim( character, 'REC_RabbidShop_Generic_A_SCREAM', 'REC_RabbidShop_Generic_A_SCREAM', 'REC_RabbidShop_Generic_A_LOOP', 'REC_RabbidShop_Generic_B_LOOP', 'REC_RabbidShop_Generic_C_LOOP' )
				addEndLoopMultipleRandomAnim( character, 'REC_RabbidShop_Generic_B_SCREAM', 'REC_RabbidShop_Generic_B_SCREAM', 'REC_RabbidShop_Generic_A_LOOP', 'REC_RabbidShop_Generic_B_LOOP', 'REC_RabbidShop_Generic_C_LOOP' )
				addEndLoopMultipleRandomAnim( character, 'REC_RabbidShop_Generic_C_Point', 'REC_RabbidShop_Generic_C_Point', 'REC_RabbidShop_Generic_A_LOOP', 'REC_RabbidShop_Generic_B_LOOP', 'REC_RabbidShop_Generic_C_LOOP' )
				addAnim( character, 'REC_RabbidShop_Generic_A_LOOP', 'REC_RabbidShop_Generic_A_LOOP' )
				addAnim( character, 'REC_RabbidShop_Generic_B_LOOP', 'REC_RabbidShop_Generic_B_LOOP' )
				addAnim( character, 'REC_RabbidShop_Generic_C_LOOP', 'REC_RabbidShop_Generic_C_LOOP' )
				
				addEndLoopAnim( character, 'REC_Rabbid_Generic_A_LOOP', 'REC_Rabbid_Generic_A_LOOP', 'REC_Rabbid_Generic_A_SCREAM' )
				addAnim( character, 'REC_Rabbid_Generic_A_SCREAM', 'REC_Rabbid_Generic_A_SCREAM' )
				addEndLoopAnim( character, 'REC_Rabbid_Generic_B_LOOP', 'REC_Rabbid_Generic_B_LOOP', 'REC_Rabbid_Generic_B_SCREAM' )
				addAnim( character, 'REC_Rabbid_Generic_B_SCREAM', 'REC_Rabbid_Generic_B_SCREAM' )
				
				addEndLoopAnim( character, 'REC_RAY_Generic_A', 'REC_RAY_Generic_A', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_RAY_Generic_B', 'REC_RAY_Generic_B', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_RAY_Generic_C', 'REC_RAY_Generic_C', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_RAY_Generic_D', 'REC_RAY_Generic_D', 'REC_RAY_Generic_LOOP' )
				addAnim( character, 'REC_RAY_Generic_LOOP', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_RAY_Generic_NO', 'REC_RAY_Generic_NO', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_RAY_Generic_YES', 'REC_RAY_Generic_YES', 'REC_RAY_Generic_LOOP' )
				addEndLoopAnim( character, 'REC_Shady_Generic_YES_1', 'REC_Shady_Generic_YES_1', 'REC_Shady_Generic_YES_1_LOOP' )
				addAnim( character, 'REC_Shady_Generic_YES_1_LOOP', 'REC_Shady_Generic_YES_1_LOOP' )
				addAnim( character, 'REC_Shady_Generic_YES_2_LOOP', 'REC_Shady_Generic_YES_2_LOOP' )
				addAnim( character, 'REC_Torres_Generic_LOOP_B', 'REC_Torres_Generic_LOOP_B' )
				addEndLoopAnim( character, 'REC_Shady_Generic_YES_2', 'REC_Shady_Generic_YES_2', 'REC_Shady_Generic_YES_2_LOOP' )
			-- END FE conversation animations
			-- BEGIN FE other rooms animations
				addEndLoopAnim( character, 'CAT_chosen_IN', 'CAT_chosen_IN', 'CAT_chosen_LOOP')
				addAnim( character, 'CAT_chosen_LOOP', 'CAT_chosen_LOOP')
				addEndLoopAnim( character, 'CAT_chosen_OUT', 'CAT_chosen_OUT', 'CAT_talk_idle')
				addAnim( character, 'CAT_talk_idle', 'CAT_talk_idle')
				
				addEndLoopAnim( character, 'DER_chosen_IN', 'DER_chosen_IN', 'DER_chosen_LOOP')
				addAnim( character, 'DER_chosen_LOOP', 'DER_chosen_LOOP')
				addEndLoopAnim( character, 'DER_chosen_OUT', 'DER_chosen_OUT', 'DER_talk_idle')
				addAnim( character, 'DER_talk_idle', 'DER_talk_idle')
				
				addEndLoopAnim( character, 'GOR_chosen_IN', 'GOR_chosen_IN', 'GOR_chosen_LOOP')
				addAnim( character, 'GOR_chosen_LOOP', 'GOR_chosen_LOOP')
				addEndLoopAnim( character, 'GOR_chosen_OUT', 'GOR_chosen_OUT', 'GOR_talk_idle')
				addAnim( character, 'GOR_talk_idle', 'GOR_talk_idle')
				
				addEndLoopAnim( character, 'HIP_chosen_IN', 'HIP_chosen_IN', 'HIP_chosen_LOOP')
				addAnim( character, 'HIP_chosen_LOOP', 'HIP_chosen_LOOP')
				addEndLoopAnim( character, 'HIP_chosen_OUT', 'HIP_chosen_OUT', 'HIP_talk_idle')
				addAnim( character, 'HIP_talk_idle', 'HIP_talk_idle')
				
				addEndLoopAnim( character, 'PIG_chosen_IN', 'PIG_chosen_IN', 'PIG_chosen_LOOP')
				addAnim( character, 'PIG_chosen_LOOP', 'PIG_chosen_LOOP')
				addEndLoopAnim( character, 'PIG_chosen_OUT', 'PIG_chosen_OUT', 'PIG_talk_idle')
				addAnim( character, 'PIG_talk_idle', 'PIG_talk_idle')
				
				addEndLoopAnim( character, 'WLF_chosen_IN', 'WLF_chosen_IN', 'WLF_chosen_LOOP')
				addAnim( character, 'WLF_chosen_LOOP', 'WLF_chosen_LOOP')
				addEndLoopAnim( character, 'WLF_chosen_OUT', 'WLF_chosen_OUT', 'WLF_talk_idle')
				addAnim( character, 'WLF_talk_idle', 'WLF_talk_idle')

				addEndLoopAnim( character, 'RAB_chosen_IN', 'RAB_chosen_IN', 'RAB_chosen_LOOP')
				addAnim( character, 'RAB_chosen_LOOP', 'RAB_chosen_LOOP')
				addEndLoopAnim( character, 'RAB_chosen_OUT', 'RAB_chosen_OUT', 'RAB_talk_idle')
				addAnim( character, 'RAB_talk_idle', 'RAB_talk_idle')
								
				addEndLoopAnim( character, 'PELE_chosen_IN', 'PELE_chosen_IN', 'PELE_chosen_LOOP')
				addAnim( character, 'PELE_chosen_LOOP', 'PELE_chosen_LOOP')
				addEndLoopAnim( character, 'PELE_chosen_OUT', 'PELE_chosen_OUT', 'PELE_talk_idle')
				addAnim( character, 'PELE_talk_idle', 'PELE_talk_idle')

				addAnim( character, 'CAT_FE_MINIGAME_L_Idle', 'CAT_FE_MINIGAME_L_Idle' )
				addAnim( character, 'CAT_FE_MINIGAME_R_Idle', 'CAT_FE_MINIGAME_R_Idle' )
				addAnim( character, 'DER_FE_MINIGAME_L_Idle', 'DER_FE_MINIGAME_L_Idle' )
				addAnim( character, 'DER_FE_MINIGAME_R_Idle', 'DER_FE_MINIGAME_R_Idle' )
				addAnim( character, 'GOR_FE_MINIGAME_R_Idle', 'GOR_FE_MINIGAME_R_Idle' )
				addAnim( character, 'HIP_FE_MINIGAME_L_Idle', 'HIP_FE_MINIGAME_L_Idle' )
				addAnim( character, 'HIP_FE_MINIGAME_R_Idle', 'HIP_FE_MINIGAME_R_Idle' )
				addAnim( character, 'PIG_FE_MINIGAME_R_Idle', 'PIG_FE_MINIGAME_R_Idle' )
				addAnim( character, 'RAB_FE_MINIGAME_R_Idle', 'RAB_FE_MINIGAME_R_Idle' )
				addAnim( character, 'WLF_FE_MINIGAME_R_Idle', 'WLF_FE_MINIGAME_R_Idle' )
				addAnim( character, 'UBI_Altair_FE_MINIGAME_R_Idle', 'UBI_Altair_FE_MINIGAME_R_Idle' )

				-- used in character select screens
				addEndLoopAnim( character, 'CAT_FE_SELECTION_A_B', 'CAT_FE_SELECTION_A_B', 'CAT_FE_SELECTION_Idle_B')
				addAnim( character, 'CAT_FE_SELECTION_Idle_B', 'CAT_FE_SELECTION_Idle_B')
				addEndLoopAnim( character, 'CAT_FE_SELECTION_B_A', 'CAT_FE_SELECTION_B_A', 'CAT_FE_SELECTION_Idle_A')
				addAnim( character, 'CAT_FE_SELECTION_Idle_A', 'CAT_FE_SELECTION_Idle_A')
				
				addEndLoopAnim( character, 'DER_FE_SELECTION_A_B', 'DER_FE_SELECTION_A_B', 'DER_FE_SELECTION_Idle_B')
				addAnim( character, 'DER_FE_SELECTION_Idle_B', 'DER_FE_SELECTION_Idle_B')
				addEndLoopAnim( character, 'DER_FE_SELECTION_B_A', 'DER_FE_SELECTION_B_A', 'DER_FE_SELECTION_Idle_A')
				addAnim( character, 'DER_FE_SELECTION_Idle_A', 'DER_FE_SELECTION_Idle_A')

			-- END FE other rooms animations
			
			end
			do
			 	local obj = NISMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'NISPicker'
			end 
			do
			 	local obj = FaceHandsSelector(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'HandAndFace'
			 	obj.DisableMouth = 'DisableMouth'
			 	obj.ElementID = 'ElementID'	
			 	obj.OverrideMouth = 'OverrideMouth'
			 	obj.MouthTalkFrequency = 'MouthTalkFrequency'
			 	obj.MouthSmileFrequency = 'MouthSmileFrequency'
			 	obj.MouthClosedFrequency = 'MouthClosedFrequency'
			 	obj.MouthPoseDuration = 'MouthPoseDuration'
			end 
			do
			 	local obj = EventBroadcaster(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'EventBroadcaster'
			end
			do
			 	local obj = MotionList(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'Root'
				obj.Add('NISPicker')
				obj.Add('HandAndFace')
				obj.Add('EventBroadcaster')
			end 
		end
		character.DAGRoot = 'Root'
		character.Initialize()
		
	end
end

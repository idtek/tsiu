do
	local ptr
	
	-- player character file 
	local library = Animation.CharacterLibrary
	do
		local addAnim = function( character, objName, clipName, cyclic )
			local playName = 'PLAY_' .. objName
			do
				local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = playName
				obj.Cyclic = cyclic
				obj.AddClip(clipName, false, 0)
			end
			do 
				local obj = CrossFade(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				obj.Name = objName
				obj.Playback = playName
				obj.Duration = 0.20 -- or 12 frames
			end
		end
		
			
		local character = Character(EHeapIndex.ANIM_HEAPINDEX)
		ptr = AutoPointerCharacter()
		ptr.Set(character)
		library.Characters.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
		
		character.Name = 'Goalhead'
		character.SkeletonName = 'Goalhead'
		character.IndividualType = 'TemperaryNISIndividual'
		
		do
			do
				-- South America
				addAnim( character, 'SAM_Panther_Idle', 'SAM_Panther_Idle', true )
				addAnim( character, 'SAM_Panther_Roar', 'SAM_Panther_Roar', false )
				addAnim( character, 'SAM_Aztec_Idle', 'SAM_Aztec_Idle', true )
				addAnim( character, 'SAM_Aztec_Roar', 'SAM_Aztec_Roar', false )

				-- North America
				addAnim( character, 'NAM_Bear_Idle', 'NAM_Bear_Idle', true )
				addAnim( character, 'NAM_Bear_Roar', 'NAM_Bear_Roar', false )
				addAnim( character, 'NAM_Eagle_Idle', 'NAM_Eagle_Idle', true )
				addAnim( character, 'NAM_Eagle_Roar', 'NAM_Eagle_Roar', false )

				-- Africa
				addAnim( character, 'AFR_Elephant_Idle', 'AFR_Elephant_Idle', true )
				addAnim( character, 'AFR_Elephant_Roar', 'AFR_Elephant_Roar', false )
				addAnim( character, 'AFR_Lion_Idle', 'AFR_Lion_Idle', true )
				addAnim( character, 'AFR_Lion_Roar', 'AFR_Lion_Roar', false )
				
				-- Asia
				addAnim( character, 'ASA_Mask_Idle', 'ASA_Mask_Idle', true )
				addAnim( character, 'ASA_Mask_Roar', 'ASA_Mask_Roar', false )
				addAnim( character, 'ASA_Tiger_Idle', 'ASA_Tiger_Idle', true )
				addAnim( character, 'ASA_Tiger_Roar', 'ASA_Tiger_Roar', false )

				-- Europe
				addAnim( character, 'EUR_Bull_Idle', 'EUR_Bull_Idle', true )
				addAnim( character, 'EUR_Bull_Roar', 'EUR_Bull_Roar', false )
				addAnim( character, 'EUR_Bulldog_Idle', 'EUR_Bulldog_Idle', true )
				addAnim( character, 'EUR_Bulldog_Roar', 'EUR_Bulldog_Roar', false )
			end
		
			do	-- 
			 	local obj = NISMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
			 	obj.Name = 'NISPicker'
			end 
			do
			 	local obj = EventBroadcaster(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'EventBroadcaster'
			end 
			do
			 	local obj = SpecifyMotionType(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'SpecifyMotion'
			 	obj.MotionType = EMotionType.GoalheadMotion
			end 
			do
			 	local obj = MotionList(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'Root'
				obj.Add('NISPicker')
				obj.Add('SpecifyMotion')
				obj.Add('EventBroadcaster')
			end 
		end
		character.DAGRoot = 'Root'
		character.Initialize()
	end
end

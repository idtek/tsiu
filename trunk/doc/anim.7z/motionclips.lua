local clipManager = Animation.ClipManager
local characterLibrary = Animation.CharacterLibrary
local animList = {}
local unUsedList = {}
for i = 0, clipManager.NumClips() - 1 do
  unUsedList[i] = tovalue(clipManager.ClipName(i))
end

local handlerList = {}
for key, value in ipairs(characterLibrary.Characters) do
  local character = value.Ptr
  print(tovalue(character.Name))
  for motionKey, motionValue in ipairs(character.Motions) do
	local motionType = type(motionValue)
	--print("  "..motionType)
    if (tovalue(typeof(motionValue).IsSubclassOf(typeof('Playback'))) 
		or tovalue(typeof(motionValue).IsSubclassOf(typeof('PlaybackGroup'))))
	then
  	  for clipKey, clipValue in ipairs(motionValue.Clips) do
  		print("    "..tovalue(clipManager.ClipName(clipValue.ClipId)))
	    animList[tovalue(clipValue.ClipId)] = clipManager.ClipName(clipValue.ClipId)
		unUsedList[tovalue(clipValue.ClipId)] = nil
	  end
    end
  end
end

local sortList = {}
for key, value in pairs(unUsedList) do
	table.insert(sortList, value)
end
table.sort(sortList)

local result = 'do'
for key, value in pairs(sortList) do
  --result = result .. "\n" .. key .. ", '" .. value .. "'"
  result = result .. "\n  Animation.ClipManager.Delete(Animation.ClipManager.FindClip('" .. value .. "'))"
end
result = result .. '\nend\n'
return result

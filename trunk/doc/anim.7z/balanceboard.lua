do
	local ptr
	
	-- player character file 
	local library = Animation.CharacterLibrary
	do
		local character = Character(EHeapIndex.ANIM_HEAPINDEX)
		ptr = AutoPointerCharacter()
		ptr.Set(character)
		library.Characters.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
		
		character.Name = 'BBPlayer'
		character.SkeletonName = 'Player'
		character.IndividualType = 'TemperaryBalanceBoardIndividual'
		
		
        local BBSetup = {}
        BBSetup['AddSimpleMotion'] = function( animName, playName, motionName, cyclic, mirror, isEntryCondition, trickStateType, playbackRate, reverse )
            if reverse == nil then
                reverse = false
            end
	        do
	 	        local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
		        ptr = AutoInstance()
		        ptr.Set(obj)
		        character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
        		
	 	        obj.Name = playName
	 	        obj.Cyclic = cyclic
	 	        obj.PlaybackRate = playbackRate
	 	        if reverse == true then
	 	            obj.AddReverseClip(animName, mirror, 0)
	 	        else
		            obj.AddClip(animName, mirror, 0)
		        end
	        end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = playName
	 	        obj.AnimateBall = true
	 	        obj.IsEntryCondition = isEntryCondition
	            obj.TrickStateType = trickStateType
	        end
        end
        
        BBSetup['AddComplexMotion'] = function( animName, playName, motionName, paramName, minValue, maxValue, trickStateType, playbackRate )
	        do
	 	        local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
		        ptr = AutoInstance()
		        ptr.Set(obj)
		        character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
        		
	 	        obj.Name = playName
	 	        obj.PlaybackRate = playbackRate
                obj.Parameter = paramName
		        obj.AddClip(animName, false, minValue)
		        obj.AddClip(animName, false, maxValue)
	        end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = playName
	 	        obj.AnimateBall = true
	            obj.TrickStateType = trickStateType
	        end
        end
        
        BBSetup['AddTransition'] = function( animName, playName, motionName, reverse, trickStateType, playbackRate )
			do
			 	local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = playName
                obj.Cyclic = false
	 	        obj.PlaybackRate = playbackRate
                if reverse == true then
				    obj.AddReverseClip(animName, false, 0)
                else
				    obj.AddClip(animName, false, 0)
				end
			end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = playName
			 	obj.AnimateBall = true
	            obj.TrickStateType = trickStateType
	        end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName..'Interrupt'
	            obj.Playback = playName
			 	obj.AnimateBall = true
	            obj.TrickStateType = trickStateType
	            obj.IsInterrupt = true
	        end
        end
        
        BBSetup['AddBlendedMotion'] = function( animNameA, animNameB, playName, motionName, reverse, trickStateType, playbackRate )
			do
			 	local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = playName
                obj.Cyclic = false
	 	        obj.PlaybackRate = playbackRate
                obj.Parameter = 'BlendProgress'
                if reverse == true then
				    obj.AddClip(animNameB, false, -1.0)
				    obj.AddReverseClip(animNameA, false, 1.0)
                else
				    obj.AddReverseClip(animNameB, false, -1.0)
				    obj.AddClip(animNameA, false, 1.0)
				end
			end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = playName
			 	obj.AnimateBall = true
	            obj.TrickStateType = trickStateType
			 	obj.IsReverseBlend = reverse
	        end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName..'Interrupt'
	            obj.Playback = playName
			 	obj.AnimateBall = true
	            obj.TrickStateType = trickStateType
	            obj.IsInterrupt = true
			 	obj.IsReverseBlend = reverse
	        end
        end
        
        BBSetup['AddFallMotion'] = function( animName, playName, motionName, paramName, minValue, maxValue, trickStateType, playbackRate )
			local expectedName = 'EXP_' .. motionName
			do
			 	local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = playName
                obj.Cyclic = false
	 	        obj.PlaybackRate = playbackRate
				obj.AddClip(animName, false, 0)
			end
			do
			 	local obj = ExpectedValue(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = expectedName
			 	obj.Playback = playName
			 	obj.AnimateBall = true
			 	obj.Parameter = paramName
			 	obj.MinValue = minValue
			 	obj.MaxValue = maxValue
			end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = expectedName
	 	        obj.IsEntryCondition = true
	            obj.TrickStateType = trickStateType
	        end
		end
        
        BBSetup['AddCelebration'] = function()
            local playName = 'PLAY_CELEBRATION'
            local motionName = 'Celebration'
			do
			 	local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = playName
                obj.Cyclic = false
	 	        obj.PlaybackRate = 1.0
				obj.AddClip('CAT_BB_celebration', false, 0)
			end
	        do
	            local obj = BalanceBoardIntention(EHeapIndex.ANIM_HEAPINDEX)
	            ptr = AutoInstance()
	            ptr.Set(obj)
	            character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
	            
	            obj.Name = motionName
	            obj.Playback = playName
	 	        obj.AnimateBall = true
	 	        obj.IsEntryCondition = true
	            obj.TrickStateType = EBalanceBoardTrickStateType.CELEBRATION
	        end
        end
        
		do
		    -- Standing Idle
			do
			 	local obj = Playback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'PLAY_IDLE'
	 	        obj.PlaybackRate = 1.0
				obj.AddClip('CAT_BB_stand_Idle', false, 0)
			end
			do
			 	local obj = ExpectedMovementIntention(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'Idle'
			 	obj.Playback = 'PLAY_IDLE'
			 	obj.AnimateBall = true
			end
			
			
			local fallPlaybackRate = 1.0
			local idlePlaybackRate = 1.0
			local leanPlaybackRate = 1.0
			local toShoulderPlaybackRate = 1.2
			local fromShoulderPlaybackRate = 1.5
			local balancePlaybackRate = 2.0
			local offBalancePlaybackRate = 1.0
			local feetPlaybackRate = 1.0
			local headBouncePlaybackRate = 1.0
			
			local maxInput      = 100
			local minInput      = -100
			
			local shoulder_LR   = 25
			local balance_LR    = 40
			local offBalance_LR = 50
			
			local lean_F        = 12
			local balance_F     = 21
			local offBalance_F  = 30
			
			local lean_B        = -32
			local balance_B     = -41
			local offBalance_B  = -50
			
			
			-- Left anims
			BBSetup.AddComplexMotion( 'CAT_BB_L_shoulder_Idle',      'PLAY_LEFT_SHOULDER_IDLE',        'LeftShoulderIdle',       'LeftRightBalance', shoulder_LR,    balance_LR,     EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_L_lean_Idle',          'PLAY_LEFT_LEAN_IDLE',            'LeftLeanIdle',           'LeftRightBalance', balance_LR,     balance_LR,     EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_L_balance_Idle',       'PLAY_LEFT_BALANCE_IDLE',         'LeftBalanceIdle',        'LeftRightBalance', balance_LR,     offBalance_LR,  EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddFallMotion(    'CAT_BB_L_Fall',               'PLAY_LEFT_FALL',                 'LeftFall',               'LeftRightBalance', offBalance_LR,  maxInput,       EBalanceBoardTrickStateType.UPPER_BODY, fallPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Fall_Idle',          'PLAY_LEFT_FALL_IDLE',            'LeftFallIdle',           true,  false, false,             EBalanceBoardTrickStateType.FALLEN, idlePlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_idle_to_L_shoulder',   'PLAY_LEFT_SHOULDER',             'LeftShoulder',           false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, toShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_shoulder_to_idle',   'PLAY_LEFT_SHOULDER_REVERSE',     'LeftShoulderReverse',    false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  fromShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_shoulder_to_L_lean', 'PLAY_LEFT_LEAN',                 'LeftLean',               false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, leanPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_lean_to_L_shoulder', 'PLAY_LEFT_LEAN_REVERSE',         'LeftLeanReverse',        false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  leanPlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_L_Offbalance',         'PLAY_LEFT_OFF_BALANCE',          'LeftOffBalance',         false,                           EBalanceBoardTrickStateType.UPPER_BODY, offBalancePlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_L_Offbalance',         'PLAY_LEFT_OFF_BALANCE_REVERSE',  'LeftOffBalanceReverse',  true,                            EBalanceBoardTrickStateType.ANY_STATE,  offBalancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_L_balance', 'CAT_BB_L_balance_to_L_lean', 'PLAY_LEFT_BALANCE',        'LeftBalance',         false,                 EBalanceBoardTrickStateType.UPPER_BODY, balancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_L_balance', 'CAT_BB_L_balance_to_L_lean', 'PLAY_LEFT_BALANCE_REVERSE','LeftBalanceReverse',  true,                  EBalanceBoardTrickStateType.ANY_STATE,  balancePlaybackRate )
			
			-- Right anims
			BBSetup.AddComplexMotion( 'CAT_BB_R_shoulder_Idle',      'PLAY_RIGHT_SHOULDER_IDLE',       'RightShoulderIdle',      'LeftRightBalance', -balance_LR,    -shoulder_LR,   EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_R_lean_Idle',          'PLAY_RIGHT_LEAN_IDLE',           'RightLeanIdle',          'LeftRightBalance', -balance_LR,    -balance_LR,    EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_R_balance_Idle',       'PLAY_RIGHT_BALANCE_IDLE',        'RightBalanceIdle',       'LeftRightBalance', -offBalance_LR, -balance_LR,    EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddFallMotion(    'CAT_BB_R_Fall',               'PLAY_RIGHT_FALL',                'RightFall',              'LeftRightBalance', minInput,       -offBalance_LR, EBalanceBoardTrickStateType.UPPER_BODY, fallPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Fall_Idle',          'PLAY_RIGHT_FALL_IDLE',           'RightFallIdle',          true,  false, false,             EBalanceBoardTrickStateType.FALLEN, idlePlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_idle_to_R_shoulder',   'PLAY_RIGHT_SHOULDER',            'RightShoulder',          false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, toShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_shoulder_to_idle',   'PLAY_RIGHT_SHOULDER_REVERSE',    'RightShoulderReverse',   false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  fromShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_shoulder_to_R_lean', 'PLAY_RIGHT_LEAN',                'RightLean',              false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, leanPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_lean_to_R_shoulder', 'PLAY_RIGHT_LEAN_REVERSE',        'RightLeanReverse',       false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  leanPlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_R_Offbalance',         'PLAY_RIGHT_OFF_BALANCE',         'RightOffBalance',        false,                           EBalanceBoardTrickStateType.UPPER_BODY, offBalancePlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_R_Offbalance',         'PLAY_RIGHT_OFF_BALANCE_REVERSE', 'RightOffBalanceReverse', true,                            EBalanceBoardTrickStateType.ANY_STATE,  offBalancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_R_balance', 'CAT_BB_R_balance_to_R_lean', 'PLAY_RIGHT_BALANCE',         'RightBalance',           false,            EBalanceBoardTrickStateType.UPPER_BODY, balancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_R_balance', 'CAT_BB_R_balance_to_R_lean', 'PLAY_RIGHT_BALANCE_REVERSE', 'RightBalanceReverse',    true,             EBalanceBoardTrickStateType.ANY_STATE,  balancePlaybackRate )
			
			-- Front anims
			BBSetup.AddComplexMotion( 'CAT_BB_F_lean_Idle',          'PLAY_FRONT_LEAN_IDLE',           'FrontLeanIdle',          'BackFrontBalance', lean_F,         balance_F,      EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_F_balance_Idle',       'PLAY_FRONT_BALANCE_IDLE',        'FrontBalanceIdle',       'BackFrontBalance', balance_F,      offBalance_F,   EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddFallMotion(    'CAT_BB_F_Fall',               'PLAY_FRONT_FALL',                'FrontFall',              'BackFrontBalance', offBalance_F,   maxInput,       EBalanceBoardTrickStateType.UPPER_BODY, fallPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_F_Fall_Idle',          'PLAY_FRONT_FALL_IDLE',           'FrontFallIdle',          true,  false, false,             EBalanceBoardTrickStateType.FALLEN, idlePlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_F_lean',               'PLAY_FRONT_LEAN',                'FrontLean',              false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, toShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_F_lean_to_Idle',       'PLAY_FRONT_LEAN_REVERSE',        'FrontLeanReverse',       false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  fromShoulderPlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_F_Offbalance',         'PLAY_FRONT_OFF_BALANCE',         'FrontOffBalance',        false,                           EBalanceBoardTrickStateType.UPPER_BODY, offBalancePlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_F_Offbalance',         'PLAY_FRONT_OFF_BALANCE_REVERSE', 'FrontOffBalanceReverse', true,                            EBalanceBoardTrickStateType.ANY_STATE,  offBalancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_F_balance', 'CAT_BB_F_balance_to_F_lean', 'PLAY_FRONT_BALANCE',         'FrontBalance',           false,            EBalanceBoardTrickStateType.UPPER_BODY, balancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_F_balance', 'CAT_BB_F_balance_to_F_lean', 'PLAY_FRONT_BALANCE_REVERSE', 'FrontBalanceReverse',    true,             EBalanceBoardTrickStateType.ANY_STATE,  balancePlaybackRate )
			
			-- Back anims
			BBSetup.AddComplexMotion( 'CAT_BB_B_lean_Idle',          'PLAY_BACK_LEAN_IDLE',            'BackLeanIdle',           'BackFrontBalance', balance_B,      lean_B,         EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddComplexMotion( 'CAT_BB_B_balance_Idle',       'PLAY_BACK_BALANCE_IDLE',         'BackBalanceIdle',        'BackFrontBalance', offBalance_B,   balance_B,      EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddFallMotion(    'CAT_BB_B_Fall',               'PLAY_BACK_FALL',                 'BackFall',               'BackFrontBalance', minInput,       offBalance_B,   EBalanceBoardTrickStateType.UPPER_BODY, fallPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_B_Fall_Idle',          'PLAY_BACK_FALL_IDLE',            'BackFallIdle',           true,  false, false,             EBalanceBoardTrickStateType.FALLEN, idlePlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_B_lean',               'PLAY_BACK_LEAN',                 'BackLean',               false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY, toShoulderPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_B_lean_to_Idle',       'PLAY_BACK_LEAN_REVERSE',         'BackLeanReverse',        false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,  fromShoulderPlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_B_Offbalance',         'PLAY_BACK_OFF_BALANCE',          'BackOffBalance',         false,                           EBalanceBoardTrickStateType.UPPER_BODY, offBalancePlaybackRate )
			BBSetup.AddTransition(    'CAT_BB_B_Offbalance',         'PLAY_BACK_OFF_BALANCE_REVERSE',  'BackOffBalanceReverse',  true,                            EBalanceBoardTrickStateType.ANY_STATE,  offBalancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_B_balance', 'CAT_BB_B_balance_to_B_lean', 'PLAY_BACK_BALANCE',         'BackBalance',            false,             EBalanceBoardTrickStateType.UPPER_BODY, balancePlaybackRate )
			BBSetup.AddBlendedMotion( 'CAT_BB_B_balance', 'CAT_BB_B_balance_to_B_lean', 'PLAY_BACK_BALANCE_REVERSE', 'BackBalanceReverse',     true,              EBalanceBoardTrickStateType.ANY_STATE,  balancePlaybackRate )
			
			-- Front Left anims
			BBSetup.AddSimpleMotion(  'CAT_BB_L_back_idle',           'PLAY_LEFT_FRONT_IDLE',             'LeftFrontIdle',           true,  false, false,         EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_shoulder_to_L_back',  'PLAY_LEFT_SHOULDER_TO_LEFT_FRONT', 'LeftShoulderToLeftFront', false, false, true,          EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_back_to_L_shoulder',  'PLAY_LEFT_FRONT_TO_LEFT_SHOULDER', 'LeftFrontToLeftShoulder', false, false, true,          EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_back_to_F_lean',      'PLAY_LEFT_FRONT_TO_FRONT_LEAN',    'LeftFrontToFrontLean',    false, false, true,          EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_F_lean_to_L_back',      'PLAY_FRONT_LEAN_TO_LEFT_FRONT',    'FrontLeanToLeftFront',    false, false, true,          EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			
			-- Front Right anims
			BBSetup.AddSimpleMotion(  'CAT_BB_R_back_idle',           'PLAY_RIGHT_FRONT_IDLE',              'RightFrontIdle',            true,  false, false,     EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_shoulder_to_R_back',  'PLAY_RIGHT_SHOULDER_TO_RIGHT_FRONT', 'RightShoulderToRightFront', false, false, true,      EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_back_to_R_shoulder',  'PLAY_RIGHT_FRONT_TO_RIGHT_SHOULDER', 'RightFrontToRightShoulder', false, false, true,      EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_back_to_F_lean',      'PLAY_RIGHT_FRONT_TO_FRONT_LEAN',     'RightFrontToFrontLean',     false, false, true,      EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_F_lean_to_R_back',      'PLAY_FRONT_LEAN_TO_RIGHT_FRONT',     'FrontLeanToRightFront',     false, false, true,      EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			
			-- Back Left anims
			BBSetup.AddSimpleMotion(  'CAT_BB_L_front_idle',           'PLAY_LEFT_BACK_IDLE',             'LeftBackIdle',             true,  false, false,        EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_shoulder_to_L_front',  'PLAY_LEFT_SHOULDER_TO_LEFT_BACK', 'LeftShoulderToLeftBack',   false, false, true,         EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_front_to_L_shoulder',  'PLAY_LEFT_BACK_TO_LEFT_SHOULDER', 'LeftBackToLeftShoulder',   false, false, true,         EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_front_to_B_lean',      'PLAY_LEFT_BACK_TO_BACK_LEAN',     'LeftBackToBackLean',       false, false, true,         EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_B_lean_to_L_front',      'PLAY_BACK_LEAN_TO_LEFT_BACK',     'BackLeanToLeftBack',       false, false, true,         EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			
			-- Back Right anims
			BBSetup.AddSimpleMotion(  'CAT_BB_R_front_idle',           'PLAY_RIGHT_BACK_IDLE',              'RightBackIdle',             true,  false, false,     EBalanceBoardTrickStateType.UPPER_BODY, idlePlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_shoulder_to_R_front',  'PLAY_RIGHT_SHOULDER_TO_RIGHT_BACK', 'RightShoulderToRightBack',  false, false, true,      EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_front_to_R_shoulder',  'PLAY_RIGHT_BACK_TO_RIGHT_SHOULDER', 'RightBackToRightShoulder',  false, false, true,      EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_front_to_B_lean',      'PLAY_RIGHT_BACK_TO_BACK_LEAN',      'RightBackToBackLean',       false, false, true,      EBalanceBoardTrickStateType.UPPER_BODY, 1.0 )
			BBSetup.AddSimpleMotion(  'CAT_BB_B_lean_to_R_front',      'PLAY_BACK_LEAN_TO_RIGHT_BACK',      'BackLeanToRightBack',       false, false, true,      EBalanceBoardTrickStateType.ANY_STATE,  1.0 )
			
			-- Head anims
			BBSetup.AddSimpleMotion(  'CAT_BB_Head_bounce_from_idle',      'PLAY_IDLE_TO_HEAD_BOUNCE',      'IdleToHeadBounce',      false, false, true,              EBalanceBoardTrickStateType.HEAD_BOUNCE, headBouncePlaybackRate )
            BBSetup.AddSimpleMotion(  'CAT_BB_Head_bounce_to_idle',        'PLAY_HEAD_BOUNCE_TO_IDLE',      'HeadBounceToIdle',      false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY,  headBouncePlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_Head_bounce_cycle',          'PLAY_HEAD_BOUNCE',              'HeadBounce',            true,  false, true,              EBalanceBoardTrickStateType.HEAD_BOUNCE, headBouncePlaybackRate )
			
			-- Feet anims
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_bounce_cycle',        'PLAY_LEFT_FOOT_BOUNCE',         'LeftFootBounce',        true,  false, true,              EBalanceBoardTrickStateType.LEFT_FOOT_BOUNCE,  feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_bounce_cycle',        'PLAY_RIGHT_FOOT_BOUNCE',        'RightFootBounce',       true,  false, true,              EBalanceBoardTrickStateType.RIGHT_FOOT_BOUNCE, feetPlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_bounce_from_idle',    'PLAY_IDLE_TO_LEFT_FOOT',        'IdleToLeftFoot',        false, false, true,              EBalanceBoardTrickStateType.LEFT_FOOT_IDLE,    feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_bounce_from_idle',    'PLAY_IDLE_TO_RIGHT_FOOT',       'IdleToRightFoot',       false, false, true,              EBalanceBoardTrickStateType.RIGHT_FOOT_IDLE,   feetPlaybackRate )
            
            BBSetup.AddSimpleMotion(  'CAT_BB_stand_idle_from_L_foot',     'PLAY_LEFT_FOOT_TO_IDLE',        'LeftFootToIdle',        false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY,        feetPlaybackRate )
            BBSetup.AddSimpleMotion(  'CAT_BB_stand_idle_from_R_foot',     'PLAY_RIGHT_FOOT_TO_IDLE',       'RightFootToIdle',       false, false, true,              EBalanceBoardTrickStateType.UPPER_BODY,        feetPlaybackRate )
            
            BBSetup.AddSimpleMotion(  'CAT_BB_L_to_R_Foot_Pass',           'PLAY_LEFT_TO_RIGHT_FOOT',       'LeftToRightFoot',       false, false, true,              EBalanceBoardTrickStateType.BETWEEN_FEET,      feetPlaybackRate )
            BBSetup.AddSimpleMotion(  'CAT_BB_L_to_R_Foot_Pass',           'PLAY_RIGHT_TO_LEFT_FOOT',       'RightToLeftFoot',       false, true,  true,              EBalanceBoardTrickStateType.BETWEEN_FEET,      feetPlaybackRate )
            
            BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_bounce_Fail',         'PLAY_LEFT_FOOT_FAIL',           'LeftFootFail',          false, false, false,             EBalanceBoardTrickStateType.FEET_FAIL,         feetPlaybackRate )
            BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_bounce_Fail',         'PLAY_RIGHT_FOOT_FAIL',          'RightFootFail',         false, false, false,             EBalanceBoardTrickStateType.FEET_FAIL,         feetPlaybackRate )
            
            BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_Idle',                'PLAY_LEFT_FOOT_IDLE',           'LeftFootIdle',          true,  false, false,             EBalanceBoardTrickStateType.LEFT_FOOT_IDLE,    feetPlaybackRate )
            BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_Idle',                'PLAY_RIGHT_FOOT_IDLE',          'RightFootIdle',         true,  false, false,             EBalanceBoardTrickStateType.RIGHT_FOOT_IDLE,   feetPlaybackRate )
            
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_to_R_Foot_inside',    'PLAY_RIGHT_FOOT_TO_INSIDE',     'RightFootToInside',     false, false, true,              EBalanceBoardTrickStateType.RIGHT_FOOT_INSIDE_BOUNCE, feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_inside_to_R_Foot',    'PLAY_RIGHT_INSIDE_TO_FOOT',     'RightInsideToFoot',     false, false, true,              EBalanceBoardTrickStateType.RIGHT_FOOT_IDLE,          feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_R_Foot_inside_bounce_cycle', 'PLAY_RIGHT_FOOT_INSIDE_BOUNCE', 'RightFootInsideBounce', true,  false, true,              EBalanceBoardTrickStateType.RIGHT_FOOT_INSIDE_BOUNCE, feetPlaybackRate )
			
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_to_L_Foot_inside',    'PLAY_LEFT_FOOT_TO_INSIDE',      'LeftFootToInside',      false, false, true,              EBalanceBoardTrickStateType.LEFT_FOOT_INSIDE_BOUNCE,  feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_inside_to_L_Foot',    'PLAY_LEFT_INSIDE_TO_FOOT',      'LeftInsideToFoot',      false, false, true,              EBalanceBoardTrickStateType.ANY_STATE,                feetPlaybackRate )
			BBSetup.AddSimpleMotion(  'CAT_BB_L_Foot_inside_bounce_cycle', 'PLAY_LEFT_FOOT_INSIDE_BOUNCE',  'LeftFootInsideBounce',  true,  false, true,              EBalanceBoardTrickStateType.LEFT_FOOT_INSIDE_BOUNCE,  feetPlaybackRate )
            
            -- Celebration
            BBSetup.AddCelebration()
            
            
			do	-- StateControl Motion
				local obj = AdaptState(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = 'StateControl'
				obj.StateScript = 'BalanceBoardPlayer'
				obj.InitialState = 'Idle'
			end
			do  -- EventBroadcaster Motion
				local obj = EventBroadcaster(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = 'EventBroadcaster'
			end
			do  -- FaceHandsSelector Motion
				local obj = FaceHandsSelector(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = 'FaceHandsSelector'
			end				
			do
			 	local obj = PhysicsMessenger(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'PhysicsMessenger'
			end
			do
			 	local obj = BalanceBoardMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'BalanceBoard'
			end
			do
			 	local obj = MotionList(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'Root'
			 	obj.Add('BalanceBoard')
			 	obj.Add('StateControl')
			 	obj.Add('EventBroadcaster')
			 	obj.Add('PhysicsMessenger')
				obj.Add('FaceHandsSelector')
			end
		end
		character.DAGRoot = 'Root'
		character.Initialize()
		
	end
end

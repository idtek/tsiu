PlayerSetup = {}
PlayerSetup.HeapIndex = EHeapIndex.ANIM_HEAPINDEX
PlayerSetup.MaxFootHeight = 0.5
PlayerSetup.MinChestHeight = PlayerSetup.MaxFootHeight
PlayerSetup.MaxChestHeight = 1.6
PlayerSetup.MaxSpeed = 7.5
PlayerSetup.MinSpeed = 0.5
PlayerSetup.TrapPlaybackRate = 0.9

PlayerSetup['AddPlayback'] = function(character, motionName, clipName, mirrored, cyclic)
	do
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = motionName
		obj.AddClip(clipName, mirrored, 0)
		obj.Cyclic = cyclic
	end	
end

PlayerSetup['CatchUnitHelper'] = function(character, motionName, adjustName, playName, clipName, mirror)
	do	-- playName
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	
	do  -- specificName
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Catch
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 100.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		obj.IsEntryCondition = true
		obj.AdjustTarget = true
		obj.AdjustPosition = true
	end	
	
	do	-- motionTypeName
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_CATCH_BALL
		obj.MotionType = EMotionType.Catch
	end 	
end

PlayerSetup['CatchUnit'] = function(character, baseName, clipName)
	local motionName	= baseName;
	local adjustName	= "ADJUST_"..motionName
	local playName		= "PLAY_"..motionName
	local lmotionName	= "M_"..motionName
	local ladjustName	= "M_"..adjustName
	local lplayName		= "M_"..playName

	PlayerSetup.CatchUnitHelper (character, baseName, adjustName, playName, clipName, false)
	PlayerSetup.CatchUnitHelper (character, lmotionName, ladjustName, lplayName, clipName, true)
end

PlayerSetup['AddCatches'] = function(character, prefix)
	PlayerSetup.CatchUnit(character, 'CATCH_1', prefix..'_catch_1')
	PlayerSetup.CatchUnit(character, 'CATCH_2', prefix..'_catch_2')
	PlayerSetup.CatchUnit(character, 'CATCH_3', prefix..'_catch_3')
	PlayerSetup.CatchUnit(character, 'CATCH_4', prefix..'_catch_4')
	PlayerSetup.CatchUnit(character, 'CATCH_5', prefix..'_catch_5')
	PlayerSetup.CatchUnit(character, 'CATCH_6', prefix..'_catch_6')
	PlayerSetup.CatchUnit(character, 'CATCH_7', prefix..'_catch_7')
	PlayerSetup.CatchUnit(character, 'CATCH_8', prefix..'_catch_8')
	PlayerSetup.CatchUnit(character, 'CATCH_9', prefix..'_catch_9')
	PlayerSetup.CatchUnit(character, 'CATCH_10', prefix..'_catch_10')
	PlayerSetup.CatchUnit(character, 'CATCH_11', prefix..'_catch_11')
	PlayerSetup.CatchUnit(character, 'CATCH_12', prefix..'_catch_12')
	PlayerSetup.CatchUnit(character, 'CATCH_13', prefix..'_catch_13')
	
	-- CATCH motion
	do
	    local obj = CatchContactBallNearestGridMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.ImpulseType = EBallImpulseType.Catch
    	
	    	
		obj.Name = 'CATCH'
	    obj.Add('CATCH_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_1', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_1', false, 0, 'Ball'))
	    obj.Add('CATCH_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_2', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_2', false, 0, 'Ball'))
	    obj.Add('CATCH_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_3', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_3', false, 0, 'Ball'))
	    obj.Add('CATCH_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_4', false, 0, 'Ball'))
	    obj.Add('CATCH_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_5', false, 0, 'Ball'))
	    obj.Add('CATCH_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_6', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_6', false, 0, 'Ball'))
	    obj.Add('CATCH_7', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_7', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_7', false, 0, 'Ball'))
	    obj.Add('CATCH_8', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_8', false, 0, 'Ball'))
	    obj.Add('CATCH_9', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_9', false, 0, 'Ball'))
	    obj.Add('CATCH_10', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_10', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_10', false, 0, 'Ball'))
	    obj.Add('CATCH_11', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_11', false, 0, 'Ball'))
	    obj.Add('CATCH_12', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_12', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_12', false, 0, 'Ball'))
	    obj.Add('CATCH_13', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_13', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_13', false, 0, 'Ball'))
	    obj.Add('M_CATCH_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_1', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_1', true, 0, 'Ball'))
	    obj.Add('M_CATCH_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_2', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_2', true, 0, 'Ball'))
	    obj.Add('M_CATCH_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_3', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_3', true, 0, 'Ball'))
	    obj.Add('M_CATCH_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_4', true, 0, 'Ball'))
	    obj.Add('M_CATCH_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_5', true, 0, 'Ball'))
	    obj.Add('M_CATCH_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_6', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_6', true, 0, 'Ball'))
	    obj.Add('M_CATCH_7', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_7', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_7', true, 0, 'Ball'))
	    obj.Add('M_CATCH_8', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_8', true, 0, 'Ball'))
	    obj.Add('M_CATCH_9', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_9', true, 0, 'Ball'))
	    obj.Add('M_CATCH_10', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_10', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_10', true, 0, 'Ball'))
	    obj.Add('M_CATCH_11', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_11', true, 0, 'Ball'))
	    obj.Add('M_CATCH_12', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_12', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_12', true, 0, 'Ball'))
	    obj.Add('M_CATCH_13', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_catch_13', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_catch_13', true, 0, 'Ball'))
	end
    	
	do
	    local obj = IgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'CATCH_IGNORE_CONTACT'
	end
	
	do
	    local obj = OverrideIgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'OVERRIDE_IGNORE_CONTACT'
	end
	
end

PlayerSetup['ParryUnitHelper'] = function(character, motionName, adjustName, playName, clipName, mirror)
	do	-- playName
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	
	do	-- specificName
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Catch
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 100.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		obj.IsEntryCondition = true
		obj.AdjustTarget = true
		obj.AdjustPosition = true
	end	
	
	do	-- motionTypeName
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_PARRY_BALL
		obj.MotionType = EMotionType.Parry
	end 	
end

PlayerSetup['ParryUnit'] = function(character, baseName, clipName)
	local playName = "PLAY_"..baseName
	local adjustName = "ADJUST_"..baseName
	local specificName = "SPECIFIC_"..baseName
	local motionTypeName = baseName
	local lplayName = "M_"..playName
	local ladjustName = "M_"..adjustName
	local lspecificName = "M_"..specificName
	local lmotionTypeName = "M_"..motionTypeName

	local motionName	= baseName;
	local adjustName	= "ADJUST_"..motionName
	local playName		= "PLAY_"..motionName
	local lmotionName	= "M_"..motionName
	local ladjustName	= "M_"..adjustName
	local lplayName		= "M_"..playName

	PlayerSetup.ParryUnitHelper (character, baseName, adjustName, playName, clipName, false)
	PlayerSetup.ParryUnitHelper (character, lmotionName, ladjustName, lplayName, clipName, true)
end

PlayerSetup['AddParries'] = function(character, prefix)
	PlayerSetup.ParryUnit(character, 'PARRY_1', prefix..'_parry_1')
	PlayerSetup.ParryUnit(character, 'PARRY_2', prefix..'_parry_2')
	PlayerSetup.ParryUnit(character, 'PARRY_3', prefix..'_parry_3')
	PlayerSetup.ParryUnit(character, 'PARRY_4', prefix..'_parry_4')
	PlayerSetup.ParryUnit(character, 'PARRY_5', prefix..'_parry_5')
	PlayerSetup.ParryUnit(character, 'PARRY_6', prefix..'_parry_6')
	PlayerSetup.ParryUnit(character, 'PARRY_7', prefix..'_parry_7')
	PlayerSetup.ParryUnit(character, 'PARRY_8', prefix..'_parry_8')
	PlayerSetup.ParryUnit(character, 'PARRY_9', prefix..'_parry_9')
	PlayerSetup.ParryUnit(character, 'PARRY_10', prefix..'_parry_10')
	PlayerSetup.ParryUnit(character, 'PARRY_11', prefix..'_parry_11')
	PlayerSetup.ParryUnit(character, 'PARRY_12', prefix..'_parry_12')
	PlayerSetup.ParryUnit(character, 'PARRY_13', prefix..'_parry_13')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_1', prefix..'_QUICKparry_4')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_2', prefix..'_QUICKparry_5')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_3', prefix..'_QUICKparry_8')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_4', prefix..'_QUICKparry_9')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_5', prefix..'_QUICKparry_11')
	PlayerSetup.ParryUnit(character, 'QUICKPARRY_6', prefix..'_QUICKparry_11a')

	do	
		-- PARRY motion
		local obj = ParryContactBallNearestGridMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		obj.ImpulseType = EBallImpulseType.Parry
		
		obj.Name = 'PARRY'
		obj.Add('PARRY_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_1', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_1', false, 0, 'Ball'))
		obj.Add('PARRY_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_2', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_2', false, 0, 'Ball'))
		obj.Add('PARRY_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_3', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_3', false, 0, 'Ball'))
		obj.Add('PARRY_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_4', false, 0, 'Ball'))
		obj.Add('PARRY_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_5', false, 0, 'Ball'))
		obj.Add('PARRY_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_6', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_6', false, 0, 'Ball'))
		obj.Add('PARRY_7', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_7', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_7', false, 0, 'Ball'))
		obj.Add('PARRY_8', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_8', false, 0, 'Ball'))
		obj.Add('PARRY_9', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_9', false, 0, 'Ball'))
		obj.Add('PARRY_10', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_10', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_10', false, 0, 'Ball'))
		obj.Add('PARRY_11', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_11', false, 0, 'Ball'))
		obj.Add('PARRY_12', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_12', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_12', false, 0, 'Ball'))
		obj.Add('PARRY_13', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_13', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_13', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_4', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_5', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_8', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_9', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_11', false, 0, 'Ball'))
		obj.Add('QUICKPARRY_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_11a', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_11a', false, 0, 'Ball'))
		obj.Add('M_PARRY_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_1', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_1', true, 0, 'Ball'))
		obj.Add('M_PARRY_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_2', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_2', true, 0, 'Ball'))
		obj.Add('M_PARRY_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_3', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_3', true, 0, 'Ball'))
		obj.Add('M_PARRY_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_4', true, 0, 'Ball'))
		obj.Add('M_PARRY_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_5', true, 0, 'Ball'))
		obj.Add('M_PARRY_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_6', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_6', true, 0, 'Ball'))
		obj.Add('M_PARRY_7', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_7', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_7', true, 0, 'Ball'))
		obj.Add('M_PARRY_8', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_8', true, 0, 'Ball'))
		obj.Add('M_PARRY_9', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_9', true, 0, 'Ball'))
		obj.Add('M_PARRY_10', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_10', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_10', true, 0, 'Ball'))
		obj.Add('M_PARRY_11', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_11', true, 0, 'Ball'))
		obj.Add('M_PARRY_12', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_12', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_12', true, 0, 'Ball'))
		obj.Add('M_PARRY_13', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_parry_13', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_parry_13', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_4', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_4', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_5', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_5', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_8', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_8', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_4', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_9', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_9', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_5', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_11', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_11', true, 0, 'Ball'))
		obj.Add('M_QUICKPARRY_6', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_QUICKparry_11a', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_QUICKparry_11a', true, 0, 'Ball'))
	end	
	
	do
	    local obj = OverrideIgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'OVERRIDE_IGNORE_CONTACT'
	end
	
end

PlayerSetup['DiveOnBallHelper'] = function(character, motionName, clipName, mirror)
	local playName = 'PLAY_' .. motionName
	local adjustName = 'ADJUST_' .. motionName
	do	-- playName
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	do  -- adjustName
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Catch
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 100.0
		obj.ContactDirection = 'DesiredContactDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		obj.IsEntryCondition = true
		obj.AdjustTarget = true
		obj.AdjustPosition = true
		obj.AdjustOrientation = true
	end	
	do	-- motionTypeName
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_DIVEON_BALL
		obj.MotionType = EMotionType.Catch
	end 	
end

PlayerSetup['AddDives'] = function(character, prefix)
	PlayerSetup.DiveOnBallHelper (character, 'DIVEONBALL_0', prefix..'_JUMPonBALL', false)
	PlayerSetup.DiveOnBallHelper (character, 'DIVEONBALL_1', prefix..'_pounce_0', false)
	PlayerSetup.DiveOnBallHelper (character, 'DIVEONBALL_2', prefix..'_pounce_CC45', false)
	PlayerSetup.DiveOnBallHelper (character, 'M_DIVEONBALL_2', prefix..'_pounce_CC45', true)
	PlayerSetup.DiveOnBallHelper (character, 'DIVEONBALL_3', prefix..'_BUM_Slide_onBALL', false)
	
	do 
		local obj = DiveBallMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = 'DIVEONBALL'
		obj.Add('DIVEONBALL_0', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_JUMPonBALL', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_JUMPonBALL', false, 0, 'Ball') )
		obj.Add('DIVEONBALL_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_pounce_0', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_pounce_0', false, 0, 'Ball') )
		obj.Add('DIVEONBALL_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_pounce_CC45', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_pounce_CC45', false, 0, 'Ball') )
		obj.Add('M_DIVEONBALL_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_pounce_CC45', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_pounce_CC45', true, 0, 'Ball') )
		obj.Add('DIVEONBALL_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_BUM_Slide_onBALL', EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_BUM_Slide_onBALL', false, 0, 'Ball') )
	end
	
	do
	    local obj = OverrideIgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'OVERRIDE_IGNORE_CONTACT'
	end
end

PlayerSetup['MissSaveUnitHelper'] = function(character, motionName, playName, clipName, mirror)
	
	do	-- playName
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	
	do	-- motionTypeName
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_MISS_SAVE_BALL
		obj.MotionType = EMotionType.MissSave
	end 	

end

PlayerSetup['MissSaveUnit'] = function(character, baseName, clipName)
	local motionName = baseName
	local playName = "PLAY_"..motionName
	local lmotionName = "M_"..motionName
	local lplayName = "M_"..playName

	PlayerSetup.MissSaveUnitHelper (character, motionName, playName, clipName, false)
	PlayerSetup.MissSaveUnitHelper (character, lmotionName, lplayName, clipName, true)
end

PlayerSetup['AddMissSaves'] = function(character, prefix)
	PlayerSetup.MissSaveUnit(character, 'MISS_SAVE_1', prefix..'_missed_save_A')
	PlayerSetup.MissSaveUnit(character, 'MISS_SAVE_2', prefix..'_missed_save_B')
	PlayerSetup.MissSaveUnit(character, 'MISS_SAVE_3', prefix..'_missed_save_C')
	
	do
		-- MISS_SAVE motion
		local obj = ContactBallNearestGridMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'MISS_SAVE'
		obj.IgnoreFailedIntersect = true
		obj.Add('MISS_SAVE_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_A', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_A', false, 0, 'Ball'))
		obj.Add('MISS_SAVE_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_B', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_B', false, 0, 'Ball'))
		obj.Add('MISS_SAVE_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_C', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_C', false, 0, 'Ball'))
		obj.Add('M_MISS_SAVE_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_A', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_A', true, 0, 'Ball'))
		obj.Add('M_MISS_SAVE_2', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_B', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_B', true, 0, 'Ball'))
		obj.Add('M_MISS_SAVE_3', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_C', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_C', true, 0, 'Ball'))
	end
	
	do
	    local obj = OverrideIgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'OVERRIDE_IGNORE_CONTACT'
	end
	
end

PlayerSetup['MissSaveWideUnitHelper'] = function(character, motionName, playName, clipName, mirror)
	
	do	-- playName
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	
	do	-- motionTypeName
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_MISS_SAVE_WIDE_BALL
		obj.MotionType = EMotionType.MissSave
	end 	
	
end

PlayerSetup['MissSaveWideUnit'] = function(character, baseName, clipName)
	local motionName = baseName
	local playName = "PLAY_"..motionName
	local lmotionName = "M_"..motionName
	local lplayName = "M_"..playName

	PlayerSetup.MissSaveWideUnitHelper (character, motionName, playName, clipName, false)
	PlayerSetup.MissSaveWideUnitHelper (character, lmotionName, lplayName, clipName, true)
end

PlayerSetup['AddMissSavesWide'] = function(character, prefix)
	PlayerSetup.MissSaveWideUnit(character, 'MISS_SAVE_WIDE_1', prefix..'_missed_save_noGoal')
	
	do
		-- MISS_SAVE motion
		local obj = ContactBallNearestGridMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'MISS_SAVE_WIDE'
		obj.IgnoreFailedIntersect = true
		obj.Add('MISS_SAVE_WIDE_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_noGoal', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_noGoal', false, 0, 'Ball'))
		obj.Add('M_MISS_SAVE_WIDE_1', EBallImpulseType.AnimatedBall, ClipManager.GetTagTime(prefix..'_missed_save_noGoal', EAnimTag.HeadBallCollision.Value, EAnimTag.StopBallAnim.Value, 0), ClipManager.GetOffsetToJoint(prefix..'_missed_save_noGoal', true, 0, 'Ball'))
	end

	do
	    local obj = OverrideIgnoreContactMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'OVERRIDE_IGNORE_CONTACT'
	end
	
end

PlayerSetup['AddSaves'] = function(character, prefix)
	PlayerSetup.AddDives(character, prefix)
	PlayerSetup.AddCatches(character, prefix)
	PlayerSetup.AddParries(character, prefix)
	PlayerSetup.AddMissSaves(character, prefix)
	PlayerSetup.AddMissSavesWide(character, prefix)
	
	local obj = CompositeMotion(PlayerSetup.HeapIndex)
	ptr = AutoInstance()
	ptr.Set(obj)
	character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
	obj.Name = 'SAVE'
	obj.Add('DIVEONBALL')
	obj.Add('CATCH')
	obj.Add('PARRY')
	obj.Add('MISS_SAVE')
	obj.Add('MISS_SAVE_WIDE')
end	

PlayerSetup['StandVolley'] = function(	character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, 
										mirror, minHeight, maxHeight, startState )

	local playName		= "PLAY_"..baseName
	local adjustName	= "ADJUST_"..baseName
	local motionName	= baseName
	
	local startStartPosition = ClipManager.GetStateStartPosition(clipName, mirror, startState, 0)

	do	-- PLAY_KICK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	do	-- ADJUST_KICK
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, startStartPosition.AsFloat(), 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minA
		obj.Max = maxA
		obj.IsEntryCondition = true
		obj.AdjustOrientation = true
		obj.AdjustPosition = false
		obj.AdjustTarget = true
	end
	do	-- RUN_KICK motion
		local obj = ExpectedVolleyIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.IsEntryCondition = true
		obj.KickType = kickType
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_KICK_BALL
		
		obj.Height = 'TrapHeight'
		obj.MinHeight = minHeight
		obj.MaxHeight = maxHeight
		obj.MotionType = motionType
	end 
	
end

PlayerSetup['RunVolley'] = function(	character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, 
										mirror, minHeight, maxHeight, startState )
	
	local phasedName = "PHASED_" .. baseName
	PlayerSetup.StandVolley( character, phasedName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, mirror, minHeight, maxHeight, startState )

	do -- PHASED_
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
		obj.Name = baseName
		obj.Playback = phasedName
		obj.StartState = startState
		obj.StartPosition = startStatePosition
		obj.StartRegion = 0
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
		obj.Duration = 0.1 -- 6 frames
	end
	
end


PlayerSetup['KickUnitHelper'] = function(	character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, 
											mirror, startState )

	local footednessName = baseName
	if ( startState == EAnimState.RightFootOnGround.Value ) then 
		footednessName	= 'R_'..footednessName
	else
		footednessName	= 'L_'..footednessName
	end

	local playName		= "PLAY_"..footednessName
	local adjustName	= "ADJUST_"..footednessName
	local phasedName	= "PHASED_"..footednessName
	local motionName	= footednessName
	
	local startStartPosition = ClipManager.GetStateStartPosition(clipName, mirror, startState, 0)

	do	-- PLAY_KICK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end

	do	-- ADJUST_KICK
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, startStartPosition.Value, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minA
		obj.Max = maxA
		obj.AdjustOrientation = false
	end
	do -- PHASED_
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
		obj.Name = phasedName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartPosition = startStartPosition.Value
		obj.StartRegion = 0
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
		obj.Duration = 0.1 -- 6 frames
	end
	do	-- RUN_KICK motion
		local obj = ExpectedKickIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = phasedName
		obj.BeforeContact = true
		obj.KickType = kickType
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_KICK_BALL
		obj.MotionType = motionType
	end 
	
end

PlayerSetup['DoubleKickUnitHelper'] = function(character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, 
												mirror, talentID)
	local playName = "PLAY_"..baseName
	local adjustName = "ADJUST_"..baseName
	local motionTypeName = baseName

	if mirror == true then
		playName = "M_"..playName
		adjustName = "M_"..adjustName
		motionTypeName = "M_"..motionTypeName
	end

	do	-- PLAY_KICK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end

	do	-- ADJUST_KICK
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 1)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 100.0 -- this test should never fail for talent kicks
		obj.PlaybackAngle = playbackAngle
		obj.Min = minA
		obj.Max = maxA
		obj.AdjustOrientation = false
	end

	do	-- RUN_KICK motion
		local obj = TalentKickIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionTypeName
		obj.Playback = adjustName
		obj.BeforeContact = true
		obj.KickType = kickType
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_KICK_BALL
		obj.MotionType = motionType
		obj.TalentID = talentID
	end 
end

-- shot unit helper sets up transitions from both the right and left foot, using the same clip mirrored
PlayerSetup['AddStandShot'] = function(	character, baseName, clipName, mirror, motionType, impulseType, kickType, minA, maxA, playbackAngle )

	local playName = "PLAY_"..baseName
	local adjustName = "ADJUST_"..baseName
	local blendName = "BLEND_"..baseName
	local motionName = baseName

	do	-- PLAY_KICK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	do	-- ADJUST_KICK
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = impulseType
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minA
		obj.Max = maxA
		obj.IsEntryCondition = true
		obj.AdjustOrientation = false
	end
	do
		local obj = CrossFade(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = blendName
		obj.Playback = adjustName
		obj.Duration = 0.05 -- 3 frames
	end
	do	-- RUN_KICK motion
		local obj = ExpectedKickIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = blendName
		
		obj.BeforeContact = true
		obj.KickType = kickType
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_KICK_BALL
		obj.MotionType = motionType
	end 
end

-- shot unit helper sets up transitions from both the right and left foot, using the same clip mirrored
PlayerSetup['AddRunShot'] = function(	character, baseName, clipName, mirror, startState, motionType, impulseType, kickType, minA, maxA, playbackAngle )

	local playName = "PLAY_"..baseName
	local adjustName = "ADJUST_"..baseName
	local blendName = "BLEND_"..baseName
	local motionName = baseName

	do	-- PLAY_KICK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.AddClip(clipName, mirror, 0)
		obj.Cyclic = false
	end
	do	-- ADJUST_KICK
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = impulseType
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minA
		obj.Max = maxA
		obj.IsEntryCondition = true
		obj.AdjustOrientation = false
	end
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = blendName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirror, obj.StartState, 0).Value
		obj.StartRegion = 0.01667
		obj.EndRegion = 0.01667
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
	do	-- RUN_KICK motion
		local obj = ExpectedKickIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = blendName
		
		obj.BeforeContact = true
		obj.KickType = kickType
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_KICK_BALL
		obj.MotionType = motionType
	end 
end

PlayerSetup['AddPowerShots'] = function(character)
	local impulseType = EBallImpulseType.PowerShot
	local motionType = EMotionType.PowerShot
	local kickType = EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT
	
	PlayerSetup.AddRunShot(character, 'LEFT_RUN_POWERSHOT_0',		'CAT_run_powershot_0',		true,	EAnimState.LeftFootOnGround.Value,	motionType, impulseType, kickType,  -45,   45,    0)
	PlayerSetup.AddRunShot(character, 'LEFT_RUN_POWERSHOT_CC90',	'CAT_run_powershot_CW90',	true,	EAnimState.LeftFootOnGround.Value,	motionType, impulseType, kickType,   45,  135,   90)
	PlayerSetup.AddRunShot(character, 'LEFT_RUN_POWERSHOT_CW90',	'CAT_run_powershot_CC90',	true,	EAnimState.LeftFootOnGround.Value,	motionType, impulseType, kickType, -135,  -45,  -90)
	PlayerSetup.AddRunShot(character, 'LEFT_RUN_POWERSHOT_CC180',	'CAT_run_powershot_CC180',	true,	EAnimState.LeftFootOnGround.Value,	motionType, impulseType, kickType,  135,  180,  180)
	PlayerSetup.AddRunShot(character, 'LEFT_RUN_POWERSHOT_CW180',	'CAT_run_powershot_CC180',	true,	EAnimState.LeftFootOnGround.Value,	motionType, impulseType, kickType, -180, -135, -180)

	PlayerSetup.AddRunShot(character, 'RIGHT_RUN_POWERSHOT_0',		'CAT_run_powershot_0',		false,	EAnimState.RightFootOnGround.Value,	motionType, impulseType, kickType,  -45,   45,    0)
	PlayerSetup.AddRunShot(character, 'RIGHT_RUN_POWERSHOT_CC90',	'CAT_run_powershot_CC90',	false,	EAnimState.RightFootOnGround.Value,	motionType, impulseType, kickType,   45,  135,   90)
	PlayerSetup.AddRunShot(character, 'RIGHT_RUN_POWERSHOT_CW90',	'CAT_run_powershot_CW90',	false,	EAnimState.RightFootOnGround.Value,	motionType, impulseType, kickType, -135,  -45,  -90)
	PlayerSetup.AddRunShot(character, 'RIGHT_RUN_POWERSHOT_CC180',	'CAT_run_powershot_CC180',	false,	EAnimState.RightFootOnGround.Value,	motionType, impulseType, kickType,  135,  180,  180)
	PlayerSetup.AddRunShot(character, 'RIGHT_RUN_POWERSHOT_CW180',	'CAT_run_powershot_CC180',	false,	EAnimState.RightFootOnGround.Value,	motionType, impulseType, kickType, -180, -135, -180)
																												 
	PlayerSetup.AddStandShot(character, 'STAND_POWERSHOT_0',		'CAT_stand_powershot_0',		false,	motionType, impulseType, kickType,  -45,   45,    0)
	PlayerSetup.AddStandShot(character, 'STAND_POWERSHOT_CC90',		'CAT_stand_powershot_CC90',		false,	motionType, impulseType, kickType,   45,  135,   90)
	PlayerSetup.AddStandShot(character, 'STAND_POWERSHOT_CW90',		'CAT_stand_powershot_CC90',		true,	motionType, impulseType, kickType, -135,  -45,  -90)
	PlayerSetup.AddStandShot(character, 'STAND_POWERSHOT_CC180',	'CAT_stand_powershot_CC180',	false,	motionType, impulseType, kickType,  135,  180,  180)
	PlayerSetup.AddStandShot(character, 'STAND_POWERSHOT_CW180',	'CAT_stand_powershot_CC180',	true,	motionType, impulseType, kickType, -180, -135, -180)
	

	do	-- RUN_KICK motion
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_POWER_SHOT'
		obj.Add('LEFT_RUN_POWERSHOT_0')
		obj.Add('RIGHT_RUN_POWERSHOT_0')
		obj.Add('LEFT_RUN_POWERSHOT_CC90')
		obj.Add('RIGHT_RUN_POWERSHOT_CC90')
		obj.Add('LEFT_RUN_POWERSHOT_CW90')
		obj.Add('RIGHT_RUN_POWERSHOT_CW90')
		obj.Add('LEFT_RUN_POWERSHOT_CC180')
		obj.Add('RIGHT_RUN_POWERSHOT_CC180')
		obj.Add('LEFT_RUN_POWERSHOT_CW180')
		obj.Add('RIGHT_RUN_POWERSHOT_CW180')
	end 
	do	-- RUN_KICK motion
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'STAND_POWER_SHOT'
		
		obj.Add('STAND_POWERSHOT_0')
		obj.Add('STAND_POWERSHOT_CC90')
		obj.Add('STAND_POWERSHOT_CW90')
		obj.Add('STAND_POWERSHOT_CW180')
		obj.Add('STAND_POWERSHOT_CC180')
	end 
end

PlayerSetup['AddHeadersAndVolleys'] = function( character, 
												stand_volley_char, stand_scissor_char, stand_header_char,
												run_volley_char, run_scissor_char, run_header_char )
	local impulseType	= EBallImpulseType.Volley
	local motionType	= EMotionType.Volley
	local kickType		= EKickTypeInfo.EKickTypeInfo_FOR_VOLLEY
	local volleyHeight	= { min = 0.0,	max = 1.51 }
	local scissorHeight	= { min = 1.5,	max = 1000.0 }
	local headerHeight	= scissorHeight

	-- character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, mirror, minSpeed, maxSpeed, minHeight, maxHeight, startState
	PlayerSetup.StandVolley(character, 'STAND_VOLLEY_0',		stand_volley_char .. '_Stand_volley_0',			impulseType, motionType,  -45,   45, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_VOLLEY_CC90',		stand_volley_char .. '_Stand_volley_CC90',		impulseType, motionType,   45,  135, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_VOLLEY_CW90',		stand_volley_char .. '_Stand_volley_CC90',		impulseType, motionType, -135,  -45, kickType, 0, true,		volleyHeight.min, volleyHeight.max, EAnimState.LeftFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_VOLLEY_CC180',	stand_volley_char .. '_Stand_volley_CC180',		impulseType, motionType,  135,  180, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_VOLLEY_CW180',	stand_volley_char .. '_Stand_volley_CC180',		impulseType, motionType, -180, -135, kickType, 0, true,		volleyHeight.min, volleyHeight.max, EAnimState.LeftFootOnGround.Value)
	
	PlayerSetup.StandVolley(character, 'STAND_SCISSOR_0',		stand_scissor_char .. '_stand_scissor_CC180',	impulseType, motionType,  -45,   45, kickType, 0, false,	scissorHeight.min, scissorHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_SCISSOR_CC90',	stand_scissor_char .. '_stand_scissor_CC90',	impulseType, motionType,   45,  135, kickType, 0, false,	scissorHeight.min, scissorHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_SCISSOR_CW90',	stand_scissor_char .. '_stand_scissor_CC90',	impulseType, motionType, -135,  -45, kickType, 0, true,		scissorHeight.min, scissorHeight.max, EAnimState.LeftFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_SCISSOR_CC180',	stand_scissor_char .. '_stand_scissor_0',		impulseType, motionType,  135,  180, kickType, 0, false,	scissorHeight.min, scissorHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_SCISSOR_CW180',	stand_scissor_char .. '_stand_scissor_0',		impulseType, motionType, -180, -135, kickType, 0, false,	scissorHeight.min, scissorHeight.max, EAnimState.RightFootOnGround.Value)

	PlayerSetup.StandVolley(character, 'STAND_HEADER_0',		stand_header_char .. '_stand_jump_header_0',		impulseType, motionType,  -45,   45, kickType, 0, false, headerHeight.min, headerHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_HEADER_CC90',		stand_header_char .. '_stand_jump_header_CC90',		impulseType, motionType,   45,  135, kickType, 0, false, headerHeight.min, headerHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_HEADER_CW90',		stand_header_char .. '_stand_jump_header_CW90',		impulseType, motionType, -135,  -45, kickType, 0, false, headerHeight.min, headerHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_HEADER_CC180',	stand_header_char .. '_stand_jump_header_CC180',	impulseType, motionType,  135,  180, kickType, 0, false, headerHeight.min, headerHeight.max, EAnimState.RightFootOnGround.Value)
	PlayerSetup.StandVolley(character, 'STAND_HEADER_CW180',	stand_header_char .. '_stand_jump_header_CW180',	impulseType, motionType, -180, -135, kickType, 0, false, headerHeight.min, headerHeight.max, EAnimState.RightFootOnGround.Value)

	PlayerSetup.RunVolley(character, 'R_RUN_VOLLEY_0',		run_volley_char .. '_Run_volley_0',		impulseType, motionType,  -45,   45, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value );
	PlayerSetup.RunVolley(character, 'R_RUN_VOLLEY_CC90',	run_volley_char .. '_Run_volley_CC90',	impulseType, motionType,   45,  180, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value );
	PlayerSetup.RunVolley(character, 'R_RUN_VOLLEY_CW90',	run_volley_char .. '_Run_volley_CW90',	impulseType, motionType, -180,  -45, kickType, 0, false,	volleyHeight.min, volleyHeight.max, EAnimState.RightFootOnGround.Value );
	PlayerSetup.RunVolley(character, 'L_RUN_VOLLEY_0',		run_volley_char .. '_Run_volley_0',		impulseType, motionType,  -45,   45, kickType, 0, true,		volleyHeight.min, volleyHeight.max, EAnimState.LeftFootOnGround.Value );
	PlayerSetup.RunVolley(character, 'L_RUN_VOLLEY_CW90',	run_volley_char .. '_Run_volley_CC90',	impulseType, motionType, -180,  -45, kickType, 0, true,		volleyHeight.min, volleyHeight.max, EAnimState.LeftFootOnGround.Value );
	PlayerSetup.RunVolley(character, 'L_RUN_VOLLEY_CC90',	run_volley_char .. '_Run_volley_CW90',	impulseType, motionType,   45,  180, kickType, 0, true,		volleyHeight.min, volleyHeight.max, EAnimState.LeftFootOnGround.Value );
	
	-- craigf - and the other foot for runs?
	
	do	-- 
		local obj = RandomCompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_VOLLEY'
		obj.Add('STAND_SCISSOR_0')
		obj.Add('STAND_SCISSOR_CC90')
		obj.Add('STAND_SCISSOR_CW90')
		obj.Add('STAND_SCISSOR_CC180')
		obj.Add('STAND_SCISSOR_CW180')

		obj.Add('STAND_HEADER_0')
		obj.Add('STAND_HEADER_CC90')
		obj.Add('STAND_HEADER_CW90')
		obj.Add('STAND_HEADER_CC180')
		obj.Add('STAND_HEADER_CW180')
		
		obj.Add('R_RUN_VOLLEY_0')
		obj.Add('R_RUN_VOLLEY_CC90')
		obj.Add('R_RUN_VOLLEY_CW90')
		obj.Add('L_RUN_VOLLEY_0')
		obj.Add('L_RUN_VOLLEY_CC90')
		obj.Add('L_RUN_VOLLEY_CW90')
	end 

	do	-- 
		local obj = RandomCompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'STAND_VOLLEY'
		obj.Add('STAND_SCISSOR_0')
		obj.Add('STAND_SCISSOR_CC90')
		obj.Add('STAND_SCISSOR_CW90')
		obj.Add('STAND_SCISSOR_CC180')
		obj.Add('STAND_SCISSOR_CW180')
		
		obj.Add('STAND_HEADER_0')
		obj.Add('STAND_HEADER_CC90')
		obj.Add('STAND_HEADER_CW90')
		obj.Add('STAND_HEADER_CC180')
		obj.Add('STAND_HEADER_CW180')
		
		obj.Add('STAND_VOLLEY_0')
		obj.Add('STAND_VOLLEY_CC90')
		obj.Add('STAND_VOLLEY_CW90')
		obj.Add('STAND_VOLLEY_CC180')
		obj.Add('STAND_VOLLEY_CW180')
	end 
	
end

PlayerSetup['AddPasses'] = function(character)

	local impulseType = EBallImpulseType.LowPass
	local motionType = EMotionType.LowPass
	local kickType = EKickTypeInfo.EKickTypeInfo_FOR_LOW_PASS
	
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_0',		'CAT_Stand_pass_0',		impulseType, motionType,  -45,   45, kickType,    0, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CC90',	'CAT_Stand_pass_cw90',	impulseType, motionType,   45,  135, kickType,   90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CW90',	'CAT_Stand_pass_cc90',	impulseType, motionType, -135,  -45, kickType,  -90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CC180',	'CAT_Stand_pass_cw180',	impulseType, motionType,  135,  180, kickType,  180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CW180',	'CAT_Stand_pass_cc180',	impulseType, motionType, -180, -135, kickType, -180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_0',			'CAT_Run_pass_0',		impulseType, motionType,  -45,   45, kickType,    0, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CC90',		'CAT_Run_pass_cw90',	impulseType, motionType,   45,  135, kickType,   90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CW90',		'CAT_Run_pass_cc90',	impulseType, motionType, -135,  -45, kickType,  -90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CC180',		'CAT_Run_pass_cw180',	impulseType, motionType,  135,  180, kickType,  180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CW180',		'CAT_Run_pass_cc180',	impulseType, motionType, -180, -135, kickType, -180, true,	EAnimState.LeftFootOnGround.Value)
	
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_0',		'CAT_Stand_pass_0',		impulseType, motionType,  -45,   45, kickType,    0, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CW90',	'CAT_Stand_pass_cw90',	impulseType, motionType, -135,  -45, kickType,  -90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CC90',	'CAT_Stand_pass_cc90',	impulseType, motionType,   45,  135, kickType,   90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CW180',	'CAT_Stand_pass_cw180',	impulseType, motionType, -180, -135, kickType, -180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_LOW_PASS_CC180',	'CAT_Stand_pass_cc180',	impulseType, motionType,  135,  180, kickType,  180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_0',			'CAT_Run_pass_0',		impulseType, motionType,  -45,   45, kickType,    0, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CW90',		'CAT_Run_pass_cw90',	impulseType, motionType, -135,  -45, kickType,  -90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CC90',		'CAT_Run_pass_cc90',	impulseType, motionType,   45,  135, kickType,   90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CW180',		'CAT_Run_pass_cw180',	impulseType, motionType, -180, -135, kickType, -180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_LOW_PASS_CC180',		'CAT_Run_pass_cc180',	impulseType, motionType,  135,  180, kickType,  180, false,	EAnimState.RightFootOnGround.Value)

	-- character, baseName, clipName, kickStyle, motionType, minA, maxA, kickType, playbackAngle, mirror, minSpeed, maxSpeed, startState
	impulseType = EBallImpulseType.HighPass
	motionType = EMotionType.HighPass
	kickType = EKickTypeInfo.EKickTypeInfo_FOR_HIGH_PASS
	
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_0',		'CAT_stand_highpass_0',		impulseType, motionType,  -45,   45, kickType,    0, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CC90',	'CAT_stand_highpass_cw90',	impulseType, motionType,   45,  135, kickType,   90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CW90',	'CAT_stand_highpass_cc90',	impulseType, motionType, -135,  -45, kickType,  -90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CC180',	'CAT_stand_highpass_cw180',	impulseType, motionType,  135,  180, kickType,  180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CW180',	'CAT_stand_highpass_cc180',	impulseType, motionType, -180, -135, kickType, -180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_0',		'CAT_Run_highpass_0',		impulseType, motionType,  -45,   45, kickType,    0, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CW90',		'CAT_Run_highpass_cc90',	impulseType, motionType, -135,  -45, kickType,  -90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CC90',		'CAT_Run_highpass_cw90',	impulseType, motionType,   45,  135, kickType,   90, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CW180',	'CAT_Run_highpass_cc180',	impulseType, motionType, -180, -135, kickType, -180, true,	EAnimState.LeftFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CC180',	'CAT_Run_highpass_cw180',	impulseType, motionType,  135,  180, kickType,  180, true,	EAnimState.LeftFootOnGround.Value)
	
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_0',		'CAT_stand_highpass_0',		impulseType, motionType,  -45,   45, kickType,    0, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CC90',	'CAT_stand_highpass_cc90',	impulseType, motionType,   45,  135, kickType,   90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CW90',	'CAT_stand_highpass_cw90',	impulseType, motionType, -135,  -45, kickType,  -90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CC180',	'CAT_stand_highpass_cc180',	impulseType, motionType,  135,  180, kickType,  180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'STAND_HIGH_PASS_CW180',	'CAT_stand_highpass_cw180',	impulseType, motionType, -180, -135, kickType, -180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_0',		'CAT_Run_highpass_0',		impulseType, motionType,  -45,   45, kickType,    0, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CC90',		'CAT_Run_highpass_cc90',	impulseType, motionType,   45,  135, kickType,   90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CW90',		'CAT_Run_highpass_cw90',	impulseType, motionType, -135,  -45, kickType,  -90, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CC180',	'CAT_Run_highpass_cc180',	impulseType, motionType,  135,  180, kickType,  180, false,	EAnimState.RightFootOnGround.Value)
	PlayerSetup.KickUnitHelper(character, 'RUN_HIGH_PASS_CW180',	'CAT_Run_highpass_cw180',	impulseType, motionType, -180, -135, kickType, -180, false,	EAnimState.RightFootOnGround.Value)

	do	-- RUN_HIGH_PASS motion
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_PASS'
		
		obj.Add('L_RUN_HIGH_PASS_0')
		obj.Add('R_RUN_HIGH_PASS_0')
		obj.Add('L_RUN_LOW_PASS_0')
		obj.Add('R_RUN_LOW_PASS_0')
		obj.Add('L_RUN_HIGH_PASS_CC90')
		obj.Add('R_RUN_HIGH_PASS_CC90')
		obj.Add('L_RUN_LOW_PASS_CC90')
		obj.Add('R_RUN_LOW_PASS_CC90')
		obj.Add('L_RUN_HIGH_PASS_CW90')
		obj.Add('R_RUN_HIGH_PASS_CW90')
		obj.Add('L_RUN_LOW_PASS_CW90')
		obj.Add('R_RUN_LOW_PASS_CW90')
	end 
	
	do	-- RUN_HIGH_PASS motion
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_PASS_TO_IDLE'
		
		obj.Add('L_RUN_HIGH_PASS_CC180')
		obj.Add('R_RUN_HIGH_PASS_CC180')
		obj.Add('L_RUN_HIGH_PASS_CW180')
		obj.Add('R_RUN_HIGH_PASS_CW180')
		obj.Add('L_RUN_LOW_PASS_CC180')
		obj.Add('R_RUN_LOW_PASS_CC180')
		obj.Add('L_RUN_LOW_PASS_CW180')
		obj.Add('R_RUN_LOW_PASS_CW180')
	end 
	
	do	-- STAND_HIGH_PASS motion
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'STAND_PASS'
		obj.Add('R_STAND_HIGH_PASS_0')
		obj.Add('R_STAND_HIGH_PASS_CC90')
		obj.Add('R_STAND_HIGH_PASS_CW90')
		obj.Add('R_STAND_HIGH_PASS_CC180')
		obj.Add('R_STAND_HIGH_PASS_CW180')
		
		obj.Add('L_STAND_HIGH_PASS_0')
		obj.Add('L_STAND_HIGH_PASS_CC90')
		obj.Add('L_STAND_HIGH_PASS_CW90')
		obj.Add('L_STAND_HIGH_PASS_CC180')
		obj.Add('L_STAND_HIGH_PASS_CW180')
		
		obj.Add('R_STAND_LOW_PASS_0')
		obj.Add('R_STAND_LOW_PASS_CC90')
		obj.Add('R_STAND_LOW_PASS_CW90')
		obj.Add('R_STAND_LOW_PASS_CC180')
		obj.Add('R_STAND_LOW_PASS_CW180')

		obj.Add('L_STAND_LOW_PASS_0')
		obj.Add('L_STAND_LOW_PASS_CC90')
		obj.Add('L_STAND_LOW_PASS_CW90')
		obj.Add('L_STAND_LOW_PASS_CC180')
		obj.Add('L_STAND_LOW_PASS_CW180')
	end 
end

PlayerSetup['AddTackles'] = function(character, slidePrefix, leftRightPrefix)
	
	local slideTackleClip		  = slidePrefix.."_TACKLE_Slide_0"
	local leftRighTackleClip	  = leftRightPrefix.."_grasscutter_tackle_CC"
	local contactThreshold		  = 0.5
	
	PlayerSetup.AddPlayback(character, 'PLAY_SLIDE_TACKLE', slideTackleClip, false, false)
	PlayerSetup.AddPlayback(character, 'PLAY_SLIDE_TACKLE_LEFT', leftRighTackleClip, false, false)
	PlayerSetup.AddPlayback(character, 'PLAY_SLIDE_TACKLE_RIGHT', leftRighTackleClip, true, false)
	
	do	-- ADJUST_SLIDE_TACKLE_FRONT
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_FRONT'
		obj.Playback = 'PLAY_SLIDE_TACKLE'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(slideTackleClip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(slideTackleClip)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(slideTackleClip, false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'DesiredMovementDirection'
		obj.PlaybackAngle = 0
		obj.IsEntryCondition = true
		obj.AdjustPosition = true
		obj.Min = -60
		obj.Max = 60
	end
	
	do	-- ADJUST_SLIDE_TACKLE_LEFT
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_LEFT'
		obj.Playback = 'PLAY_SLIDE_TACKLE_LEFT'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(leftRighTackleClip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(leftRighTackleClip)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(leftRighTackleClip, false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'DesiredMovementDirection'
		obj.PlaybackAngle = 0
		obj.IsEntryCondition = true
		obj.AdjustPosition = true
		obj.AdjustOrientation = false
		obj.AdjustTarget = false
		obj.Min = 61
		obj.Max = 120
	end
	
	do	-- ADJUST_SLIDE_TACKLE_RIGHT
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_RIGHT'
		obj.Playback = 'PLAY_SLIDE_TACKLE_RIGHT'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(leftRighTackleClip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(leftRighTackleClip)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(leftRighTackleClip, true, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'DesiredMovementDirection'
		obj.PlaybackAngle = 0
		obj.IsEntryCondition = true
		obj.AdjustPosition = true
		obj.AdjustOrientation = false
		obj.AdjustTarget = false
		obj.Min = -120
		obj.Max = -61
	end
	
	do	-- ADJUST_SLIDE_TACKLE_BACK_LEFT
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_BACK_LEFT'
		obj.Playback = 'PLAY_SLIDE_TACKLE'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(slideTackleClip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(slideTackleClip)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(slideTackleClip, false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'DesiredMovementDirection'
		obj.PlaybackAngle = 0
		obj.IsEntryCondition = true
		obj.AdjustPosition = true
		obj.Min = 121
		obj.Max = 180
	end
	
	do	-- ADJUST_SLIDE_TACKLE_BACK_RIGHT
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_BACK_RIGHT'
		obj.Playback = 'PLAY_SLIDE_TACKLE'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(slideTackleClip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(slideTackleClip)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(slideTackleClip, false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'DesiredMovementDirection'
		obj.PlaybackAngle = 0
		obj.IsEntryCondition = true
		obj.AdjustPosition = true
		obj.Min = -180
		obj.Max = -121
	end
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
			
		obj.Name = 'SLIDE_TACKLE_COMPOSITE'
		obj.Add('ADJUST_SLIDE_TACKLE_FRONT')
		obj.Add('ADJUST_SLIDE_TACKLE_LEFT')
		obj.Add('ADJUST_SLIDE_TACKLE_RIGHT')
		obj.Add('ADJUST_SLIDE_TACKLE_BACK_LEFT')
		obj.Add('ADJUST_SLIDE_TACKLE_BACK_RIGHT')
	end
	do	-- SLIDE_TACKLE motion
		local obj = TackleIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SLIDE_TACKLE'
		obj.Playback = 'SLIDE_TACKLE_COMPOSITE'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.SLIDE_TACKLE
		obj.MotionType = EMotionType.SlideTackle
		obj.Height = 'TrapHeight'
	end 

	do	-- ADJUST_SLIDE_NO_BALL_TACKLE
		local obj = TurningAngleAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SLIDE_TACKLE_NOBALL'
		obj.Playback = 'PLAY_SLIDE_TACKLE'
		obj.AngleParameter = 'ExecutionAngle'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		obj.Duration = 0.05 -- 3 frames
	end
	do	-- SLIDE_NO_BALL_TACKLE motion
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SLIDE_TACKLE_NOBALL'
		obj.Playback = 'ADJUST_SLIDE_TACKLE_NOBALL'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.SLIDE_TACKLE
		obj.MotionType = EMotionType.SlideTackle
	end
	
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
			
		obj.Name = 'TACKLE'
		obj.Add('SLIDE_TACKLE')
		obj.Add('SLIDE_TACKLE_NOBALL')
	end
end

PlayerSetup['AddTackleReactions'] = function(character, lightPrefix, mediumPrefix, heavyPrefix, chopperPrefix, keeperPrefix)

	do	-- PLAY_TACKLE_REACTION_LIGHT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_LIGHT'
		
		local clipName = lightPrefix.."_tackle_react_light_0"
		--obj.AddClip('CAT_tackle_react_light_0', false, 0)
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_TACKLE_REACTION_LIGHT_CW45
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_LIGHT_CW45'
		local clipName = lightPrefix.."_tackle_react_light_CW45"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_TACKLE_REACTION_LIGHT_CC45
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_LIGHT_CC45'
		local clipName = lightPrefix.."_tackle_react_light_CC45"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_TACKLE_REACTION_MEDIUM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_MEDIUM'
		local clipName = mediumPrefix.."_tackle_react_heavy_0"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end

	do	-- PLAY_TACKLE_REACTION_MEDIUM_CW45
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_MEDIUM_CW45'
		local clipName = mediumPrefix.."_tackle_react_heavy_CW45"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
		do	-- PLAY_TACKLE_REACTION_MEDIUM_CC45
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_MEDIUM_CC45'
		local clipName = mediumPrefix.."_tackle_react_heavy_CC45"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_STEPIN_TACKLE_REACTION_HEAVY
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_HEAVY'
		local clipName = heavyPrefix.."_tackle_react_brutal_0"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_TACKLE_REACTION_KEEPER
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_TACKLE_REACTION_KEEPER'
		
		local clipName = keeperPrefix.."_GKCollision_0"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_CHOPPER_REACTION_FRONT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_CHOPPER_REACTION_FRONT'
		
		local clipName = chopperPrefix.."_chopper_reaction_front"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_CHOPPER_REACTION_BACK
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_CHOPPER_REACTION_BACK'
		
		local clipName = chopperPrefix.."_chopper_reaction_back"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_CHOPPER_REACTION_GROUND
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_CHOPPER_REACTION_GROUND'
		
		local clipName = chopperPrefix.."_chopper_reaction_ground"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	-- PLAY_CHOPPER_STANDUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_CHOPPER_STANDUP'
		
		local clipName = chopperPrefix.."_chopper_reaction_standup"
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_LIGHT'
		obj.Playback = 'PLAY_TACKLE_REACTION_LIGHT'
		obj.MotionType = EMotionType.TackleReactionLight
	end
	do	-- TACKLE_REACTION_LIGHT
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_LIGHT'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_LIGHT'
		obj.Interaction		= EInteraction.TACKLE
		obj.ReactionType	= ETackleReaction.ETackleReaction_LIGHT
		
		obj.Range1Min		= -45.0
		obj.Range1Max		= 45.0
		obj.Range2Min		= -135.0
		obj.Range2Max		= -180.0
		obj.Range3Min		= 135.0
		obj.Range3Max		= 180.0
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_light_0', false)
		obj.Duration = 0.833333
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_LIGHT_CW45'
		obj.Playback = 'PLAY_TACKLE_REACTION_LIGHT_CW45'
		obj.MotionType = EMotionType.TackleReactionLight
	end
	do	-- STEPIN_TACKLE_REACTION_LIGHT_CW45
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_LIGHT_CW45'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_LIGHT_CW45'
		obj.Interaction		= EInteraction.TACKLE
		obj.ReactionType	= ETackleReaction.ETackleReaction_LIGHT
	
		obj.Range1Min		= 45.0
		obj.Range1Max		= 135.0
		obj.Range2Min		= 1.0
		obj.Range2Max		= -1.0
		obj.Range3Min		= 1.0
		obj.Range3Max		= -1.0
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_light_CW45', false)
		obj.Duration = 0.833333
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_LIGHT_CC45'
		obj.Playback = 'PLAY_TACKLE_REACTION_LIGHT_CC45'
		obj.MotionType = EMotionType.TackleReactionLight
	end
	do	-- STEPIN_TACKLE_REACTION_LIGHT_CC45
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_LIGHT_CC45'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_LIGHT_CC45'
		obj.Interaction		= EInteraction.TACKLE
		obj.ReactionType	= ETackleReaction.ETackleReaction_LIGHT
		
		obj.Range1Min		= -135.0
		obj.Range1Max		= -45.0
		obj.Range2Min		= 1.0
		obj.Range2Max		= -1.0
		obj.Range3Min		= 1.0
		obj.Range3Max		= -1.0
		
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_light_CC45', false)
		obj.Duration = 0.833333
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_MEDIUM'
		obj.Playback = 'PLAY_TACKLE_REACTION_MEDIUM'
		obj.MotionType = EMotionType.TackleReactionMedium
	end
	do	-- STEPIN_TACKLE_REACTION_MEDIUM
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_MEDIUM'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_MEDIUM'
		obj.ReactionType	= ETackleReaction.ETackleReaction_MEDIUM
		obj.Interaction		= EInteraction.TACKLE
		
		obj.Range1Min		= -45.0
		obj.Range1Max		= 45.0
		obj.Range2Min		= -135.0
		obj.Range2Max		= -180.0
		obj.Range3Min		= 135.0
		obj.Range3Max		= 180.0
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_heavy_0', false)
		obj.Duration = 1.933333
	end
	
		
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_MEDIUM_CW45'
		obj.Playback = 'PLAY_TACKLE_REACTION_MEDIUM_CW45'
		obj.MotionType = EMotionType.TackleReactionMedium
	end
	do	-- STEPIN_TACKLE_REACTION_MEDIUM_CW45
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_MEDIUM_CW45'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_MEDIUM_CW45'
		obj.ReactionType	= ETackleReaction.ETackleReaction_MEDIUM
		obj.Interaction		= EInteraction.TACKLE

		obj.Range1Min		= 45.0
		obj.Range1Max		= 135.0
		obj.Range2Min		= 1.0
		obj.Range2Max		= -1.0
		obj.Range3Min		= 1.0
		obj.Range3Max		= -1.0
		
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_heavy_CW45', false)
		obj.Duration = 1.933333
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_MEDIUM_CC45'
		obj.Playback = 'PLAY_TACKLE_REACTION_MEDIUM_CC45'
		obj.MotionType = EMotionType.TackleReactionMedium
	end
	do	-- TACKLE_REACTION_MEDIUM_CC45
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_MEDIUM_CC45'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_MEDIUM_CC45'
		obj.ReactionType	= ETackleReaction.ETackleReaction_MEDIUM
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= -135.0
		obj.Range1Max		= -45.0
		obj.Range2Min		= 1.0
		obj.Range2Max		= -1.0
		obj.Range3Min		= 1.0
		obj.Range3Max		= -1.0
		
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_heavy_CC45', false)
		obj.Duration = 1.933333
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_HEAVY'
		obj.Playback = 'PLAY_TACKLE_REACTION_HEAVY'
		obj.MotionType = EMotionType.TackleReactionHeavy
	end
	do	-- TACKLE_REACTION_HEAVY
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_HEAVY'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_HEAVY'
		obj.ReactionType	= ETackleReaction.ETackleReaction_HEAVY
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= 0.0
		obj.Range1Max		= 180.0
		obj.Range2Min		= -180.0
		obj.Range2Max		= 0.0
		obj.MotionDirection = ClipManager.GetMovementDirection('CAT_tackle_react_brutal_0', false)
		obj.Duration = 1.566667
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_TACKLE_REACTION_KEEPER'
		obj.Playback = 'PLAY_TACKLE_REACTION_KEEPER'
		obj.MotionType = EMotionType.TackleReactionKeeper
	end
	do	-- TACKLE_REACTION_KEEPER
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		local name = keeperPrefix.."_GKCollision_0"
		
		obj.Name = 'TACKLE_REACTION_KEEPER'
		obj.Playback = 'SPECIFIC_TACKLE_REACTION_KEEPER'
		obj.ReactionType	= ETackleReaction.ETackleReaction_KEEPER
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= 0.0
		obj.Range1Max		= 180.0
		obj.Range2Min		= -180.0
		obj.Range2Max		= 0.0
		obj.MotionDirection = ClipManager.GetMovementDirection(name, false)
		obj.Duration = 1.566667
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_KNOCKDOWN'
		obj.Playback = 'PLAY_TACKLE_REACTION_KEEPER'
		obj.MotionType = EMotionType.TackleReactionKeeper
		obj.MovementIntention = EMovementInterpretation.FALL_OVER
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_CHOPPER_REACTION_FRONT'
		obj.Playback = 'PLAY_CHOPPER_REACTION_FRONT'
		obj.MotionType = EMotionType.TackleReactionChopper
	end
	do	-- TACKLE_REACTION_CHOPPER_FRONT
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_CHOPPER_FRONT'
		obj.Playback = 'SPECIFIC_CHOPPER_REACTION_FRONT'
		obj.ReactionType	= ETackleReaction.ETackleReaction_CHOPPER
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= 0.0
		obj.Range1Max		= 90.0
		obj.Range2Min		= -90.0
		obj.Range2Max		= 0.0
		local clipName = chopperPrefix.."_chopper_reaction_front"
		obj.MotionDirection = ClipManager.GetMovementDirection(clipName, false)
		obj.Duration = 1.566667
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_CHOPPER_REACTION_BACK'
		obj.Playback = 'PLAY_CHOPPER_REACTION_BACK'
		obj.MotionType = EMotionType.TackleReactionChopper
	end
	do	-- TACKLE_REACTION_CHOPPER_BACK
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_CHOPPER_BACK'
		obj.Playback = 'SPECIFIC_CHOPPER_REACTION_BACK'
		obj.ReactionType	= ETackleReaction.ETackleReaction_CHOPPER
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= -90.0
		obj.Range1Max		= -180.0
		obj.Range2Min		= 90.0
		obj.Range2Max		= 180.0
		local clipName = chopperPrefix.."_chopper_reaction_back"
		obj.MotionDirection = ClipManager.GetMovementDirection(clipName, false)
		obj.Duration = 1.566667
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SPECIFIC_CHOPPER_REACTION_GROUND'
		obj.Playback = 'PLAY_CHOPPER_REACTION_GROUND'
		obj.MotionType = EMotionType.TackleReactionChopper
	end
	do	-- TACKLE_REACTION_CHOPPER_GROUND
		local obj = TackleReaction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TACKLE_REACTION_CHOPPER_GROUND'
		obj.Playback = 'SPECIFIC_CHOPPER_REACTION_GROUND'
		obj.ReactionType	= ETackleReaction.ETackleReaction_CHOPPER
		obj.Interaction		= EInteraction.TACKLE
		obj.Range1Min		= 0.0
		obj.Range1Max		= 180.0
		obj.Range2Min		= -180.0
		obj.Range2Max		= 0.0
		local clipName = chopperPrefix.."_chopper_reaction_ground"
		obj.MotionDirection = ClipManager.GetMovementDirection(clipName, false)
		obj.Duration = 1.833333
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'CHOPPER_STANDUP'
		obj.Playback = 'PLAY_CHOPPER_STANDUP'
		obj.MotionType = EMotionType.TackleReactionChopper
	end
	
		
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
			
		obj.Name = 'TO_RUN_TACKLE_REACTION'
		obj.Add('TACKLE_REACTION_LIGHT')
		obj.Add('TACKLE_REACTION_LIGHT_CW45')
		obj.Add('TACKLE_REACTION_LIGHT_CC45')
		
	end 
	
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TO_IDLE_TACKLE_REACTION'
		obj.Add('TACKLE_REACTION_MEDIUM')
		obj.Add('TACKLE_REACTION_MEDIUM_CW45')
		obj.Add('TACKLE_REACTION_MEDIUM_CC45')
		obj.Add('TACKLE_REACTION_HEAVY')
		obj.Add('TACKLE_REACTION_KEEPER')
	end
	
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'TO_CHOPPER_REACTION'
		obj.Add('TACKLE_REACTION_CHOPPER_FRONT')
		obj.Add('TACKLE_REACTION_CHOPPER_BACK')
	end
	
end

PlayerSetup['AddSynchronizedMotionHelper'] = function(character, name, clip, motiontype, interaction, interactionmotion, behaviour, endeventtype, animateball, doheader )
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_'..name
		obj.Cyclic = false
		
		obj.AddClip(clip, false, 0)
	end 
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name		= 'SPECIFIC_'..name
		obj.Playback	= 'PLAY_'..name
		obj.MotionType	= motiontype
	end
	do	
		local obj = SynchronizedInteraction(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name			= 'SYNC_'..name
		obj.Playback		= 'SPECIFIC_'..name
		obj.Interaction		= interaction
		obj.InteractionMotion = interactionmotion
		obj.Behaviour		= behaviour
		obj.AnimateBall		= animateball
		obj.AdjustPosition  = false
		
			
		if (endeventtype ~= nil) then
			obj.EndEventType = endeventtype
		end
		
		if ( behaviour == ECoarseBehaviour.ECoarseBehaviour_DEFENDER) then
			obj.RelativeRootTransform = ClipManager.GetStartTransform(clip, false, 'Movement')
			obj.SynchonizeWithOther = true		
			
			if (endeventtype == EJostleState.EJostleState_CORE_DONE) then
				obj.SynchonizePosition = true
			else
				obj.SynchonizePosition = false
			end
		end
		
		if ( doheader ) then
			obj.ContactStyle = EBallImpulseType.Header
			obj.ContactTime = ClipManager.GetTagTime(clip, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
			obj.ContactDuration = ClipManager.GetDuration(clip)
			obj.ContactOffset = ClipManager.GetOffsetToJoint(clip, mirror, 0, 'Ball')
			obj.ContactJoint = 'Ball'
			obj.ContactThreshold = 1000.0
			--obj.ContactDirection = 'TouchDirection'
			obj.AdjustPosition = false
			obj.AdjustOrientation = false
			obj.AdjustTarget = true
			obj.PlaybackAngle = 0
			obj.Min = -180
			obj.Max = 180
		end
		
	end 
end

PlayerSetup['AddSynchronizedDoubleTouchHelper'] = function(character, name, clip, motiontype, interaction, interactionmotion, behaviour, endeventtype, animateball )
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_'..name
		obj.Cyclic = false
		
		obj.AddClip(clip, false, 0)
	end 
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name		= 'SPECIFIC_'..name
		obj.Playback	= 'PLAY_'..name
		obj.MotionType	= motiontype
	end
	do	
		local obj = SynchronizedDoubleTouch(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name			= 'SYNC_'..name
		obj.Playback		= 'SPECIFIC_'..name
		obj.Interaction		= interaction
		obj.InteractionMotion = interactionmotion
		obj.Behaviour		= behaviour
		obj.AnimateBall		= animateball
		
		
		if (endeventtype ~= nil) then
			obj.EndEventType = endeventtype
		end
		
		if ( behaviour == ECoarseBehaviour.ECoarseBehaviour_DEFENDER) then
			obj.RelativeRootTransform = ClipManager.GetStartTransform(clip, false, 'Movement')
			obj.SynchonizeWithOther = true		
			
			if (endeventtype == EJostleState.EJostleState_CORE_DONE) then
				obj.SynchonizePosition = true
			else
				obj.SynchonizePosition = false
			end
		end
		
		
		obj.ContactStyle = EBallImpulseType.LowPass --DMY temp workaround dribble problem!
		obj.SecondContactTime = ClipManager.GetTagTime(clip, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clip, mirror, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
				
	end 
end

PlayerSetup['AddJostleHeaderMotions'] = function(character, characterList, prefix, clipCyclePrefix, clipCycleSuffix, clipExitPrefix )

	PlayerSetup.AddSynchronizedMotionHelper( character, 'A_JOSTLEH_CYCLE', clipCyclePrefix .. 'HeaderJostle_cycle_' .. clipCycleSuffix .. '0', EMotionType.Jostle, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_CYCLE, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, nil, false, false )
	PlayerSetup.AddSynchronizedMotionHelper( character, 'D_JOSTLEH_CYCLE', clipCyclePrefix .. 'HeaderJostle_cycle_' .. clipCycleSuffix .. '1', EMotionType.Jostle, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_CYCLE, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, EJostleState.EJostleState_CORE_DONE, false, false )

	PlayerSetup.AddSynchronizedMotionHelper( character, 'A_JOSTLEH_EXIT_A_WIN_STRONG', clipExitPrefix .. 'header_jostle_OFF_WIN', EMotionType.JostleExit, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, EJostleState.EJostleState_EXIT_ATTACKER_WIN, false, true )
	PlayerSetup.AddSynchronizedMotionHelper( character, 'D_JOSTLEH_EXIT_A_WIN_STRONG', clipExitPrefix .. 'header_jostle_DEF_LOSS', EMotionType.JostleExit, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, nil, false, false )

	PlayerSetup.AddSynchronizedMotionHelper( character, 'A_JOSTLEH_EXIT_D_WIN_STRONG', clipExitPrefix .. 'header_jostle_OFF_LOSS', EMotionType.JostleExit, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, EJostleState.EJostleState_EXIT_DEFENDER_WIN, false, false )
	PlayerSetup.AddSynchronizedMotionHelper( character, 'D_JOSTLEH_EXIT_D_WIN_STRONG', clipExitPrefix .. 'header_jostle_DEF_WIN', EMotionType.JostleExit, EInteraction.JOSTLE_HEADER, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, nil, false, true )

	local obj = SynchronisedInteractionCharacterSpecificSet(PlayerSetup.HeapIndex)
	ptr = AutoInstance()
	ptr.Set(obj)
	character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
	obj.Name = prefix..'JOSTLEHEADER'
	obj.Switchable = false
	obj.Add('SYNC_A_JOSTLEH_CYCLE')
	obj.Add('SYNC_D_JOSTLEH_CYCLE')
	
	obj.Add('SYNC_D_JOSTLEH_EXIT_D_WIN_STRONG')
	obj.Add('SYNC_D_JOSTLEH_EXIT_A_WIN_STRONG')
	obj.Add('SYNC_A_JOSTLEH_EXIT_D_WIN_STRONG')
	obj.Add('SYNC_A_JOSTLEH_EXIT_A_WIN_STRONG')
	
	for index, characterName in pairs(characterList) do
		obj.AddValidCharacter(characterName)
	end
end

-- second parameter should be a list of names of character types that can be used for this anim set, i.e. 'PIG', 'GOR', 'CAT' etc.
PlayerSetup['AddJostleMotions'] = function(character, characterList, prefix, attackCycleAnim, defenseCycleAnim, attackExitWinAnim, attackExitLossAnim, defenseExitWinAnim, defenseExitLossAnim, attackExitLossAnim2, defenseExitLossAnim2)	

	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_A_JOSTLE_CYCLE', attackCycleAnim, EMotionType.Jostle, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_CYCLE, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, EJostleState.EJostleState_CORE_DONE, true, false )
	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_D_JOSTLE_CYCLE', defenseCycleAnim, EMotionType.Jostle, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_CYCLE, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, EJostleState.EJostleState_CORE_DONE, true, false )

	PlayerSetup.AddSynchronizedDoubleTouchHelper( character, prefix .. '_A_JOSTLE_EXIT_A_WIN', attackExitWinAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_WEAK, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, nil, false )
	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_D_JOSTLE_EXIT_A_WIN', defenseExitLossAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_WEAK, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, EJostleState.EJostleState_EXIT_ATTACKER_WIN, true, false )

	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_A_JOSTLE_EXIT_D_WIN', attackExitLossAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_WEAK, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, nil, false, false )
	PlayerSetup.AddSynchronizedDoubleTouchHelper( character, prefix .. '_D_JOSTLE_EXIT_D_WIN', defenseExitWinAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_WEAK, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, EJostleState.EJostleState_EXIT_DEFENDER_WIN, false )

	PlayerSetup.AddSynchronizedDoubleTouchHelper( character, prefix .. '_A_JOSTLE_EXIT_A_WIN_STRONG', attackExitWinAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, EJostleState.EJostleState_EXIT_ATTACKER_WIN, false )
	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_D_JOSTLE_EXIT_A_WIN_STRONG', defenseExitLossAnim2, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_ATTACK_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, nil, false, false )

	PlayerSetup.AddSynchronizedMotionHelper( character, prefix .. '_A_JOSTLE_EXIT_D_WIN_STRONG', attackExitLossAnim2, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_ATTACKER, nil, false, false )
	PlayerSetup.AddSynchronizedDoubleTouchHelper( character, prefix .. '_D_JOSTLE_EXIT_D_WIN_STRONG', defenseExitWinAnim, EMotionType.JostleExit, EInteraction.JOSTLE, EInteractionMotion.JOSTLE_EXIT_DEFEND_WIN_STRONG, ECoarseBehaviour.ECoarseBehaviour_DEFENDER, EJostleState.EJostleState_EXIT_DEFENDER_WIN, false)
	
	do
		local obj = SynchronisedInteractionCharacterSpecificSet(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
			
		obj.Name = prefix..'JOSTLE_CYCLE'
		obj.Switchable = false
		obj.Add('SYNC_' .. prefix .. '_A_JOSTLE_CYCLE')
		obj.Add('SYNC_' .. prefix .. '_D_JOSTLE_CYCLE')
		
		for index, characterName in pairs(characterList) do
			obj.AddValidCharacter(characterName)
		end
		--print("Added motion:"..obj.Name)
	end
	
	do
		local obj = SynchronisedInteractionCharacterSpecificSet(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		obj.Name = prefix..'JOSTLE_WIN'
		obj.Switchable = false
		obj.Add('SYNC_' .. prefix .. '_D_JOSTLE_EXIT_D_WIN')
		obj.Add('SYNC_' .. prefix .. '_D_JOSTLE_EXIT_D_WIN_STRONG')
		obj.Add('SYNC_' .. prefix .. '_A_JOSTLE_EXIT_A_WIN')
		obj.Add('SYNC_' .. prefix .. '_A_JOSTLE_EXIT_A_WIN_STRONG')
		
		for index, characterName in pairs(characterList) do
			obj.AddValidCharacter(characterName)
		end
		
		--print("Added motion:"..obj.Name)
	end
	
	do
		local obj = SynchronisedInteractionCharacterSpecificSet(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		obj.Name = prefix..'JOSTLE_LOSE_TOSTUMBLE'
		obj.Switchable = false
		obj.Add('SYNC_' .. prefix .. '_A_JOSTLE_EXIT_D_WIN')
		
		for index, characterName in pairs(characterList) do
			obj.AddValidCharacter(characterName)
		end
		--print("Added motion:"..obj.Name)
	end
	
	do
		local obj = SynchronisedInteractionCharacterSpecificSet(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		obj.Name = prefix..'JOSTLE_LOSE_TOCONFUSED'
		obj.Switchable = false
		obj.Add('SYNC_' .. prefix .. '_D_JOSTLE_EXIT_A_WIN')
		obj.Add('SYNC_' .. prefix .. '_D_JOSTLE_EXIT_A_WIN_STRONG')	
		obj.Add('SYNC_' .. prefix .. '_A_JOSTLE_EXIT_D_WIN_STRONG')
		
		for index, characterName in pairs(characterList) do
			obj.AddValidCharacter(characterName)
		end
		--print("Added motion:"..obj.Name)
	end
end
PlayerSetup['AddStumbleMotions'] = function(character, prefix)
	local clipName = prefix..'_stumble_Stun'
	do	-- STUMBLE ANIM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'STUMBLE'
		obj.AddClip(clipName, false, 0)
	end	
	
	do -- RUN VERSION OF FALL ANIM
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_STUMBLE'
		obj.Playback = 'STUMBLE'
		obj.MovementIntention = EMovementInterpretation.STUMBLE;
		obj.IsEntryCondition = true;
		obj.MotionType = EMotionType.Stun
	end
end

PlayerSetup['AddConfusedMotions'] = function(character, prefix)
	local clipName = prefix..'_Confused_look'
	do	-- CONFUSED ANIM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'CONFUSED'
		obj.AddClip(clipName, false, 0)
	end	
	
	do -- RUN VERSION OF FALL ANIM
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CONFUSED'
		obj.Playback = 'CONFUSED'
		obj.MovementIntention = EMovementInterpretation.CONFUSED;
		obj.IsEntryCondition = true;
		obj.MotionType = EMotionType.Stun
	end
end


PlayerSetup['AddStunMotions'] = function(character)
	do	-- STUN ANIM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_STUN'
		obj.AddClip('CAT_stun_IDLE_long', false, 0)
	end	
	
	do -- RUN VERSION OF STUN ANIM
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_STUN'
		obj.Playback = 'PLAY_STUN'
		obj.MovementIntention = EMovementInterpretation.STUNNED
		obj.IsEntryCondition = true
		obj.MotionType = EMotionType.Stun
	end
end
PlayerSetup['AddDodgeHelper'] = function(character, clip, dodgeType, animName, mirror)
	do	-- DODGE_LEFT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = "PLAY_"..animName
		obj.AddClip(clip, mirror, 0)
		obj.Cyclic = false
	end	
	do	-- ADJUST_DODGE
		local obj = DoubleTouchMotion((PlayerSetup.HeapIndex)) --  SingleTouchAnimateBall(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = "ADJUST_"..animName
		obj.Playback = "PLAY_"..animName
		obj.ContactStyle = EBallImpulseType.Dribble
		obj.ContactTime = ClipManager.GetTagTime(clip, EAnimTag.StartBallAnim.Value, EAnimTag.StartBallAnim.Value, 0) --  LeftFootBallCollision
		obj.ContactDuration = ClipManager.GetDuration(clip)
		obj.SecondContactTime = ClipManager.GetTagTime(clip, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clip, mirror, 0, 'Ball') 
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 0.5
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = ClipManager.GetTurningAngle(clip, mirror)
		obj.Min = -180
		obj.Max = 180
	end	
	do -- DODGE_LEFT
		local obj = DodgeIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = animName
		obj.Playback = "ADJUST_"..animName
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_DODGE_WITH_BALL
		obj.DodgeRequest = dodgeType
		obj.MotionType = EMotionType.Dodge
		obj.IsEntryCondition = true
	end
end
PlayerSetup['AddDodge'] = function(character, prefix)

	local clipName = prefix..'_dodge_CC'
	PlayerSetup.AddDodgeHelper( character, clipName, EDodgeRequestType.EDodgeRequestType_DODGE_LEFT, "DODGE_LEFT", false );
	PlayerSetup.AddDodgeHelper( character, clipName, EDodgeRequestType.EDodgeRequestType_DODGE_RIGHT, "DODGE_RIGHT", true );

	do	-- RUN_DODGE
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_DODGE'
		obj.Add('DODGE_LEFT')
		obj.Add('DODGE_RIGHT')
--		obj.Add('DODGE_CENTER')
	end 
end
PlayerSetup['AddDodgeReaction'] = function(character, prefix)

	do	-- PLAY_DODGE_REACTION_MEDIUM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_DODGE_REACTION_MEDIUM'
		local clipName = prefix..'_dodge_Reaction'
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end

	do -- TO_DODGE_REACTION
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'TO_DODGE_REACTION'
		obj.Playback = 'PLAY_DODGE_REACTION_MEDIUM'
		obj.MovementIntention = EMovementInterpretation.DODGED
		obj.IsEntryCondition = true
		obj.MotionType = EMotionType.DodgeReaction
	end
	
	do	-- PLAY_DODGE_FAIL
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_DODGE_FAIL'
		local clipName = prefix..'_dodge_Fail_0'
		obj.AddClip(clipName, false, 0)
		obj.Cyclic = false
	end

	do -- TO_DODGE_REACTION
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_DODGE_FAIL'
		obj.Playback = 'PLAY_DODGE_FAIL'
		obj.MovementIntention = EMovementInterpretation.DODGEFAIL
		obj.IsEntryCondition = true
		obj.MotionType = EMotionType.DodgeFail
	end
end

PlayerSetup['AddDribble'] = function(character, clipName, motionName, contactThreshold, minAngle, maxAngle, playbackAngle, startState, endState, isMirror )
	local playName = 'PLAY_'..motionName
	local adjustName = 'ADJUST_'..motionName
	local phaseName = motionName -- 'PHASED_'..motionName
	
	do	-- RUN_DRIBBLE_CC_TURN
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj) 
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'TouchAngle'
		obj.AddClip(clipName, isMirror, playbackAngle)
		obj.EndPosition = ClipManager.GetStateStartPosition(clipName, isMirror, endState, 1)
	end
	do	-- ADJUST_RUN_DRIBBLE_CW_TURN
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Dribble
		obj.ContactTime = ClipManager.GetTagTime(clipName, 
												EAnimTag.HeadBallCollision.Value, 
												EAnimTag.LeftFootBallCollision.Value, 
												0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, 
														isMirror, 
														ClipManager.GetStateStartPosition(clipName, isMirror, startState, 0).AsFloat(), 
														'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minAngle
		obj.Max = maxAngle
	end
	do -- PHASED_RUN_DRIBBLE
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = phaseName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, isMirror, startState, 0).Value
		obj.StartRegion = 0.0
		obj.EndRegion = 0.01667
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
end

PlayerSetup['AddDoubleDribble'] = function(character, clipName, motionName, contactThreshold, minAngle, maxAngle, playbackAngle, startState, endState, isMirror )
	local playName = 'PLAY_'..motionName
	local adjustName = 'ADJUST_'..motionName
	local phaseName = motionName --'PHASED_'..motionName
	
	do	-- RUN_DRIBBLE_CC_TURN
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj) 
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'TouchAngle'
		obj.AddClip(clipName, isMirror, playbackAngle)
		obj.Cyclic = false
	end
	do	-- ADJUST_RUN_DRIBBLE_CW_TURN
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Dribble
		obj.ContactTime = ClipManager.GetTagTime(	clipName, 
													EAnimTag.HeadBallCollision.Value, 
													EAnimTag.LeftFootBallCollision.Value, 
													0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetTagTime(	clipName, 
														EAnimTag.StopBallAnim.Value, 
														EAnimTag.StopBallAnim.Value, 
														0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, 
														isMirror, 
														ClipManager.GetStateStartPosition(clipName, isMirror, startState, 0).AsFloat(), 
														'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minAngle
		obj.Max = maxAngle
	end
	do -- PHASED_RUN_DRIBBLE
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = phaseName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartRegion = 0.0
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, isMirror, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
end

PlayerSetup['AddGenericIntention'] = function(character, motionName, playbackName, motionType, genericType)
    do
	    local obj = GenericAnimationIntention(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

	    obj.Name = motionName
	    obj.Playback = playbackName
	    obj.MovementIntention = EMovementInterpretation.GENERIC_ANIMATION
	    obj.GenericAnimationRequest = genericType
	    obj.IsEntryCondition = true
	    obj.MotionType = motionType
    end
end

PlayerSetup['AddRandomComposite'] = function(character, selectName, nodes )
    do 
	    local obj = RandomCompositeMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

	    obj.Name = selectName
    	for i=1,#nodes do
	        obj.Add(nodes[i])
	    end
    end
end

PlayerSetup['AddGenericMotions'] = function(character, wavePrefix, distractedPrefix, captureReactPrefix, chestBeatPrefix)
    
    local waveMotionName = 'WAVE'
    do
        local motionName = waveMotionName
        local clipName = wavePrefix .. '_Wave_0'
        local playName = 'PLAY_' .. motionName
	    PlayerSetup.AddPlayback(character, playName, clipName, false, true)
	    PlayerSetup.AddGenericIntention(character, motionName, playName, EMotionType.Wave, EGenericAnimationType.WAVE)
	end
	
	local distractedMotionName = 'DISTRACTED'
	do
	    local motionName = distractedMotionName
	    local selectName = 'SELECT_' .. motionName
	    
	    local clipNameA = distractedPrefix..'_distracted_IDLE_A'
	    local playNameA = 'PLAY_' .. motionName .. '_A'
        PlayerSetup.AddPlayback(character, playNameA, clipNameA, false, true)
        
	    local clipNameB = distractedPrefix..'_distracted_IDLE_B'
	    local playNameB = 'PLAY_' .. motionName .. '_B'
        PlayerSetup.AddPlayback(character, playNameB, clipNameB, false, true)
        
        local nodes = { playNameA, playNameB }
        PlayerSetup.AddRandomComposite(character, selectName, nodes)
	    PlayerSetup.AddGenericIntention(character, motionName, selectName, EMotionType.Distracted, EGenericAnimationType.DISTRACTED)
    end
    
    local captureReactMotionName = 'CAP_REACT'
    if captureReactPrefix then
        do
            local motionName = captureReactMotionName
            local clipName = captureReactPrefix .. '_Capture_React'
            local playName = 'PLAY_' .. motionName
	        PlayerSetup.AddPlayback(character, playName, clipName, false, false)
	        PlayerSetup.AddGenericIntention(character, motionName, playName, EMotionType.CaptureReaction, EGenericAnimationType.CAPTURE_REACTION)
	    end
	end
    
    local chestBeatMotionName = 'CHEST_BEAT'
    if chestBeatPrefix then
        do
            local motionName = chestBeatMotionName
            local clipName = chestBeatPrefix .. '_Minigame_TackleSTART'
            local playName = 'PLAY_' .. motionName
	        PlayerSetup.AddPlayback(character, playName, clipName, false, false)
	        PlayerSetup.AddGenericIntention(character, motionName, playName, EMotionType.ChestBeat, EGenericAnimationType.CHEST_BEAT)
	    end
	end
    
    do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'GENERIC'
		obj.Add(waveMotionName)
		obj.Add(distractedMotionName)
        if captureReactPrefix then
            obj.Add(captureReactMotionName)
        end
        if chestBeatPrefix then
            obj.Add(chestBeatMotionName)
        end
    end
end

PlayerSetup['AddTalentChargeups'] = function(character, final_motion_name, anim_0, CC90_anim, CW90_anim, CC180_anim, CW180_anim, movement, calculateAngle)
	do	-- CHARGEUP ANIM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name .. '_0'
		obj.Parameter = 'ChargeUpAngle'
		obj.AddClip(anim_0, false, -45.0)
		obj.AddClip(anim_0, false, 45.0)
		obj.Cyclic = false
	end	
	do	-- 
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name .. '_CW90'
		obj.Parameter = 'ChargeUpAngle'
		obj.AddClip(CW90_anim, false, -45.0)
		obj.AddClip(CW90_anim, false, -135.0)
		obj.Cyclic = false
	end	
	do	-- 
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name .. '_CC90'
		obj.Parameter = 'ChargeUpAngle'
		obj.AddClip(CC90_anim, false, 45.0)
		obj.AddClip(CC90_anim, false, 135.0)
		obj.Cyclic = false
	end	
	do	-- 
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name .. '_CW180'
		obj.Parameter = 'ChargeUpAngle'
		obj.AddClip(CW180_anim, false, -135.0)
		obj.AddClip(CW180_anim, false, -180.0)
		obj.Cyclic = false
	end	
	do	-- 
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name .. '_CC180'
		obj.Parameter = 'ChargeUpAngle'
		obj.AddClip(CW180_anim, true, 135.0)
		obj.AddClip(CW180_anim, true, 180.0)
		obj.Cyclic = false
	end	
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SELECT_' .. final_motion_name
		obj.Add(final_motion_name .. '_0')
		obj.Add(final_motion_name .. '_CW90')
		obj.Add(final_motion_name .. '_CC90')
		obj.Add(final_motion_name .. '_CW180')
		obj.Add(final_motion_name .. '_CC180')
		obj.Switchable = false
	end
	
	do -- RUN VERSION OF CHARGEUP ANIM
		local obj = TalentChargeUpIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = final_motion_name
		obj.Playback = 'SELECT_' .. final_motion_name
		obj.CalculateAngleToGoal = calculateAngle
		obj.IsEntryCondition = true
		obj.MovementIntention = movement
		obj.AnimateBall = true
		obj.MotionType = EMotionType.TalentChargeUp
		
		--print("Chargeup motion:")
		--print(final_motion_name)
		--print(tostring(calculateAngle))
	end
end

PlayerSetup['AddTalentMotions'] = function(character)
	
	do	-- PLAY_SUPERSLIDE_TACKLE_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_SUPERSLIDE_TACKLE_CHARGEUP'
		obj.AddClip('PIG_TALENT_torpedo_intro', false, 0)
		obj.Cyclic = false
	end
	
	do	-- RUN_SUPERSLIDE_TACKLE_CHARGEUP
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SUPERSLIDE_TACKLE_CHARGEUP'
		obj.Playback = 'PLAY_SUPERSLIDE_TACKLE_CHARGEUP'
		obj.AngleName = 'TurningAngle'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		--obj.Duration = 1.666667 
		obj.MinSpeed = 0.0
		obj.SpeedName = 'FeasableSpeed'
		obj.AdjustmentRate = 6.0
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SUPERSLIDE_TACKLE_CHARGEUP'
		obj.Playback = 'ADJUST_SUPERSLIDE_TACKLE_CHARGEUP'
		obj.MotionType = EMotionType.TalentChargeUp
	end
	
		do	-- PLAY_SUPERSLIDE_TACKLE_CHARGEUP_IDLE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_SUPERSLIDE_TACKLE_CHARGEUP_IDLE'
		obj.AddClip('PIG_TALENT_torpedo_idle_intro', false, 0)
		obj.Cyclic = false
	end
	
	do	-- RUN_SUPERSLIDE_TACKLE_CHARGEUP_IDLE
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SUPERSLIDE_TACKLE_CHARGEUP_IDLE'
		obj.Playback = 'PLAY_SUPERSLIDE_TACKLE_CHARGEUP_IDLE'
		obj.AngleName = 'TurningAngle'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		--obj.Duration = 1.666667 
		obj.MinSpeed = 0.0
		obj.SpeedName = 'FeasableSpeed'
		obj.AdjustmentRate = 6.0
	end
	
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SUPERSLIDE_TACKLE_CHARGEUP_IDLE'
		obj.Playback = 'ADJUST_SUPERSLIDE_TACKLE_CHARGEUP_IDLE'
		obj.MotionType = EMotionType.TalentChargeUp
	end
	
	local superSlideClipName = "PIG_TACKLE_Slide_0" -- PIG_TALENT_torpedo_slide
	
	do	-- PLAY_SUPERSLIDE_TACKLE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'PLAY_SUPERSLIDE_TACKLE'
		obj.AddClip(superSlideClipName, false, 0)
		obj.Cyclic = false
	end
	do	-- ADJUST_SUPERSLIDE_TACKLE
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_SUPERSLIDE_TACKLE'
		obj.Playback = 'PLAY_SUPERSLIDE_TACKLE'
		obj.ContactStyle = EBallImpulseType.SlideTackle
		obj.ContactTime = ClipManager.GetTagTime(superSlideClipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(superSlideClipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(superSlideClipName, false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 40.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
		obj.IsEntryCondition = true
	end
	do	-- SLIDE_TACKLE motion
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SUPERSLIDE_TACKLE'
		obj.Playback = 'ADJUST_SUPERSLIDE_TACKLE'
		obj.IsEntryCondition = true

		obj.MovementIntention = EMovementInterpretation.SLIDE_TACKLE
		obj.AnimateBall		  = false
		obj.TalentID		  = EPlayerTalent.SUPERSLIDE
		obj.MotionType        = EMotionType.SlideTackle
	end 
	
	do	-- CHOPPER ANIM
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CHOPPER_SPIN'
		obj.AddClip('WLF_TALENT_Chopper_spin', false, 0)
		obj.Cyclic = true
	end	
	do	-- 
		local obj = PositionAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	
		obj.Name = 'POSITION_ADJUST_CHOPPER_SPIN'
		obj.Playback = 'PLAY_CHOPPER_SPIN'
		obj.Speed = 8.0
	end
	do -- RUN VERSION OF CHOPPER ANIM
		local obj = ChopperIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CHOPPER_SPIN'
		obj.Playback = 'POSITION_ADJUST_CHOPPER_SPIN'
		obj.MovementIntention = EMovementInterpretation.NONCONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.CHOPPER
		obj.MotionType = EMotionType.Talent
	end
	
	do	-- CHOPPER ANIM INTRO
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CHOPPER_INTRO'
		obj.Parameter = 'FeasableSpeed'
		obj.AddClip('WLF_TALENT_idle_chargeup_0', false, 0)
		obj.AddClip('WLF_TALENT_run_chargeup_0', false, PlayerSetup.MinSpeed)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF CHOPPER ANIM
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CHOPPER_INTRO'
		obj.Playback = 'PLAY_CHOPPER_INTRO'
		obj.MovementIntention = EMovementInterpretation.NONCONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.CHOPPER
		obj.MotionType = EMotionType.TalentChargeUp
	end
	
	do	-- CHOPPER ANIM EXIT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CHOPPER_EXIT'
		obj.AddClip('WLF_TALENT_Chopper_exit', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF CHOPPER ANIM
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CHOPPER_EXIT'
		obj.Playback = 'PLAY_CHOPPER_EXIT'
		obj.MovementIntention = EMovementInterpretation.NONCONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.CHOPPER
		obj.MotionType = EMotionType.Talent
	end
	
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'RUN_CHOPPER'
		obj.Add('RUN_CHOPPER_INTRO')
		obj.Add('RUN_CHOPPER_SPIN')
		obj.Add('RUN_CHOPPER_EXIT')
	end
	
	do	-- PLAY_GOR_UNSTOPPABLE_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_UNSTOPPABLE_CHARGEUP'
		obj.Parameter = 'FeasableSpeed'
		obj.AddClip('GOR_talent_Unstoppable_chargeup', false, PlayerSetup.MinSpeed)
		obj.AddClip('GOR_talent_Unstoppable_idle_chargeup', false, 0)
		--obj.AddClip('GOR_talent_Unstoppable_chargeup', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF UNSTOPPABLE CHARGEUP
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_UNSTOPPABLE_CHARGEUP'
		obj.Playback = 'PLAY_UNSTOPPABLE_CHARGEUP'
		obj.MovementIntention = EMovementInterpretation.NONCONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.UNSTOPPABLE
		obj.AnimateBall = true
		obj.MotionType = EMotionType.TalentChargeUp
	end	
	
	--do	-- PLAY_GOR_UNSTOPPABLE_CHARGEUP_IDLE
	--	local obj = Playback(PlayerSetup.HeapIndex)
	--	ptr = AutoInstance()
	--	ptr.Set(obj)
	--	character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
--
--		obj.Name = 'PLAY_UNSTOPPABLE_CHARGEUP_IDLE'
--		obj.AddClip('GOR_talent_Unstoppable_idle_chargeup', false, 0)
--		obj.Cyclic = false
--	end	
--	do -- RUN VERSION OF UNSTOPPABLE CHARGEUP_IDLE
--		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
--		ptr = AutoInstance()
--		ptr.Set(obj)
--		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

--		obj.Name = 'RUN_UNSTOPPABLE_CHARGEUP_IDLE'
--		obj.Playback = 'PLAY_UNSTOPPABLE_CHARGEUP_IDLE'
--		obj.MovementIntention = EMovementInterpretation.NONCONTACT_TALENT
---		obj.IsEntryCondition = true
--		obj.TalentID = EPlayerTalent.UNSTOPPABLE
--		obj.AnimateBall = true
--		obj.MotionType = EMotionType.TalentChargeUp
--	end	
	
	do	-- PLAY_GOR_UNSTOPPABLE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_UNSTOPPABLE'
		obj.AddClip('GOR_talent_Unstoppable', false, 0)
		obj.Cyclic = false
	end	
	do
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_UNSTOPPABLE'
		obj.Playback = 'PLAY_UNSTOPPABLE'
		obj.ContactStyle = EBallImpulseType.Dribble
		
		obj.SecondContactTime = ClipManager.GetTagTime(	'GOR_talent_Unstoppable', 
														EAnimTag.HeadBallCollision.Value, 
														EAnimTag.LeftFootBallCollision.Value, 
														0)
		
		obj.ContactOffset = ClipManager.GetOffsetToJoint('GOR_talent_Unstoppable', false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 40.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	do -- RUN VERSION OF UNSTOPPABLE 
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_UNSTOPPABLE'
		obj.Playback = 'ADJUST_UNSTOPPABLE'
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.IsEntryCondition = true
		--obj.TalentID = EPlayerTalent.UNSTOPPABLE
		obj.MotionType = EMotionType.Talent
	end	
	
	
	
	do	-- PLAY_GOR_CATLIKEGRACE_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CATLIKEGRACE_CHARGEUP'
		obj.AddClip('DER_TALENT_CatlikeGrace_chargeup', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF CATLIKEGRACE CHARGEUP
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CATLIKEGRACE_CHARGEUP'
		obj.Playback = 'PLAY_CATLIKEGRACE_CHARGEUP'
		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.CATLIKEGRACE
		obj.AnimateBall = true
		obj.MotionType = EMotionType.TalentChargeUp
	end	
	
	
	do	-- PLAY_CATLIKEGRACE_CHARGEUP_IDLE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CATLIKEGRACE_CHARGEUP_IDLE'
		obj.AddClip('DER_TALENT_CatlikeGrace_idle_chargeup', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF CATLIKEGRACE CHARGEUP_IDLE
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CATLIKEGRACE_CHARGEUP_IDLE'
		obj.Playback = 'PLAY_CATLIKEGRACE_CHARGEUP_IDLE'
		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.CATLIKEGRACE
		obj.AnimateBall = true
		obj.MotionType = EMotionType.TalentChargeUp
	end	
	
	do	-- PLAY_CATLIKEGRACE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_CATLIKEGRACE'
		obj.AddClip('DER_TALENT_CatlikeGrace', false, 0)
		obj.Cyclic = false
	end	
	do	-- ADJUST_CATLIKEGRACE
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_CATLIKEGRACE'
		obj.Playback = 'PLAY_CATLIKEGRACE'
		obj.ContactStyle = EBallImpulseType.Dribble
		
		obj.SecondContactTime = ClipManager.GetTagTime(	'DER_TALENT_CatlikeGrace', 
														EAnimTag.HeadBallCollision.Value, 
														EAnimTag.LeftFootBallCollision.Value, 
														0)
		
		obj.ContactOffset = ClipManager.GetOffsetToJoint('DER_TALENT_CatlikeGrace', false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 40.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	do -- RUN VERSION OF CATLIKEGRACE
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_CATLIKEGRACE'
		obj.Playback = 'ADJUST_CATLIKEGRACE'
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.IsEntryCondition = true
		--obj.TalentID = EPlayerTalent.CATLIKEGRACE
		--obj.AnimateBall = true
		obj.MotionType = EMotionType.Talent
	end	
	
	do	-- PLAY_SAMFISHER_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_SAMFISHER_CHARGEUP'
		obj.AddClip('UBI_SAM_TALENT_stealth_chargeup', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF SAMFISHER CHARGEUP
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_SAMFISHER_CHARGEUP'
		obj.Playback = 'PLAY_SAMFISHER_CHARGEUP'
		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
		obj.IsEntryCondition = true
		obj.TalentID = EPlayerTalent.UBIFISHER
		obj.AnimateBall = true
		obj.MotionType = EMotionType.TalentChargeUp
	end	
	
	do	-- PLAY_SAMFISHER_TALENT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_SAMFISHER_TALENT'
		obj.AddClip('UBI_SAM_TALENT_stealth_exit', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF FISHER TALENT
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_SAMFISHER_TALENT'
		obj.Playback = 'PLAY_SAMFISHER_TALENT'
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.IsEntryCondition = true
		--obj.TalentID = EPlayerTalent.UNSTOPPABLE
		obj.AnimateBall = true
		obj.MotionType = EMotionType.Talent
	end	
		
	do	-- PLAY_PRINCE_TALENT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_PRINCE_TALENT'
		obj.AddClip('UBI_POP_TALENT_Acrobatic', false, 0)
		obj.Cyclic = false
	end	
	do -- RUN VERSION OF PRINCE TALENT
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_PRINCE_TALENT'
		obj.Playback = 'PLAY_PRINCE_TALENT'
		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
		obj.IsEntryCondition = true
		obj.AnimateBall = true
		obj.TalentID = EPlayerTalent.UBIPRINCE
		obj.MotionType = EMotionType.Talent
	end	
	

	do	-- PLAY_JADE_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_JADE_CHARGEUP'
		obj.AddClip('UBI_Jade_TALENT_Photo_intro', false, 0)
		obj.Cyclic = false
	end	
	
	do -- RUN VERSION OF JADE CHARGEUP ANIM
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_JADE_CHARGEUP'
		obj.Playback = 'PLAY_JADE_CHARGEUP'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.AnimateBall = false
		obj.TalentID = EPlayerTalent.UBIJADE
		obj.MotionType = EMotionType.TalentChargeUp
	end
	
	do	-- PLAY_JADE_TALENT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_JADE_TALENT'
		obj.AddClip('UBI_Jade_TALENT_Photo_exit', false, 0)
		obj.Cyclic = false
	end	
	
	do -- RUN VERSION OF JADE CHARGEUP ANIM
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_JADE_TALENT'
		obj.Playback = 'PLAY_JADE_TALENT'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.AnimateBall = false
		obj.TalentID = EPlayerTalent.UBIJADE
		obj.MotionType = EMotionType.Talent
	end
	
		do	-- PLAY_PELE_CHARGEUP
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_PELE_CHARGEUP'
		obj.AddClip('PEL_TALENT_fancy_footwork_chargeup', false, 0)
		obj.Cyclic = false
	end	
	
	do -- RUN VERSION OF PELE CHARGEUP ANIM
		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_PELE_CHARGEUP'
		obj.Playback = 'PLAY_PELE_CHARGEUP'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
		obj.AnimateBall = true
		obj.TalentID = EPlayerTalent.UBIPELE
		obj.MotionType = EMotionType.TalentChargeUp
	end
	
	do	-- PLAY_PELE_TALENT
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'PLAY_PELE_TALENT'
		obj.AddClip('PEL_TALENT_fancy_footwork', false, 0)
		obj.Cyclic = false
	end	
	
	do	-- ADJUST_PELE_TALENT
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'ADJUST_PELE_TALENT'
		obj.Playback = 'PLAY_PELE_TALENT'
		obj.ContactStyle = EBallImpulseType.Dribble
		
		obj.SecondContactTime = ClipManager.GetTagTime(	'PEL_TALENT_fancy_footwork', 
													EAnimTag.HeadBallCollision.Value, 
													EAnimTag.LeftFootBallCollision.Value, 
													0)
		
		obj.ContactOffset = ClipManager.GetOffsetToJoint('PEL_TALENT_fancy_footwork', false, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = 40.0
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	
	do -- RUN VERSION OF PELE CHARGEUP ANIM
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = 'RUN_PELE_TALENT'
		obj.Playback = 'ADJUST_PELE_TALENT'
		obj.IsEntryCondition = true
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.AnimateBall = true
		--obj.TalentID = EPlayerTalent.UBIPELE
		obj.MotionType = EMotionType.Talent
	end
	
	--do	-- PLAY_PRINCE_CHARGEUP
--		local obj = Playback(PlayerSetup.HeapIndex)
--		ptr = AutoInstance()
--		ptr.Set(obj)
--		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

--		obj.Name = 'PLAY_PRINCE_CHARGEUP'
--		obj.AddClip('Cat_TALENT_chargeup', false, 0)
--		obj.Cyclic = false
--	end	
--	do -- RUN VERSION OF PRINCE CHARGEUP
--		local obj = ExpectedTalentIntention(PlayerSetup.HeapIndex)
--		ptr = AutoInstance()
--		ptr.Set(obj)
--		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

--		obj.Name = 'RUN_PRINCE_CHARGEUP'
--		obj.Playback = 'PLAY_PRINCE_CHARGEUP'
--		obj.MovementIntention = EMovementInterpretation.CONTACT_TALENT
--		obj.IsEntryCondition = true
--		obj.TalentID = EPlayerTalent.UBIPRINCE
--		obj.AnimateBall = true
--		obj.MotionType = EMotionType.TalentChargeUp
--	end	
	
	PlayerSetup.AddTalentChargeups( character, 'TALENT_CHARGEUP', 'Cat_TALENT_chargeup', 'Cat_TALENT_chargeup_CC90', 'Cat_TALENT_chargeup_CW90', 'Cat_TALENT_chargeup_CW180', 'Cat_TALENT_chargeup_CW180', EMovementInterpretation.APPROACH_AND_KICK_BALL, false)
	PlayerSetup.AddTalentChargeups( character, 'IDLE_TALENT_CHARGEUP', 'Cat_TALENT_idle_chargeup', 'Cat_TALENT_idle_chargeup_CC90', 'Cat_TALENT_idle_chargeup_CW90', 'Cat_TALENT_idle_chargeup_CW180', 'Cat_TALENT_idle_chargeup_CW180', EMovementInterpretation.APPROACH_AND_KICK_BALL, false )
	PlayerSetup.AddTalentChargeups( character, 'RABBIDSHOT_CHARGEUP', 'UBI_RAB_TALENT_plunger_shot_chargeup', 'UBI_RAB_TALENT_plunger_shot_chargeup_CC90', 'UBI_RAB_TALENT_plunger_shot_chargeup_CW90', 'UBI_RAB_TALENT_plunger_shot_chargeup_CC180', 'UBI_RAB_TALENT_plunger_shot_chargeup_CC180', EMovementInterpretation.APPROACH_AND_KICK_BALL, false)
	PlayerSetup.AddTalentChargeups( character, 'MIA_CHARGEUP', 'UBI_Hamm_TALENT_chargeup_0', 'UBI_Hamm_TALENT_chargeup_CC90', 'UBI_Hamm_TALENT_chargeup_CW90', 'UBI_Hamm_TALENT_chargeup_180', 'UBI_Hamm_TALENT_chargeup_180', EMovementInterpretation.APPROACH_AND_KICK_BALL, false)
	PlayerSetup.AddTalentChargeups( character, 'ALTAIR_CHARGEUP', 'UBI_ALT_TALENT_chargeup', 'UBI_ALT_TALENT_chargeup_CC90', 'UBI_ALT_TALENT_chargeup_CW90', 'UBI_ALT_TALENT_chargeup_CW180', 'UBI_ALT_TALENT_chargeup_CW180', EMovementInterpretation.APPROACH_AND_KICK_BALL, false)
	PlayerSetup.AddTalentChargeups( character, 'RUN_PRINCE_CHARGEUP', 'Cat_TALENT_chargeup', 'Cat_TALENT_chargeup_CC90', 'Cat_TALENT_chargeup_CW90', 'Cat_TALENT_chargeup_CW180', 'Cat_TALENT_chargeup_CW180', EMovementInterpretation.CONTACT_TALENT, true)
	
	do  -- this motion is used to test whether the player lost the ball during chargeup
	    local obj = HasBallMotion(PlayerSetup.HeapIndex)
	    ptr = AutoInstance()
	    ptr.Set(obj)
	    character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
	    obj.Name = 'LOST_BALL_MOTION'
	    obj.HasBall = false
	end

end


PlayerSetup['AddToIdle'] = function(character, clipName, motionName, mirror, tagState)
	local playMotion = 'PLAY_' .. motionName
	local playSpeedMotion = 'SPEED_' .. motionName
	local specificMotion = 'SPECIFY_' .. motionName
	do	-- TO_IDLE motion
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playMotion
		obj.Parameter = 'FeasableSpeed'
		obj.AddClip(clipName, mirror, 0.0)
		obj.Cyclic = false;
	end 
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playSpeedMotion
		obj.Playback = playMotion
		obj.Speed = 'FeasableSpeed'
		obj.MinSpeed = PlayerSetup.MinSpeed
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = specificMotion
		obj.Playback = playMotion
		obj.MotionType = EMotionType.Run
	end	
	do	--
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = specificMotion
		obj.StartState = tagState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirror, obj.StartState, 0).Value
		obj.StartRegion = 0.0 -- To idle is not loopable so lets not have a start cushion
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
		obj.Duration = 0.1 -- 6 frames
	end	
end

PlayerSetup['LocomotionTurn'] = function(character, clipName, motionName, mirrored, animateBall, startState, angleName, minAngle, maxAngle, playbackAngle, adjustmentRate, timeOffset, speedName, minSpeed)
	local playName = 'PLAY_' .. motionName
	local adjustName = 'ADJUST_' .. motionName
	local phaseName = 'PHASE_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = speedName
		obj.AddClip(clipName, mirrored, minSpeed)
		obj.AddClip(clipName, mirrored, 100)
	end 
	do	
		local obj = PivotRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.PlaybackAngle = playbackAngle
		obj.AdjustmentRate = adjustmentRate
		obj.OffsetTime = timeOffset
		obj.SpeedName = speedName
		obj.AngleName = angleName
		obj.Min = minAngle
		obj.Max = maxAngle
		obj.MinSpeed = minSpeed
	end 
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = phaseName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirrored, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
	do	
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = phaseName
		obj.MotionType = EMotionType.Run
		obj.AnimateBall = animateBall
	end
end

PlayerSetup['LocomotionSnake'] = function(character, clipName, motionName, mirrored, animateBall, startState, angleName, minAngle, maxAngle, playbackAngle, adjustmentRate, speedName, minSpeed)
	local playName = 'PLAY_' .. motionName
	local playSpeedName = 'SPEED_' .. motionName
	local adjustName = 'ADJUST_' .. motionName
	local phaseName = 'PHASE_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = speedName
		obj.AddClip(clipName, mirrored, minSpeed)
		obj.AddClip(clipName, mirrored, 100)
	end 
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playSpeedName
		obj.Playback = playName
		obj.Speed = speedName
		obj.AdjustableRate = true
		obj.MinSpeed = minSpeed
	end
	do	-- ADJUST_JOG_RUN_0
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playSpeedName
		obj.AdjustmentRate = adjustmentRate
		obj.PlaybackAngle = playbackAngle
		obj.SpeedName = speedName
		obj.AngleName = angleName
		obj.Min = minAngle
		obj.Max = maxAngle
		obj.MinSpeed = minSpeed
	end
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = phaseName
		obj.Playback = adjustName
		obj.StartState = startState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirrored, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
	do	
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = phaseName
		obj.MotionType = EMotionType.Run
		obj.AnimateBall = animateBall
	end
end

PlayerSetup['FromIdleToDribble'] = function(character, clipName, motionName, mirrored, minAngle, maxAngle, playbackAngle, contactThreshold, contactDuration)
	local playName = 'PLAY_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		--obj.EndPosition = ClipManager.GetStateStartPosition(clipName, mirror, EAnimState.RightFootOnGround.Value, 1)
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
	end 
	do	
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Dribble
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirrored, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minAngle
		obj.Max = maxAngle
	end 
end

PlayerSetup['FromIdleToDoubleDribble'] = function(character, clipName, motionName, mirrored, minAngle, maxAngle, playbackAngle, contactThreshold, contactDuration)
	local playName = 'PLAY_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
	end 
	do	
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.ContactStyle = EBallImpulseType.Dribble
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetTagTime(clipName, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirrored, 0, 'Ball')
		obj.ContactJoint = 'Ball'
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.PlaybackAngle = playbackAngle
		obj.Min = minAngle
		obj.Max = maxAngle
	end 
end

PlayerSetup['FromIdleToRun'] = function(character, clipName, motionName, timeOffset, angleName, minAngle, maxAngle, playbackAngle, turningRate, speedName, minSpeed)
	local playName = 'PLAY_' .. motionName
	local playSpeedName = 'SPEED_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = speedName
		obj.AddClip(clipName, false, minSpeed)
		obj.AddClip(clipName, false, 100)
		obj.Cyclic = false
	end 
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playSpeedName
		obj.Playback = playName
		obj.Speed = speedName
		obj.AdjustableRate = true
		obj.MinSpeed = minSpeed
	end
	do	
		local obj = PivotRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playSpeedName
		obj.PlaybackAngle = playbackAngle
		obj.AdjustmentRate = turningRate
		obj.OffsetTime = timeOffset
		obj.SpeedName = speedName
		obj.AngleName = angleName
		obj.Min = minAngle
		obj.Max = maxAngle
		obj.MinSpeed = minSpeed
	end 
end

PlayerSetup['AddRunToStrafe'] = function(character, motionName, prefix, animateBall, maxTurnRate)
	local playName		= 'PLAY_' .. motionName
	local selectName	= 'SELECT_' .. motionName
	local strafeName	= 'STRAFE_' .. motionName
	local rightName		= 'RIGHT_' .. motionName
	local leftName		= 'LEFT_' .. motionName
	local clipName		= prefix..'_0'
	
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.AddClip(prefix..'_CC180',	false, -180)
		obj.AddClip(prefix..'_CC135',	true,  -135)
		obj.AddClip(prefix..'_CC90',	true,   -90)
		obj.AddClip(prefix..'_CW45',	false,  -45)
		obj.AddClip(prefix..'_0',		false,    0)
		obj.AddClip(prefix..'_CC45',	false,   45)
		obj.AddClip(prefix..'_CC90',	false,   90)
		obj.AddClip(prefix..'_CC135',	false,  135)
		obj.AddClip(prefix..'_CC180',	false,  180)
		obj.Cyclic = false
	end 
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = leftName
		obj.Playback = playName
		obj.StartState = EAnimState.LeftFootOnGround.Value
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirrored, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = rightName
		obj.Playback = playName
		obj.StartState = EAnimState.RightFootOnGround.Value
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirrored, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
	do	-- 
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = selectName
		obj.Add(leftName)
		obj.Add(rightName)
		obj.Switchable = false
	end
	do	-- 
		local obj = StrafeAngle(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = strafeName
		obj.Playback = selectName
		obj.InitializeWithDesiredMovement = true
	end 
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = strafeName
		obj.MotionType = EMotionType.Strafe
	end
end

PlayerSetup['AddIdleToStrafe'] = function(character, motionName, prefix, animateBall, maxTurnRate)
	local specificName	= 'SPECIFIC_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	local speedName     = 'SPEED_' .. motionName
	local fadeName		= 'FADE_' .. motionName
	local playName		= 'PLAY_' .. motionName
	do	-- PLAY_STRAFE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.AddClip(prefix .. '_CC180',	false, -180)
		obj.AddClip(prefix .. '_CC135',	true,  -135)
		obj.AddClip(prefix .. '_CC90',	true,   -90)
		obj.AddClip(prefix .. '_CW45',	false,  -45)
		obj.AddClip(prefix .. '_0',		false,    0)
		obj.AddClip(prefix .. '_CC45',	false,   45)
		obj.AddClip(prefix .. '_CC90',	false,   90)
		obj.AddClip(prefix .. '_CC135',	false,  135)
		obj.AddClip(prefix .. '_CC180',	false,  180)
		obj.Cyclic = false
	end
	do	-- STRAFE
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.AdjustmentRate = maxTurnRate
		obj.PlaybackAngle = 0
		obj.SpeedName = 'FeasableSpeed'
		obj.AngleName = 'TurningAngle'
		obj.Min = -180
		obj.Max = 180
		obj.MinSpeed = PlayerSetup.MinSpeed
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = specificName
		obj.Playback = adjustName
		obj.MotionType = EMotionType.Strafe
		obj.AnimateBall = animateBall
	end
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = speedName
		obj.Playback = specificName
		obj.Speed = 'FeasableSpeed'	
		obj.AdjustableRate = true
		obj.MinSpeed = PlayerSetup.MinSpeed		
	end
	do	--
		local obj = StrafeAngle(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = speedName
		obj.AdjustmentRate = maxTurnRate
		obj.InitializeWithDesiredMovement = true
	end
end

PlayerSetup['AddStrafe'] = function(character, motionName, prefix, animateBall, loopable, maxTurnRate)
	local specificName	= 'SPECIFIC_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	local speedName     = 'SPEED_' .. motionName
	local fadeName		= 'FADE_' .. motionName
	local playName		= 'PLAY_' .. motionName
	do	-- PLAY_STRAFE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.AddClip(prefix .. '_CC180',	false, -180)
		obj.AddClip(prefix .. '_CC135',	true,  -135)
		obj.AddClip(prefix .. '_CC90',	true,   -90)
		obj.AddClip(prefix .. '_CW45',	false,  -45)
		obj.AddClip(prefix .. '_0',		false,    0)
		obj.AddClip(prefix .. '_CC45',	false,   45)
		obj.AddClip(prefix .. '_CC90',	false,   90)
		obj.AddClip(prefix .. '_CC135',	false,  135)
		obj.AddClip(prefix .. '_CC180',	false,  180)
		obj.Cyclic = loopable
	end
	do	-- STRAFE
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.AdjustmentRate = maxTurnRate
		obj.PlaybackAngle = 0
		obj.SpeedName = 'FeasableSpeed'
		obj.AngleName = 'TurningAngle'
		obj.Min = -180
		obj.Max = 180
		obj.MinSpeed = PlayerSetup.MinSpeed
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = specificName
		obj.Playback = adjustName
		obj.MotionType = EMotionType.Strafe
		obj.AnimateBall = animateBall
	end
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = speedName
		obj.Playback = specificName
		obj.Speed = 'FeasableSpeed'	
		obj.AdjustableRate = true
		obj.MinSpeed = PlayerSetup.MinSpeed		
	end
	do	--
		local obj = StrafeAngle(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = speedName
		obj.AdjustmentRate = maxTurnRate
		obj.InitializeWithDesiredMovement = false
	end
end

PlayerSetup['AddStrafeToRun'] = function(character, motionName, prefix, animateBall, maxTurnRate, minSpeed)
	--local specificName	= 'SPECIFIC_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	local speedName     = 'SPEED_' .. motionName
	local playName		= 'PLAY_' .. motionName
	do	-- PLAY_STRAFE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.AddClip(prefix .. '_CC180',	false, -180)
		obj.AddClip(prefix .. '_CC135',	true,  -135)
		obj.AddClip(prefix .. '_CC90',	true,   -90)
		obj.AddClip(prefix .. '_CW45',	false,  -45)
		obj.AddClip(prefix .. '_0',		false,    0)
		obj.AddClip(prefix .. '_CC45',	false,   45)
		obj.AddClip(prefix .. '_CC90',	false,   90)
		obj.AddClip(prefix .. '_CC135',	false,  135)
		obj.AddClip(prefix .. '_CC180',	false,  180)
		obj.Cyclic = false
	end
	do	-- STRAFE
		local obj = ContinuousRootAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = adjustName
		obj.Playback = playName
		obj.AdjustmentRate = maxTurnRate
		obj.PlaybackAngle = 0
		obj.SpeedName = 'FeasableSpeed'
		obj.AngleName = 'TurningAngle'
		obj.Min = -180
		obj.Max = 180
		obj.MinSpeed = minSpeed
	end
	do
		local obj = PlaybackSpeed(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = speedName
		obj.Playback = adjustName
		obj.Speed = 'FeasableSpeed'
		obj.AdjustableRate = true
		obj.MinSpeed = minSpeed
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName 
		obj.Playback = speedName
		obj.MotionType = EMotionType.Run
		obj.AnimateBall = animateBall
	end
end

PlayerSetup['AddStrafeToIdle'] = function(character, motionName, prefix, animateBall)
	local fadeName	= 'FADE_' .. motionName
	local speedName = 'SPEED_' .. motionName
	local playName	= 'PLAY_' .. motionName
	do	-- PLAY_STRAFE
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.AddClip(prefix .. '_CC180',	false, -180)
		obj.AddClip(prefix .. '_CC135',	true,  -135)
		obj.AddClip(prefix .. '_CC90',	true,   -90)
		obj.AddClip(prefix .. '_CW45',	false,  -45)
		obj.AddClip(prefix .. '_0',		false,    0)
		obj.AddClip(prefix .. '_CC45',	false,   45)
		obj.AddClip(prefix .. '_CC90',	false,   90)
		obj.AddClip(prefix .. '_CC135',	false,  135)
		obj.AddClip(prefix .. '_CC180',	false,  180)
		obj.Cyclic = false
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName 
		obj.Playback = playName
		obj.MotionType = EMotionType.Strafe
		obj.AnimateBall = animateBall
	end
end

PlayerSetup['AddStrafeInterrupt'] = function(character, motionName)
	do	--
		local obj = MovementToFacing(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.ResetValues = 'LocomotionParameters'
	end
end

PlayerSetup['AddIdle'] = function(character, motionName, clipName, animateBall)
	local playName = 'PLAY_' .. motionName
	do	-- PLAY_IDLE motion
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'FeasableSpeed'
		obj.AddClip(clipName, false, 0.0)
		obj.AddClip(clipName, false, PlayerSetup.MinSpeed)
	end 
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.MotionType = EMotionType.Idle
		obj.AnimateBall = animateBall
	end
end

PlayerSetup['AddTurnOnSpot'] = function(character, motionName, prefix, animateBall)
	local playName		= 'PLAY_' .. motionName
	local specificName	= 'SPECIFIC_' .. motionName
	do	-- PLAY_STRAFE
		local obj = TurnToAngle(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Parameter = 'StrafeAngle'
		obj.Speed = 'FeasableSpeed'
		obj.MinSpeed = 0.0
		obj.MaxSpeed = PlayerSetup.MinSpeed -- same as the min speed for strafing
		obj.StopAngle = 0.0
		obj.StopRange = 1.0
		obj.AddClip(prefix .. '_CC180',		true,   180.0)
		obj.AddClip(prefix .. '_CC90',		true,	 90.0)
		obj.AddClip(prefix .. '_CC45',		true,	 45.0)
		obj.AddClip(prefix .. '_inplace',	false,    0.0)
		obj.AddClip(prefix .. '_CC45',		false,  -45.0)
		obj.AddClip(prefix .. '_CC90',		false,  -90.0)
		obj.AddClip(prefix .. '_CC180',		false, -180.0)
		obj.Cyclic = false
	end
	do	--
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = specificName
		obj.Playback = playName
		obj.MotionType = EMotionType.Idle
		obj.AnimateBall = animateBall
	end
	do	--
		local obj = StrafeAngle(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = specificName
		obj.AdjustmentRate = 180
		obj.OnEntry = true
		obj.InitializeWithDesiredMovement = false
	end
end

PlayerSetup['AddThrow'] = function(character, clipName, motionName, mirrored)
	local playName = 'PLAY_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
	end 
	do	
		local obj = ThrowAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.PlaybackAngle = 0
		obj.AngleParameter = 'TouchAngle'
		obj.Min = -180
		obj.Max = 180
		obj.Duration = 0.25
		obj.IsEntryCondition = true
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)

	end 
end

PlayerSetup['AddThrowAway'] = function(character, clipName, motionName, mirrored, minA, maxA)
	local playName = 'PLAY_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
	end 
	do	
		local obj = ThrowAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = playName
		obj.PlaybackAngle = 0
		obj.AngleParameter = 'TouchAngle'
		obj.Min = minA
		obj.Max = maxA
		obj.Duration = 0.25
		obj.IsEntryCondition = true
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)

	end 
end

PlayerSetup['AddThrows'] = function(character)
	
	-- (1) BALL_THROW_TARGETED is for the main game.
	do
		local obj = RandomCompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SELECT_BALL_THROW_TARGETED'
		obj.Add('LEFT_BALL_THROW')
		obj.Add('RIGHT_BALL_THROW')
		obj.Add('LEFT_SIDE_BALL_THROW')
		obj.Add('RIGHT_SIDE_BALL_THROW')
		obj.Switchable = false
	end 
	do
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'BALL_THROW_TARGETED'
		obj.Playback = 'SELECT_BALL_THROW_TARGETED'
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_THROW_BALL
		obj.IsEntryCondition = true;
		obj.MotionType = EMotionType.Throw
	end
	-- (2) BALL_THROW_AWAY is for the goalkeeping mini-game.
	do
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'SELECT_BALL_THROW_AWAY'
		obj.Add('LEFT_BALL_THROW_AWAY')
		obj.Add('RIGHT_BALL_THROW_AWAY')
		obj.Switchable = false
	end 
	do
		local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'BALL_THROW_AWAY'
		obj.Playback = 'SELECT_BALL_THROW_AWAY'
		obj.MovementIntention = EMovementInterpretation.GOALKEEPER_THROW_BALL_AWAY
		obj.IsEntryCondition = true;
		obj.MotionType = EMotionType.Throw
	end 
	--  Distinguished between (1)(2) by obj.MovementIntention
	do 
		local obj = CompositeMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = 'BALL_THROW'
		obj.Add('BALL_THROW_TARGETED')
		obj.Add('BALL_THROW_AWAY')
		obj.Switchable = false
	end 
end

PlayerSetup['AddSimpleTrap'] = function(character, clipName, motionName, mirrored, kickStyle, isEntryCondition, angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)
	local playName		= 'PLAY_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
		obj.PlaybackRate = PlayerSetup.TrapPlaybackRate
	end 
	do	-- 
		local obj = TouchAdjustment(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirrored, 0, contactJoint)
		obj.ContactJoint = contactJoint
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.AdjustTarget = adjustTarget
		obj.AdjustPosition = adjustPosition
		obj.AdjustOrientation = adjustOrientation
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	do	-- 
		local obj = ExpectedTrapIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_TRAP_BALL
		obj.Angle = angleName
		obj.Height = 'TrapHeight'
		obj.Speed = 'TargetSpeed'
		obj.MinSpeed = minSpeed
		obj.MaxSpeed = maxSpeed
		obj.MinAngle = minAngle
		obj.MaxAngle = maxAngle
		obj.MinHeight = minHeight
		obj.MaxHeight = maxHeight
		obj.BeforeContact = true
		obj.IsEntryCondition = isEntryCondition
		obj.MotionType = EMotionType.Trap
		
		-- override the Motion Type if it's a chest trap
		if string.find(motionName, 'CHEST') ~= nil
		then
			obj.MotionType = EMotionType.ChestTrap
		end
	end
end
PlayerSetup['AddControlTrap'] = function(character, clipName, motionName, mirrored, kickStyle, isEntryCondition, angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)
	local playName		= 'PLAY_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
		obj.PlaybackRate = PlayerSetup.TrapPlaybackRate
	end 
	do	-- 
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetTagTime(clipName, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirrored, 0, contactJoint)
		obj.ContactJoint = contactJoint
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.AdjustTarget = adjustTarget
		obj.AdjustPosition = adjustPosition
		obj.AdjustOrientation = adjustOrientation
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	do	-- 
		local obj = ExpectedTrapIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.MovementIntention = EMovementInterpretation.APPROACH_AND_TRAP_BALL
		obj.Angle = angleName
		obj.Height = 'TrapHeight'
		obj.Speed = 'TargetSpeed'
		obj.MinSpeed = minSpeed
		obj.MaxSpeed = maxSpeed
		obj.MinAngle = minAngle
		obj.MaxAngle = maxAngle
		obj.MinHeight = minHeight
		obj.MaxHeight = maxHeight
		obj.BeforeContact = true
		obj.IsEntryCondition = isEntryCondition
		obj.MotionType = EMotionType.Trap
		
		-- override the Motion Type if it's a chest trap
		if string.find(motionName, 'CHEST') ~= nil
		then
			obj.MotionType = EMotionType.ChestTrap
		end
	end
end

PlayerSetup['AddNoRequestTrap'] = function(character, clipName, motionName, mirrored, kickStyle, isEntryCondition, angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)
	local playName		= 'PLAY_' .. motionName
	local adjustName	= 'ADJUST_' .. motionName
	do	
		local obj = Playback(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = playName
		obj.Cyclic = false
		obj.AddClip(clipName, mirrored, 0)
		obj.PlaybackRate = PlayerSetup.TrapPlaybackRate
	end 
	do	-- 
		local obj = DoubleTouchMotion(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)

		obj.Name = adjustName
		obj.Playback = playName
		obj.ContactStyle = kickStyle
		obj.ContactTime = ClipManager.GetTagTime(clipName, EAnimTag.HeadBallCollision.Value, EAnimTag.LeftFootBallCollision.Value, 0)
		obj.ContactDuration = ClipManager.GetDuration(clipName)
		obj.SecondContactTime = ClipManager.GetTagTime(clipName, EAnimTag.StopBallAnim.Value, EAnimTag.StopBallAnim.Value, 0)
		obj.ContactOffset = ClipManager.GetOffsetToJoint(clipName, mirrored, 0, contactJoint)
		obj.ContactJoint = contactJoint
		obj.ContactThreshold = contactThreshold
		obj.ContactDirection = 'TouchDirection'
		obj.AdjustTarget = adjustTarget
		obj.AdjustPosition = adjustPosition
		obj.AdjustOrientation = adjustOrientation
		obj.PlaybackAngle = 0
		obj.Min = -180
		obj.Max = 180
	end
	do	-- 
		local obj = ExpectedTrapIntention(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = adjustName
		obj.MovementIntention = EMovementInterpretation.NO_REQUEST
		obj.Angle = angleName
		obj.Height = 'TrapHeight'
		obj.Speed = 'TargetSpeed'
		obj.MinSpeed = minSpeed
		obj.MaxSpeed = maxSpeed
		obj.MinAngle = minAngle
		obj.MaxAngle = maxAngle
		obj.MinHeight = minHeight
		obj.MaxHeight = maxHeight
		obj.BeforeContact = true
		obj.IsEntryCondition = isEntryCondition
		obj.MotionType = EMotionType.Trap
		
		-- override the Motion Type if it's a chest trap
		if string.find(motionName, 'CHEST') ~= nil
		then
			obj.MotionType = EMotionType.ChestTrap
		end
	end
end

PlayerSetup['AddTrap'] = function(character, trapFn, clipName, motionName, mirrored, startState, kickStyle, isEntryCondition, angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)
	local trapName = 'TRAP_' .. motionName
	
	trapFn(character, clipName, trapName, mirrored, kickStyle, isEntryCondition, angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)
	
	
	do
		local obj = PhaseTransition(PlayerSetup.HeapIndex)
		ptr = AutoInstance()
		ptr.Set(obj)
		character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
		
		obj.Name = motionName
		obj.Playback = trapName
		obj.StartState = startState
		obj.StartPosition = ClipManager.GetStateStartPosition(clipName, mirrored, obj.StartState, 0).Value
		obj.StartGeneric = ClipManager.TimeToGenericTime(clipName, obj.StartRegion)
		obj.EndGeneric = ClipManager.TimeToGenericTime(clipName, obj.EndRegion)
	end
end

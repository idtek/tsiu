do
	local ptr
	
	-- player character file 
	local library = Animation.CharacterLibrary
	do
		local addGroupAnim = function( character, groupName, clipName, characterName )
			local motionName = characterName .. '_' .. groupName
			--local playName = 'Play_' .. motionName		
			do
				local obj = CharacterPlayback(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				--obj.Name = playName
				obj.Name = motionName
				obj.CharacterName = characterName
				obj.AddClip(clipName, false, 0)
			end
			
			-- do 
				-- local obj = CrossFade(EHeapIndex.ANIM_HEAPINDEX)
				-- ptr = AutoInstance()
				-- ptr.Set(obj)
				-- character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
			
				-- obj.Name = motionName
				-- obj.Playback = playName -- CrossFade instance picks the CharacterPlayback instance to call
				-- obj.Duration = 0.20 -- or 12 frames
				-- --obj.Duration = 0.05 -- or 3 frames
			-- end
			
			local groupIndex = tovalue(character.FindIndex(groupName))
			if groupIndex < 0 then -- Group Not Found
			 	local obj = CompositeMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
				obj.Name = groupName
				obj.Add(motionName) -- CompositeMotion instance picks the CrossFade instance to call
			else -- Group found
				local obj = character.Motions[groupIndex]
				obj.Add(motionName)
			end
		end
		
		local character = Character(EHeapIndex.ANIM_HEAPINDEX)
		ptr = AutoPointerCharacter()
		ptr.Set(character)
		library.Characters.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
		
		character.Name = 'NISPlayer'
		character.SkeletonName = 'Player'
		character.IndividualType = 'TemperaryNISIndividual'
		
		do		
			do
				-- this list only covers the case for Hippo and Rabbid goalies. Should any other character go in net, game will assert or lock (final)
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Pig')
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Cat')
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Gorilla')				
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Hippo')
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Wolf')				
				addGroupAnim( character, 'Rage', 'HIP_disappointed', 'Deer')
				addGroupAnim( character, 'Rage', 'RAG_disappointed', 'Rabbid')
				addGroupAnim( character, 'Rage', 'RAY_disappointed', 'Pele') -- Special case handled by code for approriate resources

				addGroupAnim( character, 'Celebrate', 'PIG_celeb_dance', 'Pig')
				addGroupAnim( character, 'Celebrate', 'CAT_celeb_FistPump', 'Cat')
				addGroupAnim( character, 'Celebrate', 'GOR_celeb1Hpose', 'Gorilla')
				addGroupAnim( character, 'Celebrate', 'DER_Celeb_Loop', 'Hippo')
				addGroupAnim( character, 'Celebrate', 'WLF_celeb_Windmill', 'Wolf')				
				addGroupAnim( character, 'Celebrate', 'DER_celeb_backflips', 'Deer')
				addGroupAnim( character, 'Celebrate', 'RAB_celeb_RunCircles', 'Rabbid')
				addGroupAnim( character, 'Celebrate', 'PEL_celeb_FistPump', 'Pele') -- Special case handled by code for approriate resources

				addGroupAnim( character, 'Celebrate2', 'PIG_celeb_plane', 'Pig')
				addGroupAnim( character, 'Celebrate2', 'CAT_celeb_kneeslide', 'Cat')
				addGroupAnim( character, 'Celebrate2', 'GOR_celeb_chest', 'Gorilla')
				addGroupAnim( character, 'Celebrate2', 'DER_Celeb_Loop', 'Hippo')
				addGroupAnim( character, 'Celebrate2', 'WLF_cocky', 'Wolf')				
				addGroupAnim( character, 'Celebrate2', 'DER_celeb_point', 'Deer')
				addGroupAnim( character, 'Celebrate2', 'RAB_celeb_RunCircles', 'Rabbid')
				addGroupAnim( character, 'Celebrate2', 'PEL_celeb_kneeslide', 'Pele') -- Special case handled by code for approriate resources

				addGroupAnim( character, 'Win', 'PIG_win1', 'Pig')
				addGroupAnim( character, 'Win', 'CAT_win1', 'Cat')
				addGroupAnim( character, 'Win', 'CAT_win1', 'BBPlayer')
				addGroupAnim( character, 'Win', 'GOR_win1', 'Gorilla')
				addGroupAnim( character, 'Win', 'HIP_win1', 'Hippo')
				addGroupAnim( character, 'Win', 'CAT_win1', 'Wolf')
				addGroupAnim( character, 'Win', 'DER_win1', 'Deer')
				addGroupAnim( character, 'Win', 'RAB_celeb_dance1', 'Rabbid')
				addGroupAnim( character, 'Win', 'CAT_win1', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Fail', 'PIG_loose2', 'Pig')
				addGroupAnim( character, 'Fail', 'CAT_loose1', 'Cat')
				addGroupAnim( character, 'Fail', 'CAT_loose1', 'BBPlayer')
				addGroupAnim( character, 'Fail', 'GOR_loose1', 'Gorilla')
				addGroupAnim( character, 'Fail', 'HIP_loose1', 'Hippo')
				addGroupAnim( character, 'Fail', 'CAT_loose1', 'Wolf')
				addGroupAnim( character, 'Fail', 'DER_loose1', 'Deer')
				addGroupAnim( character, 'Fail', 'PIG_loose2', 'Rabbid')
				addGroupAnim( character, 'Fail', 'CAT_loose1', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Fail2', 'PIG_loose2', 'Pig')
				addGroupAnim( character, 'Fail2', 'CAT_loose2', 'Cat')
				addGroupAnim( character, 'Fail2', 'CAT_loose2', 'BBPlayer')
				addGroupAnim( character, 'Fail2', 'GOR_loose2', 'Gorilla')
				addGroupAnim( character, 'Fail2', 'HIP_loose2', 'Hippo')
				addGroupAnim( character, 'Fail2', 'CAT_loose1', 'Wolf')
				addGroupAnim( character, 'Fail2', 'DER_loose2', 'Deer')
				addGroupAnim( character, 'Fail2', 'PIG_loose2', 'Rabbid')
				addGroupAnim( character, 'Fail2', 'CAT_loose2', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Loop', 'PIG_celeb_loop', 'Pig')
				addGroupAnim( character, 'Loop', 'CAT_celeb_cheer', 'Cat')
				addGroupAnim( character, 'Loop', 'GOR_celeb_loop', 'Gorilla')
				addGroupAnim( character, 'Loop', 'HIP_celeb_loop', 'Hippo')
				addGroupAnim( character, 'Loop', 'WLF_celeb_loop', 'Wolf')
				addGroupAnim( character, 'Loop', 'DER_celeb_cheer', 'Deer')
				addGroupAnim( character, 'Loop', 'RAB_celeb_dance1', 'Rabbid')
				addGroupAnim( character, 'Loop', 'PEL_celeb_cheer', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Loop2', 'PIG_game_dance1', 'Pig')
				addGroupAnim( character, 'Loop2', 'CAT_game_dance3', 'Cat')
				addGroupAnim( character, 'Loop2', 'GOR_celeb_loop2', 'Gorilla')
				addGroupAnim( character, 'Loop2', 'HIP_celeb_loop2', 'Hippo')
				addGroupAnim( character, 'Loop2', 'WLF_celeb_loop2', 'Wolf')
				addGroupAnim( character, 'Loop2', 'DER_game_dance2', 'Deer')
				addGroupAnim( character, 'Loop2', 'RAB_celeb_dance2', 'Rabbid')
				addGroupAnim( character, 'Loop2', 'PEL_game_dance3', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Dance', 'PIG_game_dance1', 'Pig')
				addGroupAnim( character, 'Dance', 'CAT_game_dance1', 'Cat')
				addGroupAnim( character, 'Dance', 'GOR_celeb_cheer', 'Gorilla')
				addGroupAnim( character, 'Dance', 'HIP_game_dance1', 'Hippo')
				addGroupAnim( character, 'Dance', 'WLF_game_dance1', 'Wolf')
				addGroupAnim( character, 'Dance', 'DER_game_dance1', 'Deer')
				addGroupAnim( character, 'Dance', 'RAB_celeb_dance1', 'Rabbid')
				addGroupAnim( character, 'Dance', 'PEL_game_dance1', 'Pele') -- Special case handled by code for approriate resources
				
				addGroupAnim( character, 'Dance2', 'PIG_game_dance2', 'Pig')
				addGroupAnim( character, 'Dance2', 'CAT_game_dance3', 'Cat')
				addGroupAnim( character, 'Dance2', 'GOR_celeb_cheer2', 'Gorilla')
				addGroupAnim( character, 'Dance2', 'HIP_game_dance2', 'Hippo')
				addGroupAnim( character, 'Dance2', 'WLF_celeb_loop', 'Wolf')
				addGroupAnim( character, 'Dance2', 'DER_game_dance2', 'Deer')
				addGroupAnim( character, 'Dance2', 'RAB_celeb_dance2', 'Rabbid')
				addGroupAnim( character, 'Dance2', 'PEL_game_dance3', 'Pele') -- Special case handled by code for approriate resources
			end
			do
			 	local obj = NISMotion(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'NISPicker'
			end 
			do
			 	local obj = EventBroadcaster(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'EventBroadcaster'
			end 
			do  -- FaceHandsSelector Motion
				local obj = FaceHandsSelector(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'FaceHandsSelector'
			end			
			do
			 	local obj = SpecifyMotionType(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'SpecifyMotion'
			 	obj.MotionType = EMotionType.NISMotion
			end 
			do
			 	local obj = MotionList(EHeapIndex.ANIM_HEAPINDEX)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(EHeapIndex.ANIM_HEAPINDEX.Value, ptr)
				
			 	obj.Name = 'Root'
				obj.Add('NISPicker')
				obj.Add('SpecifyMotion')
				obj.Add('EventBroadcaster')
				obj.Add('FaceHandsSelector')
				
			end 
		end
		character.DAGRoot = 'Root'
		character.Initialize()
		
	end
end

package.path = "anim:?.lua"
require "PlayerSetup"

do
	local ptr
	
	-- player character file 
	local library = Animation.CharacterLibrary
	do
		local cat = {}
		local character = Character(PlayerSetup.HeapIndex)
		ptr = AutoPointerCharacter()
		ptr.Set(character)
		library.Characters.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)				
		
		character.Name				= 'Cat'
		character.SkeletonName		= 'Player'
		character.IndividualType	= 'TemperaryIndividual'
		
		cat.adjustmentRate = 6.0
		cat.maxStrafeRate = 5.0
		cat.dribbleThreshold = 0.40
		cat.standTrapThreshold = 0.30
		cat.runTrapThreshold = 0.40
		cat.standChestTrapThreshold = 0.30
		cat.runChestTrapThreshold = 0.5
		
		do		
			do	-- MovementFacingDirection Motion
				local obj = MovementFacingDirection(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'MovementFacingDirection'
				obj.Facing = 'Facing'
				obj.Movement = 'Movement'
			end 
			do	-- LocomotionParameters Motion
				local obj = LocomotionParameters(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'LocomotionParameters'
				obj.MaxSpeed = PlayerSetup.MaxSpeed
				obj.MinSpeed = PlayerSetup.MinSpeed
				obj.StrafeSpeed = 1.1*ClipManager.GetSpeed('Cat_strafe_0', false)
				obj.StopDistance = ClipManager.GetDisplacement('CAT_run_to_stop_TRANS', false)
				
				obj.BodyContactHeights.Chest	= 1.0881
				obj.BodyContactHeights.Head		= 2.1
				obj.BodyContactHeights.Header	= 2.922
			end 
			do  -- PhysicsMessenger Motion
				local obj = PhysicsMessenger(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'PhysicsMessenger'
				obj.Dribble.MinimumTouchCount = 3
				obj.Dribble.MinimalDistance = 0.20
				obj.Dribble.StraightAwayAngle = 45
				obj.Dribble.MaxSpeed = ClipManager.GetSpeed('cat_RUN_dribble_0', false)
			end
			do  -- EventBroadcaster Motion
				local obj = EventBroadcaster(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'EventBroadcaster'
			end
			do  -- FaceHandsSelector Motion
				local obj = FaceHandsSelector(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'FaceHandsSelector'
			end			
			
			PlayerSetup.AddIdle(character, 'IDLE', 'CAT_Ready_idle', false)
			PlayerSetup.AddIdle(character, 'BALL_IDLE', 'GK_standing_idle_wBALL', true)
			PlayerSetup.AddTurnOnSpot(character, 'TURN_ON_SPOT', 'CAT_ready_TURN', false)
			PlayerSetup.AddTurnOnSpot(character, 'BALL_TURN_ON_SPOT', 'GK_standing_TURN_wBALL', true)
			
			--PlayerSetup.FromIdleToRun(character, clipName, motionName, timeOffset, angleName, minAngle, maxAngle, playbackAngle, turningRate, speedName, minSpeed)
			PlayerSetup.FromIdleToRun(character, 'CAT_ready_to_run_TRANS',			'IDLE_0',		0.1665, 'TurningAngle',  -45,   45,    0, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.FromIdleToRun(character, 'CAT_ready_to_run_TRANS_CC90',		'IDLE_CC90',	0.1665, 'TurningAngle',   45,  135,   90, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.FromIdleToRun(character, 'CAT_ready_to_run_TRANS_CW90',		'IDLE_CW90',	0.1665, 'TurningAngle', -135,  -45,  -90, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.FromIdleToRun(character, 'CAT_ready_to_run_TRANS_CC180',	'IDLE_CC180',	0.1665, 'TurningAngle',  135,  180,  180, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.FromIdleToRun(character, 'CAT_ready_to_run_TRANS_CW180',	'IDLE_CW180',	0.1665, 'TurningAngle', -180, -135, -180, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			
			do	-- FROM_IDLE motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'COMPOSITE_FROM_IDLE'
				obj.Add('IDLE_0')
				obj.Add('IDLE_CW90')
				obj.Add('IDLE_CC90')
				obj.Add('IDLE_CW180')
				obj.Add('IDLE_CC180')
				obj.Switchable = false
			end 
			do	-- FROM_IDLE_SPECIFIC
				local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'FROM_IDLE'
				obj.Playback = 'COMPOSITE_FROM_IDLE'
				obj.MotionType = EMotionType.Run
			end		
			
			-- PlayerSetup.FromIdleToDribble(character, clipName, motionName, mirrored, minAngle, maxAngle, contactThreshold, contactDuration)
			PlayerSetup.FromIdleToDribble(character, 'cat_READY_RUN_dribble_0',		'IDLE_TO_DRIBBLE_0',			false,  -22,   22,    0, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDribble(character, 'cat_READY_RUN_dribble_CC45',	'IDLE_TO_DRIBBLE_CC45',			false,   22,   67,   45, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDribble(character, 'cat_READY_RUN_dribble_CW45',	'IDLE_TO_DRIBBLE_CW45',			false,  -67,  -22,  -45, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDribble(character, 'cat_READY_RUN_dribble_CC90',	'IDLE_TO_DRIBBLE_CC90',			false,   67,  135,   90, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDribble(character, 'cat_READY_RUN_dribble_CW90',	'IDLE_TO_DRIBBLE_CW90',			false, -135,  -67,  -90, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDoubleDribble(character, 'cat_READY_RUN_dribble_CC180', 'IDLE_TO_DRIBBLE_CC180',	false,  135,  180,  180, cat.dribbleThreshold, 0.075)
			PlayerSetup.FromIdleToDoubleDribble(character, 'cat_READY_RUN_dribble_CW180', 'IDLE_TO_DRIBBLE_CW180',	false, -180, -135, -180, cat.dribbleThreshold, 0.075)
			
			do	-- FROM_IDLE_TO_DRIBBLE motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'SELECT_IDLE_TO_DRIBBLE'
				obj.Add('IDLE_TO_DRIBBLE_0')
				obj.Add('IDLE_TO_DRIBBLE_CW45')
				obj.Add('IDLE_TO_DRIBBLE_CC45')
				obj.Add('IDLE_TO_DRIBBLE_CW90')
				obj.Add('IDLE_TO_DRIBBLE_CC90')
				obj.Add('IDLE_TO_DRIBBLE_CW180')
				obj.Add('IDLE_TO_DRIBBLE_CC180')
				obj.Switchable = false
			end 
			--do
			--	local obj = CrossFade(PlayerSetup.HeapIndex)
			--	ptr = AutoInstance()
			--	ptr.Set(obj)
			--	character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
			--	
			--	obj.Name = 'BLEND_IDLE_TO_DRIBBLE'
			--	obj.Playback = 'SELECT_IDLE_TO_DRIBBLE'
			--	obj.Duration = 0.1 -- 6 frames
			--end
			do	-- FromIdleToDribblePivot motion
				local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'IDLE_TO_DRIBBLE'
				obj.Playback = 'SELECT_IDLE_TO_DRIBBLE'
				obj.MovementIntention = EMovementInterpretation.APPROACH_AND_DRIBBLE_BALL
				obj.BeforeContact = true
				obj.MotionType = EMotionType.Dribble
			end 

			------------------------ Cat Locomotion ------------------------
			PlayerSetup.LocomotionTurn(character,	'Cat_run_turn_CW180',	'LEFT_RUN_PIVOT_CW180',		false,	false, EAnimState.LeftFootOnGround.Value,	'TurningAngle', -180, -120, -180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character,	'Cat_run_turn_CC180',	'RIGHT_RUN_PIVOT_CW180',	true,	false, EAnimState.RightFootOnGround.Value, 'TurningAngle', -180, -120, -180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character,	'Cat_run_turn_CC180',	'LEFT_RUN_PIVOT_CC180',		false,	false, EAnimState.LeftFootOnGround.Value,	'TurningAngle',  120,  180,  180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character,	'Cat_run_turn_CW180',	'RIGHT_RUN_PIVOT_CC180',	true,	false, EAnimState.RightFootOnGround.Value, 'TurningAngle',  120,  180,  180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionSnake(character,	'Cat_run_0',			'LEFT_RUN_SNAKE',			false,	false, EAnimState.LeftFootOnGround.Value,	'TurningAngle', -160,  160,    0, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionSnake(character,	'Cat_run_0',			'RIGHT_RUN_SNAKE',			true,	false, EAnimState.RightFootOnGround.Value, 'TurningAngle', -160,  160,    0, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			
			do	-- PIVOT motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_SNAKE'
				obj.Add('LEFT_RUN_SNAKE')
				obj.Add('RIGHT_RUN_SNAKE')
				obj.Switchable = false
			end 
			do	-- PIVOT motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_PIVOT'
				obj.Add('LEFT_RUN_PIVOT_CW180')
				obj.Add('LEFT_RUN_PIVOT_CC180')
				obj.Add('RIGHT_RUN_PIVOT_CW180')
				obj.Add('RIGHT_RUN_PIVOT_CC180')
				obj.Switchable = false
			end 
			
			PlayerSetup.LocomotionTurn(character, 'GK_walk_wBALL_Turn_CW180', 'LEFT_BALL_PIVOT_CW180', false, true, EAnimState.LeftFootOnGround.Value, 'TurningAngle', -180, -120, -180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character, 'GK_walk_wBALL_Turn_CC180', 'RIGHT_BALL_PIVOT_CC180', true, true, EAnimState.RightFootOnGround.Value, 'TurningAngle',  120,  180,  180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character, 'GK_walk_wBALL_Turn_CC180', 'LEFT_BALL_PIVOT_CC180', false, true, EAnimState.LeftFootOnGround.Value, 'TurningAngle',  120,  180,  180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionTurn(character, 'GK_walk_wBALL_Turn_CW180', 'RIGHT_BALL_PIVOT_CW180', true, true, EAnimState.RightFootOnGround.Value, 'TurningAngle', -180, -120, -180, cat.adjustmentRate, 0.1665, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionSnake(character, 'GK_walk_wBALL_0', 'LEFT_BALL_SNAKE', false, true, EAnimState.LeftFootOnGround.Value, 'TurningAngle', -160, 160, 0, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			PlayerSetup.LocomotionSnake(character, 'GK_walk_wBALL_0', 'RIGHT_BALL_SNAKE', true, true, EAnimState.RightFootOnGround.Value, 'TurningAngle', -160, 160, 0, cat.adjustmentRate, 'FeasableSpeed', PlayerSetup.MinSpeed)
			
			do	-- PIVOT motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'BALL_SNAKE'
				obj.Add('LEFT_BALL_SNAKE')
				obj.Add('RIGHT_BALL_SNAKE')
				obj.Switchable = false
			end 
			do	-- PIVOT motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'BALL_PIVOT'
				obj.Add('LEFT_BALL_PIVOT_CW180')
				obj.Add('LEFT_BALL_PIVOT_CC180')
				obj.Add('RIGHT_BALL_PIVOT_CW180')
				obj.Add('RIGHT_BALL_PIVOT_CC180')
			end 
			PlayerSetup.AddToIdle(character, 'CAT_run_to_stop_TRANS', 'LEFT_TO_IDLE', true, EAnimState.LeftFootOnGround.Value)
			PlayerSetup.AddToIdle(character, 'CAT_run_to_stop_TRANS', 'RIGHT_TO_IDLE', false, EAnimState.RightFootOnGround.Value)
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'ToIdle'
				obj.Add('LEFT_TO_IDLE')
				obj.Add('RIGHT_TO_IDLE')
				obj.Add('SPECIFY_RIGHT_TO_IDLE') -- danc: Please remove, this is to eleviate a bug where no foot is down and I must transition.  
				obj.Switchable = false
			end		
			------------------------ End Locomotion ------------------------

			-- LEFT and RIGHT phases of dribbles. the LEFT/RIGHT indicates which foot should be down when it starts.
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CC45', 'LEFT_DRIBBLE_CC45',		cat.dribbleThreshold,   40,   67,   45, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, false )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CW45', 'LEFT_DRIBBLE_CW45',		cat.dribbleThreshold,  -67,  -40,  -45, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, false )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CC90', 'LEFT_DRIBBLE_CC90',		cat.dribbleThreshold,   67,  135,   90, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, false )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CW90', 'LEFT_DRIBBLE_CW90',		cat.dribbleThreshold, -135,  -67,  -90, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, false )
			PlayerSetup.AddDoubleDribble(character, 'cat_RUN_dribble_turn_CW180', 'LEFT_DRIBBLE_CC180',	cat.dribbleThreshold,  135,  180,  180, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, true )
			PlayerSetup.AddDoubleDribble(character, 'cat_RUN_dribble_turn_CC180', 'LEFT_DRIBBLE_CW180',	cat.dribbleThreshold, -180, -135, -180, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, true )

			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CW45', 'RIGHT_DRIBBLE_CC45',		cat.dribbleThreshold,   40,	  67,   45, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, true )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CC45', 'RIGHT_DRIBBLE_CW45',		cat.dribbleThreshold,  -67,	 -40,  -45, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, true )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CW90', 'RIGHT_DRIBBLE_CC90',		cat.dribbleThreshold,   67,  135,   90, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, true )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_pivot_CC90', 'RIGHT_DRIBBLE_CW90',		cat.dribbleThreshold, -135,  -67,  -90, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, true )
			PlayerSetup.AddDoubleDribble(character, 'cat_RUN_dribble_turn_CC180', 'RIGHT_DRIBBLE_CC180',	cat.dribbleThreshold,  135,  180,  180, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, false )
			PlayerSetup.AddDoubleDribble(character, 'cat_RUN_dribble_turn_CW180', 'RIGHT_DRIBBLE_CW180',	cat.dribbleThreshold, -180, -135, -180, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, false )
			
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_0', 'LEFT_DRIBBLE_0',	cat.dribbleThreshold, -45, 45, 0, EAnimState.LeftFootOnGround.Value, EAnimState.RightFootOnGround.Value, false )
			PlayerSetup.AddDribble(character, 'cat_RUN_dribble_0', 'RIGHT_DRIBBLE_0',	cat.dribbleThreshold, -45, 45, 0, EAnimState.RightFootOnGround.Value, EAnimState.LeftFootOnGround.Value, true )
	
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap, 'cat_RUN_dribble_stop', 'LEFT_RUN_DRIBBLE_STOP',  true,  EAnimState.LeftFootOnGround.Value,  EBallImpulseType.FullStop, true, 'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, 180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap, 'cat_RUN_dribble_stop', 'RIGHT_RUN_DRIBBLE_STOP', false, EAnimState.RightFootOnGround.Value, EBallImpulseType.FullStop, true, 'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, 180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddNoRequestTrap, 'cat_RUN_dribble_stop', 'LEFT_NOREQUEST_RUN_DRIBBLE_STOP',  true,  EAnimState.LeftFootOnGround.Value,  EBallImpulseType.FullStop, false, 'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, 180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddNoRequestTrap, 'cat_RUN_dribble_stop', 'RIGHT_NOREQUEST_RUN_DRIBBLE_STOP', false, EAnimState.RightFootOnGround.Value, EBallImpulseType.FullStop, false, 'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, 180, 0, PlayerSetup.MaxFootHeight)

			do	-- RUN_DRIBBLE_STOP
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_DRIBBLE_STOP'
				obj.Add('LEFT_RUN_DRIBBLE_STOP')
				obj.Add('RIGHT_RUN_DRIBBLE_STOP')
				obj.Add('LEFT_NOREQUEST_RUN_DRIBBLE_STOP')
				obj.Add('RIGHT_NOREQUEST_RUN_DRIBBLE_STOP')
				obj.Switchable = false
			end 
			do	-- 
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'SELECT_RUN_DRIBBLE'
				obj.Add('LEFT_DRIBBLE_CW45')
				obj.Add('LEFT_DRIBBLE_CC45')
				obj.Add('RIGHT_DRIBBLE_CW45')
				obj.Add('RIGHT_DRIBBLE_CC45')
				obj.Add('LEFT_DRIBBLE_CW90')
				obj.Add('LEFT_DRIBBLE_CC90')
				obj.Add('RIGHT_DRIBBLE_CW90')
				obj.Add('RIGHT_DRIBBLE_CC90')
				obj.Add('LEFT_DRIBBLE_CW180')
				obj.Add('LEFT_DRIBBLE_CC180')
				obj.Add('RIGHT_DRIBBLE_CW180')
				obj.Add('RIGHT_DRIBBLE_CC180')
				obj.Add('LEFT_DRIBBLE_0')
				obj.Add('RIGHT_DRIBBLE_0')
			end 
			do	-- RUN_DRIBBLE motion
				local obj = ExpectedMovementIntention(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_DRIBBLE'
				obj.Playback = 'SELECT_RUN_DRIBBLE'
				obj.MovementIntention = EMovementInterpretation.APPROACH_AND_DRIBBLE_BALL
				obj.BeforeContact = true
				obj.MotionType = EMotionType.Dribble
			end 			
			
			-- PlayerSetup.AddTrap(character, trapFn,					clipName,								motionName,							mirrored, startState,						kickStyle,					entryCondition,	angleName, contactJoint, adjustTarget, adjustPosition, adjustOrientation, contactThreshold, minSpeed, maxSpeed, minAngle, maxAngle, minHeight, maxHeight)			
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC180',		'LEFT_IDLE_FOOT_TRAP_CC180',		false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.FullStop,	false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC90',		'LEFT_IDLE_FOOT_TRAP_CC90',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.FullStop,	false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_0',			'LEFT_IDLE_FOOT_TRAP_0',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.FullStop,	false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC90',		'LEFT_IDLE_FOOT_TRAP_CW90',			true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC180',		'LEFT_IDLE_FOOT_TRAP_CW180',		true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, -135, 0, PlayerSetup.MaxFootHeight)

			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC180',		'RIGHT_IDLE_FOOT_TRAP_CC180',		true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC90',		'RIGHT_IDLE_FOOT_TRAP_CC90',		true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_0',			'RIGHT_IDLE_FOOT_TRAP_0',			true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC90',		'RIGHT_IDLE_FOOT_TRAP_CW90',		false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_to_idle_CC180',		'RIGHT_IDLE_FOOT_TRAP_CW180',		false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', false, true, true, cat.runTrapThreshold, 0, PlayerSetup.MinSpeed, -180, -135, 0, PlayerSetup.MaxFootHeight)

			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC180',				'LEFT_RUN_CHEST_TRAP_CC180',		false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC90',				'LEFT_RUN_CHEST_TRAP_CC90',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_0',					'LEFT_RUN_CHEST_TRAP_0',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC90',				'LEFT_RUN_CHEST_TRAP_CW90',			true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC180',				'LEFT_RUN_CHEST_TRAP_CW180',		true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)

			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC180',				'RIGHT_RUN_CHEST_TRAP_CC180',		true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC90',				'RIGHT_RUN_CHEST_TRAP_CC90',		true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_0',					'RIGHT_RUN_CHEST_TRAP_0',			true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC90',				'RIGHT_RUN_CHEST_TRAP_CW90',		false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_chest_trap_CC180',				'RIGHT_RUN_CHEST_TRAP_CW180',		false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.runChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)

			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_CC180',				'LEFT_RUN_FOOT_TRAP_CC180',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'LEFT_RUN_FOOT_TRAP_CC90',			false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'LEFT_RUN_FOOT_TRAP_0',				false,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'LEFT_RUN_FOOT_TRAP_CW90',			true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_CC180',				'LEFT_RUN_FOOT_TRAP_CW180',			true,	EAnimState.LeftFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, 0, PlayerSetup.MaxFootHeight)

			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_CC180',				'RIGHT_RUN_FOOT_TRAP_CC180',		true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'RIGHT_RUN_FOOT_TRAP_CC90',			true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'RIGHT_RUN_FOOT_TRAP_0',			true,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddSimpleTrap,	'cat_RUN_dribble_0',					'RIGHT_RUN_FOOT_TRAP_CW90',			false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.dribbleThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddTrap(character, PlayerSetup.AddControlTrap,	'CAT_run_foot_trap_CC180',				'RIGHT_RUN_FOOT_TRAP_CW180',		false,	EAnimState.RightFootOnGround.Value,	EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', false, true, true, cat.runTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, 0, PlayerSetup.MaxFootHeight)

			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_to_idle_CC180',	'IDLE_STAND_CHEST_TRAP_CC180',		false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standChestTrapThreshold, 0, PlayerSetup.MinSpeed,  135,  180, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_to_idle_CC90',	'IDLE_STAND_CHEST_TRAP_CC90',		false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standChestTrapThreshold, 0, PlayerSetup.MinSpeed,   45,  135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_to_idle_0',		'IDLE_STAND_CHEST_TRAP_0',			false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standChestTrapThreshold, 0, PlayerSetup.MinSpeed,  -45,   45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_to_idle_CC90',	'IDLE_STAND_CHEST_TRAP_CW90',		true,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standChestTrapThreshold, 0, PlayerSetup.MinSpeed, -135,  -45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_to_idle_CC180',	'IDLE_STAND_CHEST_TRAP_CW180',		true,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standChestTrapThreshold, 0, PlayerSetup.MinSpeed, -180, -135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)

			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_CC180',			'RUN_STAND_CHEST_TRAP_CC180',		false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_CC90',			'RUN_STAND_CHEST_TRAP_CC90',		false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standChestTrapThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_0',				'RUN_STAND_CHEST_TRAP_0',			false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standChestTrapThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_CC90',			'RUN_STAND_CHEST_TRAP_CW90',		true,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_chest_trap_CC180',			'RUN_STAND_CHEST_TRAP_CW180',		true,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standChestTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, PlayerSetup.MinChestHeight, PlayerSetup.MaxChestHeight)

			PlayerSetup.AddControlTrap(character,						'CAT_stand_foot_trap_CC180',			'IDLE_STAND_FOOT_TRAP_CC180',		false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standTrapThreshold, 0, PlayerSetup.MinSpeed,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_CC90',				'IDLE_STAND_FOOT_TRAP_CC90',		false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standTrapThreshold, 0, PlayerSetup.MinSpeed,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_0',				'IDLE_STAND_FOOT_TRAP_0',			false,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standTrapThreshold, 0, PlayerSetup.MinSpeed,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_CC90',				'IDLE_STAND_FOOT_TRAP_CW90',		true,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standTrapThreshold, 0, PlayerSetup.MinSpeed, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_foot_trap_CC180',			'IDLE_STAND_FOOT_TRAP_CW180',		true,										EBallImpulseType.FullStop,  false,			'InAngle', 'Ball', true, false, false, cat.standTrapThreshold, 0, PlayerSetup.MinSpeed, -180, -135, 0, PlayerSetup.MaxFootHeight)

			PlayerSetup.AddControlTrap(character,						'CAT_stand_foot_trap_to_run_CC180',		'RUN_STAND_FOOT_TRAP_CC180',		false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standTrapThreshold, PlayerSetup.MinSpeed, 1000,  135,  180, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_to_run_CC90',		'RUN_STAND_FOOT_TRAP_CC90',			false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standTrapThreshold, PlayerSetup.MinSpeed, 1000,   45,  135, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_to_run_0',			'RUN_STAND_FOOT_TRAP_0',			false,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standTrapThreshold, PlayerSetup.MinSpeed, 1000,  -45,   45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddSimpleTrap(character,						'CAT_stand_foot_trap_to_run_CC90',		'RUN_STAND_FOOT_TRAP_CW90',			true,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standTrapThreshold, PlayerSetup.MinSpeed, 1000, -135,  -45, 0, PlayerSetup.MaxFootHeight)
			PlayerSetup.AddControlTrap(character,						'CAT_stand_foot_trap_to_run_CC180',		'RUN_STAND_FOOT_TRAP_CW180',		true,										EBallImpulseType.Dribble,   false,			'InOutAngle', 'Ball', true, false, true, cat.standTrapThreshold, PlayerSetup.MinSpeed, 1000, -180, -135, 0, PlayerSetup.MaxFootHeight)

			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'IDLE_FOOT_TRAP'
				obj.Add('LEFT_IDLE_FOOT_TRAP_0')
				obj.Add('RIGHT_IDLE_FOOT_TRAP_0')
				obj.Add('LEFT_IDLE_FOOT_TRAP_CC90')
				obj.Add('LEFT_IDLE_FOOT_TRAP_CW90')
				obj.Add('RIGHT_IDLE_FOOT_TRAP_CC90')
				obj.Add('RIGHT_IDLE_FOOT_TRAP_CW90')
				obj.Add('LEFT_IDLE_FOOT_TRAP_CC180')
				obj.Add('LEFT_IDLE_FOOT_TRAP_CW180')
				obj.Add('RIGHT_IDLE_FOOT_TRAP_CC180')
				obj.Add('RIGHT_IDLE_FOOT_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_CHEST_TRAP'
				obj.Add('LEFT_RUN_CHEST_TRAP_0')
				obj.Add('RIGHT_RUN_CHEST_TRAP_0')
				obj.Add('LEFT_RUN_CHEST_TRAP_CC90')
				obj.Add('LEFT_RUN_CHEST_TRAP_CW90')
				obj.Add('RIGHT_RUN_CHEST_TRAP_CC90')
				obj.Add('RIGHT_RUN_CHEST_TRAP_CW90')
				obj.Add('LEFT_RUN_CHEST_TRAP_CC180')
				obj.Add('LEFT_RUN_CHEST_TRAP_CW180')
				obj.Add('RIGHT_RUN_CHEST_TRAP_CC180')
				obj.Add('RIGHT_RUN_CHEST_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_FOOT_TRAP'
				obj.Add('LEFT_RUN_FOOT_TRAP_0')
				obj.Add('RIGHT_RUN_FOOT_TRAP_0')
				obj.Add('LEFT_RUN_FOOT_TRAP_CC90')
				obj.Add('LEFT_RUN_FOOT_TRAP_CW90')
				obj.Add('RIGHT_RUN_FOOT_TRAP_CC90')
				obj.Add('RIGHT_RUN_FOOT_TRAP_CW90')
				obj.Add('LEFT_RUN_FOOT_TRAP_CC180')
				obj.Add('LEFT_RUN_FOOT_TRAP_CW180')
				obj.Add('RIGHT_RUN_FOOT_TRAP_CC180')
				obj.Add('RIGHT_RUN_FOOT_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'IDLE_STAND_CHEST_TRAP'
				obj.Add('IDLE_STAND_CHEST_TRAP_0')
				obj.Add('IDLE_STAND_CHEST_TRAP_CC90')
				obj.Add('IDLE_STAND_CHEST_TRAP_CW90')
				obj.Add('IDLE_STAND_CHEST_TRAP_CC180')
				obj.Add('IDLE_STAND_CHEST_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_STAND_CHEST_TRAP'
				obj.Add('RUN_STAND_CHEST_TRAP_0')
				obj.Add('RUN_STAND_CHEST_TRAP_CC90')
				obj.Add('RUN_STAND_CHEST_TRAP_CW90')
				obj.Add('RUN_STAND_CHEST_TRAP_CC180')
				obj.Add('RUN_STAND_CHEST_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'IDLE_STAND_FOOT_TRAP'
				obj.Add('IDLE_STAND_FOOT_TRAP_0')
				obj.Add('IDLE_STAND_FOOT_TRAP_CC90')
				obj.Add('IDLE_STAND_FOOT_TRAP_CW90')
				obj.Add('IDLE_STAND_FOOT_TRAP_CC180')
				obj.Add('IDLE_STAND_FOOT_TRAP_CW180')
				obj.Switchable = false
			end		
			do	--
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_STAND_FOOT_TRAP'
				obj.Add('RUN_STAND_FOOT_TRAP_0')
				obj.Add('RUN_STAND_FOOT_TRAP_CC90')
				obj.Add('RUN_STAND_FOOT_TRAP_CW90')
				obj.Add('RUN_STAND_FOOT_TRAP_CC180')
				obj.Add('RUN_STAND_FOOT_TRAP_CW180')
				obj.Switchable = false
			end		
			
			PlayerSetup.AddRunShot(character,	'LEFT_RUN_SHOT_0',		'CAT_run_shot_0',		true,	EAnimState.LeftFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  -45,   45,    0)
			PlayerSetup.AddRunShot(character,	'LEFT_RUN_SHOT_CC90',	'CAT_run_shot_CW90',	true,	EAnimState.LeftFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,   45,  135,   90)
			PlayerSetup.AddRunShot(character,	'LEFT_RUN_SHOT_CW90',	'CAT_run_shot_CC90',	true,	EAnimState.LeftFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -135,  -45,  -90)
			PlayerSetup.AddRunShot(character,	'LEFT_RUN_SHOT_CC180',	'CAT_run_shot_CC180',	true,	EAnimState.LeftFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  135,  180,  180)
			PlayerSetup.AddRunShot(character,	'LEFT_RUN_SHOT_CW180',	'CAT_run_shot_CC180',	true,	EAnimState.LeftFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -180, -135, -180)

			PlayerSetup.AddRunShot(character,	'RIGHT_RUN_SHOT_0',		'CAT_run_shot_0',		false,	EAnimState.RightFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  -45,   45,    0)
			PlayerSetup.AddRunShot(character,	'RIGHT_RUN_SHOT_CC90',	'CAT_run_shot_CC90',	false,	EAnimState.RightFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,   45,  135,   90)
			PlayerSetup.AddRunShot(character,	'RIGHT_RUN_SHOT_CW90',	'CAT_run_shot_CW90',	false,	EAnimState.RightFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -135,  -45,  -90)
			PlayerSetup.AddRunShot(character,	'RIGHT_RUN_SHOT_CC180',	'CAT_run_shot_CC180',	false,	EAnimState.RightFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  135,  180,  180)
			PlayerSetup.AddRunShot(character,	'RIGHT_RUN_SHOT_CW180',	'CAT_run_shot_CC180',	false,	EAnimState.RightFootOnGround.Value,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -180, -135, -180)

			PlayerSetup.AddStandShot(character, 'STAND_SHOT_0',			'CAT_stand_shot_0',		false,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  -45,   45,    0)
			PlayerSetup.AddStandShot(character, 'STAND_SHOT_CC90',		'CAT_stand_shot_CC90',	false,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,   45,  135,   90)
			PlayerSetup.AddStandShot(character, 'STAND_SHOT_CW90',		'CAT_stand_shot_CC90',	true,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -135,  -45,  -90)
			PlayerSetup.AddStandShot(character, 'STAND_SHOT_CC180',		'CAT_stand_shot_CC180',	false,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT,  135,  180,  180)
			PlayerSetup.AddStandShot(character, 'STAND_SHOT_CW180',		'CAT_stand_shot_CC180',	true,	EMotionType.Shot, EBallImpulseType.Shot, EKickTypeInfo.EKickTypeInfo_FOR_SHOT, -180, -135, -180)
			
			do	-- RUN_KICK motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_SHOT'
				obj.Add('LEFT_RUN_SHOT_0')
				obj.Add('RIGHT_RUN_SHOT_0')
				obj.Add('LEFT_RUN_SHOT_CC90')
				obj.Add('RIGHT_RUN_SHOT_CC90')
				obj.Add('LEFT_RUN_SHOT_CW90')
				obj.Add('RIGHT_RUN_SHOT_CW90')
			end 
			do	-- RUN_KICK motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'RUN_IDLE_SHOT'
				obj.Add('LEFT_RUN_SHOT_CC180')
				obj.Add('RIGHT_RUN_SHOT_CC180')
				obj.Add('LEFT_RUN_SHOT_CW180')
				obj.Add('RIGHT_RUN_SHOT_CW180')
			end 
			do	-- 
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'STAND_SHOT'
				obj.Add('STAND_SHOT_0')
				obj.Add('STAND_SHOT_CC90')
				obj.Add('STAND_SHOT_CW90')
				obj.Add('STAND_SHOT_CC180')
				obj.Add('STAND_SHOT_CW180')
			end 
			
			PlayerSetup.DoubleKickUnitHelper(character, 'HELIX_SHOT_0', 'CAT_talent_BananaKick', EBallImpulseType.Shot, EMotionType.Talent, -180,180, EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT, 
											ClipManager.GetTurningAngle('CAT_talent_BananaKick', false),false, EPlayerTalent.BANANAKICK )
			PlayerSetup.DoubleKickUnitHelper(character, 'HELIX_SHOT_1', 'CAT_talent_HelixKick', EBallImpulseType.Shot, EMotionType.Talent, -180,180, EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT, 
											ClipManager.GetTurningAngle('CAT_talent_HelixKick', false),false, EPlayerTalent.BOUNCEKICK )
			PlayerSetup.DoubleKickUnitHelper(character, 'ALTAIR_SHOT', 'UBI_ALT_TALENT_death_shot', EBallImpulseType.Shot, EMotionType.Talent, -180,180, EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT, 
											ClipManager.GetTurningAngle('UBI_ALT_TALENT_death_shot', false),false, EPlayerTalent.UBIALTAIR )
			PlayerSetup.DoubleKickUnitHelper(character, 'BICYCLE_KICK', 'UBI_Hamm_TALENT_Bicycle', EBallImpulseType.Shot, EMotionType.Talent, -180,180, EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT, 
											ClipManager.GetTurningAngle('UBI_Hamm_TALENT_Bicycle', false),false, EPlayerTalent.UBIMIA )
			PlayerSetup.DoubleKickUnitHelper(character, 'RABBID_SHOT', 'UBI_RAB_TALENT_plunger_shot', EBallImpulseType.Shot, EMotionType.Talent, -180,180, EKickTypeInfo.EKickTypeInfo_FOR_POWER_SHOT, 
											ClipManager.GetTurningAngle('UBI_RAB_TALENT_plunger_shot', false),false, EPlayerTalent.UBIRABBID1 )

			do	-- RUN_KICK motion
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'TALENT_SHOT'
				obj.Add('HELIX_SHOT_0')
				obj.Add('HELIX_SHOT_1')
			end 
			
			PlayerSetup.AddPowerShots(character)
			PlayerSetup.AddPasses(character)
			PlayerSetup.AddHeadersAndVolleys(character, 'CAT', 'CAT', 'CAT', 'CAT', 'CAT', 'CAT')
			
			PlayerSetup.AddRunToStrafe(character,		'RUN_TO_STRAFE',		'CAT_run_to_strafe',			false,	180.0)
			PlayerSetup.AddIdleToStrafe(character,		'IDLE_TO_STRAFE',		'CAT_idle_to_strafe',			false,	180.0)
			PlayerSetup.AddIdleToStrafe(character,		'IDLE_TO_BALL_STRAFE',	'GK_standing_to_walk_wBALL',	true,	180.0)
			PlayerSetup.AddStrafe(character,			'STRAFE',				'Cat_strafe',					false,	true,	cat.maxStrafeRate)
			PlayerSetup.AddStrafe(character,			'BALL_STRAFE',			'GK_walk_wBALL',				true,	true,	cat.maxStrafeRate)
			PlayerSetup.AddStrafeToRun(character,		'STRAFE_TO_RUN',		'CAT_strafe_to_run',			false,	cat.maxStrafeRate, PlayerSetup.MinSpeed)
			PlayerSetup.AddStrafeToIdle(character,		'STRAFE_TO_IDLE',		'CAT_strafe_to_idle',			false)
			PlayerSetup.AddStrafeToIdle(character,		'STRAFE_TO_BALL_IDLE',	'GK_walk_to_standing_wBALL',	true)
			PlayerSetup.AddStrafeInterrupt(character,	'STRAFE_INTERRUPT')
			
			PlayerSetup.AddSaves(character, 'R_gk')
			PlayerSetup.AddTackles(character, 'CAT', 'CAT')
			PlayerSetup.AddTackleReactions(character, 'CAT', 'CAT', 'CAT', 'CAT', 'CAT')
			
			local jostleList = {'Cat', 'Hippo', 'Deer', 'Wolf', 'Pig', 'Rabbid'}
			PlayerSetup.AddJostleMotions(character, jostleList, 'CAT_CAT_',
											'DER_CATjostleCycle_A_D_DER_0', 
											'DER_CATjostleCycle_A_D_CAT_1', 
											'DER_CAT_EXIT_DER_Awin',
											'DER_CAT_EXIT_DER_Aloss', 
											'DER_CAT_EXIT_CAT_Dwin',
											'DER_CAT_EXIT_CAT_Dloss',
											'DER_CAT_EXIT_DER_A_falls',
											'DER_CAT_EXIT_CAT_D_falls') 
											
			
			jostleList = {'Gorilla'}
			PlayerSetup.AddJostleMotions(character, jostleList, 'CAT_GOR_',
											'CAT_GORjostleCycleA_D_CAT_0', 
											'GOR_CATjostleCycleA_D_CAT_1', 
											'CAT_GOR_EXIT_CAT_Awin', 
											'CAT_GOR_EXIT_CAT_Aloss', 
											'GOR_CAT_EXIT_CAT_Dwin', 
											'GOR_CATjostleExitA_Dloss_CAT_1',
											'CAT_GOR_EXIT_CAT_A_falls',
											'DER_CAT_EXIT_CAT_D_falls') 
			
			
			do			
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'JOSTLE_CYCLE'
				obj.Switchable = false
				obj.Add('CAT_CAT_JOSTLE_CYCLE')
				obj.Add('CAT_GOR_JOSTLE_CYCLE')
			end
			
			do			
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'JOSTLE_WIN'
				obj.Switchable = false
				obj.Add('CAT_CAT_JOSTLE_WIN')
				obj.Add('CAT_GOR_JOSTLE_WIN')
			end
			
			do			
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'JOSTLE_LOSE_TOSTUMBLE'
				obj.Switchable = false
				obj.Add('CAT_CAT_JOSTLE_LOSE_TOSTUMBLE')
				obj.Add('CAT_GOR_JOSTLE_LOSE_TOSTUMBLE')
			end
		
			do			
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'JOSTLE_LOSE_TOCONFUSED'
				obj.Switchable = false
				obj.Add('CAT_CAT_JOSTLE_LOSE_TOCONFUSED')
				obj.Add('CAT_GOR_JOSTLE_LOSE_TOCONFUSED')
			end
			
			jostleList = {'Cat', 'Hippo', 'Deer', 'Wolf', 'Gorilla', 'Pig', 'Rabbid'}
			PlayerSetup.AddJostleHeaderMotions(character, jostleList, 'CAT_', 'CAT_CAT_', 'CAT_', 'CAT_')
			
			do 
				local obj = CompositeMotion(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
					
				obj.Name = 'JOSTLEHEADER'
				obj.Switchable = false
				obj.Add('CAT_JOSTLEHEADER')
			end
			
			
			PlayerSetup.AddStunMotions(character)
			PlayerSetup.AddStumbleMotions(character, 'CAT')
			PlayerSetup.AddConfusedMotions(character, 'CAT')
			PlayerSetup.AddDodge(character, 'CAT')
			PlayerSetup.AddDodgeReaction(character, 'CAT')
			PlayerSetup.AddGenericMotions(character, 'CAT', 'GK', nil, nil)
			PlayerSetup.AddTalentMotions(character)
			
			PlayerSetup.AddThrow(character, 'GK_throw_0', 'LEFT_BALL_THROW', true)
			PlayerSetup.AddThrow(character, 'GK_throw_0', 'RIGHT_BALL_THROW', false)
			PlayerSetup.AddThrow(character, 'GK_side_throw_0', 'LEFT_SIDE_BALL_THROW', true)
			PlayerSetup.AddThrow(character, 'GK_side_throw_0', 'RIGHT_SIDE_BALL_THROW', false)
			PlayerSetup.AddThrowAway(character, 'GK_throw_Lside', 'LEFT_BALL_THROW_AWAY' , false,   0, 180 )
			PlayerSetup.AddThrowAway(character, 'GK_throw_Rside', 'RIGHT_BALL_THROW_AWAY', false,-180,   0 )
			PlayerSetup.AddThrows(character)
			
			do	-- StateControl Motion
				local obj = AdaptState(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
				obj.Name = 'StateControl'
				obj.StateScript = 'Player'
				obj.InitialState = 'Idle'
			end 
			do	-- MotionList Motion
			 	local obj = MotionList(PlayerSetup.HeapIndex)
				ptr = AutoInstance()
				ptr.Set(obj)
				character.Motions.IncreaseAdd(PlayerSetup.HeapIndex.Value, ptr)
				
			 	obj.Name = 'Root'
			 	obj.Add('LocomotionParameters')
			 	obj.Add('StateControl')
			 	obj.Add('PhysicsMessenger')
			 	obj.Add('MovementFacingDirection')
			 	obj.Add('EventBroadcaster')
				obj.Add('FaceHandsSelector')
			end 
		end
		character.DAGRoot = 'Root'
		character.Initialize()
	end
end


#ifndef  _CAMERAGAMEPLAY_H_
# define _CAMERAGAMEPLAY_H_

# ifndef _CAMERA_H
#  include "presentation/camera/camera.h"
# endif
# ifndef _CAMERACURVE_H
#  include "presentation/camera/cameracurve.h"
# endif

# ifndef __COLLECTIONS_GENERIC__LIST_H
#  include <collections/list.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class CameraGamePlay : public Camera
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraGamePlay(const CAMERA_TYPE_e);
			/* virtual */ ~CameraGamePlay(void);

			// Public members
			const Tracking*								AddAxisTracking(void);
			PRESENTATION_INLINE void					SetPostTrackingOffset( TRACKING_OFFSETTYPE_e, Axiom::Math::Vector3 );
			PRESENTATION_INLINE const int				GetNbAxisTrackings(void);

			const Tracking*								AddTracking(void);
			PRESENTATION_INLINE void					SetPostAxisTrackingOffset( TRACKING_OFFSETTYPE_e, Axiom::Math::Vector3 );
			PRESENTATION_INLINE const int				GetNbTrackings(void);

			void										SetTrackingActive(bool);
			PRESENTATION_INLINE const bool				IsTrackingActive(void);

			PRESENTATION_INLINE FlexibleShape*			GetBinding(void);
			PRESENTATION_INLINE Volume*					GetBodyBoundaries(void);
			PRESENTATION_INLINE Shape*					GetTargetBoundaries(void);
			PRESENTATION_INLINE Shape*					GetAxisBoundaries(void);

			FloatComponent*								GetBindingWidthComponent(void);
			FloatComponent*								GetBindingHeightComponent(void);

			Tracking*									GetTracking(int);
			Tracking*									GetAxisTracking(int);

			// Public virtual functions
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentBodyPosition(void) const;
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentTargetPosition(void) const;
			/* virtual */ const float					GetCurrentZoom(void) const;
			/* virtual */ const float					GetCurrentRoll(void) const;
			/* virtual */ const Framing&				GetCurrentFraming(void) const;
			/* virtual */ const Orientation				GetOrientation(void);
			/* virtual */ Point*						GetBodyPoint(void);
			/* virtual */ Point*						GetTargetPoint(void);
			/* virtual */ FloatComponent*				GetZoomComponent(void);
			/* virtual */ FloatComponent*				GetRollComponent(void);
			/* virtual */ Framing*						GetFraming(void);
			
			/* virtual */ void							CopyData(Camera*);

			/* virtual */ void							Reset(bool);
			/* virtual */ int							UpdateEffects(float);
			/* virtual */ void							Draw(const PresentationInput&,PresentationOutput*, const Orientation&, const unsigned int channel);

		protected:

			// Protected variable members
			Point														m_InitialBody;
			Point														m_InitialTarget;
			FloatComponent												m_InitialZoom;
			FloatComponent												m_InitialRoll;

			Point														m_Body;
			Point														m_Target;
			FloatComponent												m_Zoom;
			FloatComponent												m_Roll;

			Volume														m_InitialBodyBoundaries;
			Shape														m_InitialTargetBoundaries;
			Shape														m_InitialAxisBoundaries;
			FlexibleShape												m_InitialBinding;

			Volume														m_BodyBoundaries;
			Shape														m_TargetBoundaries;
			Shape														m_AxisBoundaries;
			FlexibleShape												m_Binding;

			Framing														m_Framing;

			bool														m_TrackingActive;

			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Tracking> >	m_Trackings;
			TRACKING_TYPE_e												m_TrackingType;
			Axiom::Math::Vector3										m_PostTrackingOffset;
			TRACKING_OFFSETTYPE_e										m_PostTrackingOffsetType;
			Axiom::Math::Vector3										m_TrackingDebugPosition;

			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Tracking> >	m_AxisTrackings;		
			TRACKING_TYPE_e												m_AxisTrackingType;
			Axiom::Math::Vector3										m_PostAxisTrackingOffset;
			TRACKING_OFFSETTYPE_e										m_PostAxisTrackingOffsetType;
			Axiom::Math::Vector3										m_AxisTrackingDebugPosition;
			Axiom::Math::Vector3										m_AxisTrackingInBoundariesDebugPosition;

		};

		class CameraGamePlayTargetRelative : public CameraGamePlay
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();
		
			// Constructor & virtual destructor
			CameraGamePlayTargetRelative(void);
			CameraGamePlayTargetRelative(const CAMERA_TYPE_e);
			/* virtual */ ~CameraGamePlayTargetRelative(void);

			// Public methods
			CumulativeFloatComponent*		GetPitchComponent(void);
			CumulativeFloatComponent*		GetHeadingComponent(void);
			CumulativeFloatComponent*		GetDistanceComponent(void);

			// Public virtual functions
			/* virtual */ void				CopyData(Camera*);

			/* virtual */ void				Reset(bool);
			/* virtual */ int				Update(float,const PresentationInput&);

		protected:

			PRESENTATION_INLINE const float	GetTrackingMultiplePointsIncHeading(void);
			PRESENTATION_INLINE const float	GetTrackingMultiplePointsIncDistance(void);

		private:
		
			// Friendship declaration
			friend class Tracking;				// To access the private GetHeadingComponent method

			// Private variable members
			CumulativeFloatComponent	m_InitialPitch;
			CumulativeFloatComponent	m_InitialHeading;
			CumulativeFloatComponent	m_InitialDistance;

			CumulativeFloatComponent	m_Pitch;
			CumulativeFloatComponent	m_Heading;
			CumulativeFloatComponent	m_Distance;

			bool						m_UsePitchAsHeight;

			float						m_MultipleTrackingIncHeading;
			float						m_MultipleTrackingIncDistance;

		};

		class CameraGamePlayTargetRelativeController : public CameraGamePlay
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();
		
			// Constructor & virtual destructor
			CameraGamePlayTargetRelativeController(void);
			CameraGamePlayTargetRelativeController(const CAMERA_TYPE_e);
			/* virtual */ ~CameraGamePlayTargetRelativeController(void);

			// Public functions
			FloatComponent*	GetSecondaryPitchComponent(void);
			FloatComponent*	GetSecondaryHeadingComponent(void);
			FloatComponent*	GetSecondaryDistanceComponent(void);

			// Public virtual functions
			/* virtual */ void					CopyData(Camera*);

			/* virtual */ void					Reset(bool);
			/* virtual */ int					Update(float,const PresentationInput&);

		private:
		
			// Private variable members
			float			m_CurrentTime;

			Curve			m_PrimaryPitch;
			Iterator		m_PrimaryPitchIterator;
			Curve			m_PrimaryHeading;
			Iterator		m_PrimaryHeadingIterator;
			Curve			m_PrimaryDistance;
			Iterator		m_PrimaryDistanceIterator;

			FloatComponent	m_InitialSecondaryPitch;
			FloatComponent	m_InitialSecondaryHeading;
			FloatComponent	m_InitialSecondaryDistance;

			FloatComponent	m_SecondaryPitch;
			FloatComponent	m_SecondaryHeading;
			FloatComponent	m_SecondaryDistance;

			bool			m_UsePitchAsHeight;

		};

		class AdditionalControls
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			AdditionalControls(void);
			virtual ~AdditionalControls(void);

			// Public functions
			FloatComponent*	GetControlledPitchComponent(void);
			FloatComponent*	GetControlledHeadingComponent(void);

			void			UpdateControls(const Axiom::Math::Vector2&);
			void			UpdateControls(const float,const float);

			const float		GetCurrentControlledHeading(void) const;
			const float		GetCurrentControlledPitch(void) const;

			void			CopyData(AdditionalControls*);

			void			Reset(void);
			void			Update(float,bool);

		protected:

			// Protected data members
			FloatComponent	m_ControlledPitch;
			FloatComponent	m_ControlledHeading;

			float			m_ControlledPitchAngle;
			float			m_ControlledHeadingAngle;

		private:

			// Friendship declaration
			friend class CameraGamePlayControlledTargetRelative;				// For reflection purposes
			friend class CameraGamePlayControlledTargetRelativeController;	// For reflection purposes

			// Private data members
			FloatComponent				m_InitialControlledPitch;
			FloatComponent				m_InitialControlledHeading;

		};

		class CameraGamePlayControlledTargetRelative : public CameraGamePlayTargetRelative, public AdditionalControls
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraGamePlayControlledTargetRelative(void);
			/* virtual */~CameraGamePlayControlledTargetRelative(void);

			// Public virtual functions
			/* virtual */ void					CopyData(Camera*);

			/* virtual */ void					Reset(bool);
			/* virtual */ int					Update(float,const PresentationInput&);

		};

		class CameraGamePlayControlledTargetRelativeController : public CameraGamePlayTargetRelativeController, public AdditionalControls
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraGamePlayControlledTargetRelativeController(void);
			/* virtual */~CameraGamePlayControlledTargetRelativeController(void);

			// Public virtual functions
			/* virtual */ void					CopyData(Camera*);

			/* virtual */ void					Reset(bool);
			/* virtual */ int					Update(float,const PresentationInput&);

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/source/cameragameplay.inl"
# endif

	}
}

#endif


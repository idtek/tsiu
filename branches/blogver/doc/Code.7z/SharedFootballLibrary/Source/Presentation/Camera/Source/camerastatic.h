
#ifndef  _CAMERASTATIC_H_
# define _CAMERASTATIC_H_

# ifndef _CAMERA_H_
#  include "presentation/camera/camera.h"
# endif

namespace SharedSoccer
{
	class ReplayData;

	namespace Presentation
	{
		class Orientation;

		class CameraStatic : public Camera
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();
		
			// Constructor & virtual destructor
			CameraStatic(void);
			/* virtual */ ~CameraStatic(void);

			// Public functions
			void										UpdatePositions(const float);

			// Public virtual functions
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentBodyPosition(void) const;
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentTargetPosition(void) const;
			/* virtual */ const float					GetCurrentZoom(void) const;
			/* virtual */ const float					GetCurrentRoll(void) const;
			/* virtual */ const Framing&				GetCurrentFraming(void) const;
			/* virtual */ const Orientation				GetOrientation(void);
			/* virtual */ Point*						GetBodyPoint(void);
			/* virtual */ Point*						GetTargetPoint(void);
			/* virtual */ FloatComponent*				GetZoomComponent(void);
			/* virtual */ FloatComponent*				GetRollComponent(void);
			/* virtual */ Framing*						GetFraming(void);

			/* virtual */ void							CopyData(Camera*);
			
			/* virtual */ void							Reset(bool);
			/* virtual */ int							Update(float,const PresentationInput&);
			/* virtual */ int							UpdateEffects(float);
			/* virtual */ void							Draw(const PresentationInput&,PresentationOutput*,const Orientation&, const unsigned int channel);
			
		private:
		
			// Private variable members
			Volume			m_InitialTargetBoundaries;
			Volume			m_InitialBodyBoundaries;
			Point			m_InitialBody;
			Point			m_InitialTarget;
			FloatComponent	m_InitialZoom;
			FloatComponent	m_InitialRoll;

			Volume			m_TargetBoundaries;
			Volume			m_BodyBoundaries;
			Point			m_Body;
			Point			m_Target;
			FloatComponent	m_Zoom;
			FloatComponent	m_Roll;

			Framing			m_Framing;

		};
	}
}

#endif

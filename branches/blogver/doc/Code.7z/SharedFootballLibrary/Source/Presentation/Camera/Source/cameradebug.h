
#ifndef  _CAMERADEBUG_H_
# define _CAMERADEBUG_H_

# ifndef _CAMERA_H_
#  include "presentation/camera/camera.h"
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class CameraDebug : public Camera
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraDebug(const CAMERA_TYPE_e);
			/* virtual */ ~CameraDebug(void);
			
			// Public virtual functions
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentBodyPosition(void) const;
			/* virtual */ const float					GetCurrentZoom(void) const;
			/* virtual */ const float					GetCurrentRoll(void) const;
			/* virtual */ Point*						GetBodyPoint(void);
			/* virtual */ FloatComponent*				GetZoomComponent(void);
			/* virtual */ FloatComponent*				GetRollComponent(void);

			/* virtual */ void							Draw(const PresentationInput&,PresentationOutput*,const Orientation&, const unsigned int channel);

			// Virtual functions proper to debug cameras
			virtual int									UpdateDebug(Camera*,float,const PresentationInput&) = 0;
			virtual void								DrawDebug(Camera*,const PresentationInput&,PresentationOutput*,const Orientation&, const unsigned int channel);

		protected:

			// Protected member variable
			Point				m_Body;
			FloatComponent		m_Zoom;

		};

		class CameraDebugControlled : public CameraDebug
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraDebugControlled(void);
			/* virtual */ ~CameraDebugControlled(void);
			
			// Public functions
			const float									GetPitch(void) const;	
			const float									GetHeading(void) const;
			void 										UpdateOrientation(const Axiom::Math::Vector2&);
			void										UpdatePosition(const Axiom::Math::Vector3&);
			void 										UpdateZoom(const float);

			// Public virtual functions
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentTargetPosition(void) const;
			/* virtual */ const Framing&				GetCurrentFraming(void) const;
			/* virtual */ const Orientation				GetOrientation(void);
			/* virtual */ Point*						GetTargetPoint(void);
			/* virtual */ Framing*						GetFraming(void);
			
			/* virtual */ void							CopyData(Camera*);
			
			/* virtual */ void							Reset(bool);
			/* virtual */ int							Update(float,const PresentationInput&);

			/* virtual */ int							UpdateDebug(Camera*,float,const PresentationInput&);

		private:

			// Private member variable
			float			m_Pitch;
			float			m_Heading;

			float			m_IncZoom;
			float			m_IncPosition;
			float			m_IncOrientation;

		};

		class CameraDebugFar : public CameraDebug
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraDebugFar(void);
			/* virtual */ ~CameraDebugFar(void);
			
			// Public virtual functions
			/* virtual */ const Axiom::Math::Vector3&	GetCurrentTargetPosition(void) const;
			/* virtual */ const Framing&				GetCurrentFraming(void) const;
			/* virtual */ const Orientation				GetOrientation(void);
			/* virtual */ Point*						GetTargetPoint(void);
			/* virtual */ Framing*						GetFraming(void);
			
			/* virtual */ void							CopyData(Camera*);
			
			/* virtual */ void							Reset(bool);
			/* virtual */ int							Update(float,const PresentationInput&);

			/* virtual */ int							UpdateDebug(Camera*,float,const PresentationInput&);

		private:

			// Private member variable
			Point			m_Target;

			float			m_AdditionalDistance;
			float			m_AdditionalZoom;

		};
	}
}

#endif


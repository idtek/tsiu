
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef _CAMERADEBUG_H_
# include "presentation/camera/source/cameradebug.h"
#endif
#ifndef _CAMERAEFFECT_HANDHELD_H_
# include "presentation/camera/source/cameraeffect_handheld.h"
#endif
#ifndef _CAMERAEFFECT_SHAKE_H_
# include "presentation/camera/source/cameraeffect_shake.h"
#endif

#ifndef _MATRIX4_H
# include <math/matrix4.h>
#endif
#ifndef _SCRIPT_H_
# include <reflection/script.h>
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/cameramanager.inl"
#endif

// Static member
CameraManager* CameraManager::m_pInstance = NULL;

// Reflection declaration
AP_TYPE(CameraManager)
	// Property Reflections
	AP_FIELD("Cameras",				m_Cameras,					"Camera node list")
	// Function Reflections
	AP_NAMED_COMMAND("DeleteCamera",	DeleteCamera_Reflection,	"Remove Selected Camera")
	AP_NAMED_COMMAND("AddCamera",		AddCamera_Reflection,		"Add a Camera")
	AP_NAMED_COMMAND("IsCameraActive",	IsCameraActive_Reflection,	"Is the named camera currently part of a visible viewport")
	AP_PROXY("Camera")
AP_TYPE_END()

// Camera manager
// --------------------------------------------------------------------------------------------------------------------------------------

// Private methods
void CameraManager::RemoveViewportPtr(Viewport *pViewport)
{
	PRESENTATION_ASSERT( pViewport != NULL, "Camera Error: NULL pointer passed!\n" );

	m_Viewports.Remove( pViewport );
}

void CameraManager::RemoveCameraPtr(Camera* pCamera)
{
	PRESENTATION_ASSERT( pCamera != NULL, "Camera Error: NULL pointer passed!\n" );

	unsigned int i;
	for (i=0;i<m_Cameras.Count();i++)
	{
		if (m_Cameras[i].pVal()==pCamera)
		{
			m_Cameras.RemoveAt(i);
			break;
		}
	}
}

// Constructors & destructors
CameraManager::CameraManager() :
	m_Viewports(),
	m_pUpdateViewport(NULL),
	m_Cameras(),
	m_Effects(),
	m_CameraTracker()
{
	m_Effects.Resize(Axiom::Memory::PRESENTATION_HEAP, k_NbActiveEffectsMax);
}

CameraManager::~CameraManager(void)
{
	m_Viewports.Clear();
	m_Cameras.Clear();
}

// Singleton Stuff
/* static */ CameraManager *CameraManager::Init(Axiom::Memory::HeapId iHeapID)
{
	PRESENTATION_ASSERT(m_pInstance == NULL, "Camera Error: Init should only be called once!\n");
	if(m_pInstance == NULL)
	{
		m_pInstance = PRESENTATION_NEW( iHeapID, CameraManager());
		PRESENTATION_ASSERT(m_pInstance != NULL, "Camera Error: Can't allocate memory!\n");

		// Reference things that otherwise wont be compiled and linked 
		CameraEffect_Handheld::TypeId();
		CameraEffect_Shake::TypeId();

		// Load camera manager from saved file
		AP::Reflection::Script::Register("CameraManager", AP::Reflection::Instance(m_pInstance), "Camera Manager");
	}
	return m_pInstance;
}

/* static */ void CameraManager::Destroy(void)
{
	PRESENTATION_DELETE(m_pInstance);
	m_pInstance = NULL;
}

// Public methods
const Viewport* CameraManager::AddViewport(void)
{
	PRESENTATION_ASSERT( m_Viewports.Count() < m_Viewports.Capacity(), "Camera Error: Can't add viewport!\n" );

	// Create the viewport
	Viewport *pViewport = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Viewport());
	PRESENTATION_ASSERT( pViewport != NULL, "Camera Error: Can't create viewport!\n" );

	// Add the viewport object
	m_Viewports.Add(pViewport);

	// Return the viewport object
	return pViewport;
}

void CameraManager::RemoveViewport(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	m_Viewports.Remove( FindViewportPtr( pName ) );
}

void CameraManager::RemoveViewport(const Axiom::CRC &rCRC)
{
	m_Viewports.Remove( FindViewportPtr( rCRC ) );
}

const Viewport& CameraManager::FindViewport(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	Viewport *pViewport = FindViewportPtr( Axiom::CRC( pName ) );
	PRESENTATION_ASSERT(pViewport != NULL, "Camera Error: Viewport can't be retrieved!\n");

	return *pViewport;
}

const Viewport& CameraManager::FindViewport(const Axiom::CRC &rCRC)
{
	Viewport *pViewport = FindViewportPtr(rCRC);
	PRESENTATION_ASSERT(pViewport != NULL, "Camera Error: Viewport can't be retrieved!\n");

	return *pViewport;
}

Viewport* CameraManager::FindViewportPtr(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	return FindViewportPtr( Axiom::CRC( pName ) );
}

Viewport* CameraManager::FindViewportPtr(const Axiom::CRC& rCRC)
{
	for(unsigned int i = 0; i < m_Viewports.Count(); ++i)
	{
		Viewport *pViewport = m_Viewports[i];
		PRESENTATION_ASSERT(pViewport != NULL, "Camera Error: Viewport can't be retrieved!\n");

		if( pViewport->GetID() == rCRC )
		{
			return pViewport;
		}
	}

	return NULL;
}

Axiom::SmartPtr<Camera> CameraManager::AddCamera(const CAMERA_TYPE_e eType)
{
	PRESENTATION_ASSERT( m_Cameras.Count() < m_Cameras.Capacity(), "Camera Error: Can't add camera!\n" );

	// Create the camera
	Axiom::SmartPtr<Camera> pCameraPtr = CreateCamera( eType );
	PRESENTATION_ASSERT( pCameraPtr.IsValid(), "Camera Error: Can't create camera!\n" );

	// Add the camera object
	m_Cameras.Add(pCameraPtr);

	// Return the camera object
	return pCameraPtr;
}

void CameraManager::RemoveCamera(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	RemoveCameraPtr( FindCameraPtr( pName ) );
}

void CameraManager::RemoveCamera(const Axiom::CRC &rCRC)
{
	RemoveCameraPtr( FindCameraPtr( rCRC ) );
}

const Camera& CameraManager::FindCamera(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	Camera *pCamera = FindCameraPtr( Axiom::CRC( pName ) );
	PRESENTATION_ASSERT(pCamera != NULL, "Camera Error: Camera can't be retrieved!\n");

	return *pCamera;
}

const Camera& CameraManager::FindCamera(const Axiom::CRC &rCRC)
{
	Camera *pCamera = FindCameraPtr(rCRC);
	PRESENTATION_ASSERT(pCamera != NULL, "Camera Error: Camera can't be retrieved!\n");

	return *pCamera;
}

Camera* CameraManager::FindCameraPtr(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	return FindCameraPtr( Axiom::CRC( pName ) );
}

Camera* CameraManager::FindCameraPtr(const Axiom::CRC& rCRC)
{
	for(unsigned int i = 0; i < m_Cameras.Count(); ++i)
	{
		Camera *pCamera = const_cast<Camera*>( m_Cameras[i].pVal() );
		PRESENTATION_ASSERT(pCamera != NULL, "Camera Error: Camera can't be retrieved!\n");

		if( Axiom::CRC(pCamera->GetID().AsChar()) == rCRC )
		{
			return pCamera;
		}
	}

	return NULL;
}

const Camera* CameraManager::GetCamera(const Axiom::CRC &rCRC)
{
	return FindCameraPtr(rCRC);
}

const Camera* CameraManager::GetCamera(const char *pName)
{
	return FindCameraPtr(pName);
}

void CameraManager::AddEffect(Axiom::SmartPtr<SharedSoccer::Presentation::CameraEffect> pEffect)
{
	if(!m_Effects.Contains(pEffect))
	{
		if(m_Effects.IsFull())
		{
			m_Effects.RemoveAt(0);
		}
		m_Effects.Add(pEffect);
	}
}

void CameraManager::ApplyEffectsToCameraData(Point& rPostEffectBody, Point& rPostEffectTarget)
{
	unsigned int i;
	for( i = 0 ; i < m_Effects.Count() ; ++i )
	{
		m_Effects[i]->Apply(rPostEffectBody, rPostEffectTarget);
	}
}

const Viewport* CameraManager::GetViewport(const Axiom::CRC &rCRC)
{
	return FindViewportPtr(rCRC);
}

const Viewport* CameraManager::GetViewport(const char *pName)
{
	return FindViewportPtr(pName);
}

void CameraManager::Reset(void)
{
	for(unsigned int i = 0; i < m_Viewports.Count(); i++)
	{
		m_Viewports[i]->Reset();
	}
	for(unsigned int i = 0; i < m_Cameras.Count(); i++)
	{
		m_Cameras[i]->Reset(true);
	}

	// Reset effects
	m_Effects.Clear();
}

void CameraManager::Update(float fDeltaTime, const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int debugChannel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed!\n" );
	unsigned int i = 0;

	// Update effects
	for( i = 0 ; i < m_Effects.Count() ; ++i )
	{
		if(!m_Effects[i]->Update(fDeltaTime))
		{
			m_Effects.RemoveAt(i);
			--i;
		}
	}

	// Update the right viewport
	for( i = 0 ; i < m_Viewports.Count() ; ++i )
	{
		m_pUpdateViewport = m_Viewports[i];
		if( m_pUpdateViewport->GetState() == VIEWPORT_STATE_e::VIEWPORT_STATE_VISIBLE )
		{
			m_pUpdateViewport->Update(fDeltaTime, rInput, pOutput, debugChannel);
		}		
	}

	m_CameraTracker.BuildTransformsFromCamera();

	m_pUpdateViewport = NULL;
}

// Reflection methods
bool CameraManager::AddViewport_Reflection(char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	Viewport *pViewport = const_cast<Viewport*>(reinterpret_cast<const Viewport*>(AddViewport()));
	PRESENTATION_ASSERT( pViewport != NULL, "Camera Error: Can't create viewport!\n" );

	// Set viewport name
	pViewport->SetName(pName);

	return true;
}

bool CameraManager::DeleteViewport_Reflection(int i)
{
	PRESENTATION_ASSERT( i >= 0 && static_cast<unsigned int>(i) < m_Viewports.Count(), "Camera Error: !\n" );
	m_Viewports.RemoveAt(i);
	return true;
}

bool CameraManager::AddCamera_Reflection(CAMERA_TYPE_e eType, char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Camera Error: NULL pointer passed!\n" );

	Axiom::SmartPtr<Camera> pCameraPtr = AddCamera( eType );

	// Set camera name
	Camera *pCamera = pCameraPtr.pVal();
	pCamera->SetName(pName);

	return true;
}

bool CameraManager::DeleteCamera_Reflection(int i)
{
	PRESENTATION_ASSERT( i >= 0 && static_cast<unsigned int>(i) < m_Cameras.Count(), "Camera Error: !\n" );
	m_Cameras.RemoveAt(i);
	return true;
}

bool CameraManager::IsCameraActive_Reflection(char* pCameraName)
{
	PRESENTATION_ASSERT( pCameraName != NULL, "Camera Error: NULL pointer passed!\n" );

	// Check for active viewports and look for their camera 
	for(unsigned int i = 0 ; i < m_Viewports.Count() ; ++i )
	{
		const Viewport * pViewport = m_Viewports[i];
		if( pViewport->GetState() == VIEWPORT_STATE_e::VIEWPORT_STATE_VISIBLE )
		{
			if( Axiom::StringCompareNoCase(pViewport->GetCamera()->GetID().AsChar(), pCameraName, Axiom::StringLength(pCameraName)) == 0)
			{
				return true;
			}
		}		
	}

	return false;
}

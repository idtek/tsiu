
#ifndef _CAMERACOMMAND_H_
# include "presentation/camera/cameracommand.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _CAMERAEFFECT_HANDHELD_H_
# include "presentation/camera/source/cameraeffect_handheld.h"
#endif
#ifndef _CAMERAEFFECT_SHAKE_H_
# include "presentation/camera/source/cameraeffect_shake.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/cameracommand.inl"
#endif

AP_TYPE(CameraCutCommand)
	AP_DEFAULT_CREATE()
	AP_FIELD("CameraID", m_CameraID, "The camera ID")
	AP_FIELD("Transition", m_Transition, "Transition")
	AP_FIELD("BlendTime", m_BlendTime, "Length of the blend between cameras.")
	AP_FIELD("CurveName", m_CurveID, "Name of the curve to use for the blend.")
	AP_ATTRIBUTE("DefaultValue", "{CameraID={Value=\"\"}, Transition=VIEWPORT_TRANSITION_CUT, CurveName={Value=\"Linear\"}}")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(VIEWPORT_TRANSITION_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()


// Camera Cut Command Key
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraCutCommand::CameraCutCommand(void) :
	m_Transition(VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUT),
	m_CameraID(),
	m_BlendTime(0.0f),
	m_CurveID()
{
}

CameraCutCommand::CameraCutCommand(const Axiom::ShortString& pCameraName, VIEWPORT_TRANSITION_e eTransition) :
	m_Transition(eTransition),
	m_CameraID(pCameraName),
	m_BlendTime(0.0f),
	m_CurveID()
{
}

CameraCutCommand::CameraCutCommand(const Axiom::ShortString& pCameraName, const CameraCutCommand& inputcommand) :
	m_Transition(inputcommand.m_Transition),
	m_CameraID(pCameraName),
	m_BlendTime(inputcommand.m_BlendTime),
	m_CurveID(inputcommand.m_CurveID)
{
}

CameraCutCommand::~CameraCutCommand(void)
{
}

Camera* CameraCutCommand::Execute(Camera *pCamera) const
{
	CameraManager *pInstance = CameraManager::GetInstance();
	PRESENTATION_ASSERT( pInstance != NULL, "Camera Error: Camera manager is not created!\n" );

	Camera *pNewCamera = pInstance->FindCameraPtr( Axiom::CRC(m_CameraID.AsChar()) );
	if( pNewCamera != NULL )
	{
		// Operate the transition
		switch( m_Transition )
		{
		case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUT:
			pNewCamera->Reset(true);
		case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUTSAME:
			pNewCamera->SetImmediateUpdate(true,true);
			break;
		case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_BLEND:
			pNewCamera->Reset(true);
			pNewCamera->SetImmediateUpdate(false,false);
			if( pCamera != NULL )
			{
				pNewCamera->CopyData( pCamera );
			}
			break;
		case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUTSAME_BASIC:
			pNewCamera->SetImmediateUpdate(true,false);
			break;
		case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_RESET:
			pNewCamera->Reset(false);
			pNewCamera->SetImmediateUpdate(false,false);
			break;
		default:
			break;
		}
		return pNewCamera;
	}

	// For cutsame keys, use current camera (if no other cam is specified in name)
	// Operate the transition
	switch( m_Transition )
	{
	case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUTSAME:
		pCamera->SetImmediateUpdate(true,true);
		return pCamera;
		break;
	case VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_CUTSAME_BASIC:
		pCamera->SetImmediateUpdate(true,false);
		return pCamera;
		break;
	default:
		break;
	}
	
	return NULL;
}

#pragma once

#ifndef  _CAMERACOMMAND_H_
# define _CAMERACOMMAND_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _CAMERAEFFECT_H_
#  include "presentation/camera/cameraeffect.h"
# endif
# ifndef __CORE_REFERENCED_H
#  include "core/referenced.h"
# endif

# ifndef _CLASSEDENUM_H
#  include <core/classedenum.h>
# endif


namespace SharedSoccer
{
	namespace Presentation
	{
		class Orientation;
		class Viewport;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 0


		CLASSEDENUM_REFLECTED(	VIEWPORT_TRANSITION_e, \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_CUT) \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_BLEND) \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_CUTSAME) \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_CUTSAME_BASIC) \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_RESET) \
						CLASSEDENUM_ITEM(VIEWPORT_TRANSITION_UNDEFINED) \
						,VIEWPORT_TRANSITION_CUT)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		class CameraCutCommand : public Axiom::Referenced
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			CameraCutCommand(void);	
			CameraCutCommand(const Axiom::ShortString&, VIEWPORT_TRANSITION_e);	
			CameraCutCommand(const Axiom::ShortString&, const CameraCutCommand&);	
			/* virtual */ ~CameraCutCommand(void);	

			// Public method
			Camera* Execute(Camera*) const;

			// Operators needed for reflection
			bool operator ==(const CameraCutCommand&) const;

			PRESENTATION_INLINE VIEWPORT_TRANSITION_e		GetTransition() const;
			PRESENTATION_INLINE const Axiom::ShortString&	GetCameraID() const;
			PRESENTATION_INLINE float						GetBlendTime() const;
			PRESENTATION_INLINE const Axiom::StripStringCRC&		GetCurveID() const;

		private:

			// Private member variables
			VIEWPORT_TRANSITION_e	m_Transition;
			Axiom::ShortString		m_CameraID;

			// These parameters are used to blend cuts
			float					m_BlendTime;
			Axiom::StripStringCRC		m_CurveID;
			
		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/cameracommand.inl"
# endif

	}
}

#endif

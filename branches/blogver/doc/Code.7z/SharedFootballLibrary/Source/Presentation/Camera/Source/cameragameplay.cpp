
#ifndef _CAMERAGAMEPLAY_H_
# include "presentation/camera/source/cameragameplay.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef _PRESENTATIONINPUT_H_
# include "presentation/presentationinput.h"
#endif
#ifndef _PRESENTATION_UTILS_H_
# include "presentation/presentation_utils.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif

#ifndef _APMATH_H
# include <math/apmath.h>
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/source/cameragameplay.inl"
#endif

// Reflection declaration
AP_TYPE(CameraGamePlay)
	AP_BASE_TYPE(Camera)
	AP_FIELD("Body", m_InitialBody, "Body")
	AP_FIELD("Target", m_InitialTarget, "Target")
	AP_FIELD("Zoom", m_InitialZoom, "Zoom")
	AP_FIELD("Roll", m_InitialRoll, "Roll")
	AP_FIELD("AxisBoundaries", m_InitialAxisBoundaries, "Axis boundaries")
	AP_FIELD("BodyBoundaries", m_InitialBodyBoundaries, "Body boundaries")
	AP_FIELD("TargetBoundaries", m_InitialTargetBoundaries, "Target boundaries")
	AP_FIELD("Binding", m_InitialBinding, "Target binding info")
	AP_FIELD("Framing", m_Framing, "Framing")
	AP_FIELD("Trackings", m_Trackings, "Trackings")
	AP_FIELD("TrackingType", m_TrackingType, "Tracking type")
	AP_FIELD("PostTrackingOffset", m_PostTrackingOffset, "Post-tracking offset")
	AP_FIELD("PostTrackingOffsetType", m_PostTrackingOffsetType, "Post-tracking offset type")
	AP_FIELD("Axis", m_AxisTrackings, "Axis")
	AP_FIELD("AxisType", m_AxisTrackingType, "Axis type")
	AP_FIELD("PostAxisTrackingOffset", m_PostAxisTrackingOffset, "Axis post-tracking offset")
	AP_FIELD("PostAxisTrackingOffsetType", m_PostAxisTrackingOffsetType, "Axis post-tracking offset")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraGamePlayTargetRelative)
	AP_BASE_TYPE(CameraGamePlay)
	AP_DEFAULT_CREATE()
	AP_FIELD("Pitch", m_InitialPitch, "Pitch data")
	AP_FIELD("Heading", m_InitialHeading, "Heading data")
	AP_FIELD("Distance", m_InitialDistance, "Distance data")
	AP_FIELD("UsePitchAsHeight", m_UsePitchAsHeight, "Use pitch as height")
	AP_FIELD("IncHeading", m_MultipleTrackingIncHeading, "Heading incremental (multiple tracking)")
	AP_FIELD("IncDistance", m_MultipleTrackingIncDistance, "Distance incremental (multiple tracking)")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraGamePlayTargetRelativeController)
	AP_BASE_TYPE(CameraGamePlay)
	AP_DEFAULT_CREATE()
	AP_FIELD("PrimaryPitch", m_PrimaryPitch, "Primary pitch data")
	AP_FIELD("PrimaryPitchIterator", m_PrimaryPitchIterator, "Primary pitch iterator")
	AP_FIELD("PrimaryHeading", m_PrimaryHeading, "Primary heading")
	AP_FIELD("PrimaryHeadingIterator", m_PrimaryHeadingIterator, "Primary heading iterator")
	AP_FIELD("PrimaryDistance", m_PrimaryDistance, "Primary distance")
	AP_FIELD("PrimaryDistanceIterator", m_PrimaryDistanceIterator, "Primary distance iterator")
	AP_FIELD("SecondaryPitch", m_InitialSecondaryPitch, "Secondary pitch data")
	AP_FIELD("SecondaryHeading", m_InitialSecondaryHeading, "Secondary heading data")
	AP_FIELD("SecondaryDistance", m_InitialSecondaryDistance, "Secondary distance data")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(AdditionalControls)
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraGamePlayControlledTargetRelative)
	AP_BASE_TYPE(CameraGamePlayTargetRelative)
	AP_DEFAULT_CREATE()
	AP_FIELD("ControlledPitch", m_InitialControlledPitch, "Controlled pitch data")
	AP_FIELD("ControlledHeading", m_InitialControlledHeading, "Controlled heading data")
	AP_FIELD("ControlledPitchAngle", m_ControlledPitchAngle, "Controlled pitch angle")
	AP_FIELD("ControlledHeadingAngle", m_ControlledHeadingAngle, "Controlled heading angle")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraGamePlayControlledTargetRelativeController)
	AP_BASE_TYPE(CameraGamePlayTargetRelativeController)
	AP_DEFAULT_CREATE()
	AP_FIELD("ControlledPitch", m_InitialControlledPitch, "Controlled pitch data")
	AP_FIELD("ControlledHeading", m_InitialControlledHeading, "Controlled heading data")
	AP_FIELD("ControlledPitchAngle", m_ControlledPitchAngle, "Controlled pitch angle")
	AP_FIELD("ControlledHeadingAngle", m_ControlledHeadingAngle, "Controlled heading angle")
	AP_PROXY("Camera")
AP_TYPE_END()

// Camera gameplay
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraGamePlay::CameraGamePlay(const CAMERA_TYPE_e eType) : Camera(eType),
	m_InitialBody(),
	m_InitialTarget(),
	m_InitialZoom(),
	m_InitialRoll(),
	m_Body(),
	m_Target(),
	m_Zoom(),
	m_Roll(),
	m_InitialBodyBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_InitialTargetBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_InitialAxisBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_InitialBinding(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_BodyBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_TargetBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_AxisBoundaries(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_Binding(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_Framing(),
	m_TrackingActive(true),
	m_Trackings(),
	m_TrackingType(TRACKING_TYPE_e::TRACKING_TYPE_SINGLEPOINT),
	m_PostTrackingOffset(),
	m_TrackingDebugPosition(),
	m_AxisTrackings(),
	m_AxisTrackingType(TRACKING_TYPE_e::TRACKING_TYPE_SINGLEPOINT),
	m_PostAxisTrackingOffset(),
	m_AxisTrackingDebugPosition(),
	m_AxisTrackingInBoundariesDebugPosition()
{
}

/* virtual */ CameraGamePlay::~CameraGamePlay(void)
{
	m_AxisTrackings.Clear();
	m_Trackings.Clear();
}

// Public methods
const Tracking* CameraGamePlay::AddAxisTracking(void)
{
	PRESENTATION_ASSERT( m_AxisTrackings.Count() < m_AxisTrackings.Capacity(), "Camera Error: Out of capacity!\n" );

	// Create the axis (tracking)
	Tracking *pTracking = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Tracking() );
	PRESENTATION_ASSERT( pTracking != NULL, "Camera Error: Can't create axis tracking\n" );

	m_AxisTrackings.Add(Axiom::SmartPtr<Tracking>(pTracking));

	return pTracking;
}

const Tracking* CameraGamePlay::AddTracking(void)
{
	PRESENTATION_ASSERT( m_Trackings.Count() < m_Trackings.Capacity(), "Camera Error: Out of capacity!\n" );

	// Create the tracking
	Tracking *pTracking = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Tracking() );
	PRESENTATION_ASSERT( pTracking != NULL, "Camera Error: Can't create tracking\n" );

	m_Trackings.Add(Axiom::SmartPtr<Tracking>(pTracking));

	return pTracking;
}

void CameraGamePlay::SetTrackingActive(bool bTrackingActive)
{
	m_TrackingActive = bTrackingActive;
}

FloatComponent* CameraGamePlay::GetBindingWidthComponent(void)
{
	return m_Binding.GetWidthComponent();
}

FloatComponent* CameraGamePlay::GetBindingHeightComponent(void)
{
	return m_Binding.GetHeightComponent();
}

Tracking* CameraGamePlay::GetTracking(int iIndex)
{
	PRESENTATION_ASSERT( CastToUInt(iIndex) < m_Trackings.Capacity(), "Camera Error: Index out of range!\n" );

	return m_Trackings[iIndex].pVal();
}

Tracking* CameraGamePlay::GetAxisTracking(int iIndex)
{
	PRESENTATION_ASSERT( CastToUInt(iIndex) < m_AxisTrackings.Capacity(), "Camera Error: Index out of range!\n" );

	return m_AxisTrackings[iIndex].pVal();
}

// Public virtual functions
/* virtual */ const Axiom::Math::Vector3& CameraGamePlay::GetCurrentBodyPosition(void) const
{
	return m_Body.GetCurrent();
}

/* virtual */ const Axiom::Math::Vector3& CameraGamePlay::GetCurrentTargetPosition(void) const
{
	return m_Target.GetCurrent();
}

/* virtual */ const float CameraGamePlay::GetCurrentRoll(void) const
{
	return m_Roll.GetCurrent();
}

/* virtual */ const float CameraGamePlay::GetCurrentZoom(void) const
{
	return m_Zoom.GetCurrent();
}

/* virtual */ const Framing& CameraGamePlay::GetCurrentFraming(void) const
{
	return m_Framing;
}

/* virtual */ const Orientation CameraGamePlay::GetOrientation(void)
{
	return Orientation( m_Framing.GetBodyPosition(), m_Framing.GetTargetPosition(), m_Roll.GetCurrent() );
}

/* virtual */ Point* CameraGamePlay::GetBodyPoint(void)
{
	return &m_Body;
}

/* virtual */ Point* CameraGamePlay::GetTargetPoint(void)
{
	return &m_Target;
}

/* virtual */ FloatComponent* CameraGamePlay::GetZoomComponent(void) 
{
	return &m_Zoom;
}

/* virtual */ FloatComponent* CameraGamePlay::GetRollComponent(void) 
{
	return &m_Roll;
}

/* virtual */ Framing* CameraGamePlay::GetFraming(void) 
{
	return &m_Framing;
}

/* virtual */ void CameraGamePlay::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	Point *pPoint = pSource->GetBodyPoint();
	m_Body.SetCurrent( pPoint->GetCurrent() );
	pPoint = pSource->GetTargetPoint();
	m_Target.SetCurrent( pPoint->GetCurrent() );
	FloatComponent *pComponent = pSource->GetZoomComponent();
	m_Zoom.SetCurrent( pComponent->GetCurrent() );
	pComponent = pSource->GetRollComponent();
	m_Roll.SetCurrent( pComponent->GetCurrent() );
}

/* virtual */ void CameraGamePlay::Reset(bool bFirstUpdate)
{
	m_Body = m_InitialBody;
	m_Target = m_InitialTarget;
	m_Zoom = m_InitialZoom;
	m_Roll = m_InitialRoll;
	m_BodyBoundaries = m_InitialBodyBoundaries;
	m_TargetBoundaries = m_InitialTargetBoundaries;
	m_AxisBoundaries = m_InitialAxisBoundaries;
	m_Binding = m_InitialBinding;

	Camera::Reset(bFirstUpdate);
}

/* virtual */ int CameraGamePlay::UpdateEffects(float fDeltaTime)
{
	int  iResult = CAMERA_UPDATEREPORT_NONE;

	// Save the body and target for effects
	if( m_FirstUpdate || m_ImmediateBasicUpdate )
	{
		m_PostEffectBody = m_Body;
		m_PostEffectTarget = m_Target;
	}
	else
	{
		m_PostEffectBody.Set( m_Body, false, true, true );
		m_PostEffectTarget.Set( m_Target, false, true, true );
	}

	// Update the camera
	if( m_ImmediateBasicUpdate )
	{
		if( m_Target.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_TARGET;
		}
		if( m_Body.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_BODY;
		}
		if( m_Zoom.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_ZOOM;
		}
		if( m_Roll.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_ROLL;
		}
	}
	else
	{
		if( m_Target.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_TARGET;
		}
		if( m_Body.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_BODY;
		}
		if( m_Zoom.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_ZOOM;
		}
		if( m_Roll.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_ROLL;
		}
	}

	// Apply the effects
	Camera::UpdateEffects(fDeltaTime);

	// Update the post effect points
	if( m_ImmediateBasicUpdate )
	{
		if( m_PostEffectTarget.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTTARGET;
		}
		if( m_PostEffectBody.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTBODY;
		}
	}
	else
	{
		if( m_PostEffectTarget.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTTARGET;
		}
		if( m_PostEffectBody.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTBODY;
		}
	}

	// Adjust the framing
	m_Framing.Adjust( m_PostEffectBody.GetCurrent(), m_PostEffectTarget.GetCurrent(), m_Zoom.GetCurrent(), m_Roll.GetCurrent() );

	return iResult;
}

/* virtual */ void CameraGamePlay::Draw(const PresentationInput &rInput, PresentationOutput *pOutput, const Orientation &rOrientation, const unsigned int channel)
{
#if CORE_USERDEBUG == CORE_YES
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed!\n" );

	// Draw the essentials
	pOutput->DrawPoint( m_Target, channel  );
	pOutput->DrawPoint( m_Body, channel  );

	// Draw the tracking objects
	unsigned int i;
	for( i = 0 ; i < m_Trackings.Count() ; ++i )
	{
		Tracking *pTracking = m_Trackings[i].pVal();
		if( pTracking->IsTracked() )
		{
			pOutput->DrawSphere( pTracking->GetOffsetTrackedPosition(), 0.05f, GRAPHICS_RGBAF(0.5f, 0.0f, 0.5f, 1.0f), channel  );

			Volume tVolume = rInput.GetEntityVolume( pTracking );
			pOutput->DrawVolume( tVolume, GRAPHICS_RGBAF(0.5f, 0.0f, 0.5f, 1.0f), channel  );		
		}
	}
	pOutput->DrawSphere( m_TrackingDebugPosition, 0.075f, GRAPHICS_RGBAF(1.0f, 0.0f, 1.0f, 1.0f), channel  );

	// Draw the axis tracking objects
	for( i = 0 ; i < m_AxisTrackings.Count() ; ++i )
	{
		Tracking *pTracking = m_AxisTrackings[i].pVal();
		if( pTracking->IsTracked() )
		{
			pOutput->DrawSphere( pTracking->GetOffsetTrackedPosition(), 0.05f, GRAPHICS_RGBAF(0.5f, 0.5f, 0.0f, 1.0f), channel  );

			Volume tVolume = rInput.GetEntityVolume( pTracking );
			pOutput->DrawVolume( tVolume, GRAPHICS_RGBAF(0.5f, 0.5f, 0.0f, 1.0f), channel  );		
		}
	}
	pOutput->DrawSphere( m_AxisTrackingDebugPosition, 0.075f, GRAPHICS_RGBAF(0.1f, 0.1f, 0.0f, 1.0f), channel  );

	// Draw the binding shapes
	pOutput->DrawShape( m_Binding, GRAPHICS_RGBAF(1.0f, 0.0f, 1.0f, 1.0f), channel , m_TrackingDebugPosition.Z() );
	pOutput->DrawVolume( m_BodyBoundaries, GRAPHICS_RGBAF(0.75f, 0.25f, 0.25f, 1.0f), channel  );
	pOutput->DrawShape( m_TargetBoundaries, GRAPHICS_RGBAF(0.25f, 0.75f, 0.25f, 1.0f), channel , m_Target.GetCurrent().Z() );
	pOutput->DrawShape( m_AxisBoundaries, GRAPHICS_RGBAF(0.25f, 0.25f, 0.75f, 1.0f), channel , m_Target.GetCurrent().Z() );
	pOutput->DrawSphere( m_AxisTrackingInBoundariesDebugPosition, 0.075f, GRAPHICS_RGBAF(0.25f, 0.25f, 0.75f, 1.0f), channel  );

	// Draw the essentials
	Camera::Draw( rInput, pOutput, rOrientation, channel );
#endif
}

// CameraGamePlayTargetRelative
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
CameraGamePlayTargetRelative::CameraGamePlayTargetRelative(void) : CameraGamePlay(CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE),
	m_InitialPitch(),
	m_InitialHeading(),
	m_InitialDistance(),
	m_Pitch(),
	m_Heading(),
	m_Distance(),
	m_UsePitchAsHeight(false),
	m_MultipleTrackingIncHeading(0.0f),
	m_MultipleTrackingIncDistance(0.0f)
{
	m_InitialDistance.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_InitialDistance.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

CameraGamePlayTargetRelative::CameraGamePlayTargetRelative(const CAMERA_TYPE_e eType) : CameraGamePlay(eType),
	m_InitialPitch(),
	m_InitialHeading(),
	m_InitialDistance(),
	m_Pitch(),
	m_Heading(),
	m_Distance(),
	m_MultipleTrackingIncHeading(0.0f),
	m_MultipleTrackingIncDistance(0.0f)
{
	m_InitialDistance.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_InitialDistance.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

/* virtual */ CameraGamePlayTargetRelative::~CameraGamePlayTargetRelative(void)
{
}

// Public methods
CumulativeFloatComponent* CameraGamePlayTargetRelative::GetPitchComponent(void)
{
	return &m_Pitch;
}

CumulativeFloatComponent* CameraGamePlayTargetRelative::GetHeadingComponent(void)
{
	return &m_Heading;
}

CumulativeFloatComponent* CameraGamePlayTargetRelative::GetDistanceComponent(void)
{
	return &m_Distance;
}

// Public virtual methods
/* virtual */ void CameraGamePlayTargetRelative::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	// Specifics
	switch( pSource->GetCameraType() )
	{
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE:
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED:
		{
			CameraGamePlayTargetRelative *pGamePlaySource = static_cast<CameraGamePlayTargetRelative*>(pSource);
			m_Pitch.SetCurrent( pGamePlaySource->m_Pitch.GetCurrent() );
			m_Heading.SetCurrent( pGamePlaySource->m_Heading.GetCurrent() );
			m_Distance.SetCurrent( pGamePlaySource->m_Distance.GetCurrent() );
		}
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER:
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED:
		// TODO: Implement this
		break;
	default:
		break;
	}

	// Call the base class
	CameraGamePlay::CopyData(pSource);
}

/* virtual */ void CameraGamePlayTargetRelative::Reset(bool bFirstUpdate)
{
	m_Pitch = m_InitialPitch;
	m_Heading = m_InitialHeading;
	m_Distance = m_InitialDistance;

	CameraGamePlay::Reset(bFirstUpdate);
}

/* virtual */ int CameraGamePlayTargetRelative::Update(float fDeltaTime, const PresentationInput &rInput)
{
	// Update trackings and dependencies
	if( m_TrackingActive )
	{
		// Target tracking
		TrackingResult tTrackingResult = Tracking::TrackEntities( m_Trackings, m_TrackingType, rInput, this );
		if( (tTrackingResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
		{
			// Save the position for drawing reasons
			m_TrackingDebugPosition = tTrackingResult.m_Position;

			// Orient the binding box
			m_Binding.Update( fDeltaTime );
			m_Binding.SetOrientation( m_Body.GetCurrent() );

			// Make sure the binding shape contains our tracked point
			Axiom::Math::Vector3 vPosition = tTrackingResult.m_Position;
			if( m_FirstUpdate || m_ImmediateInternalUpdate )
			{
				m_Binding.SetCenter( vPosition.X(), vPosition.Y() );
			}
			else
			{
				vPosition = m_Binding.Constrain( vPosition );
			}

			// Include the ones we would like in
			for( unsigned int i = 0 ; i < m_Trackings.Count() ; ++i )
			{
				Tracking *pResultTracking = m_Trackings[ i ].pVal();
				if( pResultTracking->IsTracked() && pResultTracking->IsForcedToBeIncluded() )
				{
					vPosition = m_Binding.Constrain( pResultTracking->GetOffsetTrackedPosition() );
				}
			}

			// Apply the post-tracking offset
			switch( m_PostTrackingOffsetType )
			{
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_ENTITYRELATIVE:			
				vPosition += ( m_PostTrackingOffset * tTrackingResult.m_Facing );
				break;
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_STATIC:
				vPosition += m_PostTrackingOffset;
				break;
			default:										
				break;
			}

			// Restrain the target to which ever flat constraints
			vPosition = m_TargetBoundaries.Restrain( vPosition );

			// Overwrite the target desired
			m_Target.SetDesired( vPosition );

			// Adjust the primary distance and heading
			if( m_TrackingType == TRACKING_TYPE_e::TRACKING_TYPE_MULTIPLEPOINTS )
			{
				m_Distance.AddPrimaryDesired( tTrackingResult.m_ProposedDeltaDistance );
				m_Heading.AddPrimaryDesired( tTrackingResult.m_ProposedDeltaHeading );
			}
		}

		// Axis tracking (Body)
		TrackingResult tAxisResult = Tracking::TrackEntities( m_AxisTrackings, m_AxisTrackingType, rInput, this );
		if( (tAxisResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
		{
			// Save the position for drawing reasons
			m_AxisTrackingDebugPosition = tAxisResult.m_Position;

			// Apply the post-axistracking offset
			Axiom::Math::Vector3 vPosition = tAxisResult.m_Position;
			switch( m_PostAxisTrackingOffsetType )
			{
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_ENTITYRELATIVE:			
				vPosition += ( m_PostAxisTrackingOffset * tAxisResult.m_Facing );
				break;
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_STATIC:
				vPosition += m_PostAxisTrackingOffset;
				break;
			default:										
				break;
			}

			// Restrain the axis to which ever flat constraints
			vPosition = m_AxisBoundaries.Restrain( vPosition );

			// Save the position for drawing reasons
			m_AxisTrackingInBoundariesDebugPosition = vPosition;

			// Get the right orientation out of the axis
			vPosition -= m_Target.GetDesired();
			float fMagnitude = vPosition.Magnitude();
			if( fMagnitude > 0.0f )
			{
				vPosition /= fMagnitude;
			}
			float fHeading = NormalizeAngle( atan2f( vPosition.Y(), vPosition.X() ) + Axiom::Math::PI_DIV_TWO );

			// Overwrite the secondary desired
			m_Heading.SetSecondaryDesired( fHeading );
		}

		// Special case for immediate update
		if( m_ImmediateInternalUpdate )
		{
			m_Pitch.UpdateImmediate();
			m_Heading.UpdateImmediate();
			m_Distance.UpdateImmediate();
		}
		else
		{
			m_Pitch.Update(fDeltaTime,!m_UsePitchAsHeight);
			m_Heading.Update(fDeltaTime);
			m_Distance.Update(fDeltaTime,false);
		}

		// Get the values
		float fPitch = m_Pitch.GetCurrent();
		float fHeading = m_Heading.GetCurrent();
		float fDistance = m_Distance.GetCurrent();

		// Special case for controlled gameplay cameras
		if( m_Type == CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED )
		{
			AdditionalControls *pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelative*>(this) );
			fPitch += pControl->GetCurrentControlledPitch();
			fHeading += pControl->GetCurrentControlledHeading();
		}

		// Compute the body position
		Axiom::Math::Vector3 vPosition( 0.0f, 1.0f, 0.0f );
		if( !m_UsePitchAsHeight )
		{
			vPosition = RotateX( vPosition, fPitch );
		}
		vPosition = RotateZ( vPosition, fHeading  );

		// Push it and offset it to the target positions
		vPosition *= fDistance;
		if( m_UsePitchAsHeight )
		{
			vPosition.Z( fPitch );
		}
		vPosition += m_Target.GetDesired();

		// Restrain the target to which ever flat constraints
		vPosition = m_BodyBoundaries.Restrain( vPosition );

		// Overwrite the target desired
		m_Body.SetDesired( vPosition );
	}
	else
	{
		// Special case for immediate update
		if( m_ImmediateInternalUpdate )
		{
			m_Pitch.UpdateImmediate();
			m_Heading.UpdateImmediate();
			m_Distance.UpdateImmediate();
		}
		else
		{
			m_Pitch.Update(fDeltaTime,!m_UsePitchAsHeight);
			m_Heading.Update(fDeltaTime);
			m_Distance.Update(fDeltaTime,false);
		}
	}

	// Update the points, effects and framing
	int iResult = CameraGamePlay::UpdateEffects(fDeltaTime);

	// Kill the updates
	m_ImmediateBasicUpdate = false;
	m_ImmediateInternalUpdate = false;
	m_FirstUpdate = false;

	return iResult;
}

// CameraGamePlayTargetRelativeController
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
CameraGamePlayTargetRelativeController::CameraGamePlayTargetRelativeController(void) : CameraGamePlay(CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER),
	m_PrimaryPitch(),
	m_PrimaryPitchIterator(),
	m_PrimaryHeading(),
	m_PrimaryHeadingIterator(),
	m_PrimaryDistance(),
	m_PrimaryDistanceIterator(),
	m_InitialSecondaryPitch(),
	m_InitialSecondaryHeading(),
	m_InitialSecondaryDistance(),
	m_SecondaryPitch(),
	m_SecondaryHeading(),
	m_SecondaryDistance()
{
	m_InitialSecondaryDistance.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_InitialSecondaryDistance.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

CameraGamePlayTargetRelativeController::CameraGamePlayTargetRelativeController(const CAMERA_TYPE_e eType) : CameraGamePlay(eType),
	m_PrimaryPitch(),
	m_PrimaryPitchIterator(),
	m_PrimaryHeading(),
	m_PrimaryHeadingIterator(),
	m_PrimaryDistance(),
	m_PrimaryDistanceIterator(),
	m_InitialSecondaryPitch(),
	m_InitialSecondaryHeading(),
	m_InitialSecondaryDistance(),
	m_SecondaryPitch(),
	m_SecondaryHeading(),
	m_SecondaryDistance()
{
	m_InitialSecondaryDistance.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_InitialSecondaryDistance.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

/* virtual */ CameraGamePlayTargetRelativeController::~CameraGamePlayTargetRelativeController(void)
{
}

// Public methods
FloatComponent* CameraGamePlayTargetRelativeController::GetSecondaryPitchComponent(void)
{
	return &m_SecondaryPitch;
}

FloatComponent* CameraGamePlayTargetRelativeController::GetSecondaryHeadingComponent(void)
{
	return &m_SecondaryHeading;
}

FloatComponent* CameraGamePlayTargetRelativeController::GetSecondaryDistanceComponent(void)
{
	return &m_SecondaryDistance;
}

// Public virtual methods
/* virtual */ void CameraGamePlayTargetRelativeController::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	// Specifics
	switch( pSource->GetCameraType() )
	{
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE:
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED:
		// TODO: Implement this
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER:
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED:
		{
			CameraGamePlayTargetRelativeController *pGamePlaySource = static_cast<CameraGamePlayTargetRelativeController*>(pSource);
			m_SecondaryPitch.SetCurrent( pGamePlaySource->m_SecondaryPitch.GetCurrent() );
			m_SecondaryHeading.SetCurrent( pGamePlaySource->m_SecondaryHeading.GetCurrent() );
			m_SecondaryDistance.SetCurrent( pGamePlaySource->m_SecondaryDistance.GetCurrent() );
		}
		break;
	default:
		break;
	}

	// Call the base class
	CameraGamePlay::CopyData(pSource);
}

/* virtual */ void CameraGamePlayTargetRelativeController::Reset(bool bFirstUpdate)
{
	m_CurrentTime = 0.0f;

	m_SecondaryPitch = m_InitialSecondaryPitch;
	m_SecondaryHeading = m_InitialSecondaryHeading;
	m_SecondaryDistance = m_InitialSecondaryDistance;

	CameraGamePlay::Reset(bFirstUpdate);
}

/* virtual */ int CameraGamePlayTargetRelativeController::Update(float fDeltaTime, const PresentationInput &rInput)
{
	// Iterate time
	m_CurrentTime += fDeltaTime;

	// Update trackings and dependencies
	if( m_TrackingActive )
	{
		// Target tracking
		TrackingResult tTrackingResult = Tracking::TrackEntities( m_Trackings, m_TrackingType, rInput, this );
		if( (tTrackingResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
		{
			// Save the position for drawing reasons
			m_TrackingDebugPosition = tTrackingResult.m_Position;

			// Orient the binding box
			m_Binding.Update( fDeltaTime );
			m_Binding.SetOrientation( m_Body.GetCurrent() );

			// Make sure the binding shape contains our tracked point
			Axiom::Math::Vector3 vPosition = tTrackingResult.m_Position;
			if( m_FirstUpdate || m_ImmediateInternalUpdate )
			{
				m_Binding.SetCenter( vPosition.X(), vPosition.Y() );
			}
			else
			{
				vPosition = m_Binding.Constrain( vPosition );
			}

			// Include the ones we would like in
			for( unsigned int i = 0 ; i < m_Trackings.Count() ; ++i )
			{
				Tracking *pResultTracking = m_Trackings[ i ].pVal();
				if( pResultTracking->IsTracked() && pResultTracking->IsForcedToBeIncluded() )
				{
					vPosition = m_Binding.Constrain( pResultTracking->GetTrackedPosition() );
				}
			}

			// Apply the post-tracking offset
			switch( m_PostTrackingOffsetType )
			{
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_ENTITYRELATIVE:			
				vPosition += ( m_PostTrackingOffset * tTrackingResult.m_Facing );
				break;
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_STATIC:
				vPosition += m_PostTrackingOffset;
				break;
			default:										
				break;
			}

			// Restrain the target to which ever flat constraints
			vPosition = m_TargetBoundaries.Restrain( vPosition );

			// Overwrite the target desired
			m_Target.SetDesired( vPosition );
		}

		// Axis tracking (Body)
		TrackingResult tAxisResult = Tracking::TrackEntities( m_AxisTrackings, m_AxisTrackingType, rInput, this );
		if( (tAxisResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
		{
			// Save the position for drawing reasons
			m_AxisTrackingDebugPosition = tAxisResult.m_Position;

			// Apply the post-axistracking offset
			Axiom::Math::Vector3 vPosition = tAxisResult.m_Position;
			switch( m_PostAxisTrackingOffsetType )
			{
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_ENTITYRELATIVE:			
				vPosition += ( m_PostAxisTrackingOffset * tAxisResult.m_Facing );
				break;
			case TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_STATIC:
				vPosition += m_PostAxisTrackingOffset;
				break;
			default:										
				break;
			}

			// Restrain the axis to which ever flat constraints
			vPosition = m_AxisBoundaries.Restrain( vPosition );

			// Save the position for drawing reasons
			m_AxisTrackingInBoundariesDebugPosition = vPosition;

			// Get the right orientation out of the axis
			vPosition -= m_Target.GetDesired();
			float fMagnitude = vPosition.Magnitude();
			if( fMagnitude > 0.0f )
			{
				vPosition /= fMagnitude;
			}
			float fHeading = NormalizeAngle( atan2f( vPosition.Y(), vPosition.X() ) + Axiom::Math::PI_DIV_TWO );

			// Overwrite the secondary desired
			m_SecondaryHeading.SetDesired( fHeading );
		}

		// Special case for immediate update
		if( m_ImmediateInternalUpdate )
		{
			m_SecondaryPitch.UpdateImmediate();
			m_SecondaryHeading.UpdateImmediate();
			m_SecondaryDistance.UpdateImmediate();
		}
		else
		{
			m_SecondaryPitch.Update(fDeltaTime,!m_UsePitchAsHeight);
			m_SecondaryHeading.Update(fDeltaTime);
			m_SecondaryDistance.Update(fDeltaTime,false);
		}

		// Get the values
		float fPitch = 0.0f, fHeading = 0.0f, fDistance = 0.0f;
		m_PrimaryHeading.Evaluate( &fHeading, m_PrimaryHeadingIterator.Evaluate( m_CurrentTime ), 1.0f );
		fHeading += m_SecondaryHeading.GetCurrent();
		m_PrimaryPitch.Evaluate( &fPitch, m_PrimaryPitchIterator.Evaluate( m_CurrentTime ), 1.0f );
		fPitch += m_SecondaryPitch.GetCurrent();
		m_PrimaryDistance.Evaluate( &fDistance, m_PrimaryDistanceIterator.Evaluate( m_CurrentTime ), 1.0f );
		fDistance += m_SecondaryDistance.GetCurrent();

		// Special case for controlled gameplay cameras
		if( m_Type == CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED )
		{
			AdditionalControls *pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelativeController*>(this) );
			fPitch += pControl->GetCurrentControlledPitch();
			fHeading += pControl->GetCurrentControlledHeading();
		}

		// Compute the body position
		tAxisResult.m_Facing = Axiom::Math::Vector3( 0.0f, 1.0f, 0.0f );
		if( !m_UsePitchAsHeight )
		{
			tAxisResult.m_Facing = RotateX( tAxisResult.m_Facing, fPitch );
		}
		tAxisResult.m_Facing = RotateZ( tAxisResult.m_Facing, fHeading );

		// Push it and offset it to the target position
		tAxisResult.m_Facing *= fDistance;
		if( m_UsePitchAsHeight )
		{
			tAxisResult.m_Facing.Z( fPitch );
		}
		tAxisResult.m_Facing += m_Target.GetDesired();

		// Restrain the target to which ever flat constraints
		tAxisResult.m_Facing = m_BodyBoundaries.Restrain( tAxisResult.m_Facing );

		// Straight to the current position
		m_Body.SetCurrent( tAxisResult.m_Facing );
	}
	else
	{
		// Special case for immediate update
		if( m_ImmediateInternalUpdate )
		{
			m_SecondaryPitch.UpdateImmediate();
			m_SecondaryHeading.UpdateImmediate();
			m_SecondaryDistance.UpdateImmediate();
		}
		else
		{
			m_SecondaryPitch.Update(fDeltaTime,!m_UsePitchAsHeight);
			m_SecondaryHeading.Update(fDeltaTime);
			m_SecondaryDistance.Update(fDeltaTime,false);
		}
	}

	// Update the points, effects and framing
	int iResult = CameraGamePlay::UpdateEffects(fDeltaTime);

	// Reset immediate updates
	m_ImmediateBasicUpdate = false;
	m_ImmediateInternalUpdate = false;
	m_FirstUpdate = true;

	return iResult;
}

// AdditionalControls
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor and virtual destructor
AdditionalControls::AdditionalControls(void) :
	m_ControlledPitch(),
	m_ControlledHeading(),
	m_ControlledPitchAngle( 0.0f ),
	m_ControlledHeadingAngle( 0.0f ),
	m_InitialControlledPitch(),
	m_InitialControlledHeading()
{
}

/* virtual */AdditionalControls::~AdditionalControls(void)
{
}

// Public methods
FloatComponent* AdditionalControls::GetControlledPitchComponent(void)
{
	return &m_ControlledPitch;
}

FloatComponent* AdditionalControls::GetControlledHeadingComponent(void)
{
	return &m_ControlledHeading;
}

void AdditionalControls::UpdateControls(const float fPitch, const float fHeading)
{
	float fPitchFactor = ( fPitch > 1.0f ? 1.0f : ( fPitch < -1.0f ? -1.0f : fPitch ) );
	m_ControlledPitch.SetDesired( m_ControlledPitchAngle * fPitchFactor );
	float fHeadingFactor = ( fHeading > 1.0f ? 1.0f : ( fHeading < -1.0f ? -1.0f : fHeading ) );
	m_ControlledHeading.SetDesired( m_ControlledHeadingAngle * fHeadingFactor );
}

void AdditionalControls::UpdateControls(const Axiom::Math::Vector2 &rOrientation)
{
	UpdateControls( rOrientation.X(), rOrientation.Y() );
}

const float AdditionalControls::GetCurrentControlledPitch(void) const
{
	return m_ControlledPitch.GetCurrent();
}

const float AdditionalControls::GetCurrentControlledHeading(void) const
{
	return m_ControlledHeading.GetCurrent();
}

void AdditionalControls::Reset(void)
{
	m_ControlledPitch = m_InitialControlledPitch;
	m_ControlledHeading = m_InitialControlledHeading;
}

void AdditionalControls::CopyData(AdditionalControls *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );
	
	m_ControlledPitch.SetCurrent( pSource->GetCurrentControlledPitch() );
	m_ControlledHeading.SetCurrent( pSource->GetCurrentControlledHeading() );
}

void AdditionalControls::Update(float fDeltaTime, bool bImmediateUpdate)
{
	// Special case for immediate update
	if( bImmediateUpdate )
	{
		m_ControlledPitch.UpdateImmediate();
		m_ControlledHeading.UpdateImmediate();
	}
	else
	{
		m_ControlledPitch.Update(fDeltaTime);
		m_ControlledHeading.Update(fDeltaTime);
	}
}

// CameraGamePlayControlledTargetRelative
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraGamePlayControlledTargetRelative::CameraGamePlayControlledTargetRelative(void) : CameraGamePlayTargetRelative( CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED ), AdditionalControls()
{
}

/* virtual */CameraGamePlayControlledTargetRelative::~CameraGamePlayControlledTargetRelative(void)
{
}

// Public virtual functions
/* virtual */void CameraGamePlayControlledTargetRelative::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	AdditionalControls *pControl = NULL;
	switch( pSource->GetCameraType() )
	{
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED:
		pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelative*>(pSource) );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED:
		pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelativeController*>(pSource) );
		break;
	default:
		break;
	}
	if( pControl != NULL )
	{
		AdditionalControls::CopyData( pControl );
	}

	// Call base class
	CameraGamePlayTargetRelative::CopyData(pSource);
}

/* virtual */void CameraGamePlayControlledTargetRelative::Reset(bool bFirstUpdate)
{
	AdditionalControls::Reset();
	CameraGamePlayTargetRelative::Reset(bFirstUpdate);
}

/* virtual */int CameraGamePlayControlledTargetRelative::Update(float fDeltaTime, const PresentationInput &rInput)
{
	AdditionalControls::Update( fDeltaTime, (m_FirstUpdate | m_ImmediateInternalUpdate) );

	// Call base class
	return CameraGamePlayTargetRelative::Update(fDeltaTime, rInput);
}

// CameraGamePlayControlledTargetRelativeController
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraGamePlayControlledTargetRelativeController::CameraGamePlayControlledTargetRelativeController(void) : CameraGamePlayTargetRelativeController( CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED ), AdditionalControls()
{
}

/* virtual */CameraGamePlayControlledTargetRelativeController::~CameraGamePlayControlledTargetRelativeController(void)
{
}

// Public virtual functions
/* virtual */void CameraGamePlayControlledTargetRelativeController::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	AdditionalControls *pControl = NULL;
	switch( pSource->GetCameraType() )
	{
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED:
		pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelative*>(pSource) );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED:
		pControl = static_cast<AdditionalControls*>( static_cast<CameraGamePlayControlledTargetRelativeController*>(pSource) );
		break;
	default:
		break;
	}
	if( pControl != NULL )
	{
		AdditionalControls::CopyData( pControl );
	}

	// Call base class
	CameraGamePlayTargetRelativeController::CopyData(pSource);
}

/* virtual */void CameraGamePlayControlledTargetRelativeController::Reset(bool bFirstUpdate)
{
	AdditionalControls::Reset();
	CameraGamePlayTargetRelativeController::Reset(bFirstUpdate);
}

/* virtual */int CameraGamePlayControlledTargetRelativeController::Update(float fDeltaTime, const PresentationInput &rInput)
{
	AdditionalControls::Update( fDeltaTime, (m_FirstUpdate | m_ImmediateInternalUpdate) );

	// Call base class
	return CameraGamePlayTargetRelativeController::Update(fDeltaTime, rInput);
}

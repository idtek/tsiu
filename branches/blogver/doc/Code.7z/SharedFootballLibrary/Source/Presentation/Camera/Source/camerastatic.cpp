
#ifndef _CAMERASTATIC_H_
# include "presentation/camera/source/camerastatic.h"
#endif
#ifndef _PRESENTATION_UTILS_H
# include "presentation/presentation_utils.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef _PRESENTATIONINPUT_H
# include "presentation/presentationinput.h"
#endif
#ifndef _PRESENTATIONOUTPUT_H
# include "presentation/presentationoutput.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

AP_TYPE(CameraStatic)
	AP_BASE_TYPE(Camera)
	AP_DEFAULT_CREATE()
	AP_FIELD("Body", m_InitialBody, "Body")
	AP_FIELD("Target", m_InitialTarget, "Target")
	AP_FIELD("Zoom", m_InitialZoom, "Zoom")
	AP_FIELD("Roll", m_InitialRoll, "Roll")
	AP_FIELD("Framing", m_Framing, "Framing")
	AP_FIELD("BodyBoundaries", m_InitialBodyBoundaries, "Body boundaries")
	AP_FIELD("TargetBoundaries", m_InitialTargetBoundaries, "Target boundaries")
	AP_PROXY("Camera")
AP_TYPE_END()

// Constructor & virtual destructor
CameraStatic::CameraStatic(void) : 
	Camera(CAMERA_TYPE_e::CAMERA_TYPE_STATIC),
	m_InitialTargetBoundaries(VOLUME_TYPE_e::VOLUME_TYPE_BOX),
	m_InitialBodyBoundaries(VOLUME_TYPE_e::VOLUME_TYPE_BOX),
	m_InitialBody(),
	m_InitialTarget(),
	m_InitialZoom(),
	m_InitialRoll(),
	m_TargetBoundaries(VOLUME_TYPE_e::VOLUME_TYPE_BOX),
	m_BodyBoundaries(VOLUME_TYPE_e::VOLUME_TYPE_BOX),
	m_Body(),
	m_Target(),
	m_Zoom(),
	m_Roll(),
	m_Framing()
{
}

/* virtual */ CameraStatic::~CameraStatic(void)
{
}

// Public functions
void CameraStatic::UpdatePositions(const float fMovement)
{
	if( Axiom::Math::FloatAbs( fMovement ) < Axiom::Math::EPSILON )
	{
		m_Body.Immobilize();
		m_Target.Immobilize();
	}
	else
	{
		Axiom::Math::Vector3 vMovement = Axiom::Math::Vector3( 0.0f, 0.0f, fMovement );
		m_Body.AddDesired(vMovement);
		m_Target.AddDesired(vMovement);
	}
}

// Public virtual functions
/* virtual */ const Axiom::Math::Vector3& CameraStatic::GetCurrentBodyPosition(void) const
{
	return m_Body.GetCurrent();
}

/* virtual */ const Axiom::Math::Vector3& CameraStatic::GetCurrentTargetPosition(void) const
{
	return m_Target.GetCurrent();
}

/* virtual */ const float CameraStatic::GetCurrentRoll(void) const
{
	return 0.0f;
}

/* virtual */ const float CameraStatic::GetCurrentZoom(void) const
{
	return m_Zoom.GetCurrent();
}

/* virtual */ const Framing& CameraStatic::GetCurrentFraming(void) const
{
	return m_Framing;
}

/* virtual */ const Orientation CameraStatic::GetOrientation(void)
{
	return Orientation( m_Framing.GetBodyPosition(), m_Framing.GetTargetPosition(), m_Roll.GetCurrent() );
}

/* virtual */ Point* CameraStatic::GetBodyPoint(void) 
{
	return &m_Body;
}

/* virtual */ Point* CameraStatic::GetTargetPoint(void) 
{
	return &m_Target;
}

/* virtual */ FloatComponent* CameraStatic::GetZoomComponent(void)
{
	return &m_Zoom;
}

/* virtual */ FloatComponent* CameraStatic::GetRollComponent(void)
{
	return &m_Roll;
}

/* virtual */ Framing* CameraStatic::GetFraming(void) 
{
	return &m_Framing;
}

/* virtual */ void CameraStatic::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	m_Body.SetCurrent( pSource->GetCurrentBodyPosition() );
	m_Target.SetCurrent( pSource->GetCurrentTargetPosition() );
	m_Zoom.SetCurrent( pSource->GetCurrentZoom() );
	m_Roll.SetCurrent( pSource->GetCurrentRoll() );
}

/* virtual */ void CameraStatic::Reset(bool bFirstUpdate)
{
	m_BodyBoundaries = m_InitialBodyBoundaries;
	m_TargetBoundaries = m_InitialTargetBoundaries;
	m_Body = m_InitialBody;
	m_Target = m_InitialTarget;
	m_Zoom = m_InitialZoom;
	m_Roll = m_InitialRoll;

	Camera::Reset(bFirstUpdate);
}

/* virtual */ int CameraStatic::UpdateEffects(float fDeltaTime)
{
	int  iResult = CAMERA_UPDATEREPORT_NONE;

	// Save the body and target for effects
	if( m_FirstUpdate || m_ImmediateBasicUpdate )
	{
		m_PostEffectBody = m_Body;
		m_PostEffectTarget = m_Target;
	}
	else
	{
		m_PostEffectBody.Set( m_Body, false, true, true );
		m_PostEffectTarget.Set( m_Target, false, true, true );
	}

	// Update the camera
	if( m_ImmediateBasicUpdate )
	{
/*
		if( m_Target.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_TARGET;
		}
		if( m_Body.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_BODY;
		}
		if( m_Zoom.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_ZOOM;
		}
		if( m_Roll.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_ROLL;
		}
*/
	}
	else
	{
		if( m_Target.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_TARGET;
		}
		if( m_Body.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_BODY;
		}
		if( m_Zoom.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_ZOOM;
		}
		if( m_Roll.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_ROLL;
		}
	}

	// Apply the effects
	Camera::UpdateEffects(fDeltaTime);

	// Update the post effect points
	if( m_ImmediateBasicUpdate )
	{
/*
		if( m_PostEffectTarget.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTTARGET;
		}
		if( m_PostEffectBody.UpdateImmediate() )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTBODY;
		}
*/
	}
	else
	{
		if( m_PostEffectTarget.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTTARGET;
		}
		if( m_PostEffectBody.Update(fDeltaTime) )
		{
			iResult |= CAMERA_UPDATEREPORT_POSTEFFECTBODY;
		}
	}

	// Adjust the framing
	m_Framing.Adjust( m_PostEffectBody.GetCurrent(), m_PostEffectTarget.GetCurrent(), m_Zoom.GetCurrent(), m_Roll.GetCurrent() );

	return iResult;
}

/* virtual */ int CameraStatic::Update(float fDeltaTime, const PresentationInput&)
{
	// Constraining the points
	Axiom::Math::Vector3 vDesiredPosition = m_TargetBoundaries.CameraRestrain( m_Target.GetDesired(), this, BOUNDARY_TYPE_TARGET );
	m_Target.SetDesired(vDesiredPosition);
	vDesiredPosition = m_BodyBoundaries.CameraRestrain( m_Body.GetDesired(), this, BOUNDARY_TYPE_BODY );
	m_Body.SetDesired(vDesiredPosition);

	// Update the points, effects and framing
	int iResult = UpdateEffects(fDeltaTime);

	// Restore immediate update
	m_ImmediateBasicUpdate = false;
	m_ImmediateInternalUpdate = false;
	m_FirstUpdate = false;

	return iResult;
}

/* virtual */ void CameraStatic::Draw(const PresentationInput &rInput,PresentationOutput *pOutput, const Orientation &rOrientation, const unsigned int channel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed!\n" );

	// Draw the points
	pOutput->DrawPoint( m_Target, channel );
	pOutput->DrawPoint( m_Body, channel  );

	// Draw the volumes
	pOutput->DrawVolume( m_BodyBoundaries, GRAPHICS_RGBAF(0.75f, 0.25f, 0.25f, 1.0f), channel  );
	pOutput->DrawVolume( m_TargetBoundaries, GRAPHICS_RGBAF(0.25f, 0.75f, 0.25f, 1.0f), channel  );

	// Draw the essentials
	Camera::Draw( rInput, pOutput, rOrientation, channel );
}

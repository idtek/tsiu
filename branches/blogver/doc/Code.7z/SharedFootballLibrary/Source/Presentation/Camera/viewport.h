#pragma once

#ifndef  _VIEWPORT_H_
# define _VIEWPORT_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef  _CAMERACOMMAND_H_
#  include "presentation/camera/cameracommand.h"
# endif
# ifndef _PRESENTATION_TRANSFORMATION_DATA_H_
#  include "presentation/Shared/presentationtransformationdata.h"
# endif

# ifndef _MATRIX4_H_
#  include <math/matrix4.h>
# endif
# ifndef _MATRIX44_H_
#  include <math/matrix44.h>
# endif
# ifndef _CRC_H
#  include <core/crc.h>
# endif
# ifndef _CORE_TIME_H
#  include <core/time.h>
# endif
# ifndef _CLASSEDENUM_H
#  include <core/classedenum.h>
# endif
# ifndef __CORE_ATOMIC_H
#  include <thread/atomic.h>
# endif
# ifndef _LOOKUP_CURVE_H
#  include <particles/curve.h>
# endif


namespace SharedSoccer
{
	namespace Presentation
	{
		class Camera;
		class CameraDebug;
		class PresentationInput;
		class PresentationOutput;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM_REFLECTED(	VIEWPORT_STATE_e, \
								CLASSEDENUM_ITEMWITHVALUE(VIEWPORT_STATE_INVALID, -1) \
								CLASSEDENUM_ITEM(VIEWPORT_STATE_INVISIBLE) \
								CLASSEDENUM_ITEM(VIEWPORT_STATE_VISIBLE) \
								CLASSEDENUM_ITEM(VIEWPORT_NBSTATES) \
								,VIEWPORT_STATE_INVALID)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS


		enum VIEWPORT_USAGE_e
		{
			VIEWPORT_USAGE_NONE = 0,

			VIEWPORT_USAGE_NORMAL,
			VIEWPORT_USAGE_DEBUG,

			VIEWPORT_NBUSAGES
		};

		const unsigned int	c_CAMERA_STACK_SIZE = 4;

		class Orientation : public Axiom::Math::Matrix4
		{
		public:

			// Constructor & destructor
			Orientation(void);
			Orientation(const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const float);
			Orientation(const Axiom::Math::Vector3&, const float, const float, const float);
			~Orientation(void);

			// Public members
			void 	Set(const Axiom::Math::Matrix4&);
			void	Set(const Axiom::Math::Matrix4&, const Axiom::Math::Vector3&, bool buildOriginInMatrix );
			void	Set(const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const float);
			void	Set(const Axiom::Math::Vector3&, const float, const float, const float);

			// Helpers
			const Axiom::Math::Vector3	GetUp(void) const;
			const Axiom::Math::Vector3	GetFront(void) const;
			const Axiom::Math::Vector3	GetSide(void) const;
			const Axiom::Math::Vector3	GetOrigin(void) const;
			static Orientation Interpolate(float fraction, const Orientation& lhs, const Orientation& rhs);
			
		private:
			
			// Private data member	
			Axiom::Math::Vector3	m_Origin;

		};

		class Projection : public Axiom::Math::Matrix44
		{
		public:

			// Constructor & destructor
			Projection(void);
			Projection(const float,const float,const float,const float);
			~Projection(void);

			// Public members
			void	Set(const float,const float,const float,const float);

		};

		class Pointer
		{
		public: 

			// Constructor & destructor
			Pointer(void);
			~Pointer(void);

			// Public methods
			PRESENTATION_INLINE const float	GetX(void) const;
			PRESENTATION_INLINE const float	GetY(void) const;
			PRESENTATION_INLINE void		SetX(float);
			PRESENTATION_INLINE void		SetY(float);

		private:

			float m_X;
			float m_Y;

		};

		class ViewportCameraData
		{
		public:

			ViewportCameraData();
			ViewportCameraData(const Orientation& orientation, const float fov);
			ViewportCameraData(const ViewportCameraData& rhs);

			ViewportCameraData& operator=(const ViewportCameraData& rhs);

			static ViewportCameraData Interpolate(float fraction, const ViewportCameraData& oldViewport, const ViewportCameraData& newViewport);

			Orientation			m_Orientation;
			float				m_FOV;

		};

		class Viewport
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Viewport(void);
			Viewport(const float,const float,const float,const float,const int,const int);
			virtual ~Viewport(void);

			// Public methods		
			void										SetName(const char*);
			PRESENTATION_INLINE const Axiom::CRC&		GetID(void) const;

			void										SetCameraCut(const CameraCutCommand&, const bool push);
			void										SetBakedCameraCut(	const Axiom::ShortString& rBakedCamName, 
																			const PresentationTransformationData& rTransformData,
																			const CameraCutCommand &rCommand,
																			const float time,
																			const float timeScale,
																			const float fov,
																			const bool useCurvedPitchCalc);
			void										PopCameraCut(const SharedSoccer::Presentation::CameraCutCommand& cameracutcommand);
			PRESENTATION_INLINE const Camera*			GetCamera() const;

			void										SetPointerValues( float, float );

			PRESENTATION_INLINE void					Set(const float fFOV, const float fAspectRatio, const float fNearPlane, const float fFarPlane, const int iWidth, const int iHeight);
			PRESENTATION_INLINE void					SetState(const VIEWPORT_STATE_e);
			PRESENTATION_INLINE const VIEWPORT_STATE_e	GetState(void) const;
			PRESENTATION_INLINE void					SetSize(const int,const int);
			PRESENTATION_INLINE const int				GetWidth(void) const;
			PRESENTATION_INLINE const int				GetHeight(void) const;
			PRESENTATION_INLINE const float				GetAspectRatio(void) const;
			PRESENTATION_INLINE const float				GetNearPlane(void) const;
			PRESENTATION_INLINE const float				GetFarPlane(void) const;

			const Orientation&							GetOrientation(void) const;
			const Projection&							GetProjection(void) const;

			// Debug methods
			void										SetDebugCamera(const char*,bool,bool bOverwrite=false,bool bCopyData=true);
			void										SetDebugCamera(const Axiom::CRC&,bool,bool bOverwrite=false,bool bCopyData=true);
			const CameraDebug*							GetDebugCamera(void) const;
			PRESENTATION_INLINE const bool				IsInDebugMode(void) const;
		
			// Update method
			void										Reset(void);
			void										Update(float, const PresentationInput&, PresentationOutput*, const unsigned int channel);

			// Operators needed for reflection
			const bool operator ==(const Viewport&) const;

		private:

			// Initialise blend from camera cut command
			void										InitialiseBlend(const CameraCutCommand& rCommand);

			class BakedCameraData
			{
			public:
				BakedCameraData():
					m_ID(),
					m_Transform(),
					m_Time(0.0f),
					m_TimeScale(30.0f),
					m_CurrentRotation(),
					m_CurrentPosition(),
					m_FOV(0.0),
					m_UseCurvedPitchCalc(true)
				{

				}

				BakedCameraData(const Axiom::ShortString& rID,
								const PresentationTransformationData& rTransform,
								const float time,
								const float timeScale,
								const float fov,
								const bool useCurvedPitchCalc):
						m_ID(rID),
						m_Transform(rTransform),
						m_Time(time),
						m_TimeScale(timeScale),
						m_CurrentRotation(),
						m_CurrentPosition(),
						m_FOV (fov),
						m_UseCurvedPitchCalc(useCurvedPitchCalc)
				{
					m_Transform.SetTransformNeedsToUpdate(true);
				}

				void Reset()
				{
					m_ID = 0;
					m_Time = 0.0f;
					m_Transform.SetTransformNeedsToUpdate(true);
					m_CurrentRotation = Axiom::Math::Quaternion();
					m_CurrentPosition = Axiom::Math::Vector3();
				}

				bool IsValid() const
				{
					return m_ID.GetHashID() != 0;
				}

				void UpdatePositionRotation( const PresentationInput &rInput );

				void UpdateTime(const float deltaTime)
				{
					m_Time += deltaTime;
				}

				const Axiom::Math::Quaternion& GetCurrentRotation()
				{
					return m_CurrentRotation;
				}

				const Axiom::Math::Vector3& GetCurrentPosition()
				{
					return m_CurrentPosition;
				}


				Axiom::ShortString					m_ID;
				PresentationTransformationData 		m_Transform;
				float								m_Time;
				float								m_TimeScale;
				float								m_FOV;
				bool								m_UseCurvedPitchCalc;

			private:
				Axiom::Math::Quaternion				m_CurrentRotation;
				Axiom::Math::Vector3				m_CurrentPosition;
			};

			// Private data
			Axiom::StripStringCRC	m_ID;

			Axiom::Math::Vector3	m_Pointer;
			Camera				*m_pCamera;

			BakedCameraData		m_BakedCameraData; // overrides m_pCamera when set

			Axiom::Collections::StaticList<CameraCutCommand, c_CAMERA_STACK_SIZE>
								m_CameraCommands; // Last element in list is current command

			CameraDebug			*m_pDebugCamera;
			bool				m_InDebugMode;
			bool				m_OverwriteInDebugMode;

			VIEWPORT_STATE_e	m_State;
			Projection			m_Projection;
			float				m_AspectRatio;
			float				m_NearPlane;
			float				m_FarPlane;
			int					m_Width;
			int					m_Height;

			ViewportCameraData	m_SourceViewportCameraData;
			ViewportCameraData	m_CurrentViewportCameraData;

			float				m_TargetBlendTime;
			float				m_CurrentBlendTime;
			const SharedSoccer::Particle::LookupCurve*  m_pBlendCurve;

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/viewport.inl"
# endif

	}
}

#endif

#pragma once

#ifndef  _CAMERAEFFECT_H_
# define _CAMERAEFFECT_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef __CORE_REFERENCED_H
#  include <core/referenced.h>
# endif


namespace SharedSoccer
{
	namespace Presentation
	{
		class Camera;
		class Point;


		class CameraEffect : public Axiom::Referenced
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			CameraEffect();
			virtual ~CameraEffect(void);

			// Public methods
			virtual void Init( float fDuration = -1.0f, float fMagnitudeMod = 1.0f ) = 0;
			virtual void Reset(void) = 0;
			virtual bool Update(float fDeltaTime) = 0;
			virtual void Apply(Point &pBody, Point &pTarget) = 0;
			
		private:

		};



		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/cameraeffect.inl"
# endif
	}
}

#endif

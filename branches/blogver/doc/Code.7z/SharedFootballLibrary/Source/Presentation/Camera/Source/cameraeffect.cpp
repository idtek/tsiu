
#ifndef  _CAMERAEFFECT_H_
# include "presentation/camera/cameraeffect.h"
#endif
#ifndef  _CAMERAEFFECT_SHAKE_H_
# include "presentation/camera/source/cameraeffect_shake.h"
#endif
#ifndef  _CAMERAEFFECT_HANDHELD_H_
# include "presentation/camera/source/cameraeffect_handheld.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/cameraeffect.inl"
#endif

// Reflection declarations
AP_TYPE(CameraEffect)
	AP_PROXY("Camera")
AP_TYPE_END()


// Camera effect
// --------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraEffect::CameraEffect()
{
}

/* virtual */ CameraEffect::~CameraEffect(void)
{
}


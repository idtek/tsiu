
#ifndef _CAMERASTATIC_H_
# include "presentation/camera/source/camerastatic.h"
#endif
#ifndef _CAMERAGAMEPLAY_H_
# include "presentation/camera/source/cameragameplay.h"
#endif
#ifndef _CAMERADEBUG_H_
# include "presentation/camera/source/cameradebug.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef _PRESENTATION_UTILS_H
# include "presentation/presentation_utils.h"
#endif
#ifndef _CAMERAEFFECT_HANDHELD_H_
# include "presentation/camera/source/cameraeffect_handheld.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/camera.inl"
#endif

// Reflection declaration
AP_TYPE(Camera)
	AP_FIELD("ID", m_ID, "ID")
	AP_FIELD("Type", m_Type, "Camera Type")
		AP_FIELD_ATTRIBUTE("ProxyAttribute", "[ReadOnly(true)]")
	// Function Reflections
	AP_NAMED_COMMAND("Reset", Reset_Reflection, "Reset")
	AP_ATTRIBUTE("PrimaryKey", "ID.Value")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CAMERA_TYPE_e)
	AP_ENUM()
	AP_PROXY("Camera")
AP_TYPE_END()

// Creator implementation
Axiom::SmartPtr<SharedSoccer::Presentation::Camera> SharedSoccer::Presentation::CreateCamera(const CAMERA_TYPE_e eType)
{
	Camera *pCamera = NULL;

	switch(eType)
	{
	case CAMERA_TYPE_e::CAMERA_TYPE_STATIC:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraStatic() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraGamePlayTargetRelative() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraGamePlayControlledTargetRelative() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraGamePlayTargetRelativeController() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraGamePlayControlledTargetRelativeController() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_CONTROLLED:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraDebugControlled() );
		break;
	case CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_FAR:
		pCamera = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, CameraDebugFar() );
		break;
	default:
		break;
	}

	return Axiom::SmartPtr<SharedSoccer::Presentation::Camera>(pCamera);
}

// Camera
// -------------------------------------------------------------------------------------------------------------------------

// Private methods for reflection
bool Camera::Reset_Reflection(void)
{
	// Reset the camera itself
	Reset(true);

	// Snap!
	SetImmediateUpdate(true,true);

	return true;
}

// Protected methods
void Camera::Draw(const PresentationInput&,PresentationOutput *pOutput, const Orientation &rOrientation, const unsigned int channel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed!\n" );

	Framing					tFraming = GetCurrentFraming();
	Axiom::Math::Vector3	vTargetPosition = tFraming.GetTargetPosition();
	Axiom::Math::Vector3	vBodyPosition = tFraming.GetBodyPosition();

	// Draw the orientation 
	pOutput->DrawLine(vTargetPosition, vTargetPosition + rOrientation.GetUp(), GRAPHICS_RGBAF(1.0f, 0.0f, 0.0f, 1.0f), channel);
	pOutput->DrawLine(vTargetPosition, vTargetPosition + rOrientation.GetSide(), GRAPHICS_RGBAF(0.0f, 1.0f, 0.0f, 1.0f), channel);
	pOutput->DrawLine(vTargetPosition, vTargetPosition + rOrientation.GetFront(), GRAPHICS_RGBAF(0.0f, 0.0f, 1.0f, 1.0f), channel);

	// Draw the framed camera body
	Axiom::Math::Vector3 vSide = rOrientation.GetSide();
	Axiom::Math::Vector3 vUp = rOrientation.GetUp();
	Axiom::Math::Vector3 vDepth = vBodyPosition - ( CAMERADEBUG_DRAWBODY_HALFDEPTH * rOrientation.GetFront() );

	Axiom::Math::Vector3 vTopLeft = vSide + vUp;
	vTopLeft.Normalize();
	vTopLeft *= CAMERADEBUG_DRAWBODY_HALFWIDTH;
	vTopLeft += vDepth;
	Axiom::Math::Vector3 vTopRight = vUp - vSide;
	vTopRight.Normalize();
	vTopRight *= CAMERADEBUG_DRAWBODY_HALFWIDTH;
	vTopRight += vDepth;
	Axiom::Math::Vector3 vBottomLeft = vSide - vUp;
	vBottomLeft.Normalize();
	vBottomLeft *= CAMERADEBUG_DRAWBODY_HALFWIDTH;
	vBottomLeft += vDepth;
	Axiom::Math::Vector3 vBottomRight = - vUp - vSide;
	vBottomRight.Normalize();
	vBottomRight *= CAMERADEBUG_DRAWBODY_HALFWIDTH;
	vBottomRight += vDepth;

	pOutput->DrawLine(vBodyPosition,GetCurrentBodyPosition(),GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);

	pOutput->DrawLine(vBodyPosition,vTopLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vBodyPosition,vTopRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vBodyPosition,vBottomLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vBodyPosition,vBottomRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);

	pOutput->DrawLine(vBottomLeft,vTopLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vTopLeft,vTopRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vTopRight,vBottomRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vBottomRight,vBottomLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);

	// Draw the frame
	Axiom::Math::Vector3	vOffset = vTargetPosition - vBodyPosition;
	float					fCoef = vOffset.Magnitude() * 2.0f * tanf( GetCurrentZoom() / 2.0f );

	vSide *= CAMERADEBUG_DRAWTARGET_WIDTH * fCoef;
	vUp *= CAMERADEBUG_DRAWTARGET_HEIGHT * fCoef;

	Axiom::Math::Vector3 vScreenTopLeft = vSide + vUp + vTargetPosition;
	Axiom::Math::Vector3 vScreenTopRight = vUp - vSide + vTargetPosition;
	Axiom::Math::Vector3 vScreenBottomLeft = vSide - vUp + vTargetPosition;
	Axiom::Math::Vector3 vScreenBottomRight = -vUp - vSide + vTargetPosition;

	pOutput->DrawLine(vTargetPosition,GetCurrentTargetPosition(),GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);

	pOutput->DrawLine(vScreenBottomLeft,vScreenTopLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vScreenTopLeft,vScreenTopRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vScreenTopRight,vScreenBottomRight,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);
	pOutput->DrawLine(vScreenBottomRight,vScreenBottomLeft,GRAPHICS_RGBAF(1.0f, 1.0f, 1.0f, 1.0f), channel);

	pOutput->DrawLine(vScreenTopLeft,vTopLeft,GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);
	pOutput->DrawLine(vScreenTopRight,vTopRight,GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);
	pOutput->DrawLine(vScreenBottomLeft,vBottomLeft,GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);
	pOutput->DrawLine(vScreenBottomRight,vBottomRight,GRAPHICS_RGBAF(0.5f, 0.5f, 0.5f, 1.0f), channel);
}

// Constructor & virtual destructor
Camera::Camera(const CAMERA_TYPE_e eType) :
	m_ID(),
	m_Type(eType),
	m_ImmediateBasicUpdate(false),
	m_ImmediateInternalUpdate(false),
	m_FirstUpdate(false),
	m_PostEffectBody(),
	m_PostEffectTarget()
{
}

/* virtual */ Camera::~Camera(void)
{
}

// Public methods
void Camera::SetName(const char *pName)
{
	m_ID.Set(pName);
}

// Virtual methods
/* virtual */ void Camera::SetImmediateUpdate(bool bImmediateBasicUpdate,bool bImmediateInternalUpdate)
{
	m_ImmediateBasicUpdate = bImmediateBasicUpdate;
	m_ImmediateInternalUpdate = bImmediateInternalUpdate;
}

/* virtual */ void Camera::Reset(bool bFirstUpdate)
{
	// First update
	m_FirstUpdate = bFirstUpdate;
}

/* virtual */ int Camera::UpdateEffects(float fDeltaTime)
{
	// Assumes that PostEffectBody and PostEffectTarget contain valid info
	CameraManager::GetInstance()->ApplyEffectsToCameraData(m_PostEffectBody, m_PostEffectTarget);

	return CAMERA_UPDATEREPORT_NONE;
}


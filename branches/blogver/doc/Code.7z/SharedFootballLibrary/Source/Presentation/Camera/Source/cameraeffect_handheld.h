
#ifndef  _CAMERAEFFECT_HANDHELD_H_
# define _CAMERAEFFECT_HANDHELD_H_

# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _CAMERAEFFECT_H_
#  include "presentation/camera/cameraeffect.h"
# endif

# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{

		class CameraEffect_Handheld : public CameraEffect
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			CameraEffect_Handheld(void);
			~CameraEffect_Handheld(void);

			// Public virtual methods
			/* virtual */ void Init( float fDuration = -1.0f, float fMagnitudeMod = 1.0f );
			/* virtual */ void Reset(void);
			/* virtual */ bool Update(float);
			/* virtual */ void Apply(Point &pBody, Point &pTarget);

		private:

			// Private data members
			Axiom::Math::Vector2	m_Bouncing;
			float					m_MagnitudeUp;
			float					m_MagnitudeSide;
			float					m_Duration;
			float					m_FinalDuration;
			bool					m_ApplyToTarget;
			bool					m_ApplyToBody;


		};
	}
}

#endif

#pragma once

#ifndef  _CAMERA_H_
# define _CAMERA_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H_
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif
# ifndef _CAMERAEFFECT_H_
#  include "presentation/camera/cameraeffect.h"
# endif
# ifndef _PRESENTATIONOUTPUT_H_
#  include "presentation/presentationoutput.h"
# endif

# ifndef __CORE_VECTOR3_H
#  include <math/vector3.h>
# endif
# ifndef _CRC_H
#  include <core/crc.h>
# endif
# ifndef _CORE_TIME_H
#  include <core/time.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class Time;
		class Sequence;
		class Orientation;
		class Camera;
		class DebugDrawing;
		class PresentationInput;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef	 INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM_REFLECTED(	CAMERA_TYPE_e,\
								CLASSEDENUM_ITEMWITHVALUE(CAMERA_TYPE_INVALID, -1)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_STATIC)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_GAMEPLAY_TARGETRELATIVECONTROLLER_CONTROLLED)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_DEBUG_CONTROLLED)\
								CLASSEDENUM_ITEM(CAMERA_TYPE_DEBUG_FAR)\
								CLASSEDENUM_ITEM(CAMERA_NBTYPES)\
								,CAMERA_TYPE_INVALID)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		enum CAMERA_UPDATEREPORT_e
		{
			CAMERA_UPDATEREPORT_NONE = 0,

			CAMERA_UPDATEREPORT_BODY =				0x01,
			CAMERA_UPDATEREPORT_TARGET =			0x02,
			CAMERA_UPDATEREPORT_ZOOM =				0x04,
			CAMERA_UPDATEREPORT_ROLL =				0x08,
			CAMERA_UPDATEREPORT_POSTEFFECTBODY =	0x10,
			CAMERA_UPDATEREPORT_POSTEFFECTTARGET =	0x20,
		};

		class Camera : public Axiom::Referenced
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			Camera(const CAMERA_TYPE_e);
			virtual ~Camera(void);
			
			// Public methods
			void									SetName(const char*);
			PRESENTATION_INLINE const Axiom::ShortString& GetID(void) const;
			PRESENTATION_INLINE const CAMERA_TYPE_e	GetCameraType(void) const;

			// Virtual public methods
			virtual const Axiom::Math::Vector3&		GetCurrentBodyPosition(void) const = 0;
			virtual const Axiom::Math::Vector3&		GetCurrentTargetPosition(void) const = 0;
			virtual const float						GetCurrentZoom(void) const = 0;
			virtual const float						GetCurrentRoll(void) const = 0;
			virtual const Framing&					GetCurrentFraming(void) const = 0;
			virtual const Orientation				GetOrientation(void) = 0;
			virtual Point*							GetBodyPoint(void) = 0;
			virtual Point*							GetTargetPoint(void) = 0;
			virtual FloatComponent*					GetZoomComponent(void) = 0;
			virtual FloatComponent*					GetRollComponent(void) = 0;
			virtual Framing*						GetFraming(void) = 0;

			virtual void							SetImmediateUpdate(bool,bool);
			virtual void							CopyData(Camera*) = 0;
			
			virtual void							Reset(bool);
			virtual int								Update(float, const PresentationInput&) = 0;
			virtual int								UpdateEffects(float);
			virtual void							Draw(const PresentationInput&,PresentationOutput*,const Orientation&, const unsigned int channel);

		protected:
		
			// Protected member variables
			Axiom::ShortString																m_ID;
			CAMERA_TYPE_e																	m_Type;
			bool																			m_ImmediateBasicUpdate;		// For Body, Target, Zoom & Roll			
			bool																			m_ImmediateInternalUpdate;	// For any dependencies affection the basics (Distance, Heading & Pitch)
			bool																			m_FirstUpdate;

			// Post Effect Data
			Point																			m_PostEffectBody;
			Point																			m_PostEffectTarget;

		private:

			// Friendship declaration
			friend class	CameraGamePlay;			// To access the private GetBodyPoint/GetTargetPoint/GetZoomComponent/GetRollComponent methods
			friend class	Tracking;				// To access the private GetBodyPoint/GetTargetPoint/GetZoomComponent/GetRollComponent/GetFraming methods

			// Reflection methods
			bool				Reset_Reflection(void);

		};
		
		// Creator function
		Axiom::SmartPtr<Camera> CreateCamera(const CAMERA_TYPE_e);

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/camera.inl"
# endif

	}
}

#endif

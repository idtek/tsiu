#pragma once

#ifndef  _CAMERAMANAGER_H_
# define _CAMERAMANAGER_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _CAMERA_H_
#  include "presentation/camera/camera.h"
# endif
# ifndef _VIEWPORT_H_
#  include "presentation/camera/viewport.h"
# endif
#ifndef _CAMERA_TRACKER_H_
#include "presentation/Shared/cameratracker.h"
#endif

# ifndef __COLLECTIONS_GENERIC__LIST_H
#  include <collections/list.h>
# endif
# ifndef __CORE_SINGLETON_H_
#  include <core/singleton.h>
# endif
# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class Orientation;
		class Viewport;

		class CameraManager /*: public Axiom::Singleton<CameraManager>*/
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			CameraManager(void);
			virtual ~CameraManager(void);	

			// Singleton stuff
			static CameraManager*						Init(Axiom::Memory::HeapId);
			static void									Destroy(void);
			PRESENTATION_INLINE static CameraManager*	GetInstance(void);

			// Camera & viewports
			Axiom::SmartPtr<Camera>						AddCamera(const CAMERA_TYPE_e);
			void										RemoveCamera(const char*);
			void										RemoveCamera(const Axiom::CRC&);
			const Camera&								FindCamera(const char*);
			const Camera&								FindCamera(const Axiom::CRC&);
			Camera*										FindCameraPtr(const char*);
			Camera*										FindCameraPtr(const Axiom::CRC&);
			PRESENTATION_INLINE const int				GetNbCameras(void) const;

			const Viewport*								AddViewport(void);
			void										RemoveViewport(const char*);
			void										RemoveViewport(const Axiom::CRC&);
			const Viewport&								FindViewport(const char*);		
			const Viewport&								FindViewport(const Axiom::CRC&);		
			Viewport*									FindViewportPtr(const char*);		
			Viewport*									FindViewportPtr(const Axiom::CRC&);		
			PRESENTATION_INLINE const int				GetNbViewports(void) const;

			// Effects
			void										AddEffect(Axiom::SmartPtr<SharedSoccer::Presentation::CameraEffect> pEffect);
			void										ApplyEffectsToCameraData(Point& rPostEffectBody, Point& rPostEffectTarget);

			// Position/Rotation Data
			PRESENTATION_INLINE const CameraTracker&	GetCameraTracker(void) const;

			// Helpers	
			const Viewport*								GetViewport(const Axiom::CRC&);
			const Viewport*								GetViewport(const char*);
			const Camera*								GetCamera(const Axiom::CRC&);
			const Camera*								GetCamera(const char*);

			// Update	
			PRESENTATION_INLINE const Viewport*			GetUpdateViewport(void);

			void										Reset(void);
			void										Update(float, const PresentationInput&, PresentationOutput*, const unsigned int debugChannel);

		private:

			// Reflection declaration
			AP_NON_COPYABLE( CameraManager )

			// Static instance				
			static CameraManager*	m_pInstance;

			// Private constants
			static const int k_NbActiveEffectsMax = 4;
			static const int k_NbCamerasMax = 64;
			static const int k_NbViewportsMax = 2;

			// Private variable members

			// Viewport data
			Axiom::Collections::StaticList<Viewport*,
										   k_NbCamerasMax>			m_Viewports;
			Viewport*												m_pUpdateViewport;

			// Camera data
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Camera> >			m_Cameras;

			Axiom::Collections::ReflectedList<Axiom::SmartPtr<CameraEffect> >	m_Effects;

			CameraTracker											m_CameraTracker;

			// Private methods
			void		RemoveViewportPtr(Viewport*);
			void		RemoveCameraPtr(Camera*);

			// Reflection methods
			bool		AddViewport_Reflection(char*);
			bool		DeleteViewport_Reflection(int);
			bool		AddCamera_Reflection(CAMERA_TYPE_e,char*);
			bool		DeleteCamera_Reflection(int);
			bool		IsCameraActive_Reflection(char*);

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/cameramanager.inl"
# endif

	}
}

#endif

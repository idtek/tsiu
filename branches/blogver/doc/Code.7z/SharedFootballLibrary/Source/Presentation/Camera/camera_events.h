#pragma once

#ifndef  _CAMERA_EVENTS_H_
# define _CAMERA_EVENTS_H_

# ifndef _EVENTMAN_H__
#  include <eventsystem/eventman.h>
# endif
# ifndef __MESSAGES_H
#  include <kernel/messages.h>
# endif

namespace AP
{
	namespace Events
	{
		//-----------------------------------------------------------------------------------------------------------------------------------
		class ViewportUpdateEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( ViewportUpdateEvent );

			Axiom::Math::Vector3	m_Position;
			Axiom::Math::Vector3	m_Front;
			Axiom::Math::Vector3	m_Up;
			Axiom::Math::Vector3	m_Right;

			ViewportUpdateEvent() : EventMsg(EVENT_GUID)
			{
			}

			ViewportUpdateEvent(Axiom::Math::Vector3 vPosition, Axiom::Math::Vector3 vFront, Axiom::Math::Vector3 vUp, Axiom::Math::Vector3 vRight) : EventMsg(EVENT_GUID),
				m_Position(vPosition),				
				m_Front(vFront),
				m_Up(vUp),
				m_Right(vRight)
			{
			}
		};

	}
}

#endif


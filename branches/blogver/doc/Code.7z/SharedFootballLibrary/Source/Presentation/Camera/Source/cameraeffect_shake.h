
#ifndef  _CAMERAEFFECT_SHAKE_H_
# define _CAMERAEFFECT_SHAKE_H_

# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _CAMERAEFFECT_H_
#  include "presentation/camera/cameraeffect.h"
# endif
# ifndef _PRESENTATION_UTILS_H
#  include "presentation/presentation_utils.h"
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class CameraEffect_Shake : public CameraEffect
		{
		public:

			// Reflection
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			CameraEffect_Shake(void);
			~CameraEffect_Shake(void);


			// Public virtual methods
			/* virtual */ void Reset(void);
			/* virtual */ void Init(float fDuration = -1.0f, float fMagnitudeMod = 1.0f);
			/* virtual */ bool Update(float);
			/* virtual */ void Apply(Point &pBody, Point &pTarget);

		private:

			// Private data members
			Noise		m_BodyNoise;
			Noise		m_TargetNoise;

		};
	}
}

#endif


#ifndef _CAMERAEFFECT_SHAKE_H_
# include "presentation/camera/source/cameraeffect_shake.h"
#endif
#ifndef _CAMERA_H
# include "presentation/camera/camera.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;


// Reflection declaration
AP_TYPE(CameraEffect_Shake)
	AP_BASE_TYPE(CameraEffect)
	AP_DEFAULT_CREATE()
	AP_FIELD("BodyNoise",			m_BodyNoise,			"Body Noise")
	AP_FIELD("TargetNoise",			m_TargetNoise,			"Target Noise")
	AP_PROXY("Camera")
AP_TYPE_END()

// Constructor and destructor
CameraEffect_Shake::CameraEffect_Shake(void) : CameraEffect(),
	m_BodyNoise(),
	m_TargetNoise()
{
}

CameraEffect_Shake::~CameraEffect_Shake(void)
{
}

// Public virtual functions
/* virtual */ void CameraEffect_Shake::Reset(void)
{
	m_BodyNoise.Reset();
	m_TargetNoise.Reset();
}

/* virtual */ void CameraEffect_Shake::Init(float fDuration /* = -1.0f */,  float fMagnitudeMod /* = 1.0f */)
{
	m_BodyNoise.Init(fDuration, fMagnitudeMod);
	m_TargetNoise.Init(fDuration, fMagnitudeMod);
}

/* virtual */ bool CameraEffect_Shake::Update(float fDeltaTime)
{
	bool result = m_BodyNoise.Update(fDeltaTime);
	result |= m_TargetNoise.Update(fDeltaTime);
	return result;
}

/* virtual */ void CameraEffect_Shake::Apply(Point &pBody, Point &pTarget)
{
	pBody.SetMaxVelocity(m_BodyNoise.GetFrequency());
	pBody.SetAcceleration(m_BodyNoise.GetFrequency() * 100.0f);
	pBody.AddDesired( m_BodyNoise.GetMagnitudeVector() );

	pTarget.SetMaxVelocity(m_TargetNoise.GetFrequency());
	pTarget.SetAcceleration(m_TargetNoise.GetFrequency() * 100.0f);
	pTarget.AddDesired( m_TargetNoise.GetMagnitudeVector() );
}
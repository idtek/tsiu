
#ifndef _CAMERACURVE_H_
# include "presentation/camera/cameracurve.h"
#endif
#ifndef _PRESENTATION_UTILS_H
# include "presentation/presentation_utils.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/cameracurve.inl"
#endif

// Reflection 
AP_TYPE(Vector)
	AP_FIELD("Current", m_Current, "Current Position")
	AP_FIELD("Desired", m_Desired, "Desired Position")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Float)
	AP_FIELD("Current", m_Current, "Current")
	AP_FIELD("Desired", m_Desired, "Desired")
	AP_FIELD("Maximum", m_Maximum, "Maximum")
	AP_FIELD("Minimum", m_Minimum, "Minimum")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(CumulativeFloat)
	AP_FIELD("Current", m_Current, "Current")
	AP_FIELD("PrimaryDesired", m_PrimaryDesired, "EventDesired")
	AP_FIELD("SecondaryDesired", m_SecondaryDesired, "AreaDesired")
	AP_FIELD("Maximum", m_Maximum, "Maximum")
	AP_FIELD("Minimum", m_Minimum, "Minimum")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Point)
	AP_FIELD("Current", m_Data.m_Current, "Current position")
	AP_FIELD("Desired", m_Data.m_Desired, "Desired position")
	AP_FIELD("MaximumVelocity", m_Velocity.m_Maximum, "Maximum velocity")
	AP_FIELD("Acceleration", m_Acceleration, "Acceleration")
	AP_FIELD("Speed", m_BaseSpeed, "Speed")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(FloatComponent)
	AP_FIELD("Current", m_Data.m_Current, "Current value")
	AP_FIELD("Desired", m_Data.m_Desired, "Desired value")
	AP_FIELD("MaximumVelocity", m_Velocity.m_Maximum, "Maximum velocity")
	AP_FIELD("Acceleration", m_Acceleration, "Acceleration")
	AP_FIELD("Speed", m_BaseSpeed, "Speed")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(CumulativeFloatComponent)
	AP_FIELD("Current", m_Data.m_Current, "Current value")
	AP_FIELD("PrimaryDesired", m_Data.m_PrimaryDesired, "Desired value for events")
	AP_FIELD("SecondaryDesired", m_Data.m_SecondaryDesired, "Desired value for areas")
	AP_FIELD("MaximumVelocity", m_Velocity.m_Maximum, "Maximum velocity")
	AP_FIELD("Acceleration", m_Acceleration, "Acceleration")
	AP_FIELD("Speed", m_BaseSpeed, "BaseSpeed")
	AP_FIELD("Maximum", m_Data.m_Maximum, "Maximum value")
	AP_FIELD("Minimum", m_Data.m_Minimum, "Minimum value")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Curve)
	AP_FIELD("Keys", m_AnimationKeys, "Animation Keys")
	AP_NAMED_COMMAND("AddAnimationKey", AddAnimationKey_Reflection, "Add a new animation key")
	AP_NAMED_COMMAND("DeleteAnimationKey", DeleteAnimationKey_Reflection, "Delete an animation key at provided index")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Iterator)
	AP_FIELD("Type",	m_IteratorType, "Type or iterator")
	AP_FIELD("Maximum", m_Maximum, "Maximum range")
	AP_FIELD("Minimum", m_Minimum, "Minimum range")
	AP_FIELD("Multiplicator", m_Multiplicator, "Multiplicator")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(ITERATOR_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

// Vector
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Vector::Vector(void) :
	m_Current(),
	m_Desired()
{
}

Vector::~Vector(void)
{
}

// Public methods
const Axiom::Math::Vector3 Vector::GetDelta(void)
{
	return Axiom::Math::Vector3( m_Desired - m_Current );
}

void Vector::UpdateImmediate(void)
{
	m_Current = m_Desired;
}

void Vector::Immobilize(void)
{
	m_Desired = m_Current;
}

// Public operators
Vector& Vector::operator =(const Vector &rVector)
{
	m_Current = rVector.m_Current;
	m_Desired = rVector.m_Desired;

	return *this;
}

Vector&  Vector::Set(const Vector &rVector, bool bCurrent, bool bDesired)
{
	if( bCurrent )
	{
		m_Current = rVector.m_Current;
	}
	if( bDesired )
	{
		m_Desired = rVector.m_Desired;
	}

	return *this;
}

// Float
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Float::Float(void) : 
	m_Current(0.0f),
	m_Desired(0.0f),
	m_Maximum(0.0f),
	m_Minimum(0.0f)
{
}

Float::~Float(void)
{
}

// Public methods
const float Float::GetDelta(void)
{
	return m_Desired - m_Current;
}

void Float::ClampDesired(void)
{
	if( m_Desired > m_Maximum )
	{
		m_Desired = m_Maximum;
	}
	else if( m_Desired < m_Minimum )
	{
		m_Desired = m_Minimum;
	}
}

void Float::ClampCurrent(void)
{
	if( m_Current > m_Maximum )
	{
		m_Current = m_Maximum;
	}
	else if( m_Current < m_Minimum )
	{
		m_Current = m_Minimum;
	}
}

void Float::ApplyAcceleration(const float fAcceleration)
{
	if( m_Current < m_Desired )
	{
		// Speed up
		m_Current += fAcceleration;
		if( m_Current > m_Desired )
		{
			m_Current = m_Desired;
		}
	}
	else
	{
		// Slow down
		m_Current -= fAcceleration;
		if( m_Current < m_Desired )
		{
			m_Current = m_Desired;
		}
	}
}

void Float::UpdateImmediate(void)
{
	m_Current = m_Desired;
	ClampCurrent();
}

void Float::Immobilize(void)
{
	ClampCurrent();
	m_Desired = m_Current;
}

// Public operators
Float& Float::operator =(const Float &rFloat)
{
	m_Current = rFloat.m_Current;
	m_Desired = rFloat.m_Desired;
	m_Maximum = rFloat.m_Maximum;
	m_Minimum = rFloat.m_Minimum;

	return *this;
}

Float& Float::Set(const Float &rFloat, bool bCurrent, bool bDesired)
{
	if( bCurrent )
	{
		m_Current = rFloat.m_Current;
	}
	if( bDesired )
	{
		m_Desired = rFloat.m_Desired;
	}
	m_Maximum = rFloat.m_Maximum;
	m_Minimum = rFloat.m_Minimum;

	return *this;
}

// Cumulative Float
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
CumulativeFloat::CumulativeFloat(void) : 
	m_Current(0.0f),
	m_PrimaryDesired(0.0f),
	m_SecondaryDesired(0.0f),
	m_Maximum(0.0f),
	m_Minimum(0.0f)
{
}

CumulativeFloat::~CumulativeFloat(void)
{
}

// Public methods
const float CumulativeFloat::GetDelta(void)
{
	return m_PrimaryDesired + m_SecondaryDesired - m_Current;
}

void CumulativeFloat::ClampCurrent(void)
{
	if( m_Current > m_Maximum )
	{
		m_Current = m_Maximum;
	}
	else if( m_Current < m_Minimum )
	{
		m_Current = m_Minimum;
	}
}

void CumulativeFloat::ApplyAcceleration(const float fAcceleration)
{
	float fDesired = m_PrimaryDesired + m_SecondaryDesired;
	if( m_Current < fDesired )
	{
		// Speed up
		m_Current += fAcceleration;
		if( m_Current > fDesired )
		{
			m_Current = fDesired;
		}
	}
	else
	{
		// Slow down
		m_Current -= fAcceleration;
		if( m_Current < fDesired )
		{
			m_Current = fDesired;
		}
	}
}

void CumulativeFloat::UpdateImmediate(void)
{
	m_Current = GetDesired();
	ClampCurrent();
}

void CumulativeFloat::Immobilize(void)
{
	ClampCurrent();
	m_PrimaryDesired = m_Current / 2.0f;
	m_SecondaryDesired = m_Current / 2.0f;
}

// Public operators
CumulativeFloat& CumulativeFloat::operator =(const CumulativeFloat &rCumulativeFloat)
{
	m_Current = rCumulativeFloat.m_Current;
	m_PrimaryDesired = rCumulativeFloat.m_PrimaryDesired;
	m_SecondaryDesired = rCumulativeFloat.m_SecondaryDesired;
	m_Maximum = rCumulativeFloat.m_Maximum;
	m_Minimum = rCumulativeFloat.m_Minimum;

	return *this;
}

CumulativeFloat& CumulativeFloat::Set(const CumulativeFloat &rCumulativeFloat, bool bCurrent, bool bPrimaryDesired, bool bSecondaryDesired)
{
	if( bCurrent )
	{
		m_Current = rCumulativeFloat.m_Current;
	}
	if( bPrimaryDesired )
	{
		m_PrimaryDesired = rCumulativeFloat.m_PrimaryDesired;
	}
	if( bSecondaryDesired )
	{
		m_SecondaryDesired = rCumulativeFloat.m_SecondaryDesired;
	}
	m_Maximum = rCumulativeFloat.m_Maximum;
	m_Minimum = rCumulativeFloat.m_Minimum;

	return *this;
}

// Point
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Point::Point(void) :
	m_Data(),
	m_Velocity(),
	m_Acceleration(POINT_ACCELERATION_DEFAULT),
	m_Tolerance(POINT_TOLERANCE_DEFAULT),
	m_BaseSpeed(POINT_BASESPEED_DEFAULT)
{
	m_Velocity.SetMaximum( POINT_VELOCITY_MAXIMUM_DEFAULT );
	m_Velocity.SetMinimum( POINT_VELOCITY_MINIMUM_DEFAULT );
}

Point::~Point(void)
{
}

// Public methods
bool Point::Update(float fDeltaTime)
{
 	// Calculate the distance to move
	Axiom::Math::Vector3 vDeltaDistance = m_Data.GetDesired() - m_Data.GetCurrent();
	float fDeltaDistance = vDeltaDistance.Magnitude();
	if( (fDeltaDistance - m_Tolerance) < CAMERA_EPSILON  )
	{
		return false;
	}

	// Calculate the new desired velocity
	m_Velocity.SetDesired( m_Velocity.GetMaximum() * ( fDeltaDistance / m_BaseSpeed ) );
	m_Velocity.ClampDesired();

	// Move current velocity towards desired, with out jumping over
	m_Velocity.ClampCurrent();
	m_Velocity.ApplyAcceleration( m_Acceleration * fDeltaTime );

	// The real distance to move
	float fMoveDistance = m_Velocity.GetCurrent() * fDeltaTime;
	if( fMoveDistance > fDeltaDistance )
	{
		fMoveDistance = fDeltaDistance;
	}
	vDeltaDistance.Normalize();
	vDeltaDistance *= fMoveDistance;
	m_Data.AddCurrent( vDeltaDistance );

	return true;
}
 
bool Point::UpdateImmediate(void)
{
	float fMagnitude = m_Data.GetDelta().Magnitude();
	if( fMagnitude < m_Tolerance )
	{
		return false;
	}

	m_Data.UpdateImmediate();

	return true;
}

void Point::Immobilize(void)
{
	m_Data.Immobilize();
}

// Public debug methods
bool Point::IsValid(void)
{
	const Axiom::Math::Vector3 &rDesired = m_Data.GetDesired();
	const Axiom::Math::Vector3 &rCurrent = m_Data.GetCurrent();

	return Axiom::Math::FloatAbs( rDesired.X() ) < CAMERA_THRESHOLD &&
		   Axiom::Math::FloatAbs( rDesired.Y() ) < CAMERA_THRESHOLD &&
		   Axiom::Math::FloatAbs( rDesired.Z() ) < CAMERA_THRESHOLD &&
		   Axiom::Math::FloatAbs( rCurrent.X() ) < CAMERA_THRESHOLD &&
		   Axiom::Math::FloatAbs( rCurrent.Y() ) < CAMERA_THRESHOLD &&
		   Axiom::Math::FloatAbs( rCurrent.Z() ) < CAMERA_THRESHOLD;
}

// Public operators
Point& Point::operator =(const Point &rPoint)
{
	m_Data = rPoint.m_Data;
	m_Velocity = rPoint.m_Velocity;
	m_BaseSpeed = rPoint.m_BaseSpeed;
	m_Tolerance = rPoint.m_Tolerance;
	m_Acceleration = rPoint.m_Acceleration;

	return *this;
}

Point& Point::Set(const Point &rPoint, bool bCurrent, bool bDesired, bool bUpdateSpeedData)
{
	m_Data.Set( rPoint.m_Data, bCurrent, bDesired );
	if(bUpdateSpeedData)
	{
		m_Velocity = rPoint.m_Velocity;
		m_BaseSpeed = rPoint.m_BaseSpeed;
		m_Tolerance = rPoint.m_Tolerance;
		m_Acceleration = rPoint.m_Acceleration;
	}

	return *this;
}


// TimeInterpolatePoint
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
TimeInterpolatePoint::TimeInterpolatePoint(void) :
	m_Data(),
	m_Time(1.0f),
	m_Curve(0),
	m_CurrentTime(0.0f)
{
}

TimeInterpolatePoint::~TimeInterpolatePoint(void)
{
}

// Public methods
bool TimeInterpolatePoint::Update(float fDeltaTime)
{
	AP_ASSERT(m_Time != 0.0f);

	m_CurrentTime += fDeltaTime;

	return m_CurrentTime <= m_Time;
}


// Public debug methods
bool TimeInterpolatePoint::IsValid(void)
{
	return true;
}

// Public operators
TimeInterpolatePoint& TimeInterpolatePoint::operator =(const TimeInterpolatePoint &rPoint)
{
	m_Data = rPoint.m_Data;
	m_Time = rPoint.m_Time;
	m_Curve = rPoint.m_Curve;
	m_CurrentTime = rPoint.m_CurrentTime;

	return *this;
}



TimeInterpolatePoint& TimeInterpolatePoint::Set(const TimeInterpolatePoint &rPoint, bool bCurrent, bool bDesired)
{
	m_Data.Set( rPoint.m_Data, bCurrent, bDesired );
	m_Time = rPoint.m_Time;
	m_Curve = rPoint.m_Curve;
	m_CurrentTime = rPoint.m_CurrentTime;

	return *this;
}

TimeInterpolatePoint& TimeInterpolatePoint::Set(const Point &rPoint, bool bCurrent, bool bDesired)
{
	if(bDesired && !bCurrent)
	{
		SetDesired(rPoint.GetDesired());
	}
	else
	{
		m_CurrentTime = 0.0f;
		m_Data.Set( rPoint.m_Data, bCurrent, bDesired );
	}

	return *this;
}



// Component
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
FloatComponent::FloatComponent(void) :
	m_Data(),
	m_Velocity(),
	m_Acceleration(COMPONENT_ACCELERATION_DEFAULT),
	m_Tolerance(COMPONENT_TOLERANCE_DEFAULT),
	m_BaseSpeed(COMPONENT_BASESPEED_DEFAULT)
{
	m_Velocity.SetMaximum( COMPONENT_VELOCITY_MAXIMUM_DEFAULT );
	m_Velocity.SetMinimum( COMPONENT_VELOCITY_MINIMUM_DEFAULT );	
	m_Data.SetMaximum( COMPONENT_DATA_MAXIMUMANGLE_DEFAULT );
	m_Data.SetMinimum( COMPONENT_DATA_MINIMUMANGLE_DEFAULT );
}

FloatComponent::~FloatComponent(void)
{
}

// Public methods
bool FloatComponent::Update(float fDeltaTime, bool bAngle /* =true */)
{
	// Calculate the delta
	float fDelta = m_Data.GetDesired() - m_Data.GetCurrent();
	if( bAngle )
	{
		fDelta = NormalizeAngle( fDelta );
	}
	float fAbsDelta = Axiom::Math::FloatAbs(fDelta);
	if( fAbsDelta < CAMERA_EPSILON )
	{
		return false;
	}

	// Calculate the new desired velocity
	m_Velocity.SetDesired( m_Velocity.GetMaximum() * ( fAbsDelta / m_BaseSpeed ) );
	m_Velocity.ClampDesired();

	// Move current velocity towards desired, with out jumping over
	m_Velocity.ClampCurrent();
	m_Velocity.ApplyAcceleration( m_Acceleration * fDeltaTime );

	// The real distance to move
	float fMove = m_Velocity.GetCurrent() * fDeltaTime;
	if( fMove > fAbsDelta )
	{
		fMove = fAbsDelta;
	}
	m_Data.AddCurrent( fDelta < CAMERA_EPSILON ? -fMove : fMove );
	m_Data.ClampCurrent();

	return true;
}

bool FloatComponent::UpdateImmediate(void)
{
	float fDeltaAbs = Axiom::Math::FloatAbs( m_Data.GetDelta() );
	if( fDeltaAbs < m_Tolerance )
	{
		return false;
	}

	m_Data.UpdateImmediate();

	return true;
}

void FloatComponent::Immobilize(void)
{
	m_Data.Immobilize();
}

// Public operators
FloatComponent& FloatComponent::operator =(const FloatComponent &rComponent)
{
	m_Data = rComponent.m_Data;
	m_Velocity = rComponent.m_Velocity;
	m_Acceleration = rComponent.m_Acceleration;
	m_Tolerance = rComponent.m_Tolerance;
	m_BaseSpeed = rComponent.m_BaseSpeed;

	return *this;
}

FloatComponent& FloatComponent::Set(const FloatComponent &rComponent, bool bCurrent, bool bDesired)
{
	m_Data.Set( rComponent.m_Data, bCurrent, bDesired );
	m_Velocity = rComponent.m_Velocity;
	m_Acceleration = rComponent.m_Acceleration;
	m_Tolerance = rComponent.m_Tolerance;
	m_BaseSpeed = rComponent.m_BaseSpeed;

	return *this;
}

// Cumulative Component
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
CumulativeFloatComponent::CumulativeFloatComponent(void) :
	m_Data(),
	m_Velocity(),
	m_Acceleration(COMPONENT_ACCELERATION_DEFAULT),
	m_Tolerance(COMPONENT_TOLERANCE_DEFAULT),
	m_BaseSpeed(COMPONENT_BASESPEED_DEFAULT)
{
	m_Velocity.SetMaximum( COMPONENT_VELOCITY_MAXIMUM_DEFAULT );
	m_Velocity.SetMinimum( COMPONENT_VELOCITY_MINIMUM_DEFAULT );	
	m_Data.SetMaximum( COMPONENT_DATA_MAXIMUMANGLE_DEFAULT );
	m_Data.SetMinimum( COMPONENT_DATA_MINIMUMANGLE_DEFAULT );
}

CumulativeFloatComponent::~CumulativeFloatComponent(void)
{
}

// Public methods
bool CumulativeFloatComponent::Update(float fDeltaTime, bool bAngle /* =true */)
{
	// Calculate the delta
	float fDelta = GetDesired() - GetCurrent();
	if( bAngle )
	{
		fDelta = NormalizeAngle( fDelta );
	}
	float fAbsDelta = Axiom::Math::FloatAbs(fDelta);
	if( fAbsDelta < CAMERA_EPSILON )
	{
		return false;
	}

	// Calculate the new desired velocity
	m_Velocity.SetDesired( m_Velocity.GetMaximum() * ( fAbsDelta / m_BaseSpeed ) );
	m_Velocity.ClampDesired();

	// Move current velocity towards desired, with out jumping over
	m_Velocity.ClampCurrent();
	m_Velocity.ApplyAcceleration( m_Acceleration * fDeltaTime );

	// The real distance to move
	float fMove = m_Velocity.GetCurrent() * fDeltaTime;
	if( fMove > fAbsDelta )
	{
		fMove = fAbsDelta;
	}
	m_Data.AddCurrent( fDelta < CAMERA_EPSILON ? -fMove : fMove );
	m_Data.ClampCurrent();

	return true;
}

bool CumulativeFloatComponent::UpdateImmediate(void)
{
	float fDeltaAbs = Axiom::Math::FloatAbs( m_Data.GetDelta() );
	if( fDeltaAbs < m_Tolerance )
	{
		return false;
	}

	m_Data.UpdateImmediate();

	return true;
}

void CumulativeFloatComponent::Immobilize(void)
{
	m_Data.Immobilize();
}

// Public operators
CumulativeFloatComponent& CumulativeFloatComponent::operator =(const CumulativeFloatComponent &rComponent)
{
	m_Data = rComponent.m_Data;
	m_Velocity = rComponent.m_Velocity;
	m_Acceleration = rComponent.m_Acceleration;
	m_Tolerance = rComponent.m_Tolerance;
	m_BaseSpeed = rComponent.m_BaseSpeed;

	return *this;
}

CumulativeFloatComponent& CumulativeFloatComponent::Set(const CumulativeFloatComponent &rComponent, bool bCurrent, bool bPrimaryDesired, bool bSecondaryDesired)
{
	m_Data.Set( rComponent.m_Data, bCurrent, bPrimaryDesired, bSecondaryDesired );
	m_Velocity = rComponent.m_Velocity;
	m_Acceleration = rComponent.m_Acceleration;
	m_Tolerance = rComponent.m_Tolerance;
	m_BaseSpeed = rComponent.m_BaseSpeed;

	return *this;
}

// Curve
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Private methods
void Curve::GetTangent( unsigned int iIndex, bool bIsWeighted, Axiom::Math::Vector2 &rIn, Axiom::Math::Vector2 &rOut) const
{
	AP_ASSERT( m_AnimationKeys.Count() > 0 && iIndex < m_AnimationKeys.Count() );

	const Gel::AnimationKey *pPrevKeyFrame = NULL;
	const Gel::AnimationKey *pNextKeyFrame = NULL;
	const Gel::AnimationKey *pKeyFrame = m_AnimationKeys[iIndex].pVal();

	if( iIndex >= 1 )
	{
		pPrevKeyFrame = m_AnimationKeys[iIndex-1].pVal();
	}
	if( iIndex < ( m_AnimationKeys.Count() - 1 ) )
	{
		pNextKeyFrame = m_AnimationKeys[iIndex+1].pVal();
	}

	HermineCurve::GetTangent( pKeyFrame, pPrevKeyFrame, pNextKeyFrame, bIsWeighted, rIn, rOut );
}

// Private reflected methods
bool Curve::AddAnimationKey_Reflection(float fTime, float fValue)
{
	return (AddAnimationKey(fTime,fValue) != NULL);
}

bool Curve::DeleteAnimationKey_Reflection(int i)
{
	m_AnimationKeys.RemoveAt(i);
	return true;
}

// Constructor & virtual destructor
Curve::Curve(void) : HermineCurve(),
	m_AnimationKeys()
{
}

/* virtual */Curve::~Curve(void)
{
	m_AnimationKeys.Clear();
}

// Public methods
const Gel::AnimationKey* Curve::AddAnimationKey(float fTime /* =0.0f */, float fValue /* =0.0f */)
{
	PRESENTATION_ASSERT( m_AnimationKeys.Count() < m_AnimationKeys.Capacity(), "Camera Error: Out of capacity!\n" );

	// Create the axis (tracking)
	Gel::AnimationKey *pKey = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Gel::AnimationKey(fTime,fValue) );
	PRESENTATION_ASSERT( pKey != NULL, "Camera Error: Can't create axis tracking\n" );

	m_AnimationKeys.Add( Axiom::SmartPtr<Gel::AnimationKey>(pKey) );

	return pKey;
}

int Curve::Evaluate( float *pValue, float fTime, float fDefaultValue /*=0.0f*/ ) const
{
	AP_ASSERTMESSAGE( pValue != NULL, "AnimationCurve Error: NULL pointer passed!\n" );

	// Special 'no channel keyframes' cases
	if( m_AnimationKeys.Count() == 0 )
	{
		*pValue = fDefaultValue;
		return 0;
	}
	if( m_AnimationKeys.Count() == 1 )
	{
		*pValue = m_AnimationKeys[0]->GetValue();
		return 1;
	}

	const float firstTime = m_AnimationKeys.FirstItem()->GetTime();
	const float lastTime = m_AnimationKeys.LastItem()->GetTime();

#if CORE_USERDEBUG==CORE_YES
	static bool sCurveLogging = false;

	if(sCurveLogging)
	{
		Log( "Presentation", "first and last are %f, %f", firstTime, lastTime );
	}
#endif
	
	// If time is before the first keyframe's time
	if( fTime < firstTime )
	{
		*pValue = m_AnimationKeys.FirstItem()->GetValue();
		return 1;
	}
	// If time is after the last keyframe's time
	else if( fTime > lastTime )
	{
		*pValue = m_AnimationKeys.LastItem()->GetValue();
		return 1;
	}

#if CORE_USERDEBUG==CORE_YES
	if(sCurveLogging)
	{
		for( unsigned int i = 0; i < m_AnimationKeys.Count(); ++i )
		{
			Log( "Presentation", "value at %d is %f", i, m_AnimationKeys[i]->GetTime() );
		}
	}
#endif

	// Guess which keyframe to use
	unsigned int iGuessIndex = CastToUInt( CastToFloat(m_AnimationKeys.Count()-1) * (fTime - firstTime)/(lastTime - firstTime) );

	AP_ASSERT( iGuessIndex < m_AnimationKeys.Count() );

	const Gel::AnimationKey *pGuessKeyFrame = m_AnimationKeys[iGuessIndex].pVal();

	// Find the keyframes to evaluate the position
	while( fTime < pGuessKeyFrame->GetTime() )
	{
		AP_ASSERTMESSAGE( iGuessIndex >= 1, "guess index is %d and total count is %d", iGuessIndex, m_AnimationKeys.Count() );
		pGuessKeyFrame = m_AnimationKeys[ --iGuessIndex ].pVal();
	}

	unsigned iStartIndex = 0, iEndIndex = 0;
	for( unsigned int i = iGuessIndex ; i < m_AnimationKeys.Count() ; ++i )
	{
		const Gel::AnimationKey *pKeyFrame = m_AnimationKeys[i].pVal();

		// If we hit a keyframe then just return its value
		const float fDeltaTime = fTime - pKeyFrame->GetTime();
		if( abs( fDeltaTime ) < CAMERA_EPSILON )
		{
			*pValue = pKeyFrame->GetValue();
			return 1;
		}
		// Determine the start and end indexes       
		if( fTime < pKeyFrame->GetTime() )
		{
			iStartIndex = iEndIndex = i;
			--iStartIndex;
			break;
		}
	}

	// Evaluate the value
	Axiom::Math::Vector2 vIn, vOut, vDummy;

	// Get the tangents
	GetTangent( iStartIndex, false, vDummy, vOut );
	const Gel::AnimationKey *pStartKeyFrame = m_AnimationKeys[iStartIndex].pVal();

	if( vOut.X() == 0.0f && vOut.Y() == 0.0f )
	{
		*pValue = pStartKeyFrame->GetValue();
		return 1;
	}

	GetTangent( iEndIndex, false, vIn, vDummy );

	*pValue = HermineCurve::HermiteEvaluate( fTime, pStartKeyFrame, vOut, m_AnimationKeys[iEndIndex].pVal(), vIn );
	return 1;
}

// Public operators
Curve& Curve::operator =(const Curve &rCurve)
{
	m_AnimationKeys = rCurve.m_AnimationKeys;

	return *this;
}

// Iterator
// -------------------------------------------------------------------------------------------------------------------------

// Private methods
float Iterator::ApplyRange(float fValue)
{
	// Range the number
	if( fValue > m_Maximum )
	{
		fValue = m_Maximum;
	}
	else if( fValue < m_Minimum )
	{
		fValue = m_Minimum;
	}
	// Turn it into a 0.0f-1.0f ranged number
	fValue = (fValue - m_Minimum)/(m_Maximum - m_Minimum);

	return fValue;
}

float Iterator::ApplyMultiplicator(float fValue)
{
	return fValue * m_Multiplicator;
}

// Constructor & destructor
Iterator::Iterator(void) :
	m_IteratorType(ITERATOR_TYPE_e::ITERATOR_TYPE_INVALID),
	m_Maximum(0.0f),
	m_Minimum(0.0f),
	m_Multiplicator(1.0f)
{
}

Iterator::~Iterator(void)
{
}

// Public methods
float Iterator::Evaluate(float fValue)
{
	UNUSED_PARAM(fValue);
	float fResult = 0.0f;

	switch( m_IteratorType )
	{
		case ITERATOR_TYPE_e::ITERATOR_TYPE_TARGETX:
			{
				// Grab the target position
				const Viewport *pViewport = CameraManager::GetInstance()->GetUpdateViewport();
				if( pViewport != NULL )
				{
					const Camera *pCamera = pViewport->GetCamera();
					if( pCamera != NULL )
					{
						fResult = pCamera->GetCurrentTargetPosition().X();
					}
				}
				// Apply the range and multiplicator
				fResult = ApplyRange( fResult );
				fResult = ApplyMultiplicator( fResult );
			}
			break;
		case ITERATOR_TYPE_e::ITERATOR_TYPE_TARGETY:
			{
				// Grab the target position
				const Viewport *pViewport = CameraManager::GetInstance()->GetUpdateViewport();
				if( pViewport != NULL )
				{
					const Camera *pCamera = pViewport->GetCamera();
					if( pCamera != NULL )
					{
						fResult = pCamera->GetCurrentTargetPosition().Y();
					}
				}
				// Apply the range and multiplicator
				fResult = ApplyRange( fResult );
				fResult = ApplyMultiplicator( fResult );
			}
			break;
		case ITERATOR_TYPE_e::ITERATOR_TYPE_PASSTHROUGH:
			// Just apply the multiplicator
			fResult = ApplyMultiplicator( fResult );
			break;
		default:
			break;
	}

	return fResult;
}

// Public operators
Iterator& Iterator::operator =(const Iterator &rIterator)
{
	m_IteratorType = rIterator.m_IteratorType;
	m_Maximum = rIterator.m_Maximum;
	m_Minimum = rIterator.m_Minimum;
	m_Multiplicator = rIterator.m_Multiplicator;

	return *this;
}


#ifndef _CAMERAEFFECT_HANDHELD_H_
# include "presentation/camera/source/cameraeffect_handheld.h"
#endif
#ifndef _CAMERA_H
# include "presentation/camera/camera.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;


// Reflection declaration
AP_TYPE(CameraEffect_Handheld)
	AP_BASE_TYPE(CameraEffect)
	AP_DEFAULT_CREATE()
	AP_FIELD("Up",			m_MagnitudeUp,			"Up down magnitude")
	AP_FIELD("Side",		m_MagnitudeSide,		"Side to side magnitude")
	AP_FIELD("Duration",	m_Duration,				"Duration of effect")
	AP_FIELD("ApplyToTarget",m_ApplyToTarget,		"Whether we apply the shake to the target or not")
	AP_FIELD("ApplyToBody",	m_ApplyToBody,			"Whether we apply the shake to the body or not")
	AP_PROXY("Camera")
AP_TYPE_END()



// Constructor and destructor
CameraEffect_Handheld::CameraEffect_Handheld(void) : CameraEffect(),
	m_Bouncing(),
	m_MagnitudeUp(0.25f),
	m_MagnitudeSide(0.1f),
	m_Duration(0.0f),
	m_FinalDuration(0.0f),
	m_ApplyToTarget(false),
	m_ApplyToBody(true)
{
}

CameraEffect_Handheld::~CameraEffect_Handheld(void)
{
}
// Public virtual functions
/* virtual */ void CameraEffect_Handheld::Init(float fDuration /* = -1.0f */,  float fMagnitudeMod /* = 1.0f */)
{
	m_FinalDuration = (fDuration > 0.0f) ? fDuration : m_Duration;
	m_Bouncing = Axiom::Math::Vector2(0.0f,0.0f);
}


/* virtual */ void CameraEffect_Handheld::Reset(void)
{
	m_Bouncing = Axiom::Math::Vector2(0.0f,0.0f);
}

/* virtual */ bool CameraEffect_Handheld::Update(float fDeltaTime)
{
	bool result = false;
	//result |= m_BodyNoise.Update(fDeltaTime);
	//result |= m_TargetNoise.Update(fDeltaTime);

	return result;
}

/* virtual */ void CameraEffect_Handheld::Apply(Point &pBody, Point &pTarget)
{
	//pBody.AddDesired( m_BodyNoise.GetAMagnitudeVector() );
	//pTarget.AddDesired( m_TargetNoise.GetAMagnitudeVector() );
}


///* virtual */ void CameraEffect_Handheld::Update(float fDeltaTime, Point *pBody, Point *pTarget)
//{
//	PRESENTATION_ASSERT( pBody != NULL, "Camera Error: NULL body pointer passed!\n" );
//	PRESENTATION_ASSERT( pTarget != NULL, "Camera Error: NULL target pointer passed!\n" );
//
//	Axiom::Math::Vector3 vDelta = pBody->GetDesired() - pBody->GetCurrent();
//	float fDeltaMagnitude = vDelta.Magnitude();
//
///* KGF TODO: What is this for? :
//	if( fDeltaMagnitude > 0.0f )
//	{
//		vDelta /= fDeltaMagnitude;
//	}
//*/
//
//	if( fDeltaMagnitude > 0.1f )	// Some epsilon value
//	{
//		m_Bouncing.X( fDeltaMagnitude * m_MagnitudeUp * cosf( fDeltaTime ) );
//		m_Bouncing.Y( fDeltaMagnitude * m_MagnitudeSide * sinf( fDeltaTime ) );
//
//		const Axiom::Math::Vector3 vBounce = Axiom::Math::Vector3( 0.0f, m_Bouncing.Y(), m_Bouncing.X() );
//
//		if(m_ApplyToBody)
//		{
//			pBody->AddDesired( vBounce );
//		}
//		if(m_ApplyToTarget)
//		{
//			pTarget->AddDesired( vBounce );
//		}
//	}
//}

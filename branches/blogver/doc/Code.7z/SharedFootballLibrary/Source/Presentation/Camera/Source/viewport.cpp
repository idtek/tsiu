
#ifndef _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _CAMERADEBUG_H_
# include "presentation/camera/source/cameradebug.h"
#endif
#ifndef  _CAMERACOMMAND_H_
# include "presentation/camera/cameracommand.h"
#endif
#ifndef  _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif

#ifndef _COMPONENT_MANAGER_H
# include <kernel/componentmanager.h>
#endif
#ifndef GEL_H
# include <gel/gel.h>
#endif

#ifndef HEADER_TRANSFORMUTILS_H
# include <math/transformutils.h>
#endif

#include <math/matrixutils.h> // Pragma'ed once
#include <particles/curves.h> // Pragme'ed once


// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;
using namespace Particle;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/camera/viewport.inl"
#endif

extern SharedSoccer::Presentation::ViewportCameraData	s_CurrentBakedCameraData;

// Reflection declaration
AP_TYPE(Viewport)
	AP_FIELD("ID", m_ID, "ID")
	AP_FIELD("FOV", m_CurrentViewportCameraData.m_FOV, "Viewport field of view")
	AP_FIELD("AspectRatio", m_AspectRatio, "Viewport Aspect Ratio")
	AP_FIELD("NearPlane", m_NearPlane, "Viewport Near Plane")
	AP_FIELD("FarPlane", m_FarPlane, "Viewport Far Plane")
	AP_FIELD("Width", m_Width, "Viewport Width")
	AP_FIELD("Height", m_Height, "Viewport Height")
//	AP_FIELD("State", m_State, "Viewport State")			// TODO: Add enum support
AP_TYPE_END()

AP_TYPE(VIEWPORT_STATE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()


// Orientation
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Orientation::Orientation(void) : 
	Axiom::Math::Matrix4(),
	m_Origin()
{
	SetIdentity();
}

Orientation::Orientation(const Axiom::Math::Vector3 &rOrigin, const Axiom::Math::Vector3 &rLookAt, const float fRoll) :
	Axiom::Math::Matrix4(),
	m_Origin( rOrigin )
{
	// Get the yaws
	Yaw tYaw( rOrigin, rLookAt );

	// Compute the orientation
	Matrix4 mRotation = RotationY(fRoll) * RotationZ( tYaw.GetHeading() ) * RotationX( tYaw.GetPitch() );
	*reinterpret_cast<Axiom::Math::Matrix4*>(this) = Translation( -m_Origin ) * mRotation;
}

Orientation::Orientation(const Axiom::Math::Vector3 &rOrigin, const float fHeading, const float fPitch, const float fRoll) :
	Axiom::Math::Matrix4(),
	m_Origin( rOrigin )
{
	// Compute the orientation
	Matrix4 mRotation = RotationY(fRoll) * RotationZ(fHeading) * RotationX(fPitch);
	*reinterpret_cast<Axiom::Math::Matrix4*>(this) = Translation( -m_Origin ) * mRotation;
}

Orientation::~Orientation(void)
{
}

// Public methods
void Orientation::Set(const Axiom::Math::Matrix4 &rMatrix)
{
	*reinterpret_cast<Axiom::Math::Matrix4*>(this) = rMatrix;
}

void Orientation::Set(const Axiom::Math::Matrix4& rMatrix, const Axiom::Math::Vector3& rOrigin, bool buildOriginInMatrix)
{
	m_Origin = rOrigin;
	if(buildOriginInMatrix)
	{
		*reinterpret_cast<Axiom::Math::Matrix4*>(this) = Translation( -m_Origin ) * rMatrix;
	}
	else
	{
		*reinterpret_cast<Axiom::Math::Matrix4*>(this) = rMatrix;
	}
}

void Orientation::Set(const Axiom::Math::Vector3 &rOrigin, const Axiom::Math::Vector3 &rLookAt, const float fRoll)
{
	// Store the origin
	m_Origin = rOrigin;

	// Get the yaws
	Yaw tYaw( rOrigin, rLookAt );

	// Compute the orientation
	Matrix4 mRotation = RotationY(fRoll) * RotationZ( tYaw.GetHeading() ) * RotationX( tYaw.GetPitch() );
	*reinterpret_cast<Axiom::Math::Matrix4*>(this) = Translation( -m_Origin ) * mRotation;
}

void Orientation::Set(const Axiom::Math::Vector3 &rOrigin, const float fHeading, const float fPitch, const float fRoll)
{
	// Store the origin
	m_Origin = rOrigin;

	// Compute the orientation
	Matrix4 mRotation = RotationY(fRoll) * RotationZ(fHeading) * RotationX(fPitch);
	*reinterpret_cast<Axiom::Math::Matrix4*>(this) = Translation( -m_Origin ) * mRotation;
}

const Axiom::Math::Vector3 Orientation::GetFront(void) const
{
	Axiom::Math::Vector3 vFront = GetZbasis();
	vFront.Normalize();
    return vFront;
}

const Axiom::Math::Vector3 Orientation::GetUp(void) const
{
	Axiom::Math::Vector3 vUp = GetYbasis();
	vUp.Normalize();
	return vUp;
}

const Axiom::Math::Vector3 Orientation::GetSide(void) const
{
	Axiom::Math::Vector3 vSide = GetXbasis();
	vSide.Normalize();
	return vSide;
}

const Axiom::Math::Vector3 Orientation::GetOrigin(void) const
{
	return m_Origin;
}

/* static */ Orientation Orientation::Interpolate(float fraction, const Orientation& lhs, const Orientation& rhs)
{
	PRESENTATION_ASSERT( fraction >= 0.0f && fraction <= 1.0f, "Orientation::Interpolate. Fraction should be between 0.0f and 1.0f" );

	Orientation output;

	//benh 11-Dec-2008: There is no interpolate that takes Matrix4 ... yet.
	Axiom::Math::RigidMatrix oldMatrix(lhs);
	Axiom::Math::RigidMatrix newMatrix(rhs);
	Axiom::Math::Vector3 oldOrigin(lhs.GetOrigin());
	Axiom::Math::Vector3 newOrigin(rhs.GetOrigin());

	Axiom::Math::RigidMatrix outputMatrix(Axiom::Math::Interpolate(fraction, oldMatrix, newMatrix));
	Axiom::Math::Vector3 outputOrigin(Axiom::Math::Interpolate(fraction, oldOrigin, newOrigin));

	output.Set(outputMatrix.AsMatrix4(), outputOrigin, false);

	return output;
}

// Projector
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Projection::Projection(void) : 
	Axiom::Math::Matrix44()
{
}

Projection::Projection(const float fFOV, const float fAspect, const float fNear, const float fFar)
{
	Set(fFOV,fAspect,fNear,fFar);
}

Projection::~Projection(void)
{
}

// Public methods
void Projection::Set(const float fFOV, const float fAspect, const float fNear, const float fFar)
{
	Axiom::Math::Matrix44 mPerspective = Axiom::Math::Perspective( fFOV, fAspect, fNear, fFar );

#if CORE_WII
	// Fix the planes
	float fRatio = fFar / (fNear - fFar);
	mPerspective.SetE( 2, 2, fRatio );
	mPerspective.SetE( 2, 3, -1.0f );
	mPerspective.SetE( 3, 2, fNear * fRatio );
	mPerspective.SetE( 3, 3, 0.0f );
#endif

	*reinterpret_cast<Axiom::Math::Matrix44*>(this) = mPerspective;
}

// Pointer
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

Pointer::Pointer(void) :
	m_X(0.0f),
	m_Y(0.0f)
{
}

Pointer::~Pointer(void)
{
}

// ViewportData
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
ViewportCameraData::ViewportCameraData(void) :
	m_Orientation(),
	m_FOV(VIEWPORT_FOV_DEFAULT)
{
}

ViewportCameraData::ViewportCameraData(const Orientation& orientation, float fov) :
	m_Orientation(orientation),
	m_FOV(fov)
{
}
		

ViewportCameraData::ViewportCameraData(const ViewportCameraData& rhs) :
	m_Orientation(rhs.m_Orientation),
	m_FOV(rhs.m_FOV)
{

}

ViewportCameraData& ViewportCameraData::operator =(const ViewportCameraData& rhs)
{
	m_Orientation = rhs.m_Orientation;
	m_FOV = rhs.m_FOV;

	return *this;
}

/* static */ ViewportCameraData ViewportCameraData::Interpolate(float fraction, const ViewportCameraData& oldViewport, const ViewportCameraData& newViewport)
{
	if(fraction <= 0.0f)
		return oldViewport;

	if(fraction >= 1.0f)
		return newViewport;

	ViewportCameraData output;

	output.m_Orientation = Orientation::Interpolate(fraction, oldViewport.m_Orientation, newViewport.m_Orientation);
	output.m_FOV = oldViewport.m_FOV + (fraction * (newViewport.m_FOV - oldViewport.m_FOV));

	return output;
}

// Viewport
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Viewport::Viewport(void) :
	m_pCamera(NULL),
	m_BakedCameraData(),
	m_pDebugCamera(NULL),
	m_InDebugMode(false),
	m_OverwriteInDebugMode(false),
	m_Projection(),
	m_State(VIEWPORT_STATE_e::VIEWPORT_STATE_INVALID),
	m_AspectRatio(VIEWPORT_ASPECTRATIO_DEFAULT),
	m_NearPlane(VIEWPORT_NEARPLANE_DEFAULT),
	m_FarPlane(VIEWPORT_FARPLANE_DEFAULT),
	m_Width(/*Gel::GetScreenWidth()*/16),
	m_Height(/*Gel::GetScreenHeight()*/9),
	m_CurrentViewportCameraData(),
	m_SourceViewportCameraData(),
	m_TargetBlendTime(0.0f),
	m_CurrentBlendTime(0.0f),
	m_pBlendCurve(NULL)
{
#if CORE_WII
	//Wii is anamorphic, and we need to set up the projection matrix differently.
	if(Gel::IsWideScreen())
	{
		m_Width = 16;
		m_Height = 9;
	}
	else
	{
		m_Width = 4;
		m_Height = 3;
	}
#endif
}

Viewport::~Viewport(void)
{
}

// Public methods
void Viewport::SetName(const char *pName)
{
	m_ID.Set(pName);
}

void Viewport::SetCameraCut(const CameraCutCommand &rCommand, const bool push)
{
	Camera *pCamera = rCommand.Execute(m_pCamera);
	if( pCamera != NULL )
	{
		if(push)
		{
			// Build command to return and save on stack
			const CameraCutCommand popCommand(m_pCamera->GetID(), rCommand.GetTransition());
			if(m_CameraCommands.IsFull())
			{
				m_CameraCommands.RemoveHead();
			}
			m_CameraCommands.Add(popCommand);
		}

		// Assign the new camera
		m_pCamera = pCamera;

		// Initialise blend from command
		InitialiseBlend(rCommand);

		m_BakedCameraData.Reset();
	}
#if CORE_USERDEBUG == CORE_YES
	else
	{
		SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
		Axiom::ShortString output("Cant find cam: ");
		output += rCommand.GetCameraID();
		pSimulatedPresentation->AddDebugText(output);
	}
#endif
}

void Viewport::InitialiseBlend(const CameraCutCommand& rCommand)
{
	if(rCommand.GetBlendTime() > 0.0f)
	{
		m_SourceViewportCameraData = m_CurrentViewportCameraData;
		m_TargetBlendTime = rCommand.GetBlendTime();
		m_CurrentBlendTime = 0.0f;
		m_pBlendCurve = LookupCurveManager::GetInstance()->GetCurve(rCommand.GetCurveID());
	}
	else
	{
		m_TargetBlendTime = 0.0f;
		m_CurrentBlendTime = 0.0f;
		m_pBlendCurve = NULL;
	}
}

void Viewport::SetBakedCameraCut(const Axiom::ShortString& rBakedCamName, 
								 const PresentationTransformationData& rTransformData,
								 const CameraCutCommand &rCommand,
								 const float time,
								 const float timeScale,
								 const float fov,
								 const bool useCurvedPitchCalc )
{
	// Initialise blend from command
	InitialiseBlend(rCommand);

	m_BakedCameraData = BakedCameraData(rBakedCamName, rTransformData, time, timeScale, fov, useCurvedPitchCalc );
}


void Viewport::PopCameraCut(const SharedSoccer::Presentation::CameraCutCommand& cameracutcommand)
{
	if( m_BakedCameraData.IsValid() && (cameracutcommand.GetCameraID().Length() == 0 || m_BakedCameraData.m_ID.Find(cameracutcommand.GetCameraID()) >= 0 ) )
	{
		m_BakedCameraData.Reset();

		if(cameracutcommand.GetTransition() != VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_UNDEFINED)
		{
			// Initialise blend from command
			InitialiseBlend(cameracutcommand);
		}
		else
		{
			// if no transition specified, re-run the last transition we used, in SetBakedCameraCut, at the new camera position
			m_SourceViewportCameraData = m_CurrentViewportCameraData;
			m_CurrentBlendTime = 0.0f;				
		}
	}
	else if(m_CameraCommands.Count() > 0)
	{
		CameraCutCommand command = m_CameraCommands.LastItem();

		if (cameracutcommand.GetCameraID().Length() == 0 || m_pCamera->GetID() == cameracutcommand.GetCameraID())
		{
			m_CameraCommands.RemoveTail();
		}
		else
		{
			const int topOfCameraStack = m_CameraCommands.Count() - 1;
			int index = topOfCameraStack;
			for ( ; index >= 0; --index ) //search top down through camera stack
			{
				const Axiom::ShortString& cameraId = cameracutcommand.GetCameraID();
				if (cameraId.Find(m_CameraCommands[index].GetCameraID()) >= 0)
				{
					//when we remove a camera not on top of the stack, do not change the current camera. do not execute the cameracutcommand.
					m_CameraCommands.RemoveAt(index);
					return;
				}
			}
#if CORE_USERDEBUG==CORE_YES
			SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
			pSimulatedPresentation->AddDebugText("Viewport::PopCameraCut(): tried to pop non-existent cameraID");
#endif
			return;
		}

		if(cameracutcommand.GetTransition() != VIEWPORT_TRANSITION_e::VIEWPORT_TRANSITION_UNDEFINED)
		{
			command = CameraCutCommand(command.GetCameraID(), cameracutcommand);
		}

		Camera *pCamera = command.Execute(m_pCamera);

		if ( pCamera != NULL )
		{
			// Assign the new camera
			m_pCamera = pCamera;

			// Initialise blend from command
			InitialiseBlend(command);
		}
	}
}

void Viewport::SetDebugCamera(const char *pName, bool bDebugMode, bool bOverwrite /*=false*/, bool bCopyData /*=true*/)
{
	SetDebugCamera( Axiom::CRC(pName), bDebugMode, bOverwrite, bCopyData );
}

void Viewport::SetDebugCamera(const Axiom::CRC &rCRC, bool bDebugMode, bool bOverwrite /*=false*/, bool bCopyData /*=true*/)
{
	// Set the debug mode
	m_InDebugMode = bDebugMode;
	if( m_InDebugMode )
	{
		// Overwrite data?
		m_OverwriteInDebugMode = bOverwrite;

		// Get the debug camera
		CameraManager *pInstance = CameraManager::GetInstance();
		PRESENTATION_ASSERT( pInstance != NULL, "Camera Error: Can't get camera manager!\n" );

		m_pDebugCamera = static_cast<CameraDebug*>( pInstance->FindCameraPtr( rCRC ) );
		PRESENTATION_ASSERT( m_pDebugCamera != NULL && 
						   ( m_pDebugCamera->GetCameraType() == CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_CONTROLLED ||
							 m_pDebugCamera->GetCameraType() == CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_FAR        ), "Camera Error: Can't find camera!\n" );

		// Make sure the debug camera starts at the last point of the normal camera
		if( m_pCamera != NULL && bCopyData )
		{
			m_pDebugCamera->CopyData( m_pCamera );
		}
	}
	else
	{
		m_pDebugCamera = NULL;
		m_OverwriteInDebugMode = false;
	}
}

const CameraDebug* Viewport::GetDebugCamera(void) const
{
	return m_pDebugCamera;
}

const Orientation& Viewport::GetOrientation(void) const
{
	return m_CurrentViewportCameraData.m_Orientation;
}

const Projection& Viewport::GetProjection(void) const
{
	return m_Projection;
}

void Viewport::Reset(void)
{
	m_CameraCommands.Clear();
	m_BakedCameraData.Reset();
	m_pCamera = NULL;
	m_pDebugCamera = NULL;
	m_InDebugMode = false;
	m_OverwriteInDebugMode = false;
	m_State = VIEWPORT_STATE_e::VIEWPORT_STATE_INVALID;
	m_TargetBlendTime = 0.0f;
	m_CurrentBlendTime = 0.0f;
}

void Viewport::Update(float fDeltaTime, const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int channel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed!\n" );

	if( m_pCamera != NULL )
	{
		VIEWPORT_USAGE_e eUsage = VIEWPORT_USAGE_NORMAL;

		// Setup the viewport aspect ratio
		m_AspectRatio = static_cast<float>(m_Width) / static_cast<float>(m_Height);

		if( m_InDebugMode && m_pDebugCamera != NULL ) // Alternative debug camera
		{

			// Update the main camera
			if( fDeltaTime > 0.0f && fDeltaTime < CAMERA_TIME_THRESHOLD )
			{
				m_pCamera->Update(fDeltaTime,rInput);
			}

			// Get the orientation and FOV
			Orientation tOrientation = m_pCamera->GetOrientation();
			float		fFOV = m_pCamera->GetCurrentZoom();

			if( m_OverwriteInDebugMode )
			{
				pOutput->ExportViewportData( eUsage, tOrientation, fFOV, m_AspectRatio, m_NearPlane, m_FarPlane, m_Pointer );
			}
	
			// Update the debug camera
			m_pDebugCamera->UpdateDebug(m_pCamera,CAMERA_DELTATIME_DEFAULT,rInput);

			// Get the orientation, projection and FOV
			ViewportCameraData debugViewportCameraData;
			debugViewportCameraData.m_Orientation = m_pDebugCamera->GetOrientation();
			debugViewportCameraData.m_FOV = m_pDebugCamera->GetCurrentZoom();

			m_Projection.Set( debugViewportCameraData.m_FOV, m_AspectRatio, m_NearPlane, m_FarPlane );

			// Draw the debug camera
			m_pDebugCamera->DrawDebug(m_pCamera,rInput,pOutput,tOrientation, channel);

			eUsage = VIEWPORT_USAGE_DEBUG;

			// Setup the viewport destination data
			pOutput->ExportViewportData( eUsage, debugViewportCameraData.m_Orientation, debugViewportCameraData.m_FOV, m_AspectRatio, m_NearPlane, m_FarPlane, m_Pointer );
		}
		else
		{
			if(!m_BakedCameraData.IsValid())
			{
				// Update the main camera
				float blendFraction = 1.0f;
				int iReport = CAMERA_UPDATEREPORT_NONE;
				if( fDeltaTime > 0.0f && fDeltaTime < CAMERA_TIME_THRESHOLD )
				{
					iReport = m_pCamera->Update(fDeltaTime,rInput);

					m_CurrentBlendTime += fDeltaTime;
					if(m_CurrentBlendTime >= m_TargetBlendTime)
					{
						blendFraction = 1.0f;
					}
					else
					{
						PRESENTATION_ASSERT(m_pBlendCurve != NULL, "Viewport::Update. BlendCurve is null");
						float mappedTime = m_CurrentBlendTime / m_TargetBlendTime;
						blendFraction = m_pBlendCurve->GetValue(mappedTime);
						PRESENTATION_ASSERT(blendFraction >= 0.0f && blendFraction <= 1.0f, "Viewport::Update. blendFraction must be between 0.0 and 1.0.");
					}
				}

				//Blend the orientation and FOV from source to current camera
				ViewportCameraData targetCameraData(m_pCamera->GetOrientation(), m_pCamera->GetCurrentZoom());
				m_CurrentViewportCameraData = ViewportCameraData::Interpolate(blendFraction, m_SourceViewportCameraData, targetCameraData);

				// Get the orientation, projection and FOV
				m_Projection.Set( m_CurrentViewportCameraData.m_FOV, m_AspectRatio, m_NearPlane, m_FarPlane );

				// Draw the camera
				m_pCamera->Draw(rInput,pOutput,m_CurrentViewportCameraData.m_Orientation, channel);

				// Notify the camera update
				if( ( iReport & CAMERA_UPDATEREPORT_BODY ) != 0 )
				{
					pOutput->NotifyViewportChange(m_CurrentViewportCameraData.m_Orientation);
				}

				// Setup the viewport destination data
				pOutput->ExportViewportData( eUsage, m_CurrentViewportCameraData.m_Orientation, m_CurrentViewportCameraData.m_FOV, m_AspectRatio, m_NearPlane, m_FarPlane, m_Pointer );
			}
			else
			{
				//find the blend fraction for the baked camera
				float blendFraction = 1.0f;
				//int iReport = CAMERA_UPDATEREPORT_NONE;
				if( fDeltaTime > 0.0f && fDeltaTime < CAMERA_TIME_THRESHOLD )
				{
					//iReport = m_pCamera->Update(fDeltaTime,rInput);

					m_CurrentBlendTime += fDeltaTime;
					if(m_CurrentBlendTime >= m_TargetBlendTime)
					{
						blendFraction = 1.0f;
					}
					else
					{
						PRESENTATION_ASSERT(m_pBlendCurve != NULL, "Viewport::Update. BlendCurve is null");
						float mappedTime = m_CurrentBlendTime / m_TargetBlendTime;
						blendFraction = m_pBlendCurve->GetValue(mappedTime);
						PRESENTATION_ASSERT(blendFraction >= 0.0f && blendFraction <= 1.0f, "Viewport::Update. blendFraction must be between 0.0 and 1.0.");
					}
				}

				// Setup the viewport destination data
				m_BakedCameraData.UpdatePositionRotation(rInput);
				pOutput->ExportBakedViewportData( Axiom::CRC(m_BakedCameraData.m_ID.AsChar()), 
												  m_BakedCameraData.m_Time * m_BakedCameraData.m_TimeScale,
												  m_BakedCameraData.GetCurrentRotation(),
												  m_BakedCameraData.GetCurrentPosition(),
												  m_BakedCameraData.m_FOV,
												  m_BakedCameraData.m_UseCurvedPitchCalc,
												  m_SourceViewportCameraData, //only valid if we are blending, and should only be used in pres if we are blending
												  blendFraction);

				m_BakedCameraData.UpdateTime(fDeltaTime);

				//current Baked camera will generate it's own camera data on Pres side, on this side (Sim side) m_CurrentViewportCameraData is used to help us blend to the next non-baked camera.
				m_CurrentViewportCameraData = s_CurrentBakedCameraData;  //1 frame delay ok for blending?
			}
		}
	}
}

// Protected methods

// Operator
const bool Viewport::operator ==(const Viewport &rViewport) const
{ 
	return m_pCamera == rViewport.m_pCamera &&
		   m_State == rViewport.m_State &&
		   m_CurrentViewportCameraData.m_FOV == rViewport.m_CurrentViewportCameraData.m_FOV &&
		   m_AspectRatio == rViewport.m_AspectRatio &&
		   m_NearPlane == rViewport.m_NearPlane  &&
		   m_FarPlane == rViewport.m_FarPlane &&
		   m_Width == rViewport.m_Width &&
		   m_Height == rViewport.m_Height;
}

void Viewport::SetPointerValues( float x, float y )
{
	if( m_pCamera == NULL )
	{
		return;
	}
	m_Pointer.Set(x, y, 0);
}


void Viewport::BakedCameraData::UpdatePositionRotation( const PresentationInput &rInput )
{
	if(m_Transform.GetTransformNeedsToUpdate() || m_Transform.GetUpdatesTransformEveryFrame())
	{
		m_Transform.GetTranslationAndRotation(rInput, m_CurrentPosition, m_CurrentRotation);
		m_Transform.SetTransformNeedsToUpdate(false);
	}
}


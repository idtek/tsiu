#pragma once

#ifndef  _CAMERACURVE_H
# define _CAMERACURVE_H

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H_
#  include "presentation/camera/camera_defines.h"
# endif

# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif
# ifndef __CORE_VECTOR3_H
#  include <math/vector3.h>
# endif
# ifndef __CORE_VECTOR4_H
#  include <math/vector4.h>
# endif
# ifndef _CLASSEDENUM_H
#  include <core/classedenum.h>
# endif
# ifndef HERMINE_CURVE_H
#  include <gel/herminecurve.h>
# endif
# ifndef __COLLECTIONS_GENERIC__LIST_H
#  include <collections/list.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM_REFLECTED(	ITERATOR_TYPE_e,\
								CLASSEDENUM_ITEMWITHVALUE(ITERATOR_TYPE_INVALID, -1) \
								CLASSEDENUM_ITEM(ITERATOR_TYPE_PASSTHROUGH) \
								CLASSEDENUM_ITEM(ITERATOR_TYPE_TARGETX) \
								CLASSEDENUM_ITEM(ITERATOR_TYPE_TARGETY) \
								CLASSEDENUM_ITEM(ITERATOR_NBTYPES) \
								,ITERATOR_TYPE_INVALID)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		class Vector
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			Vector(void);
			~Vector(void);

			// Public methods
			PRESENTATION_INLINE void							AddCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const Axiom::Math::Vector3&		GetCurrent(void) const;

			PRESENTATION_INLINE void							AddDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const Axiom::Math::Vector3&		GetDesired(void) const;

			const Axiom::Math::Vector3							GetDelta(void);

			void												UpdateImmediate(void);
			void												Immobilize(void);

			// Public operators
			Vector&	operator =(const Vector&);
			Vector&	Set(const Vector&,bool,bool);

		private:

			// Friendship declaration
			friend class Point;			// For reflection purposes

			// Private members
			Axiom::Math::Vector3	m_Current;
			Axiom::Math::Vector3	m_Desired;

		};
		
		class Float
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			Float(void);
			~Float(void);

			// Public methods
			PRESENTATION_INLINE void			SetMaximum(float);
			PRESENTATION_INLINE const float		GetMaximum(void) const;
			PRESENTATION_INLINE void			SetMinimum(float);
			PRESENTATION_INLINE const float		GetMinimum(void) const;

			PRESENTATION_INLINE void			AddDesired(float);
			PRESENTATION_INLINE void			SetDesired(float);
			PRESENTATION_INLINE const float		GetDesired(void) const;

			PRESENTATION_INLINE void			AddCurrent(float);
			PRESENTATION_INLINE void			SetCurrent(float);
			PRESENTATION_INLINE const float		GetCurrent(void) const;

			const float							GetDelta(void);

			void								ClampDesired(void);
			void								ClampCurrent(void);
			void								ApplyAcceleration(const float);

			void								UpdateImmediate(void);
			void								Immobilize(void);

			// Public operators
			Float& operator =(const Float&);
			Float& Set(const Float&,bool,bool);

		private:

			// Friendship declaration
			friend class Point;						// For reflection purposes
			friend class FloatComponent;			// For reflection purposes
			friend class CumulativeFloatComponent;	// For reflection purposes

			// Private members
			float	m_Current;
			float	m_Desired;
			float	m_Maximum;
			float	m_Minimum;

		};

		class CumulativeFloat
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			CumulativeFloat(void);
			~CumulativeFloat(void);

			// Public methods
			PRESENTATION_INLINE void			SetMaximum(float);
			PRESENTATION_INLINE const float		GetMaximum(void) const;
			PRESENTATION_INLINE void			SetMinimum(float);
			PRESENTATION_INLINE const float		GetMinimum(void) const;

			PRESENTATION_INLINE void			AddPrimaryDesired(const float);
			PRESENTATION_INLINE void			AddSecondaryDesired(const float);
			PRESENTATION_INLINE void			SetPrimaryDesired(const float);
			PRESENTATION_INLINE void			SetSecondaryDesired(const float);
			PRESENTATION_INLINE const float		GetPrimaryDesired(void) const;
			PRESENTATION_INLINE const float		GetSecondaryDesired(void) const;
			PRESENTATION_INLINE const float		GetDesired(void) const;

			PRESENTATION_INLINE void			AddCurrent(const float);
			PRESENTATION_INLINE void			SetCurrent(const float);
			PRESENTATION_INLINE const float		GetCurrent(void) const;

			const float							GetDelta(void);

			void								ClampDesired(void);
			void								ClampCurrent(void);
			void								ApplyAcceleration(const float);

			void								UpdateImmediate(void);
			void								Immobilize(void);

			// Public operators
			CumulativeFloat& operator =(const CumulativeFloat&);
			CumulativeFloat& Set(const CumulativeFloat&,bool,bool,bool);

		private:

			// Friendship declaration
			friend class CumulativeFloatComponent;	// For reflection purposes

			// Private members
			float	m_Current;
			float	m_PrimaryDesired;
			float	m_SecondaryDesired;
			float	m_Maximum;
			float	m_Minimum;

		};

		class Point
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			Point(void);
			~Point(void);

			// Public methods
			PRESENTATION_INLINE void							AddDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const Axiom::Math::Vector3&		GetDesired(void) const;

			PRESENTATION_INLINE void							SetAcceleration(float);
			PRESENTATION_INLINE void							SetMaxVelocity(float);
			PRESENTATION_INLINE void							SetVelocity(float);
			PRESENTATION_INLINE void							SetBaseSpeed(float);

			PRESENTATION_INLINE void							AddCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const Axiom::Math::Vector3&		GetCurrent(void) const;

			bool												Update(float);
			bool												UpdateImmediate(void);
			void												Immobilize(void);

			// Public debug methods
			bool												IsValid(void);

			// Public operators
			Point&		operator =(const Point&);
			Point&		Set(const Point&,bool bCurrent, bool bDesired, bool bUpdateSpeedData);


		private:
			friend class TimeInterpolatePoint;

			// Public members
			Vector		m_Data;
			Float		m_Velocity;
			float		m_Acceleration;
			float		m_Tolerance;
			float		m_BaseSpeed;

		};

		class TimeInterpolatePoint
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			TimeInterpolatePoint(void);
			~TimeInterpolatePoint(void);

			// Public methods
			PRESENTATION_INLINE void							AddDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetDesired(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const Axiom::Math::Vector3&		GetDesired(void) const;

			PRESENTATION_INLINE void							AddCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void							SetCurrent(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE Axiom::Math::Vector3			GetCurrent(void) const;
			PRESENTATION_INLINE float							GetInterpolation() const;
			PRESENTATION_INLINE void							SetTime(float);

			bool												Update(float);

			// Public debug methods
			bool												IsValid(void);

			// Public operators
			TimeInterpolatePoint&		operator =(const TimeInterpolatePoint&);
			TimeInterpolatePoint&		Set(const TimeInterpolatePoint&,bool,bool);
			TimeInterpolatePoint&		Set(const Point&,bool,bool);

		private:

			// Public members
			Vector		m_Data;
			float		m_Time;
			Axiom::UInt8 m_Curve;
			float		m_CurrentTime;
		};
		
		class FloatComponent
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			FloatComponent(void);
			~FloatComponent(void);

			// Public methods
			PRESENTATION_INLINE void		SetMaximum(float);
			PRESENTATION_INLINE const float	GetMaximum(void) const;
			PRESENTATION_INLINE void		SetMinimum(float);
			PRESENTATION_INLINE const float	GetMinimum(void) const;

			PRESENTATION_INLINE void		AddDesired(const float);
			PRESENTATION_INLINE void		SetDesired(const float);
			PRESENTATION_INLINE const float	GetDesired(void) const;

			PRESENTATION_INLINE void		AddCurrent(const float);
			PRESENTATION_INLINE void		SetCurrent(const float);
			PRESENTATION_INLINE const float	GetCurrent(void) const;

			bool							Update(float, bool bAngle=true);
			bool							UpdateImmediate(void);
			void							Immobilize(void);

			// Public operators
			FloatComponent& operator =(const FloatComponent&);
			FloatComponent& Set(const FloatComponent&,bool,bool);

		private:

			// Public members
			Float	m_Data;			
			Float	m_Velocity;
			float	m_Acceleration;
			float	m_Tolerance;
			float	m_BaseSpeed;				

		};

		class CumulativeFloatComponent
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			CumulativeFloatComponent(void);
			~CumulativeFloatComponent(void);

			// Public methods
			PRESENTATION_INLINE void			SetMaximum(float);
			PRESENTATION_INLINE const float		GetMaximum(void) const;
			PRESENTATION_INLINE void			SetMinimum(float);
			PRESENTATION_INLINE const float		GetMinimum(void) const;

			PRESENTATION_INLINE void			AddCurrent(const float);
			PRESENTATION_INLINE void			SetCurrent(const float);
			PRESENTATION_INLINE const float		GetCurrent(void) const;

			PRESENTATION_INLINE void			AddPrimaryDesired(const float);
			PRESENTATION_INLINE void			AddSecondaryDesired(const float);
			PRESENTATION_INLINE void			SetPrimaryDesired(const float);
			PRESENTATION_INLINE void			SetSecondaryDesired(const float);
			PRESENTATION_INLINE const float		GetPrimaryDesired(void) const;
			PRESENTATION_INLINE const float		GetSecondaryDesired(void) const;
			PRESENTATION_INLINE const float		GetDesired(void) const;

			bool								Update(float, bool bAngle=true);
			bool								UpdateImmediate(void);
			void								Immobilize(void);

			// Public operators
			CumulativeFloatComponent& operator =(const CumulativeFloatComponent&);
			CumulativeFloatComponent& Set(const CumulativeFloatComponent&,bool,bool,bool);

		private:

			// Public members
			CumulativeFloat		m_Data;			
			Float				m_Velocity;
			float				m_Acceleration;
			float				m_Tolerance;
			float				m_BaseSpeed;				

		};

		class Curve : public Gel::HermineCurve
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Curve(void);
			virtual ~Curve(void);

			// Public methods
			const Gel::AnimationKey*	AddAnimationKey(float fTime=0.0f, float fValue=0.0f);
			int							Evaluate(float *pValue, float fTime, float fDefaultValue=0.0f ) const;

			// Public operators
			Curve&	operator =(const Curve&);

		private:

			// Private constants
			static const int k_NbAnimationKeysMax = 24;

			// Private methods
			void	GetTangent( unsigned int iIndex, bool bIsWeighted, Axiom::Math::Vector2 &rIn, Axiom::Math::Vector2 &rOut) const;

			// Private reflection methods
			bool	AddAnimationKey_Reflection(float fTime,float fValue);
			bool	DeleteAnimationKey_Reflection(int);

			// Private data members
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Gel::AnimationKey> >	m_AnimationKeys;

		};

		class Iterator
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			Iterator(void);
			~Iterator(void);

			// Public methods
			float	Evaluate(float);

			// Public operators
			Iterator&	operator =(const Iterator&);

		private:

			// Private members
			ITERATOR_TYPE_e		m_IteratorType;
			float				m_Maximum;
			float				m_Minimum;
			float				m_Multiplicator;				

			// Private methods
			float				ApplyRange(float);
			float				ApplyMultiplicator(float);

		};

// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/camera/cameracurve.inl"
# endif

	}
}

#endif

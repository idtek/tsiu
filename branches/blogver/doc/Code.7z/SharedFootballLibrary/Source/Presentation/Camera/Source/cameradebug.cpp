
#ifndef _CAMERADEBUG_H_
# include "presentation/camera/source/cameradebug.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _VIEWPORT_H_
# include "presentation/camera/Viewport.h"
#endif

/*
#ifndef _PRESENTATIONMANAGER_H
# include "presentation/presentationmanager.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H
# include "presentation/simulatedpresentation.h"
#endif
*/

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Reflection declaration
AP_TYPE(CameraDebug)
	AP_BASE_TYPE(Camera)
	AP_FIELD("Body", m_Body, "Body")
	AP_FIELD("Zoom", m_Zoom, "Zoom")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraDebugControlled)
	AP_BASE_TYPE(CameraDebug)
	AP_DEFAULT_CREATE()
	AP_FIELD("IncZoom", m_IncZoom, "Inc Zoom")
	AP_FIELD("IncPosition", m_IncPosition, "Inc Position")
	AP_FIELD("IncOrientation", m_IncOrientation, "Inc Orientation")
	AP_PROXY("Camera")
AP_TYPE_END()

AP_TYPE(CameraDebugFar)
	AP_BASE_TYPE(CameraDebug)
	AP_DEFAULT_CREATE()
	AP_FIELD("Target", m_Target, "Target")
	AP_FIELD("AdditionalDistance", m_AdditionalDistance, "AdditionalDistance")
	AP_FIELD("AdditionalZoom", m_AdditionalZoom, "AdditionalZoom")
	AP_PROXY("Camera")
AP_TYPE_END()

// Camera debug
// ----------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraDebug::CameraDebug(const CAMERA_TYPE_e eType) : Camera(eType),
	m_Body(),
	m_Zoom()
{
	m_Zoom.SetDesired( VIEWPORT_FOV_DEFAULT );
	m_Zoom.UpdateImmediate();
}

/* virtual */ CameraDebug::~CameraDebug(void)
{
}

// Public virtual functions
/* virtual */ const Axiom::Math::Vector3& CameraDebug::GetCurrentBodyPosition(void) const
{
	return m_Body.GetCurrent();
}

/* virtual */ const float CameraDebug::GetCurrentRoll(void) const
{
	return 0.0f;
}

/* virtual */ const float CameraDebug::GetCurrentZoom(void) const
{
	return m_Zoom.GetCurrent();
}

/* virtual */ Point* CameraDebug::GetBodyPoint(void)
{
	return &m_Body;
}

/* virtual */ FloatComponent* CameraDebug::GetZoomComponent(void)
{
	return &m_Zoom;
}

/* virtual */ FloatComponent* CameraDebug::GetRollComponent(void)
{
	return NULL;
}

/* virtual */ void CameraDebug::Draw(const PresentationInput&, PresentationOutput*, const Orientation&, const unsigned int channel)
{
}

/* virtual */ void CameraDebug::DrawDebug(Camera*, const PresentationInput&, PresentationOutput*, const Orientation&, const unsigned int channel)
{
}

// Camera debug controlled
// ----------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraDebugControlled::CameraDebugControlled(void) : CameraDebug(CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_CONTROLLED),
	m_Pitch(0.0f),
	m_Heading(0.0f),
	m_IncZoom(CAMERADEBUG_INCZOOM_DEFAULT),
	m_IncPosition(CAMERADEBUG_INCPOSITION_DEFAUT),
	m_IncOrientation(CAMERADEBUG_INCORIENTATION_DEFAULT)
{
}

/* virtual */ CameraDebugControlled::~CameraDebugControlled(void)
{
}

// Public functions
const float CameraDebugControlled::GetPitch(void) const
{
	return m_Pitch;
}

const float CameraDebugControlled::GetHeading(void) const
{
	return m_Heading;
}

void CameraDebugControlled::UpdateOrientation(const Axiom::Math::Vector2 &rOrientation)
{
	Axiom::Math::Vector2 vOrientation = rOrientation * m_IncOrientation;
	if( vOrientation.Magnitude() > 0.0f )
	{
		m_Heading += vOrientation.X();
		m_Pitch -= vOrientation.Y();
	}
}

void CameraDebugControlled::UpdatePosition(const Axiom::Math::Vector3 &rPosition)
{
	if( rPosition.Magnitude() > CAMERA_EPSILON )
	{
		Axiom::Math::Vector3 vOffset = rPosition.AsNormal();
		vOffset *= m_IncPosition;
//		vOffset = RotateX(vOffset, m_Pitch );		// Uncomment if you want the pitch to affect the direction of the camera
		vOffset = RotateZ(vOffset, -m_Heading );	
		
		m_Body.AddDesired( vOffset );
	}
	else
	{
		m_Body.Immobilize();
	}
}

void CameraDebugControlled::UpdateZoom(const float fZoom)
{
	if( Axiom::Math::FloatAbs( fZoom ) > CAMERA_EPSILON )
	{
		m_Zoom.AddDesired( fZoom * m_IncZoom );
	}
	else 
	{
		m_Zoom.Immobilize();
	}
}

// Public virtual functions
/* virtual */ const Axiom::Math::Vector3& CameraDebugControlled::GetCurrentTargetPosition(void) const
{
	static Axiom::Math::Vector3 s_TargetPosition;
		
	// Compute a static target position
	Orientation tOrientation;
	tOrientation.Set( m_Body.GetCurrent(), m_Heading, m_Pitch, 0.0f );
	s_TargetPosition = tOrientation.GetFront() * CAMERADEBUG_TARGET_DISTANCE;

	return s_TargetPosition;
}

/* virtual */ const Framing& CameraDebugControlled::GetCurrentFraming(void) const
{
	static Framing s_Framing;

	// Compute a static framing
	s_Framing.Adjust(m_Body.GetCurrent(), GetCurrentTargetPosition(), m_Zoom.GetCurrent(), GetCurrentRoll() );

	return s_Framing;
}

/* virtual */ const Orientation CameraDebugControlled::GetOrientation(void)
{
	return Orientation( m_Body.GetCurrent(), m_Heading, m_Pitch, 0.0f );
}

/* virtual */  Point* CameraDebugControlled::GetTargetPoint(void)
{
	return NULL;
}

/* virtual */ Framing* CameraDebugControlled::GetFraming(void)
{
	return NULL;
}

/* virtual */ void CameraDebugControlled::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	Framing tFraming = pSource->GetCurrentFraming();
	m_Body.SetDesired( tFraming.GetBodyPosition() );
	m_Body.UpdateImmediate();
	Yaw tYaw( tFraming.GetBodyPosition(), tFraming.GetTargetPosition() );
	m_Pitch = tYaw.GetPitch();
	m_Heading = tYaw.GetHeading();
	m_Zoom.SetDesired( pSource->GetCurrentZoom() );
	m_Zoom.UpdateImmediate();
}

/* virtual */ void CameraDebugControlled::Reset(bool)
{
}

/* virtual */ int CameraDebugControlled::Update(float fDeltaTime, const PresentationInput&)
{
	int iResult = CAMERA_UPDATEREPORT_NONE;

	if( m_Body.Update( fDeltaTime ) )
	{
		iResult |= CAMERA_UPDATEREPORT_BODY;
	}
	if( m_Zoom.Update( fDeltaTime ) )
	{
		iResult |= CAMERA_UPDATEREPORT_ZOOM;
	}

	return iResult;
}

/* virtual */ int CameraDebugControlled::UpdateDebug(Camera*, float fDeltaTime, const PresentationInput &rInput)
{
	return Update(fDeltaTime,rInput);
}

// Camera debug far
// ----------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
CameraDebugFar::CameraDebugFar(void) : CameraDebug(CAMERA_TYPE_e::CAMERA_TYPE_DEBUG_FAR),
	m_Target(),
	m_AdditionalDistance(0.0f),
	m_AdditionalZoom(0.0f)
{
}

/* virtual */ CameraDebugFar::~CameraDebugFar(void)
{
}

// Public virtual functions
/* virtual */ const Axiom::Math::Vector3& CameraDebugFar::GetCurrentTargetPosition(void) const
{
	static Axiom::Math::Vector3 s_TargetPosition;
		
	// Compute a static target position
	Orientation tOrientation;
	tOrientation.Set( m_Body.GetCurrent(), m_Target.GetCurrent(), 0.0f );
	s_TargetPosition = tOrientation.GetFront() * CAMERADEBUG_TARGET_DISTANCE;
	return s_TargetPosition;
}

/* virtual */ const Framing& CameraDebugFar::GetCurrentFraming(void) const
{
	static Framing s_Framing;

	// Compute a static framing
	s_Framing.Adjust(m_Body.GetCurrent(), GetCurrentTargetPosition(), m_Zoom.GetCurrent(), GetCurrentRoll() );
	return s_Framing;
}

/* virtual */ const Orientation CameraDebugFar::GetOrientation(void)
{
	return Orientation( m_Body.GetCurrent(), m_Target.GetCurrent(), 0.0f );
}

/* virtual */  Point* CameraDebugFar::GetTargetPoint(void)
{
	return &m_Target;
}

/* virtual */ Framing* CameraDebugFar::GetFraming(void)
{
	return NULL;
}

/* virtual */ void CameraDebugFar::CopyData(Camera *pSource)
{
	PRESENTATION_ASSERT( pSource != NULL, "Camera Error: NULL pointer passed!\n" );

	Framing tFraming = pSource->GetCurrentFraming();
	m_Body.SetDesired( tFraming.GetBodyPosition() );
	m_Body.UpdateImmediate();
	m_Target.SetDesired( pSource->GetCurrentTargetPosition() );
	m_Target.UpdateImmediate();
	m_Zoom.SetDesired( pSource->GetCurrentZoom() );
	m_Zoom.UpdateImmediate();
}

/* virtual */ void CameraDebugFar::Reset(bool)
{
}

/* virtual */ int CameraDebugFar::Update(float fDeltaTime, const PresentationInput&)
{
	int iResult = CAMERA_UPDATEREPORT_NONE;

	if( m_Body.Update( fDeltaTime ) )
	{
		iResult |= CAMERA_UPDATEREPORT_BODY;
	}
	if( m_Target.Update( fDeltaTime ) )
	{
		iResult |= CAMERA_UPDATEREPORT_TARGET;
	}
	if( m_Zoom.Update( fDeltaTime ) )
	{
		iResult |= CAMERA_UPDATEREPORT_ZOOM;
	}

	return iResult;
}

/* virtual */ int CameraDebugFar::UpdateDebug(Camera *pCamera, float fDeltaTime, const PresentationInput &rInput)
{
	// Update the camera
	int iResult = pCamera->Update(fDeltaTime,rInput);

	// Add the distance information
	Axiom::Math::Vector3	vDelta = pCamera->GetCurrentBodyPosition() - pCamera->GetCurrentTargetPosition();
	float					fMagnitude = vDelta.Magnitude();
	if( fMagnitude > 0.0f )
	{
		vDelta /= fMagnitude;
		vDelta *= m_AdditionalDistance;

		m_Body.SetCurrent( pCamera->GetCurrentBodyPosition() + vDelta );
		m_Target.SetCurrent( pCamera->GetCurrentTargetPosition() );
	}

	// Add the zoom
	m_Zoom.SetCurrent( pCamera->GetCurrentZoom() + m_AdditionalZoom );

	return iResult;
}


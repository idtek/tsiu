#pragma once

#ifndef  _PRESENTATION_UTILS_H_
# define _PRESENTATION_UTILS_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _CAMERA_DEFINES_H
#  include "presentation/camera/camera_defines.h"
# endif
# ifndef _CAMERACURVE_H_
#  include "presentation/camera/cameracurve.h"
# endif

# ifndef _AP_ENTITY
#  include "gamedata/entity.h"
# endif

# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif
# ifndef __CORE_VECTOR3_H
#  include <math/vector3.h>
# endif
# ifndef __CORE_VECTOR4_H
#  include <math/vector4.h>
# endif
# ifndef __CORE_FRUSTUM_H
#  include "shape/frustum.h"
# endif
# ifndef _CRC_H
#  include <core/crc.h>
# endif
# ifndef _CORE_TIME_H
#  include <core/time.h>
# endif
# ifndef __COLLECTIONS_GENERIC__LIST_H
#  include <collections/list.h>
# endif
# ifndef GRAPHICS_COLOR_H
#  include <graphics/color.h>
# endif
# ifndef AP_INSTANCE_H
#  include <reflection/instance.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class Camera;
		class DebugDrawing;
		class PresentationInput;
		class PresentationOutput;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM_REFLECTED(	TRACKING_OFFSETTYPE_e,\
								CLASSEDENUM_ITEMWITHVALUE(TRACKING_OFFSETTYPE_INVALID, -1) \
								CLASSEDENUM_ITEM(TRACKING_OFFSETTYPE_STATIC) \
								CLASSEDENUM_ITEM(TRACKING_OFFSETTYPE_ENTITYRELATIVE) \
								CLASSEDENUM_ITEM(TRACKING_NBOFFSETTYPES) \
								,TRACKING_OFFSETTYPE_INVALID)

		CLASSEDENUM_REFLECTED(	TRACKING_TYPE_e, \
								CLASSEDENUM_ITEMWITHVALUE(TRACKING_TYPE_INVALID, -1) \
								CLASSEDENUM_ITEM(TRACKING_TYPE_SINGLEPOINT) \
								CLASSEDENUM_ITEM(TRACKING_TYPE_MIDDLEPOINT) \
								CLASSEDENUM_ITEM(TRACKING_TYPE_MULTIPLEPOINTS) \
								CLASSEDENUM_ITEM(TRACKING_NBTYPES) \
								,TRACKING_TYPE_INVALID)
		
		CLASSEDENUM_REFLECTED(	SHAPE_TYPE_e, \
								CLASSEDENUM_ITEMWITHVALUE(SHAPE_TYPE_INVALID, -1) \
								CLASSEDENUM_ITEM(SHAPE_TYPE_RECTANGLE) \
								CLASSEDENUM_ITEM(SHAPE_TYPE_ORIENTEDRECTANGLE) \
								CLASSEDENUM_ITEM(SHAPE_TYPE_CIRCLE) \
								CLASSEDENUM_ITEM(SHAPE_NBTYPES) \
								,SHAPE_TYPE_INVALID)

		CLASSEDENUM_REFLECTED(	VOLUME_TYPE_e, \
								CLASSEDENUM_ITEMWITHVALUE(VOLUME_TYPE_INVALID, -1) \
								CLASSEDENUM_ITEM(VOLUME_TYPE_BOX) \
								CLASSEDENUM_ITEM(VOLUME_TYPE_SPHERE) \
								CLASSEDENUM_ITEM(VOLUME_NBTYPES) \
								,VOLUME_TYPE_INVALID)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		enum TRACKING_REPORT_e
		{
			TRACKING_REPORT_NONE				= 0,
			TRACKING_REPORT_POSITION			= 0x01,
			TRACKING_REPORT_FACING				= 0x02,
			TRACKING_REPORT_ENTITYID			= 0x04,
			TRACKING_REPORT_PROPOSEDDISTANCE	= 0x08,
			TRACKING_REPORT_PROPOSEDHEADING		= 0x10
		};

		enum BOUNDARY_TYPE_e
		{
			BOUNDARY_TYPE_NONE = 0,
			BOUNDARY_TYPE_BODY,
			BOUNDARY_TYPE_TARGET
		};

		enum BOUNDARY_AXIS_e
		{
			BOUNDARY_AXIS_NONE = 0,
			BOUNDARY_AXIS_X,
			BOUNDARY_AXIS_Y,
			BOUNDARY_AXIS_Z,
		};

		class BaseShape : public Axiom::Referenced
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			BaseShape(void);
			BaseShape(const SHAPE_TYPE_e&);
			~BaseShape(void);
				
			// Public methods
			PRESENTATION_INLINE void				SetShapeType(const SHAPE_TYPE_e&);
			PRESENTATION_INLINE const SHAPE_TYPE_e	GetShapeType(void) const;

			void									SetCenter(const Axiom::Math::Vector2&);
			void									SetCenter(const float, const float);
			const Axiom::Math::Vector2&				GetCenter(void) const;

			void									SetOrientation(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE const float			GetOrientation(void) const;

			bool									IsIn(const Axiom::Math::Vector3&);
			const Axiom::Math::Vector3				CameraRestrain(const Axiom::Math::Vector3&,const Camera*,const BOUNDARY_TYPE_e&);
			const Axiom::Math::Vector3				Restrain(const Axiom::Math::Vector3&);
			const Axiom::Math::Vector3				Constrain(const Axiom::Math::Vector3&);
			
			// Public virtual functions
			virtual const float						GetRay(void) const = 0;
			virtual const float						GetWidth(void) const = 0;
			virtual const float						GetHeight(void) const = 0;

		protected:

			// Protected members
			SHAPE_TYPE_e			m_Type;
			Axiom::Math::Vector2	m_Center;
			float					m_Orientation;

		private:

			// Private functions
			Axiom::Math::Vector2	ConstrainOrientedRectangle(const Axiom::Math::Vector3&);
			bool					IsInOrientedRectangle(const Axiom::Math::Vector3&);

		};

		class Shape : public BaseShape
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Shape(void);
			Shape(const SHAPE_TYPE_e&);
			~Shape(void);
			
			// Public methods
			void						SetSize(const float, const float fHeight=0.0f);

			// Public operators
			Shape&						operator =(const Shape&);
			Shape&						Set(const Shape&);

			// Public virtual functions
			/* virtual */ const float	GetRay(void) const;
			/* virtual */ const float	GetWidth(void) const;
			/* virtual */ const float	GetHeight(void) const;

		protected:

			// Protected members
			float					m_Width;
			float					m_Height;

		};

		class FlexibleShape : public BaseShape
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			FlexibleShape(void);
			FlexibleShape(const SHAPE_TYPE_e&);
			~FlexibleShape(void);
				
			// Public methods
			void						Update(float);

			FloatComponent*				GetWidthComponent(void);
			FloatComponent*				GetHeightComponent(void);

			// Public operators
			FlexibleShape&				operator =(const FlexibleShape&);
			FlexibleShape&				Set(const FlexibleShape&,bool,bool,bool,bool);
			FlexibleShape&				SetCurrent(const Shape&);
			FlexibleShape&				SetDesired(const Shape&);

			// Public virtual functions
			/* virtual */ const float	GetRay(void) const;
			/* virtual */ const float	GetWidth(void) const;
			/* virtual */ const float	GetHeight(void) const;

		protected:

			// Protected data
			FloatComponent	m_Width;
			FloatComponent	m_Height;

		};

		class BaseVolume
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			BaseVolume(void);
			BaseVolume(const VOLUME_TYPE_e&);
			virtual ~BaseVolume(void);
				
			// Public methods
			PRESENTATION_INLINE void				SetVolumeType(const VOLUME_TYPE_e&);
			PRESENTATION_INLINE const VOLUME_TYPE_e	GetVolumeType(void) const;

			void									SetCenter(const float, const float, const float);
			void									SetCenter(const Axiom::Math::Vector3&);
			const Axiom::Math::Vector3&				GetCenter(void) const;

			bool									IsIn(const Axiom::Math::Vector3&);
			const Axiom::Math::Vector3				CameraRestrain(const Axiom::Math::Vector3&,const Camera*,const BOUNDARY_TYPE_e&);
			const Axiom::Math::Vector3				Restrain(const Axiom::Math::Vector3&);
			const Axiom::Math::Vector3				Constrain(const Axiom::Math::Vector3&);

			// Frustum specific
			bool									IsFullyInFrustum(SharedSoccer::Shape::Frustum*) const;
			bool									IsInFrustum(SharedSoccer::Shape::Frustum*) const;
			float									GetDistanceFromFrustumPlane(SharedSoccer::Shape::Frustum*,SharedSoccer::Shape::Frustum::PLANE_e) const;

			// Public virtual functions
			virtual const float						GetRay(void) const = 0;
			virtual const float						GetWidth(void) const = 0;
			virtual const float						GetHeight(void) const = 0;
			virtual const float						GetDepth(void) const = 0;

		protected:

			// Protected data
			VOLUME_TYPE_e			m_Type;
			Axiom::Math::Vector3	m_Center;

		};

		class Volume : public BaseVolume
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Volume(void);
			Volume(const VOLUME_TYPE_e&);
			~Volume(void);
				
			// Public methods
			void						SetSize(const float, const float fHeight=0.0f, const float fDepth=0.0f);

			// Public operators
			Volume&						operator =(const Volume&);
			Volume&						Set(const Volume&);

			// Public virtual functions
			/* virtual */ const float	GetRay(void) const;
			/* virtual */ const float	GetWidth(void) const;
			/* virtual */ const float	GetHeight(void) const;
			/* virtual */ const float	GetDepth(void) const;

		protected:

			// Protected members
			float					m_Width;
			float					m_Height;
			float					m_Depth;

		};

		class FlexibleVolume : public BaseVolume
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			FlexibleVolume(void);
			FlexibleVolume(const VOLUME_TYPE_e&);
			~FlexibleVolume(void);
				
			// Public methods
			void						Update(float);

			FloatComponent*				GetWidthComponent(void);
			FloatComponent*				GetHeightComponent(void);
			FloatComponent*				GetDepthComponent(void);

			// Public operators
			FlexibleVolume&				operator =(const FlexibleVolume&);
			FlexibleVolume&				Set(const FlexibleVolume&,bool,bool,bool,bool,bool,bool);
			FlexibleVolume&				SetCurrent(const Volume&);
			FlexibleVolume&				SetDesired(const Volume&);

			// Public virtual functions
			/* virtual */ const float	GetRay(void) const;
			/* virtual */ const float	GetWidth(void) const;
			/* virtual */ const float	GetHeight(void) const;
			/* virtual */ const float	GetDepth(void) const;

		protected:

			// Protected data
			FloatComponent	m_Width;
			FloatComponent	m_Height;
			FloatComponent	m_Depth;

		};

		class Yaw
		{
		public:
			
			// Constructor & destructor
			Yaw(void);
			Yaw(const Axiom::Math::Vector3&, const Axiom::Math::Vector3&);
			~Yaw(void);

			// Public methods
			PRESENTATION_INLINE const float GetPitch(void);
			PRESENTATION_INLINE const float GetHeading(void);

		private:

			// Private data members
			float m_Pitch;
			float m_Heading;

		};

		class Framing
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			Framing(void);
			Framing(const Axiom::Math::Vector2&);
			~Framing(void);

			// Public methods
			void											SetOffset(const Axiom::Math::Vector2&);
			PRESENTATION_INLINE const Axiom::Math::Vector2&	GetOffset(void) const;
			PRESENTATION_INLINE const Axiom::Math::Vector3&	GetBodyPosition(void) const;
			PRESENTATION_INLINE const Axiom::Math::Vector3&	GetTargetPosition(void) const;
			void											Adjust(const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const float, const float);

		private:

			// Private members
			Axiom::Math::Vector2	m_Offset;					

			Axiom::Math::Vector3	m_FramedBodyPosition;
			Axiom::Math::Vector3	m_FramedTargetPosition;

		};

		class TrackingData
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructors
			TrackingData(void);
			TrackingData(const TrackingData&);

			// Copy operator
			void operator=(const TrackingData&);

			// Data
			AP::Reflection::AutoInstance  /* TRACKING_ENTITY_e */		m_Tracking;			
			AP::Reflection::AutoInstance  /* TRACKING_ENTITYBONE_e */	m_TrackingBone;		
			float														m_Weight;
			TRACKING_OFFSETTYPE_e										m_OffsetType;		
			Axiom::Math::Vector3										m_Offset;
			float														m_VolumeSize;
			bool														m_ForcedToBeIncluded;

		};

		class TrackingResult
		{
		public:

			TrackingResult(void);

			int							m_Report;
			SharedSoccer::EntityGUID	m_EntityID;
			float						m_ProposedDeltaDistance;
			float						m_ProposedDeltaHeading;
			Axiom::Math::Vector3		m_Position;
			Axiom::Math::Vector3		m_Facing;

		};

		class Tracking : public Axiom::Referenced
		{
		public:

			// Public constants
			static const int	k_NbTrackingsMax = 4;

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Tracking(void);
			Tracking(const TrackingData&);
			~Tracking(void);

			// Public static methods
			static TrackingResult TrackEntities(Axiom::Collections::ReflectedList<Axiom::SmartPtr<Tracking> >&, int, const PresentationInput&, Camera *pCamera=NULL);

			// Public methods
			PRESENTATION_INLINE const bool					IsForcedToBeIncluded(void) const;
			PRESENTATION_INLINE const bool					IsTracked(void) const;
			PRESENTATION_INLINE const Axiom::Math::Vector3	GetOffset(void) const;
			PRESENTATION_INLINE const TRACKING_OFFSETTYPE_e	GetOffsetType(void) const;
			PRESENTATION_INLINE const float					GetVolumeSize(void) const;

			void											SetTrackedPosition(const Axiom::Math::Vector3&);
			void											SetOffsetTrackedPosition(const Axiom::Math::Vector3&);
			PRESENTATION_INLINE void						ResetPosition(void);
			PRESENTATION_INLINE const Axiom::Math::Vector3	GetTrackedPosition(void) const;
			PRESENTATION_INLINE const Axiom::Math::Vector3	GetOffsetTrackedPosition(void) const;
			PRESENTATION_INLINE bool						IsTrackingValid(void) const;
			PRESENTATION_INLINE bool						IsTrackingBoneValid(void) const;

			// Public operators
			Tracking&	operator =(const Tracking&);
			Tracking&	Set(const TrackingData&,bool,bool,bool);

			// Template accessors
			template <typename T> inline const T& GetTrackingEntity(void);
			template <typename T> inline const T& GetTrackingEntityBone(void);


		private:

			// Private members
			TrackingData			m_Data;

			bool					m_Tracked;			
			Axiom::Math::Vector3	m_TrackedPosition;
			Axiom::Math::Vector3	m_OffsetTrackedPosition;

		};

		// Template accessors
		template <typename T> inline const T& Tracking::GetTrackingEntity(void)
		{
			return m_Data.m_Tracking.Get().As<T>();
		}

		template <typename T> inline const T& Tracking::GetTrackingEntityBone(void)
		{
			return m_Data.m_TrackingBone.Get().As<T>();
		}

		class Noise
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor		
			Noise(void);
			~Noise(void);

			// Public methods
			void						Reset(float fMagnitudeModifier = 1.0f);
			void						Init(float fDuration = -1.0f, float fMagnitudeModifier = 1.0f);
			bool						Update(float);
			const Axiom::Math::Vector3	GetMagnitudeVector(void);
			float						GetTimeIntervalForUpdate() const { return 1.0f / m_Frequency; }
			float						GetFrequency() const { return m_Frequency; }

		private:

			// Private member data: Set in reflection by user
			float	m_Magnitude;
			float	m_Duration;
			float	m_Frequency;

			// Private member data: Controlled by code to create the shake
			float	m_InitialDuration;
			float	m_MagnitudeScale;
			float	m_CurrentMagnitude;
			float	m_CurrentTime;
			float	m_UpdateTime;
			Axiom::Math::Vector3 m_Noise;

		};

		class Colour
		{
		public:

			AP_DECLARE_TYPE();

			Colour();
			Colour(float R, float G, float B, float A);
			Colour(Axiom::Math::Vector4& colour);

			PRESENTATION_INLINE float	R(void);
			PRESENTATION_INLINE float	G(void);
			PRESENTATION_INLINE float	B(void);
			PRESENTATION_INLINE float	A(void); 

			PRESENTATION_INLINE void	R(float);
			PRESENTATION_INLINE void	G(float);
			PRESENTATION_INLINE void	B(float);
			PRESENTATION_INLINE void	A(float);

			Axiom::Math::Vector4		Get(void) const;
			void						Set(Axiom::Math::Vector4&);
			void						Set(float,float,float,float);
			void						Set(int,int,int,int);

			Graphics::Color				GetAsRGBA(void);

			bool operator==( const Colour& other ) const;

			inline bool operator !=( const Colour& other ) const { return !(*this == other ); }

		private:

			float m_A;
			float m_R;
			float m_G;
			float m_B;

		};

		// Util functions
		const float NormalizeAngle(const float);

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/presentation_utils.inl"
# endif

	}
}

#endif

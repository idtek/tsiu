#pragma once

#ifndef  _PRESENTATION_EVENTS_H_
# define _PRESENTATION_EVENTS_H_

# ifndef _SEQUENCE_H_
#  include "presentation/sequence/sequence.h"
# endif
# ifndef  _SIMULATEDPRESENTATION_H_
#  include "presentation/simulatedpresentation.h"
# endif

# ifndef _EVENTMAN_H__
#  include <eventsystem/eventman.h>
# endif
# ifndef __MESSAGES_H
#  include <kernel/messages.h>
# endif

#ifndef  _PRESENTATION_UTILS_H_
# include "presentation/presentation_utils.h"
#endif

namespace AP
{
	namespace Events
	{
		//-----------------------------------------------------------------------------------------------------------------------------------
		class PresentationAnalogInputEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( PresentationAnalogInputEvent);

			int						m_ControllerID;
			int						m_AnalogID;
			Axiom::Math::Vector2	m_Movement;

			PresentationAnalogInputEvent() : EventMsg(EVENT_GUID)
			{
			}

			PresentationAnalogInputEvent(int iControllerID, int iAnalogID, const Axiom::Math::Vector2& vMovement) :	EventMsg(EVENT_GUID),
				m_ControllerID(iControllerID),
				m_AnalogID(iAnalogID),
				m_Movement(vMovement)
			{
			}
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class PresentationDigitalInputEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( PresentationDigitalInputEvent);

			int										m_ControllerID;
			SharedSoccer::Presentation::BUTTON_e	m_Button;

			PresentationDigitalInputEvent() : EventMsg(EVENT_GUID)
			{
			}

			PresentationDigitalInputEvent(int iControllerID, SharedSoccer::Presentation::BUTTON_e eButton) : EventMsg(EVENT_GUID),
				m_ControllerID(iControllerID),
				m_Button(eButton)
			{
			}

			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class PresentationUpdateViewportEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( PresentationUpdateViewportEvent );

			Axiom::Math::Vector3	m_Position;
			Axiom::Math::Vector3	m_Front;
			Axiom::Math::Vector3	m_Up;
			Axiom::Math::Vector3	m_Right;

			PresentationUpdateViewportEvent() : EventMsg(EVENT_GUID)
			{
			}

			PresentationUpdateViewportEvent(Axiom::Math::Vector3 vPosition, Axiom::Math::Vector3 vFront, Axiom::Math::Vector3 vUp, Axiom::Math::Vector3 vRight) : EventMsg(EVENT_GUID),
				m_Position(vPosition),				
				m_Front(vFront),
				m_Up(vUp),
				m_Right(vRight)
			{
			}
		};

	}
}


#endif

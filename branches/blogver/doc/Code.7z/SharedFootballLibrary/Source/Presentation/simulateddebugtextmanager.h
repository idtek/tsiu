#pragma once

#ifndef  _SIMULATED_DEBUG_TEXT_H_
# define _SIMULATED_DEBUG_TEXT_H_


#  ifndef _PRESENTATION_CONFIG_H_
#   include "presentation/presentation_config.h"
#  endif
#  ifndef  _PRESENTATION_DEFINES_H_
#   include "presentation/presentation_defines.h"
#  endif

#  ifndef _CORE_TIME_H
#   include <core/time.h>
#  endif
#  ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#   include <collections/list.h>
#  endif
#  ifndef __CORE_VECTOR2_H
#   include <math/vector2.h>
#  endif

// K.Fos temp spot for this... maybe we should do soimething more elegant in the core library
#if CORE_USERDEBUG==CORE_YES
static int s_LogPersistentCount = 0;
static int s_LogPersistentRepeatIndex = 250;
	#define INTERMITTENTLY_LOG_PERSISTENT_MESSAGE(A, ...) \
		if(s_LogPersistentCount % s_LogPersistentRepeatIndex == 0) \
		{ \
			Axiom::Log(A, __VA_ARGS__); \
		} 
#else
	#define INTERMITTENTLY_LOG_PERSISTENT_MESSAGE(A, ...)
#endif


# if CORE_USERDEBUG == CORE_YES

namespace SharedSoccer
{
	namespace Presentation
	{
		class PresentationOutput;

		class SimulatedDebugTextElement
		{
		public:

			// Constructor & destructor
			SimulatedDebugTextElement(const Axiom::ShortString&, float);
			~SimulatedDebugTextElement(void);

			// Public methods
			PRESENTATION_INLINE const Axiom::ShortString&	GetText(void) const;
			PRESENTATION_INLINE void						SetText(const Axiom::ShortString&);
			PRESENTATION_INLINE float						GetRemoveTime(void) const;
			PRESENTATION_INLINE void						SetRemoveTime(float);

		private:

			Axiom::ShortString		m_Text;
			float					m_RemoveTime;

		};

		class SimulatedDebugTextManager
		{
		public:

			// Constructor & destructor
			SimulatedDebugTextManager(const Axiom::Math::Vector2 vPosition=Axiom::Math::Vector2(PRESENTATION_DEBUGTEXT_POSITIONX_DEFAULT, PRESENTATION_DEBUGTEXT_POSITIONY_DEFAULT) );
			~SimulatedDebugTextManager(void);

			// Public methods
			PRESENTATION_INLINE void	SetPosition(const Axiom::Math::Vector2&);
			void						AddText(const Axiom::ShortString&, float);
			void						Reset(void);
			void						Update(const Axiom::TimeAbsolute&,PresentationOutput*);

		private:

			Axiom::Collections::StaticList<SimulatedDebugTextElement, 
										   PRESENTATION_DEBUGTEXT_NBLINES_MAX>	m_DebugTextList;
			Axiom::Math::Vector2												m_Position;
			float																m_CurrentTime;

		};
# ifdef PRESENTATON_USE_INLINE
#  include "presentation/simulateddebugtextmanager.inl"
# endif
	}
}

# endif 

#endif 

#pragma once

#ifndef  _PRESENTATIONOUTPUT_H_
# define _PRESENTATIONOUTPUT_H_

# ifndef _VIEWPORT_H
#  include "presentation/camera/viewport.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif
# ifndef _PARTICLE_SYSTEM_DEFINITION_H
#  include "particles/particlesystemdefinition.h"
# endif
# ifndef _PARTICLE_ELEMENT_DATA_H
#  include "particles/particleelementdata.h"
# endif


# ifndef GRAPHICS_COLOR_H
#  include <graphics/color.h>
# endif

// Forward declarations
namespace SharedSoccer
{
	namespace Shape
	{
		class Box;
		class Cylinder;
	}
}


// Code
namespace SharedSoccer
{
	namespace Presentation
	{
		static const int LINE_LIST_SIZE = 16;
		typedef Axiom::Collections::StaticList<Axiom::Math::Vector3, LINE_LIST_SIZE> LineList;

		// Class
		class PresentationOutput
		{
		public:

			// Constructor and virtual destructor
			explicit PresentationOutput(void);
			virtual ~PresentationOutput(void);
			
			// Public functions
			void NotifyViewportChange( const Orientation& );

			// Public virtual functions
			virtual void ExportViewportData( VIEWPORT_USAGE_e, const Orientation&, const float, 
											const float, const float, const float, const Axiom::Math::Vector3& pointerValue );

			virtual void ExportBakedViewportData(const Axiom::CRC& rBakedCameraID, 
												const float bakedCameraTime,
												const Axiom::Math::Quaternion& rBaseRotation, 
												const Axiom::Math::Vector3& rBasePosition,
												const float fov,
												const bool useCurvedPitchCalc,
												const SharedSoccer::Presentation::ViewportCameraData& rSourceCamera,
												const float blendFraction);


			virtual void ExportPRSElementData(	const Axiom::Math::Matrix4& transform,
												const Axiom::Math::Quaternion& rotation,
												float frame,
												const Axiom::StripStringCRC& prsControllerName,
												const Axiom::StripStringCRC& clusterName,
												const SharedSoccer::Presentation::PRS_DRAW_ORDER_e& prsDrawOrder,
												const Axiom::CRC& sceneHashName,
												bool prsRequiresUpdating,
												bool clusterRequiresDrawing );


			 virtual  void ExportParticleData(	const Axiom::StripStringCRC& systemID,
												Particle::ParticleSystemDefinition_c* def,
												float elapsedTime,
												const Particle::ParticleTransformDataArray& transformData,
												char revisionNumber);

			virtual void Draw2DText(float,float,const char*,const Graphics::Color&);

			virtual void DrawLine( const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const Graphics::Color&, const unsigned int channel );
			virtual void DrawSphere( const Axiom::Math::Vector3&, const float, const Graphics::Color&, const unsigned int channel );
			virtual void DrawVolume( const BaseVolume&, const Graphics::Color&, const unsigned int channel );
			virtual void DrawShape( const BaseShape&, const Graphics::Color&, const unsigned int channel, float fZ=0 );
			virtual void DrawPoint( const Point&, const unsigned int channel );
			virtual void DrawArrow( const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const Graphics::Color&, const unsigned int channel );
			virtual void DrawCylinder( const Axiom::Math::RigidMatrix&, const SharedSoccer::Shape::Cylinder&, const Graphics::Color&, const unsigned int numSubdivisions, const unsigned int channel );
			virtual void DrawBox( const Axiom::Math::RigidMatrix&, const SharedSoccer::Shape::Box&, const Graphics::Color&, const unsigned int channel );

			virtual void DrawLineList( const LineList&, const Graphics::Color&, const unsigned int channel );

		};
	}
}

#endif

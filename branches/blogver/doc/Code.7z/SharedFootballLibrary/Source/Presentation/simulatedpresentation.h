#pragma once

#ifndef  _SIMULATEDPRESENTATION_H_
# define _SIMULATEDPRESENTATION_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _SEQUENCEMANAGER_H_
#  include "presentation/sequence/sequencemanager.h"
# endif
# ifndef  _SIMULATED_DEBUG_TEXT_H
#  include "presentation/simulateddebugtextmanager.h"
# endif
# ifndef _SIMULATED_PRSMANAGER_H
#  include "prs/simulatedprsmanager.h"
# endif

# ifndef __CORE_EVENT_MESSAGE_BOX_H
#  include <eventsystem/eventmsgbox.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 1

		// TODO: Move that to title specific
		CLASSEDENUM_REFLECTED(	BUTTON_e,\
						CLASSEDENUM_ITEMWITHVALUE(BUTTON_INVALID, -1)\
						CLASSEDENUM_ITEM(BUTTON_ZOOMIN)\
						CLASSEDENUM_ITEM(BUTTON_ZOOMOUT)\
						CLASSEDENUM_ITEM(BUTTON_MOVEUP_FAST)\
						CLASSEDENUM_ITEM(BUTTON_MOVEUP_NORMAL)\
						CLASSEDENUM_ITEM(BUTTON_MOVEUP_SLOW)\
						CLASSEDENUM_ITEM(BUTTON_MOVEDOWN_FAST)\
						CLASSEDENUM_ITEM(BUTTON_MOVEDOWN_NORMAL)\
						CLASSEDENUM_ITEM(BUTTON_MOVEDOWN_SLOW)\
						CLASSEDENUM_ITEM(BUTTON_MOVEUP)\
						CLASSEDENUM_ITEM(BUTTON_MOVEDOWN)\
						CLASSEDENUM_ITEM(BUTTON_TOGGLETRACKING)\
						CLASSEDENUM_ITEM(BUTTON_TOGGLECAMERA)\
						CLASSEDENUM_ITEM(BUTTON_ROTATELEFT)\
						CLASSEDENUM_ITEM(BUTTON_ROTATERIGHT)\
						CLASSEDENUM_ITEM(BUTTON_TOGGLEDEBUGMODE)\
						CLASSEDENUM_ITEM(BUTTON_INCREASEDEBUGINDEX)\
						CLASSEDENUM_ITEM(BUTTON_DECREASEDEBUGINDEX)\
						CLASSEDENUM_ITEM(BUTTON_INCREASEDEBUGARRAYINDEX)\
						CLASSEDENUM_ITEM(BUTTON_DECREASEDEBUGARRAYINDEX)\
						CLASSEDENUM_ITEM(BUTTON_TOGGLEDEBUGFARCAMERA)\
						CLASSEDENUM_ITEM(BUTTON_SKIPNIS)\
						CLASSEDENUM_ITEM(NBBUTTONS),\
						BUTTON_INVALID)

# undef  INVALIDITEMS
# define INVALIDITEMS 0
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS
		class SimulatedPresentationControl : public Axiom::Singleton<SimulatedPresentationControl>
		{
		public:

			// Constructor & destructor
			SimulatedPresentationControl(void);
			~SimulatedPresentationControl(void);

			// Public methods
			void						SetPosition(const Axiom::Math::Vector2&);
			void						SetOrientation(const Axiom::Math::Vector2&);
			PRESENTATION_INLINE void	SetButton(int);
			PRESENTATION_INLINE void	UpdateButtons(int);
			PRESENTATION_INLINE void	ResetButtons(void);

			const Axiom::Math::Vector2&	GetPosition(void);
			const Axiom::Math::Vector2& GetOrientation(void);
			const bool					IsButtonPressed(const BUTTON_e);
			const bool					IsButtonPressedOnce(const BUTTON_e);
			const bool					IsInDebugMode(void);

		private:		

			// Private data
			Axiom::Math::Vector2	m_Position;
			Axiom::Math::Vector2	m_Orientation;
			int						m_CurrentButtons;
			int						m_PreviousButtons;

		};

		class SimulatedPresentation_Interface
		{
		public:

			// Constructor & virtual destructor
			SimulatedPresentation_Interface(void);
			virtual ~SimulatedPresentation_Interface(void);

			// Public virtual functions
			virtual void	RegisterEvents(Axiom::EventMsgBoxHandle) = 0;
			virtual void	HandleEvents(Axiom::EventMsgBoxHandle, const PresentationInput&, PresentationOutput*) = 0;

			virtual void	Init(void) = 0;
			virtual void	Reset(void) = 0;

			virtual void	Update(float, const PresentationInput&, PresentationOutput*) = 0;

		};

		class SimulatedPresentation
		{
		public:

			// Reflection declaration
			AP_DECLARE_TYPE();

			// Constructor & destructor
			SimulatedPresentation(void);
			~SimulatedPresentation(void);

			// Public methods
			static SimulatedPresentation*								Init(Axiom::Memory::HeapId);
			static void													Destroy(void);
			
			PRESENTATION_INLINE static SimulatedPresentation*			GetInstance(void);

			PRESENTATION_INLINE void									RegisterImplementation(SimulatedPresentation_Interface*);
			PRESENTATION_INLINE SimulatedPresentation_Interface*		GetImplementation(void);

			PRESENTATION_INLINE Axiom::EventMsgBoxHandle				GetMessageBox(void);

			PRESENTATION_INLINE void									SetBypassAreas(bool);
			PRESENTATION_INLINE bool									AreAreasBypassed(void);

			// Public methods interoperating with presentation interface 
			void														RegisterEvents(Axiom::EventMsgBoxHandle);
			void														HandleEvents(const PresentationInput&, PresentationOutput*);

			void														Init(void);
			void														Reset(void);

			void														Update(const Axiom::TimeAbsolute&, const PresentationInput&, PresentationOutput*, const unsigned int debugChannel);

			// Misc
			PRESENTATION_INLINE void									SetDebugChannel(const unsigned int channel);

			// Reflected methods
			void														Reset_Reflection(void);

			// Public debug methods
			AP_USERDEBUG_SUPPORT(void									AddDebugText(const Axiom::ShortString&, float fSecondsToDisplay=PRESENTATION_DEBUGTEXT_SECONDSTODISPLAY); )
			AP_USERDEBUG_SUPPORT(void									SetDebugMode(bool, bool bOverwrite=false, bool bCopyData=true); )
			AP_USERDEBUG_SUPPORT(void									SetDebugMode(const char*, bool, bool bOverwrite=false, bool bCopyData=true); )

		private:

			// Reflection declaration
			AP_NON_COPYABLE( SimulatedPresentation )

			// Singleton data
			static SimulatedPresentation		*m_pInstance;

			// Presentation components to simulate
			CameraManager						*m_pCameraManager;
			SequenceManager						*m_pSequenceManager;
			SimulatedPRSManager					*m_pSimulatedPRSManager;
			SimulatedPresentationControl		*m_pControl;

			// Event Message Handler
			Axiom::EventMsgBoxHandle			m_hMessageBox;

			// Title implementation
			SimulatedPresentation_Interface		*m_pImplementation;

			// Areas
			bool								m_BypassAreas;

			// Delta time
			Axiom::TimeAbsolute					m_CurrentTime;
			float								m_DeltaTime;

# if CORE_USERDEBUG == CORE_YES
			// Debug module
			SimulatedDebugTextManager*			m_pDebugTextManager;			
# endif

		};

// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/simulatedpresentation.inl"
# endif

	}
}

#endif
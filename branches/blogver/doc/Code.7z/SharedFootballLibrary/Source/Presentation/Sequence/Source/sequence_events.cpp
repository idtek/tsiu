
#ifndef  _SEQUENCE_EVENTS_H_
# include "presentation/sequence/sequence_events.h"
#endif
#ifndef  _SEQUENCE_DEFINES_H_
# include "presentation/sequence/sequence_defines.h"
#endif

#ifndef __STRING_STATIC_STRING_HEADER__
# include <string/staticstring.h>
#endif

// Namespace usage
using namespace AP;
using namespace Events;

// Reflection declaration
#if CORE_USERDEBUG == CORE_YES
AP_TYPE(SequenceTriggerEventEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("EventID",	m_EventID, "ID of the event")
	AP_FIELD("AreaID",	m_AreaID, "ID of the area")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SequenceStateChangeEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("State",	m_State, "State of sequence")
	AP_FIELD("ID",	m_SequenceID, "State of sequence")
	AP_PROXY("Presentation")
AP_TYPE_END()
#endif

AP_TYPE(SequenceAreaEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("EventID",	m_Event,	"ID of the event")
	AP_FIELD("Sequence", m_pSequence, "Owning sequence")
	AP_FIELD("EventType", m_Event,	"Type of area event")
	AP_FIELD("AreaId", m_AreaID, "ID of area")
AP_TYPE_END()

 
#ifndef _SEQUENCEMANAGER_H_
# include "presentation/sequence/sequencemanager.h"
#endif
#ifndef _SEQUENCE_H_
# include "presentation/sequence/sequence.h"
#endif
#ifndef _SEQUENCE_EVENTS_H_
# include "presentation/sequence/sequence_events.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif

#ifndef _MATRIX4_H
# include <math/matrix4.h>
#endif
#ifndef _COMPONENT_MANAGER_H
# include <kernel/componentmanager.h>
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/sequence/sequencemanager.inl"
#endif

// Static members
SequenceManager* SequenceManager::m_pInstance = NULL;

// Reflection declaration
AP_TYPE(SequenceManager)
	AP_FIELD("Sequences", m_Sequences, "Sequence list")
	AP_NAMED_COMMAND("StopSequence", StopSequence_Reflection, "Stop Sequence")
	AP_NAMED_COMMAND("PauseSequence", PauseSequence_Reflection, "Pause Sequence")
	AP_NAMED_COMMAND("PlaySequence", PlaySequence_Reflection, "Play Sequence")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SequenceCommand)
	AP_DEFAULT_CREATE()
	AP_FIELD("SequenceID", m_SequenceID, "The sequence ID")
	AP_FIELD("Command", m_Command, "The command")
	AP_ATTRIBUTE("DefaultValue", "{SequenceID={Value=\"SET_THIS\"}, Command=SEQUENCE_COMMAND_PLAY}")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SequenceWeightedCommand)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(SequenceCommand)
	AP_FIELD("Weight", m_Weight, "Random weight")
	AP_PROXY("Presentation")
	AP_ATTRIBUTE("DefaultValue", "{Weight=1.0}")
AP_TYPE_END()

AP_TYPE(SEQUENCE_COMMAND_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

// Sequence Command Key
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
SequenceCommand::SequenceCommand(void) :
	m_Command(SEQUENCE_COMMAND_e::SEQUENCE_COMMAND_PLAY),
	m_SequenceID()
{
}

SequenceCommand::SequenceCommand(const Axiom::StripStringCRC& rSequenceName, SEQUENCE_COMMAND_e eCommand) :
	m_Command(eCommand),
	m_SequenceID(rSequenceName)
{
}

SequenceCommand::~SequenceCommand(void)
{
}

// Public methods
const SEQUENCE_COMMAND_e& SequenceCommand::GetCommandType(void) const
{
	return m_Command;
}

const Axiom::StripStringCRC& SequenceCommand::GetSequenceID(void) const
{
	return m_SequenceID;
}

const void SequenceCommand::SetSequenceID(const Axiom::StripStringCRC& rID)
{
	m_SequenceID = rID;
}
				

Sequence* SequenceCommand::Execute(Sequence *pPreviousSequence, const PresentationInput &rInput, PresentationOutput *pOutput) const
{
	PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed!\n" );

	Sequence *pNewSequence = SequenceManager::GetInstance()->FindSequencePtr( m_SequenceID );

	if( pNewSequence != NULL )
	{
		switch( m_Command )
		{
		case SEQUENCE_COMMAND_e::SEQUENCE_COMMAND_STOPANDPLAY:
			// Grab the viewport from the previous sequence
			if( pPreviousSequence != NULL )
			{
				pNewSequence->SetViewport( pPreviousSequence );		
				// Stop the previous sequence
				pPreviousSequence->Stop(rInput, pOutput);
			}
			// Play the new sequence
			pNewSequence->Play(0.0f, rInput, pOutput);
			break;				
		case SEQUENCE_COMMAND_e::SEQUENCE_COMMAND_PLAY:
			// Grab the viewport from the previous sequence
			if( pPreviousSequence != NULL )
			{
				pNewSequence->SetViewport( pPreviousSequence );		
			}
			// Play the new sequence
			pNewSequence->Play(0.0f, rInput, pOutput);
			break;				
		case SEQUENCE_COMMAND_e::SEQUENCE_COMMAND_STOP:
			pNewSequence->Stop(rInput, pOutput);
			break;
		default:
			break;
		}
		return pNewSequence;
	}
#if CORE_USERDEBUG == CORE_YES
	Axiom::Log("Presentation", "WARNING: Couldn't find sequence: %s", m_SequenceID.GetDebugString());
#endif
	return NULL;
}

// Operator needed for reflection
bool SequenceCommand::operator ==(const SequenceCommand &rCommand) const
{ 
	return m_Command == rCommand.m_Command && m_SequenceID == rCommand.m_SequenceID;
}


// Sequence Random Command Key
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
SequenceWeightedCommand::SequenceWeightedCommand(void) : SequenceCommand(),
	m_Weight(1.0f)
{
}

SequenceWeightedCommand::SequenceWeightedCommand(const char *pSequenceName, SEQUENCE_COMMAND_e eCommand, float fWeight) : SequenceCommand(pSequenceName, eCommand),
	m_Weight(fWeight)
{
}

SequenceWeightedCommand::~SequenceWeightedCommand(void)
{
}

// Sequence Manager
// --------------------------------------------------------------------------------

// Private methods 
void SequenceManager::RemoveSequencePtr(Sequence *pSequence)
{
	PRESENTATION_ASSERT( pSequence != NULL, "Sequence Error: NULL pointer passed!\n" );

	unsigned int i;
	for (i=0;i<m_Sequences.Count();i++)
	{
		if (m_Sequences[i].pVal()==pSequence)
		{
			m_Sequences.RemoveAt(i);
			break;
		}
	}
}

Sequence* SequenceManager::FindSequencePtr(const char *pName)
{
	return FindSequencePtr( Axiom::CRC( pName ) );
}

Sequence* SequenceManager::FindSequencePtr(const Axiom::CRC &rCRC)
{
	for(unsigned int i = 0; i < m_Sequences.Count(); i++)
	{
		Sequence *pSequence = const_cast<Sequence*>( m_Sequences[i].pVal() );
		PRESENTATION_ASSERT( pSequence != NULL, "Sequence Error: Can't!\n" );

		if( pSequence->GetID() == rCRC )
		{
			return pSequence;
		}
	}

	return NULL;
}

// Constructors & destructors
SequenceManager::SequenceManager(void) :
	m_Sequences(),
	m_pUpdateSequence(NULL)
{
}

SequenceManager::~SequenceManager(void)
{
	m_Sequences.Clear();
}

// Singleton stuff
SequenceManager *SequenceManager::Init(Axiom::Memory::HeapId iHeapID)
{
	AP_ASSERTMESSAGE(m_pInstance == NULL, "Init should only be called once.");
	if(m_pInstance == NULL)
	{
		m_pInstance = AP_NEW( iHeapID, SequenceManager());
		AP_ASSERTMESSAGE(m_pInstance != NULL, "error allocating memory.");

		AP::Reflection::Script::Register("SequenceManager", AP::Reflection::Instance(m_pInstance), "Presentation Tool");
	}
	return m_pInstance;
}

void SequenceManager::Destroy(void)
{
	AP::Reflection::Script::Unregister("SequenceManager");

	AP_DELETE(m_pInstance);
	m_pInstance= NULL;
}

// Public methods
Axiom::SmartPtr<Sequence> SequenceManager::AddSequence(void)
{
	PRESENTATION_ASSERT( m_Sequences.Count() < m_Sequences.Capacity(), "" );
	
	// Create sequence
	Axiom::SmartPtr<Sequence> pSequencePtr = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Sequence() );
	PRESENTATION_ASSERT( pSequencePtr.IsValid(), "Sequence Error: Can't create sequence!\n" );

	// Add the sequence
	m_Sequences.Add(pSequencePtr);

	return pSequencePtr;
}

void SequenceManager::RemoveSequence(const char *pName)
{
	PRESENTATION_ASSERT( pName !=NULL, "" );

	m_Sequences.Remove( FindSequencePtr( pName ) );
}

void SequenceManager::RemoveSequence(const Axiom::CRC &rCRC)
{
	m_Sequences.Remove( FindSequencePtr( rCRC ) );
}

const Sequence& SequenceManager::FindSequence(const char *pName)
{
	PRESENTATION_ASSERT(pName != NULL, "Sequence Error: NULL pointer passed!\n");

	Sequence *pSequence = FindSequencePtr(pName);
	PRESENTATION_ASSERT(pSequence != NULL, "Sequence Error: Sequence can't be retrieved!\n");

	return *pSequence;
}

const Sequence& SequenceManager::FindSequence(const Axiom::CRC &rCRC)
{
	Sequence *pSequence = FindSequencePtr(rCRC);
	PRESENTATION_ASSERT(pSequence != NULL, "Sequence Error: Sequence can't be retrieved!\n");

	return *pSequence;
}

const Sequence* SequenceManager::GetSequence(const Axiom::CRC &rCRC)
{
	return FindSequencePtr(rCRC);
}

const Sequence* SequenceManager::GetSequence(const char *pName)
{
	return FindSequencePtr(pName);
}

const Sequence* SequenceManager::GetSequence(const SEQUENCE_CATEGORY_e& rCategory, int& index )
{
	int j = -1, lastGoodIndex = -1, lastGoodJ = -1, firstGoodIndex = -1, firstGoodJ = -1;
	for(unsigned int i = 0; i < m_Sequences.Count(); i++)
	{
		if(m_Sequences[i]->GetCategory() == rCategory)
		{
			j++;
			lastGoodIndex = i;
			lastGoodJ = j;
			if(firstGoodIndex < 0)
			{
				firstGoodIndex = i;
				firstGoodJ = j;
			}
			if(j == index)
			{
				return const_cast<Sequence*>( m_Sequences[i].pVal() );
			}
		}
	}
	if(index < 0)
	{
		index = lastGoodJ;
		return const_cast<Sequence*>( m_Sequences[lastGoodIndex].pVal() );
	}
	else if(firstGoodIndex >= 0)
	{
		index = firstGoodJ;
		return const_cast<Sequence*>( m_Sequences[firstGoodIndex].pVal() );
	}
	return NULL;
}

void SequenceManager::StopAllSequences(const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed!\n" );

	for(unsigned int i = 0; i < m_Sequences.Count(); i++)
	{
		m_Sequences[i]->Stop( rInput, pOutput );
	}
}

void SequenceManager::StopAllSequences(SEQUENCE_CATEGORY_e eCategory, const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed!\n" );

	for(unsigned int i = 0; i < m_Sequences.Count(); i++)
	{
		Sequence *pSequence = m_Sequences[i].pVal();
		if( pSequence->GetCategory() == eCategory )
		{
			pSequence->Stop( rInput, pOutput );
		}
	}
}

void SequenceManager::Reset(void)
{
	for(unsigned int i = 0; i < m_Sequences.Count(); i++)
	{
		m_Sequences[i]->Reset();
	}
}

void SequenceManager::Update(float fDeltaTime, const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int debugChannel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed\n" );	

	// Only update when the delta time make sense
	for( unsigned int i = 0 ; i < m_Sequences.Count() ; ++i )
	{
		m_pUpdateSequence = m_Sequences[i].pVal();
		if( m_pUpdateSequence->GetState() == SEQUENCE_STATE_e::SEQUENCE_STATE_PLAY )
		{
			// Update this sequence
			m_pUpdateSequence->Update( fDeltaTime, rInput, pOutput );

			// Draw if not in debug mode
			const Viewport *pViewport = m_pUpdateSequence->GetViewport();
			if( pViewport != NULL && !pViewport->IsInDebugMode() )
			{ 
				m_pUpdateSequence->Draw( pOutput, debugChannel );
			}
		}
	}
	m_pUpdateSequence = NULL;
}

// Reflection functions
void SequenceManager::StopSequence_Reflection(char *pName)
{
	Sequence *pSequence = FindSequencePtr( pName );
	if( pSequence != NULL )
	{
		AP::Events::SequenceStopEvent tEvent( pSequence );
		SEND_EVENT( tEvent );
	}
}

void SequenceManager::PauseSequence_Reflection(char *pName)
{
	Sequence *pSequence = FindSequencePtr( pName );
	if( pSequence != NULL )
	{
		AP::Events::SequencePauseEvent tEvent( pSequence );
		SEND_EVENT( tEvent );
	}
}

void SequenceManager::PlaySequence_Reflection(char *pName)
{
	Sequence *pSequence = FindSequencePtr(pName);
	if( pSequence != NULL )
	{
		AP::Events::SequencePlayEvent tEvent( pSequence );
		SEND_EVENT( tEvent );
	}
#if CORE_LOGGING == CORE_YES
	else
	{
		Axiom::Log("Presentation", "PlaySequence. Sequence '%s' not found", pName);
	}
#endif
}

#if CORE_USERDEBUG == CORE_YES
void SequenceManager::SendSequenceTriggerEventEvent(int iEventID)
{
	// Notifying the external sources of a presentation event
	SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
	AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "Sequence Error: Presentation not existing!\n" );

	AP::Events::SequenceTriggerEventEvent eventEvent(iEventID);
	pSimulatedPresentation->GetMessageBox()->SendEvent( &eventEvent );
}
#endif

 
#ifndef _KEY_H_
# include "presentation/sequence/key.h"
#endif
#ifndef _SEQUENCE_H_
# include "presentation/sequence/sequence.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif

#ifndef _SYSTEM_RAND_H__
# include "system/systemrand.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/sequence/key.inl"
#endif

// Reflection declaration
AP_TYPE(Key)
	AP_FIELD("Active", m_Active, "Key Activity")
	AP_FIELD("Trigger", m_Trigger, "Key Trigger")
	AP_FIELD("Event", m_Event, "Event")
		AP_FIELD_ATTRIBUTE("GuiConstrainToTypeName", "EVENT_e")
		AP_FIELD_ATTRIBUTE("AllowNull", "false")
	AP_FIELD("EventID", m_EventID, "Event ID")
	AP_FIELD("ValueIn", m_ValueIn, "Value In")
	AP_FIELD("ValueOut", m_ValueOut, "Value out")
	AP_ATTRIBUTE("DefaultValue", "{Active=True}")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(BASE_EVENT_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(KEY_TRIGGER_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

// Key
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & virtual destructor
Key::Key() :
	m_State(KEY_STATE_VALID),
	m_PreviousState(KEY_STATE_VALID),
	m_Active(true),
	m_Trigger(KEY_TRIGGER_e::KEY_TRIGGER_INVALID),
	m_Event(),
	m_ValueIn(0.0f),
	m_ValueOut(0.0f),
	m_EstablishedValueIn(0.0f),
	m_EstablishedValueOut(0.0f),
	m_EventID(NULL)
{
}

Key::~Key(void)
{
}

// Static Methods
Axiom::SmartPtr<Key> Key::CreateKeyByName(const Axiom::StripStringCRC& rKeyName)
{
	const AP::Reflection::Type* type = AP::Reflection::Type::TypeOf(rKeyName);
	return type->CreateInstance(Axiom::Memory::PRESENTATION_HEAP).As< Axiom::SmartPtr<SharedSoccer::Presentation::Key> >();
}

// Public methods
void Key::ResetValid(void)
{
	// Validity update
	switch( m_Trigger )
	{
	// Time only triggers
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUE_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE_RANDOM_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE:
		m_State = KEY_STATE_INVALID;
		break;
	// Event triggers
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMERANGE:
		m_State = KEY_STATE_VALID;
		break;
	default:
		break;
	}
}

bool Key::IsValid(float fValue)
{
	if( !m_Active || m_State == KEY_STATE_INVALID ) 
	{
		return false;
	}

	// If it's only a matter of time
	switch( m_Trigger )
	{
	// Time only trigger
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUE_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE:
		if( m_ValueIn <= fValue )
		{
			return true;
		}
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE_RANDOM_ONCE:
		if( ( m_State == KEY_STATE_VALID && m_ValueIn <= fValue && fValue <= m_ValueOut ) ||
			( m_State == KEY_STATE_ESTABLISHED && m_EstablishedValueIn <= fValue ) )
		{
			return true;
		}
		break;
	// Event with time trigger
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE:
		if( m_State == KEY_STATE_ESTABLISHED )
		{
			if( m_EstablishedValueIn <= fValue )
			{
				return true;
			}
		}
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMERANGE:
		if( m_State == KEY_STATE_TRIGGERED )
		{
			return true;
		}
		else if( m_State == KEY_STATE_ESTABLISHED )
		{
			if( m_EstablishedValueIn <= fValue )
			{
				return true;
			}
		}
		break;
	default:
		break;
	}

	return false;
}

bool Key::PreUpdate(Sequence* pSequence, float fValue, const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Key Error: NULL pointer passed!\n" );

	// Save the previous state
	m_PreviousState = m_State;

	// Validity update
	switch( m_Trigger )
	{
	// Time only trigger
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUE_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE:
		m_State = KEY_STATE_TRIGGERED;
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE_RANDOM_ONCE:
		if( m_State == KEY_STATE_VALID )
		{
			m_EstablishedValueIn = fValue + RANDFLOAT( m_ValueIn, m_ValueOut );
			m_State = KEY_STATE_ESTABLISHED;
			return false;
		}
		else
		{
			m_State = KEY_STATE_TRIGGERED;
		}
		break;
	// Event trigger
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_ONCE:
		m_State = KEY_STATE_TRIGGERED;
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE:
		if( m_State == KEY_STATE_VALID )
		{
			m_EstablishedValueIn = fValue + m_ValueIn;
			m_State = KEY_STATE_ESTABLISHED;
			return false;
		}
		else 
		{
			m_State = KEY_STATE_TRIGGERED;
		}
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMERANGE:
		if( m_State == KEY_STATE_VALID )
		{
			m_EstablishedValueIn = fValue + m_ValueIn;
			if( m_ValueOut > 0.0f )
			{
				m_EstablishedValueOut = fValue + m_ValueOut;
			}
			m_State = KEY_STATE_ESTABLISHED;
			return false;
		}
		else 
		{
			m_State = KEY_STATE_TRIGGERED;
		}
		break;
	default:
		break;
	}

	if( m_State != m_PreviousState )
	{
		Init(pSequence,fValue,rInput,pOutput);
	}

	return true;
}

void Key::PostUpdate(float fValue, const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Key Error: NULL pointer passed!\n" );

	// Save the previous state
	m_PreviousState = m_State;

	// Validity update
	switch( m_Trigger )
	{
	// Time only triggers
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUE_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE_RANDOM_ONCE:
		m_State = KEY_STATE_INVALID;			// Automatically invalid it (time has passed)
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_VALUERANGE:
		if( m_ValueOut > 0.0f && fValue >= m_ValueOut )
		{
			m_State = KEY_STATE_INVALID;
		}
		break;
	// Event triggers
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_ONCE:
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE:
		m_State = KEY_STATE_VALID;				// Automatically valid it (event might happen again)
		break;
	case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMERANGE:
		if( m_ValueOut > 0.0f && fValue >= m_EstablishedValueOut )
		{
			m_State = KEY_STATE_VALID;
		}
		break;
	default:
		break;
	}

	if( m_State != m_PreviousState )
	{
		Exit(fValue,rInput,pOutput);
	}
}

// Virtual public methods
/* virtual */ void Key::Init(Sequence*, float, const PresentationInput&, PresentationOutput*)
{	
}

/* virtual */ void Key::Update(Sequence* pSequence, float fValue, const PresentationInput &rInput, PresentationOutput *pOutput)
{	
	if( Key::PreUpdate(pSequence, fValue, rInput, pOutput) )
	{
		Key::PostUpdate(fValue,rInput,pOutput);
	}
}

/* virtual */ void Key::Exit(float, const PresentationInput&, PresentationOutput*)
{	
	ResetValid();
}

/* virtual */ void Key::Reset(const PresentationInput&, PresentationOutput*)
{	
	m_State = m_PreviousState = KEY_STATE_VALID;
};

 
#ifndef _SEQUENCE_H_
# include "presentation/sequence/sequence.h"
#endif
#ifndef _SEQUENCEMANAGER_H_
# include "presentation/sequence/sequencemanager.h"
#endif
#ifndef _SEQUENCE_EVENTS_H_
# include "presentation/sequence/sequence_events.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif
#ifndef _PRESENTATIONINPUT_H
# include "presentation/presentationinput.h"
#endif

#ifndef _COMPONENT_MANAGER_H
# include "kernel/componentmanager.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inline
#ifndef PRESENTATION_USE_INLINE
# include "presentation/sequence/sequence.inl"
#endif

// Reflection 
AP_TYPE(Area)
	AP_DEFAULT_CREATE()
	AP_DEFAULT_TOSTRING()
	AP_FIELD("ID", m_ID, "ID")
	AP_FIELD("Center", m_Center, "Center")
	AP_FIELD("Width", m_Width, "Width")
	AP_FIELD("Height", m_Height, "Height")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Sequence)
	AP_DEFAULT_CREATE()
	AP_DEFAULT_TOSTRING()
	AP_FIELD("ID", m_ID, "ID")
	AP_READONLY_FIELD("State", m_State, "State")
	AP_FIELD("Category", m_Category, "Category")
	// Reflected Properties
	AP_FIELD("Keys", m_Keys, "All keys for this sequence")
	AP_FIELD("Areas", m_Areas, "Areas associated with events for this sequence")
	AP_FIELD("AreaTrackings", m_AreaTrackings, "Trackings for this sequence")
	// Reflected Functions
	AP_ATTRIBUTE("PrimaryKey", "ID.Value")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SEQUENCE_CATEGORY_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SEQUENCE_STATE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

// Area
// -----------------------------------------------------------------------------------------------------------

// Constructor & destructor
Area::Area(void) : Shape(SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE),
	m_ID(),
	m_State(AREA_STATE_INVALID)
{
}

Area::~Area(void)
{
}

// Public methods
void Area::SetName(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Sequence Error: NULL pointer passed!\n" );

	m_ID = pName;
}

// Operator needed for reflection
const bool Area::operator ==(const Area &rArea) const
{
	return m_ID == rArea.m_ID &&
		   m_State == rArea.m_State;
}

// Sequence
// -----------------------------------------------------------------------------------------------------------

// Private methods
void Sequence::ResetKeys(const PresentationInput &rInput, PresentationOutput *pOutput)
{
	// Reset the keys
	for(unsigned int i = 0; i < m_Keys.Count(); i++)
	{
		m_Keys[i]->Reset(rInput, pOutput);
	}
}

Key* Sequence::GetKeyPtr(const int i)
{
	return m_Keys[i].pVal();
}

Area* Sequence::FindAreaPtr(const char *pName)
{
	return FindAreaPtr( Axiom::CRC( pName ) );
}

Area* Sequence::FindAreaPtr(const Axiom::CRC &rCRC)
{
	for(unsigned int i = 0; i < m_Areas.Count(); i++)
	{
		Area *pArea = m_Areas[i].pVal();
		if( pArea->GetID() == rCRC )
		{
			return pArea;
		}
	}

	return NULL;
}

void Sequence::RemoveAreaPtr(Area *pArea)
{
	PRESENTATION_ASSERT( pArea != NULL, "Sequence Error: NULL pointer passed!\n" );

	unsigned int i;
	for (i=0;i<m_Areas.Count();i++)
	{
		if (m_Areas[i].pVal()==pArea)
		{
			m_Areas.RemoveAt(i);
			break;
		}
	}
}

void Sequence::RemoveKeyPtr(Key *pKey)
{
	PRESENTATION_ASSERT( pKey != NULL, "Sequence Error: NULL pointer passed!\n" );

	unsigned int i;
	for (i=0;i<m_Keys.Count();i++)
	{
		if( m_Keys[i].pVal() == pKey )
		{
			m_Keys.RemoveAt(i);
			break;
		}
	}
}

// Constructor & destructor
Sequence::Sequence() :
	m_ID(),
	m_pViewport(NULL),
	m_Keys(),
	m_Areas(),
	m_AreaTrackings(),
	m_ResetAreas(false),
	m_StartTime(0.0f),
	m_CurrentTime(0.0f),
	m_State(SEQUENCE_STATE_e::SEQUENCE_STATE_INVALID)
{
}

Sequence::~Sequence(void)
{
	m_Keys.Clear();
	m_Areas.Clear();
	m_AreaTrackings.Clear();
}

// Public methods
void Sequence::SetViewport(const Sequence *pSequence)
{
	PRESENTATION_ASSERT( pSequence != NULL, "Sequence Error: NULL pointer passed!\n" );

	const Viewport *pViewport = pSequence->GetViewport();
	if( pViewport != NULL )
	{
		SetViewport( pViewport );		
	}
}

const Camera* Sequence::GetCamera(void) const
{
	if( m_pViewport != NULL )
	{
		return m_pViewport->GetCamera();
	}
	return NULL;
}


void Sequence::SetState(SharedSoccer::Presentation::SEQUENCE_STATE_e state)
{
#if CORE_USERDEBUG == CORE_YES
	if(state != m_State)
	{
		Axiom::ShortString sequenceName = m_ID.GetDebugString();
		Axiom::ShortString skipNames[] = { "Camera.", "ShotIndicator", "Environment.Pitch", "ShotDisc" };

		bool printDebugInfo = true;
		for(int i = 0; i < array_count( skipNames ) && printDebugInfo; ++i)
		{
			if(sequenceName.Find(skipNames[i]) >= 0)
			{
				printDebugInfo = false;
			}
		}

		if(printDebugInfo)
		{
			Axiom::MediumString debugText("Sequence ");
			debugText += m_ID.GetDebugString();
			debugText += ":";

			const int chopPosition = 15;
			Axiom::ShortString startState = m_State.StringValue();
			startState = startState.SubString(chopPosition, startState.Length() - chopPosition);
			debugText += startState;
			debugText += "->";

			Axiom::ShortString endState = state.StringValue();
			endState = endState.SubString(chopPosition, endState.Length() - chopPosition);
			debugText += endState;
			Axiom::Log("Presentation", debugText.AsChar());
		}
	}


	SharedSoccer::Presentation::SEQUENCE_STATE_e oldState = m_State;
#endif
	m_State = state;

#if CORE_USERDEBUG == CORE_YES
	if(oldState != m_State)
	{
		SendSequenceStateChangeEvent();
	}
#endif
}

Axiom::SmartPtr<Key> Sequence::AddKeyByName(const char* sName)
{
	PRESENTATION_ASSERT( m_Keys.Count() < m_Keys.Capacity(), "Sequence Error: Out of capacity!\n" );

	// Create the Key
	Axiom::SmartPtr<Key> pKeyPtr = Key::CreateKeyByName(sName);
	PRESENTATION_ASSERT( pKeyPtr.IsValid(), "Sequence Error: Can't create key!\n" );

	// Add the key
	m_Keys.Add(pKeyPtr);

	return pKeyPtr;
}

Axiom::SmartPtr<Area> Sequence::AddArea(void)
{
	PRESENTATION_ASSERT( m_Areas.Count() < m_Areas.Capacity(), "Sequence Error: Out of capacity!\n" );

	// Create the area
	Area *pArea = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Area() );
	PRESENTATION_ASSERT( pArea != NULL, "Sequence Error: Can't create area\n" );
	
	// Add the area
	Axiom::SmartPtr<Area> pAreaPtr = Axiom::SmartPtr<Area>(pArea);
	m_Areas.Add( pAreaPtr );

	return pAreaPtr;
}

void Sequence::RemoveArea(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Sequence Error: NULL pointer passed!\n" );

	m_Areas.Remove( FindAreaPtr(pName) );
}

void Sequence::RemoveArea(const Axiom::CRC &rCRC)
{
	m_Areas.Remove( FindAreaPtr(rCRC) );
}

const Area& Sequence::FindArea(const char *pName)
{
	PRESENTATION_ASSERT( pName != NULL, "Sequence Error: NULL pointer passed!\n" );

	Area *pArea = FindAreaPtr( pName );
	PRESENTATION_ASSERT( pArea != NULL, "Sequence Error: NULL pointer passed!\n" );

	return *pArea;
}

const Area& Sequence::FindArea(const Axiom::CRC &rCRC)
{
	Area *pArea = FindAreaPtr( rCRC );
	PRESENTATION_ASSERT( pArea != NULL, "Sequence Error: NULL pointer passed!\n" );

	return *pArea;
}

Axiom::SmartPtr<Tracking> Sequence::AddAreaTracking(void)
{
	PRESENTATION_ASSERT( m_AreaTrackings.Count() < m_AreaTrackings.Capacity(), "Sequence Error: Out of capacity!\n" );

	// Create the tracking
	Tracking *pTracking = PRESENTATION_NEW( Axiom::Memory::PRESENTATION_HEAP, Tracking() );
	PRESENTATION_ASSERT( pTracking != NULL, "Sequence Error: Can't create tracking\n" );

	// Add the tracking
	Axiom::SmartPtr<Tracking> pTrackingPtr = Axiom::SmartPtr<Tracking>(pTracking);
	m_AreaTrackings.Add(pTrackingPtr);

	return pTrackingPtr;
}

void Sequence::ResetAreas(void)
{
	// Reset the areas
	for(unsigned int i = 0; i < m_Areas.Count(); i++)
	{
		m_Areas[i]->SetState( AREA_STATE_INVALID );
	}
}

// Sets the state to play, sets the current time to the start
// time if we weren't in paused mode before.
float Sequence::Play(float fStartTime, const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed\n" );

	ResetAreas();
	ResetKeys( rInput, pOutput );
	
	// Get the start time
	m_StartTime = fStartTime;

	switch( m_State )
	{
	case SEQUENCE_STATE_e::SEQUENCE_STATE_PAUSE:
		break;
	default:
		// Set current time if we weren't paused before
		m_CurrentTime = m_StartTime;
		break;
	}

	// Change the sequence state
	SetState(SEQUENCE_STATE_e::SEQUENCE_STATE_PLAY);

	return m_CurrentTime;
}

float Sequence::Pause(const PresentationInput&, PresentationOutput*)
{
	// Change the sequence state
	switch( m_State )
	{
	case SEQUENCE_STATE_e::SEQUENCE_STATE_PAUSE:
		SetState(SEQUENCE_STATE_e::SEQUENCE_STATE_PLAY);
		break;
	case SEQUENCE_STATE_e::SEQUENCE_STATE_PLAY:
		SetState(SEQUENCE_STATE_e::SEQUENCE_STATE_PAUSE);
		break;
	default:
		break;
	}

	return m_CurrentTime;
}

float Sequence::Stop(const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed\n" );

	// Stop the keys
	for(unsigned int i = 0; i < m_Keys.Count(); i++)
	{
		m_Keys[i]->Exit(m_CurrentTime, rInput, pOutput);
	}

	// Kill the viewport	
	m_pViewport = NULL;

	// Update the state
	SetState(SEQUENCE_STATE_e::SEQUENCE_STATE_STOP);

	return m_CurrentTime;
}

void Sequence::Reset(void)
{
	ResetAreas();
//	ResetKeys();

	// Kill the viewport	
	m_pViewport = NULL;

	// Update the state
	SetState(SEQUENCE_STATE_e::SEQUENCE_STATE_INVALID);
}

void Sequence::Update(float fDeltaTime, const PresentationInput &rInput, PresentationOutput *pOutput)
{
	// Update the time
	m_CurrentTime += fDeltaTime;

	// The simulated presentation implementation should know if we apply the areas right now...
	if( SimulatedPresentation::GetInstance()->AreAreasBypassed() )
	{
		if( !m_ResetAreas )
		{
			ResetAreas();

			// Reset only once!
			m_ResetAreas = true;
		}
	}
	else
	{
		// Update areas' tracking
		TrackingResult	tResult;
		unsigned int		iNbTrackings = m_AreaTrackings.Count();
		for( unsigned int i = 0 ; i < iNbTrackings ; ++i ) 
		{
			const Camera *pCamera = ( m_pViewport != NULL ? m_pViewport->GetCamera() : NULL );
			tResult = rInput.TrackEntity( m_AreaTrackings[i].pVal(), pCamera );
			if( (tResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
			{ 
				// Update the areas
				unsigned int iNbAreas = m_Areas.Count();
				for( unsigned int i = 0; i < iNbAreas; ++i )
				{
					Area	*pArea = m_Areas[i].pVal();
					bool	bTargetIn = pArea->IsIn(tResult.m_Position);

					// Update the state of the area
					switch( pArea->GetState() )
					{
					case AREA_STATE_INVALID:	// Consider INVALID as OUT.
					case AREA_STATE_OUT:
						if(	bTargetIn )
						{
							pArea->SetState( AREA_STATE_ENTER );

							// Broadcast an enter area event
							AP::Events::SequenceAreaEvent tEvent( BASE_EVENT_e::BASE_EVENT_ENTERAREA, pArea->GetID(), this );
							SEND_EVENT( tEvent );
						}
						break;
					case AREA_STATE_IN:
						if(	!bTargetIn )
						{
							pArea->SetState( AREA_STATE_EXIT );

							// Broadcast an exit area event
							AP::Events::SequenceAreaEvent tEvent( BASE_EVENT_e::BASE_EVENT_EXITAREA, pArea->GetID(), this );
							SEND_EVENT( tEvent );
						}
						break;
					case AREA_STATE_ENTER:
						if(	bTargetIn )
						{
							pArea->SetState( AREA_STATE_IN );
						}
						else
						{
							pArea->SetState( AREA_STATE_EXIT );

							// Broadcast an exit area event
							AP::Events::SequenceAreaEvent tEvent( BASE_EVENT_e::BASE_EVENT_EXITAREA, pArea->GetID(), this );
							SEND_EVENT( tEvent );
						}
						break;
					case AREA_STATE_EXIT:
						if(	!bTargetIn )
						{
							pArea->SetState( AREA_STATE_OUT );
						}
						else
						{
							pArea->SetState( AREA_STATE_ENTER );

							// Broadcast an enter area event
							AP::Events::SequenceAreaEvent tEvent( BASE_EVENT_e::BASE_EVENT_ENTERAREA, pArea->GetID(), this );
							SEND_EVENT( tEvent );
						}
						break;
					default:
						break;
					}
				}

				break;
			}
		}

		// Make sure next time we bypass the areas we start back
		m_ResetAreas = false;
	}

	// Update the keys
	float			fTime = m_CurrentTime - m_StartTime;
	unsigned int	iNbKeys = m_Keys.Count();
	for(unsigned int i = 0; i < iNbKeys; ++i)
	{
		Key								*pKey = m_Keys[i].pVal();
		const AP::Reflection::Instance	&rInstance = pKey->GetEventInstance();
		if( rInstance.IsValid() )
		{
			switch( rInstance.GetField("Value").As<int>() )
			{
			case BASE_EVENT_e::BASE_EVENT_TIMEBASED:
			default:
				if( pKey->IsValid( fTime ) )
				{
					pKey->Update( this, fTime, rInput, pOutput );
				}
				break;
			}
		}
	}
}

void Sequence::Draw(PresentationOutput *pOutput, const unsigned int channel)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed!\n" );

	// Draw the areas
	unsigned int iNbAreas = m_Areas.Count();
	for(unsigned int i = 0; i < iNbAreas ; i++)
	{
		Area *pArea = m_Areas[i].pVal();
	
		float fHalfWidth = pArea->GetWidth() / 2.0f;
		float fHalfHeight = pArea->GetHeight() / 2.0f;
		float fCenterX = pArea->GetCenter().X();
		float fCenterY = pArea->GetCenter().Y();
		Axiom::Math::Vector3 vTopLeftPos;
		vTopLeftPos.Set( fCenterX - fHalfWidth, fCenterY - fHalfHeight, 0.1f );
		Axiom::Math::Vector3 vTopRightPos;
		vTopRightPos.Set( fCenterX + fHalfWidth, fCenterY - fHalfHeight, 0.1f );
		Axiom::Math::Vector3 vBottomLeftPos;
		vBottomLeftPos.Set( fCenterX - fHalfWidth, fCenterY + fHalfHeight, 0.1f );
		Axiom::Math::Vector3 vBottomRightPos;
		vBottomRightPos.Set( fCenterX + fHalfWidth, fCenterY + fHalfHeight, 0.1f );

		pOutput->DrawLine(vTopLeftPos,vTopRightPos,GRAPHICS_RGBAF(1.0f, 1.0f, 0.0f, 1.0f), channel);
		pOutput->DrawLine(vTopRightPos,vBottomRightPos,GRAPHICS_RGBAF(1.0f, 1.0f, 0.0f, 1.0f), channel);	
		pOutput->DrawLine(vBottomRightPos,vBottomLeftPos,GRAPHICS_RGBAF(1.0f, 1.0f, 0.0f, 1.0f), channel);
		pOutput->DrawLine(vBottomLeftPos,vTopLeftPos,GRAPHICS_RGBAF(1.0f, 1.0f, 0.0f, 1.0f), channel);
	}
}

const bool Sequence::operator ==(const Sequence &rSequence) const
{
	return  m_ID == rSequence.m_ID &&
			m_Keys == rSequence.m_Keys &&
			m_Areas == rSequence.m_Areas &&
			m_AreaTrackings == rSequence.m_AreaTrackings &&
			m_StartTime == rSequence.m_StartTime &&
			m_CurrentTime == rSequence.m_CurrentTime &&
			m_State == rSequence.m_State;
}

// Reflection methods
#if CORE_USERDEBUG == CORE_YES
void Sequence::SendSequenceStateChangeEvent()
{
	// Notifying the external sources of a presentation event
	SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
	AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "Sequence Error: Presentation not existing!\n" );

	AP::Events::SequenceStateChangeEvent eventEvent(m_State, m_ID);
	pSimulatedPresentation->GetMessageBox()->SendEvent( &eventEvent );
}
#endif

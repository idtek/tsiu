#pragma once

#ifndef  _KEY_H_
# define _KEY_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _SEQUENCE_DEFINES_H_
#  include "presentation/sequence/sequence_defines.h"
# endif
# ifndef _CAMERACURVE_H_
#  include "presentation/camera/cameracurve.h"
# endif
# ifndef _PRSELEMENTANIMDATA_H
#  include "prs/prselementanimdata.h"
# endif

# ifndef __CORE_SMARTPTR_H
#  include <core/smartptr.h>
# endif
# ifndef __CORE_VECTOR3_H
#  include <math/vector3.h>
# endif
# ifndef PRS_CONTROLLER_H
#  include <gel/prscontroller.h>
# endif
#include <core/autopointer.h>

namespace SharedSoccer
{
	namespace Presentation
	{
		class Sequence;
		class Viewport;
		class PresentationInput;
		class PresentationOutput;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef	 INVALIDITEMS
# define INVALIDITEMS 1

		// Base Events
		CLASSEDENUM_REFLECTED(	BASE_EVENT_e,\
						CLASSEDENUM_ITEMWITHVALUE(BASE_EVENT_INVALID, -1)\
						CLASSEDENUM_ITEM(BASE_EVENT_TIMEBASED)		/* Mandatory */\
						CLASSEDENUM_ITEM(BASE_EVENT_ENTERAREA)		/* Mandatory */\
						CLASSEDENUM_ITEM(BASE_EVENT_EXITAREA)		/* Mandatory */\
						,BASE_EVENT_INVALID)

		// Key triggers
		CLASSEDENUM_REFLECTED(	KEY_TRIGGER_e,\
						CLASSEDENUM_ITEMWITHVALUE(KEY_TRIGGER_INVALID, -1)\
						/* EVENT based*/\
						CLASSEDENUM_ITEM(KEY_TRIGGER_EVENT_ONCE)\
						CLASSEDENUM_ITEM(KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE)\
						CLASSEDENUM_ITEM(KEY_TRIGGER_EVENT_TIMERANGE)\
						/* VALUE based */\
						CLASSEDENUM_ITEM(KEY_TRIGGER_VALUERANGE_RANDOM_ONCE)\
						CLASSEDENUM_ITEM(KEY_TRIGGER_VALUE_ONCE)\
						CLASSEDENUM_ITEM(KEY_TRIGGER_VALUERANGE)\
						,KEY_TRIGGER_INVALID)

# undef	 INVALIDITEMS
# define INVALIDITEMS 0
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		enum KEY_STATE_e
		{
			KEY_STATE_INVALID = -1,
			
			KEY_STATE_VALID,
			KEY_STATE_ESTABLISHED,
			KEY_STATE_TRIGGERED,

			KEY_NBSTATES,
		};

		class Key : public Axiom::Referenced
		{
		public: 

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			Key();
			virtual ~Key(void);

			// Static methods
			static Axiom::SmartPtr<Key> CreateKeyByName(const Axiom::StripStringCRC& rKeyName);

			// Public methods
			PRESENTATION_INLINE const AP::Reflection::Instance&	GetEventInstance(void);
			PRESENTATION_INLINE const Axiom::StripStringCRC*			GetEventID(void);
			PRESENTATION_INLINE const int						GetUniqueKeyID() const;

			void												ResetValid(void);
			bool												IsValid(float);
	
			bool												PreUpdate(Sequence*, float, const PresentationInput&, PresentationOutput*);
			void												PostUpdate(float, const PresentationInput&, PresentationOutput*);

			// Public virtual methods
			virtual void										Init(Sequence*, float, const PresentationInput&, PresentationOutput*);
			virtual void										Update(Sequence*, float, const PresentationInput&, PresentationOutput*);
			virtual void										Exit(float, const PresentationInput&, PresentationOutput*);
			virtual void										Reset(const PresentationInput&, PresentationOutput*);

			// Template functions
			template <typename T> inline const T&				GetEvent(void);
			template <typename T> inline bool					IsValid(float,T);

		protected:

			// Private member variables
			KEY_STATE_e										m_State;
			KEY_STATE_e										m_PreviousState;

			bool											m_Active;

			KEY_TRIGGER_e									m_Trigger;
			AP::Reflection::AutoInstance /* EVENT_e */		m_Event;

			float											m_ValueIn;
			float											m_ValueOut;

			float											m_EstablishedValueIn;
			float											m_EstablishedValueOut;

			Axiom::AutoPointer<Axiom::StripStringCRC>			m_EventID;

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/sequence/key.inl"
# endif

		// Template functions
		template <typename T> inline const T& Key::GetEvent(void)
		{
			return m_Event.Get().As<T>();
		}

		template <typename T> inline bool Key::IsValid(float fTime, T tEvent)
		{
			const AP::Reflection::Instance	&rInstance = GetEventInstance();
			if( rInstance.IsValid() )
			{
				if( !m_Active || m_State == KEY_STATE_INVALID ) 
				{
					return false;
				}

				// If and event comes along
				switch( m_Trigger )
				{
				// Event trigger
				case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_ONCE:
					if( tEvent == m_Event.Get().As<T>() )
					{
						return true;
					}
					break;
				// Event with time trigger
				case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMEOFFSET_ONCE:
				case KEY_TRIGGER_e::KEY_TRIGGER_EVENT_TIMERANGE:
					if( m_State == KEY_STATE_VALID && tEvent == m_Event.Get().As<T>() )
					{
						return true;
					}
					break;
				default:
					break;
				}
			}
			return false;
		}
	}
}

#endif

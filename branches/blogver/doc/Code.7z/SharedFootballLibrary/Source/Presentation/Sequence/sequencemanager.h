#pragma once

#ifndef  _SEQUENCEMANAGER_H_
# define _SEQUENCEMANAGER_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _SEQUENCE_DEFINES_H_
#  include "presentation/sequence/sequence_defines.h"
# endif
# ifndef _SEQUENCE_H_
#  include "presentation/sequence/sequence.h"
# endif

# ifndef __CORE_COLLECTIONS_REFLECTEDLIST_H_
#  include <collections/reflectedlist.h>
# endif
# ifndef _CRC_H
#  include <core/crc.h>
# endif
# ifndef __CORE_SINGLETON_H_
#  include <core/singleton.h>
# endif
# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class CameraManager;

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 0

		CLASSEDENUM_REFLECTED(	SEQUENCE_COMMAND_e,\
						CLASSEDENUM_ITEM(SEQUENCE_COMMAND_PLAY)\
						CLASSEDENUM_ITEM(SEQUENCE_COMMAND_STOP)\
						CLASSEDENUM_ITEM(SEQUENCE_COMMAND_STOPANDPLAY)\
						CLASSEDENUM_ITEM(SEQUENCE_NBCOMMANDS),\
						SEQUENCE_COMMAND_PLAY )

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		class SequenceCommand : public Axiom::Referenced
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			SequenceCommand(void);	
			SequenceCommand(const Axiom::StripStringCRC&, SEQUENCE_COMMAND_e);	
			virtual ~SequenceCommand(void);	

			// Public method
			const SEQUENCE_COMMAND_e& GetCommandType(void) const;
			const Axiom::StripStringCRC&	GetSequenceID(void) const;
			const void				SetSequenceID(const Axiom::StripStringCRC& rID);
			Sequence*				Execute(Sequence*, const PresentationInput&, PresentationOutput*) const;

			// Operators needed for reflection
			bool operator ==(const SequenceCommand&) const;

		private:

			// Private member variables
			SEQUENCE_COMMAND_e	m_Command;
			Axiom::StripStringCRC	m_SequenceID;
			
		};

		class SequenceWeightedCommand : public SequenceCommand
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			SequenceWeightedCommand(void);	
			SequenceWeightedCommand(const char*, SEQUENCE_COMMAND_e, float);	
			/* virtual */ ~SequenceWeightedCommand(void);	

			// Public method
			PRESENTATION_INLINE float		GetWeight() const;
			PRESENTATION_INLINE void		SetWeight(float);

		private:

			// Private member variables
			float		m_Weight;

		};

		class SequenceManager /*: public Axiom::Singleton<SequenceManager> */
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & virtual destructor
			SequenceManager();
			virtual ~SequenceManager(void);	

			// Singleton stuff 
			static SequenceManager*						Init(Axiom::Memory::HeapId);
			static void									Destroy(void);
			PRESENTATION_INLINE static SequenceManager*	GetInstance(void);

			// Sequence Add/Remove/Find
			Axiom::SmartPtr<Sequence>					AddSequence(void);
			void										RemoveSequence(const char*);
			void										RemoveSequence(const Axiom::CRC&);
			const Sequence&								FindSequence(const char*);
			const Sequence&								FindSequence(const Axiom::CRC&);
			PRESENTATION_INLINE const int				GetNbSequences(void);

			// Helpers
			const Sequence*								GetSequence(const Axiom::CRC&);
			const Sequence*								GetSequence(const char*);
			const Sequence*								GetSequence(const SEQUENCE_CATEGORY_e& rCategory, int& index );
			void										StopAllSequences(const PresentationInput&, PresentationOutput*);
			void										StopAllSequences(SEQUENCE_CATEGORY_e,const PresentationInput&, PresentationOutput*);
		
			// Events
			template <typename T> inline void			TriggerEvent(T, const PresentationInput&, PresentationOutput*);						

			// Update methods
			PRESENTATION_INLINE const Sequence*			GetUpdateSequence(void);

			void										Reset(void);
			void										Update(float, const PresentationInput&, PresentationOutput*, const unsigned int debugChannel);

			// Reflection methods
			void										PlaySequence_Reflection(char*);
			void										PauseSequence_Reflection(char*);
			void										StopSequence_Reflection(char*);

		private:

			// Reflection declaration
			AP_NON_COPYABLE( SequenceManager )

			// Friendship declaration
			friend class SequenceCommand;				// To access the private FindSequencePtr method

			// Private methods
			Sequence*									FindSequencePtr(const char*);
			Sequence*									FindSequencePtr(const Axiom::CRC&);
			void										RemoveSequencePtr(Sequence*);

#if CORE_USERDEBUG == CORE_YES
			void										SendSequenceTriggerEventEvent(int iEventID);
#endif

			// Private variable members
			static SequenceManager*															m_pInstance;

			// Sequence data
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Sequence> >					m_Sequences;

			// Update sequence
			Sequence																		*m_pUpdateSequence;

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/sequence/sequencemanager.inl"
# endif

		// Template accessors
		template <typename T> inline void SequenceManager::TriggerEvent(T tEvent, const PresentationInput &rInput, PresentationOutput *pOutput)
		{
			PRESENTATION_ASSERT( pOutput != NULL, "Sequence Error: NULL pointer passed!\n" );

# if CORE_USERDEBUG == CORE_YES
			SendSequenceTriggerEventEvent(tEvent);
# endif

			for(unsigned int i = 0; i < m_Sequences.Count(); i++)
			{
				m_pUpdateSequence = m_Sequences[i].pVal();
				if( m_pUpdateSequence->GetState() == SEQUENCE_STATE_e::SEQUENCE_STATE_PLAY )
				{
					m_pUpdateSequence->TriggerEvent<T>( tEvent, rInput, pOutput );
				}
			}
		}
	}
}

#endif

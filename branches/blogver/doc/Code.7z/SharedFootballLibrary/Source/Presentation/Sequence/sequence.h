#pragma once

#ifndef  _SEQUENCE_H_
# define _SEQUENCE_H_

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _SEQUENCE_DEFINES_H_
#  include "presentation/sequence/sequence_defines.h"
# endif
# ifndef _KEY_H_
#  include "presentation/sequence/key.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif

# ifndef _CRC_H
#  include <core/crc.h>
# endif
# ifndef __CORE_COLLECTIONS_REFLECTEDLIST_H_
#  include <collections/reflectedlist.h>
# endif
# ifndef __CORE_VECTOR2_H
#  include <math/vector2.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class Camera;
		class Viewport;

		// Reflected enums
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM(	SEQUENCE_CATEGORY_e,\
				CLASSEDENUM_ITEMWITHVALUE(SEQUENCE_CATEGORY_INVALID, -1)\
				CLASSEDENUM_ITEM(SEQUENCE_CATEGORY_ENVIRONMENT)\
				CLASSEDENUM_ITEM(SEQUENCE_CATEGORY_GAMEMODE)\
				CLASSEDENUM_ITEM(SEQUENCE_CATEGORY_CAMERA)\
				CLASSEDENUM_ITEM(SEQUENCE_CATEGORY_NIS)\
				CLASSEDENUM_ITEM(SEQUENCE_CATEGORY_FRONTEND)\
				,SEQUENCE_CATEGORY_INVALID )


				CLASSEDENUM(	SEQUENCE_STATE_e,\
				CLASSEDENUM_ITEMWITHVALUE(SEQUENCE_STATE_INVALID, -1)\
				CLASSEDENUM_ITEM(SEQUENCE_STATE_PLAY)\
				CLASSEDENUM_ITEM(SEQUENCE_STATE_PAUSE)\
				CLASSEDENUM_ITEM(SEQUENCE_STATE_STOP)\
				,SEQUENCE_STATE_INVALID )

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

	
		enum AREA_STATE_e
		{
			AREA_STATE_INVALID = -1,

			AREA_STATE_ENTER,
			AREA_STATE_IN,
			AREA_STATE_EXIT,
			AREA_STATE_OUT,

			AREA_NBSTATES,
		};

		class Area : public Shape
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Area(void);
			~Area(void);

			// Public methods
			void										SetName(const char*);
			PRESENTATION_INLINE const Axiom::StripStringCRC&	GetID(void) const;
			PRESENTATION_INLINE void					SetState(const AREA_STATE_e);
			PRESENTATION_INLINE const AREA_STATE_e		GetState(void) const;

			// Operator needed for
			const bool operator ==(const Area&) const;

		private:

			// Private members
			Axiom::StripStringCRC		m_ID;
			AREA_STATE_e			m_State;

		};

		class Sequence : public Axiom::Referenced
		{
		public:

			// Reflection declaration
			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			Sequence(void);
			virtual ~Sequence(void);

			// Public methods
			PRESENTATION_INLINE void				SetName(const char*);
			PRESENTATION_INLINE const Axiom::StripStringCRC&	GetID(void) const;

			PRESENTATION_INLINE void				SetViewport(const Viewport*);
			void									SetViewport(const Sequence*);
			PRESENTATION_INLINE const Viewport*		GetViewport(void) const;
			const Camera*							GetCamera(void) const;

			PRESENTATION_INLINE const SEQUENCE_STATE_e GetState(void) const;
			void									SetState(SEQUENCE_STATE_e);
			PRESENTATION_INLINE const SEQUENCE_CATEGORY_e GetCategory(void) const;

			Axiom::SmartPtr<Key>					AddKeyByName(const char* sName);
			PRESENTATION_INLINE const int			GetNbKeys(void) const;

			Axiom::SmartPtr<Area>					AddArea(void);
			PRESENTATION_INLINE const int			GetNbAreas(void) const;
			void									RemoveArea(const char*);
			void									RemoveArea(const Axiom::CRC&);
			const Area&								FindArea(const char*);
			const Area&								FindArea(const Axiom::CRC&);
			void									ResetAreas(void);

			Axiom::SmartPtr<Tracking>				AddAreaTracking(void);
			PRESENTATION_INLINE const int			GetNbAreaTrackings(void) const;

			float									Play(float fStartTime, const PresentationInput&, PresentationOutput*);
			float									Pause(const PresentationInput&, PresentationOutput*);
			float									Stop(const PresentationInput&, PresentationOutput*);

			template <typename T> inline void		TriggerEvent(T, const PresentationInput&, PresentationOutput*);						
			template <typename T> inline void 		TriggerEventWithID(const Axiom::CRC&, T, const PresentationInput&, PresentationOutput*);

			void									Reset(void);
			void									Update(float, const PresentationInput&, PresentationOutput*);
			void									Draw(PresentationOutput*, const unsigned int channel);

			// Operator needed for 
			const bool operator ==(const Sequence&) const;

		private:

			// Reflection Methods
#if CORE_USERDEBUG == CORE_YES
			void		SendSequenceStateChangeEvent();
#endif

			// Private constants
			static const int k_NbKeysMax = 128;
			static const int k_NbAreasMax = 16;
			static const int k_NbTrackingMax = 2;
			
			// Private member variables
			Axiom::StripStringCRC															m_ID;
			const Viewport																*m_pViewport;
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Key> >						m_Keys;
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Area> >					m_Areas;
			Axiom::Collections::ReflectedList<Axiom::SmartPtr<Tracking> >				m_AreaTrackings;

			// Area	
			bool																		m_ResetAreas;

			// Time 
			float																		m_StartTime;
			float																		m_CurrentTime;

			// State 
			SEQUENCE_STATE_e															m_State;

			// Category
			SEQUENCE_CATEGORY_e															m_Category;

			// Private methods
			void		ResetKeys(const PresentationInput&, PresentationOutput*);
			Key*		GetKeyPtr(const int);
			Area*		FindAreaPtr(const char*);
			Area*		FindAreaPtr(const Axiom::CRC&);
			void		RemoveAreaPtr(Area*);
			void		RemoveKeyPtr(Key*);

		};

		// Inlining
# ifdef PRESENTATION_USE_INLINE
#  include "presentation/sequence/sequence.inl"
# endif

		// Template accessors
		template <typename T> inline void Sequence::TriggerEvent(T tEvent, const PresentationInput &rInput, PresentationOutput *pOutput)
		{
			PRESENTATION_ASSERT( pOutput != NULL, "Camera Error: NULL pointer passed\n" );

			float fTime = m_CurrentTime - m_StartTime;
			for( unsigned int i = 0; i < m_Keys.Count(); i++)
			{
				Key *pKey = m_Keys[i].pVal();
				PRESENTATION_ASSERT( pKey != NULL, "Sequence Error: Can't retrieve key!\n" );

				if( pKey->IsValid<T>( fTime, tEvent ) )
				{
					pKey->Update( this, fTime, rInput, pOutput );
				}
			}
		}

		template <typename T> inline void Sequence::TriggerEventWithID(const Axiom::CRC &rEventID, T tEvent, const PresentationInput &rInput, PresentationOutput *pOutput)
		{
			const float fTime = m_CurrentTime - m_StartTime;
			for( unsigned int i = 0; i < m_Keys.Count(); i++)
			{
				Key *pKey = m_Keys[i].pVal();
				PRESENTATION_ASSERT( pKey != NULL, "Sequence Error: Can't retrieve key!\n" );

				const Axiom::StripStringCRC* pEventID = pKey->GetEventID();
				
				if( pEventID != NULL && rEventID == *pEventID && pKey->IsValid<T>( fTime, tEvent ) )
				{
					pKey->Update( this, fTime, rInput, pOutput );
				}
			}
		}
	}
}

#endif

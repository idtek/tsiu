#pragma once

#ifndef  _SEQUENCE_EVENTS_H_
# define _SEQUENCE_EVENTS_H_

# ifndef _SEQUENCE_H_
#  include "presentation/sequence/sequence.h"
# endif

# ifndef _EVENTMAN_H__
#  include <eventsystem/eventman.h>
# endif
# ifndef __MESSAGES_H
#  include <kernel/messages.h>
# endif

namespace AP
{
	namespace Events
	{
#if CORE_USERDEBUG == CORE_YES
		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequenceTriggerEventEvent : public Axiom::EventMsg
		{
		public:	
			AP_DECLARE_POLYMORPHIC_TYPE();

			EVENT_MSG_GUID(SequenceTriggerEventEvent);

			int		m_EventID;
			Axiom::StripStringCRC m_AreaID;

			SequenceTriggerEventEvent(int iEventID, const Axiom::StripStringCRC& rAreaId = Axiom::StripStringCRC("")) : 
				Axiom::EventMsg(EVENT_GUID),
				m_EventID(iEventID),
				m_AreaID(rAreaId)
			{
			}
			
			SequenceTriggerEventEvent(void) : 
				Axiom::EventMsg(EVENT_GUID),
				m_EventID(0),
				m_AreaID()
			{
			}
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequenceStateChangeEvent : public Axiom::EventMsg
		{
		public:	
			AP_DECLARE_POLYMORPHIC_TYPE();

			EVENT_MSG_GUID(SequenceStateChangeEvent);

			SharedSoccer::Presentation::SEQUENCE_STATE_e		m_State;
			Axiom::StripStringCRC									m_SequenceID;

			SequenceStateChangeEvent(SharedSoccer::Presentation::SEQUENCE_STATE_e state, Axiom::StripStringCRC sequenceID) : 
				Axiom::EventMsg(EVENT_GUID),
				m_State(state),
				m_SequenceID(sequenceID)
			{
			}

			SequenceStateChangeEvent(void) : 
				Axiom::EventMsg(EVENT_GUID),
				m_State(SharedSoccer::Presentation::SEQUENCE_STATE_e::SEQUENCE_STATE_INVALID)
			{
			}
		};
#endif // CORE_USERDEBUG == CORE_YES

		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequencePlayEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( SequencePlayEvent );
		
			SharedSoccer::Presentation::Sequence	*m_pSequence;
			float									m_StartTime;

			SequencePlayEvent() : EventMsg(EVENT_GUID),
				m_pSequence(NULL),
				m_StartTime(0.0f)
			{
			}

			SequencePlayEvent(SharedSoccer::Presentation::Sequence *pSequence) : EventMsg(EVENT_GUID),
				m_pSequence(pSequence),
				m_StartTime(0.0f)
			{
			}

			SequencePlayEvent(SharedSoccer::Presentation::Sequence *pSequence, float fStartTime) : EventMsg(EVENT_GUID),
				m_pSequence(pSequence),
				m_StartTime(fStartTime)
			{
			}
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequencePauseEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( SequencePauseEvent );
		
			SharedSoccer::Presentation::Sequence	*m_pSequence;

			SequencePauseEvent() : EventMsg(EVENT_GUID)
			{
			}

			SequencePauseEvent(SharedSoccer::Presentation::Sequence *pSequence) : EventMsg(EVENT_GUID),
				m_pSequence(pSequence)
			{
			}
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequenceStopEvent : public Axiom::EventMsg
		{
		public:
			EVENT_MSG_GUID( SequenceStopEvent );
		
			SharedSoccer::Presentation::Sequence	*m_pSequence;

			SequenceStopEvent() : EventMsg(EVENT_GUID)
			{
			}

			SequenceStopEvent(SharedSoccer::Presentation::Sequence *pSequence) : EventMsg(EVENT_GUID),
				m_pSequence(pSequence)
			{
			}
		};

		//-----------------------------------------------------------------------------------------------------------------------------------
		class SequenceAreaEvent : public Axiom::EventMsg
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			EVENT_MSG_GUID( SequenceAreaEvent );
		
			int										m_Event;
			Axiom::StripStringCRC						m_AreaID;
			SharedSoccer::Presentation::Sequence	*m_pSequence;

			SequenceAreaEvent() : EventMsg(EVENT_GUID)
			{
			}

			SequenceAreaEvent(const int iEvent, const Axiom::StripStringCRC &rAreaCRC, SharedSoccer::Presentation::Sequence *pSequence) : EventMsg(EVENT_GUID),
				m_Event(iEvent),
				m_AreaID(rAreaCRC),
				m_pSequence(pSequence)
			{
			}
		};
	}
}

#endif


#pragma once

#ifndef _PRESENTATION_TRANSFORMATION_DATA_H_
#define _PRESENTATION_TRANSFORMATION_DATA_H_

// Includes
# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif

#include "math/matrix4.h"

# ifndef _CLASSEDENUM_H
#  include <core/classedenum.h>
# endif

// ----------------------------------------------------------------------
namespace SharedSoccer
{
	namespace Presentation
	{

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef	 INVALIDITEMS
# define INVALIDITEMS 0

		CLASSEDENUM_REFLECTED(TRANSFORM_TYPE_e, \
			CLASSEDENUM_ITEM(TRANSFORM_CAMERALOCKED_FIRSTFRAME) \
			CLASSEDENUM_ITEM(TRANSFORM_CAMERALOCKED_PERMANENT) \
			CLASSEDENUM_ITEM(TRANSFORM_UNLOCKED) \
			CLASSEDENUM_ITEM(TRANSFORM_TRACKING_FIRSTFRAME) \
			CLASSEDENUM_ITEM(TRANSFORM_TRACKING_PERMANENT) \
			,TRANSFORM_UNLOCKED)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS


		class PresentationTransformationData
		{
		public:

			AP_DECLARE_TYPE();

			// Constructor & destructor
			PresentationTransformationData(void);
			~PresentationTransformationData(void);

			// Copy operator
			void operator=(const PresentationTransformationData&);

			// Data builders
			void GetTranslationAndRotation(const PresentationInput &rInput, Axiom::Math::Vector3& rTranslation, Axiom::Math::Quaternion& rRotation) const;
			void GetTransformAndRotation(const PresentationInput &rInput, Axiom::Math::Matrix4& rTransformation, Axiom::Math::Quaternion& rRotation) const;
			void GetTranslationAndFacing(const PresentationInput &rInput, const Axiom::Math::Vector3& rDefaultFacing, Axiom::Math::Vector3& rTranslation, Axiom::Math::Vector3& rFacing) const;
			void GetTranslationAndRotation(const PresentationInput &rInput, const Axiom::Math::Vector3& rDefaultFacing, Axiom::Math::Vector3& rTranslation, Axiom::Math::Angle& rAngle) const;
			
			// Const get methods
			PRESENTATION_INLINE bool GetUpdatesTransformEveryFrame() const;
			PRESENTATION_INLINE bool GetTransformNeedsToUpdate() const;
			PRESENTATION_INLINE TRANSFORM_TYPE_e GetTransformType() const;

			// Set methods
			PRESENTATION_INLINE void SetTranslation(const Axiom::Math::Vector3& rTranslation);
			PRESENTATION_INLINE void SetScale(const Axiom::Math::Vector3& rScale);
			PRESENTATION_INLINE void SetRotation(const Axiom::Math::Angle& xRot, const Axiom::Math::Angle& yRot, const Axiom::Math::Angle& zRot);
			PRESENTATION_INLINE void SetTransformNeedsToUpdate(bool transformNeedsToUpdate);

		private:
			// Private Methods
			void										InitializeTransformsFromTracking(const PresentationInput&, Axiom::Math::Vector3& translation, Axiom::Math::Quaternion& rotation) const;

			PRESENTATION_INLINE void					BuildRotation(Axiom::Math::Quaternion& rotation) const;
			PRESENTATION_INLINE void					BuildTranslation(Axiom::Math::Vector3& translation, const Axiom::Math::Quaternion& finalRotation) const;
			PRESENTATION_INLINE void					BuildTransform(Axiom::Math::Matrix4& result, const Axiom::Math::Vector3& finalTranslation, const Axiom::Math::Quaternion& finalRotation) const;

			// Private Data, set by user in streaker and loaded on boot
			TRANSFORM_TYPE_e				m_Type;
			TrackingData					m_Tracking;

			Axiom::Math::Vector3			m_Translation;
			Axiom::Math::Vector3			m_Scale;
			Axiom::Math::Angle				m_RotationX;
			Axiom::Math::Angle				m_RotationY;
			Axiom::Math::Angle				m_RotationZ;

			// Private data: set by code, not user
			bool							m_TransformNeedsToUpdate;
		};

// Inlining
#ifdef PRESENTATION_USE_INLINE
# include "presentation/shared/presentationtransformationdata.inl"
#endif
	}
}



#endif

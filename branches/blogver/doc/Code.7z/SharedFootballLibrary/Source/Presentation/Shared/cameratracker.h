#pragma once

#ifndef _CAMERA_TRACKER_H_
#define _CAMERA_TRACKER_H_

// Includes
# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif

// ----------------------------------------------------------------------
namespace SharedSoccer
{
	namespace Presentation
	{

		class CameraTracker
		{
		public:
			CameraTracker();
			~CameraTracker();

			void										BuildTransformsFromCamera(); 

			PRESENTATION_INLINE Axiom::Math::Vector3	GetTranslation() const; 
			PRESENTATION_INLINE Axiom::Math::Vector3	GetFront() const; 
			PRESENTATION_INLINE Axiom::Math::Quaternion	GetRotation() const; 

		private:

			// Data
			Axiom::Math::Vector3						m_CameraTranslation;
			Axiom::Math::Vector3						m_CameraFront;
			Axiom::Math::Quaternion						m_CameraRotation;
		};

// Inlining
#ifdef PRESENTATION_USE_INLINE
# include "presentation/shared/cameratracker.inl"
#endif
	}
}



#endif

// ------------------------------------------------------------------------
#include "presentation/shared/presentationtransformationdata.h"

// Additional Includes
#ifndef  _SIMULATEDPRESENTATION_H_
#include "presentation/simulatedpresentation.h"
#endif
#ifndef  _CAMERAMANAGER_H_
#include "presentation/camera/cameramanager.h"
#endif
#ifndef  _PRESENTATIONINPUT_H_
# include "presentation/presentationinput.h"
#endif
// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/shared/presentationtransformationdata.inl"
#endif

// Reflection 
// Reflection declaration
AP_TYPE(PresentationTransformationData)
	AP_DEFAULT_CREATE()
	AP_FIELD("Type", m_Type, "Specifies way PRS element will be transformed")
	AP_FIELD("Tracking", m_Tracking, "Tracking to place PRS element.. Only used if tracking type is in PRSTrackingType")
	AP_FIELD("Translation", m_Translation, "Base translation of this PRS controller")
	AP_FIELD("Scale", m_Scale, "Base scale for this PRS controller")
	AP_FIELD("RotationX", m_RotationX, "Base X rotation for the controller")
	AP_FIELD("RotationY", m_RotationY, "Base Y rotation for the controller")
	AP_FIELD("RotationZ", m_RotationZ, "Base Z rotation for the controller")
	AP_ATTRIBUTE("DefaultValue", "{Type=TRANSFORM_UNLOCKED, Scale={X=1.0, Y=1.0, Z=1.0}}") // 
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(TRANSFORM_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()


// PresentationTransformationData
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor and destructor
PresentationTransformationData::PresentationTransformationData(void) :
	m_Type(TRANSFORM_TYPE_e::TRANSFORM_UNLOCKED),
	m_Tracking(),
	m_Translation(0.0f, 0.0f, 0.0f),
	m_Scale(1.0f, 1.0f, 1.0f),
	m_RotationX(),
	m_RotationY(),
	m_RotationZ(),
	m_TransformNeedsToUpdate(false)
{
	m_Tracking.m_Tracking.Set(	AP::Reflection::Type::TypeOf("TRACKING_ENTITY_e")->CreateInstance() );
	m_Tracking.m_TrackingBone.Set(	AP::Reflection::Type::TypeOf("TRACKING_ENTITYBONE_e")->CreateInstance() );
}

PresentationTransformationData::~PresentationTransformationData(void)
{
}

// Copy operator
void PresentationTransformationData::operator=(const PresentationTransformationData &dat)
{
	m_Type = dat.m_Type;
	m_Tracking = dat.m_Tracking;
	m_Translation = dat.m_Translation;
	m_Scale = dat.m_Scale;
	m_RotationX = dat.m_RotationX;
	m_RotationY = dat.m_RotationY;
	m_RotationZ = dat.m_RotationZ;
	m_TransformNeedsToUpdate = dat.m_TransformNeedsToUpdate;
}

void PresentationTransformationData::GetTranslationAndRotation(const PresentationInput &rInput, Axiom::Math::Vector3& rTranslation, Axiom::Math::Quaternion& rRotation) const
{
	const CameraTracker& tracker = CameraManager::GetInstance()->GetCameraTracker();

	switch(m_Type)
	{
	case TRANSFORM_TYPE_e::TRANSFORM_CAMERALOCKED_FIRSTFRAME:
	case TRANSFORM_TYPE_e::TRANSFORM_CAMERALOCKED_PERMANENT:
		rRotation = tracker.GetRotation();
		rTranslation = tracker.GetTranslation();
		break;
	case TRANSFORM_TYPE_e::TRANSFORM_UNLOCKED:
		rRotation = Axiom::Math::Quaternion();
		rTranslation = Axiom::Math::Vector3();
		break;
	case TRANSFORM_TYPE_e::TRANSFORM_TRACKING_FIRSTFRAME:
	case TRANSFORM_TYPE_e::TRANSFORM_TRACKING_PERMANENT:
		InitializeTransformsFromTracking(rInput, rTranslation, rRotation);
		break;
	}

	// Here i build up my translation and rotation from the calculated values combined with the values in my structure
	// Note that I use the initial rotation to rotate the translation. KGF
	BuildTranslation(rTranslation, rRotation);
	BuildRotation(rRotation);
}

void PresentationTransformationData::GetTransformAndRotation(const PresentationInput &rInput, Axiom::Math::Matrix4& rTransformation, Axiom::Math::Quaternion& rRotation) const
{
	Axiom::Math::Vector3 translation;
	GetTranslationAndRotation(rInput, translation, rRotation);
	BuildTransform(rTransformation, translation, rRotation);
}

void PresentationTransformationData::GetTranslationAndFacing(const PresentationInput &rInput, const Axiom::Math::Vector3& rDefaultFacing, Axiom::Math::Vector3& rTranslation, Axiom::Math::Vector3& rFacing) const
{
	Axiom::Math::Quaternion rotation;
	GetTranslationAndRotation(rInput, rTranslation, rotation);
	rFacing = rDefaultFacing * rotation;
}

void PresentationTransformationData::GetTranslationAndRotation(const PresentationInput &rInput, const Axiom::Math::Vector3& rDefaultFacing, Axiom::Math::Vector3& rTranslation, Axiom::Math::Angle& rAngle) const
{
	Axiom::Math::Quaternion rotation;
	GetTranslationAndRotation(rInput, rTranslation, rotation);
	const Axiom::Math::Vector3 finalFacing = rDefaultFacing * rotation;
	rAngle = Axiom::Math::AngleBetween(rDefaultFacing, finalFacing);
}

// Private methods
void PresentationTransformationData::InitializeTransformsFromTracking(const PresentationInput &rInput, Axiom::Math::Vector3& translation, Axiom::Math::Quaternion& rotation) const
{
	Tracking	   tTracking( m_Tracking );
	TrackingResult tResult = rInput.TrackEntity( &tTracking, NULL );

	if(!(tResult.m_Report & TRACKING_REPORT_POSITION) &&
		(tResult.m_Report & TRACKING_REPORT_FACING))
	{
#if CORE_USERDEBUG==CORE_YES
		SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
		AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "PRS Error: No Simulated Presentation created!" );

		pSimulatedPresentation->AddDebugText("Tracking for PRS element failed to evaluate.");
#endif
		return;
	}

	// Set position
	translation = tResult.m_Position;

	// Set rotation
	if(tResult.m_Facing.SquareMagnitude() < Axiom::Math::EPSILON)
	{
		rotation.SetIdentity();
	}
	else
	{
		const Axiom::Math::Vector3 vFront(1.0f,0.0f,0.0f);
		const Axiom::Math::Vector3 vOrthoganal(0.0f,1.0f,0.0f);
		const Axiom::Math::Vector3 vNormalFacing = tResult.m_Facing.AsNormal();

        float CosAngle = vFront.Dot(vNormalFacing);
        CosAngle = Axiom::Math::Clamp(CosAngle, -1.0f, 1.0f );
        
        Axiom::Math::Angle tRotation = Axiom::Math::ArcCosine( CosAngle );
		if(vOrthoganal.Dot(vNormalFacing) < 0.0f)
		{
			tRotation *= -1.0f;
		}
		rotation.AxisAngle(Axiom::Math::Vector3(0.0f,0.0f,1.0f), tRotation);
    }
}

// ------------------------------------------------------------------------
#include "presentation/shared/cameratracker.h"

// Additional Includes
#ifndef  _SIMULATEDPRESENTATION_H_
#include "presentation/simulatedpresentation.h"
#endif
#ifndef  _CAMERAMANAGER_H_
#include "presentation/camera/cameramanager.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/shared/cameratracker.inl"
#endif


// PresentationCameraTracker
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CameraTracker::CameraTracker():
	m_CameraTranslation(),
	m_CameraFront(),
	m_CameraRotation()
{
}

CameraTracker::~CameraTracker()
{
}


void CameraTracker::BuildTransformsFromCamera()
{
	// Get the default viewport
	const Viewport *pViewport = CameraManager::GetInstance()->GetViewport( "Default" /* PRESENTATION_DEFAULTVIEWPORT_NAME */ );
	AP_ASSERTMESSAGE( pViewport != NULL, "Simulated PRS Manager Error: Can't retrieve Viewport!\n" );

	// Get its camera
	const Camera *pCamera = pViewport->GetCamera();

	if( pCamera == NULL )
	{
		return; // KGF TODO Should I reset the member data here?
	}

	// Recompute the framing with the original body and target data
	Framing tFraming = pCamera->GetCurrentFraming();
	tFraming.Adjust( pCamera->GetCurrentBodyPosition(), pCamera->GetCurrentTargetPosition(), pCamera->GetCurrentZoom(), pCamera->GetCurrentRoll() );

	if( !pViewport->IsInDebugMode() )
	{
		m_CameraTranslation = tFraming.GetBodyPosition();
		m_CameraFront = tFraming.GetTargetPosition() - m_CameraTranslation;
		m_CameraFront.Normalize();
	}

	// Picking up pitch and heading
	Yaw tYaw( tFraming.GetBodyPosition(), tFraming.GetTargetPosition() ); 
	const Axiom::Math::Angle currentPitch = Axiom::Math::Angle( NormalizeAngle( -tYaw.GetPitch() - Axiom::Math::PI_DIV_TWO) );
	const Axiom::Math::Angle currentHeading = Axiom::Math::Angle( NormalizeAngle( -tYaw.GetHeading() + Axiom::Math::PI_DIV_TWO) );
	const Axiom::Math::Angle currentRoll = Axiom::Math::Angle(pCamera->GetCurrentRoll());
	const Axiom::Math::Angle conversionAngle = Axiom::Math::Angle( -Axiom::Math::PI_DIV_TWO );

	// Applying rotations
	Axiom::Math::Quaternion pitchRotation, headingRotation, conversionRotation; //, rollRotation;
	pitchRotation.AxisAngle(Axiom::Math::Vector3(1.0f,0.0f,0.0f), currentPitch );
	//rollRotation.AxisAngle(Axiom::Math::Vector3(0.0f,1.0f,0.0f), currentRoll );
	headingRotation.AxisAngle(Axiom::Math::Vector3(0.0f,0.0f,1.0f), currentHeading );
	conversionRotation.AxisAngle(Axiom::Math::Vector3(0.0f,0.0f,1.0f), conversionAngle );
	m_CameraRotation = pitchRotation * headingRotation * conversionRotation; // * rollRotation
}


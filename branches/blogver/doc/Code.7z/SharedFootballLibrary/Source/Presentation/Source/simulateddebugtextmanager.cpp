
#ifndef _SIMULATED_DEBUG_TEXT_H_
# include "presentation/simulateddebugtextmanager.h"
#endif
#ifndef _PRESENTATIONOUTPUT_H_
# include "presentation/presentationoutput.h"
#endif

#ifndef GEL_DEBUG_H
# include <gel/debug.h>
#endif

#if CORE_USERDEBUG==CORE_YES

// Namespace usage
using namespace SharedSoccer;
using namespace SharedSoccer::Presentation;

// Inlining
#ifndef PRESENTATON_USE_INLINE
# include "presentation/simulateddebugtextmanager.inl"
#endif


// Constructor & destructor
SimulatedDebugTextElement::SimulatedDebugTextElement(const Axiom::ShortString &rText, float fTime) : 
	m_Text(rText), 
	m_RemoveTime(fTime)
{
}

SimulatedDebugTextElement::~SimulatedDebugTextElement(void) 
{
}

// Constructor & destructor
SimulatedDebugTextManager::SimulatedDebugTextManager(const Axiom::Math::Vector2 vPosition) :
	m_DebugTextList(),
	m_Position(vPosition)
{
}

SimulatedDebugTextManager::~SimulatedDebugTextManager(void)
{
	Reset();
}

void SimulatedDebugTextManager::Reset()
{
	m_DebugTextList.Clear();
	m_CurrentTime = 0.0f;
}

void SimulatedDebugTextManager::AddText(const Axiom::ShortString &rText, float fSecondsToDisplay)
{
	float						fRemoveTime = fSecondsToDisplay + m_CurrentTime;
	const float					fDuplicateRemoveDelay = 0.1f;
	// Replace old element with new time if its already in the list
	for(unsigned int i = 0; i < m_DebugTextList.Count(); i++)
	{
		if(m_DebugTextList[i].GetText() == rText)
		{
			if(m_CurrentTime + fDuplicateRemoveDelay >= m_DebugTextList[i].GetRemoveTime())
			{
				m_DebugTextList[i].SetRemoveTime(m_DebugTextList[i].GetRemoveTime() + fDuplicateRemoveDelay);
			}
			return;
		}
	}

	// Log text to regular output channel
	Axiom::Log("Presentation", "%s", rText.AsChar());
	
	// Add new element to my manager
	SimulatedDebugTextElement	tNewElement(rText, fRemoveTime);
	if( m_DebugTextList.Count() < static_cast<unsigned int>(PRESENTATION_DEBUGTEXT_NBLINES_MAX) )
	{
		m_DebugTextList.Add(tNewElement);
	}
	else
	{
		int		i = 0;
		float	fLowestTime = m_DebugTextList[0].GetRemoveTime();
		for( unsigned int j=1 ; j < m_DebugTextList.Count() ; j++ )
		{
			if( m_DebugTextList[j].GetRemoveTime() < fLowestTime )
			{
				i = j;
				fLowestTime = m_DebugTextList[j].GetRemoveTime();
			}
		}
		m_DebugTextList[i].SetText(rText);
		m_DebugTextList[i].SetRemoveTime(fRemoveTime);
	}
}

void SimulatedDebugTextManager::Update(const Axiom::TimeAbsolute &rCurrentTime, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( pOutput != NULL, "Debug Text Manager Error: NULL pointer passed!\n" );

	m_CurrentTime = rCurrentTime.AsFloatInSeconds();

	// Remove Old Entries from list
	for( int i = ( m_DebugTextList.Count() - 1 ) ; i >=0 ; i-- )
	{
		if(m_CurrentTime > m_DebugTextList[i].GetRemoveTime())
		{
			m_DebugTextList.RemoveAt(i);
		}
	}

	for(unsigned int i = 0; i < m_DebugTextList.Count(); i++)
	{
		float x = m_Position.X();
		float y = m_Position.Y() - static_cast<float>(i) * PRESENTATION_DEBUGTEXT_LINE_HEIGHT;
//		AP::Debug::DebugDraw::GetInstance()->DrawText2D(x, y, m_DebugTextList[i].GetText().AsChar(), Gel::Debug::COLOR_WHITE);
		pOutput->Draw2DText( x, y, m_DebugTextList[i].GetText().AsChar(), Gel::Debug::COLOR_WHITE );
	}
}

#endif

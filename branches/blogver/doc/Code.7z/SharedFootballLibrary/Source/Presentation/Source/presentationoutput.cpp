
#ifndef _PRESENTATIONOUTPUT_H_
# include "presentation/presentationoutput.h"
#endif
#ifndef  _PRESENTATION_EVENTS_H_
# include "presentation/presentation_events.h"
#endif

#ifndef _COMPONENT_MANAGER_H
# include <kernel/componentmanager.h>
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace SharedSoccer::Presentation;

// Constructor and virtual destructor
PresentationOutput::PresentationOutput(void)
{
}

/* virtual */ PresentationOutput::~PresentationOutput(void)
{
}

// Public functions
void PresentationOutput::NotifyViewportChange( const Orientation &rOrientation )
{
	AP::Events::PresentationUpdateViewportEvent evtPresentationUpdateViewport(  rOrientation.GetOrigin(), rOrientation.GetFront(), rOrientation.GetUp(), rOrientation.GetSide() );
	SEND_EVENT( evtPresentationUpdateViewport ); 
}

// Public default virtual functions
/* virtual */ void PresentationOutput::ExportViewportData(	VIEWPORT_USAGE_e, 
															const Orientation&, const float, const float, const float, const float,
															const Axiom::Math::Vector3& pointerValue )
{
	UNUSED_PARAM( pointerValue );
}

/* virtual */ void PresentationOutput::ExportBakedViewportData(const Axiom::CRC& rBakedCameraID, const float bakedCameraTime,
															   const Axiom::Math::Quaternion& rBaseRotation, const Axiom::Math::Vector3& rBasePosition, 
															   const float fov, const bool useCurvedPitchCalc,
															   const SharedSoccer::Presentation::ViewportCameraData& rSourceCamera, const float blendFraction)
{
	UNUSED_PARAM( rBakedCameraID );
	UNUSED_PARAM( bakedCameraTime );
	UNUSED_PARAM( rBaseRotation );
	UNUSED_PARAM( rBasePosition );
	UNUSED_PARAM( fov );
	UNUSED_PARAM( useCurvedPitchCalc );
	UNUSED_PARAM( rSourceCamera );
	UNUSED_PARAM( blendFraction );
}


/* virtual */ void PresentationOutput::ExportPRSElementData(const Axiom::Math::Matrix4& transform,
															const Axiom::Math::Quaternion& rotation,
															float frame,
															const Axiom::StripStringCRC& prsControllerName,
															const Axiom::StripStringCRC& clusterName,
															const SharedSoccer::Presentation::PRS_DRAW_ORDER_e& prsDrawOrder,
															const Axiom::CRC& sceneHashName,
															bool prsRequiresUpdating,
															bool clusterRequiresDrawing )
{
	UNUSED_PARAM( transform );
	UNUSED_PARAM( rotation );
	UNUSED_PARAM( frame );
	UNUSED_PARAM( prsControllerName );
	UNUSED_PARAM( clusterName );
	UNUSED_PARAM( prsDrawOrder );
	UNUSED_PARAM( sceneHashName );
	UNUSED_PARAM( prsRequiresUpdating );
	UNUSED_PARAM( clusterRequiresDrawing );
}


/* virtual */ void PresentationOutput::ExportParticleData(	const Axiom::StripStringCRC& systemID,
								 Particle::ParticleSystemDefinition_c* def,
								 float elapsedTime,
								 const Particle::ParticleTransformDataArray& transformData,
								 char revisionNumber)
{
	UNUSED_PARAM( systemID );
	UNUSED_PARAM( def );
	UNUSED_PARAM( elapsedTime );
	UNUSED_PARAM( transformData );
	UNUSED_PARAM( revisionNumber );
}

/* virtual */ void PresentationOutput::Draw2DText(float,float,const char*,const Graphics::Color&)
{
}

/* virtual */ void PresentationOutput::DrawLine( const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const Graphics::Color&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawSphere( const Axiom::Math::Vector3&, const float, const Graphics::Color&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawVolume( const BaseVolume&, const Graphics::Color&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawShape( const BaseShape&, const Graphics::Color&, const unsigned int channel, float fZ /*=0.0f*/ )
{
	UNUSED_PARAM(channel);
	UNUSED_PARAM(fZ);
}

/* virtual */ void PresentationOutput::DrawPoint( const Point&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawArrow( const Axiom::Math::Vector3&, const Axiom::Math::Vector3&, const Graphics::Color&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawCylinder( const Axiom::Math::RigidMatrix&, const SharedSoccer::Shape::Cylinder&, const Graphics::Color&, const unsigned int numSubdivisions, const unsigned int channel )
{
	UNUSED_PARAM(numSubdivisions);
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawBox( const Axiom::Math::RigidMatrix&, const SharedSoccer::Shape::Box&, const Graphics::Color&, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}

/* virtual */ void PresentationOutput::DrawLineList( const LineList& list, const Graphics::Color& colour, const unsigned int channel )
{
	UNUSED_PARAM(channel);
}
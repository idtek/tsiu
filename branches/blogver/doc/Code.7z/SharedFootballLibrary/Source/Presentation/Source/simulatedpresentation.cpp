
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif
#ifndef _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef _SEQUENCEMANAGER_H_
# include "presentation/sequence/sequencemanager.h"
#endif

#if CORE_WII
	void ResetWiiEnvH_Globals();
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace SharedSoccer::Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/simulatedpresentation.inl"
#endif

// Reflection declaration
AP_TYPE(BUTTON_e)
	AP_ENUM()
AP_TYPE_END()

AP_TYPE(SimulatedPresentation)
	AP_NAMED_COMMAND("Reset", Reset_Reflection, "Reset the simulated presentation")
AP_TYPE_END()

// Static member variables
SimulatedPresentation* SimulatedPresentation::m_pInstance = NULL;

// Simulated Presentation control
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
SimulatedPresentationControl::SimulatedPresentationControl(void) :
	m_Position(),
	m_Orientation(),
	m_CurrentButtons(0),
	m_PreviousButtons(0)
{
}

SimulatedPresentationControl::~SimulatedPresentationControl(void)
{
}

// Public methods
void SimulatedPresentationControl::SetOrientation(const Axiom::Math::Vector2 &rOrientation)
{
	m_Orientation = rOrientation;
}

void SimulatedPresentationControl::SetPosition(const Axiom::Math::Vector2 &rPosition)
{
	m_Position = rPosition;
}

const Axiom::Math::Vector2&	SimulatedPresentationControl::GetPosition(void)
{
	return m_Position;
}

const Axiom::Math::Vector2& SimulatedPresentationControl::GetOrientation(void)
{
	return m_Orientation;
}

const bool SimulatedPresentationControl::IsButtonPressed(const BUTTON_e eButton)
{
	return ( m_CurrentButtons & ( 1 << eButton ) ) != 0; 
}

const bool SimulatedPresentationControl::IsButtonPressedOnce(const BUTTON_e eButton)
{
	int iPressedButton = ( 1 << eButton );
	return ( m_CurrentButtons & iPressedButton ) != 0 && ( m_PreviousButtons & iPressedButton ) == 0; 
}

// Simulated Presentation interface
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
SimulatedPresentation_Interface::SimulatedPresentation_Interface(void)
{
}

/* virtual */SimulatedPresentation_Interface::~SimulatedPresentation_Interface(void)
{
}

// Simulation presentation
// --------------------------------------------------------------------------------------------------

// Creator and destructor
SimulatedPresentation::SimulatedPresentation(void) : 
	m_pCameraManager(NULL),
	m_pSequenceManager(NULL),
	m_pSimulatedPRSManager(NULL),
	m_pControl(NULL),
	m_hMessageBox(),
	m_pImplementation(NULL),
	m_BypassAreas(false),
	m_CurrentTime(),
#if CORE_USERDEBUG==CORE_YES
	m_DeltaTime(0.0f),
	m_pDebugTextManager(NULL)
#else
	m_DeltaTime(0.0f)
#endif
{
	// Create the camera manager and keep a link of it
	m_pCameraManager = CameraManager::Init(Axiom::Memory::PRESENTATION_HEAP);

	// Create the sequence manager and keep a link of it
	m_pSequenceManager = SequenceManager::Init(Axiom::Memory::PRESENTATION_HEAP);

	// Create the PRS manager and keep a link of it
	m_pSimulatedPRSManager = SimulatedPRSManager::Init(Axiom::Memory::PRESENTATION_HEAP);

	// Create the text manager
	AP_USERDEBUG_SUPPORT(m_pDebugTextManager = AP_NEW(Axiom::Memory::PRESENTATION_HEAP, SimulatedDebugTextManager(Axiom::Math::Vector2(50.0f,440.0f))));

	// Create the presentation control
	SimulatedPresentationControl::Init(Axiom::Memory::PRESENTATION_HEAP);
	m_pControl = SimulatedPresentationControl::GetInstance();
}

SimulatedPresentation::~SimulatedPresentation(void)
{
	// Release the presentation control
	SimulatedPresentationControl::Destroy();
	m_pControl = NULL;

#if CORE_USERDEBUG==CORE_YES
	// Release the text manager
	if(m_pDebugTextManager != NULL) 
	{
		AP_DELETE( m_pDebugTextManager );
	}
#endif

	// Release the PRS manager
	SimulatedPRSManager::Destroy();
	m_pSimulatedPRSManager = NULL;

	// Release the sequence manager
	SequenceManager::Destroy();
	m_pSequenceManager = NULL;

	// Release the camera manager
	CameraManager::Destroy();
	m_pCameraManager = NULL;
}

// Public static methods
/* static */ SimulatedPresentation* SimulatedPresentation::Init(Axiom::Memory::HeapId iHeapID)
{
	PRESENTATION_ASSERT( m_pInstance == NULL, "Presentation Error: Init should only be called once!\n");

	// Create the singleton
	m_pInstance = AP_NEW( iHeapID, SimulatedPresentation());
	PRESENTATION_ASSERT( m_pInstance != NULL, "Presentation Error: Can't create the instance!\n");

	// Reflect
	AP::Reflection::Script::Register("SimulatedPresentation", AP::Reflection::Instance(m_pInstance), "New Presentation Tool");

	return m_pInstance;
}

/* static */ void SimulatedPresentation::Destroy(void)
{
	// De-reflect
	AP::Reflection::Script::Unregister("SimulatedPresentation");

	// De-stroy
	PRESENTATION_DELETE(m_pInstance->m_pImplementation);
	m_pInstance->m_pImplementation = NULL;

	PRESENTATION_DELETE(m_pInstance);
	m_pInstance = NULL;
}

// Public virtual methods
void SimulatedPresentation::Reset(void)
{
	PRESENTATION_ASSERT( m_pImplementation != NULL, "Presentation Error: Simulation Interface not registred!\n" );

	// Reset time
	m_CurrentTime = Axiom::TimeAbsolute::Zero();

	// Reset the title specific
	m_pImplementation->Reset();

	// Reset the components
	m_pSequenceManager->Reset();
	m_pCameraManager->Reset();
	m_pSimulatedPRSManager->Reset();

	// Reset the debug compoments
#if CORE_USERDEBUG==CORE_YES
	m_pDebugTextManager->Reset();
#endif

// reset global shader parameters (building alpha, player indicator colours, etc.)
#if CORE_WII
	ResetWiiEnvH_Globals();
#endif

}

void SimulatedPresentation::Init(void)
{
	PRESENTATION_ASSERT( m_pImplementation != NULL, "Presentation Error: Simulation Interface not registred!\n" );

	m_pImplementation->Init();
}

void SimulatedPresentation::RegisterEvents(Axiom::EventMsgBoxHandle hMsgBox)
{
	PRESENTATION_ASSERT( m_pImplementation != NULL, "Presentation Error: Simulation Interface not registred!\n" );

	m_hMessageBox = hMsgBox;

	m_pImplementation->RegisterEvents(hMsgBox);
}

void SimulatedPresentation::HandleEvents(const PresentationInput &rInput, PresentationOutput *pOutput)
{
	PRESENTATION_ASSERT( m_pImplementation != NULL, "Presentation Error: Simulation Interface not registred!\n" );

	// Manage the given message box
	m_pImplementation->HandleEvents(m_hMessageBox,rInput,pOutput);

	// Clear and flush my message box
	m_hMessageBox->ClearInbox();
	m_hMessageBox->ClearOutbox();
}

void SimulatedPresentation::Update(const Axiom::TimeAbsolute &rTime, const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int debugChannel)
{
	PRESENTATION_ASSERT( m_pImplementation != NULL, "Presentation Error: Simulation Interface not registred!\n" );
	PRESENTATION_ASSERT( pOutput != NULL, "Presentation Error: NULL pointer passed!\n" );
	
	// Compute delta time
	Axiom::Time tDeltaTime = rTime - m_CurrentTime;
	m_DeltaTime = tDeltaTime.AsFloatInSeconds();
	m_CurrentTime = rTime;

	// Perform the specifics
	m_pImplementation->Update(m_DeltaTime,rInput,pOutput);

	// Update the components
	m_pSequenceManager->Update( m_DeltaTime, rInput, pOutput, debugChannel );
	m_pCameraManager->Update( m_DeltaTime, rInput, pOutput, debugChannel );
	m_pSimulatedPRSManager->Update( m_DeltaTime, rInput, pOutput );

	// Update the debug components
#if CORE_USERDEBUG==CORE_YES
	m_pDebugTextManager->Update( m_CurrentTime, pOutput );
#endif
}

// Debug methods
#if CORE_USERDEBUG==CORE_YES
void SimulatedPresentation::AddDebugText(const Axiom::ShortString &rText, float fSecondsToDisplay /*=PRESENTATION_DEBUGTEXT_SECONDSTODISPLAY*/)
{
	PRESENTATION_ASSERT(m_pDebugTextManager != NULL, "Presentation Error: Text manager not created!\n");
	m_pDebugTextManager->AddText( rText, fSecondsToDisplay );
}

void SimulatedPresentation::SetDebugMode(bool bDebugMode, bool bOverwrite /*=false*/, bool bCopyData /*=true*/ )
{
	// TODO: This is very bad!
	SetDebugMode( "Debug.Controlled"/* PRESENTATION_DEBUGCAMERA_NAME*/ , bDebugMode, bOverwrite, bCopyData );
}

void SimulatedPresentation::SetDebugMode(const char *pCameraName, bool bDebugMode, bool bOverwrite /*=false*/, bool bCopyData /*=true*/ )
{
	// Get the viewport of this sequence
	Viewport *pViewport = CameraManager::GetInstance()->FindViewportPtr( "Default" /*PRESENTATION_DEFAULTVIEWPORT_NAME*/ );
	PRESENTATION_ASSERT( pViewport != NULL, "Sequence Error: No viewport in current sequence!\n" );

	pViewport->SetDebugCamera( pCameraName, bDebugMode, bOverwrite, bCopyData );
}
#endif
	
// Reflected functions
void SimulatedPresentation::Reset_Reflection(void)
{
	Reset();
}

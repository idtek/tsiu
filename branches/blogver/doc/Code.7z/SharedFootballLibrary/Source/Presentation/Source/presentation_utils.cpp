
#ifndef  _PRESENTATION_UTILS_H_
# include "presentation/presentation_utils.h"
#endif
#ifndef  _PRESENTATIONINPUT_H_
# include "presentation/presentationinput.h"
#endif
#ifndef  _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef  _CAMERA_H_
# include "presentation/camera/camera.h"
#endif
#ifndef  _CAMERAGAMEPLAY_H_
# include "presentation/camera/source/cameragameplay.h"
#endif
#ifndef  _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif
#ifndef  _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif
#ifndef  _PRESENTATION_EVENTS_H_
# include "presentation/presentation_events.h"
#endif
#ifndef _COMPONENT_MANAGER_H
# include <kernel/componentmanager.h>
#endif

#ifndef _APMATH_H
# include <math/apmath.h>
#endif
#ifndef __CORE_FRUSTUM_H
# include "shape/frustum.h"
#endif
#ifndef _RANDOM_H___
# include <core/random.h>
#endif

// Namespace usage
using namespace SharedSoccer::Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "presentation/presentation_utils.inl"
#endif

// Reflection declaration
AP_TYPE(BaseShape)
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Shape)
	AP_BASE_TYPE(BaseShape)
	AP_DEFAULT_CREATE()
	AP_FIELD("Type",m_Type,"Type");
	AP_FIELD("Center",m_Center,"Center")
	AP_FIELD("Width",m_Width,"Width")
	AP_FIELD("Height",m_Height,"Height")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(FlexibleShape)
	AP_BASE_TYPE(BaseShape)
	AP_DEFAULT_CREATE()
	AP_FIELD("Type",m_Type,"Type");
	AP_FIELD("Center",m_Center,"Center")
	AP_FIELD("Width",m_Width,"Width")
	AP_FIELD("Height",m_Height,"Height")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(BaseVolume)
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Volume)
	AP_BASE_TYPE(BaseVolume)
	AP_DEFAULT_CREATE()
	AP_FIELD("Type",m_Type,"Type");
	AP_FIELD("Center",m_Center,"Center")
	AP_FIELD("Width",m_Width,"Width")
	AP_FIELD("Height",m_Height,"Height")
	AP_FIELD("Depth",m_Depth,"Depth")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(FlexibleVolume)
	AP_BASE_TYPE(BaseVolume)
	AP_DEFAULT_CREATE()
	AP_FIELD("Type",m_Type,"Type");
	AP_FIELD("Center",m_Center,"Center")
	AP_FIELD("Width",m_Width,"Width")
	AP_FIELD("Height",m_Height,"Height")
	AP_FIELD("Depth",m_Depth,"Depth")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Framing)
	AP_FIELD("Offset", m_Offset, "Offset")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(TrackingData)
	AP_FIELD("Tracking", m_Tracking, "Tracking entity")
		AP_FIELD_ATTRIBUTE("GuiConstrainToTypeName", "TRACKING_ENTITY_e")
		AP_FIELD_ATTRIBUTE("AllowNull", "false")
	AP_FIELD("TrackingBone", m_TrackingBone, "Entity's bone")
		AP_FIELD_ATTRIBUTE("GuiConstrainToTypeName", "TRACKING_ENTITYBONE_e")
		AP_FIELD_ATTRIBUTE("AllowNull", "false")
	AP_FIELD("OffsetType", m_OffsetType, "Type of offset")
	AP_FIELD("Offset", m_Offset, "Offset")
	AP_FIELD("Weight", m_Weight, "Weight")
	AP_FIELD("VolumeSize", m_VolumeSize, "Volume size" )
	AP_FIELD("ForcedToBeIncluded", m_ForcedToBeIncluded, "Included")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Tracking)
	AP_DEFAULT_CREATE()
	AP_FIELD("Data", m_Data, "Tracking data")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Noise)
	AP_FIELD("Magnitude", m_Magnitude, "Magnitude")
	AP_FIELD("Frequency", m_Frequency, "Frequency")
	AP_FIELD("Duration", m_InitialDuration, "Duration (overridden if key that triggers this uses a time range)")
	AP_ATTRIBUTE("DefaultValue", "{Magnitude=0.0333, Frequency=10.0, Duration=1.0}")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(Colour)
	AP_FIELD("R", m_R, "Red value")
	AP_FIELD("G", m_G, "Green value")
	AP_FIELD("B", m_B, "Blue value")
	AP_FIELD("A", m_A, "Alpha value")
	AP_ATTRIBUTE("ProxyAttribute", "[System.ComponentModel.Editor(typeof(SharedFootballLibraryProxy.SequenceColourUITypeEditor), typeof(System.Drawing.Design.UITypeEditor))]")
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(SHAPE_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(TRACKING_OFFSETTYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(TRACKING_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(VOLUME_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

// Shape
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Private methods
Axiom::Math::Vector2 BaseShape::ConstrainOrientedRectangle(const Axiom::Math::Vector3 &rPosition)
{
	// Compute the rectangle
	float fHalfWidth = GetWidth() / 2.0f;
	float fHalfHeight = GetHeight() / 2.0f;
	Axiom::Math::Vector3 vCorners[] = { Axiom::Math::Vector3( -fHalfWidth, -fHalfHeight, 0.0f ),
										Axiom::Math::Vector3(  fHalfWidth, -fHalfHeight, 0.0f ),
										Axiom::Math::Vector3(  fHalfWidth,  fHalfHeight, 0.0f ),
										Axiom::Math::Vector3( -fHalfWidth,  fHalfHeight, 0.0f ) };

	// Rotate & translate to the center
	Axiom::Math::Vector3 vCenter = Axiom::Math::Vector3( m_Center.X(), m_Center.Y(), 0.0f );
	for( int i = 0 ; i < 4 ; ++i )
	{
		vCorners[i] = RotateZ( vCorners[i], m_Orientation );
		vCorners[i] += vCenter;
	}

	// Test if the vector is in the box
	bool					bIsOutside = false;
	float					fN, fD, fT,	fTL = 1.0f;
	Axiom::Math::Vector3	vEdge, vDelta, vDirection = rPosition - vCenter;
	for( int i = 0 ; i < 4 ; ++i )
	{
		vEdge = vCorners[(i+1)&3] - vCorners[i];
		vEdge.Normalize();
		vDelta = rPosition - vCorners[i];

		fN = vEdge.Dot(vDelta);			// Dot product
		fD = -vEdge.Dot(vDirection);	// Dot product
		fT = fN / fD;
		if( fD > 0.0f && fT < fTL )
		{
			fTL = fT;
			if( fTL < 0.0f )
			{
				bIsOutside = true;
			}
		}
	}

	// Update the center
	if( bIsOutside )
	{
		vDirection *= (fTL + 1.0f);
		vCenter = rPosition - vDirection;
	}

	return Axiom::Math::Vector2( vCenter.X(), vCenter.Y() );
}

bool BaseShape::IsInOrientedRectangle(const Axiom::Math::Vector3 &rPosition)
{
	// Compute the rectangle
	float fHalfWidth = GetWidth() / 2.0f;
	float fHalfHeight = GetHeight() / 2.0f;
	Axiom::Math::Vector3 vCorners[] = { Axiom::Math::Vector3( -fHalfWidth, -fHalfHeight, 0.0f ),
										Axiom::Math::Vector3(  fHalfWidth, -fHalfHeight, 0.0f ),
										Axiom::Math::Vector3(  fHalfWidth,  fHalfHeight, 0.0f ),
										Axiom::Math::Vector3( -fHalfWidth,  fHalfHeight, 0.0f ) };

	// Rotate & translate to the center
	Axiom::Math::Vector3 vCenter = Axiom::Math::Vector3( m_Center.X(), m_Center.Y(), 0.0f );
	for( int i = 0 ; i < 4 ; ++i )
	{
		vCorners[i] = RotateZ( vCorners[i], m_Orientation );
		vCorners[i] += vCenter;
	}

	// Test if the vector is in the box
	bool					bIsOutside = false;
	float					fN, fD, fT,	fTL = 1.0f;
	Axiom::Math::Vector3	vEdge, vDelta, vDirection = rPosition - vCenter;
	for( int i = 0 ; i < 4 ; ++i )
	{
		vEdge = vCorners[(i+1)&3] - vCorners[i];
		vEdge.Normalize();
		vDelta = rPosition - vCorners[i];

		fN = vEdge.Dot(vDelta);			// Dot product
		fD = -vEdge.Dot(vDirection);	// Dot product
		fT = fN / fD;
		if( fD > 0.0f && fT < fTL )
		{
			fTL = fT;
			if( fTL < 0.0f )
			{
				bIsOutside = true;
			}
		}
	}

	return bIsOutside;
}

// Constructor & destructor
BaseShape::BaseShape() :
	m_Type(SHAPE_TYPE_e::SHAPE_TYPE_INVALID),
	m_Center(),
	m_Orientation(0.0f)
{
}

BaseShape::BaseShape(const SHAPE_TYPE_e &rType) :
	m_Type(rType),
	m_Center(),
	m_Orientation(0.0f)
{
}

BaseShape::~BaseShape(void)
{
}

// Public methods
void BaseShape::SetCenter(const Axiom::Math::Vector2 &vCenter)
{
	m_Center = vCenter;
}

void BaseShape::SetCenter(const float fPositionX, const float fPositionY)
{
	m_Center.X( fPositionX );
	m_Center.Y( fPositionY );
}

const Axiom::Math::Vector2& BaseShape::GetCenter(void) const
{
	return m_Center;
}

void BaseShape::SetOrientation(const Axiom::Math::Vector3 &rOrientationReference)
{
	Axiom::Math::Vector3 vCenter = Axiom::Math::Vector3( m_Center.X(), m_Center.Y(), 0.0f );
	Axiom::Math::Vector3 vOrientation = rOrientationReference - vCenter;
	float fMagnitude = vOrientation.Magnitude();
	if( fMagnitude > 0.0f )
	{
		vOrientation /= fMagnitude;
	}
	m_Orientation = NormalizeAngle( atan2f( vOrientation.Y(), vOrientation.X() ) );
}

bool BaseShape::IsIn(const Axiom::Math::Vector3 &rPosition)
{
	switch( m_Type )
	{
	case SHAPE_TYPE_e::SHAPE_TYPE_CIRCLE:
		{
			Axiom::Math::Vector3 vCenter = Axiom::Math::Vector3( m_Center.X(), m_Center.Y(), 0.0f );
			vCenter -= rPosition;
			
			if( vCenter.Magnitude() < GetWidth() )
			{
				return true;
			}
		}
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;

			if( rPosition.X() <  ( m_Center.X() + fHalfWidth  ) &&
				rPosition.X() >= ( m_Center.X() - fHalfWidth  ) &&
				rPosition.Y() <  ( m_Center.Y() + fHalfHeight ) &&
				rPosition.Y() >= ( m_Center.Y() - fHalfHeight ) )
			{
				return true;
			}
		}
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_ORIENTEDRECTANGLE:
		return IsInOrientedRectangle(rPosition);
	default:
		break;
	}

	return false;
}

const Axiom::Math::Vector3 BaseShape::Restrain(const Axiom::Math::Vector3 &rPosition)
{
	Axiom::Math::Vector3 vRestrained = rPosition;
	switch( m_Type )
	{
	case SHAPE_TYPE_e::SHAPE_TYPE_CIRCLE:
		// TODO: Restrain the point inside the circle
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;

			float fClamp = m_Center.X() + fHalfWidth;
			if( rPosition.X() > fClamp )
			{
				vRestrained.X( fClamp );
			}
			else
			{
				fClamp = m_Center.X() - fHalfWidth;
				if( rPosition.X() < fClamp )
				{
					vRestrained.X( fClamp );
				}
			}
			fClamp = m_Center.Y() + fHalfHeight;
			if( rPosition.Y() > fClamp )
			{
				vRestrained.Y( fClamp );
			}
			else
			{
				fClamp = m_Center.Y() - fHalfHeight;
				if( rPosition.Y() < fClamp )
				{
					vRestrained.Y( fClamp );
				}
			}
		}
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_ORIENTEDRECTANGLE:
		break;
	default:
		break;
	}

	return vRestrained;
}

const Axiom::Math::Vector3 BaseShape::CameraRestrain(const Axiom::Math::Vector3 &rPosition, const Camera *pCamera, const BOUNDARY_TYPE_e &rType )
{
	PRESENTATION_ASSERT( pCamera != NULL, "Presentation Error: NULL pointer passed!\n" );

	Axiom::Math::Vector3 vRestrained = rPosition;
	switch( m_Type )
	{
	case SHAPE_TYPE_e::SHAPE_TYPE_CIRCLE:
		// TODO: Restrain the point inside the circle
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;

			float fClamp = m_Center.X() + fHalfWidth;
			if( rPosition.X() > fClamp )
			{
				vRestrained.X( fClamp );

				// Send an event with pCamera/rType/Axis info
			}
			else
			{
				fClamp = m_Center.X() - fHalfWidth;
				if( rPosition.X() < fClamp )
				{
					vRestrained.X( fClamp );

					// Send an event with pCamera/rType/Axis info
				}
			}
			fClamp = m_Center.Y() + fHalfHeight;
			if( rPosition.Y() > fClamp )
			{
				vRestrained.Y( fClamp );

				// Send an event with pCamera/rType/Axis info
			}
			else
			{
				fClamp = m_Center.Y() - fHalfHeight;
				if( rPosition.Y() < fClamp )
				{
					vRestrained.Y( fClamp );

					// Send an event with pCamera/rType/Axis info
				}
			}
		}
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_ORIENTEDRECTANGLE:
		break;
	default:
		break;
	}

	return vRestrained;
}
const Axiom::Math::Vector3 BaseShape::Constrain(const Axiom::Math::Vector3 &rPosition)
{
	switch( m_Type )
	{
	case SHAPE_TYPE_e::SHAPE_TYPE_CIRCLE:
		// TODO: Move the circle to keep the point inside
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_RECTANGLE:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;

			float fClamp = rPosition.X() - fHalfWidth;
			if( fClamp > m_Center.X()  )
			{
				m_Center.X( fClamp );
			}
			else
			{
				fClamp = rPosition.X() + fHalfWidth;
				if( fClamp < m_Center.X() )
				{
					m_Center.X( fClamp );
				}
			}
			fClamp = rPosition.Y() - fHalfHeight;
			if( fClamp > m_Center.Y() )
			{
				m_Center.Y( fClamp );
			}
			else
			{
				fClamp = rPosition.Y() + fHalfHeight;
				if( fClamp < m_Center.Y() )
				{
					m_Center.Y( fClamp );
				}
			}
		}
		break;
	case SHAPE_TYPE_e::SHAPE_TYPE_ORIENTEDRECTANGLE:
		m_Center = ConstrainOrientedRectangle(rPosition);
		break;
	default:
		break;
	}

	return Axiom::Math::Vector3( m_Center.X(), m_Center.Y(), rPosition.Z() );
}


// Shape
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Shape::Shape() : BaseShape(),	
	m_Width(0.0f),
	m_Height(0.0f)
{
}

Shape::Shape(const SHAPE_TYPE_e &rType) : BaseShape(rType),
	m_Width(0.0f),
	m_Height(0.0f)
{
}

Shape::~Shape(void)
{
}

// Public methods
void Shape::SetSize(const float fWidth, const float fHeight)
{
	m_Width = fWidth;
	m_Height = fHeight;
}

// Public virtual methods
/* virtual */const float Shape::GetRay(void) const
{
	return m_Width;
}

/* virtual */const float Shape::GetWidth(void) const
{
	return m_Width;
}

/* virtual */const float Shape::GetHeight(void) const
{
	return m_Height;
}

// Public operators
Shape& Shape::operator =(const Shape &rShape)
{
	m_Type = rShape.m_Type;
	m_Center = rShape.m_Center;
	m_Width = rShape.m_Width;
	m_Height = rShape.m_Height;

	return *this;
}

Shape& Shape::Set(const Shape &rShape)
{
	m_Type = rShape.m_Type;
	m_Width = rShape.m_Width;
	m_Height = rShape.m_Height;

	return *this;
}

// Flexible Shape
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
FlexibleShape::FlexibleShape() : BaseShape(),
	m_Width(),
	m_Height()
{
	m_Width.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Width.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Height.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Height.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

FlexibleShape::FlexibleShape(const SHAPE_TYPE_e &rType) : BaseShape(rType),
	m_Width(),
	m_Height()
{
	m_Width.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Width.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Height.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Height.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

FlexibleShape::~FlexibleShape(void)
{
}

// Public methods
void FlexibleShape::Update(float fDeltatime)
{
	m_Width.Update(fDeltatime,false);
	m_Height.Update(fDeltatime,false);
}

FloatComponent* FlexibleShape::GetWidthComponent(void)
{
	return &m_Width;
}

FloatComponent* FlexibleShape::GetHeightComponent(void)
{
	return &m_Height;
}

// Public virtual methods
/* virtual */const float FlexibleShape::GetRay(void) const
{
	return m_Width.GetCurrent();
}

/* virtual */const float FlexibleShape::GetWidth(void) const
{
	return m_Width.GetCurrent();
}

/* virtual */const float FlexibleShape::GetHeight(void) const
{
	return m_Height.GetCurrent();
}

// Public operators
FlexibleShape& FlexibleShape::operator =(const FlexibleShape &rShape)
{
	m_Type = rShape.m_Type;
	m_Center = rShape.m_Center;
	m_Width = rShape.m_Width;
	m_Height = rShape.m_Height;

	return *this;
}

FlexibleShape& FlexibleShape::Set(const FlexibleShape &rShape, bool bUseWidthCurrent, bool bUseWidthDesired, bool bUseHeightCurrent, bool bUseHeightDesired)
{
	m_Type = rShape.m_Type;
	m_Width.Set( rShape.m_Width, bUseWidthCurrent, bUseWidthDesired );
	m_Height.Set( rShape.m_Height, bUseHeightCurrent, bUseHeightDesired );

	return *this;
}

FlexibleShape& FlexibleShape::SetCurrent(const Shape &rShape)
{
	m_Type = rShape.GetShapeType();
	m_Width.SetCurrent( rShape.GetWidth() );
	m_Height.SetCurrent( rShape.GetHeight() );

	return *this;
}

FlexibleShape& FlexibleShape::SetDesired(const Shape &rShape)
{
	m_Type = rShape.GetShapeType();
	m_Width.SetDesired( rShape.GetWidth() );
	m_Height.SetDesired( rShape.GetHeight() );

	return *this;
}

// BaseVolume
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
BaseVolume::BaseVolume(void) :
	m_Type(VOLUME_TYPE_e::VOLUME_TYPE_INVALID),
	m_Center()
{
}

BaseVolume::BaseVolume(const VOLUME_TYPE_e &rType) :
	m_Type(rType),
	m_Center()
{
}

BaseVolume::~BaseVolume(void)
{
}

// Public methods
void BaseVolume::SetCenter(const Axiom::Math::Vector3 &vCenter)
{
	m_Center = vCenter;
}

void BaseVolume::SetCenter(const float fPositionX, const float fPositionY, const float fPositionZ)
{
	m_Center.X( fPositionX );
	m_Center.Y( fPositionY );
	m_Center.Z( fPositionZ );
}

const Axiom::Math::Vector3& BaseVolume::GetCenter(void) const
{
	return m_Center;
}

bool BaseVolume::IsIn(const Axiom::Math::Vector3 &vPosition)
{
	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		{
			Axiom::Math::Vector3 vCenter = m_Center - vPosition;
			if( vCenter.Magnitude() < GetWidth() )
			{
				return true;
			}
		}
		break;
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;

			if( vPosition.X() <  ( m_Center.X() + fHalfWidth  ) &&
				vPosition.X() >= ( m_Center.X() - fHalfWidth  ) &&
				vPosition.Y() <  ( m_Center.Y() + fHalfHeight ) &&
				vPosition.Y() >= ( m_Center.Y() - fHalfHeight ) &&
				vPosition.Z() <  ( m_Center.Z() + fHalfDepth ) &&
				vPosition.Z() >= ( m_Center.Z() - fHalfDepth ) )
			{
				return true;
			}
		}
		break;
	default:
		break;
	}

	return false;
}

const Axiom::Math::Vector3 BaseVolume::CameraRestrain(const Axiom::Math::Vector3 &vPosition, const Camera *pCamera, const BOUNDARY_TYPE_e &rType)
{
	PRESENTATION_ASSERT( pCamera != NULL, "Presentation Error: NULL pointer passed!\n" );

	Axiom::Math::Vector3 vRestrained = vPosition;

	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		break;
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;

			float fClamp = m_Center.X() + fHalfWidth;
			if( vPosition.X() > fClamp )
			{
				vRestrained.X( fClamp );

				// Send an event with pCamera/rType/rAxis
			}
			else
			{
				fClamp = m_Center.X() - fHalfWidth;
				if( vPosition.X() < fClamp )
				{
					vRestrained.X( fClamp );

					// Send an event with pCamera/rType/rAxis
				}
			}
			fClamp = m_Center.Y() + fHalfHeight;
			if( vPosition.Y() > fClamp )
			{
				vRestrained.Y( fClamp );

				// Send an event with pCamera/rType/rAxis
			}
			else
			{
				fClamp = m_Center.Y() - fHalfHeight;
				if( vPosition.Y() < fClamp )
				{
					vRestrained.Y( fClamp );

					// Send an event with pCamera/rType/rAxis
				}
			}
			fClamp = m_Center.Z() + fHalfDepth;
			if( vPosition.Z() > fClamp )
			{
				vRestrained.Z( fClamp );

			}
			else
			{
				fClamp = m_Center.Z() - fHalfDepth;
				if( vPosition.Z() < fClamp )
				{
					vRestrained.Z( fClamp );

				}
			}
		}
		break;
	default:
		break;
	}

	return vRestrained;
}

const Axiom::Math::Vector3 BaseVolume::Restrain(const Axiom::Math::Vector3 &vPosition)
{
	Axiom::Math::Vector3 vRestrained = vPosition;

	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		break;
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;

			float fClamp = m_Center.X() + fHalfWidth;
			if( vPosition.X() > fClamp )
			{
				vRestrained.X( fClamp );
			}
			else
			{
				fClamp = m_Center.X() - fHalfWidth;
				if( vPosition.X() < fClamp )
				{
					vRestrained.X( fClamp );
				}
			}
			fClamp = m_Center.Y() + fHalfHeight;
			if( vPosition.Y() > fClamp )
			{
				vRestrained.Y( fClamp );
			}
			else
			{
				fClamp = m_Center.Y() - fHalfHeight;
				if( vPosition.Y() < fClamp )
				{
					vRestrained.Y( fClamp );
				}
			}
			fClamp = m_Center.Z() + fHalfDepth;
			if( vPosition.Z() > fClamp )
			{
				vRestrained.Z( fClamp );
			}
			else
			{
				fClamp = m_Center.Z() - fHalfDepth;
				if( vPosition.Z() < fClamp )
				{
					vRestrained.Z( fClamp );
				}
			}
		}
		break;
	default:
		break;
	}

	return vRestrained;
}

const Axiom::Math::Vector3 BaseVolume::Constrain(const Axiom::Math::Vector3 &vPosition)
{
	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		break;
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;

			float fClamp = vPosition.X() - fHalfWidth;
			if( fClamp > m_Center.X()  )
			{
				m_Center.X( fClamp );
			}
			else
			{
				fClamp = vPosition.X() + fHalfWidth;
				if( fClamp < m_Center.X() )
				{
					m_Center.X( fClamp );
				}
			}
			fClamp = vPosition.Y() - fHalfHeight;
			if( fClamp > m_Center.Y() )
			{
				m_Center.Y( fClamp );
			}
			else
			{
				fClamp = vPosition.Y() + fHalfHeight;
				if( fClamp < m_Center.Y() )
				{
					m_Center.Y( fClamp );
				}
			}
			fClamp = vPosition.Z() - fHalfDepth;
			if( fClamp > m_Center.Z() )
			{
				m_Center.Z( fClamp );
			}
			else
			{
				fClamp = vPosition.Z() + fHalfDepth;
				if( fClamp < m_Center.Z() )
				{
					m_Center.Z( fClamp );
				}
			}
		}
		break;
	default:
		break;
	}

	return Axiom::Math::Vector3( m_Center );
}

// Frustum specifics
bool BaseVolume::IsFullyInFrustum(SharedSoccer::Shape::Frustum *pFrustum) const
{
	PRESENTATION_ASSERT( pFrustum != NULL, "Camera Error: NULL pointer passed!\n" );

	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		{
			Axiom::Math::Vector4 vCenter( m_Center.X(), m_Center.Y(), m_Center.Z(), 1.0f );
			return ( GetRay() > 0.0f ? pFrustum->IsFullyIn( vCenter, GetRay() ) : true );
		}
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;
			Axiom::Math::Vector4 vBoxMin( m_Center.X() - fHalfWidth, m_Center.Y() - fHalfHeight, m_Center.Z() - fHalfDepth, 1.0f ); 
			Axiom::Math::Vector4 vBoxMax( m_Center.X() + fHalfWidth, m_Center.Y() + fHalfHeight, m_Center.Z() + fHalfDepth, 1.0f ); 
			return pFrustum->IsFullyIn( vBoxMin, vBoxMax );
		}
	default:
		break;
	}

	return false;
}

bool BaseVolume::IsInFrustum(SharedSoccer::Shape::Frustum *pFrustum) const
{
	PRESENTATION_ASSERT( pFrustum != NULL, "Camera Error: NULL pointer passed!\n" );

	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		{
			Axiom::Math::Vector4 vCenter( m_Center.X(), m_Center.Y(), m_Center.Z(), 1.0f );
			return ( GetRay() > 0.0f ? pFrustum->IsIn( vCenter, GetRay() ) : true );
		}
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;
			Axiom::Math::Vector4 vBoxMin( m_Center.X() - fHalfWidth, m_Center.Y() - fHalfHeight, m_Center.Z() - fHalfDepth, 1.0f ); 
			Axiom::Math::Vector4 vBoxMax( m_Center.X() + fHalfWidth, m_Center.Y() + fHalfHeight, m_Center.Z() + fHalfDepth, 1.0f ); 
			return pFrustum->IsIn( vBoxMin, vBoxMax );
		}
	default:
		break;
	}

	return false;
}

float BaseVolume::GetDistanceFromFrustumPlane(SharedSoccer::Shape::Frustum *pFrustum, SharedSoccer::Shape::Frustum::PLANE_e ePlane) const
{
	PRESENTATION_ASSERT( pFrustum != NULL, "Camera Error: NULL pointer passed!\n" );

	switch( m_Type )
	{
	case VOLUME_TYPE_e::VOLUME_TYPE_SPHERE:
		{
			Axiom::Math::Vector4 vCenter( m_Center.X(), m_Center.Y(), m_Center.Z(), 1.0f );
			return pFrustum->GetDistanceFromPlane( ePlane, vCenter, GetRay() );
		}
	case VOLUME_TYPE_e::VOLUME_TYPE_BOX:
		{
			float fHalfWidth = GetWidth() / 2.0f;
			float fHalfHeight = GetHeight() / 2.0f;
			float fHalfDepth = GetDepth() / 2.0f;
			Axiom::Math::Vector4 vBoxMin( m_Center.X() - fHalfWidth, m_Center.Y() - fHalfHeight, m_Center.Z() - fHalfDepth, 1.0f ); 
			Axiom::Math::Vector4 vBoxMax( m_Center.X() + fHalfWidth, m_Center.Y() + fHalfHeight, m_Center.Z() + fHalfDepth, 1.0f ); 
			return pFrustum->IsFullyIn( vBoxMin, vBoxMax );
		}
	default:
		break;
	}

	return false;
}

// Volume
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructors & destructors
Volume::Volume(void) : BaseVolume(),
	m_Width(0.0f),
	m_Height(0.0f),
	m_Depth(0.0f)
{
}

Volume::Volume(const VOLUME_TYPE_e &rType) : BaseVolume(rType),
	m_Width(0.0f),
	m_Height(0.0f),
	m_Depth(0.0f)
{
}

Volume::~Volume(void)
{
}

// Public methods
void Volume::SetSize(const float fWidth, const float fHeight /*=0.0f*/, const float fDepth /*=0.0f*/)
{
	m_Width = fWidth;
	m_Height = fHeight;
	m_Depth = fDepth;
}

// Public virtual methods
/* virtual */const float Volume::GetRay(void) const
{
	return m_Width;
}

/* virtual */const float Volume::GetWidth(void) const
{
	return m_Width;
}

/* virtual */const float Volume::GetHeight(void) const
{
	return m_Height;
}

/* virtual */const float Volume::GetDepth(void) const
{
	return m_Depth;
}

// Public operators
Volume& Volume::operator =(const Volume &rVolume)
{
	m_Type = rVolume.m_Type;
	m_Center = rVolume.m_Center;
	m_Width = rVolume.m_Width;
	m_Height = rVolume.m_Height;
	m_Depth = rVolume.m_Depth;

	return *this;
}

Volume& Volume::Set(const Volume &rVolume)
{
	m_Type = rVolume.m_Type;
	m_Width = rVolume.m_Width;
	m_Height = rVolume.m_Height;
	m_Depth = rVolume.m_Depth;

	return *this;
}

// FlexibleVolume
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructors & destructors
FlexibleVolume::FlexibleVolume(void) : BaseVolume(),
	m_Width(),
	m_Height(),
	m_Depth()
{
	m_Width.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Width.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Height.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Height.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Depth.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Depth.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

FlexibleVolume::FlexibleVolume(const VOLUME_TYPE_e &rType) : BaseVolume(rType),
	m_Width(),
	m_Height(),
	m_Depth()
{
	m_Width.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Width.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Height.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Height.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
	m_Depth.SetMaximum( COMPONENT_DATA_MAXIMUMNONANGLE_DEFAULT );
	m_Depth.SetMinimum( COMPONENT_DATA_MINIMUMNONANGLE_DEFAULT );
}

FlexibleVolume::~FlexibleVolume(void)
{
}

// Public methods
void FlexibleVolume::Update(float fDeltatime)
{
	m_Width.Update(fDeltatime,false);
	m_Height.Update(fDeltatime,false);
	m_Depth.Update(fDeltatime,false);
}

FloatComponent* FlexibleVolume::GetWidthComponent(void)
{
	return &m_Width;
}

FloatComponent* FlexibleVolume::GetHeightComponent(void)
{
	return &m_Height;
}

FloatComponent* FlexibleVolume::GetDepthComponent(void)
{
	return &m_Depth;
}

// Public virtual methods
/* virtual */const float FlexibleVolume::GetRay(void) const
{
	return m_Width.GetCurrent();
}

/* virtual */const float FlexibleVolume::GetWidth(void) const
{
	return m_Width.GetCurrent();
}

/* virtual */const float FlexibleVolume::GetHeight(void) const
{
	return m_Height.GetCurrent();
}

/* virtual */const float FlexibleVolume::GetDepth(void) const
{
	return m_Depth.GetCurrent();
}

// Public operators
FlexibleVolume& FlexibleVolume::operator =(const FlexibleVolume &rVolume)
{
	m_Type = rVolume.m_Type;
	m_Center = rVolume.m_Center;
	m_Width = rVolume.m_Width;
	m_Height = rVolume.m_Height;
	m_Depth = rVolume.m_Depth;

	return *this;
}

FlexibleVolume& FlexibleVolume::Set(const FlexibleVolume &rVolume, bool bUseWidthCurrent, bool bUseWidthDesired, bool bUseHeightCurrent, bool bUseHeightDesired, bool bUseDepthCurrent, bool bUseDepthDesired)
{
	m_Type = rVolume.m_Type;
	m_Width.Set( rVolume.m_Width, bUseWidthCurrent, bUseWidthDesired );
	m_Height.Set( rVolume.m_Height, bUseHeightCurrent, bUseHeightDesired );
	m_Depth.Set( rVolume.m_Depth, bUseDepthCurrent, bUseDepthDesired );

	return *this;
}

FlexibleVolume& FlexibleVolume::SetCurrent(const Volume &rVolume)
{
	m_Type = rVolume.GetVolumeType();
	m_Width.SetCurrent( rVolume.GetWidth() );
	m_Height.SetCurrent( rVolume.GetHeight() );
	m_Depth.SetCurrent( rVolume.GetDepth() );

	return *this;
}

FlexibleVolume& FlexibleVolume::SetDesired(const Volume &rVolume)
{
	m_Type = rVolume.GetVolumeType();
	m_Width.SetDesired( rVolume.GetWidth() );
	m_Height.SetDesired( rVolume.GetHeight() );
	m_Depth.SetDesired( rVolume.GetDepth() );

	return *this;
}

// Yaw
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Yaw::Yaw(void) :
	m_Pitch(0.0f),
	m_Heading(0.0f)
{
}

Yaw::Yaw(const Axiom::Math::Vector3 &rBodyPosition, const Axiom::Math::Vector3 &rTargetPosition)
{
	Axiom::Math::Vector3 vDelta = rTargetPosition - rBodyPosition;
	float fMagnitude = vDelta.Magnitude();
	if( fMagnitude > 0.0f )
	{
		vDelta /= fMagnitude;
	}
	m_Pitch = -NormalizeAngle( asinf( vDelta.Z() ) + Axiom::Math::PI_DIV_TWO );
	m_Heading = -NormalizeAngle( atan2f( vDelta.Y(), vDelta.X() ) - Axiom::Math::PI_DIV_TWO );
}

Yaw::~Yaw(void)
{
}

// Framing
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor & destructor
Framing::Framing(void) :
	m_Offset(),
	m_FramedBodyPosition(),
	m_FramedTargetPosition()
{
}

Framing::Framing(const Axiom::Math::Vector2 &vOffset) :
	m_Offset(vOffset),
	m_FramedBodyPosition(),
	m_FramedTargetPosition()
{
}

Framing::~Framing(void)
{
}

// Public methods
void Framing::SetOffset(const Axiom::Math::Vector2 &rOffset)
{
	m_Offset = rOffset;
}

void Framing::Adjust(const Axiom::Math::Vector3 &rBodyPosition, const Axiom::Math::Vector3 &rTargetPosition, const float fZoom, const float fRoll)
{
	if( Axiom::Math::FloatAbs( m_Offset.X() ) < CAMERA_EPSILON && Axiom::Math::FloatAbs( m_Offset.Y() ) < CAMERA_EPSILON )
	{
		m_FramedTargetPosition = rTargetPosition;
		m_FramedBodyPosition = rBodyPosition;
	}
	else
	{
		// Get orientation
		Orientation tOrientation;
		tOrientation.Set( rBodyPosition, rTargetPosition, fRoll );
			
		// Draw the target frame
		Axiom::Math::Vector3	vOffset = rTargetPosition - rBodyPosition;
		float					fCoef = vOffset.Magnitude() * 2.0f * tanf( fZoom / 2.0f );

		Axiom::Math::Vector3	vSide = tOrientation.GetSide() * m_Offset.X() * CAMERADEBUG_DRAWTARGET_WIDTH * fCoef;
		Axiom::Math::Vector3	vUp = /* tOrientation.GetUp() */ Axiom::Math::Vector3( 0.0f, 0.0f, 1.0f ) * m_Offset.Y() * CAMERADEBUG_DRAWTARGET_HEIGHT * fCoef;

		// Offset the points
		m_FramedTargetPosition = rTargetPosition + vSide + vUp;
		m_FramedBodyPosition = rBodyPosition + vSide + vUp;
	}
}

// Tracking
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

TrackingResult::TrackingResult(void) : 
	m_Report(TRACKING_REPORT_NONE),
	m_EntityID(),
	m_ProposedDeltaDistance(0.0f),
	m_ProposedDeltaHeading(0.0f),
	m_Position(),
	m_Facing()
{
}

// Constructor & destructor
TrackingData::TrackingData(void) :
	m_Tracking( /*TRACKING_ENTITY_e::TRACKING_ENTITY_INVALID*/ ),		
	m_TrackingBone( /*TRACKING_ENTITYBONE_e::TRACKING_ENTITYBONE_INVALID*/ ),		
	m_Weight(0.0f),
	m_OffsetType( TRACKING_OFFSETTYPE_e::TRACKING_OFFSETTYPE_INVALID ),
	m_Offset(),
	m_VolumeSize(0.0f),
	m_ForcedToBeIncluded(false)
{
}

TrackingData::TrackingData(const TrackingData &rData) :
	m_Tracking( rData.m_Tracking.Get().InstanceType()->CreateInstance() ),		
	m_TrackingBone( rData.m_TrackingBone.Get().InstanceType()->CreateInstance() ),		
	m_Weight(rData.m_Weight),
	m_OffsetType(rData.m_OffsetType),
	m_Offset(rData.m_Offset),
	m_VolumeSize(rData.m_VolumeSize),
	m_ForcedToBeIncluded(rData.m_ForcedToBeIncluded)
{
	m_Tracking.AssignGet() = rData.m_Tracking.Get();									// Copy at an instance level
	m_TrackingBone.AssignGet() = rData.m_TrackingBone.Get();							// Copy at an instance level
}

Tracking::Tracking(void) :
	m_Data(),
	m_Tracked(false),
	m_TrackedPosition()
{
}

Tracking::Tracking(const TrackingData &rData) :
	m_Data(rData),
	m_Tracked(false),
	m_TrackedPosition(),
	m_OffsetTrackedPosition()
{
}

Tracking::~Tracking(void)
{
}

// Copy operator
void TrackingData::operator=(const TrackingData &dat)
{
	m_Tracking.Set( dat.m_Tracking.Get().InstanceType()->CreateInstance() );
	m_TrackingBone.Set( dat.m_TrackingBone.Get().InstanceType()->CreateInstance() );
	m_Tracking.AssignGet() = dat.m_Tracking.Get();									// Copy at an instance level
	m_TrackingBone.AssignGet() = dat.m_TrackingBone.Get();							// Copy at an instance level
	m_Weight = dat.m_Weight;
	m_OffsetType = dat.m_OffsetType;		
	m_Offset = dat.m_Offset;
	m_VolumeSize = dat.m_VolumeSize;
	m_ForcedToBeIncluded = dat.m_ForcedToBeIncluded;
}


// Static public methods
/* static */ TrackingResult Tracking::TrackEntities(Axiom::Collections::ReflectedList<Axiom::SmartPtr<Tracking> > &rTrackings, int eType, const PresentationInput &rInput, Camera *pCamera /*= NULL*/)
{
	TrackingResult		tResult;
	const unsigned int	iNbTrackings = rTrackings.Count();

	switch( eType )
	{
	case TRACKING_TYPE_e::TRACKING_TYPE_SINGLEPOINT:
		{
			TrackingResult	tSubResult;
			for( unsigned int i = 0 ; i < iNbTrackings ; ++i )
			{
				Tracking *pTracking = rTrackings[i].pVal();
				tSubResult = rInput.TrackEntity( pTracking, pCamera );
				if( (tSubResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
				{
					tResult = tSubResult;
					break;
				}
			}
		}
		break;
	case TRACKING_TYPE_e::TRACKING_TYPE_MIDDLEPOINT:
		{		
			TrackingResult	tSubResult;
			float			fFinalWeight = 0.0f;		
			for( unsigned int i = 0 ; i < iNbTrackings ; ++i )
			{
				Tracking *pTracking = rTrackings[i].pVal();
				tSubResult = rInput.TrackEntity( pTracking, pCamera );
				if( (tSubResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
				{
					float fWeight = pTracking->m_Data.m_Weight;
					fFinalWeight += fWeight;
					tResult.m_Position += tSubResult.m_Position * fWeight;
					tResult.m_Facing += tSubResult.m_Facing * fWeight;
				}
			}
			if( Axiom::Math::FloatAbs(fFinalWeight) > 0.0f )
			{
				tResult.m_Position /= fFinalWeight;
				tResult.m_Facing /= fFinalWeight;
				tResult.m_Report = TRACKING_REPORT_POSITION | TRACKING_REPORT_FACING;
			}
		}
		break;
	case TRACKING_TYPE_e::TRACKING_TYPE_MULTIPLEPOINTS:
		{	
			PRESENTATION_ASSERT( pCamera != NULL, "Camera Error: NULL pointer passed!\n" );

			// Build the desired projection and orientation
			const Viewport *pViewport = CameraManager::GetInstance()->GetUpdateViewport();
			PRESENTATION_ASSERT( pViewport != NULL, "Camera Error: No viewport updated currently!\n" );
			const FloatComponent *pZoomComponent = pCamera->GetZoomComponent();
			PRESENTATION_ASSERT( pZoomComponent != NULL, "Camera Error: NULL pointer retrieved!\n" );
			const FloatComponent *pRollComponent = pCamera->GetRollComponent();
			PRESENTATION_ASSERT( pRollComponent != NULL, "Camera Error: NULL pointer retrieved!\n" );
			const Point	*pBodyPoint = pCamera->GetBodyPoint();
			PRESENTATION_ASSERT( pBodyPoint != NULL, "Camera Error: NULL pointer retrieved!\n" );
			const Point	*pTargetPoint = pCamera->GetTargetPoint();
			PRESENTATION_ASSERT( pTargetPoint != NULL, "Camera Error: NULL pointer retrieved!\n" );
			const Framing *pFraming = pCamera->GetFraming();
			PRESENTATION_ASSERT( pFraming != NULL, "Camera Error: NULL pointer retrieved!\n" );

			// Set desired orientation and projection matrix
			Projection	tProjection( pZoomComponent->GetDesired(), pViewport->GetAspectRatio(), pViewport->GetNearPlane(), pViewport->GetFarPlane() );
			Framing		tFraming( pFraming->GetOffset() );
			tFraming.Adjust( pBodyPoint->GetDesired(), pTargetPoint->GetDesired(), pZoomComponent->GetDesired(), pRollComponent->GetDesired() );
			Orientation	tOrientation( tFraming.GetBodyPosition(), tFraming.GetTargetPosition(), pRollComponent->GetDesired() );

			// Build the desired frustum
			SharedSoccer::Shape::Frustum tFrustum( tOrientation, tProjection );

			// Put the tracking in action
			TrackingResult	tSubResult;
			bool			bOutOfFrustum = false;
			float			fFinalWeight=0.0f, fMaximumDistanceFromLeftPlane=0.0f, fMaximumDistanceFromRightPlane=0.0f;
			for( unsigned int i = 0 ; i < iNbTrackings ; ++i )
			{
				Tracking *pTracking = rTrackings[i].pVal();
				tSubResult = rInput.TrackEntity( pTracking, pCamera );
				if( (tSubResult.m_Report & TRACKING_REPORT_POSITION) != 0 )
				{
					float fWeight = pTracking->m_Data.m_Weight;
					fFinalWeight += fWeight;
					tResult.m_Position += tSubResult.m_Position * fWeight;
					tResult.m_Facing += tSubResult.m_Facing * fWeight;
					
					// IMPORTANT: We operate the clipping on the entity, not the offset result!
//					Volume tVolume = rInput.GetEntityVolume( pTracking );

					// TODO: Force the volume to be a sphere
					float 					fRay = pTracking->GetVolumeSize();
					Axiom::Math::Vector3	vCenter = pTracking->GetTrackedPosition() + Axiom::Math::Vector3( 0.0f, 0.0f, fRay / 2.0f );
					Volume					tVolume(VOLUME_TYPE_e::VOLUME_TYPE_SPHERE);
					tVolume.SetCenter( vCenter );
					tVolume.SetSize( fRay );

					if( !tVolume.IsFullyInFrustum( &tFrustum ) )
					{
						float fDistance = -tVolume.GetDistanceFromFrustumPlane( &tFrustum, SharedSoccer::Shape::Frustum::PLANE_LEFT );
						if( fDistance > fMaximumDistanceFromLeftPlane )
						{
							fMaximumDistanceFromLeftPlane = fDistance;
						}
						fDistance = -tVolume.GetDistanceFromFrustumPlane( &tFrustum, SharedSoccer::Shape::Frustum::PLANE_RIGHT );
						if( fDistance > fMaximumDistanceFromRightPlane )
						{
							fMaximumDistanceFromRightPlane = fDistance;
						}
						
						bOutOfFrustum = true;
					}
				}
			}

			// Got the middle point
			if( Axiom::Math::FloatAbs(fFinalWeight) > 0.0f )
			{
				tResult.m_Position /= fFinalWeight;
				tResult.m_Facing /= fFinalWeight;
				tResult.m_Report = TRACKING_REPORT_POSITION | TRACKING_REPORT_FACING;
			}

			const CAMERA_TYPE_e eType = pCamera->GetCameraType();
			if( eType == CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE			   || 
				eType == CAMERA_TYPE_e::CAMERA_TYPE_GAMEPLAY_TARGETRELATIVE_CONTROLLED )
			{
				CameraGamePlayTargetRelative	*pCameraTargetRelative = static_cast<CameraGamePlayTargetRelative*>(pCamera);
				CumulativeFloatComponent		*pComponent = pCameraTargetRelative->GetDistanceComponent();
				float							fIncHeading = pCameraTargetRelative->GetTrackingMultiplePointsIncHeading();
				float							fIncDistance = pCameraTargetRelative->GetTrackingMultiplePointsIncDistance();

				// If we have to move the camera
				if( bOutOfFrustum )
				{
					// Push the distance slowly
					if( pComponent->GetPrimaryDesired() < ( pComponent->GetMaximum() - fIncDistance ) )
					{
						tResult.m_ProposedDeltaDistance = fIncDistance;
						tResult.m_Report |= TRACKING_REPORT_PROPOSEDDISTANCE;
					}

					// Push left or right
					tResult.m_ProposedDeltaHeading = ( fMaximumDistanceFromLeftPlane > fMaximumDistanceFromRightPlane ? fIncHeading : -fIncHeading );
					tResult.m_Report |= TRACKING_REPORT_PROPOSEDHEADING;
				}
				else
				{
					// Bring the distance back slowly
					if( pComponent->GetPrimaryDesired() > ( pComponent->GetMinimum() + fIncDistance ) )
					{
						tResult.m_ProposedDeltaDistance = -fIncDistance;
						tResult.m_Report |= TRACKING_REPORT_PROPOSEDDISTANCE;
					}

					// Bring the heading back slowly
					pComponent = pCameraTargetRelative->GetHeadingComponent();
					float fPrimaryDesired = pComponent->GetPrimaryDesired();
					if( fPrimaryDesired > fIncHeading )
					{
						tResult.m_ProposedDeltaHeading = -fIncHeading;
						tResult.m_Report |= TRACKING_REPORT_PROPOSEDHEADING;
					}
					else if( fPrimaryDesired < -fIncHeading )
					{
						tResult.m_ProposedDeltaHeading = fIncHeading;
						tResult.m_Report |= TRACKING_REPORT_PROPOSEDHEADING;
					}
				}
			}
		}
		break;
	default:
		break;
	}

	return tResult;
}

// Public methods
void Tracking::SetTrackedPosition(const Axiom::Math::Vector3 &vPosition)
{
	m_TrackedPosition = vPosition;
	m_Tracked = true;
}

void Tracking::SetOffsetTrackedPosition(const Axiom::Math::Vector3 &vPosition)
{
	m_OffsetTrackedPosition = vPosition;
}

// Public operators
Tracking& Tracking::operator=(const Tracking &rTracking)
{
	m_Data = rTracking.m_Data;						
	m_TrackedPosition = rTracking.m_TrackedPosition;
	m_Tracked = rTracking.m_Tracked;

	return *this;
}

Tracking& Tracking::Set(const TrackingData &rData, bool bUseOffset, bool bUseTracking, bool bUseWeight)
{
	if( bUseOffset )
	{
		m_Data.m_OffsetType = rData.m_OffsetType;
		m_Data.m_Offset = rData.m_Offset;
	}

	if( bUseTracking )
	{
		m_Data.m_Tracking.AssignGet() = rData.m_Tracking.Get();				// Copy at an instance level
		m_Data.m_TrackingBone.AssignGet() = rData.m_TrackingBone.Get();		// Copy at an instance level
		m_Data.m_ForcedToBeIncluded = rData.m_ForcedToBeIncluded;
		m_Data.m_VolumeSize = rData.m_VolumeSize;
	}

	if( bUseWeight )
	{
		m_Data.m_Weight = rData.m_Weight;
	}

	return *this;
}

// Noise
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Constructor and destructor
Noise::Noise(void) :
	m_Magnitude( 0.25f ),
	m_Duration( 0.0333f ),
	m_Frequency( 10.0f ),
	m_InitialDuration( 0.0333f ),
	m_MagnitudeScale( 0.0f ),
	m_CurrentMagnitude( 0.0f ),
	m_CurrentTime( 0.0f ),
	m_UpdateTime( 0.0f ),
	m_Noise()
{
}

Noise::~Noise(void)
{
}

void Noise::Reset(float fMagnitudeModifier /*= 1.0f*/)
{
	const float fActualMagnitude = fMagnitudeModifier * m_Magnitude;
	m_CurrentTime = 0.0f;
	m_CurrentMagnitude = fActualMagnitude;
	m_MagnitudeScale = fActualMagnitude / m_Duration;
	m_UpdateTime = 0.0f;
	GetMagnitudeVector();
}

void Noise::Init(float fDuration /*= -1.0f*/, float fMagnitudeModifier /*= 1.0f*/)
{
	if(fDuration <= 0.0f)
	{
		m_Duration = m_InitialDuration;
	}
	else
	{
		m_Duration = fDuration;
	}
	Reset(fMagnitudeModifier);
}


bool Noise::Update(float fDeltaTime)
{
	bool bResult = true;
	m_CurrentTime += fDeltaTime;
	if( m_CurrentTime >= m_Duration )
	{
		bResult = false;
	}
	m_CurrentMagnitude -= fDeltaTime * m_MagnitudeScale;
	if( m_CurrentMagnitude < 0.0f )
	{
		m_CurrentMagnitude = 0.0f;
	}

	return bResult;
}

const Axiom::Math::Vector3 Noise::GetMagnitudeVector(void)
{
	static Axiom::Random tRand;
	
	if(m_CurrentTime >= m_UpdateTime)
	{
		m_Noise = Axiom::Math::Vector3( m_CurrentMagnitude * tRand.RandFloat( -0.5f, 0.5f ),
			m_CurrentMagnitude * tRand.RandFloat( -0.5f, 0.5f ),
			m_CurrentMagnitude * tRand.RandFloat( -0.5f, 0.5f ) );
		m_UpdateTime += GetTimeIntervalForUpdate();
	}
	else if (m_CurrentTime >= m_Duration)
	{
		m_Noise = Axiom::Math::Vector3( );
	}

	return m_Noise;
}

// Colour
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Colour::Colour(void)
{
	Set(0.0f, 0.0f, 0.0f, 0.0f);
}

Colour::Colour(float fR, float fG, float fB, float fA)
{
	Set(fR, fG, fB, fA);
}

Colour::Colour(Axiom::Math::Vector4& vColour)
{
	Set(vColour);
}

Axiom::Math::Vector4 Colour::Get(void) const
{
	return Axiom::Math::Vector4(m_R, m_G, m_B, m_A);
}

void Colour::Set(Axiom::Math::Vector4& vColour)
{
	Set(vColour.X(), vColour.Y(), vColour.Z(), vColour.W());
}

void Colour::Set(float fR, float fG, float fB, float fA)
{
	AP_ASSERT( 0.0f <= fR && fR <= 1.0f );
	AP_ASSERT( 0.0f <= fG && fG <= 1.0f );
	AP_ASSERT( 0.0f <= fB && fB <= 1.0f );
	AP_ASSERT( 0.0f <= fA && fA <= 1.0f );

	m_R = fR;
	m_G = fG;
	m_B = fB;
	m_A = fA;
}

void Colour::Set(int fR, int fG, int fB, int fA)
{
	AP_ASSERT( 0 <= fR && fR <= 255 );
	AP_ASSERT( 0 <= fG && fG <= 255 );
	AP_ASSERT( 0 <= fB && fB <= 255 );
	AP_ASSERT( 0 <= fA && fA <= 255 );

	Set( CastToFloat(fR) / 255.0f,
		 CastToFloat(fG) / 255.0f,
		 CastToFloat(fB) / 255.0f,
		 CastToFloat(fA) / 255.0f );
}

Graphics::Color Colour::GetAsRGBA(void)
{
	return GRAPHICS_RGBAF(m_R, m_G, m_B, m_A);
}

bool Colour::operator==( const Colour& other ) const
{
	return( m_R == other.m_R && m_G == other.m_G && m_B == other.m_B && m_A == other.m_A );
}

// Util functions
const float SharedSoccer::Presentation::NormalizeAngle(const float f)
{
	float fResult = f;	

	while( fResult > Axiom::Math::PI )
	{
		fResult -= Axiom::Math::TWO_PI;
	}
	while( fResult < -Axiom::Math::PI )
	{
		fResult += Axiom::Math::TWO_PI;
	}

	return fResult;
}

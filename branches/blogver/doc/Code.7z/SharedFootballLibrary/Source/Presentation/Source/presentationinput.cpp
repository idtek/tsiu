
#ifndef _PRESENTATIONINPUT_H_
# include "presentation/presentationinput.h"
#endif
#ifndef _PRESENTATION_UTILS_H_
# include "presentation/presentation_utils.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace SharedSoccer::Presentation;

// Constructor and virtual destructor
PresentationInput::PresentationInput(void)
{
}

/* virtual */ PresentationInput::~PresentationInput(void)
{
}

// Public default virtual functions
/* virtual */ int PresentationInput::GetConditionTarget(const int) const
{
	return 0;
}

/* virtual */ int PresentationInput::GetBranchTarget(const int) const
{
	return 0;
}

/* virtual */ TrackingResult PresentationInput::TrackEntity( Tracking*, const Camera* ) const
{
	return TrackingResult();
}

/* virtual */ Volume PresentationInput::GetEntityVolume( Tracking* ) const
{
	return Volume();
}

/* virtual */ SharedSoccer::EntityGUID PresentationInput::GetEntityGUID( int ) const
{
	return SharedSoccer::EntityGUID();
}

/* virtual */ float PresentationInput::GetEbbFlowValue( const Axiom::CRC& ) const
{
	return 0.0f;
}


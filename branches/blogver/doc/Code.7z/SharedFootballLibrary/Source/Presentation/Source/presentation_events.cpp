
#ifndef  _PRESENTATION_EVENTS_H_
# include "presentation/presentation_events.h"
#endif

// Namespace usage
using namespace AP;
using namespace Events;

// Reflection declaration
AP_TYPE(PresentationDigitalInputEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Controller", m_ControllerID, "Controller that pressed the button.")
	AP_FIELD("Button", m_Button, "Button that was pressed")
AP_TYPE_END()


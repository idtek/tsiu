#pragma once

#ifndef  _PRESENTATION_CONFIG_H_
# define _PRESENTATION_CONFIG_H_

// Inlining
//# if CORE_DEBUG
//#  define PRESENTATION_INLINE					
//# else
#  define PRESENTATION_USE_INLINE
#  define PRESENTATION_INLINE		inline
//# endif

// Assert
# include "debug/assert.h"
# include "memory/apmemory.h"
# define PRESENTATION_ASSERT(__CONDITION__,__COMMENT__)	AP_ASSERTMESSAGE(__CONDITION__,__COMMENT__)
# define PRESENTATION_NEW(__HEAP__,__CREATOR__)			AP_NEW(__HEAP__,__CREATOR__)
# define PRESENTATION_DELETEARRAY(__DATA__)				delete [] __DATA__
# define PRESENTATION_DELETE(__DATA__)					delete __DATA__

#endif

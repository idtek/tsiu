#pragma once

#ifndef  _PRESENTATIONINPUT_H_
# define _PRESENTATIONINPUT_H_

# ifndef _VIEWPORT_H
#  include "presentation/camera/viewport.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif

#ifndef  __CORE_FRUSTUM_H
# include "shape/frustum.h"
#endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class Camera;
		class Tracking;

		class PresentationInput
		{
		public:

			// Constructor and virtual destructor
			explicit PresentationInput(void);
			virtual ~PresentationInput(void);

			// Public virtual functions
			virtual int							GetConditionTarget(const int) const;
			virtual int							GetBranchTarget(const int) const;

			virtual TrackingResult				TrackEntity( Tracking*, const Camera* ) const;
			virtual Volume						GetEntityVolume( Tracking* ) const;
			virtual SharedSoccer::EntityGUID	GetEntityGUID( int ) const;
			virtual float						GetEbbFlowValue( const Axiom::CRC& ) const;

		};
	}
}

#endif
#ifndef _PITCH_H
#define _PITCH_H

#include "collections/array.h"
#include "gamedata/commongamedataenums.h"
#include <math/conversion.h>
#include <math/vector3.h>
#include "shape/circle.h"

// forward decs
namespace Axiom
{
	namespace Math
	{
		class Vector2;
		class Vector2Adapter;
	}
}

namespace Soccer
{
////////////////////////////////////////////////////////////
// forward decs

enum EPitchZoneCategory
{
    EPitchZoneCategory_INNER_GOAL_THREAT_ATTACK,        // Zone that offers the best chance of me scoring a goal
    EPitchZoneCategory_OUTER_GOAL_THREAT_ATTACK,
    EPitchZoneCategory_MIDFIELD_ATTACK,
    EPitchZoneCategory_OUT_OF_BOUNDS_ATTACK,
    EPitchZoneCategory_OUT_OF_BOUNDS_DEFENCE,
    EPitchZoneCategory_MIDFIELD_DEFENCE,
    EPitchZoneCategory_OUTER_GOAL_THREAT_DEFENCE,
    EPitchZoneCategory_INNER_GOAL_THREAT_DEFENCE        // Zone that has the highest danger of me conceding a goal
};

enum ELandmark
{
    ELandmark_CENTRE_SPOT,
    ELandmark_LEFT_TOUCHLINE_CENTRE,
    ELandmark_RIGHT_TOUCHLINE_CENTRE,
    ELandmark_REAR_LEFT_CORNER_FLAG,
    ELandmark_REAR_RIGHT_CORNER_FLAG,    
    ELandmark_FRONT_LEFT_CORNER_FLAG,
    ELandmark_FRONT_RIGHT_CORNER_FLAG,
    ELandmark_GOAL_IM_DEFENDING_GEOMETRIC_CENTRE,
    ELandmark_GOAL_IM_DEFENDING_CENTRE,
    ELandmark_GOAL_IM_DEFENDING_PENALTY_SPOT,
    ELandmark_GOAL_IM_DEFENDING_LEFT_POST,
    ELandmark_GOAL_IM_DEFENDING_RIGHT_POST,
    ELandmark_GOAL_IM_ATTACKING_CENTRE,
    ELandmark_GOAL_IM_ATTACKING_PENALTY_SPOT,
    ELandmark_GOAL_IM_ATTACKING_LEFT_POST,
    ELandmark_GOAL_IM_ATTACKING_RIGHT_POST,
    ELandmark_GOAL_IM_ATTACKING_CENTRE_BACK_OF_NET,
    ELandmark_NULL_LANDMARK
};

enum EPointOfReference
{
    EPointOfReference_OWN_GOAL_LINE,            // perpendicular
    EPointOfReference_OPPOSITION_GOAL_LINE,     // perpendicular
    EPointOfReference_MY_LEFT_TOUCHLINE,        // perpendicular
    EPointOfReference_OPPOSITION_GOAL           // direct distance
};

class SafetyMarginSpecifier
{
public:

    static SafetyMarginSpecifier    CreateNoMargin()                    { return SafetyMarginSpecifier( 0.0f, 0.0f ); }
    static SafetyMarginSpecifier    CreateUniformMargin( float margin ) { return SafetyMarginSpecifier( margin, margin ); }
    static SafetyMarginSpecifier    CreateXYMargin( float x, float y ) { return SafetyMarginSpecifier( x, y ); }
    
    float   m_XVal;        
    float   m_YVal;
    
private:

    SafetyMarginSpecifier( float x, float y ) : m_XVal( x ), m_YVal( y ) {}
};
    
class PitchData
{
public:
    PitchData();
	AP_DECLARE_TYPE();

    AP_DATAVALIDATION_SUPPORT( bool Initialized() const { return m_Initialized; } )

    // AP_POSTCONDITION( Initialized() );
    void				InitPitch(	float width, 
									float length,
									float centreCircleRadius,
									float goalWidth, 
									float goalHeight,
									float goalDepth,
									float goalAreaBackLineLength,
									float goalAreaFrontLineLength,
									float goalBallHandleRectangleWidth,
									float goalBallHandleRectangleLength );

    void				Reset( float width, 
                               float length,
                               float centreCircleRadius,
					           float goalWidth, 
					           float goalHeight,
					           float goalDepth,
							   float goalAreaBackLineLength,
							   float goalAreaFrontLineLength,
							   float goalBallHandleRectangleWidth,
							   float goalBallHandleRectangleLength );
    									   
	const float			Width() const	            { return m_Width; }
	const float			HalfWidth() const	        { return m_Width / 2.0f; }
	const float			Length() const	            { return m_Length; }
    const float			HalfLength() const			{ return m_Length / 2.0f; }
	const float			CentreCircleRadius() const	{ return m_CentreCircleRadius; }
	//
	const float			GoalWidth() const	        { return m_GoalWidth; }
	const float			GoalHalfWidth() const	    { return m_GoalWidth / 2.0f; }
	const float			GoalDepth() const	        { return m_GoalDepth; }
	const float			GoalHeight() const	        { return m_GoalHeight; }
	//
	const float			GoalAreaBackLineLength() const;
	const float			GoalAreaFrontFlatLineLength() const;
	//
	const float			GoalBallHandleRectangleWidth() const;
	const float			GoalBallHandleRectangleLength() const;

	bool                InBounds( const Axiom::Math::Vector2Adapter&, float safetyMargin = 0.0f ) const;
	// AP_PRECONDITION( InBounds( point ) )
	bool				InGoal( const Axiom::Math::Vector3& pos, bool check_height ) const;
	bool                InOwnHalf( const Axiom::Math::Vector2Adapter& point, ETeam team ) const;
	bool                InGoalBallHandleBounds( const Axiom::Math::Vector2Adapter&, float safetyMargin = 0.0f ) const;
	
	// -1.0f is on own goal line, 0.0f is halfway line, 1.0f is opponents goal line
	// AP_PRECONDITION( InBounds( point ) )
	// AP_POSTCONDITION( result >= -1.0f && result <= 1.0f )
	float               AttackingPositionProgressRatio( const Axiom::Math::Vector2Adapter& point, ETeam ) const;
	
	// -1.0f is left hand touchline line, 0.0f is line down central spine of pitch, 1.0f is right hand touch line
	// AP_PRECONDITION( InBounds( point ) )
	// AP_POSTCONDITION( result >= -1.0f && result <= 1.0f )
	float               RightHalfPositionRatio( const Axiom::Math::Vector2Adapter& point, ETeam ) const;
    bool                IsInLeftHalfOfPitch( const Axiom::Math::Vector2Adapter& position,
                                             ETeam wrtTeam ) const;
	
	// AP_POSTCONDITION( InBounds( result ) )
	Axiom::Math::Vector3   ClampedToPitch( const Axiom::Math::Vector3& unclamped, SafetyMarginSpecifier = SafetyMarginSpecifier::CreateNoMargin() ) const;
	Axiom::Math::Vector2   ClampedToPitch( const Axiom::Math::Vector2& unclamped, SafetyMarginSpecifier = SafetyMarginSpecifier::CreateNoMargin() ) const;
	
	// to support Academy
	Axiom::Math::Vector3   ClampedToPitch( const Axiom::Math::Vector3& unclamped, float deprecatedSafetyMargin ) const;
	Axiom::Math::Vector2   ClampedToPitch( const Axiom::Math::Vector2& unclamped, float deprecatedSafetyMargin ) const;
	
	Axiom::Math::Vector3   NearestPositionOnNearestSidelineTo( const Axiom::Math::Vector3& ) const;
	
    float               DistanceFrom( Axiom::Math::Vector3 pitchCoords,
                                      EPointOfReference,
                                      ETeam ) const;
                            
    enum ERelativeDistance
    {
        ERelativeDistance_NEARER,
        ERelativeDistance_FARTHER
    };    
                               
    ELandmark           AttackingCorner( const Axiom::Math::Vector3& playerPos,
                                         ETeam playerTeam,
                                         ERelativeDistance ) const;                                    

    // AP_PRECONDITION( landmark != ELandmark_NULL_LANDMARK )
    Axiom::Math::Vector3   LandmarkPosition( ETeam myTeam,
                                             ELandmark landmark ) const;
                                             
    // AP_PRECONDITION( landmark != ELandmark_NULL_LANDMARK )
    Axiom::Math::Vector2   LandmarkPosition2D( ETeam myTeam,
                                               ELandmark landmark ) const;
                                             
    Axiom::Math::Vector3    PointXMetresInFrontOfTargetGoalCentre( ETeam myTeam, float xMetres ) const;
                                             
    // AP_PRECONDITION( InBounds( pos ) )
    EPitchZoneCategory  PitchZoneCategory( ETeam myTeam,
                                           const Axiom::Math::Vector2Adapter& pos ) const;
                                  
    // AP_POSTCONDITION( result.IsNormal() )
    Axiom::Math::Vector2
                        AttackingDirection( ETeam team ) const;
                        
    //////////////////////////////////////////////////////////////////////////////////////////////
    
    static bool         HasPitchInstance();
    // AP_POSTCONDITION( HasPitchInstance() );
    static void         AssignPitchInstance( const PitchData& );
    // AP_PRECONDITION( HasPitchInstance() );
    static const PitchData&
                        PitchInstance();
                       
    enum ESlidePreference
    {
        ESlidePreference_SLIDE_IN_EITHER_DIRECTION,
        ESlidePreference_ALWAYS_SLIDE_IN_ATTACK_DIRECTION,
        ESlidePreference_ALWAYS_SLIDE_IN_DEFENCE_DIRECTION,
        ESlidePreference_ONLY_SLIDE_IN_ATTACK_DIRECTION,
        ESlidePreference_ONLY_SLIDE_IN_DEFENCE_DIRECTION
    };
    Axiom::Math::Vector2
                        SlideClampToPitch( const Axiom::Math::Vector2Adapter& unclampedPos,
                                           const Axiom::Math::Vector2Adapter& anchorPos,
                                           SafetyMarginSpecifier,
                                           ESlidePreference,
                                           ETeam preferenceIsWRTTeam ) const;
                        
    //////////////////////////////////////////////////////////////////////////////////////////////
    
private:

	Axiom::Math::Vector3   ClampedToPitchInternal( const Axiom::Math::Vector3& unclamped, SafetyMarginSpecifier ) const;
    
    // AP_PRECONDITION( InBounds( pos ) )
    // AP_POSTCONDITION( result >= 0.0f && result <= 1.0f )
    float               RatioOfFullWidth( const Axiom::Math::Vector2Adapter& pos ) const;
    
    // AP_PRECONDITION( InBounds( pos ) )
    // AP_POSTCONDITION( result >= 0.0f && result <= 1.0f )
    float               RatioOfFullLength( const Axiom::Math::Vector2Adapter& pos ) const;
    
    // returns one of the four sides of the pitch as a 2D line.
    // Currently, iterating through all four values will guarantee returning
    // all four sides, but the order is undefined
    // AP_PRECONDITION( i >= 0 && i <= 3 )
    SharedSoccer::Shape::Line2     Side( int i ) const;

    // data members
	float               m_wallHeight;
	float               m_Length;
	float               m_Width;
	float               m_CentreCircleRadius;
	float               m_HalfWidth;
	float               m_HalfLength;
	float				m_GoalWidth;
	float				m_GoalHeight;
	float				m_GoalDepth;

	float				m_GoalAreaBackLineLength;
	float				m_GoalAreaFrontFlatLineLength;

	float				m_GoalBallHandleRectangleWidth;
	float				m_GoalBallHandleRectangleLength;

	static const PitchData* 
	                    s_PitchInstance;

    AP_DATAVALIDATION_SUPPORT( bool m_Initialized; )
};

inline Axiom::Math::Vector3 PitchData::ClampedToPitch( const Axiom::Math::Vector3& unclamped, SafetyMarginSpecifier margin ) const
{
    // safetyMargin can be negative, so don't assert on InBounds() here please
    return ClampedToPitchInternal( unclamped, margin );
}

} // end namespace AP

#endif //_PITCH_H


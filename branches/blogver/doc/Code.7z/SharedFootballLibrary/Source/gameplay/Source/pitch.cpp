 
// class header
#include "gameplay/pitch.h"
#include "shape/aabb.h"
#include "shape/line.h"
#include "math/apmath.h"

//using namespace Axiom;
////////////////////////////////////////////////////////////

namespace Soccer
{

// static 
const PitchData* PitchData::s_PitchInstance = NULL;

///////////////////////////////// class PitchData /////////////////////////////////

PitchData::PitchData()
{
    AP_DATAVALIDATION_SUPPORT( m_Initialized = false; )
}

////////////////////////////////////////////////////////////

AP_TYPE(PitchData)
	AP_FIELD("WallHeight", m_wallHeight, "The height of collision walls around the pitch.")
	AP_FIELD("Length", m_Length, "The length of the pitch.")
		AP_FIELD_ATTRIBUTE("Range", "25.0, 100.0")
	AP_FIELD("Width", m_Width, "The width of the pitch.")
		AP_FIELD_ATTRIBUTE("Range", "5.0, 100.0")
	AP_FIELD("CentreRadius", m_CentreCircleRadius, "The radius of the pitch centre.")
		AP_FIELD_ATTRIBUTE("Range", "1.0, 5.0")
	AP_FIELD("GoalWidth", m_GoalWidth, "The width of a goal.")
		AP_FIELD_ATTRIBUTE("Range", "10.0, 50.0")
	AP_FIELD("GoalHeight", m_GoalHeight, "The height of a goal.")
	AP_FIELD("GoalDepth", m_GoalDepth, "The depth of a goal.")
	AP_FIELD("GoalBackLineLength", m_GoalAreaBackLineLength, "Goal Area Back Line Length." )
	AP_FIELD("GoalFrontLineLength", m_GoalAreaFrontFlatLineLength, "Goal Area Front Line Length." )
	AP_FIELD("GoalBallHandleRectangleWidth", m_GoalBallHandleRectangleWidth, "Goal Ball Handling Rectangle Width." )
	AP_FIELD("GoalBallHandleRectangleLength", m_GoalBallHandleRectangleLength, "Goal Ball Handling Rectangle Length." )
	AP_COMMAND(Reset, "Resets the pitch parameters and restart the game state.")
	AP_PROXY("SharedFootballLibrary") 
AP_TYPE_END()

////////////////////////////////////////////////////////////

void PitchData::InitPitch(float width, 
                          float length,
                          float centreCircleRadius,
                          float goalWidth, 
                          float goalHeight,
                          float goalDepth,
						  float goalAreaBackLineLength,
						  float goalAreaFrontLineLength,
						  float goalBallHandleRectangleWidth,
						  float goalBallHandleRectangleLength )
{
	Reset( width, length, centreCircleRadius, goalWidth, goalHeight, goalDepth, goalAreaBackLineLength, goalAreaFrontLineLength, goalBallHandleRectangleWidth, goalBallHandleRectangleLength );
}						  
	
////////////////////////////////////////////////////////////
						  
void PitchData::Reset( float width, 
                       float length,
                       float centreCircleRadius,
                       float goalWidth, 
                       float goalHeight,
                       float goalDepth,
					   float goalAreaBackLineLength,
					   float goalAreaFrontLineLength,
					   float goalBallHandleRectangleWidth,
					   float goalBallHandleRectangleLength )
{
    m_Width = width;
	m_Length = length;
	m_HalfWidth = width / 2.0f;
	m_HalfLength = length / 2.0f;
	m_CentreCircleRadius = centreCircleRadius;
	m_GoalWidth = goalWidth;
	m_GoalHeight = goalHeight;	
	m_GoalDepth = goalDepth;
	m_GoalAreaBackLineLength = goalAreaBackLineLength;
	m_GoalAreaFrontFlatLineLength = goalAreaFrontLineLength;
	m_GoalBallHandleRectangleWidth = goalBallHandleRectangleWidth;
	m_GoalBallHandleRectangleLength = goalBallHandleRectangleLength;
	
	m_wallHeight = 5.f;

    AP_DATAVALIDATION_SUPPORT( m_Initialized = true; )

    AP_DATAVALIDATION_SUPPORT(AP_POSTCONDITION( Initialized() );)
}

////////////////////////////////////////////////////////////

const float PitchData::GoalAreaBackLineLength() const
{
	return m_GoalAreaBackLineLength;
}

////////////////////////////////////////////////////////////

const float	PitchData::GoalAreaFrontFlatLineLength() const
{
	return m_GoalAreaFrontFlatLineLength;
}

////////////////////////////////////////////////////////////

const float PitchData::GoalBallHandleRectangleWidth() const
{
	return m_GoalBallHandleRectangleWidth;
}

////////////////////////////////////////////////////////////

const float	PitchData::GoalBallHandleRectangleLength() const
{
	return m_GoalBallHandleRectangleLength;
}

////////////////////////////////////////////////////////////

bool PitchData::InBounds( const Axiom::Math::Vector2Adapter& pos, float safetyMargin ) const
{
    return Axiom::Math::Fabs( pos.Value().X() ) <= (m_HalfLength + safetyMargin)
        && Axiom::Math::Fabs( pos.Value().Y() ) <= (m_HalfWidth + safetyMargin);
}

////////////////////////////////////////////////////////////

bool PitchData::InGoal( const Axiom::Math::Vector3& pos, bool check_height ) const
{
    return Axiom::Math::Fabs( pos.X() ) > m_HalfLength
		&& Axiom::Math::Fabs( pos.X() ) <= (m_HalfLength+m_GoalDepth)
        && Axiom::Math::Fabs( pos.Y() ) <= (m_GoalWidth/2.0f)
		&& ((0.0f<=pos.Z() && pos.Z()<=m_GoalHeight) || !check_height); 
}

////////////////////////////////////////////////////////////

bool PitchData::InGoalBallHandleBounds( const Axiom::Math::Vector2Adapter& pos, float safetyMargin ) const
{
	return	Axiom::Math::Fabs( pos.Value().X() ) <= (m_HalfLength + safetyMargin) &&
			Axiom::Math::Fabs( pos.Value().X() ) >= (m_HalfLength - m_GoalBallHandleRectangleLength - safetyMargin) && 
			Axiom::Math::Fabs( pos.Value().Y() ) <= (m_GoalBallHandleRectangleWidth / 2.0f + safetyMargin);
}

////////////////////////////////////////////////////////////

float PitchData::AttackingPositionProgressRatio( const Axiom::Math::Vector2Adapter& point, ETeam team ) const
{
    //AP_PRECONDITION( InBounds( point ) )
    Axiom::Math::Vector2 clampPoint = ClampedToPitch( point.Value() );
    
    float result = clampPoint.X() / m_HalfLength;
    
    if( team == ETeam::ETeam_AWAY )
    {
        result *= -1.0f;
    }

    AP_ASSERT( Axiom::Math::Fabs(result) < 1.20f ); // 10% of the total field length
    
    result = Axiom::Math::FClamp( result, -1.0f, 1.0f );

    AP_POSTCONDITION( result >= -1.0f && result <= 1.0f );
    
    return result;
}

////////////////////////////////////////////////////////////

bool PitchData::InOwnHalf( const Axiom::Math::Vector2Adapter& point, ETeam team ) const
{
    return AttackingPositionProgressRatio( point, team ) <= 0.0f;
}

////////////////////////////////////////////////////////////

float PitchData::RightHalfPositionRatio( const Axiom::Math::Vector2Adapter& point, ETeam team ) const
{
    Axiom::Math::Vector2 clampPoint = ClampedToPitch( point.Value() );

    float result = clampPoint.Y() / m_HalfWidth;

    if( team == ETeam::ETeam_HOME )
    {
        result *= -1.0f;
    }

    AP_POSTCONDITION( result >= -1.0f && result <= 1.0f );

    return result;
}

////////////////////////////////////////////////////////////

float PitchData::DistanceFrom( Axiom::Math::Vector3 pitchCoords,
                               EPointOfReference pointOfReference,
                               ETeam team ) const
{
    using Axiom::Math::Vector3;

    float result = 0.0f;
    if( team == ETeam::ETeam_AWAY )
    {
        pitchCoords *= -1.0f;
    }

    switch( pointOfReference )
    {
    case EPointOfReference_MY_LEFT_TOUCHLINE:
        {
            result = pitchCoords.Y() + m_HalfWidth;
        }
        break;
    case EPointOfReference_OWN_GOAL_LINE:
    case EPointOfReference_OPPOSITION_GOAL_LINE:
        {
            result = pitchCoords.X() + m_HalfLength;
            if( pointOfReference == EPointOfReference_OPPOSITION_GOAL_LINE )
            {
                result = ( m_Length - result );
            }
        }
        break;
    case EPointOfReference_OPPOSITION_GOAL:
        pitchCoords.X(pitchCoords.X() - m_HalfLength);
        result = pitchCoords.Magnitude();
        break;
    default:
        AP_ASSERTFAIL( "Bad case" );
    }

    return result;
}

////////////////////////////////////////////////////////////

ELandmark PitchData::AttackingCorner( const Axiom::Math::Vector3& playerPos,
                                      ETeam playerTeam,
                                      ERelativeDistance relativeDistance ) const
{
    bool nearerLeftCornerFlag = IsInLeftHalfOfPitch( playerPos, playerTeam );
    
    return ( nearerLeftCornerFlag == ( relativeDistance == ERelativeDistance_NEARER ) ) ? ELandmark_FRONT_LEFT_CORNER_FLAG : ELandmark_FRONT_RIGHT_CORNER_FLAG;   
}
                                           
////////////////////////////////////////////////////////////                                           

Axiom::Math::Vector3 PitchData::LandmarkPosition( ETeam team,
                                           ELandmark landmark ) const
{
    AP_PRECONDITION( landmark != ELandmark_NULL_LANDMARK );
    
    using Axiom::Math::Vector3;
    
    #define HOTSPOT_DISTANCE_FROM_GOAL_LINE 6.5f

    Vector3 result( 0.0f, 0.0f, 0.0f );

    switch( landmark )
    {
    case ELandmark_REAR_LEFT_CORNER_FLAG:
        {
            result.X(-m_HalfLength);
            result.Y(m_HalfWidth);
            break;
        }
    case ELandmark_REAR_RIGHT_CORNER_FLAG:
        {
            result.X(-m_HalfLength);
            result.Y(-m_HalfWidth);
            break;
        }
    case ELandmark_LEFT_TOUCHLINE_CENTRE:
        {
            result.Y(m_HalfWidth);
            break;
        }
    case ELandmark_RIGHT_TOUCHLINE_CENTRE:
        {
            result.Y(-m_HalfWidth);
            break;
        }
    case ELandmark_FRONT_LEFT_CORNER_FLAG:
        {
            result.X(m_HalfLength);
            result.Y(m_HalfWidth);
            break;
        }
    case ELandmark_FRONT_RIGHT_CORNER_FLAG:
        {
            result.X(m_HalfLength);
            result.Y(-m_HalfWidth);
            break;
        }
    
    case ELandmark_GOAL_IM_DEFENDING_GEOMETRIC_CENTRE:
        {
            // just making this value up right now...
            result.X(-( m_HalfLength - 2.5f ) );
            break;
        }
    case ELandmark_GOAL_IM_DEFENDING_CENTRE:
        {
            result.X(-m_HalfLength);
            break;
        }
    case ELandmark_GOAL_IM_DEFENDING_PENALTY_SPOT:
        {
            result.X(-( m_HalfLength - HOTSPOT_DISTANCE_FROM_GOAL_LINE ));
            break;
        }
    case ELandmark_GOAL_IM_DEFENDING_LEFT_POST:
        {
            result.X(-m_HalfLength);
            result.Y(m_GoalWidth / 2.0f);
            break;
        }
    case ELandmark_GOAL_IM_DEFENDING_RIGHT_POST:
        {
            result.X(-m_HalfLength);
            result.Y(-m_GoalWidth / 2.0f);
            break;
        }
    case ELandmark_GOAL_IM_ATTACKING_CENTRE:
        {
            result.X(m_HalfLength);
            break;
        }
     case ELandmark_GOAL_IM_ATTACKING_PENALTY_SPOT:
        {
            result.X(( m_HalfLength - HOTSPOT_DISTANCE_FROM_GOAL_LINE ));
            break;
        }
    case ELandmark_GOAL_IM_ATTACKING_LEFT_POST:
        {
            result.X(m_HalfLength);
            result.Y(m_GoalWidth / 2.0f);
            break;
        }
    case ELandmark_GOAL_IM_ATTACKING_RIGHT_POST:
        {
            result.X(m_HalfLength);
            result.Y(-m_GoalWidth / 2.0f);
            break;
        }
    case ELandmark_GOAL_IM_ATTACKING_CENTRE_BACK_OF_NET:
        {
            result.X(m_HalfLength + m_GoalDepth);
            break;
        }        
    default:
        AP_ASSERTMESSAGE( landmark == ELandmark_CENTRE_SPOT, "Bad case!" );
        AP_ASSERT( result == Vector3( 0.0f, 0.0f, 0.0f ) );
    };

    if( team == ETeam::ETeam_AWAY )
    {
        result *= -1.0f;
    }

    return result;
}

////////////////////////////////////////////////////////////

Axiom::Math::Vector2 PitchData::LandmarkPosition2D( ETeam myTeam,
                                                    ELandmark landmark ) const
{
    return Axiom::Math::Vector2FromVector3XY( LandmarkPosition( myTeam, landmark ) );
}

////////////////////////////////////////////////////////////

Axiom::Math::Vector3 PitchData::PointXMetresInFrontOfTargetGoalCentre( ETeam myTeam, float xMetres ) const
{
    const Axiom::Math::Vector3 centreOfGoal = LandmarkPosition( myTeam, ELandmark_GOAL_IM_ATTACKING_CENTRE );
    const Axiom::Math::Vector3 penaltySpot = LandmarkPosition( myTeam, ELandmark_GOAL_IM_ATTACKING_PENALTY_SPOT );
    Axiom::Math::Vector3 toPenaltySpotFromCentre = penaltySpot - centreOfGoal;
    
    AP_ASSERT( toPenaltySpotFromCentre.SquareMagnitude() > 0.0f );
    
    return centreOfGoal + ( toPenaltySpotFromCentre.AsNormal() * xMetres );
}

////////////////////////////////////////////////////////////

EPitchZoneCategory PitchData::PitchZoneCategory( ETeam myTeam,
                                                 const Axiom::Math::Vector2Adapter& posAdapter ) const
{
    EPitchZoneCategory result = EPitchZoneCategory_MIDFIELD_ATTACK;
    const Axiom::Math::Vector2 pos = posAdapter.Value();
    bool bInBounds = InBounds(posAdapter);

    bool flipped = false;
    if( pos.X() < 0 ) 
    {
        flipped = true;
    }
    
    const float ratioOfFullLength = RatioOfFullLength( pos );
    const float ratioOfFullWidth = RatioOfFullWidth( pos );

	if (bInBounds == false)
	{
		if (ratioOfFullLength < 0.0f)
		{
			result = EPitchZoneCategory_OUT_OF_BOUNDS_DEFENCE;
		}
		else if (ratioOfFullLength > 1.0f)
		{
			result = EPitchZoneCategory_OUT_OF_BOUNDS_ATTACK;
		}
		else
		{ // we are out-of-bounds on the pitch sides, but still use the length to determine attack or defense
			if (ratioOfFullLength > 0.0f)
			{
				result = EPitchZoneCategory_OUT_OF_BOUNDS_ATTACK;
			}
			else
			{
				result = EPitchZoneCategory_OUT_OF_BOUNDS_DEFENCE;
			}
		}
	}
    else
    {
        if ((ratioOfFullLength > 0.66f) && (ratioOfFullWidth < 0.50f))
        {
			result = EPitchZoneCategory_INNER_GOAL_THREAT_ATTACK;
        }
        else if ((ratioOfFullLength > 0.50f) && (ratioOfFullWidth < 0.66f))
        {
            result = EPitchZoneCategory_OUTER_GOAL_THREAT_ATTACK;
        }
        
    }
    
    if( flipped == ( myTeam == ETeam::ETeam_HOME ) )
    {
        int nMaxVal = static_cast< int >( EPitchZoneCategory_INNER_GOAL_THREAT_DEFENCE );
        result = static_cast< EPitchZoneCategory >( nMaxVal - static_cast< int >( result ) );
    }
    
    return result;
}
                                      
////////////////////////////////////////////////////////////

bool PitchData::IsInLeftHalfOfPitch( const Axiom::Math::Vector2Adapter& position,
                                     ETeam wrtTeam ) const
{
    return RightHalfPositionRatio( position, wrtTeam ) <= 0.0f;
}  

////////////////////////////////////////////////////////////

Axiom::Math::Vector2 PitchData::AttackingDirection( ETeam team ) const
{
    Axiom::Math::Vector2 result( 1.0f, 0.0f );
    if( team == ETeam::ETeam_AWAY )
    {
        result *= -1.0f;
    }
    
    AP_POSTCONDITION( result.IsNormal() );
    
    return result;    
}

////////////////////////////////////////////////////////////

float PitchData::RatioOfFullWidth( const Axiom::Math::Vector2Adapter& pos ) const
{
    float result = Axiom::Math::Fabs( pos.Value().Y() ) / m_HalfWidth;
    
    return result;
}

////////////////////////////////////////////////////////////

float PitchData::RatioOfFullLength( const Axiom::Math::Vector2Adapter& pos ) const
{
    float result = Axiom::Math::Fabs( pos.Value().X() ) / m_HalfLength;

    return result;
}

////////////////////////////////////////////////////////////

Axiom::Math::Vector3 PitchData::ClampedToPitchInternal( const Axiom::Math::Vector3& unclamped, SafetyMarginSpecifier margin ) const
{
    float safetyLength = m_HalfLength - margin.m_XVal;
    float safetyWidth = m_HalfWidth - margin.m_YVal;
    return Axiom::Math::Vector3( Axiom::Math::FClamp( unclamped.X(), -safetyLength, safetyLength ),
                                 Axiom::Math::FClamp( unclamped.Y(), -safetyWidth, safetyWidth ),
                                 unclamped.Z() );
}

////////////////////////////////////////////////////////////

SharedSoccer::Shape::Line2 PitchData::Side( int i ) const
{
    AP_PRECONDITION( i >= 0 && i <= 3 );
    
    ELandmark landmarkA = ELandmark_REAR_LEFT_CORNER_FLAG;
    ELandmark landmarkB = ELandmark_FRONT_LEFT_CORNER_FLAG;
    
    switch( i )
    {
    case 0:
        landmarkA = ELandmark_FRONT_LEFT_CORNER_FLAG;
        landmarkB = ELandmark_FRONT_RIGHT_CORNER_FLAG;
        break;
    case 1:
        landmarkA = ELandmark_FRONT_RIGHT_CORNER_FLAG;
        landmarkB = ELandmark_REAR_RIGHT_CORNER_FLAG;
        break;
    case 2:
        landmarkA = ELandmark_REAR_RIGHT_CORNER_FLAG;
        landmarkB = ELandmark_REAR_LEFT_CORNER_FLAG;
        break;
    default:
        AP_ASSERT( i == 3 );
        AP_ASSERT( landmarkA == ELandmark_REAR_LEFT_CORNER_FLAG );
        AP_ASSERT( landmarkB == ELandmark_FRONT_LEFT_CORNER_FLAG );
    }

    return SharedSoccer::Shape::Line2( Axiom::Math::Vector2FromXY( LandmarkPosition( ETeam::ETeam_HOME, landmarkA ) ),
							   Axiom::Math::Vector2FromXY( LandmarkPosition( ETeam::ETeam_HOME, landmarkB ) ) );
}

////////////////////////////////////////////////////////////

Axiom::Math::Vector2 PitchData::ClampedToPitch( const Axiom::Math::Vector2& unclamped, SafetyMarginSpecifier safetyMargin ) const
{
    return Axiom::Math::Vector2FromXY( ClampedToPitch( Axiom::Math::Vector3WithZeroZ( unclamped ), safetyMargin ) );
}

///////////////////////////////// deprecated patch methods ///////////////////////////

Axiom::Math::Vector3 PitchData::ClampedToPitch( const Axiom::Math::Vector3& unclamped, float deprecatedSafetyMargin ) const
{
    return ClampedToPitch( unclamped, SafetyMarginSpecifier::CreateUniformMargin( deprecatedSafetyMargin ) );
}

Axiom::Math::Vector2 PitchData::ClampedToPitch( const Axiom::Math::Vector2& unclamped, float deprecatedSafetyMargin ) const
{
    return ClampedToPitch( unclamped, SafetyMarginSpecifier::CreateUniformMargin( deprecatedSafetyMargin ) );
}

////////////////////////////////////////////////////////////

Axiom::Math::Vector3 PitchData::NearestPositionOnNearestSidelineTo( const Axiom::Math::Vector3& pos ) const
{
    Axiom::Math::Vector3 result( pos );
    
    if( result.Y() >= 0.0f )
    {
        result.Y( HalfWidth() );
    }
    else
    {
        result.Y( -HalfWidth() );
    }
    
    return ClampedToPitch( result );
}

////////////////////////////////////////////////////////////

// static 
bool PitchData::HasPitchInstance()
{
    return s_PitchInstance != NULL;
}
// 
// static 
void PitchData::AssignPitchInstance( const PitchData& pitchData )
{
    s_PitchInstance = &pitchData;
    
    AP_POSTCONDITION( HasPitchInstance() ); 
}

// static 
const PitchData& PitchData::PitchInstance()
{
    AP_PRECONDITION( HasPitchInstance() );
    
    return *s_PitchInstance;
}

Axiom::Math::Vector2 PitchData::SlideClampToPitch( const Axiom::Math::Vector2Adapter& unclampedPosAdapter,
                                                   const Axiom::Math::Vector2Adapter& anchorPosAdapter,
                                                   SafetyMarginSpecifier safetyMargin,
                                                   ESlidePreference preference ,
                                                   ETeam preferenceIsWRTTeam ) const
{
    using Axiom::Math::Vector2;
    
    const Vector2 unclampedPos = unclampedPosAdapter.Value();
    
    const Vector2 clampedPos = ClampedToPitch( unclampedPos, safetyMargin );
    if( clampedPos == unclampedPos )
    {
        // nothing to clamp!
        return unclampedPos;
    }
    else
    {
        // may need to do us some slide clampin'
        const Vector2 anchorPos = anchorPosAdapter.Value();
        Vector2 shiftVec = unclampedPos - anchorPos;
        
        Vector2 slideDirectionUnitVector;
        
        if( preference != ESlidePreference_SLIDE_IN_EITHER_DIRECTION )
        {
            // might not want to slide at all...
            
            ELandmark landmark = ( preference == ESlidePreference_ONLY_SLIDE_IN_ATTACK_DIRECTION
                                   || preference == ESlidePreference_ALWAYS_SLIDE_IN_ATTACK_DIRECTION ) 
                                 ? ELandmark_GOAL_IM_ATTACKING_CENTRE : ELandmark_GOAL_IM_DEFENDING_CENTRE;
            
            slideDirectionUnitVector = LandmarkPosition2D( preferenceIsWRTTeam, landmark ).AsNormal();
            
            if( preference == ESlidePreference_ONLY_SLIDE_IN_ATTACK_DIRECTION
                || preference == ESlidePreference_ONLY_SLIDE_IN_DEFENCE_DIRECTION )
            {
                if( slideDirectionUnitVector.Dot( shiftVec ) < 0.0f )
                {
                    // we're not sliding at all...just return the clamped pos
                    return clampedPos;
                }
            }
        }
        else
        {
            slideDirectionUnitVector = ( shiftVec.X() >= 0.0f ) ? Vector2( 1.0f, 0.0f ) : Vector2( -1.0f, 0.0f );
        }
        
        // okay, so now we can determine the corner toward which we're sliding
        Vector2 cornerPos = slideDirectionUnitVector;
        cornerPos.Y( shiftVec.Y() >= 0.0f ? 1.0f : -1.0f );
        cornerPos *= 1000.0f;    // guaranteed to be outside pitch
        cornerPos = ClampedToPitch( cornerPos, safetyMargin );
        
        const Vector2 toCornerFromAnchor = cornerPos - anchorPos;
        const float shiftVecMagnitude = shiftVec.Magnitude();
        if( toCornerFromAnchor.SquareMagnitude() <= Axiom::Math::Square( shiftVecMagnitude ) )
        {
            // we nestle right in the corner
            return cornerPos;
        }
        else
        {
            SharedSoccer::Shape::Circle circle( anchorPos, shiftVecMagnitude );
            SharedSoccer::Shape::Line2 wall( clampedPos, cornerPos );
            Axiom::Math::Vector2 interceptPoints[2];
            int nIntercepts = circle.nIntercepts( wall, SharedSoccer::Shape::Circle::ETreatLineAsInfinite_YES, &interceptPoints[0], &interceptPoints[1] );
            if( nIntercepts == 0 )
            {
                // weird...should really have at least one. Oh well...
                return unclampedPos;
            }
            else if( nIntercepts == 1 )
            {
                return interceptPoints[0];
            }
            else
            {
                // return whichever is closer to the corner
                int closerIndex = ( ( interceptPoints[0] - cornerPos ).SquareMagnitude() < ( interceptPoints[1] - cornerPos ).SquareMagnitude() ) ? 0 : 1;
                {
                    return interceptPoints[ closerIndex ];
                }
            }
        }
    }
}

} // end namespace AP

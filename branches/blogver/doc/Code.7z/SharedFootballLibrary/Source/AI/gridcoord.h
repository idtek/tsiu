// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#ifndef GRIDCOORDdotH
# define GRIDCOORDdotH

#include "gameplay/pitch.h"
#include "string/staticstring.h"

namespace Soccer
{
    //======================================================================
    // CLASS GridCoord
    //======================================================================
    template <unsigned X_, unsigned Y_>
    class GridCoord
    {
      public:
        AP_DECLARE_TEMPLATE_TYPE_I_I(X_, Y_);
        
        enum
        {
            N_ZONES_LONG  = X_,
            N_ZONES_WIDE  = Y_,
            N_ZONES_TOTAL = N_ZONES_LONG * N_ZONES_WIDE
        }; // enum <anonymous>

        enum EWrapType
        {
            EWrapType_IGNORE,
            EWrapType_CLAMP,
            EWrapType_REPEAT,
            //EWrapType_REFLECT,   // not implemented

            EWrapType_N_TYPES
        }; // enum EWrapType

        
        static GridCoord CreateFromXY( int x, int y );
        static GridCoord CreateFromIndex( int idx );
        static GridCoord CreateFromString( const Axiom::ShortString& str );
        static GridCoord CreateFromPosition( const Axiom::Math::Vector2Adapter& pos );
        static GridCoord CreateInvalid();

        static Axiom::Math::Vector2 Dimensions();
        
        GridCoord();
        GridCoord( int x, int y );

        bool IsValid() const;
        
        int X() const;
        int Y() const;

        int                  AsIndex() const;
        Axiom::ShortString   AsString() const;
        Axiom::Math::Vector2 AsVector2() const;

        GridCoord PrevX( EWrapType wrap = EWrapType_IGNORE ) const;
        GridCoord PrevY( EWrapType wrap = EWrapType_IGNORE ) const;
        GridCoord NextX( EWrapType wrap = EWrapType_IGNORE ) const;
        GridCoord NextY( EWrapType wrap = EWrapType_IGNORE ) const;
        
        GridCoord ReflectX() const;
        GridCoord ReflectY() const;
        GridCoord ReflectXY() const;

        bool IsEqual( const GridCoord& rhs ) const;

        int   SquareDistanceTo( const GridCoord& coord ) const;
        float DistanceTo( const GridCoord& coord ) const;

        Axiom::Math::Vector2 GetInterpolants( const Axiom::Math::Vector2Adapter& pos ) const;
        
        
      private:

        int mGridX;
        int mGridY;

    }; // class GridCoord

    
    template <unsigned X_, unsigned Y_>
    inline bool operator == ( const GridCoord<X_,Y_>& lhs, const GridCoord<X_,Y_>& rhs )
    {
        return lhs.IsEqual(rhs);
    }

    template <unsigned X_, unsigned Y_>
    inline bool operator != ( const GridCoord<X_,Y_>& lhs, const GridCoord<X_,Y_>& rhs )
    {
        return !(lhs == rhs);
    }

}  // namespace Soccer


namespace Soccer {

//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::CreateFromXY( int x, int y )
{
    return GridCoord(x, y);
}

//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::CreateFromIndex( int idx )
{
    AP_PRECONDITION( 0 <= idx && idx < N_ZONES_TOTAL );

    return GridCoord( idx / N_ZONES_WIDE, idx % N_ZONES_WIDE );
}
    
//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::CreateFromString( const Axiom::ShortString& str )
{
    AP_PRECONDITION( str.Length() == 3 );

    int x = Axiom::StringConvertToInt(str.Right(2).AsChar(), 10) - 1;
    int y = str[0] - 'A';

    return GridCoord(x, y);
}

//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::CreateFromPosition( const Axiom::Math::Vector2Adapter& pos )
{
    AP_PRECONDITION( PitchData::HasPitchInstance() );
    const PitchData& pitch = PitchData::PitchInstance();
    
    AP_DATAVALIDATION_SUPPORT(AP_ASSERT( pitch.Initialized() ));

    const float halfLength = pitch.HalfLength();
    const float halfWidth  = pitch.HalfWidth();
    
    Axiom::Math::Vector2 inBoundsPos = pitch.ClampedToPitch( pos.Value() );
    Axiom::Math::Vector2 gridDim = Dimensions();

    int gridX = static_cast<int>((inBoundsPos.X() + halfLength) / gridDim.X());
    int gridY = static_cast<int>((inBoundsPos.Y() + halfWidth) / gridDim.Y());

    gridX = Axiom::Math::Clamp( gridX, 0, N_ZONES_LONG-1 );
    gridY = Axiom::Math::Clamp( gridY, 0, N_ZONES_WIDE-1 );

    return GridCoord( gridX, gridY );
}

//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::CreateInvalid()
{
    return GridCoord();
}

//------------------------------------------------------------------------------
// static
template <unsigned X_, unsigned Y_>
Axiom::Math::Vector2 GridCoord<X_,Y_>::Dimensions()
{
    AP_PRECONDITION( PitchData::HasPitchInstance() );
    const PitchData& pitch = PitchData::PitchInstance();

	AP_DATAVALIDATION_SUPPORT(AP_ASSERT( pitch.Initialized() ));

    return Axiom::Math::Vector2( pitch.Length() / N_ZONES_LONG, pitch.Width() / N_ZONES_WIDE );
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_>::GridCoord()
    : mGridX(-1)
    , mGridY(-1)
{}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_>::GridCoord( int x, int y )
    : mGridX(x)
    , mGridY(y)
{
    AP_ASSERT( IsValid() );
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
bool GridCoord<X_,Y_>::IsValid() const
{
    return (0 <= mGridX && mGridX < N_ZONES_LONG) &&
           (0 <= mGridY && mGridY < N_ZONES_WIDE);
}
      
//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
int GridCoord<X_,Y_>::X() const
{
    return mGridX;
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
int GridCoord<X_,Y_>::Y() const
{
    return mGridY;
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
int GridCoord<X_,Y_>::AsIndex() const
{
    AP_PRECONDITION( IsValid() );

    return (mGridX * N_ZONES_WIDE) + mGridY;
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
Axiom::ShortString GridCoord<X_,Y_>::AsString() const
{
    AP_PRECONDITION( IsValid() );
    
    return Axiom::ShortString::CreateFromFormat( "%c%02d", mGridY + 'A', mGridX + 1 );
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
Axiom::Math::Vector2 GridCoord<X_,Y_>::AsVector2() const
{
    AP_PRECONDITION( PitchData::HasPitchInstance() );
    const PitchData& pitch = PitchData::PitchInstance();

	AP_DATAVALIDATION_SUPPORT(AP_ASSERT( pitch.Initialized() ));

    const float halfLength = pitch.HalfLength();
    const float halfWidth  = pitch.HalfWidth();

    Axiom::Math::Vector2 halfExtents = Dimensions() / 2.0f;

    return Axiom::Math::Vector2( halfExtents.X() * (2*X()+1) - halfLength,
                                 halfExtents.Y() * (2*Y()+1) - halfWidth );
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::PrevX( EWrapType wrap ) const
{
    if( mGridX > 0 )
    {
        return GridCoord( mGridX-1, mGridY );
    }

    switch( wrap )
    {
      case EWrapType_IGNORE:
        return GridCoord( mGridX-1, mGridY );

      case EWrapType_CLAMP:
        return *this;

      case EWrapType_REPEAT:
        return ReflectX();

      default:
        AP_ASSERT( false );
    }
    
    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::NextX( EWrapType wrap ) const
{
    if( mGridX < (N_ZONES_LONG-1) )
    {
        return GridCoord( mGridX+1, mGridY );
    }

    switch( wrap )
    {
      case EWrapType_IGNORE:
        return GridCoord( mGridX+1, mGridY );

      case EWrapType_CLAMP:
        return *this;

      case EWrapType_REPEAT:
        return ReflectX();

      default:
        AP_ASSERT( false );
    }
    
    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::PrevY( EWrapType wrap ) const
{
    if( mGridY > 0 )
    {
        return GridCoord( mGridX, mGridY-1 );
    }

    switch( wrap )
    {
      case EWrapType_IGNORE:
        return GridCoord( mGridX, mGridY-1 );

      case EWrapType_CLAMP:
        return *this;

      case EWrapType_REPEAT:
        return ReflectY();

      default:
        AP_ASSERT( false );
    }
    
    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::NextY( EWrapType wrap ) const
{
    if( mGridY < (N_ZONES_WIDE-1) )
    {
        return GridCoord( mGridX, mGridY+1 );
    }

    switch( wrap )
    {
      case EWrapType_IGNORE:
        return GridCoord( mGridX, mGridY+1 );

      case EWrapType_CLAMP:
        return *this;

      case EWrapType_REPEAT:
        return ReflectY();

      default:
        AP_ASSERT( false );
    }
    
    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::ReflectX() const
{
    if( IsValid() )
    {
        return GridCoord( N_ZONES_LONG - mGridX - 1, mGridY );
    }

    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::ReflectY() const
{
    if( IsValid() )
    {
        return GridCoord( mGridX, N_ZONES_WIDE - mGridY - 1 );
    }

    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
GridCoord<X_,Y_> GridCoord<X_,Y_>::ReflectXY() const
{
    if( IsValid() )
    {
        return GridCoord( N_ZONES_LONG - mGridX - 1,
                          N_ZONES_WIDE - mGridY - 1 );
    }

    return GridCoord::CreateInvalid();
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
bool GridCoord<X_,Y_>::IsEqual( const GridCoord& rhs ) const
{
    return mGridX == rhs.mGridX && mGridY == rhs.mGridY;
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
int GridCoord<X_,Y_>::SquareDistanceTo( const GridCoord& coord ) const
{
    int x2 = Axiom::Math::Square( mGridX - coord.X() );
    int y2 = Axiom::Math::Square( mGridY - coord.Y() );

    return x2 + y2;
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
float GridCoord<X_,Y_>::DistanceTo( const GridCoord& coord ) const
{
    return Axiom::Math::SquareRoot( static_cast<float>(SquareDistanceTo(coord)) );
}

//------------------------------------------------------------------------------
//
template <unsigned X_, unsigned Y_>
Axiom::Math::Vector2 GridCoord<X_,Y_>::GetInterpolants( const Axiom::Math::Vector2Adapter& pos ) const
{
    AP_PRECONDITION( PitchData::HasPitchInstance() );
    const PitchData& pitch = PitchData::PitchInstance();

	AP_DATAVALIDATION_SUPPORT(AP_ASSERT( pitch.Initialized() ));

    const float halfLength = pitch.HalfLength();
    const float halfWidth  = pitch.HalfWidth();
    
    Axiom::Math::Vector2 inBoundsPos = pitch.ClampedToPitch( pos.Value() );
    Axiom::Math::Vector2 gridDim = Dimensions();

    // `int' as in `interpolant', not integer ;-)
    float intX = (inBoundsPos.X() + halfLength) / gridDim.X();
    float intY = (inBoundsPos.Y() + halfWidth) / gridDim.Y();

    intX -= mGridX;
    intY -= mGridY;

    return Axiom::Math::Vector2( intX, intY );
}

//------------------------------------------------------------------------------
//
#define AP_TEMPLATE_TYPE_PARAM_TEMPLATE  template <unsigned X_, unsigned Y_>
#define AP_TEMPLATE_TYPE_PARAM_CLASS  GridCoord<X_,Y_>
AP_TEMPLATE_TYPE_2(GridCoord)
	AP_FIELD("GridX", mGridX, "X coord")
	AP_FIELD("GridY", mGridY, "Y coord")
	AP_TEMPLATE_PROXY("SharedFootballLibrary", "Gameplay")
AP_TYPE_END()
#undef AP_TEMPLATE_TYPE_PARAM_CLASS
#undef AP_TEMPLATE_TYPE_PARAM_TEMPLATE

} // namespace Soccer

#endif

#ifndef _PERSISTENTDEBUGDRAW_ABSTRACT_H
#define _PERSISTENTDEBUGDRAW_ABSTRACT_H

// forward decs

namespace Axiom
{
    namespace Math
    {
        class Vector2;
    }
}

namespace Soccer
{

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
class PersistentDebugDrawAbstract
{
public:
    virtual void            AddLine( const Axiom::Math::Vector2& pos1,
                                     const Axiom::Math::Vector2& pos2,
                                     int gelColorAsInt,
                                     unsigned int channels ) = 0;
protected:
	PersistentDebugDrawAbstract() {}
	virtual ~PersistentDebugDrawAbstract() {};
};

}  // end namespace AP


#endif // _PERSISTENTDEBUGDRAW_ABSTRACT_H

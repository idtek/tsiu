#ifndef _ZONE2D_H
#define _ZONE2D_H

//--------------------------------------------------------------------------
/* _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
  /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
 / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
/_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|

Copyright (c) 2007 by Action Pants Inc

Class:      Zone2D

Lib:        Soccer
Desc:       ABC with subclasses, defining a 3D region. A 3D boolean predicate, if you will.

*/
//--------------------------------------------------------------------------

#include <core/referenced.h>
#include <core/smartptr.h>

#include "math/conversion.h"
#include "shape/aabb.h"
#include "shape/circle.h"

////////////////////////////////////////////////////////////////////

namespace Axiom
{
    namespace Math
    {
        class AABoundingRectangle;
        class Vector2;
        class Vector3;
    }
}

namespace Soccer
{

class PersistentDebugDrawAbstract;


/////////////////////////////////////// class Zone2D ///////////////////////////////////////

class Zone2D : public Axiom::Referenced
{
  public:
    bool            Covers( const Axiom::Math::Vector2Adapter& ) const;
    
    AP_USERDEBUG_SUPPORT( virtual void DisplayGraphically( PersistentDebugDrawAbstract*, unsigned int channels ) {} )
    
    AP_DECLARE_POLYMORPHIC_TYPE();

  private:
    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const = 0;

};

typedef Axiom::SmartPtr< Zone2D > Zone2DPtr;

class Zone2DFactory
{
public:
    static Zone2DPtr     CreateAxisAlignedRectangle( const SharedSoccer::Shape::AABoundingRectangle& );
    static Zone2DPtr     CreateCircularZone( const SharedSoccer::Shape::Circle& );
    
    // AP_PRECONDITION( flattenedFrontLength >= 0.0f )
    // AP_PRECONDITION( flattenedFrontLength < backLineLength )
    // AP_PRECONDITION( orientation.SquareMagnitude() > 0.0f )
    static Zone2DPtr     CreateSplitSemiCircleZone( const Axiom::Math::Vector2& backLineCentre,
                                                    const Axiom::Math::Vector2& orientation,
                                                    float backLineLength,
                                                    float flattenedFrontLength );
        
    static Zone2DPtr     CreateInvertedZone( Zone2DPtr pZoneToInvert );
    static Zone2DPtr     CreateORZone( Zone2DPtr pZone1, Zone2DPtr pZone2 );
};
  
/////////////////////////////////////////////////// 

} // end namespace AP

#endif //_ZONE2D_H


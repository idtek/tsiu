// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#include "AI/attackpatterndb.h"

#include "files/filemanager.h"
#include "reflection/serialize.h"

namespace Soccer {

namespace
{
    static const char EmptyDbFilename[] = "INVALID";
}


//==============================================================================
// CLASS AttackPatternDB
//==============================================================================

AttackPatternDB::AttackPatternDB()
    : mPatternDBs()
    , mCurPatternDB(0)
    , mCurAge(-1)
{
}

//------------------------------------------------------------------------------
//
AttackPatternDB::~AttackPatternDB()
{
    ClearDatabase();
}


//------------------------------------------------------------------------------
// Used for tests in FormationEditor.dll to make sure that SOMETHING is loaded automatically

bool AttackPatternDB::LoadAnyDatabaseForTestingPurposes()
{
	if (mCurPatternDB!=NULL)
		return true;

    using namespace Axiom::FileManager;
    FileManager* fs = FileManager::GetInstance();

	FileSet * files = fs->FindFilesWithExtension("scripts:ai_tables", ".rst");	
	AP_ASSERTMESSAGE(files->Count()>0, "No attack pattern DBs could be found");

	const char *firstFileName = (*files)[0].AsChar();
	const char *lastSlash = Axiom::StringRevFindChar(firstFileName, '\\');
	if (lastSlash!=NULL)
		firstFileName = lastSlash+1;
	lastSlash = Axiom::StringRevFindChar(firstFileName, '/');
	if (lastSlash!=NULL)
		firstFileName = lastSlash+1;
	const char *period = Axiom::StringRevFindChar(firstFileName, '.');
	AP_ASSERT(period!=NULL);
	int pos = period - firstFileName;
	Axiom::ShortString tempName;
	tempName.AssignFromSubstring(firstFileName, pos);

	return LoadDatabase(tempName.AsChar());
}

//------------------------------------------------------------------------------
//
bool AttackPatternDB::LoadDatabase( const char* dbName )
{
    Axiom::StringCRC crcName = dbName;

    // check the cache
    for( int i = 0; i < CastToInt(mPatternDBs.Count()); ++i )
    {
        if( mPatternDBs[i].name == crcName )
        {
            // found
            mPatternDBs[i].age = ++mCurAge;
            mCurPatternDB = &mPatternDBs[i].db;

            return true;
        }
    }

    // find LRU
    PatternCacheEntry* lru = 0;
    if( mPatternDBs.IsFull() )
    {
        lru = &mPatternDBs.FirstItem();
        for( int i = 1; i < CastToInt(mPatternDBs.Count()); ++i )
        {
            if( mPatternDBs[i].age < lru->age )
            {
                lru = &mPatternDBs[i];
            }
        }
    }
    else
    {
        mPatternDBs.AddDefault();
        lru = &mPatternDBs.LastItem();
    }

    AP_ASSERT( lru != 0 );

    // load new db into lru
    lru->name = crcName;
    lru->age  = ++mCurAge;
    lru->db.Clear();
    
    // fill the db with null data
    PatternList list;
    list.Add( AttackPattern() );

    while( !lru->db.IsFull() )
    {
        lru->db.Add( list );
    }

    mCurPatternDB = &lru->db;
    
    // load database
    using namespace Axiom::FileManager;
    FileManager* fs = FileManager::GetInstance();

    Axiom::ShortString fileName = Axiom::ShortString::CreateFromFormat( "scripts:/ai_tables/%s.rst", dbName );
    const FileInfo fileInfo = fs->GetFileInfo( fileName.AsChar() );
    
    if( fileInfo.GetSize() > 0 )
    {
        AP::Reflection::Deserialize::FromFile( fileName.AsChar(), this );
        //mLastDbName = dbName;
    }
    else
    {
		return false;
    }
	return true;
}

//------------------------------------------------------------------------------
//
void AttackPatternDB::ClearDatabase()
{
    mPatternDBs.Clear();
    mCurPatternDB = 0;
    mCurAge = -1;
}

//------------------------------------------------------------------------------
//
void AttackPatternDB::ExchangeDatabase()
{
    AP_PRECONDITION( mPatternDBs.Count() >= 2 );
    
    PatternCacheEntry* mru = &mPatternDBs[0]; // most recently used
    PatternCacheEntry* mru2 = &mPatternDBs[1]; // second most recently used

    if( mru->age < mru2->age )
    {
        Axiom::Swap( mru, mru2 );
    }

    for( int i = 2; i < CastToInt(mPatternDBs.Count()); ++i )
    {
        if( mPatternDBs[i].age > mru->age )
        {
            mru2 = mru;
            mru = &mPatternDBs[i];
        }
    }

    mru2->age = ++mCurAge;
    mCurPatternDB = &mru2->db;
}

//------------------------------------------------------------------------------
//
const AttackPatternDB::PatternList& AttackPatternDB::FindPatterns( const PitchGridCoord& coord ) const
{
    AP_PRECONDITION( mCurPatternDB != 0 );
    
    return mCurPatternDB->Item( coord.AsIndex() );
}

AP_TYPE(AttackPatternDB)
	AP_FIELD("AttackPatternDatabase", mCurPatternDB, "Pattern database" )
	AP_COMMAND(LoadDatabase, "Reload the attack pattern database.")
	AP_COMMAND(LoadAnyDatabaseForTestingPurposes, "Load any attack pattern database if nothing is currently loaded.")
	AP_COMMAND(ExchangeDatabase, "Exchange the two most recently used databases.")
	AP_PROXY("Gameplay")
AP_TYPE_END()

} // namespace Soccer

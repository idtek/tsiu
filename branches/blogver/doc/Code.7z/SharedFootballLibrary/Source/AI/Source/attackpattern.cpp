// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#include "AI/attackpattern.h"


namespace
{
    static const char* ERoleDebugStrings[] =
    {
        "INVALID",
        "ATTACK",
        "SUPPORT",
        "DEFENSE",
        "KEEPER",
        "OPTION1",
        "OPTION2",
        "OPTION3",
    };

    static const char* ERoleDebugLetters[] =
    {
        "-",
        "A",
        "S",
        "D",
        "K",
        "1",
        "2",
        "3",
    };
} // namespace <anonymous>

namespace Soccer {

//==============================================================================
// CLASS AttackPattern
//==============================================================================

AttackPattern::AttackPattern()
    : mBallCarrier(PitchGridCoord::CreateInvalid())
    , mRoleCoords()
{
    while( !mRoleCoords.IsFull() )
    {
        mRoleCoords.AddDefault();
    }
}

//------------------------------------------------------------------------------
//
bool AttackPattern::IsValid() const
{
    if( mBallCarrier.IsValid() && mRoleCoords.Count() >= ERole_N_BASIC_ROLES )
    {
        for( int i = 0; i < ERole_N_BASIC_ROLES; ++i )
        {
            if( !mRoleCoords[i].IsValid() )
            {
                return false;
            }
        }

        return true;
    }

    return false;
}

//------------------------------------------------------------------------------
//
bool AttackPattern::IsEqual( const AttackPattern& rhs ) const
{
    return mBallCarrier == rhs.mBallCarrier
        && mRoleCoords == rhs.mRoleCoords;
}

//------------------------------------------------------------------------------
// static
AP_USERDEBUG_SUPPORT( const char* AttackPattern::GetRoleDebugString( AttackPattern::ERole role ) { return ERoleDebugStrings[role+1]; } )

//------------------------------------------------------------------------------
// static
AP_USERDEBUG_SUPPORT( const char* AttackPattern::GetRoleDebugStringShort( AttackPattern::ERole role ) { return ERoleDebugLetters[role+1]; } )

//------------------------------------------------------------------------------
//
AP_TYPE(AttackPattern)
	AP_FIELD("BallCarrier", mBallCarrier, "Ball carrier PitchGridCoord")
	AP_FIELD("RoleCoords", mRoleCoords, "Supporting player PitchGridCoords")
	AP_PROXY("Gameplay") //common
AP_TYPE_END()


//==============================================================================
// CLASS AttackPatternInstance
//==============================================================================

AttackPatternInstance::AttackPatternInstance()
    : mPattern()
    , mReflect(EReflect_NONE)
{}

//------------------------------------------------------------------------------
//
AttackPatternInstance::AttackPatternInstance( const AttackPattern* pattern, EReflect reflect )
    : mPattern(*pattern)
    , mReflect(reflect)
{}

//------------------------------------------------------------------------------
//
AttackPatternInstance::AttackPatternInstance( const AttackPattern& pattern, EReflect reflect )
    : mPattern(pattern)
    , mReflect(reflect)
{}

//------------------------------------------------------------------------------
//
bool AttackPatternInstance::IsValid() const
{
    return mPattern.IsValid();
}

//------------------------------------------------------------------------------
//
PitchGridCoord AttackPatternInstance::BallCarrierPos() const
{
    AP_PRECONDITION( IsValid() );

    return DoReflect( mPattern.mBallCarrier, mReflect );
}

//------------------------------------------------------------------------------
//
PitchGridCoord AttackPatternInstance::RolePos( AttackPattern::ERole role ) const
{
    AP_PRECONDITION( IsValid() );
    AP_PRECONDITION( role != AttackPattern::ERole_INVALID );

    return DoReflect( mPattern.mRoleCoords[role], mReflect );
}

//------------------------------------------------------------------------------
//
PitchGridCoord AttackPatternInstance::GetPatternKey() const
{
    return mPattern.mBallCarrier;
}

//------------------------------------------------------------------------------
// static
PitchGridCoord AttackPatternInstance::DoReflect( const PitchGridCoord& coord, EReflect reflect )
{
    // TODO
    if( reflect & EReflect_X )
        return coord.ReflectXY();

    return coord;
}


} // namespace Soccer

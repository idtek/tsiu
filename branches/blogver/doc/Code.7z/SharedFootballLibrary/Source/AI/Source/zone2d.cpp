// class header
#include "AI/zone2d.h"

// other includes
#include "AI/persistentdebugdrawabstract.h"

#include "math/conversion.h"
#include "graphics/color.h"



namespace Soccer
{

AP_TYPE(Zone2D)
//
AP_PROXY("SharedFootballLibrary")
AP_TYPE_END()

bool Zone2D::Covers( const Axiom::Math::Vector2Adapter& pos ) const
{
    return DoCovers( pos.Value() );
}

// ------------------------------------ Zone2ds ------------------------------------

/////////////////////////////////////// AARectangleZone ///////////////////////////////////////

class AARectangleZone : public Zone2D
{
public:
    AARectangleZone( const SharedSoccer::Shape::AABoundingRectangle& );

private:

    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const;

    SharedSoccer::Shape::AABoundingRectangle m_Rectangle;
};

AARectangleZone::AARectangleZone( const SharedSoccer::Shape::AABoundingRectangle& rect )
:   m_Rectangle( rect )
{
    // Empty method body
}

// virtual 
bool AARectangleZone::DoCovers( const Axiom::Math::Vector2& pos ) const
{
    return m_Rectangle.Contains( pos );
}

/////////////////////////////////////// CircularZone ///////////////////////////////////////

class CircularZone : public Zone2D
{
public:
    CircularZone( const SharedSoccer::Shape::Circle& );

private:

    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const;

    SharedSoccer::Shape::Circle m_Circle;
};

CircularZone::CircularZone( const SharedSoccer::Shape::Circle& circle )
:   m_Circle( circle )
{
    // Empty method body
}

// virtual 
bool CircularZone::DoCovers( const Axiom::Math::Vector2& pos ) const
{
    return m_Circle.Contains( pos );
}

/////////////////////////////////////// SplitSemiCircleZone ///////////////////////////////////////

class SplitSemiCircleZone : public Zone2D
{
public:

    // AP_PRECONDITION( flattenedFrontLength >= 0.0f )
    // AP_PRECONDITION( flattenedFrontLength < backLineLength )
    // AP_PRECONDITION( orientation.SquareMagnitude() > 0.0f )
    SplitSemiCircleZone( const Axiom::Math::Vector2& backLineCentre,
                         const Axiom::Math::Vector2& orientation,
                         float backLineLength,
                         float flattenedFrontLength );

private:

    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const;

    AP_USERDEBUG_SUPPORT( virtual void DisplayGraphically( PersistentDebugDrawAbstract* pDebugDraw, unsigned int channels ); )
    
    // AP_PRECONDITION( i == 0 || i == 1 )
    Axiom::Math::Vector2    CircleCentre( int i ) const;
    float                   CircleRadius() const;

    Axiom::Math::Vector2    m_BackLineCentre;
    Axiom::Math::Vector2    m_Orientation;
    Axiom::Math::Vector2    m_RotatedOrientation;
    float                   m_BackLineHalfLength;
    float                   m_HalfFlattenedFrontLength;
};

#if CORE_USERDEBUG == CORE_YES
// virtual 
	void SplitSemiCircleZone::DisplayGraphically( PersistentDebugDrawAbstract* pDebugDraw, unsigned int channels )
	{
		int red = GRAPHICS_RGBAF(1.0f, 0.0f, 0.0f, 1.0f);
	    
		pDebugDraw->AddLine( m_BackLineCentre + ( m_RotatedOrientation * m_BackLineHalfLength ),
							 m_BackLineCentre + ( m_RotatedOrientation * m_BackLineHalfLength * -1.0f ),
							 red,
							 channels );
	     
		for( int i = 0; i < 2; ++i )
		{
			Axiom::Math::Vector2 circleCentre = CircleCentre( i );
			Axiom::Math::Vector2 radiusTouchingFlat = circleCentre + ( m_Orientation * CircleRadius() );
	    
			pDebugDraw->AddLine( circleCentre, radiusTouchingFlat, red, channels );
		}
	}
#endif

SplitSemiCircleZone::SplitSemiCircleZone( const Axiom::Math::Vector2& backLineCentre,
                                          const Axiom::Math::Vector2& orientation,
                                          float backLineLength,
                                          float flattenedFrontLength )
:   m_BackLineCentre( backLineCentre ),
    m_Orientation( orientation ),
    m_BackLineHalfLength( backLineLength / 2.0f ),
    m_HalfFlattenedFrontLength( flattenedFrontLength / 2.0f )
{
    AP_PRECONDITION( flattenedFrontLength >= 0.0f );
    AP_PRECONDITION( flattenedFrontLength < backLineLength );
    AP_PRECONDITION( orientation.SquareMagnitude() > 0.0f );

    m_Orientation.Normalize();    
    m_RotatedOrientation = m_Orientation.Rotated90DegreesClockwise();
}

Axiom::Math::Vector2 SplitSemiCircleZone::CircleCentre( int i ) const
{
    AP_PRECONDITION( i == 0 || i == 1 );
    
    return m_BackLineCentre + ( m_RotatedOrientation * ( i == 0 ? m_HalfFlattenedFrontLength : -m_HalfFlattenedFrontLength ) );
}

float SplitSemiCircleZone::CircleRadius() const
{
    return m_BackLineHalfLength - m_HalfFlattenedFrontLength;
}

// virtual 
bool SplitSemiCircleZone::DoCovers( const Axiom::Math::Vector2& pos ) const
{
    const Axiom::Math::Vector2 toPosFromBackLineCentre = pos - m_BackLineCentre;
    
    // we can perform a cheap first test: if we're further than m_BackLineHalfLength away from the centre, we cannot possibly
    // be within the zone
    if( toPosFromBackLineCentre.SquareMagnitude() > Axiom::Math::Square( m_BackLineHalfLength ) )
    {
        return false;
    }
    
    // if the position is behind the back line, forget it.
    if( toPosFromBackLineCentre.Dot( m_Orientation ) < 0.0f )
    {
        return false;
    }

    // Now we test to see whether the point is within one of the two quarter circles at either end.
    // Note that we can happily perform a standard circle test - we already know it cannot be
    // in the rear half of the circle due to the above test, and if it's in the "inner quarter", well, hey,
    // that's fine, because it must be within the overall zone.
    const float circleRadius = CircleRadius();
    
    for( int i = 0; i < 2; ++i )
    {
        const Axiom::Math::Vector2 testCircleCentre = CircleCentre( i );
        const Axiom::Math::Vector2 toPosFromTestCircle = pos - testCircleCentre;
        if( Axiom::Math::LessEqual( toPosFromTestCircle.SquareMagnitude(), Axiom::Math::Square( circleRadius ) ) )
        {
            return true;
        }
    }
    
    // the last test is for lying within the central "square".
    if( toPosFromBackLineCentre.Dot( m_Orientation ) > circleRadius )
    {
        return false;
    }
    
    return Axiom::Math::Fabs( toPosFromBackLineCentre.Dot( m_RotatedOrientation ) ) <= m_HalfFlattenedFrontLength;
}

/////////////////////////////////////// InvertedZone ///////////////////////////////////////

class InvertedZone : public Zone2D
{
public:
    InvertedZone( Zone2DPtr pZoneToInvert );

private:

    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const;

    Zone2DPtr m_pInvertedZone;
};

InvertedZone::InvertedZone( Zone2DPtr pZoneToInvert )
:   m_pInvertedZone( pZoneToInvert )
{
    // Empty method body
}

// virtual 
bool InvertedZone::DoCovers( const Axiom::Math::Vector2& pos ) const
{
    return !m_pInvertedZone->Covers( pos );
}

/////////////////////////////////////// ORZone ///////////////////////////////////////

class ORZone : public Zone2D
{
public:
    ORZone( Zone2DPtr pZone1, Zone2DPtr pZone2 );

private:

    virtual bool    DoCovers( const Axiom::Math::Vector2& ) const;

    Zone2DPtr m_pZone1;
    Zone2DPtr m_pZone2;
};

ORZone::ORZone( Zone2DPtr pZone1, Zone2DPtr pZone2 )
:   m_pZone1( pZone1 ),
    m_pZone2( pZone2 )
{
    // Empty method body
}

// virtual 
bool ORZone::DoCovers( const Axiom::Math::Vector2& pos ) const
{
    return m_pZone1->Covers( pos ) || m_pZone2->Covers( pos );
}

/////////////////////////////////////// class Zone2DFactory ///////////////////////////////////////

// static 
Zone2DPtr Zone2DFactory::CreateAxisAlignedRectangle( const SharedSoccer::Shape::AABoundingRectangle& rect )
{
    return AP_NEW( Axiom::Memory::AI_HEAP, AARectangleZone( rect) );
}

// static 
Zone2DPtr Zone2DFactory::CreateCircularZone( const SharedSoccer::Shape::Circle& circle )
{
    return AP_NEW( Axiom::Memory::AI_HEAP, CircularZone( circle) );
}

// static 
Zone2DPtr Zone2DFactory::CreateSplitSemiCircleZone( const Axiom::Math::Vector2& backLineCentre,
                                                    const Axiom::Math::Vector2& orientation,
                                                    float backLineLength,
                                                    float flattenedFrontLength )
{
    return AP_NEW( Axiom::Memory::AI_HEAP, SplitSemiCircleZone( backLineCentre, orientation, backLineLength, flattenedFrontLength ) );
}

// static 
Zone2DPtr Zone2DFactory::CreateInvertedZone( Zone2DPtr pZoneToInvert )
{
    return AP_NEW( Axiom::Memory::AI_HEAP, InvertedZone( pZoneToInvert) );
}

// static 
Zone2DPtr Zone2DFactory::CreateORZone( Zone2DPtr pZone1, Zone2DPtr pZone2 )
{
    return AP_NEW( Axiom::Memory::AI_HEAP, ORZone( pZone1, pZone2) );
}

} // end namespace AP

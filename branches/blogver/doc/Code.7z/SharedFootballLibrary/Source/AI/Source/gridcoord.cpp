// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#include "AI/gridcoord.h"

// TODO: GridCoord is now a template.

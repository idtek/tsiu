// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#ifndef ATTACKPATTERNdotH
#define ATTACKPATTERNdotH

#include "ai/gridcoord.h"


namespace Soccer
{
    typedef GridCoord<12, 8>  PitchGridCoord;
    
    // ======================================================================
    // CLASS AttackPattern
    // ======================================================================
    struct AttackPattern
    {
        AP_DECLARE_TYPE();
        
        enum ERole
        {
            ERole_INVALID = -1,
            
            ERole_ATTACK,
            ERole_SUPPORT,
            ERole_DEFENSE,
            ERole_KEEPER,

            ERole_N_BASIC_ROLES,
            
            ERole_OPTION1 = ERole_N_BASIC_ROLES,
            ERole_OPTION2,
            ERole_OPTION3,
            
            ERole_N_ROLES,
            ERole_N_OPTION_ROLES = ERole_N_ROLES - ERole_N_BASIC_ROLES,
        };  // enum EAttackPatternRole

        AP_USERDEBUG_SUPPORT( static const char* GetRoleDebugString( ERole role ); )
        AP_USERDEBUG_SUPPORT( static const char* GetRoleDebugStringShort( ERole role ); )
        
        typedef Axiom::Collections::StaticList<PitchGridCoord, ERole_N_ROLES>  RoleCoordList;

        PitchGridCoord mBallCarrier;
        RoleCoordList mRoleCoords;

        AttackPattern();

        bool IsValid() const;
        bool IsEqual( const AttackPattern& rhs ) const;
        
    }; // struct AttackPattern

    //------------------------------------------------------------------------------
    //
    inline bool operator==( const AttackPattern& lhs, const AttackPattern& rhs )
    {
        return lhs.IsEqual( rhs );
    }
    
    //------------------------------------------------------------------------------
    //
    inline bool operator!=( const AttackPattern& lhs, const AttackPattern& rhs )
    {
        return !(lhs == rhs);
    }
    

    // ======================================================================
    // CLASS AttackPatternInstance
    // ======================================================================
    class AttackPatternInstance
    {
      public:
        
        enum EReflect
        {
            EReflect_NONE = 0,
            EReflect_X    = 1 << 0,
            EReflect_Y    = 1 << 1,
            EReflect_XY   = EReflect_X | EReflect_Y
        }; // enum EReflect

        AttackPatternInstance();
        AttackPatternInstance( const AttackPattern* pattern, EReflect reflect );
        AttackPatternInstance( const AttackPattern& pattern, EReflect reflect );

        bool IsValid() const;

        PitchGridCoord BallCarrierPos() const;
        PitchGridCoord RolePos( AttackPattern::ERole role ) const;

        PitchGridCoord GetPatternKey() const;
        
      private:

        static PitchGridCoord DoReflect( const PitchGridCoord& coord, EReflect reflect );
        
        AttackPattern mPattern;
        EReflect mReflect;

    }; // class AttackPatternInstance
    
    
} // namespace Soccer


#endif

// Copyright (c) 2008 Action Pants Inc.  All rights reserved.

#ifndef ATTACKPATTERNDBdotH
# define ATTACKPATTERNDBdotH

#include "ai/attackpattern.h"
#include "ai/gridcoord.h"

#include "collections/list.h"
#include "core/singleton.h"


namespace Soccer {

//======================================================================
// CLASS AttackPatternDB
//======================================================================

// TODO: Perhaps add a push/pop mechanism so that client code doesn't
// need to maintain state about previous pattern dbs when switching
// between them (eg from open play to goalkick and back).

class AttackPatternDB
{
  public:

    AP_DECLARE_TYPE();

    enum
    {
        MAX_PATTERNS_PER_ZONE = 1,
    };

    typedef Axiom::Collections::StaticList<AttackPattern, MAX_PATTERNS_PER_ZONE>  PatternList;

    
    AttackPatternDB();
    ~AttackPatternDB();
    
	bool LoadAnyDatabaseForTestingPurposes();
    bool LoadDatabase( const char* dbName );
    void ClearDatabase();

    void ExchangeDatabase();
    
    const PatternList& FindPatterns( const PitchGridCoord& coord ) const;


  private:

    typedef Axiom::Collections::StaticList<PatternList, PitchGridCoord::N_ZONES_TOTAL>  PatternDB;
    
    enum
    {
        MAX_CACHED_DBS = 1,
    };
    
    struct PatternCacheEntry
    {
        Axiom::StringCRC name;
        int age;
        PatternDB db;
    };

    typedef Axiom::Collections::StaticList<PatternCacheEntry, MAX_CACHED_DBS>  PatternDBCache;
    
    
    PatternDBCache mPatternDBs;
    PatternDB* mCurPatternDB;
    int mCurAge;

}; // class AttackPatternDB


} // namespace Soccer

#endif

//////////////////////////////////////////////////////////////////////////
//
//  Arc   version:  1.0    date: 10/10/2008
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/arc.h"
#include "math/apmath.h"

using namespace Axiom::Math;

//////////////////////////////////////////////////////////////////////////
// sphere

namespace SharedSoccer
{
namespace Shape
{

Arc::Arc()
{
	// NON initializing ctor!
}

Arc::Arc(float radius, Angle angle)
	: m_radius(radius)
	, m_angle(angle)
{
	AP_ASSERT(m_radius >= 0.0f);
}

Arc::Arc(float radius, float radian)
	: m_radius(radius)
	, m_angle(radian)
{
	AP_ASSERT(m_radius >= 0.0f);
}

void Arc::EndAxis(Vector2& pt1, Vector2& pt2)const
{
	Angle axisAngle = m_axis.Rotation();
	pt1 = Vector2::CreateFromAngle(axisAngle + (m_angle/2.0f));
	pt2 = Vector2::CreateFromAngle(axisAngle - (m_angle/2.0f));
}

float Arc::Length()const
{
	return m_angle.AsRadians() * m_radius;
}

bool Arc::Contains( const Vector2& point ) const
{
	Vector2 toPoint = point - m_focal;
	float sqMag = toPoint.SquareMagnitude();
	
	// Not within the sphere radius
	if (sqMag < (m_radius * m_radius))
	{
		return false;
	}

	// Test to see if it is within the arc angle
	toPoint.Normalize();
	float angleBetweenAxisAndPoint = m_axis.Dot(toPoint);
	if ((angleBetweenAxisAndPoint * 2.0f) > m_angle.AsRadians())
	{
		return false;
	}

	return true;
}

} // end namespace Shape

} // end namespace SharedSoccer

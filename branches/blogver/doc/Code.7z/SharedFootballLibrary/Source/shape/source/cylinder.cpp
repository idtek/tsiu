//////////////////////////////////////////////////////////////////////////
//
//  cylinder   version:  1.0    date: 12/05/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/cylinder.h"

#include "math/apmath.h"
#include "math/rigidmatrix.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{
		AP_TYPE(Cylinder)
					AP_DEFAULT_CREATE()
		AP_TYPE_END()

//////////////////////////////////////////////////////////////////////////
// simple right cylinder

Cylinder::Cylinder()
{
	// NON initializing ctor!
}

Cylinder::Cylinder(float halfHeight, float radius) 
:	m_halfHeight(halfHeight)
,	m_radius(radius)
{
	// zero or positive height!
	AP_ASSERT(halfHeight >= 0.f);
	
	// tiny or zero radius ARE not allowed
	// (it's best to only support zero radius or zero height!)
	AP_ASSERT(radius > EPSILON); 
}

Cylinder::~Cylinder()
{
}

Cylinder Cylinder::GetInvalid()
{
	Cylinder retVal;
	retVal.m_halfHeight = retVal.m_radius = -FLOAT_MAX;
	return retVal;
}

} // end namespace Shape

} // end namespace SharedSoccer

//////////////////////////////////////////////////////////////////////////
//
//  overlap   version:  1.0    date: 11/27/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/overlap.h"

#include "math/apmath.h"
#include "shape/aabb.h"
#include "shape/gjk.h"

#include <core/utils.h>
#include "collections/fixedszarray.h"
#include "math/transformutils.h"

using namespace AP;
using namespace Axiom::Math;

namespace
{

	const float k_sqrOverlapEpsilon = Square(0.05f);

	float AxisTest(float c, float e1, float e2, float e3)
	{
		UNUSED_PARAM(e3);
		return FSel(c, FSel(e1 + e2 - Fabs(e1), FLOAT_MAX, -FLOAT_MAX), -FLOAT_MAX);
	}

	//////////////////////////////////////////////////////////////////////////

	template <class MapperA, class MapperB>
	bool IsOverlapTemplateLhsRelative(const MapperA& mapperLhs, const RigidMatrix& lhsT,
									  const MapperB& mapperRhs, const RigidMatrix& rhsT,
									  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
									  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
	{
		AP_ASSERT(Equal(lhsT.mRotation.Magnitude(), 1.0f));
		AP_ASSERT(Equal(rhsT.mRotation.Magnitude(), 1.0f));

		RigidMatrix lhsRelativeTransf = rhsT * lhsT.AsInverse();
		RigidMatrix lhsRelativeInvTransf = lhsRelativeTransf.AsInverse();
		typedef SharedSoccer::Shape::TransformedShapeSupportMapper<MapperB> TransformedSupportMapperT;
		TransformedSupportMapperT mapperRhsTransf(mapperRhs, lhsRelativeTransf);

		AP_ASSERT(Equal(lhsRelativeTransf.mRotation.Magnitude(), 1.0f));
		AP_ASSERT(Equal(lhsRelativeInvTransf.mRotation.Magnitude(), 1.0f));
		
		Vector3 overlapPtOnLhs, overlapPtOnRhs;
		Vector3 normalOnLhs, normalOnRhs;
		SharedSoccer::Shape::Gjk gjkMachine;

		bool isOverlapResult = gjkMachine.GetClosestPts(mapperLhs, mapperRhsTransf, lhsRelativeTransf.mTranslation,
														k_sqrOverlapEpsilon, overlapPtOnLhs, overlapPtOnRhs, normalOnLhs, normalOnRhs);

		outOverlapPtOnLhs = overlapPtOnLhs * lhsT;
		outOverlapPtOnRhs = (overlapPtOnRhs * lhsRelativeInvTransf) * rhsT;

		outNormalOnLhs = normalOnLhs * lhsT.mRotation;
		outNormalOnRhs = (normalOnRhs * lhsRelativeInvTransf.mRotation) * rhsT.mRotation;

		// BUMMER: I'd love to get rid of the following
		//		   (the trouble is that it means we have to move the normalize found
		//			inside of the GJK support mapper and do it after all the rotation
		//			transforms... not easy!)
		outNormalOnLhs.Normalize();
		outNormalOnRhs.Normalize();

		AP_ASSERT(Equal(outNormalOnLhs.Magnitude(), 1.0f));
		AP_ASSERT(Equal(outNormalOnRhs.Magnitude(), 1.0f));

		return isOverlapResult;
	}

	//////////////////////////////////////////////////////////////////////////

	template <class MapperA, class MapperB>
	bool IsOverlapTemplateTransformedShapes(const MapperA& mapperLhs, const RigidMatrix& lhsT,
											const MapperB& mapperRhs, const RigidMatrix& rhsT,
											Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
											Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
	{
		SharedSoccer::Shape::TransformedShapeSupportMapper<MapperA> mapperTransfA(mapperLhs, lhsT);
		SharedSoccer::Shape::TransformedShapeSupportMapper<MapperB> mapperTransfB(mapperRhs, rhsT);

		SharedSoccer::Shape::Gjk gjkMachine;
		bool isOverlapResult = gjkMachine.GetClosestPts(mapperTransfA, mapperTransfB, rhsT.mTranslation - lhsT.mTranslation, 
														k_sqrOverlapEpsilon, outOverlapPtOnLhs, outOverlapPtOnRhs, outNormalOnLhs, outNormalOnRhs);

		// BUMMER: I'd love to get rid of the following
		//		   (the trouble is that it means we have to move the normalize found
		//			inside of the GJK support mapper and do it after all the rotation
		//			transforms... not easy!)
		outNormalOnLhs.Normalize();
		outNormalOnRhs.Normalize();
		AP_ASSERT(Equal(outNormalOnLhs.Magnitude(), 1.0f));
		AP_ASSERT(Equal(outNormalOnRhs.Magnitude(), 1.0f));

		return isOverlapResult;
	}

	//////////////////////////////////////////////////////////////////////////

//#define IsOverlapTemplate IsOverlapTemplateLhsRelative
#define IsOverlapTemplate IsOverlapTemplateTransformedShapes

	//////////////////////////////////////////////////////////////////////////

	const int k_maxNumHalfs = 4;

	template <class MapperA, class MapperB>
	bool IsSweptOverlapTemplateTimeHalving(const MapperA& mapperLhs, const RigidMatrix& lhsT0, const RigidMatrix& lhsT1,
										   const MapperB& mapperRhs, const RigidMatrix& rhsT0, const RigidMatrix& rhsT1,
										   int recursionDepth, float lowerBoundTimeFraction, float upperBoundTimeFraction,
										   Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
										   Vector3& outNormalOnLhs, Vector3& outNormalOnRhs, float& outTimeOfOverlap)
	{
		Vector3 overlapPtOnLhsTime0;
		Vector3 overlapPtOnRhsTime0;
		Vector3 normalOnLhsTime0;
		Vector3 normalOnRhsTime0;

		Vector3 overlapPtOnLhsTime1;
		Vector3 overlapPtOnRhsTime1;
		Vector3 normalOnLhsTime1;
		Vector3 normalOnRhsTime1;

		bool isOverlapTime0 = IsOverlapTemplate(mapperLhs, lhsT0, mapperRhs, rhsT0,
												overlapPtOnLhsTime0, overlapPtOnRhsTime0,
												normalOnLhsTime0, normalOnRhsTime0);

		bool isOverlapTime1 = IsOverlapTemplate(mapperLhs, lhsT1, mapperRhs, rhsT1,
												overlapPtOnLhsTime1, overlapPtOnRhsTime1,
												normalOnLhsTime1, normalOnRhsTime1);

		int result = ((isOverlapTime0)? 0 : 2) | ((isOverlapTime1)? 1 : 0);
		switch(result)
		{
			case 0: // overlap on time 0 but not on time 1
			case 1: // overlap on time 0 and on time 1
			case 2: // no overlap on time 0 and no overlap on time 1

				// use data from first test
				outTimeOfOverlap = lowerBoundTimeFraction;
				outOverlapPtOnLhs = overlapPtOnLhsTime0;
				outOverlapPtOnRhs = overlapPtOnRhsTime0;
				outNormalOnLhs = normalOnLhsTime0;
				outNormalOnRhs = normalOnRhsTime0;
				return result < 2;
				break;
		
			case 3:
			{
				// test recursion depth
				if(--recursionDepth <= 0)
				{
					outTimeOfOverlap = upperBoundTimeFraction;
					outOverlapPtOnLhs = overlapPtOnLhsTime1;
					outOverlapPtOnRhs = overlapPtOnRhsTime1;
					outNormalOnLhs = normalOnLhsTime1;
					outNormalOnRhs = normalOnRhsTime1;
					return true;
				}

				// recursively split interval in two
				RigidMatrix lhsMiddle = Interpolate(0.5f, lhsT0, lhsT1);
				RigidMatrix rhsMiddle = Interpolate(0.5f, rhsT0, rhsT1);
				float middleTimeFraction = (lowerBoundTimeFraction + upperBoundTimeFraction) * 0.5f;

				if(IsSweptOverlapTemplateTimeHalving(mapperLhs, lhsT0, lhsMiddle,
													 mapperRhs, rhsT0, rhsMiddle,
													 recursionDepth, lowerBoundTimeFraction, middleTimeFraction,
													 outOverlapPtOnLhs, outOverlapPtOnRhs,
													 outNormalOnLhs, outNormalOnRhs, outTimeOfOverlap))
				{
					return true;
				}

				return IsSweptOverlapTemplateTimeHalving(mapperLhs, lhsMiddle, lhsT1,
														 mapperRhs, rhsMiddle, rhsT1,
														 recursionDepth, middleTimeFraction, upperBoundTimeFraction,
														 outOverlapPtOnLhs, outOverlapPtOnRhs,
														 outNormalOnLhs, outNormalOnRhs, outTimeOfOverlap);

				break;
			}
		
			default:
				break;
		}
		
		AP_ASSERTFAIL("unhandled case in time halving algorithm");
		outTimeOfOverlap = 0.0f;
		outOverlapPtOnLhs = overlapPtOnLhsTime0;
		outOverlapPtOnRhs = overlapPtOnRhsTime0;
		outNormalOnLhs = normalOnLhsTime0;
		outNormalOnRhs = normalOnRhsTime0;
		return false;
	}

	//////////////////////////////////////////////////////////////////////////

#define IsSweptOverlapTemplate IsSweptOverlapTemplateTimeHalving
}

namespace SharedSoccer
{
namespace Shape
{

//////////////////////////////////////////////////////////////////////////
// overlap

bool IsOverlap(const Aabb& lhs, const Aabb& rhs)
{
	// Taken from: http://www.gamasutra.com/features/19991018/Gomez_3.htm (ctrl+click on link)
	Vector3 centerDiff = rhs.m_center - lhs.m_center;
	Vector3 extentSum = rhs.m_halfExtents + lhs.m_halfExtents;
	return fabs(centerDiff.X()) <= extentSum.X() && fabs(centerDiff.Y()) <= extentSum.Y() && fabs(centerDiff.Z()) <= extentSum.Z();

	// If we know we're in a reasonable range we can implement a test against epsilon!
	// Vector3 testDiff = Vector3(fabs(centerDiff.x), fabs(centerDiff.y), fabs(centerDiff.z)) - extentSum;
	// return testDiff.x <= EPSILON && testDiff.y <= EPSILON && testDiff.z <= EPSILON;
}

bool IsSweptOverlap(const SweptAabb& lhs, const SweptAabb& rhs, float& normTimeOfOverlap)
{
	// Taken from: http://www.gamasutra.com/features/19991018/Gomez_3.htm (ctrl+click on link)
	//
	// Solved in A's frame of reference (ignoring rotation since aabbs are always axis aligned)
	//

	// Discreet overlap test
	if(IsOverlap(Aabb(lhs.m_centerTime0, lhs.m_halfExtents), Aabb(rhs.m_centerTime0, rhs.m_halfExtents)))
	{
		// early out!!!
		normTimeOfOverlap = 0;
		return true;
	}

	// displacement
	const Vector3 va = lhs.m_centerTime1 - lhs.m_centerTime0;
	const Vector3 vb = rhs.m_centerTime1 - rhs.m_centerTime0;

	// Relative velocity (in normalized time)
	Vector3 v = vb - va;

	// if velocity is zero, then we have already all the information we need
	// (since we already performed an overlap test)
	if(v.SquareMagnitude() < EPSILON)
	{
		normTimeOfOverlap = 0;
		return false;
	}

	// init first time of overlap (along each axis)
	Vector3 timeOfOverlap(-1.0f, -1.0f, -1.0f);

	// init last time of separation (along each axis)
	Vector3 timeOfSep(1.0f, 1.0f, 1.0f);

	// min and max points of each box at time t0
	Vector3 lhsMax = lhs.m_centerTime0 + lhs.m_halfExtents;
	Vector3 lhsMin = lhs.m_centerTime0 - lhs.m_halfExtents;
	Vector3 rhsMax = rhs.m_centerTime0 + rhs.m_halfExtents;
	Vector3 rhsMin = rhs.m_centerTime0 - rhs.m_halfExtents;

	// TODO: rewrite loop in parallelized form!
	for(Axiom::Byte i = 0; i < 3; ++i)
	{
		// This code produces the same result as the commented out block below, bit runs faster and is branch free.
		float lMax = lhsMax[i], rMax = rhsMax[i], lMin = lhsMin[i], rMin = rhsMin[i], viA = v[i], viB = v[i];

		float timeOfOverlapA = (lMax - rMin) / viA;
		float timeOfSepA = (lMin - rMax) / viB;
		float timeOfOverlapB = (lMin - rMax) / viA;
		float timeOfSepB = (lMax - rMin) / viB;

		float mod = FSel( rMin - lMax, FSel( viA, -1.0f, timeOfOverlapA), -1.0f );
		float sepMod = FSel( rMax - lMin, FSel( viB, 1.0f, timeOfSepA ), 1.0f );
		float res = FSel( mod, mod, FSel( lMin - rMax, FSel( viA - EPSILON, timeOfOverlapB, -1.0f ), -1.0f ) );
		float sepRes = FSel( sepMod, sepMod, FSel( lMax - rMin, FSel( viB - EPSILON, timeOfSepB, 1.0f ), 1.0f ) );
		timeOfOverlap[i] = res;
		timeOfSep[i] = sepRes;

		//if( lhsMax[i] < rhsMin[i] && v[i] < 0.0f )
		//{
		//	timeOfOverlap[i] = (lhsMax[i] - rhsMin[i]) / v[i];
		//}
		//else if( rhsMax[i] < lhsMin[i] && v[i] > 0.0f )
		//{
		//	timeOfOverlap[i] = (lhsMin[i] - rhsMax[i]) / v[i];
		//}
		//
		//if( rhsMax[i] > lhsMin[i] && v[i] < 0.0f )
		//{
		//	timeOfSep[i] = (lhsMin[i] - rhsMax[i]) / v[i]; 
		//}
		//else if( lhsMax[i] > rhsMin[i] && v[i] > 0.0f )
		//{
		//	timeOfSep[i] = (lhsMax[i] - rhsMin[i]) / v[i]; 
		//}
	}

	// Possible first time of overlap
	normTimeOfOverlap = Max( timeOfOverlap.X(), Max(timeOfOverlap.Y(), timeOfOverlap.Z()) );

	// Possible last time of separation
	float sepTime = Min( timeOfSep.X(), Min(timeOfSep.Y(), timeOfSep.Z()) );

	// Collision only if time of separation and time of overlap intersect AND
	// if normalized time falls within this frame (between 0 and 1)
	return normTimeOfOverlap <= 1.0f && 
			normTimeOfOverlap >= 0.0f &&
			normTimeOfOverlap <= sepTime;
}


//////////////////////////////////////////////////////////////////////////

bool IsOverlap(const RigidMatrix& lhsT, const Sphere& lhs,
						 const RigidMatrix& rhsT, const Sphere& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(SphereSupportMapper(lhs), lhsT, 
							 SphereSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Cylinder& lhs, 
						 const RigidMatrix& rhsT, const Cylinder& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(CylinderSupportMapper(lhs), lhsT, 
							 CylinderSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Box& lhs, 
						 const RigidMatrix& rhsT, const Box& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(BoxSupportMapper(lhs), lhsT, 
							 BoxSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Sphere& lhs, 
						 const RigidMatrix& rhsT, const Cylinder& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(SphereSupportMapper(lhs), lhsT, 
							 CylinderSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Cylinder& lhs, 
						 const RigidMatrix& rhsT, const Box& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(CylinderSupportMapper(lhs), lhsT, 
							 BoxSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Box& lhs, 
						 const RigidMatrix& rhsT, const Sphere& rhs,
						 Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
						 Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(BoxSupportMapper(lhs), lhsT, 
							 SphereSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Sphere& lhs,
						 const RigidMatrix& rhsT, const Sphere& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<SphereSupportMapper>(SphereSupportMapper(lhs), signedMargin), lhsT, 
							 SphereSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Cylinder& lhs, 
						 const RigidMatrix& rhsT, const Cylinder& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<CylinderSupportMapper>(CylinderSupportMapper(lhs), signedMargin), lhsT, 
							 CylinderSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Box& lhs, 
						 const RigidMatrix& rhsT, const Box& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<BoxSupportMapper>(BoxSupportMapper(lhs), signedMargin), lhsT, 
							 BoxSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Sphere& lhs, 
						 const RigidMatrix& rhsT, const Cylinder& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<SphereSupportMapper>(SphereSupportMapper(lhs), signedMargin), lhsT, 
							 CylinderSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Cylinder& lhs, 
						 const RigidMatrix& rhsT, const Box& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<CylinderSupportMapper>(CylinderSupportMapper(lhs), signedMargin), lhsT, 
							 BoxSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

bool IsOverlap(const RigidMatrix& lhsT, const Box& lhs, 
						 const RigidMatrix& rhsT, const Sphere& rhs,
						 float signedMargin, Vector3& outOverlapPtOnLhs, 
						 Vector3& outOverlapPtOnRhs, Vector3& outNormalOnLhs, Vector3& outNormalOnRhs)
{
	return IsOverlapTemplate(MarginShapeSupportMapper<BoxSupportMapper>(BoxSupportMapper(lhs), signedMargin), lhsT, 
							 SphereSupportMapper(rhs), rhsT, 
							 outOverlapPtOnLhs, outOverlapPtOnRhs,
							 outNormalOnLhs, outNormalOnRhs);
}

//////////////////////////////////////////////////////////////////////////

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Sphere& lhs,
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Sphere& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(SphereSupportMapper(lhs), lhsT0, lhsT1,
								  SphereSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Cylinder& lhs, 
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Cylinder& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(CylinderSupportMapper(lhs), lhsT0, lhsT1,
								  CylinderSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Box& lhs,
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Box& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(BoxSupportMapper(lhs), lhsT0, lhsT1,
								  BoxSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Sphere& lhs,
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Cylinder& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(SphereSupportMapper(lhs), lhsT0, lhsT1,
								  CylinderSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Cylinder& lhs,
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Box& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(CylinderSupportMapper(lhs), lhsT0, lhsT1,
								  BoxSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

bool IsSweptOverlap(const RigidMatrix& lhsT0, const RigidMatrix& lhsT1, const Box& lhs, 
							  const RigidMatrix& rhsT0, const RigidMatrix& rhsT1, const Sphere& rhs,
							  Vector3& outOverlapPtOnLhs, Vector3& outOverlapPtOnRhs,
							  Vector3& outNormalOnLhs, Vector3& outNormalOnRhs,
							  float& normalTimeOfOverlap)
{
	return IsSweptOverlapTemplate(BoxSupportMapper(lhs), lhsT0, lhsT1,
								  SphereSupportMapper(rhs), rhsT0, rhsT1,
								  k_maxNumHalfs, 0.0f, 1.0f,
								  outOverlapPtOnLhs, outOverlapPtOnRhs,
								  outNormalOnLhs, outNormalOnRhs, normalTimeOfOverlap);
}

} // end namespace Shape

} // end namespace SharedSoccer

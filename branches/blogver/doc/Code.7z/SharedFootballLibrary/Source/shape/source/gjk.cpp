//////////////////////////////////////////////////////////////////////////
//
//  gjk   version:  1.0    date: 01/05/2007
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/gjk.h"
#include "math/conversion.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{
	const float Gjk::sk_closestVxMagnitudeSqEpsilon = 0.0001f;

	// Utility methods for ReduceSimplex4
	inline void KeepFace1Only(Gjk::MinkowskiDiffSimplex& simplex)
	{
		simplex.EraseVx(2);
	}
	inline void KeepFace2Only(Gjk::MinkowskiDiffSimplex& simplex)
	{
		simplex.EraseVx(0);
	}
	inline void KeepFace3Only(Gjk::MinkowskiDiffSimplex& simplex)
	{
		simplex.EraseVx(1);
	}

	inline float SelectLeftRightFaceOrEdge(const Vector3& frustumToOriginDir, const Vector3& leftFaceDir,
										   const Vector3& edgeDir, const Vector3& rightFaceDir,
										   float leftCaseResult, float edgeCaseResult, float rightCaseResult)
	{
		Vector3 leftHalfSpaceDir = leftFaceDir.DeprecatedCrossLeftHanded(-edgeDir);
		Vector3 rightHalfSpaceDir = rightFaceDir.DeprecatedCrossLeftHanded(edgeDir);

		float leftTest = leftHalfSpaceDir.Dot(frustumToOriginDir);
		float rightTest = rightHalfSpaceDir.Dot(frustumToOriginDir);

		return FSel(leftTest, FSel(rightTest, edgeCaseResult, rightCaseResult), leftCaseResult);
	}

	inline Vector3 ComputePtFromBarycentricCoords(const Vector3& barycentricCoords, const Gjk::MinkowskiDiffSimplex::VecArray& simplex)
	{
		AP_ASSERT(simplex.Size() == 3);
		Vector3 intersectionPt = simplex[0] + barycentricCoords.X() * (simplex[1] - simplex[0]);
		return (intersectionPt + (barycentricCoords.Z() * (simplex[2] - intersectionPt)));
	}

	inline float SelectMinComponent(const Vector3& v)
	{
		return FSel(v.Y() - v.X(), FSel(v.Z() - v.X(), 1.0f, 0.0f), 0.0f);
	}


//////////////////////////////////////////////////////////////////////////
// Support mappers

SphereSupportMapper::SphereSupportMapper(const Sphere& sphere) :
	m_sphere(sphere)
{
	AP_ASSERT(m_sphere.m_radius > EPSILON);
}

Vector3 SphereSupportMapper::GetSupportVertex(const Vector3& dir) const
{
	float dirMag = dir.Magnitude();
	float dirMagToRadiusScale = FSel(Fabs(dirMag) - EPSILON, m_sphere.m_radius / dirMag, 0.0f);
	return dirMagToRadiusScale * dir;
}

Vector3 SphereSupportMapper::GetNormalOnSurface(const Vector3& dir) const
{
	float dirMag = dir.Magnitude();
	float dirMagTest = dirMag - EPSILON;
	Vector3 normal =  dir * FSel(dirMagTest, 1.0f / dirMag, FLOAT_MAX);
	normal.X(FSel(dirMagTest, normal.X(), 0.0f));
	normal.Y(FSel(dirMagTest, normal.Y(), 0.0f));
	normal.Z(FSel(dirMagTest, normal.Z(), 1.0f));
	AP_ASSERT(Equal(normal.Magnitude(), 1.0f));
	return normal;
}

//////////////////////////////////////////////////////////////////////////

CylinderSupportMapper::CylinderSupportMapper(const Cylinder& cylinder) :
	m_cylinder(cylinder)
{
	AP_ASSERT(m_cylinder.m_radius > EPSILON);
	AP_ASSERT(m_cylinder.m_halfHeight > EPSILON);
}

Vector3 CylinderSupportMapper::GetSupportVertex(const Vector3& dir) const
{
	float magnitudeXY = SquareRoot(Square(dir.X()) + Square(dir.Y()));
	float zeroTest = magnitudeXY - EPSILON;
	Vector3 vertex(FSel(zeroTest, m_cylinder.m_radius * dir.X() / magnitudeXY, 0.0f),
				   FSel(zeroTest, m_cylinder.m_radius * dir.Y() / magnitudeXY, 0.0f),
				   FSel(dir.Z(), m_cylinder.m_halfHeight, -m_cylinder.m_halfHeight));
	return vertex;
}

Vector3 CylinderSupportMapper::GetNormalOnSurface(const Vector3& dir) const
{
	float dir2dMag = Axiom::Math::Vector2FromVector3XY(dir).Magnitude();
	float dir2dMagZeroTest = dir2dMag - EPSILON;
	float sigma = FSel(dir.Z(), 1.0f, -1.0f);

	Vector3 diagonalVec(FSel(dir2dMagZeroTest, m_cylinder.m_radius * dir.X() / dir2dMag, m_cylinder.m_radius), 
						FSel(dir2dMagZeroTest, m_cylinder.m_radius * dir.Y() / dir2dMag, 0.0f), 
						sigma * m_cylinder.m_halfHeight);
	AP_ASSERT(Vector2FromVector3XY(diagonalVec).SquareMagnitude() >= 2.0f*EPSILON);

	Vector3 perpToDiag(-diagonalVec.Y(), diagonalVec.X(), 0.0f);

	float aboveOrBelowDiagonalTest = sigma * dir.DeprecatedCrossLeftHanded(diagonalVec).Dot(perpToDiag);

	Vector3 normal(FSel(aboveOrBelowDiagonalTest, 0.0f, diagonalVec.X() / m_cylinder.m_radius),
				   FSel(aboveOrBelowDiagonalTest, 0.0f, diagonalVec.Y() / m_cylinder.m_radius),
				   FSel(aboveOrBelowDiagonalTest, sigma, 0.0f));
	AP_ASSERT(Equal(normal.Magnitude(), 1.0f));
	return normal;
}

//////////////////////////////////////////////////////////////////////////

BoxSupportMapper::BoxSupportMapper(const Box& box) :
	m_box(box)
{
	AP_ASSERT(m_box.m_halfExtents.X() > 0);
	AP_ASSERT(m_box.m_halfExtents.Y() > 0);
	AP_ASSERT(m_box.m_halfExtents.Z() > 0);
}

Vector3 BoxSupportMapper::GetSupportVertex(const Vector3& dir) const
{
	return Vector3(FSel(dir.X(), m_box.m_halfExtents.X(), -m_box.m_halfExtents.X()),
					FSel(dir.Y(), m_box.m_halfExtents.Y(), -m_box.m_halfExtents.Y()),
					FSel(dir.Z(), m_box.m_halfExtents.Z(), -m_box.m_halfExtents.Z()));
}

Vector3 BoxSupportMapper::GetNormalOnSurface(const Vector3& dir) const
{
	Vector3 sigma(FSel(dir.X(), 1.0f, -1.0f), FSel(dir.Y(), 1.0f, -1.0f), FSel(dir.Z(), 1.0f, -1.0f));
	Vector3 absoluteValueDir = sigma * dir;
	Vector3 reciprocalAbsDir(FSel(absoluteValueDir.X() - EPSILON, 1.0f/absoluteValueDir.X(), FLOAT_MAX),
							 FSel(absoluteValueDir.Y() - EPSILON, 1.0f/absoluteValueDir.Y(), FLOAT_MAX),
							 FSel(absoluteValueDir.Z() - EPSILON, 1.0f/absoluteValueDir.Z(), FLOAT_MAX));

	Vector3 intercepts = m_box.m_halfExtents * reciprocalAbsDir;

	Vector3 result(Vector3::ZERO);
	result.X(SelectMinComponent(intercepts));
	result.Y(FMax(SelectMinComponent(Vector3SwizzleYXZ(intercepts)) - result.X(), 0.0f));
	result.Z(FMax(SelectMinComponent(Vector3SwizzleZXY(intercepts)) - result.X() - result.Y(), 0.0f));
	AP_ASSERT(Equal(result.Magnitude(), 1.0f));
	return sigma * result;
}


//////////////////////////////////////////////////////////////////////////
// CompoundSimplex

void Gjk::MinkowskiDiffSimplex::ComputeClosestPts(const Vector3& closestPtConfigSpace,
												  Vector3& outClosestPtOnA, Vector3& outClosestPtOnB) const
{
	// TODO: compute outNormal

	switch(Size())
	{
		case 1:
			outClosestPtOnA = m_vecArrayShapeA.Front();
			outClosestPtOnB = m_vecArrayShapeB.Front();
			break;
	
		case 2:
			{
				Vector3 dirComp = m_vecArrayConfigSpace[1] - m_vecArrayConfigSpace[0];
				float sqrDistFromStartToEnd = (m_vecArrayConfigSpace[1] - m_vecArrayConfigSpace[0]).SquareMagnitude();
				float sqrDistFromStartToClosest = (closestPtConfigSpace - m_vecArrayConfigSpace[0]).SquareMagnitude();
				float t = FSel(sqrDistFromStartToEnd - EPSILON, SquareRoot(sqrDistFromStartToClosest / sqrDistFromStartToEnd), 0.0f);
				outClosestPtOnA = (t * (m_vecArrayShapeA[1] - m_vecArrayShapeA[0])) + m_vecArrayShapeA[0];
				outClosestPtOnB = (t * (m_vecArrayShapeB[1] - m_vecArrayShapeB[0])) + m_vecArrayShapeB[0];
			}
			break;
	
		case 3:
			{
				// compute barycentric coordinates for closest pt (so that we can map it to simplexes on shapes)

				// start by computing line intersection of segment(last vx, closest pt) with segment(first vx, middle vx)
				Vector3 a = m_vecArrayConfigSpace[1] - m_vecArrayConfigSpace[0];
				Vector3 b = closestPtConfigSpace - m_vecArrayConfigSpace[2];
				Vector3 c = m_vecArrayConfigSpace[2] - m_vecArrayConfigSpace[0];
				Vector3 vecACrossB = a.DeprecatedCrossLeftHanded(b);
				float sqMagACrossB = vecACrossB.SquareMagnitude();
				float s = FSel(sqMagACrossB - 2.0f*EPSILON, ((c.DeprecatedCrossLeftHanded(b)).Dot(vecACrossB)) / (vecACrossB.SquareMagnitude()), 0.0f);
				Vector3 intersectionPtConfigSpace = (a * s) + m_vecArrayConfigSpace[0];

				// then compute coordinates by using the intersection pt computed above
				Vector3 barycentricCoords;
				{
					barycentricCoords.X(s);
					barycentricCoords.Y(1.0f - s);
					float numerator = (closestPtConfigSpace - intersectionPtConfigSpace).SquareMagnitude();
					float denominator = (m_vecArrayConfigSpace[2] - intersectionPtConfigSpace).SquareMagnitude();
					barycentricCoords.Z(FSel(denominator - EPSILON, SquareRoot(numerator / denominator), 1.0f));
				}
				outClosestPtOnA = ComputePtFromBarycentricCoords(barycentricCoords, m_vecArrayShapeA);
				outClosestPtOnB = ComputePtFromBarycentricCoords(barycentricCoords, m_vecArrayShapeB);
			}
			break;
	
		case 4:
		case 0:
		default:
			AP_ASSERTFAIL("Gjk::CompoundSimplex::ComputeClosestPts -- simplex has an invalid size (min: pt, max: triangle)");
			break;
	}
}


//////////////////////////////////////////////////////////////////////////
// gjk

Gjk::Gjk() :
	m_simplex(),
	m_loopCounter(0)
{

}

// Point
void Gjk::ReduceSimplex1(Vector3& outClosestVx)
{
	outClosestVx = m_simplex.GetConfigSpaceVx(0);
}

// Line
void Gjk::ReduceSimplex2(Vector3& outClosestVx)
{
	AP_ASSERT(m_simplex.Size() == 2);

	Vector3 segStartPt = m_simplex.GetConfigSpaceVx(0);
	Vector3 segDir = m_simplex.GetConfigSpaceVx(1) - segStartPt;

	// Consider segment as an infinite line and see where is the closest pt on it to the origin
	float t = ClosestPtOnInfiniteLineToOrigin(segStartPt, segDir);

	// Update simplex based on 't'

	// Casey Muratori observed that since last vx pushed onto the simplex is in the
	// direction of search, we do not need to look in the opposite direction! In our
	// case the last pt added is 'm_curSimplex.Back()' or m_simplex.GetCompoundVx(1)
	// (we use approximate relative error in the assert below)
	// TODO: uncomment this assert!
	// AP_ASSERTMESSAGE(t >= -((segDir.SquareMagnitude() + segStartPt.SquareMagnitude())*EPSILON), "Optimization: not considering case where closest pt is behind the first pt!");
	if(t >= (1.0f - EPSILON))
	{
		// we get rid of the close extremity
		m_simplex.EraseVx(0);
		return ReduceSimplex1(outClosestVx);
	}

	// keep segment as is
	outClosestVx = segStartPt + (t * segDir);
}

// Triangle
void Gjk::ReduceSimplex3(Vector3& outClosestVx)
{
	AP_ASSERT(m_simplex.Size() == 3);

	// compute direction of triangle's plane (like a normal but without constraint on magnitude)
	Vector3 newestToOrigin = -m_simplex.GetConfigSpaceVx(2);
	Vector3 oldestVxToNewestVx = m_simplex.GetConfigSpaceVx(2) - m_simplex.GetConfigSpaceVx(0);
	Vector3 newestVxToMiddleVx = m_simplex.GetConfigSpaceVx(1) - m_simplex.GetConfigSpaceVx(2);
	Vector3 planeDir = oldestVxToNewestVx.DeprecatedCrossLeftHanded(-newestVxToMiddleVx);

	// We consider two cases (Casey Muratori optimization, see: ReduceSimplex2)
	Vector3 outwardDirCase1 = planeDir.DeprecatedCrossLeftHanded(oldestVxToNewestVx);
	Vector3 outwardDirCase2 = planeDir.DeprecatedCrossLeftHanded(newestVxToMiddleVx);
	float outwardTest1 = outwardDirCase1.Dot(newestToOrigin);
	float outwardTest2 = outwardDirCase2.Dot(newestToOrigin);

	static const int sk_caseAboveOrBelowTriangle = 0;
	static const int sk_caseEdge2Closest = 1;
	static const int sk_caseEdge1Closest = 2;
	static const int sk_caseKeepOnlyFrustumVx = 3;

	int caseTest = static_cast<int>(FSel(outwardTest1, 
										 FSel(outwardTest2, (float)sk_caseKeepOnlyFrustumVx, (float)sk_caseEdge1Closest),
										 FSel(outwardTest2, (float)sk_caseEdge2Closest, (float)sk_caseAboveOrBelowTriangle)));
	switch(caseTest)
	{
	case 0:
		{
			// origin is within the infinite plane borders defined by the tri's edges and the plane normal

			// return closest pt on plane to origin
			planeDir.Normalize();
			float d = -(planeDir.Dot(-newestToOrigin)); // ax + bx + cx + d = 0 --> d = negative distance from origin to plane
			outClosestVx = -d * planeDir;
		}
		break;

	case 1:
		// remove oldest (1st) vx
		m_simplex.EraseVx(0);
		ReduceSimplex2(outClosestVx);
		break;

	case 2:
		// remove middle (2nd) vx
		m_simplex.EraseVx(1);
		ReduceSimplex2(outClosestVx);
		break;

	case 3:
		// closest pt is the new vx
		m_simplex.EraseVx(1);
		m_simplex.EraseVx(0);
		ReduceSimplex1(outClosestVx);
		break;

	default:
		AP_ASSERTFAIL("unsupported case!");
		// keep only newest vx
		m_simplex.EraseVx(1);
		m_simplex.EraseVx(0);
		ReduceSimplex1(outClosestVx);
		break;
	}
}

// Tetrahedron (return whether tetrahedron contains origin)
bool Gjk::ReduceSimplex4(Vector3& outClosestVx)
{
	AP_ASSERT(m_simplex.Size() == 4);

	Vector3 lastVxToOrigin = -m_simplex.GetConfigSpaceVx(3);
	bool doesContainOrigin = false;

	// base plane direction (normal, but without magnitude constraint)
	Vector3 baseEdge1 = m_simplex.GetConfigSpaceVx(1) - m_simplex.GetConfigSpaceVx(0);
	Vector3 baseEdge2 = m_simplex.GetConfigSpaceVx(2) - m_simplex.GetConfigSpaceVx(1);
	Vector3 baseEdge3 = m_simplex.GetConfigSpaceVx(0) - m_simplex.GetConfigSpaceVx(2);
	Vector3 basePlaneDir = baseEdge1.DeprecatedCrossLeftHanded(-baseEdge3);

	// compose a 'sign' parameter depending on clockwise or counter clockwise point arrangement
	float sigma = basePlaneDir.Dot(m_simplex.GetConfigSpaceVx(3) - m_simplex.GetConfigSpaceVx(0));
	sigma = FSel(sigma, 1.0f, -1.0f);

	// 3 edge directions to construct (all combinations involving newest vx and a direction to all other vx)
	Vector3 edgeDir1 = m_simplex.GetConfigSpaceVx(0) - m_simplex.GetConfigSpaceVx(3);
	Vector3 edgeDir2 = m_simplex.GetConfigSpaceVx(1) - m_simplex.GetConfigSpaceVx(3);
	Vector3 edgeDir3 = m_simplex.GetConfigSpaceVx(2) - m_simplex.GetConfigSpaceVx(3);

	// 3 face normals to construct (all combinations previous edges)
	Vector3 faceDir1 = edgeDir1.DeprecatedCrossLeftHanded(sigma * edgeDir2);
	Vector3 faceDir2 = edgeDir2.DeprecatedCrossLeftHanded(sigma * edgeDir3);
	Vector3 faceDir3 = edgeDir3.DeprecatedCrossLeftHanded(sigma * edgeDir1);

	// test whether the origin is 'inwards' or 'outwards' from the face
	float outwardTest1 = faceDir1.Dot(lastVxToOrigin);
	float outwardTest2 = faceDir2.Dot(lastVxToOrigin);
	float outwardTest3 = faceDir3.Dot(lastVxToOrigin);

	static const int sk_caseOriginEnclosed = 0;
	static const int sk_caseFace3Closest = 1;
	static const int sk_caseFace2Closest = 2;
	static const int sk_caseEdge3Closest = 3;
	static const int sk_caseFace1Closest = 4;
	static const int sk_caseEdge1Closest = 5;
	static const int sk_caseEdge2Closest = 6;
	static const int sk_caseNewestVxClosest = 7;

	int caseTest = static_cast<int>(FSel(outwardTest1,
									 FSel(outwardTest2,
										  FSel(outwardTest3, 
												(float)sk_caseNewestVxClosest,
												SelectLeftRightFaceOrEdge(lastVxToOrigin, faceDir1, (-sigma) * edgeDir2, faceDir2, (float)sk_caseFace1Closest, (float)sk_caseEdge2Closest, (float)sk_caseFace2Closest)), 
										  FSel(outwardTest3,
												SelectLeftRightFaceOrEdge(lastVxToOrigin, faceDir1, (-sigma) * edgeDir1, faceDir3, (float)sk_caseFace1Closest, (float)sk_caseEdge1Closest, (float)sk_caseFace3Closest),
												(float)sk_caseFace1Closest)),
									 FSel(outwardTest2, 
										  FSel(outwardTest3, 
												SelectLeftRightFaceOrEdge(lastVxToOrigin, faceDir2, (-sigma) * edgeDir3, faceDir3, (float)sk_caseFace2Closest, (float)sk_caseEdge3Closest, (float)sk_caseFace3Closest),
												(float)sk_caseFace2Closest), 
										  FSel(outwardTest3, 
												(float)sk_caseFace3Closest,
												(float)sk_caseOriginEnclosed))));

	switch(caseTest)
	{
	case sk_caseOriginEnclosed:
		{
			// tetrahedron encloses origin! we have collision
			doesContainOrigin = true;

			// test to see if projection of origin onto face's plane is actually contained within the face
			// (only need to test base edges)
			float insideFace1 = (basePlaneDir.DeprecatedCrossLeftHanded(baseEdge1)).Dot(lastVxToOrigin);
			float insideFace2 = (basePlaneDir.DeprecatedCrossLeftHanded(baseEdge2)).Dot(lastVxToOrigin);
			float insideFace3 = (basePlaneDir.DeprecatedCrossLeftHanded(baseEdge3)).Dot(lastVxToOrigin);

			// get scale-less distance to each plane if origin is within face's borders
			float d1 = FSel(-insideFace1, -outwardTest1 / faceDir1.Magnitude(), FLOAT_MAX);
			float d2 = FSel(-insideFace2, -outwardTest2 / faceDir2.Magnitude(), FLOAT_MAX);
			float d3 = FSel(-insideFace3, -outwardTest3 / faceDir3.Magnitude(), FLOAT_MAX);

			// select smallest distance
			if(d1 < d2)
			{
				if(d1 < d3)
				{
					// face 1 is the closest, remove the others
					KeepFace1Only(m_simplex);
				}
				else
				{
					// face 3 is the closest, remove the others
					KeepFace3Only(m_simplex);
				}
			}
			else
			{
				if(d2 < d3)
				{
					// face 2 is the closest, remove the others
					KeepFace2Only(m_simplex);
				}
				else
				{
					// face 3 is the closest, remove the others
					KeepFace3Only(m_simplex);
				}
			}
		}
		break;

	case sk_caseFace3Closest:
		KeepFace3Only(m_simplex);
		break;

	case sk_caseFace2Closest:
		KeepFace2Only(m_simplex);
		break;

	case sk_caseEdge3Closest:
		// keep edge 3 only
		m_simplex.EraseVx(1);
		m_simplex.EraseVx(0);
		break;

	case sk_caseFace1Closest:
		KeepFace1Only(m_simplex);
		break;

	case sk_caseEdge1Closest:
		// keep edge 1 only
		m_simplex.EraseVx(2);
		m_simplex.EraseVx(1);

		/*
		m_curSimplex[1] = m_curSimplex.PopBack();
		m_curSimplex.PopBack();
		*/
		break;

	case sk_caseEdge2Closest:
		// keep edge 2 only
		m_simplex.EraseVx(0);
		m_simplex.EraseVx(1);
		break;

	case sk_caseNewestVxClosest:
		// keep only newest vx!
		m_simplex.EraseVx(2);
		m_simplex.EraseVx(1);
		m_simplex.EraseVx(0);
		break;

	default:
		AP_ASSERTFAIL("unhandled case");
		m_simplex.EraseVx(0);
		return false;
		break;
	}

	AP_ASSERTMESSAGE(m_simplex.Size() < 4, "reduce simplex 4 MUST reduce the simplex before recursing further!"); 
	return doesContainOrigin || ReduceSimplex(outClosestVx); // recursion!
}

} // end namespace Shape

} // end namespace SharedSoccer

//////////////////////////////////////////////////////////////////////////
//
//  aabb   version:  1.0    date: 11/24/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/aabb.h"

#include "core/utils.h"

using namespace Axiom::Math;

//////////////////////////////////////////////////////////////////////////
// Aabb

namespace SharedSoccer
{
namespace Shape
{

Aabb::Aabb()
{
	// non initializing ctor!
}

Aabb::Aabb(const Vector3& center, const Vector3& halfExtents) :
	m_center(center),
	m_halfExtents(halfExtents)
{
    AP_DATAVALIDATION_SUPPORT( TestInvariant() );
	
}

#if CORE_DATAVALIDATION
void Aabb::TestInvariant() const
{
	AP_SIMPLEASSERTMESSAGE( FSel( m_halfExtents.X(), FSel( m_halfExtents.Y(), FSel( m_halfExtents.Z(), 1.0f, -1.0f ), -1.0f ), -1.0f ) > 0.0f, "");

	//AP_ASSERTMESSAGE( m_halfExtents.X() >= 0.0f );
    //AP_ASSERTMESSAGE( m_halfExtents.Y() >= 0.0f );
    //AP_ASSERTMESSAGE( m_halfExtents.Z() >= 0.0f );
}
#endif

Aabb Aabb::GetInvalid()
{
	Aabb retVal;
	retVal.m_center = Vector3(0, 0, 0);
	retVal.m_halfExtents = Vector3(-Axiom::Math::FLOAT_MAX, -Axiom::Math::FLOAT_MAX, -Axiom::Math::FLOAT_MAX);
	return retVal;
}

Vector3 Aabb::GetMin() const
{
	return m_center - m_halfExtents;
}

Vector3 Aabb::GetMax() const
{
	return m_center + m_halfExtents;
}

bool Aabb::Contains( const Vector3& point ) const
{
    AP_DATAVALIDATION_SUPPORT( TestInvariant() );
    
    const Vector3 toPointFromCentre = point - m_center;
    
    return Fabs( toPointFromCentre.X() ) <= m_halfExtents.X()
           && Fabs( toPointFromCentre.Y() ) <= m_halfExtents.Y()
           && Fabs( toPointFromCentre.Z() ) <= m_halfExtents.Z();
}

int inline GetIntersection( float fDst1, float fDst2, Vector3 P1, Vector3 P2, Vector3* pHit ) {
    if ( (fDst1 * fDst2) >= 0.0f) return 0;
    if ( fDst1 == fDst2) return 0; 
    *pHit = ( P1 + (P2-P1) * ( -fDst1/(fDst2-fDst1) ) );
    return 1;
}

int inline InBox( Vector3* pHit, Vector3 B1, Vector3 B2, const int axis) {
    if ( axis==1 && pHit->Z() > B1.Z() && pHit->Z() < B2.Z() && pHit->Y() > B1.Y() && pHit->Y() < B2.Y()) return 1;
    if ( axis==2 && pHit->Z() > B1.Z() && pHit->Z() < B2.Z() && pHit->X() > B1.X() && pHit->X() < B2.X()) return 1;
    if ( axis==3 && pHit->X() > B1.X() && pHit->X() < B2.X() && pHit->Y() > B1.Y() && pHit->Y() < B2.Y()) return 1;
    return 0;
}

// virtual
bool Aabb::Intersects( const Line3& line, Vector3* pHit ) const
{
    const Vector3 b1 = GetMin();
    const Vector3 b2 = GetMax();
    const Vector3 l1 = line.ValueA();
    const Vector3 l2 = line.ValueB();
    
    if (l2.X() < b1.X() && l1.X() < b1.X()) return false;
    if (l2.X() > b2.X() && l1.X() > b2.X()) return false;
    if (l2.Y() < b1.Y() && l1.Y() < b1.Y()) return false;
    if (l2.Y() > b2.Y() && l1.Y() > b2.Y()) return false;
    if (l2.Z() < b1.Z() && l1.Z() < b1.Z()) return false;
    if (l2.Z() > b2.Z() && l1.Z() > b2.Z()) return false;
    if (l1.X() > b1.X() && l1.X() < b2.X() &&
        l1.Y() > b1.Y() && l1.Y() < b2.Y() &&
        l1.Z() > b1.Z() && l1.Z() < b2.Z()) 
    {
        *pHit = l1; 
        return true;
    }
    
    return( ( GetIntersection( l1.X()-b1.X(), l2.X()-b1.X(), l1, l2, pHit) && InBox( pHit, b1, b2, 1 ))
              || ( GetIntersection( l1.Y()-b1.Y(), l2.Y()-b1.Y(), l1, l2, pHit ) && InBox( pHit, b1, b2, 2 )) 
              || ( GetIntersection( l1.Z()-b1.Z(), l2.Z()-b1.Z(), l1, l2, pHit ) && InBox( pHit, b1, b2, 3 )) 
              || ( GetIntersection( l1.X()-b2.X(), l2.X()-b2.X(), l1, l2, pHit ) && InBox( pHit, b1, b2, 1 )) 
              || ( GetIntersection( l1.Y()-b2.Y(), l2.Y()-b2.Y(), l1, l2, pHit ) && InBox( pHit, b1, b2, 2 )) 
              || ( GetIntersection( l1.Z()-b2.Z(), l2.Z()-b2.Z(), l1, l2, pHit ) && InBox( pHit, b1, b2, 3 )));
}

void Aabb::ExtendBy(const Aabb& extender)
{
	Vector3 minExtender = extender.GetMin();
	Vector3 maxExtender = extender.GetMax();

	Vector3 minExtendee = GetMin();
	Vector3 maxExtendee = GetMax();

	Vector3 newMin, newMax;

	newMin.X(Min(minExtender.X(), minExtendee.X()));
	newMin.Y(Min(minExtender.Y(), minExtendee.Y()));
	newMin.Z(Min(minExtender.Z(), minExtendee.Z()));
	newMax.X(Max(maxExtender.X(), maxExtendee.X()));
	newMax.Y(Max(maxExtender.Y(), maxExtendee.Y()));
	newMax.Z(Max(maxExtender.Z(), maxExtendee.Z()));

	m_center = ComputeCenter(newMin, newMax);
	m_halfExtents = ComputeHalfExtents(newMin, newMax);
	
	
}

void Aabb::ExtendBy(const SweptAabb& extender)
{
	ExtendBy(Aabb(extender.m_centerTime0, extender.m_halfExtents));
	ExtendBy(Aabb(extender.m_centerTime1, extender.m_halfExtents));
}

void Aabb::AdjustYWidth( float change )
{
    float newY = m_halfExtents.Y() + change;
    m_halfExtents.Y( Axiom::Math::Max( newY, 0.0f ) );
}

void Aabb::AdjustHeight( float change )
{
    m_halfExtents.Z( m_halfExtents.Z() + change );
    m_center.Z( m_center.Z() + ( change / 2.0f ) );
}

void Aabb::InitFromMinMax( const Vector3& min, const Vector3& max )
{
    this->operator = ( CreateUsingMinMax( min, max ) );
}

// static 
Aabb Aabb::CreateUsingMinMax( const Vector3& min, const Vector3& max )
{
    return Aabb( ComputeCenter( min, max ), ComputeHalfExtents(min, max) );
}

// static
Vector3 Aabb::ComputeCenter(const Vector3& min, const Vector3& max)
{
	return ( 0.5f * (max + min) );
}

// static
Vector3 Aabb::ComputeHalfExtents(const Vector3& min, const Vector3& max)
{
	AP_ASSERTMESSAGE(max.X() >= min.X(), "invalid min & max parameters passed in");
	AP_ASSERTMESSAGE(max.Y() >= min.Y(), "invalid min & max parameters passed in");
	AP_ASSERTMESSAGE(max.Z() >= min.Z(), "invalid min & max parameters passed in");
	return ( 0.5f * (max - min) );
}

//////////////////////////////////////////////////////////////////////////
// SweptAabb

SweptAabb::SweptAabb()
{
	// non initializing ctor!
}

SweptAabb::SweptAabb(const Aabb& staticAabb) :
	m_centerTime0(staticAabb.m_center),
	m_centerTime1(staticAabb.m_center),
	m_halfExtents(staticAabb.m_halfExtents)
{
}

SweptAabb::SweptAabb(const Vector3& center_t0, const Vector3& center_t1, 
					 const Vector3& halfExtents) :
	m_centerTime0(center_t0),
	m_centerTime1(center_t1),
	m_halfExtents(halfExtents)
{
	AP_ASSERTMESSAGE( FSel( halfExtents.X(), FSel( halfExtents.Y(), FSel( halfExtents.Z(), 1.0f, -1.0f ), -1.0f ), -1.0f ) > 0.0f, "invalid half extent parameter passed in" );

	//AP_ASSERTMESSAGE(halfExtents.X() >= 0.0f, "invalid half extent parameter passed in");
	//AP_ASSERTMESSAGE(halfExtents.Y() >= 0.0f, "invalid half extent parameter passed in");
	//AP_ASSERTMESSAGE(halfExtents.Z() >= 0.0f, "invalid half extent parameter passed in");
}


SweptAabb SweptAabb::GetInvalid()
{
	SweptAabb retVal;
	retVal.m_centerTime0 = Vector3(0, 0, 0);
	retVal.m_centerTime1 = Vector3(0, 0, 0);
	retVal.m_halfExtents = Vector3(-Axiom::Math::FLOAT_MAX, -Axiom::Math::FLOAT_MAX, -Axiom::Math::FLOAT_MAX);
	return retVal;
}

SweptAabb SweptAabb::InitFromMotionAndExtents(const RigidMatrix& transformT0, const RigidMatrix& transformT1, const Vector3& axisAlignedHalfExtents)
{
	// NOTE: Allowing some rotational tunneling...

	// assuming small rotations
	Vector3 rotatedHalfExt0 = axisAlignedHalfExtents * transformT0.mRotation;
	Vector3 rotatedHalfExt1 = axisAlignedHalfExtents * transformT1.mRotation;

	Vector3 augmentedExtents = Vector3(FMax(Fabs(axisAlignedHalfExtents.X()), FMax(Fabs(rotatedHalfExt0.X()), Fabs(rotatedHalfExt1.X()))),
									   FMax(Fabs(axisAlignedHalfExtents.Y()), FMax(Fabs(rotatedHalfExt0.Y()), Fabs(rotatedHalfExt1.Y()))),
									   FMax(Fabs(axisAlignedHalfExtents.Z()), FMax(Fabs(rotatedHalfExt0.Z()), Fabs(rotatedHalfExt1.Z()))));

	return SweptAabb(transformT0.mTranslation, transformT1.mTranslation, augmentedExtents);
}


//////////////////////////////////////////////////////////////////////////
// AABoundingRectangle

AABoundingRectangle::AABoundingRectangle()
{
    // non initializing ctor!
}

AABoundingRectangle::AABoundingRectangle(const Axiom::Math::Vector2& center, const Axiom::Math::Vector2& halfExtents)
: m_center(center)
, m_halfExtents(halfExtents)
{
    AP_DATAVALIDATION_SUPPORT( TestInvariant() );
}

#if CORE_DATAVALIDATION
void AABoundingRectangle::TestInvariant() const
{
    AP_ASSERT( m_halfExtents.X() >= 0.0f );
    AP_ASSERT( m_halfExtents.Y() >= 0.0f );
}
#endif

AABoundingRectangle AABoundingRectangle::GetInvalid()
{
    AABoundingRectangle retVal;
    retVal.m_center = Axiom::Math::Vector2( 0.0f, 0.0f );
    retVal.m_halfExtents = Axiom::Math::Vector2(-Axiom::Math::FLOAT_MAX, -Axiom::Math::FLOAT_MAX);
    return retVal;
}

Axiom::Math::Vector2 AABoundingRectangle::GetMin() const
{
    return m_center - m_halfExtents;
}

Axiom::Math::Vector2 AABoundingRectangle::GetMax() const
{
    return m_center + m_halfExtents;
}

bool AABoundingRectangle::Contains( const Axiom::Math::Vector2& point ) const
{
    AP_DATAVALIDATION_SUPPORT( TestInvariant() );

    const Axiom::Math::Vector2 toPointFromCentre = point - m_center;

    return Fabs( toPointFromCentre.X() ) <= m_halfExtents.X()
        && Fabs( toPointFromCentre.Y() ) <= m_halfExtents.Y();
}

int inline GetIntersection( float fDst1, float fDst2, Axiom::Math::Vector2 P1, Axiom::Math::Vector2 P2, Axiom::Math::Vector2* pHit ) {
    if ( (fDst1 * fDst2) >= 0.0f) return 0;
    if ( fDst1 == fDst2) return 0; 
    *pHit = ( P1 + (P2-P1) * ( -fDst1/(fDst2-fDst1) ) );
    return 1;
}

int inline InBox( Axiom::Math::Vector2* pHit, Axiom::Math::Vector2 B1, Axiom::Math::Vector2 B2) {
    return pHit->X() > B1.X() && pHit->X() < B2.X() && pHit->Y() > B1.Y() && pHit->Y() < B2.Y();
}

// virtual
bool AABoundingRectangle::Intersects( const Line2& line, Axiom::Math::Vector2* pHit ) const
{
    const Axiom::Math::Vector2 b1 = GetMin();
    const Axiom::Math::Vector2 b2 = GetMax();
    const Axiom::Math::Vector2 l1 = line.ValueA();
    const Axiom::Math::Vector2 l2 = line.ValueB();

    if (l2.X() < b1.X() && l1.X() < b1.X()) return false;
    if (l2.X() > b2.X() && l1.X() > b2.X()) return false;
    if (l2.Y() < b1.Y() && l1.Y() < b1.Y()) return false;
    if (l2.Y() > b2.Y() && l1.Y() > b2.Y()) return false;
    if (l1.X() > b1.X() && l1.X() < b2.X() &&
        l1.Y() > b1.Y() && l1.Y() < b2.Y() )
    {
        *pHit = l1; 
        return true;
    }

    // Errrm.....is this correct?
    return InBox( pHit, b1, b2 )
           && ( GetIntersection( l1.X()-b1.X(), l2.X()-b1.X(), l1, l2, pHit)
                || GetIntersection( l1.Y()-b1.Y(), l2.Y()-b1.Y(), l1, l2, pHit)
                || GetIntersection( l1.X()-b2.X(), l2.X()-b2.X(), l1, l2, pHit)
                || GetIntersection( l1.Y()-b2.Y(), l2.Y()-b2.Y(), l1, l2, pHit) );
}

void AABoundingRectangle::ExtendBy(const AABoundingRectangle& extender)
{
    Axiom::Math::Vector2 minExtender = extender.GetMin();
    Axiom::Math::Vector2 maxExtender = extender.GetMax();

    Axiom::Math::Vector2 minExtendee = GetMin();
    Axiom::Math::Vector2 maxExtendee = GetMax();

    Axiom::Math::Vector2 newMin, newMax;

    newMin.X(Min(minExtender.X(), minExtendee.X()));
    newMin.Y(Min(minExtender.Y(), minExtendee.Y()));
    newMax.X(Max(maxExtender.X(), maxExtendee.X()));
    newMax.Y(Max(maxExtender.Y(), maxExtendee.Y()));

    m_center = ComputeCenter(newMin, newMax);
    m_halfExtents = ComputeHalfExtents(newMin, newMax);
}

void AABoundingRectangle::InitFromMinMax( const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max )
{
    this->operator = ( CreateUsingMinMax( min, max ) );
}

// static 
AABoundingRectangle AABoundingRectangle::CreateUsingMinMax( const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max )
{
    return AABoundingRectangle( ComputeCenter( min, max ), ComputeHalfExtents(min, max) );
}

// static
Axiom::Math::Vector2 AABoundingRectangle::ComputeCenter(const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max)
{
    return ( 0.5f * (max + min) );
}

// static
Axiom::Math::Vector2 AABoundingRectangle::ComputeHalfExtents(const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max)
{
    AP_ASSERTMESSAGE(max.X() >= min.X(), "invalid min & max parameters passed in");
    AP_ASSERTMESSAGE(max.Y() >= min.Y(), "invalid min & max parameters passed in");
    return ( 0.5f * (max - min) );
}

} // end namespace Shape

} // end namespace SharedSoccer

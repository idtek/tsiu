// plane.cpp - (c) 2009 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#include "shape/plane.h"

// --------------------------------------------------------------------------------------------------------------------
namespace SharedSoccer
{
namespace Shape
{

// --------------------------------------------------------------------------------------------------------------------
Plane3::Plane3()
:	mNormal(Axiom::Math::Vector3::XAxis())
,	mDistance(0.f) 
{
}

// --------------------------------------------------------------------------------------------------------------------
Plane3::Plane3(const Axiom::Math::Vector3& normal, const Axiom::Math::Vector3& point)
:	mNormal(Axiom::Math::Vector3::XAxis())
,	mDistance(0.f) 
{
	Set(normal, point);
}

// --------------------------------------------------------------------------------------------------------------------
Plane3::Plane3(const Axiom::Math::Vector3& normal, const float distance)
:	mNormal(normal)
,	mDistance(distance) 
{
	AP_SIMPLEASSERTMESSAGE(normal.IsNormal(), "Normal is not of unit length");
}

// --------------------------------------------------------------------------------------------------------------------
Plane3::Plane3(const Axiom::Math::Vector3& normal)
:	mNormal(normal)
,	mDistance(0.f) 
{
	AP_SIMPLEASSERTMESSAGE(normal.IsNormal(), "Normal is not of unit length");
}

// --------------------------------------------------------------------------------------------------------------------
Plane3::Plane3(const float distance)
:	mNormal(Axiom::Math::Vector3::XAxis())
,	mDistance(distance) 
{
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Shape
} // namespace SharedSoccer

// End of file --------------------------------------------------------------------------------------------------------

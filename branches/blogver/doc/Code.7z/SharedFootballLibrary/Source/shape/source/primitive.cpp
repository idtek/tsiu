//////////////////////////////////////////////////////////////////////////
//
//  primitive   version:  1.0    date: 12/06/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/primitive.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{

//////////////////////////////////////////////////////////////////////////
// primitive

Vector3 ClampToAabb(const Aabb& aabb, const Vector3& vecToClamp)
{
	return Vector3(FClamp(vecToClamp.X(), aabb.GetMin().X(), aabb.GetMax().X()),
				   FClamp(vecToClamp.Y(), aabb.GetMin().Y(), aabb.GetMax().Y()),
				   FClamp(vecToClamp.Z(), aabb.GetMin().Z(), aabb.GetMax().Z()));

}

Aabb WrapAabbArround(const Sphere& sphere)
{
	return Aabb(Vector3(0, 0, 0), Vector3(sphere.m_radius, sphere.m_radius, sphere.m_radius));
}

Aabb WrapAabbArround(const Cylinder& cylinder)
{
	return Aabb(Vector3(0, 0, 0), Vector3(cylinder.m_radius, cylinder.m_radius, cylinder.m_halfHeight));
}

Aabb WrapAabbArround(const RigidMatrix& , const Sphere& )
{
	AP_ASSERTMESSAGE(false, "TODO!");
	return Aabb();
}

Aabb WrapAabbArround(const RigidMatrix& , const Cylinder& )
{
	AP_ASSERTMESSAGE(false, "TODO!");
	return Aabb();
}

SweptAabb WrapSweptAabbArround(const RigidMatrix& , const RigidMatrix& , const Sphere& )
{
	AP_ASSERTMESSAGE(false, "TODO!");
	return SweptAabb();
}

SweptAabb WrapSweptAabbArround(const RigidMatrix& , const RigidMatrix& , const Cylinder& )
{
	AP_ASSERTMESSAGE(false, "TODO!");
	return SweptAabb();
}

} // end namespace Shape

} // end namespace SharedSoccer

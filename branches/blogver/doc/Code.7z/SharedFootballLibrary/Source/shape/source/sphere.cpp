//////////////////////////////////////////////////////////////////////////
//
//  sphere   version:  1.0    date: 12/05/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/sphere.h"
#include "math/apmath.h"

//////////////////////////////////////////////////////////////////////////
// sphere

namespace SharedSoccer
{
namespace Shape
{

Sphere::Sphere()
{
	// NON initializing ctor!
}

Sphere::Sphere(float radius) :
	m_radius(radius)
{
	AP_ASSERT(m_radius >= 0.0f);
}

//////////////////////////////////////////////////////////////////////////
//

Sphere Sphere::GetInvalid()
{
	Sphere retVal;
	retVal.m_radius = -Axiom::Math::FLOAT_MAX;
	return retVal;
}

} // end namespace Shape

} // end namespace SharedSoccer

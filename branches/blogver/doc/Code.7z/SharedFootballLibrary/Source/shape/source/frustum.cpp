#ifndef  __CORE_MATRIX4_H
# include "math/matrix4.h"
#endif

#ifndef  __CORE_FRUSTUM_H
# include "shape/frustum.h"
#endif

// Namespace usage
using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{

// Static private data
//Frustum::PLANE_e	Frustum::m_sEvaluationOrder[] = { PLANE_RIGHT, PLANE_LEFT, PLANE_NEAR, PLANE_TOP, PLANE_BOTTOM, PLANE_FAR };
//int					Frustum::m_sNbEvaluations = 6;

// Private methods
void Frustum::InitPlanes(const Matrix44 &m)
{
	const Vector4 c0 = m.GetCol4(0);
	const Vector4 c1 = m.GetCol4(1);
	const Vector4 c2 = m.GetCol4(2);
	const Vector4 c3 = m.GetCol4(3);

	m_aPlanes[PLANE_LEFT].m_Normal   = (c3 + c0);
	m_aPlanes[PLANE_RIGHT].m_Normal  = (c3 - c0);
	m_aPlanes[PLANE_BOTTOM].m_Normal = (c3 + c1);
	m_aPlanes[PLANE_TOP].m_Normal    = (c3 - c1);
	m_aPlanes[PLANE_NEAR].m_Normal   = (c2);
	m_aPlanes[PLANE_FAR].m_Normal    = (c3 - c2);

	for (int iPlanes = 0 ; iPlanes < NBPLANES ; ++iPlanes)
	{
		// Normalize the plane (could be bypassed for optimization)
		Vector3 v( m_aPlanes[iPlanes].m_Normal.X(), m_aPlanes[iPlanes].m_Normal.Y(), m_aPlanes[iPlanes].m_Normal.Z() );
		float fMagnitude = v.Magnitude();
		m_aPlanes[iPlanes].m_Normal /= fMagnitude;

		// Find the right 
		if( v.X() >= 0.0f )
		{
			if( v.Y() >= 0.0f )
			{
				if( v.Z() >= 0.0f )
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_NEAR_BOTTOM_LEFT;
					m_aPlanes[iPlanes].m_PVertex = POINT_FAR_TOP_RIGHT;
				}
				else
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_FAR_BOTTOM_LEFT;
					m_aPlanes[iPlanes].m_PVertex = POINT_NEAR_TOP_RIGHT;
				}
			}
			else
			{
				if( v.Z() >= 0.0f )
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_NEAR_TOP_LEFT;
					m_aPlanes[iPlanes].m_PVertex = POINT_FAR_BOTTOM_RIGHT;
				}
				else
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_FAR_TOP_LEFT;
					m_aPlanes[iPlanes].m_PVertex = POINT_NEAR_BOTTOM_RIGHT;
				}
			}
		}
		else
		{
			if( v.Y() >= 0.0f )
			{
				if( v.Z() >= 0.0f )
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_NEAR_BOTTOM_RIGHT;
					m_aPlanes[iPlanes].m_PVertex = POINT_FAR_TOP_LEFT;
				}
				else
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_FAR_BOTTOM_RIGHT;
					m_aPlanes[iPlanes].m_PVertex = POINT_NEAR_TOP_LEFT;
				}
			}
			else
			{
				if( v.Z() >= 0.0f )
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_NEAR_TOP_RIGHT;
					m_aPlanes[iPlanes].m_PVertex = POINT_FAR_BOTTOM_LEFT;
				}
				else
				{
					m_aPlanes[iPlanes].m_NVertex = POINT_FAR_TOP_RIGHT;
					m_aPlanes[iPlanes].m_PVertex = POINT_NEAR_BOTTOM_LEFT;
				}
			}
		}
	}
}

bool Frustum::FullyOutsidePlane( const Vector4 &vPVertex, const PLANE_e ePlane )
{
	return ( m_aPlanes[ ePlane ].m_Normal.Dot( vPVertex ) < 0.0f );
}

Frustum::REPORT_e Frustum::OutsidePlane( const Vector4 &vNVertex, const Vector4 &vPVertex, const PLANE_e ePlane )
{
	if( m_aPlanes[ ePlane ].m_Normal.Dot( vPVertex ) < 0.0f )
	{
		return REPORT_FULLY_OUTSIDE;
	}

	if( m_aPlanes[ ePlane ].m_Normal.Dot( vNVertex ) > 0.0f )
	{
		return REPORT_INSIDE;
	}

	return REPORT_PARTIALLY_OUTSIDE;
}

// Constructors & destructors
Frustum::FrustumPlane::FrustumPlane(void) :
	m_Normal(),
	m_NVertex(POINT_INVALID),
	m_PVertex(POINT_INVALID)
{
}

Frustum::Frustum(void)
{
}

Frustum::Frustum(const Matrix44 &mViewProjection)
{
	InitPlanes(mViewProjection);
}

Frustum::Frustum(const Matrix4 &mView, const Matrix44 &mProjection)
{
	Matrix44 mViewProjection = static_cast<Axiom::Math::Matrix44>(mView) * mProjection;
	InitPlanes(mViewProjection);
}

Frustum::~Frustum(void)
{
}

float Frustum::GetDistanceFromPlane(PLANE_e ePlane, Vector4 vCenter, float fRadius)
{
	return m_aPlanes[ ePlane ].m_Normal.Dot( vCenter ) - fRadius;
}

float Frustum::GetDistanceFromPlane(PLANE_e ePlane, Vector4 vBoxMin, Vector4 vBoxMax)
{
	Vector4 vCorners[ NBPOINTS ];
	vCorners[ POINT_FAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_NEAR_TOP_RIGHT ].Z( vBoxMin.Z() );
	vCorners[ POINT_NEAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].Y( vBoxMin.Y() );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].X( vBoxMax.X() );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_TOP_LEFT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_LEFT ].X( vBoxMin.X() );
	vCorners[ POINT_FAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_TOP_LEFT ].Y( vBoxMax.Y() );
	vCorners[ POINT_NEAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_FAR_BOTTOM_LEFT ].Z( vBoxMax.Z() );
	vCorners[ POINT_FAR_BOTTOM_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_LEFT ].W( 1.0f );

//	return m_aPlanes[ ePlane ].m_Normal.Dot( vCorners[ m_aPlanes[ePlane].m_NVertex ] );
	return m_aPlanes[ ePlane ].m_Normal.Dot( vCorners[ m_aPlanes[ePlane].m_PVertex ] );
}

bool Frustum::IsFullyIn(Vector4 vCenter, float fRadius)
{
	return ( m_aPlanes[ PLANE_RIGHT ].m_Normal.Dot( vCenter ) > fRadius  &&
			 m_aPlanes[ PLANE_LEFT ].m_Normal.Dot( vCenter ) > fRadius   &&
			 m_aPlanes[ PLANE_NEAR ].m_Normal.Dot( vCenter ) > fRadius   &&
			 m_aPlanes[ PLANE_TOP ].m_Normal.Dot( vCenter ) > fRadius    &&
			 m_aPlanes[ PLANE_BOTTOM ].m_Normal.Dot( vCenter ) > fRadius &&
			 m_aPlanes[ PLANE_FAR ].m_Normal.Dot( vCenter ) > fRadius    );
}

bool Frustum::IsIn(Vector4 vCenter, float fRadius)
{
	return ( m_aPlanes[ PLANE_RIGHT ].m_Normal.Dot( vCenter ) > fRadius  ||
			 m_aPlanes[ PLANE_LEFT ].m_Normal.Dot( vCenter ) > fRadius   ||
			 m_aPlanes[ PLANE_NEAR ].m_Normal.Dot( vCenter ) > fRadius   ||
			 m_aPlanes[ PLANE_TOP ].m_Normal.Dot( vCenter ) > fRadius    ||
			 m_aPlanes[ PLANE_BOTTOM ].m_Normal.Dot( vCenter ) > fRadius ||
			 m_aPlanes[ PLANE_FAR ].m_Normal.Dot( vCenter ) > fRadius    );
}

bool Frustum::IsFullyIn(Vector4 vBoxMin, Vector4 vBoxMax)
{
	Vector4 vCorners[ NBPOINTS ];
	vCorners[ POINT_FAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_NEAR_TOP_RIGHT ].Z( vBoxMin.Z() );
	vCorners[ POINT_NEAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].Y( vBoxMin.Y() );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].X( vBoxMax.X() );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_TOP_LEFT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_LEFT ].X( vBoxMin.X() );
	vCorners[ POINT_FAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_TOP_LEFT ].Y( vBoxMax.Y() );
	vCorners[ POINT_NEAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_FAR_BOTTOM_LEFT ].Z( vBoxMax.Z() );
	vCorners[ POINT_FAR_BOTTOM_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_LEFT ].W( 1.0f );

	return ( OutsidePlane( vCorners[ m_aPlanes[PLANE_RIGHT].m_NVertex ], vCorners[ m_aPlanes[PLANE_RIGHT].m_PVertex ], PLANE_RIGHT ) == REPORT_INSIDE    &&
			 OutsidePlane( vCorners[ m_aPlanes[PLANE_LEFT].m_NVertex ], vCorners[ m_aPlanes[PLANE_LEFT].m_PVertex ], PLANE_LEFT ) == REPORT_INSIDE       &&
			 OutsidePlane( vCorners[ m_aPlanes[PLANE_NEAR].m_NVertex ], vCorners[ m_aPlanes[PLANE_NEAR].m_PVertex ], PLANE_NEAR ) == REPORT_INSIDE       &&
			 OutsidePlane( vCorners[ m_aPlanes[PLANE_TOP].m_NVertex ], vCorners[ m_aPlanes[PLANE_TOP].m_PVertex ], PLANE_TOP ) == REPORT_INSIDE          &&
			 OutsidePlane( vCorners[ m_aPlanes[PLANE_BOTTOM].m_NVertex ], vCorners[ m_aPlanes[PLANE_BOTTOM].m_PVertex ], PLANE_BOTTOM ) == REPORT_INSIDE &&
			 OutsidePlane( vCorners[ m_aPlanes[PLANE_FAR].m_NVertex ], vCorners[ m_aPlanes[PLANE_FAR].m_PVertex ], PLANE_FAR ) == REPORT_INSIDE          );
}

bool Frustum::IsIn(Vector4 vBoxMin, Vector4 vBoxMax)
{
	Vector4 vCorners[ NBPOINTS ];
	vCorners[ POINT_FAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_RIGHT ] = vBoxMax;
	vCorners[ POINT_NEAR_TOP_RIGHT ].Z( vBoxMin.Z() );
	vCorners[ POINT_NEAR_TOP_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ] = vBoxMax;
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].Y( vBoxMin.Y() );
	vCorners[ POINT_FAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].X( vBoxMax.X() );
	vCorners[ POINT_NEAR_BOTTOM_RIGHT ].W( 1.0f );
	vCorners[ POINT_FAR_TOP_LEFT ] = vBoxMax;
	vCorners[ POINT_FAR_TOP_LEFT ].X( vBoxMin.X() );
	vCorners[ POINT_FAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_TOP_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_TOP_LEFT ].Y( vBoxMax.Y() );
	vCorners[ POINT_NEAR_TOP_LEFT ].W( 1.0f );
	vCorners[ POINT_FAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_FAR_BOTTOM_LEFT ].Z( vBoxMax.Z() );
	vCorners[ POINT_FAR_BOTTOM_LEFT ].W( 1.0f );
	vCorners[ POINT_NEAR_BOTTOM_LEFT ] = vBoxMin;
	vCorners[ POINT_NEAR_BOTTOM_LEFT ].W( 1.0f );

	return !( FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_RIGHT].m_PVertex ], PLANE_RIGHT )   &&
			  FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_LEFT].m_PVertex ], PLANE_LEFT )	   &&
			  FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_NEAR].m_PVertex ], PLANE_NEAR )	   &&
			  FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_TOP].m_PVertex ], PLANE_TOP )	   &&
			  FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_BOTTOM].m_PVertex ], PLANE_BOTTOM ) &&
			  FullyOutsidePlane( vCorners[ m_aPlanes[PLANE_FAR].m_PVertex ], PLANE_FAR )       );
}

} // end namespace Shape

} // end namespace SharedSoccer

// class header
#include "shape/line.h"
#include "shape/circle.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{

///////////////////////////////////////////////////////// Line2 /////////////////////////////////////////////////////////

enum ELineTest
{
    ELineTest_ANTICLOCKWISE,
    ELineTest_CLOCKWISE,
    ELineTest_LINE
};

///////////////////////////////////

ELineTest CheckTriClockDir( const Vector2& pt1, const Vector2& pt2, const Vector2& pt3 )
{
    float test = (((pt2.x - pt1.x)*(pt3.y - pt1.y)) - ((pt3.x - pt1.x)*(pt2.y - pt1.y))); 
    if( test > 0.0f )
    {
        return ELineTest_ANTICLOCKWISE;
    }
    else if(test < 0.0f)
    {
        return ELineTest_CLOCKWISE;
    }
    else
    {
        return ELineTest_LINE;
    }
}
    
///////////////////////////////////

bool Line2::Intersects( const Line2& xRef ) const
{
    ELineTest test1_a = CheckTriClockDir(ValueA(), ValueB(), xRef.ValueA());
    ELineTest test1_b = CheckTriClockDir(ValueA(), ValueB(), xRef.ValueB());
    if (test1_a != test1_b)
    {
        ELineTest test2_a = CheckTriClockDir(xRef.ValueA(), xRef.ValueB(), ValueA());
        ELineTest test2_b = CheckTriClockDir(xRef.ValueA(), xRef.ValueB(), ValueB());
        if (test2_a != test2_b)
        {
            return true;
        }
    }
    return false;
}

bool Line2::Intersects( const Line2& xRef, Vector2* pIntersection ) const
{
    float bx = ValueB().X() - ValueA().X();
    float by = ValueB().Y() - ValueA().Y();
    float dx = xRef.ValueB().X() - xRef.ValueA().X();
    float dy = xRef.ValueB().Y() - xRef.ValueA().Y();

    float b_dot_d_perp = bx * dy - by * dx;

    // guard ------------------------------------
    if( b_dot_d_perp == 0 )
    {
        return false;
    }
    // guard ------------------------------------    

    float cx = xRef.ValueA().X() - ValueA().X();
    float cy = xRef.ValueA().Y() - ValueA().Y();

    float t = (cx * dy - cy * dx) / b_dot_d_perp;
    
    // guard ------------------------------------
    if(t < 0 || t > 1)
    {
        return false;
    }
    // guard ------------------------------------ 

    float u = (cx * by - cy * bx) / b_dot_d_perp;
    
    // guard ------------------------------------
    if(u < 0 || u > 1)
    {
        return false;
    }
    // guard ------------------------------------ 

    pIntersection->X( ValueA().X() + ( t * bx ) );
    pIntersection->Y( ValueA().Y() + ( t * by ) );
    
    return true;
}

///////////////////////////////////

float Line2::SquareMagnitude() const
{
    return ToBFromA().SquareMagnitude();
}

bool Line2::PassesWithinDistance( const Vector2& vec, float distance ) const
{
	Circle circle( vec, distance );

	Vector2 dummy1;
	Vector2 dummy2;

	return ( circle.nIntercepts( *this, Circle::ETreatLineAsInfinite_NO, &dummy1, &dummy2) > 0 );
}

} // end namespace Shape

} // end namespace SharedSoccer

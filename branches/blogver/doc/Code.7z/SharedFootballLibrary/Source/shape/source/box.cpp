//////////////////////////////////////////////////////////////////////////
//
//  box   version:  1.0    date: 12/06/2006
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
//  -------------------------------------------------------------
// 
//////////////////////////////////////////////////////////////////////////

#include "shape/box.h"
#include "math/apmath.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{
		AP_TYPE(Box)
					AP_DEFAULT_CREATE()
		AP_TYPE_END()

//////////////////////////////////////////////////////////////////////////
// box

Box::Box()
{
	// NON initializing ctor!
}

Box::Box(const Vector3& halfExtents) :
	m_halfExtents(halfExtents)
{
}

Box::~Box()
{
}

// static
Box Box::GetInvalid()
{
	Box retVal;
	retVal.m_halfExtents = Vector3(-FLOAT_MAX, -FLOAT_MAX, -FLOAT_MAX);
	return retVal;
}

}
}

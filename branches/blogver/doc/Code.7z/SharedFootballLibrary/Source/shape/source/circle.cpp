// class header

#include "shape/circle.h"

// other includes

#include "math/apmath.h"
#include "shape/line.h"

using namespace Axiom::Math;

namespace SharedSoccer
{
namespace Shape
{

int Circle::nIntercepts( const Line2& line, ETreatLineAsInfinite treatLineAsInfiniteEnum, Vector2* pIntercept1, Vector2* pIntercept2 ) const
{
    // NOTE
    // There may well be a FAR more elegant way to do this. In which case, please feel free to
    // change as you see fit. I haven't studied maths since 1991, so go easy on me.
    // CPS
    
    AP_PRECONDITION( line.SquareMagnitude() > 0.0f );
    
    const bool lineIsFinite = ( treatLineAsInfiniteEnum == ETreatLineAsInfinite_NO );
    
    const Vector2 lineEnds[] = { line.ValueA(), line.ValueB() };
    
    const float sqrRadius = Square( m_Radius );
    
    const Vector2 toCentreFromEnd[] = { m_CentrePos - lineEnds[0], m_CentrePos - lineEnds[1] };
    const float toCentreFromEndDistance[] = { toCentreFromEnd[0].Magnitude(), toCentreFromEnd[1].Magnitude() };
    
    // If both points of the line are inside the circle, there can be no interception
    // GUARD ==============================================================
    if( lineIsFinite
        && toCentreFromEndDistance[0] < m_Radius
        && toCentreFromEndDistance[1] < m_Radius )
    {
        return 0;
    }
    // GUARD ==============================================================
    
    int result = 0;

    const Vector2 toBFromA = line.ToBFromA();
    Vector2 orthogonal( toBFromA.Y(), -toBFromA.X() );
    AP_ASSERT( orthogonal.SquareMagnitude() > 0.0f );
    orthogonal.Normalize();
    
    bool lineEnd1IsCentre = ( toCentreFromEndDistance[0] == 0.0f );
    const Vector2& toCentreFromEndNonZero = lineEnd1IsCentre ? toCentreFromEnd[1] : toCentreFromEnd[0];
    AP_ASSERT( toCentreFromEndNonZero.SquareMagnitude() != 0.0f );
    
    const float normalToCentreDistance = toCentreFromEndNonZero.Dot( orthogonal );
    
    // if normalToCentreDistance is greater than the radius, the line is fully outside the circle
    if( Fabs( normalToCentreDistance ) <= m_Radius )
    {
        // otherwise, there is at least one intercept point
        orthogonal *= normalToCentreDistance;
        const Vector2 orthogonalPoint = m_CentrePos - orthogonal;

        const float toCircleFromOP = SquareRoot( sqrRadius - Square( normalToCentreDistance ) );
        const Vector2 toBFromANormal = toBFromA.AsNormal();
        
        if( lineIsFinite )
        {
            Vector2* pIntercept = pIntercept1;
            Vector2 lineEndFromOP[2];
            
            for( int i = 0; i < 2; ++i )
            {
                lineEndFromOP[i] = lineEnds[i] - orthogonalPoint;
                if( lineEndFromOP[i].SquareMagnitude() >= Square( toCircleFromOP ) )
                {
                    ++result;
                    *pIntercept = orthogonalPoint + ( lineEndFromOP[i].AsNormal() * toCircleFromOP );
                    pIntercept = pIntercept2;
                }
            }

            if( result == 2 )
            {
                if( lineEndFromOP[0].Dot( lineEndFromOP[1] ) > 0.0f )
                {
                    // both points are the same side of the normal line. This means there are, in fact, NO intercepts
                    result = 0;
                }
                else if( *pIntercept1 == *pIntercept2 )
                {
                    // no point returning two identical results; treat it as a single intercept
                    result = 1;
                }
            }
        }
        else
        {
            *pIntercept1 = orthogonalPoint + ( toBFromANormal * toCircleFromOP );
            *pIntercept2 = orthogonalPoint - ( toBFromANormal * toCircleFromOP );
            result = 2;
        }
    }
    
    return result;
}

bool Circle::ContainsCompletely( const Circle& otherCircle ) const
{
    bool result = false;
    
    if( Contains( otherCircle.CentrePos() ) )
    {
        const Vector2 lineBetweenCentres = otherCircle.CentrePos() - CentrePos();
        const float D = lineBetweenCentres.Magnitude();
        
        return ( otherCircle.Radius() + D ) < Radius();
    }
    
    return result;
}

int Circle::nIntercepts( const Circle& otherCircle,
                         Vector2* pIntercept1, 
                         Vector2* pIntercept2 ) const
{
    const Vector2 lineBetweenCentres = otherCircle.CentrePos() - CentrePos();
    const float R1 = Radius();
    const float R2 = otherCircle.Radius();
    const float combinedRadii = R1 + R2;
    
    // no intercepts if one circle is completely outside the other
    if( lineBetweenCentres.SquareMagnitude() > Square( combinedRadii ) )
    {
        return 0;
    }
    
    const float D = lineBetweenCentres.Magnitude();
    
    // no intercepts if one circle is completely contained by the other
    if( ContainsCompletely( otherCircle )
        || otherCircle.ContainsCompletely( *this ) )
    {
        return 0;
    }
    
    // okay, if we haven't exited yet, we must have some intercepts
    const float y1 = CentrePos().Y();
    const float y2 = otherCircle.CentrePos().Y();
    const float x1 = CentrePos().X();
    const float x2 = otherCircle.CentrePos().X();
    
    const float A = Axiom::Math::SquareRoot( ( D + R1 + R2 ) * ( D + R1 - R2 ) * ( D - R1 + R2 ) * ( R1 + R2 - D ) ) / 4.0f;
    
    const float DSquared = Axiom::Math::Square( D );
    const float R1Squared = Axiom::Math::Square( R1 );
    const float R2Squared = Axiom::Math::Square( R2 );
    
    const float xBase = ( ( x1 + x2 ) / 2.0f ) - ( ( x1 - x2 ) * ( R1Squared - R2Squared ) / ( 2.0f * DSquared ) );
    const float xShift = 2 * ( y1 - y2 ) * A / DSquared;
    
    const float yBase = ( ( y1 + y2 ) / 2.0f ) - ( ( y1 - y2 ) * ( R1Squared - R2Squared ) / ( 2.0f * DSquared ) );
    const float yShift = 2 * ( x1 - x2 ) * A / DSquared;
    
    pIntercept1->X( xBase + xShift );
    pIntercept1->Y( yBase - yShift );
    
    pIntercept2->X( xBase - xShift );
    pIntercept2->Y( yBase + yShift );
    
    return 2;
}

void Circle::CalculateTangents( const Vector2& pointOutsideCircle, Vector2* pTangent1, Vector2* pTangent2 ) const
{
    AP_PRECONDITION( !Contains( pointOutsideCircle ) );
    
    const Vector2 lineToCentre = CentrePos() - pointOutsideCircle;
    
    float intersectingCircleRadius = Axiom::Math::SquareRoot( lineToCentre.SquareMagnitude() - Axiom::Math::Square( Radius() ) );
    
    AP_ASSERT_SUPPORTASSIGN(int nIntersections, nIntercepts( Circle( pointOutsideCircle, intersectingCircleRadius ), pTangent1, pTangent2 ));
    
    AP_ASSERT( nIntersections == 2 );
}

} // end namespace Shape

} // end namespace SharedSoccer

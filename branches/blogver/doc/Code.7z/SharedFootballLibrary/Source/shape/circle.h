//////////////////////////////////////////////////////////////////////////
// File: sphere.h

#ifndef __CORE_HEADER_CIRCLE_H
#define __CORE_HEADER_CIRCLE_H

#include "math/apmath.h"
#include "math/vector2.h"

namespace SharedSoccer
{
namespace Shape
{

// forward decs
class Line2;

////////////////////////////////////// class Circle ///////////////////////////////////

class Circle
{
public:
	Circle( const Axiom::Math::Vector2& centrePos, float radius );
	
	const Axiom::Math::Vector2&  CentrePos() const;
	const float     Radius() const;
	
	enum ETreatLineAsInfinite
	{
	    ETreatLineAsInfinite_NO,
	    ETreatLineAsInfinite_YES
	};
	
	// AP_PRECONDITION( line.SquareMagnitude() > 0.0f )
	int             nIntercepts( const Line2& line,
	                             ETreatLineAsInfinite,
	                             Axiom::Math::Vector2* pIntercept1, 
	                             Axiom::Math::Vector2* pIntercept2 ) const;
	                             
    bool            Contains( const Axiom::Math::Vector2& ) const;
    
    bool            ContainsCompletely( const Circle& ) const;
    
    int             nIntercepts( const Circle& otherCircle,
                                 Axiom::Math::Vector2* pIntercept1, 
                                 Axiom::Math::Vector2* pIntercept2 ) const;
    
    // AP_PRECONDITION( !Contains( pointOutsideCircle ) )
    void            CalculateTangents( const Axiom::Math::Vector2& pointOutsideCircle, Axiom::Math::Vector2* pTangent1, Axiom::Math::Vector2* pTangent2 ) const;

private:
	Axiom::Math::Vector2 m_CentrePos;
	float   m_Radius;
};


////////////////////////////////////// inlines (Circle) ///////////////////////////////////

inline Circle::Circle( const Axiom::Math::Vector2& centrePos, float radius )
:   m_CentrePos( centrePos ),
    m_Radius( radius )
{
    // Empty method body
}
inline const Axiom::Math::Vector2& Circle::CentrePos() const
{
    return m_CentrePos;
}

inline const float Circle::Radius() const
{
    return m_Radius;
}

inline bool Circle::Contains( const Axiom::Math::Vector2& pos ) const
{
    return ( pos - m_CentrePos ).SquareMagnitude() <= Axiom::Math::Square( m_Radius );
}

} // end namespace Shape

} // end namespace SharedSoccer


#endif // __CORE_HEADER_CIRCLE_H


// plane.h - (c) 2009 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef __CORE_PLANE_H
#define __CORE_PLANE_H

#include "math/vector3.h"

// --------------------------------------------------------------------------------------------------------------------
namespace SharedSoccer
{
namespace Shape
{

// --------------------------------------------------------------------------------------------------------------------
class Plane3
{
public:
							Plane3();
							Plane3(const Axiom::Math::Vector3& normal, const Axiom::Math::Vector3& point);
							Plane3(const Axiom::Math::Vector3& normal, const float distance);
							Plane3(const Axiom::Math::Vector3& normal);
							Plane3(const float distance);

	void					Set(const Axiom::Math::Vector3& normal, const Axiom::Math::Vector3& point);
	void					Set(const Axiom::Math::Vector3& normal, const float distance);
	void					Set(const Axiom::Math::Vector3& normal);
	void					Set(const float distance);

	Axiom::Math::Vector3&	Normal();	
	Axiom::Math::Vector3	Normal() const;	
	Axiom::Math::Vector3	Origin() const;	// Compute the closest point on the plane to the origin
	Axiom::Math::Vector3	ProjectedPoint(const Axiom::Math::Vector3& point) const; // Returns the result of projecting the given point onto the plane
	float					Distance(const Axiom::Math::Vector3& point) const; // How far away is the point from the plane
	const bool				IsBehind(const Axiom::Math::Vector3& point) const; // is the point on the back side of the plane
	const bool				IsFacing(const Axiom::Math::Vector3& point) const; // is the plane facing the point (or in front of plane)

private:
	Axiom::Math::Vector3	mNormal;	// In what direction is the plane facing
	float					mDistance;	// Distance of the plane to the origin
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Shape
} // namespace SharedSoccer

#include "shape/source/plane.inl"

#endif //_PLANE_H

// End of file --------------------------------------------------------------------------------------------------------

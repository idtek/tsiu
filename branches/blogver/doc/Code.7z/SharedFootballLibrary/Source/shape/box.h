//////////////////////////////////////////////////////////////////////////
// File: box.h

#ifndef __CORE_HEADER_BOX_H
#define __CORE_HEADER_BOX_H

#include "math/vector3.h"

namespace SharedSoccer
{
	namespace Shape
	{
		// axis aligned box @ origin
		class Box
		{
		// ctor / dtor
		public:
			Box(); // NON initializing ctor!
			Box(const Axiom::Math::Vector3& halfExtents);
			~Box();
		
		// imp
		public:
			static Box GetInvalid();
		
		// fields
		public:
			Axiom::Math::Vector3 m_halfExtents;

			AP_DECLARE_TYPE();		
		};
	}
}


#endif // __CORE_HEADER_BOX_H


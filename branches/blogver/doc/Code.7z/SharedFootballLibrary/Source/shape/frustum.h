
#ifndef  __CORE_FRUSTUM_H
# define __CORE_FRUSTUM_H

# include "math/matrix44.h"

namespace SharedSoccer
{
	namespace Shape
	{
		class Frustum
		{
		public:

			enum PLANE_e
			{
				PLANE_LEFT,
				PLANE_RIGHT,
				PLANE_BOTTOM,
				PLANE_TOP,
				PLANE_NEAR,
				PLANE_FAR,

				NBPLANES
			};

			enum POINT_e 
			{ 
				POINT_INVALID = -1,

				POINT_NEAR_TOP_LEFT, 
				POINT_NEAR_TOP_RIGHT, 
				POINT_NEAR_BOTTOM_RIGHT, 
				POINT_NEAR_BOTTOM_LEFT,
				POINT_FAR_TOP_LEFT,
				POINT_FAR_TOP_RIGHT,
				POINT_FAR_BOTTOM_RIGHT,
				POINT_FAR_BOTTOM_LEFT,

				NBPOINTS 
			};

			enum REPORT_e 
			{
				REPORT_FULLY_OUTSIDE,
				REPORT_PARTIALLY_OUTSIDE,
				REPORT_INSIDE,

				NBREPORTS
			};

			Frustum(void);
			Frustum(const Axiom::Math::Matrix44&);
			Frustum(const Axiom::Math::Matrix4&,const Axiom::Math::Matrix44&);
			~Frustum(void);

			float	GetDistanceFromPlane(PLANE_e,Axiom::Math::Vector4,float);
			float	GetDistanceFromPlane(PLANE_e,Axiom::Math::Vector4,Axiom::Math::Vector4);

			bool	IsIn(Axiom::Math::Vector4,float);
			bool	IsIn(Axiom::Math::Vector4,Axiom::Math::Vector4);
			bool	IsFullyIn(Axiom::Math::Vector4,float);
			bool	IsFullyIn(Axiom::Math::Vector4,Axiom::Math::Vector4);

		private:

			// Private classes
			class FrustumPlane
			{
			public:

				FrustumPlane(void);

				Axiom::Math::Vector4	m_Normal;
				POINT_e	m_NVertex;
				POINT_e	m_PVertex;
			};
	
			// Private methods
			void		InitPlanes(const Axiom::Math::Matrix44&);
			bool		FullyOutsidePlane(const Axiom::Math::Vector4&, const PLANE_e);
			REPORT_e	OutsidePlane(const Axiom::Math::Vector4&, const Axiom::Math::Vector4&, const PLANE_e);

			// Static private data members
//			static PLANE_e	m_sEvaluationOrder[NBPLANES];
//			static int		m_sNbEvaluations;

			// Private data
			FrustumPlane	m_aPlanes[NBPLANES];

		};
	}
}

#endif


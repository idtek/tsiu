//////////////////////////////////////////////////////////////////////////
// File: sphere.h

#ifndef __CORE_HEADER_SPHERE_H
#define __CORE_HEADER_SPHERE_H

namespace SharedSoccer
{
	namespace Shape
	{
		// Sphere at origin
		class Sphere
		{
		// ctor / dtor
		public:
			Sphere(); // NON initializing ctor!
			Sphere(float radius);

		// invalid
		public:
			static Sphere GetInvalid();

		// fields
		public:
			float m_radius;
		};
	}
}


#endif // __CORE_HEADER_SPHERE_H


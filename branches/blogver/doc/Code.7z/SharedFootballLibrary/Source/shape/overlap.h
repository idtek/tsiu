//////////////////////////////////////////////////////////////////////////
// File: overlap.h

#ifndef __CORE_HEADER_OVERLAP_H
#define __CORE_HEADER_OVERLAP_H

#include "math/vector3.h"
#include "math/rigidmatrix.h"

namespace SharedSoccer
{
	namespace Shape
	{

		class Aabb;
		class SweptAabb;
		class Sphere;
		class Cylinder;
		class Box;

		//////////////////////////////////////////////////////////////////////////
		// Discreet tests

		bool IsOverlap(const Aabb& lhs, const Aabb& rhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Sphere& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Sphere& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Cylinder& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Cylinder& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Box& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Box& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Sphere& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Cylinder& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Cylinder& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Box& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Box& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Sphere& rhs,
					   Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		//////////////////////////////////////////////////////////////////////////

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Sphere& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Sphere& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, 
					   Axiom::Math::Vector3& outOverlapPtOnRhs, Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Cylinder& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Cylinder& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
					   Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Box& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Box& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, 
					   Axiom::Math::Vector3& outOverlapPtOnRhs, Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Sphere& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Cylinder& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, 
					   Axiom::Math::Vector3& outOverlapPtOnRhs, Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Cylinder& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Box& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, 
					   Axiom::Math::Vector3& outOverlapPtOnRhs, Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		bool IsOverlap(const Axiom::Math::RigidMatrix& lhsT, const Box& lhs,
					   const Axiom::Math::RigidMatrix& rhsT, const Sphere& rhs,
					   float signedMargin, Axiom::Math::Vector3& outOverlapPtOnLhs, 
					   Axiom::Math::Vector3& outOverlapPtOnRhs, Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs);

		//////////////////////////////////////////////////////////////////////////
		// Swept tests

		bool IsSweptOverlap(const SweptAabb& lhs, const SweptAabb& rhs, float& normTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Sphere& lhs,
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Sphere& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Cylinder& lhs, 
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Cylinder& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Box& lhs,
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Box& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Sphere& lhs,
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Cylinder& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Cylinder& lhs,
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Box& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);

		bool IsSweptOverlap(const Axiom::Math::RigidMatrix& lhsT0, const Axiom::Math::RigidMatrix& lhsT1, const Box& lhs, 
							const Axiom::Math::RigidMatrix& rhsT0, const Axiom::Math::RigidMatrix& rhsT1, const Sphere& rhs,
							Axiom::Math::Vector3& outOverlapPtOnLhs, Axiom::Math::Vector3& outOverlapPtOnRhs,
							Axiom::Math::Vector3& outNormalOnLhs, Axiom::Math::Vector3& outNormalOnRhs,
							float& normalTimeOfOverlap);
	}
}


#endif // __CORE_HEADER_OVERLAP_H


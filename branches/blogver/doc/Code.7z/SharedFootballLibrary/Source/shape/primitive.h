//////////////////////////////////////////////////////////////////////////
// File: primitive.h

#ifndef __CORE_HEADER_PRIMITIVE_H
#define __CORE_HEADER_PRIMITIVE_H

#include "shape/aabb.h"
#include "shape/sphere.h"
#include "shape/cylinder.h"
#include "shape/overlap.h"

namespace SharedSoccer
{
	namespace Shape
	{
		Axiom::Math::Vector3 ClampToAabb(const Aabb& aabb, const Axiom::Math::Vector3& vecToClamp);

		Aabb WrapAabbArround(const Sphere& sphere);
		Aabb WrapAabbArround(const Cylinder& cylinder);

		Aabb WrapAabbArround(const Axiom::Math::RigidMatrix& transform, const Sphere& sphere);
		Aabb WrapAabbArround(const Axiom::Math::RigidMatrix& transform, const Cylinder& cylinder);

		SweptAabb WrapSweptAabbArround(const Axiom::Math::RigidMatrix& transformT0, const Axiom::Math::RigidMatrix& transformT1, const Sphere& sphere);
		SweptAabb WrapSweptAabbArround(const Axiom::Math::RigidMatrix& transformT0, const Axiom::Math::RigidMatrix& transformT1, const Cylinder& cylinder);
	}
}


#endif // __CORE_HEADER_PRIMITIVE_H


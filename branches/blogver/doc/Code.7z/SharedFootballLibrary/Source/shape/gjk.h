//////////////////////////////////////////////////////////////////////////
// File: gjk.h

#ifndef __CORE_HEADER_GJK_H
#define __CORE_HEADER_GJK_H

#include "math/apmath.h"
#include "shape/box.h"
#include "shape/sphere.h"
#include "shape/cylinder.h"
#include "math/quaternion.h"
#include "math/RigidMatrix.h"

#include "collections/fixedszarray.h"

#include "core/autopointer.h"

namespace SharedSoccer
{
	namespace Shape
	{
		//////////////////////////////////////////////////////////////////////////
		// Fwd declares

		class SphereSupportMapper;
		class CylinderSupportMapper;
		class BoxSupportMapper;
		template <class ShapeSupportMapperT> class TransformedShapeSupportMapper;

		//////////////////////////////////////////////////////////////////////////
		// GJK

		class Gjk
		{
		public:
			//////////////////////////////////////////////////////////////////////
			// Simplex class used to store GJK state
			// (combines support mappings of two shapes with Minkowski difference)

			class MinkowskiDiffSimplex
			{
			public:
				typedef Axiom::Collections::FixedSizeArray<Axiom::Math::Vector3, 4> VecArray;
				typedef VecArray::SizeType SizeType;
				static const SizeType sk_maxCardinality = 4;

			public:
				template <class SupportMapperA, class SupportMapperB>
				void ComputeExtremeVxInDir(const SupportMapperA& shapeA,
										   const SupportMapperB& shapeB, const Axiom::Math::Vector3& direction);
				void PushNextVx();
				inline SizeType Size() const;
				void EraseVx(SizeType i);
				const Axiom::Math::Vector3& GetConfigSpaceVx(SizeType i) const;
				const Axiom::Math::Vector3& GetNextCompoundVx() const;
				const Axiom::Math::Vector3& GetLastCompoundVx() const;
				void ComputeClosestPts(const Axiom::Math::Vector3& closestConfigSpacePt,
					Axiom::Math::Vector3& outClosestPtOnA, Axiom::Math::Vector3& outClosestPtOnB) const;
				bool IsNextCompoundVxRedundant(float squareEpsilon) const;

			private:
				VecArray m_vecArrayConfigSpace;
				VecArray m_vecArrayShapeA;
				VecArray m_vecArrayShapeB;

				Axiom::Math::Vector3 m_nextVxCompound;
				Axiom::Math::Vector3 m_nextVxShapeA;
				Axiom::Math::Vector3 m_nextVxShapeB;
			};

			static const float sk_closestVxMagnitudeSqEpsilon;
			static const float sk_coplanarityEpsilon;

		public:
			Gjk();

			template <class SupportMapperA, class SupportMapperB>
			bool GetClosestPts(const SupportMapperA& shapeA, const SupportMapperB& shapeB,
							   const Axiom::Math::Vector3& initialDir, float squareEpsilon,
							   Axiom::Math::Vector3& outClosestPtOnA, Axiom::Math::Vector3& outClosestPtOnB,
							   Axiom::Math::Vector3& outNormalOnA, Axiom::Math::Vector3& outNormalOnB);

			Axiom::UInt16 GetLoopCount() const;

		private:
			float MeasureSquareCloseness(const Axiom::Math::Vector3& closestVx, const Axiom::Math::Vector3& nextVx) const;
			float ClosestPtOnInfiniteLineToOrigin(const Axiom::Math::Vector3& segStartPt, const Axiom::Math::Vector3& segDir) const;

			// Simplex reduction
			bool ReduceSimplex(Axiom::Math::Vector3& outClosestVx);
			void ReduceSimplex1(Axiom::Math::Vector3& outClosestVx);
			void ReduceSimplex2(Axiom::Math::Vector3& outClosestVx);
			void ReduceSimplex3(Axiom::Math::Vector3& outClosestVx);
			bool ReduceSimplex4(Axiom::Math::Vector3& outClosestVx);

		private:
			MinkowskiDiffSimplex m_simplex;
			Axiom::UInt16 m_loopCounter;
		};


		//////////////////////////////////////////////////////////////////////////
		// Support Mappers

		class SphereSupportMapper
		{
		public:
			SphereSupportMapper(const Sphere& sphere);

			Axiom::Math::Vector3 GetSupportVertex(const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetNormalOnSurface(const Axiom::Math::Vector3& dir) const;

			Sphere m_sphere;
		};

		class CylinderSupportMapper
		{
		public:
			CylinderSupportMapper(const Cylinder& cylinder);

			float RayTraceInfiniteCylinder(float radius, const Axiom::Math::Vector3& dir) const;

			float RayTraceHalfSphere(float radius, float height, const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetSupportVertex(const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetNormalOnSurface(const Axiom::Math::Vector3& dir) const;

			Cylinder m_cylinder;
		};

		class BoxSupportMapper
		{
		public:
			BoxSupportMapper(const Box& box);

			Axiom::Math::Vector3 GetSupportVertex(const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetNormalOnSurface(const Axiom::Math::Vector3& dir) const;

			Box m_box;
		};

		template <class ShapeSupportMapperT>
		class TransformedShapeSupportMapper
		{
		public:
			TransformedShapeSupportMapper(const ShapeSupportMapperT& shape, const Axiom::Math::RigidMatrix& transform);

			Axiom::Math::Vector3 GetSupportVertex(const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetNormalOnSurface(const Axiom::Math::Vector3& dir) const;

			ShapeSupportMapperT m_shape;
			Axiom::Math::RigidMatrix m_transform;
			Axiom::Math::Quaternion m_invRot;
		};

		template <class ShapeSupportMapperT>
		class MarginShapeSupportMapper
		{
		public:
			MarginShapeSupportMapper(const ShapeSupportMapperT& shape, float signedMargin);

			Axiom::Math::Vector3 GetSupportVertex(const Axiom::Math::Vector3& dir) const;

			Axiom::Math::Vector3 GetNormalOnSurface(const Axiom::Math::Vector3& dir) const;

			ShapeSupportMapperT m_shape;
			float m_signedMargin;
		};




		//////////////////////////////////////////////////////////////////////////
		// Inline: Gjk

		inline Axiom::UInt16 Gjk::GetLoopCount() const
		{
			return m_loopCounter;
		}

		inline float Gjk::ClosestPtOnInfiniteLineToOrigin(const Axiom::Math::Vector3& segStartPt, const Axiom::Math::Vector3& segDir) const
		{
			return -((segStartPt /* - Axiom::Math::Vector3(0, 0, 0)*/).Dot(segDir)) / segDir.SquareMagnitude();
		}

		inline bool Gjk::ReduceSimplex(Axiom::Math::Vector3& outClosestVx)
		{
			switch(m_simplex.Size())
			{
			case 0:	// no vertices!
			default: // more then 4 vertices!
				AP_SIMPLEASSERTFAIL("unsupported case!");
				break;

			case 1: // single vx
				ReduceSimplex1(outClosestVx);
				break;

			case 2: // edge (2 vx)
				ReduceSimplex2(outClosestVx);
				break;

			case 3: // triangle (3 vx)
				ReduceSimplex3(outClosestVx);
				break;

			case 4: // tetrahedron (4 vx)
				return ReduceSimplex4(outClosestVx); // return whether 4 simplex contains origin
				break;
			};

			return false;
		}

		inline Axiom::Math::Vector3 SelectNonZeroVec(const Axiom::Math::Vector3& inVec)
		{
			float sqMag = inVec.SquareMagnitude();
			float zeroTest = sqMag - 2.0f * Axiom::Math::EPSILON;
			return Axiom::Math::Vector3(Axiom::Math::FSel(zeroTest, inVec.X(), 1.0f),
				Axiom::Math::FSel(zeroTest, inVec.Y(), 0.0f),
				Axiom::Math::FSel(zeroTest, inVec.Z(), 0.0f));
		}

		template <class SupportMapperA, class SupportMapperB>
		bool Gjk::GetClosestPts(const SupportMapperA& shapeA, const SupportMapperB& shapeB,
								const Axiom::Math::Vector3& initialDir, float squareEpsilon,
								Axiom::Math::Vector3& outClosestPtOnA, Axiom::Math::Vector3& outClosestPtOnB,
								Axiom::Math::Vector3& outNormalOnA, Axiom::Math::Vector3& outNormalOnB)
		{
			AP_ASSERTMESSAGE(squareEpsilon > 2.0f*Axiom::Math::EPSILON, "Gjk::GetClosestPts -- 'squareEpsilon' has to be big enough to also eliminate floating point problems");

			AP_DATAVALIDATION_SUPPORT(static Axiom::AutoPointer<MinkowskiDiffSimplex> pDebugSimplex(AP_ALIGNED_NEW(Axiom::Memory::PHYSICS_HEAP, 16, MinkowskiDiffSimplex)));

			// get first vx and next vx from initial dir
			m_simplex.ComputeExtremeVxInDir(shapeA, shapeB, initialDir);
			m_simplex.PushNextVx();
			Axiom::Math::Vector3 closestConfigSpacePt = m_simplex.GetConfigSpaceVx(0);
			m_simplex.ComputeExtremeVxInDir(shapeA, shapeB, -closestConfigSpacePt);

			// iteratively get closer and closer to origin until next vx doesn't help much
			bool isOverlapCertain = false;

			// how close is the next vx to being the result of searching in the ideal direction
			float nextSquareCloseness = Axiom::Math::FLOAT_MAX; // (arbitrary starting value, we must enter the loop at least once)
			float closestVxSqMagnitude = Axiom::Math::FLOAT_MAX;
			AP_ASSERT(nextSquareCloseness > squareEpsilon);

			m_loopCounter = 1;

			// while we get an improvement(positive) from the next iteration 
			// and while the next best vx is not the one we got previously
			while(  m_loopCounter < 17 &&												// HACK this temporarily takes care of some termination problems
					closestVxSqMagnitude > sk_closestVxMagnitudeSqEpsilon &&		// if this falls too low we'll get termination errors
					nextSquareCloseness > (squareEpsilon * closestVxSqMagnitude) &&	// using relative error in order to prevent termination problems
					!m_simplex.IsNextCompoundVxRedundant(squareEpsilon))			// if the next vx is the same as either the last or before last vx, then we can't get further improvement
			{
				//AP_ASSERTMESSAGE(loopCounter < 20);
				++m_loopCounter;

				// push next vx onto simplex (vx stack)
				m_simplex.PushNextVx();

				// reduce simplex and check if overlap is certain
				{
					AP_DATAVALIDATION_SUPPORT(*pDebugSimplex = m_simplex);
					bool does4simplexContainOrigin = ReduceSimplex(closestConfigSpacePt);
					isOverlapCertain = isOverlapCertain || does4simplexContainOrigin;
				}

				// next vx
				m_simplex.ComputeExtremeVxInDir(shapeA, shapeB, -closestConfigSpacePt);

				// closeness of 'nextVx' to origin along direction of 'outClosestPt'
				closestVxSqMagnitude = closestConfigSpacePt.SquareMagnitude();
				nextSquareCloseness = closestVxSqMagnitude - closestConfigSpacePt.Dot(m_simplex.GetNextCompoundVx());
			}

			AP_ASSERT(m_simplex.Size() > 0);
			m_simplex.ComputeClosestPts(closestConfigSpacePt, outClosestPtOnA, outClosestPtOnB);
			outNormalOnA = shapeA.GetNormalOnSurface(outClosestPtOnA);
			outNormalOnB = shapeB.GetNormalOnSurface(outClosestPtOnB);

			return isOverlapCertain || (m_simplex.Size() < 4 && closestVxSqMagnitude < squareEpsilon);
		}

		//////////////////////////////////////////////////////////////////////////
		// Inline: Gjk::CompoundSimplex

		template <class SupportMapperA, class SupportMapperB>
		inline void Gjk::MinkowskiDiffSimplex::ComputeExtremeVxInDir(const SupportMapperA& shapeA, const SupportMapperB& shapeB, const Axiom::Math::Vector3& direction)
		{
			AP_SIMPLEASSERTMESSAGE(Size() < sk_maxCardinality, "");

			m_nextVxShapeA = shapeA.GetSupportVertex(direction);
			m_nextVxShapeB = shapeB.GetSupportVertex(-direction);
			m_nextVxCompound = m_nextVxShapeA - m_nextVxShapeB;
		}

		inline void Gjk::MinkowskiDiffSimplex::PushNextVx()
		{
			AP_SIMPLEASSERTMESSAGE(Size() < sk_maxCardinality, "");

			m_vecArrayConfigSpace.PushBack(m_nextVxCompound);
			m_vecArrayShapeA.PushBack(m_nextVxShapeA);
			m_vecArrayShapeB.PushBack(m_nextVxShapeB);

			AP_SIMPLEASSERTMESSAGE(m_vecArrayConfigSpace.Size() == m_vecArrayShapeA.Size(), "");
			AP_SIMPLEASSERTMESSAGE(m_vecArrayConfigSpace.Size() == m_vecArrayShapeB.Size(), "");
		}

		inline Gjk::MinkowskiDiffSimplex::SizeType Gjk::MinkowskiDiffSimplex::Size() const
		{
			AP_SIMPLEASSERTMESSAGE(m_vecArrayConfigSpace.Size() == m_vecArrayShapeA.Size(), "");
			AP_SIMPLEASSERTMESSAGE(m_vecArrayConfigSpace.Size() == m_vecArrayShapeB.Size(), "");
			return m_vecArrayConfigSpace.Size();
		}

		inline void Gjk::MinkowskiDiffSimplex::EraseVx(SizeType i)
		{
			SizeType cardinality = Size();

			AP_SIMPLEASSERTMESSAGE(i < cardinality, "");
			AP_SIMPLEASSERTMESSAGE(cardinality <= sk_maxCardinality, "");

			for(SizeType arrayIdx = i + 1; arrayIdx < cardinality; ++arrayIdx)
			{
				m_vecArrayConfigSpace[arrayIdx - 1] = m_vecArrayConfigSpace[arrayIdx];
				m_vecArrayShapeA[arrayIdx - 1] = m_vecArrayShapeA[arrayIdx];
				m_vecArrayShapeB[arrayIdx - 1] = m_vecArrayShapeB[arrayIdx];
			}

			m_vecArrayConfigSpace.PopBack();
			m_vecArrayShapeA.PopBack();
			m_vecArrayShapeB.PopBack();
		}

		inline const Axiom::Math::Vector3& Gjk::MinkowskiDiffSimplex::GetConfigSpaceVx(SizeType i) const
		{
			AP_SIMPLEASSERTMESSAGE(i < Size(), "");
			return m_vecArrayConfigSpace[i];
		}

		inline const Axiom::Math::Vector3& Gjk::MinkowskiDiffSimplex::GetNextCompoundVx() const
		{
			return m_nextVxCompound;
		}

		inline const Axiom::Math::Vector3& Gjk::MinkowskiDiffSimplex::GetLastCompoundVx() const
		{
			AP_SIMPLEASSERTMESSAGE(Size() > 0, "");
			return m_vecArrayConfigSpace.Back();
		}

		inline bool Gjk::MinkowskiDiffSimplex::IsNextCompoundVxRedundant(float squareEpsilon) const
		{
			// only need to test last 3 vertices (two if no bugs are present :-s)
			int k = static_cast<int>(Size()) - 1;
			int j = Axiom::Math::Max(k - 1, 0);
			int i = Axiom::Math::Max(j - 1, 0);
			float minCloseness = Axiom::Math::FMin(Axiom::Math::FMin((m_nextVxCompound - m_vecArrayConfigSpace[k]).SquareMagnitude(),
										   (m_nextVxCompound - m_vecArrayConfigSpace[j]).SquareMagnitude()),
									  (m_nextVxCompound - m_vecArrayConfigSpace[i]).SquareMagnitude());
			return minCloseness <= squareEpsilon;
		}

		//////////////////////////////////////////////////////////////////////////
		// Inline: TransformedShapeSupportMapper

		template <class ShapeSupportMapperT>
		TransformedShapeSupportMapper<ShapeSupportMapperT>::TransformedShapeSupportMapper(const ShapeSupportMapperT& shape, const Axiom::Math::RigidMatrix& transform) :
			m_shape(shape),
			m_transform(transform),
			m_invRot(transform.mRotation.AsInverse())
		{
		}

		template <class ShapeSupportMapperT>
		Axiom::Math::Vector3 TransformedShapeSupportMapper<ShapeSupportMapperT>::GetSupportVertex(const Axiom::Math::Vector3& dir) const
		{
			return m_shape.GetSupportVertex(dir * m_invRot) * m_transform;
		}

		template <class ShapeSupportMapperT>
		Axiom::Math::Vector3 TransformedShapeSupportMapper<ShapeSupportMapperT>::GetNormalOnSurface(const Axiom::Math::Vector3& dir) const
		{
			return m_shape.GetNormalOnSurface((dir - m_transform.mTranslation) * m_invRot) * m_transform.mRotation;
		}

		//////////////////////////////////////////////////////////////////////////
		// Inline: MarginShapeSupportMapper

		template <class ShapeSupportMapperT>
		MarginShapeSupportMapper<ShapeSupportMapperT>::MarginShapeSupportMapper(const ShapeSupportMapperT& shape, float signedMargin) :
			m_shape(shape), 
			m_signedMargin(signedMargin)
		{
			AP_SIMPLEASSERTMESSAGE(Axiom::Math::Fabs(m_signedMargin) > Axiom::Math::EPSILON, "");
		}

		template <class ShapeSupportMapperT>
		Axiom::Math::Vector3 MarginShapeSupportMapper<ShapeSupportMapperT>::GetSupportVertex(const Axiom::Math::Vector3& dir) const
		{
			Axiom::Math::Vector3 vx = m_shape.GetSupportVertex(dir);
			return vx + (m_signedMargin * vx.AsNormal());
		}

		template <class ShapeSupportMapperT>
		Axiom::Math::Vector3 MarginShapeSupportMapper<ShapeSupportMapperT>::GetNormalOnSurface(const Axiom::Math::Vector3& dir) const
		{
			return m_shape.GetNormalOnSurface(dir);
		}
	}
}


#endif // __CORE_HEADER_GJK_H

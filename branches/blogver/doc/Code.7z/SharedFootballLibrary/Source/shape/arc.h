//////////////////////////////////////////////////////////////////////////
// File: arc.h

#ifndef __CORE_HEADER_ARC_H
#define __CORE_HEADER_ARC_H

#include "math/angle.h"
#include "math/vector2.h"

namespace SharedSoccer
{
	namespace Shape
	{
		// Arc at origin
		class Arc
		{
		// ctor / dtor
		public:
			Arc(); // NON initializing ctor!
			Arc(float radius, Axiom::Math::Angle angle);
			Arc(float radius, float radian);
			
			void		EndAxis(Axiom::Math::Vector2& pt1, Axiom::Math::Vector2& pt2)const;
			float		Length()const;
			bool		Contains( const Axiom::Math::Vector2& point) const; 

			float m_radius;
			Axiom::Math::Angle m_angle;
			Axiom::Math::Vector2 m_focal;
			Axiom::Math::Vector2 m_axis;
		};
	}
}


#endif // __CORE_HEADER_SPHERE_H


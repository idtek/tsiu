//////////////////////////////////////////////////////////////////////////
// File: aabb.h

#ifndef __CORE_HEADER_AABB_H
#define __CORE_HEADER_AABB_H

#include "shape/line.h"
#include "math/vector2.h"
#include "math/vector3.h"
#include "math/rigidmatrix.h"

namespace SharedSoccer
{
	namespace Shape
	{
		//////////////////////////////////////////////////////////////////////////
		// fwd declares
		class SweptAabb;

		//////////////////////////////////////////////////////////////////////////

		class Aabb
		{
		// ctor / dtor
		public:
			Aabb(); // non initializing ctor!
			Aabb(const Axiom::Math::Vector3& center, const Axiom::Math::Vector3& halfExtents);
			
			static Aabb     CreateUsingMinMax( const Axiom::Math::Vector3& min, const Axiom::Math::Vector3& max );
			
			void            InitFromMinMax( const Axiom::Math::Vector3& min, const Axiom::Math::Vector3& max );
		
		// ops
		public:

			Axiom::Math::Vector3 GetMin() const;
			Axiom::Math::Vector3 GetMax() const;
			
			bool    Contains( const Axiom::Math::Vector3& point ) const;
			bool    Intersects( const Line3& line, Axiom::Math::Vector3* pHit ) const;

			void ExtendBy(const Aabb& extender);
			void ExtendBy(const SweptAabb& extender);
			
			// if change is 5, will become 10 units wider (5 on both sides)
			void AdjustYWidth( float change );
			// if change is 5, will become 5 units taller, with centre moving up 2.5 units
			void AdjustHeight( float change );
			
		public:
			static Aabb GetInvalid();
			
		// fields
		public:
			Axiom::Math::Vector3 m_center;
			Axiom::Math::Vector3 m_halfExtents;
			
        private:
            
            AP_DATAVALIDATION_SUPPORT(void TestInvariant() const;)
            static Axiom::Math::Vector3 ComputeCenter(const Axiom::Math::Vector3& min, const Axiom::Math::Vector3& max);
            static Axiom::Math::Vector3 ComputeHalfExtents(const Axiom::Math::Vector3& min, const Axiom::Math::Vector3& max);
		};

		//////////////////////////////////////////////////////////////////////////

		class SweptAabb
		{
		// ctor / dtor
		public:
			SweptAabb(); // non initializing ctor!
			SweptAabb(const Aabb& staticAabb);
			SweptAabb(const Axiom::Math::Vector3& center_t0, const Axiom::Math::Vector3& center_t1, 
					  const Axiom::Math::Vector3& halfExtents);

		public:
			static SweptAabb GetInvalid();
			static SweptAabb InitFromMotionAndExtents(const Axiom::Math::RigidMatrix& transformT0, const Axiom::Math::RigidMatrix& transformT1, const Axiom::Math::Vector3& axisAlignedHalfExtents);

		// fields
		public:
			Axiom::Math::Vector3 m_centerTime0;
			Axiom::Math::Vector3 m_centerTime1;
			Axiom::Math::Vector3 m_halfExtents;
		};
		
		//////////////////////////////////////////////////////////////////////////
		
        class AABoundingRectangle
        {
            // ctor / dtor
        public:
            AABoundingRectangle(); // non initializing ctor!
            AABoundingRectangle( const Axiom::Math::Vector2& center, const Axiom::Math::Vector2& halfExtents );

            static AABoundingRectangle     CreateUsingMinMax( const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max );

            void            InitFromMinMax( const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max );

            // ops
        public:

            Axiom::Math::Vector2 GetMin() const;
            Axiom::Math::Vector2 GetMax() const;

            bool    Contains( const Axiom::Math::Vector2& point ) const;
            bool    Intersects( const Line2& line, Axiom::Math::Vector2* pHit ) const;

            void ExtendBy(const AABoundingRectangle& extender);

        public:
            static AABoundingRectangle GetInvalid();

            // fields
        public:
            Axiom::Math::Vector2 m_center;
            Axiom::Math::Vector2 m_halfExtents;

        private:

            static Axiom::Math::Vector2 ComputeCenter(const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max);
            static Axiom::Math::Vector2 ComputeHalfExtents(const Axiom::Math::Vector2& min, const Axiom::Math::Vector2& max);
            AP_DATAVALIDATION_SUPPORT(void TestInvariant() const;)
        };
	}
}


#endif // __CORE_HEADER_AABB_H


//////////////////////////////////////////////////////////////////////////
// File: line.h

#ifndef __CORE_HEADER_LINE_H
#define __CORE_HEADER_LINE_H

#include "math/vector2.h"
#include "math/vector3.h"

namespace SharedSoccer
{
namespace Shape
{

// Line at origin
template<class T> class Pair
{
// ctor / dtor
public:
	Pair(); // NON initializing ctor!
	Pair( const T& a, const T&b );
	
	const T& ValueA() const;
	const T& ValueB() const;

	T& ValueA();
	T& ValueB();
	// AP_PRECONDITION( index < 2 );
	const T& operator []( Axiom::uint index ) const;

protected	:
    T   mA, mB;
};

template<class T> 
Pair<T>::Pair()
:   mA( Axiom::Math::Vector3::ZERO ),
    mB( Axiom::Math::Vector3::ZERO )
{
    // Empty method body
}
	
template<class T> 
Pair<T>::Pair( const T& a, const T&b )
:   mA( a ),
    mB( b )
{
    // Empty method body
}

template<class T> 
const T& Pair<T>::ValueA() const
{
    return mA;
}

template<class T> 
const T& Pair<T>::ValueB() const
{
    return mB;
}

template<class T> 
T& Pair<T>::ValueA()
{
    return mA;
}

template<class T> 
T& Pair<T>::ValueB()
{
    return mB;
}

template<class T> 
const T& Pair<T>::operator []( Axiom::uint index ) const
{
    AP_PRECONDITION( index < 2 );
    
    return ( index == 0 ) ? mA : mB;
}

class Line2 : public Pair< Axiom::Math::Vector2 >
{
public:
    
    Line2( const Axiom::Math::Vector2& a, const Axiom::Math::Vector2&b );
    
    bool    Intersects( const Line2& ) const;
	bool    Intersects( const Line2& xRef, Axiom::Math::Vector2* pIntersection ) const;
    Axiom::Math::Vector2 ToBFromA() const;
    float   SquareMagnitude() const;

	bool PassesWithinDistance( const Axiom::Math::Vector2& vec, float distance ) const;
};

typedef Pair< Axiom::Math::Vector3 > Line3;

inline Line2::Line2( const Axiom::Math::Vector2& a, const Axiom::Math::Vector2&b )
:   Pair< Axiom::Math::Vector2 >( a, b )
{
    // Empty method body
}

inline Axiom::Math::Vector2 Line2::ToBFromA() const
{
    return ValueB() - ValueA();
}

} // end namespace Shape

} // end namespace SharedSoccer


#endif // __CORE_HEADER_LINE_H

//////////////////////////////////////////////////////////////////////////
// File: Cylinder.h

#ifndef __CORE_HEADER_CYLINDER_H
#define __CORE_HEADER_CYLINDER_H

namespace SharedSoccer
{

	namespace Shape
	{
		//////////////////////////////////////////////////////////////////////////
		// Simple right Cylinder

		class Cylinder
		{
		// ctor / dtor
		public:
			Cylinder(); // NON initializing ctor!

			Cylinder(float halfHeight, float radius); // height of center of top capping hemisphere
			~Cylinder();
		
		// invalid
		public:
			static Cylinder GetInvalid();
		
		// fields
		public:
			float m_halfHeight; // height of center of top capping hemisphere
			float m_radius;
			AP_DECLARE_TYPE();
		};

	}
	
}


#endif // __CORE_HEADER_CYLINDER_H


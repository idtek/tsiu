// rectangle.h - (c) 2007 Action Pants Inc.
// -----------------------------------------------------------------------------

#ifndef __CORE_RECTANGLE_H
#define __CORE_RECTANGLE_H

#include "math/vector2.h"

namespace SharedSoccer
{
	namespace Shape
	{
        ////////////////////////////////////// class Rectangle //////////////////////////////////////
		class AP_API Rectangle
		{
		public:
							Rectangle	(const float left = 0.f, const float top = 0.f, const float right = 0.f, const float bottom = 0.f);
							Rectangle	(const Axiom::Math::Vector2& topLeft, const Axiom::Math::Vector2& bottomRight);

			Rectangle&		Set			(const float left, const float top, const float right, const float bottom);
			Rectangle&		Set			(const Axiom::Math::Vector2& topLeft, const Axiom::Math::Vector2& bottomRight);
			Rectangle&		Clear		();

			const float		Top			() const;
			const float		Left		() const;
			const float		Bottom		() const;
			const float		Right		() const;
			const float		Width		() const;
			const float		Height		() const;
			Rectangle&		Top			(const float top);
			Rectangle&		Left		(const float left);
			Rectangle&		Bottom		(const float bottom);
			Rectangle&		Right		(const float right);
			Rectangle&		Width		(const float width);
			Rectangle&		Height		(const float height);

			const Axiom::Math::Vector2	TopLeft		() const;
			const Axiom::Math::Vector2	TopRight	() const;
			const Axiom::Math::Vector2	BottomLeft	() const;
			const Axiom::Math::Vector2	BottomRight	() const;
			Rectangle&		TopLeft		(const float left, const float top);
			Rectangle&		TopLeft		(const Axiom::Math::Vector2& v);
			Rectangle&		BottomRight	(const float right, const float bottom);
			Rectangle&		BottomRight	(const Axiom::Math::Vector2& v);

		    const bool		IsEmpty		() const;
		    const bool		IsValid		() const;
			Rectangle&		Validate	();
			Rectangle		Validate	() const;

			Rectangle&		Offset		(const float x, const float y);
			Rectangle&		Offset		(const Axiom::Math::Vector2& v);
			Rectangle		Offset		(const float x, const float y)	const;
			Rectangle		Offset		(const Axiom::Math::Vector2& v) const;

			const bool		Intersects	(const Rectangle& rect) const;
			Rectangle&		Intersect	(const Rectangle& rect);
			inline Rectangle		Intersect	(const Rectangle& rect) const;

			const bool		Contains	(const float x, const float y) const;
			const bool		Contains	(const Axiom::Math::Vector2& v) const;
			const bool		Contains	(const Rectangle& rect) const;

			Rectangle&		Union		(const float x, const float y);
			Rectangle		Union		(const float x, const float y) const;
			Rectangle&		Union		(const Axiom::Math::Vector2& v);
			Rectangle		Union		(const Axiom::Math::Vector2& v) const;
			Rectangle&		Union		(const Rectangle& rect);
			Rectangle		Union		(const Rectangle& rect) const;

			float			ClampWidth	(const float f) const;
			float			ClampHeight	(const float f) const;
			Axiom::Math::Vector2			Clamp		(const Axiom::Math::Vector2& v) const;
		protected:
			float mTop, mLeft, mBottom, mRight;
		};
	} // namespace Shape
} // namespace SharedSoccer

#include "shape/source/rectangle.inl"


#endif // __CORE_RECTANGLE_H

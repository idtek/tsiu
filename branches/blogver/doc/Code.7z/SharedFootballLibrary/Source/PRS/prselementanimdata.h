#pragma once

#ifndef  _PRSELEMENTANIMDATA_H
# define _PRSELEMENTANIMDATA_H

# ifndef _PRESENTATION_CONFIG_H_
#  include "presentation/presentation_config.h"
# endif
# ifndef _PRESENTATION_UTILS_H_
#  include "presentation/presentation_utils.h"
# endif
#ifndef _PRESENTATION_TRANSFORMATION_DATA_H_
#  include "presentation/Shared/presentationtransformationdata.h"
# endif

# ifndef __CORE_VECTOR3_H
#  include <math/vector3.h>
# endif
# ifndef __CORE_ANGLE_H
#  include <math/angle.h>
# endif
# ifndef __CORE_REFERENCED_H
#  include <core/referenced.h>
# endif
# ifndef _CLASSEDENUM_H
#  include <core/classedenum.h>
# endif
# ifndef GEL_RENDERABLELIST_H
#  include <gel/renderablelist.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef	 INVALIDITEMS
# define INVALIDITEMS 0

		CLASSEDENUM_REFLECTED(PRS_LOOP_TYPE_e,\
			CLASSEDENUM_ITEM(PRS_LOOP_FORWARD)\
			CLASSEDENUM_ITEM(PRS_PLAY_FORWARD_ONCE)\
			CLASSEDENUM_ITEM(PRS_LOOP_PING_PONG)\
			,PRS_LOOP_FORWARD)

		CLASSEDENUM_REFLECTED(PRS_TYPE_e, \
			CLASSEDENUM_ITEM(PRS_TYPE_ALREADYINRENDERLIST) \
			CLASSEDENUM_ITEM(PRS_TYPE_ADDINRENDERLIST_TARGET)\
			CLASSEDENUM_ITEM(PRS_TYPE_ADDINRENDERLIST) \
			,PRS_TYPE_ALREADYINRENDERLIST)


		CLASSEDENUM_REFLECTED(PRS_DRAW_ORDER_e,\
			CLASSEDENUM_ITEM(PRS_DRAW_FIRST)\
			CLASSEDENUM_ITEM(PRS_DRAW_AFTER_SCENE)\
			CLASSEDENUM_ITEM(PRS_DRAW_AFTER_PARTICLES)\
			,PRS_DRAW_FIRST )

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

		class PRSElementData : public Axiom::Referenced
		{
		public:

			// Constants
			static const float				k_Framerate;
			static const Axiom::CRC			k_PRSSceneName; 

		public:

			AP_DECLARE_POLYMORPHIC_TYPE();

			// Constructor & destructor
			PRSElementData(void);
			~PRSElementData(void);

			// Copy operator
			PRESENTATION_INLINE void operator=(const PRSElementData&);
			PRESENTATION_INLINE bool operator==(const PRSElementData&) const;

			// Misc Functions
			PRESENTATION_INLINE bool		IsValid() const;
			PRESENTATION_INLINE Axiom::CRC	GetSceneHashName() const;

			PRESENTATION_INLINE bool		GetClusterRequiresDrawing() const;
			PRESENTATION_INLINE bool		GetMeshInstanceRequiresShowAndHide() const;
			PRESENTATION_INLINE float		GetLoopStartTime() const;
			PRESENTATION_INLINE float		GetLoopEndTime() const;


			// Controller name
			Axiom::StripStringCRC				m_PRSControllerName;
			Axiom::StripStringCRC				m_ClusterName;
			PRS_DRAW_ORDER_e				m_DrawOrder;

			// Public Time Data
			float							m_TimeScale;
			PRS_LOOP_TYPE_e	 				m_LoopType;

			// Animated Element Handling
			PresentationTransformationData  m_Transform;
			PRS_TYPE_e						m_PRSType;

			float							m_LoopStartKeyFrame;
			float							m_LoopEndKeyFrame;
		};

		// Inlining
#ifdef PRESENTATION_USE_INLINE
# include "prs/prselementdata.inl"
#endif

	}
}

#endif

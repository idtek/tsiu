
#ifndef _PRS_EVENTS_H_
# include "prs/prs_events.h"
#endif

// Namespace usage
using namespace AP;
using namespace Events;

// Reflection declaration
AP_TYPE(PRSPanelVisibilityEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("SmallVis", mSmallPanelsVisible, "Set to true to show small panels")
AP_TYPE_END()


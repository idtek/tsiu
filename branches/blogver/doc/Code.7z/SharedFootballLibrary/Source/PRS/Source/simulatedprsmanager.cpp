
// Class header
#ifndef _SIMULATED_PRSMANAGER_H
# include "prs/simulatedprsmanager.h"
#endif
#ifndef _PRS_EVENTS_H
# include "prs/prs_events.h"
#endif
#ifndef  _SEQUENCEMANAGER_H_
# include "presentation/sequence/sequencemanager.h"
#endif
#ifndef  _PRESENTATION_UTILS_H_
# include "presentation/presentation_utils.h"
#endif
#ifndef  _PRESENTATIONINPUT_H_
# include "presentation/presentationinput.h"
#endif
#ifndef  _CAMERAMANAGER_H_
# include "presentation/camera/cameramanager.h"
#endif
#ifndef  _VIEWPORT_H_
# include "presentation/camera/viewport.h"
#endif

// Debug
# ifndef  _SIMULATEDPRESENTATION_H_
#  include "presentation/simulatedpresentation.h"
# endif

// to get prs controller resource from prselementdata
#include"Apres/apres.h"

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "prs/simulatedprsmanager.inl"
#endif

// Static data member
SimulatedPRSManager* SimulatedPRSManager::m_pInstance = NULL;

// Constructor & destructor
SimulatedPRSManager::SimulatedPRSManager(void) :
	m_ActiveElements()
{
}

SimulatedPRSManager::~SimulatedPRSManager(void)
{
}

// Static public methods
/* static */ SimulatedPRSManager *SimulatedPRSManager::Init(Axiom::Memory::HeapId iHeapID)
{
	AP_ASSERTMESSAGE(m_pInstance == NULL, "Init should only be called once.");
	if(m_pInstance == NULL)
	{
		(void)AP_TYPEOF(AP::Events::PRSPanelVisibilityEvent);

		m_pInstance = AP_NEW( iHeapID, SimulatedPRSManager());
		AP_ASSERTMESSAGE(m_pInstance != NULL, "error allocating memory.");
	}
	return m_pInstance;
}

/* static */ void SimulatedPRSManager::Destroy(void)
{
	AP_DELETE(m_pInstance);
	m_pInstance= NULL;
}

// Public methods
void SimulatedPRSManager::AddActiveElement(const PRSElementData &rNewElement,
										   bool reset)
{
#if CORE_USERDEBUG == CORE_YES
	if( !rNewElement.IsValid() )
	{
		Axiom::ShortString text("PRS Data invalid:");
		Axiom::ShortString sceneID(rNewElement.m_PRSControllerName.GetDebugString());
		Axiom::ShortString spacer(" - ");
		Axiom::ShortString clusterID(rNewElement.m_ClusterName.GetDebugString());
		text += sceneID;
		text += spacer;
		text += clusterID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
		return;
	}
#endif

	int i = GetIndexOfActivePRSElement(rNewElement.m_PRSControllerName);
	if( i < 0 )
	{
		i = m_ActiveElements.Count();
		m_ActiveElements.AddDefault();
		m_ActiveElements[i].SetData(rNewElement);

#if !(CORE_USERDEBUG == CORE_YES)
		if(m_ActiveElements[i].GetData().GetMeshInstanceRequiresShowAndHide())
		{
			SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
			AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "Character Animation Controller Key Error: No Simulated Presentation created!" );

			AP::Events::PRSVisibilityEvent eEvent( m_ActiveElements[i].GetData().m_PRSControllerName, true );
			pSimulatedPresentation->GetMessageBox()->SendEvent( &eEvent );
		}
#endif
	}
	else
	{
		m_ActiveElements[i].SetData(rNewElement);
	}

	if(reset)
	{
#if CORE_USERDEBUG == CORE_YES
		// Call show event as required in all cases, in case user changed name in streaker. In final, this should only be called as is done when
		// the element isn't found (done in the if (i<0) branch above
		if(m_ActiveElements[i].GetData().GetMeshInstanceRequiresShowAndHide())
		{
			SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
			AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "Character Animation Controller Key Error: No Simulated Presentation created!" );

			AP::Events::PRSVisibilityEvent eEvent( m_ActiveElements[i].GetData().m_PRSControllerName, true );
			pSimulatedPresentation->GetMessageBox()->SendEvent( &eEvent );
		}
#endif

		m_ActiveElements[i].Reset();
		m_ActiveElements[i].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
}

bool SimulatedPRSManager::RemoveActiveElement(const Axiom::StripStringCRC &rID)
{
	int i = GetIndexOfActivePRSElement(rID);	
	if( i >= 0 )
	{
		RemoveElementAt(i);
		return true;
	}
	return false;
}

bool SimulatedPRSManager::RemoveElementAt(int i)
{
	if(m_ActiveElements[i].GetData().GetMeshInstanceRequiresShowAndHide())
	{
		SimulatedPresentation *pSimulatedPresentation = SimulatedPresentation::GetInstance();
		AP_ASSERTMESSAGE( pSimulatedPresentation != NULL, "Couldn't get SimulatedPresentation instance!" );

		AP::Events::PRSVisibilityEvent eEvent( m_ActiveElements[i].GetData().m_PRSControllerName, false);
		pSimulatedPresentation->GetMessageBox()->SendEvent( &eEvent );
	}
	m_ActiveElements.RemoveAt(i);
	return false;
}

void SimulatedPRSManager::Reset(void)
{
	for(int i = m_ActiveElements.Count()-1; i >=0 ; --i)
	{
		RemoveElementAt(i);
	}
	m_ActiveElements.Clear();
}


void SimulatedPRSManager::Update(float deltaTime, const PresentationInput& rInput, PresentationOutput *pOutput)
{
	AP_ASSERTMESSAGE(pOutput != NULL, "PRS Error: NULL pointer passed!\n");

	for(unsigned int i = 0; i < m_ActiveElements.Count(); ++i)
	{
		PRSElement &rActiveElement = m_ActiveElements[i];
		PRSElementData &rActiveElementData = rActiveElement.GetData();

		Axiom::Math::Vector3 position;
		Axiom::Math::Quaternion rotation;

		bool prsRequiresUpdate =	rActiveElementData.m_Transform.GetUpdatesTransformEveryFrame() || 
									rActiveElementData.m_Transform.GetTransformNeedsToUpdate();
#if CORE_USERDEBUG == CORE_YES
		prsRequiresUpdate |= rActiveElementData.m_Transform.GetTransformType() == TRANSFORM_TYPE_e::TRANSFORM_UNLOCKED;
		prsRequiresUpdate |= deltaTime==0.0f; // This might seem weird, but for running with streaker, we still want to update the PRS when time is paused (in debug mode) so that we can tweak the positions of things in streaker
#endif

	   if(prsRequiresUpdate)
		{
			rActiveElementData.m_Transform.GetTransformAndRotation(rInput, rActiveElement.GetTransformRef(), m_ActiveElements[i].GetRotationRef());
			rActiveElementData.m_Transform.SetTransformNeedsToUpdate(false);
		}

		prsRequiresUpdate |= rActiveElement.Update(deltaTime);

		if(prsRequiresUpdate || rActiveElementData.GetClusterRequiresDrawing())
		{
			pOutput->ExportPRSElementData(	rActiveElement.GetTransform(), 
				rActiveElement.GetRotation(),
				rActiveElement.GetFrame(),
				rActiveElementData.m_PRSControllerName,
				rActiveElementData.m_ClusterName,
				rActiveElementData.m_DrawOrder,
				rActiveElementData.GetSceneHashName(),
				prsRequiresUpdate,
				rActiveElementData.GetClusterRequiresDrawing());
		}
	}
}

void SimulatedPRSManager::UpdateTimeScale(const Axiom::StripStringCRC& rControllerName, float timeScale)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_TimeScale = timeScale;
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateStartKeyFrame(const Axiom::StripStringCRC& rControllerName, float startKeyFrame)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_LoopStartKeyFrame = startKeyFrame;
		//m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateEndKeyFrame(const Axiom::StripStringCRC& rControllerName, float endKeyFrame)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_LoopEndKeyFrame = endKeyFrame;
		//m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateScale(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Vector3& rScale)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_Transform.SetScale(rScale);
		m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateRotation(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Angle& rRotX, const Axiom::Math::Angle& rRotY, const Axiom::Math::Angle& rRotZ)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_Transform.SetRotation(rRotX, rRotY, rRotZ);
		m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateTranslation(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Vector3& rTranslation)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_Transform.SetTranslation(rTranslation);
		m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::UpdateLoopType(const Axiom::StripStringCRC& rControllerName, const PRS_LOOP_TYPE_e& rLoopType)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_LoopType = rLoopType;
		//m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}

void SimulatedPRSManager::PlayAnimationFromStartFrame(const Axiom::StripStringCRC& rControllerName)
{
	int index = GetIndexOfActivePRSElement(rControllerName);
	if(index >= 0)
	{
		m_ActiveElements[index].GetData().m_Transform.SetTransformNeedsToUpdate(true);
		m_ActiveElements[index].Reset();
	}
#if CORE_USERDEBUG==CORE_YES
	else
	{
		Axiom::ShortString text("PRS Can't find:");
		Axiom::ShortString sceneID(rControllerName.GetDebugString());
		text += sceneID;
		Presentation::SimulatedPresentation::GetInstance()->AddDebugText(text);
	}
#endif
}


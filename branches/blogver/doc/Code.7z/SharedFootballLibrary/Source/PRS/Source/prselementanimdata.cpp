 
#ifndef _PRSELEMENTANIMDATA_H
# include "PRS/prselementanimdata.h"
#endif

// Namespace usage
using namespace SharedSoccer; 
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "PRS/prselementdata.inl"
#endif

// Reflection declaration
AP_TYPE(PRSElementData)
	AP_DEFAULT_CREATE()
	AP_FIELD("Name", m_PRSControllerName, "PRS Controller name")
	AP_FIELD("ClusterName", m_ClusterName, "Cluster name")
	AP_FIELD("DrawOrder", m_DrawOrder, "Draw order. Use first for player indicators. Use last for other transparent objects. Use whatever for everything else.")
	AP_FIELD("TimeScale", m_TimeScale, "FPS - Frames Per Second playback speed")
	AP_FIELD("StartKeyFrame", m_LoopStartKeyFrame, "Start key frame for default loop")
	AP_FIELD("EndKeyFrame", m_LoopEndKeyFrame, "End key frame for default loop")
	AP_FIELD("LoopType", m_LoopType, "Loop type: 0 = forward loop 1 = ping pong")
	AP_FIELD("Transform", m_Transform, "Specifies way PRS element will be transformed")
	AP_FIELD("Type", m_PRSType, "Type of PRS object. Determines how scene is rendered.")
	AP_NAMED_COMMAND("GetStartTime", GetLoopStartTime, "Get start time (seconds)")
	AP_NAMED_COMMAND("GetEndTime", GetLoopEndTime, "Get start time (seconds)")
	AP_ATTRIBUTE("DefaultValue", "{TimeScale=30.0,ClusterName={Value=\"SET_THIS\"}, Name={Value=\"SET_THIS\"}, EndKeyFrame=100.0, Type=PRS_TYPE_ALREADYINRENDERLIST, LoopType=PRS_LOOP_FORWARD}") // 
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(PRS_LOOP_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(PRS_TYPE_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()

AP_TYPE(PRS_DRAW_ORDER_e)
	AP_ENUM()
	AP_PROXY("Presentation")
AP_TYPE_END()


// Static data
const Axiom::CRC PRSElementData::k_PRSSceneName = Axiom::CRC( "color_prs" );
const float PRSElementData::k_Framerate = 30.0f;

// Constructor and destructor
PRSElementData::PRSElementData(void) :
	m_PRSControllerName(),
	m_ClusterName(),
	m_DrawOrder(PRS_DRAW_ORDER_e::PRS_DRAW_FIRST),
	m_TimeScale(k_Framerate),
	m_LoopType(PRS_LOOP_TYPE_e::PRS_LOOP_FORWARD),
	m_Transform(),
	m_PRSType(PRS_TYPE_e::PRS_TYPE_ADDINRENDERLIST_TARGET),
	m_LoopStartKeyFrame(0.0f),
	m_LoopEndKeyFrame(100.0f)
{
}

PRSElementData::~PRSElementData(void)
{
}



#ifndef _PRSELEMENT_H
# include "prs/prselement.h"
#endif

// Namespace usage
using namespace SharedSoccer;
using namespace Presentation;

// Inlining
#ifndef PRESENTATION_USE_INLINE
# include "prs/prselement.inl"
#endif

// Constructor & destructor
PRSElement::PRSElement(void ) :
	m_Transform(),
	m_Rotation(),
	m_Frame(-1.0f),
	m_FrameDirection(1.0f),
	m_PRSElementData()
{
}

PRSElement::~PRSElement(void)
{
}

#pragma once

#ifndef  _PRS_DEFINES_H_
# define _PRS_DEFINES_H_

// PRS 
# define PRESENTATION_NBRENDERPRSELEMENTS_MAX				16
# define PRESENTATION_NBACTIVEPRSELEMENTS_MAX				32

#endif

#pragma once

#ifndef  _PRS_EVENTS_H_
# define _PRS_EVENTS_H_

# ifndef _EVENTMAN_H__
#  include <eventsystem/eventman.h>
# endif
# ifndef __MESSAGES_H
#  include <kernel/messages.h>
# endif

namespace AP
{
	namespace Events
	{
		// -----------------------------------------------------------------------------------------------------------------------
		class PRSVisibilityEvent : public Axiom::EventMsg
		{
		public:

			EVENT_MSG_GUID( PRSVisibilityEvent );

			Axiom::CRC	mAnimControllerID;
			bool		mVisible;

			PRSVisibilityEvent() : Axiom::EventMsg(EVENT_GUID), 
				mAnimControllerID(0)
			{
			}

			PRSVisibilityEvent(const Axiom::CRC& animControllerID, bool visible) : EventMsg(EVENT_GUID),
				mAnimControllerID(animControllerID),
				mVisible(visible)
			{
			}

		};

		// -----------------------------------------------------------------------------------------------------------------------
		class PRSPanelVisibilityEvent : public Axiom::EventMsg
		{
		public:

			EVENT_MSG_GUID( PRSPanelVisibilityEvent );

			AP_DECLARE_POLYMORPHIC_TYPE();

			bool mSmallPanelsVisible;

			PRSPanelVisibilityEvent() : Axiom::EventMsg(EVENT_GUID), 
				mSmallPanelsVisible(false)
			{
			}

			PRSPanelVisibilityEvent(const bool visible) : EventMsg(EVENT_GUID),
				mSmallPanelsVisible(visible)
			{
			}
		};
	}
}

#endif
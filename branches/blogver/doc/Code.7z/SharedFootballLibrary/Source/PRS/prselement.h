#pragma once


#ifndef _PRSELEMENT_H
#define _PRSELEMENT_H

#ifndef  _PRS_DEFINES_H_
# include "prs/prs_defines.h"
#endif
#ifndef _PRSELEMENTANIMDATA_H
# include "prs/prselementanimdata.h"
#endif
#ifndef __CORE_MATRIX4_H
# include "math/matrix4.h"
#endif

#ifndef __CORE_QUATERNION_H
# include "math/quaternion.h"
#endif
#ifndef __CORE_VECTOR3_H
# include "math/vector3.h"
#endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class PRSElement
		{
		public:

			// Constructor & destructor
			PRSElement(void);
			~PRSElement(void);

			// Operator ==
			PRESENTATION_INLINE bool operator==(const PRSElement&) const;

			// Public methods
			PRESENTATION_INLINE void					SetTransform(const Axiom::Math::Matrix4& transform);
			PRESENTATION_INLINE void					SetRotation(const Axiom::Math::Quaternion& rotation);
			PRESENTATION_INLINE Axiom::Math::Matrix4&	GetTransformRef();
			PRESENTATION_INLINE Axiom::Math::Quaternion& GetRotationRef();

			PRESENTATION_INLINE void					SetData(const PRSElementData&);
			PRESENTATION_INLINE PRSElementData&			GetData();
			PRESENTATION_INLINE void					Reset();

			PRESENTATION_INLINE Axiom::Math::Matrix4	GetTransform();
			PRESENTATION_INLINE Axiom::Math::Quaternion GetRotation();
			PRESENTATION_INLINE float					GetFrame();

			PRESENTATION_INLINE bool					Update(float deltaTime);
			PRESENTATION_INLINE void					BuildTransformMatrix(const Axiom::Math::Vector3& translation, const Axiom::Math::Vector3& scale);

		private:

			Axiom::Math::Matrix4			m_Transform;
			Axiom::Math::Quaternion			m_Rotation;
			float							m_Frame;
			float							m_FrameDirection; // will be +1.0 or -1.0
			PRSElementData					m_PRSElementData;

		};

		// Inlining
#ifdef PRESENTATION_USE_INLINE
# include "prs/prselement.inl"
#endif

	}
}

#endif

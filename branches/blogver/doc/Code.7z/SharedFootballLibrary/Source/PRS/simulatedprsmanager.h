#pragma once

#ifndef  _SIMULATED_PRSMANAGER_H
# define _SIMULATED_PRSMANAGER_H

# ifndef  _PRESENTATION_DEFINES_H_
#  include "presentation/presentation_defines.h"
# endif
# ifndef _PRSELEMENT_H
#  include "prs/prselement.h"
# endif

# ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#  include <collections/list.h>
# endif

namespace SharedSoccer
{
	namespace Presentation
	{
		class PRSElementData;
		class PresentationInput;
		class PresentationOutput;

		class SimulatedPRSManager
		{
		public:

			// Constructor & destructor
			SimulatedPRSManager(void);
			~SimulatedPRSManager(void);

			// Singleton stuff 
			static SimulatedPRSManager*							Init(Axiom::Memory::HeapId);
			static void											Destroy(void);
			PRESENTATION_INLINE static SimulatedPRSManager*		GetInstance(void);

			// Main Methods
			void												AddActiveElement(const PRSElementData& rData,
																				 const bool reset );
			bool												RemoveActiveElement(const Axiom::StripStringCRC &rID);
			bool												RemoveElementAt(int);

			void												Reset(void);
			void												Update(float, const PresentationInput&, PresentationOutput*);

			// Tweak methods
			void												UpdateTimeScale(const Axiom::StripStringCRC& rControllerName, float timeScale);
			void												UpdateStartKeyFrame(const Axiom::StripStringCRC& rControllerName, float startKeyFrame);
			void												UpdateEndKeyFrame(const Axiom::StripStringCRC& rControllerName, float endKeyFrame);
			void												UpdateScale(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Vector3& rScale);
			void												UpdateRotation(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Angle& rRotX, const Axiom::Math::Angle& rRotY, const Axiom::Math::Angle& rRotZ);
			void												UpdateTranslation(const Axiom::StripStringCRC& rControllerName, const Axiom::Math::Vector3& rTranslation);
			void												UpdateLoopType(const Axiom::StripStringCRC& rControllerName, const PRS_LOOP_TYPE_e& rLoopType);
			void												PlayAnimationFromStartFrame(const Axiom::StripStringCRC& rControllerName);

		private:

			// Singleton instance
			static SimulatedPRSManager*												m_pInstance;

			// Local data
			Axiom::Collections::StaticList<PRSElement,
										   PRESENTATION_NBACTIVEPRSELEMENTS_MAX>	m_ActiveElements;

			// Private Methods	
			PRESENTATION_INLINE int		GetIndexOfActivePRSElement(const Axiom::StripStringCRC& rControllerName);

		};

		// Inlining
#ifdef PRESENTATION_USE_INLINE
# include "prs/simulatedprsmanager.inl"
#endif
	}
}

#endif

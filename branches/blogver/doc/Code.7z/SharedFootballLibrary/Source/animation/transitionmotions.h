// TransitionMotions.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _TRANSITIONMOTIONS_H_
#define _TRANSITIONMOTIONS_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/motion.h>
#include <animation/playbackmotion.h>
#include <animation/tag.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{
// --------------------------------------------------------------------------------------------------------------------
struct TransitionInfo
{
	PlaybackInfo mPlaybackData;
	Axiom::TimeAbsolute mStart;
	Axiom::TimeAbsolute mActive;
	Axiom::TimeAbsolute mEnd;
	MotionIndex mOutMotion;

	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class CrossFade : public Motion
{
public:
							CrossFade();

	void					Initialize(const Character*);
	const bool				IsPlayable(const Individual::Ptr&) const;
	void					StartPlayback(Individual::Ptr&) const;
	const bool 				Play(Individual::Ptr&) const;
	void					Serialize(Axiom::Serializer& stream, Character* character);

protected:
	const char*				PlaybackMotion() const;
	void					PlaybackMotion(const char* motionName);
	float					Duration() const;
	void					Duration(const float seconds);
	float					StartPosition() const;
	void					StartPosition(const float seconds);

	Individual::Parameter	mPlaybackData;
	Individual::Parameter	mActivePlaybackData;
	Individual::Parameter	mTransitionData;

	Axiom::Time				mDuration;
	MotionIndex				mPlayback;
	GenericTime				mStartPosition;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class PhaseTransition : public CrossFade
{
public:
							PhaseTransition();

	const bool				IsPlayable(const Individual::Ptr&) const;
	void					StartPlayback(Individual::Ptr&) const;
	void					Serialize(Axiom::Serializer& stream, Character* character);

protected:
	int						StartState() const;
	void					StartState(const int stateId);
	float					StartRegion() const;
	void					StartRegion(const float seconds);
	float					EndRegion() const;
	void					EndRegion(const float seconds);

	AnimStateId				mStartState;
	GenericTime				mGenericStart;
	GenericTime				mGenericEnd;
	Axiom::Time				mRegionStart;
	Axiom::Time				mRegionEnd;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _TRANSITIONMOTIONS_H_

// End of file --------------------------------------------------------------------------------------------------------

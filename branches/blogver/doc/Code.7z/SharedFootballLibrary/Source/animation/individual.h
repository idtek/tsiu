// individual.h - (c) 2007 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _INDIVIDUAL_H_
#define _INDIVIDUAL_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <core/referenced.h>
#include <core/smartptr.h>
#include <animation/recipe.h>
#include <eventsystem/eventMan.h>
#include <GameData/entity.h>

namespace Gel
{
	class Skeleton;
}

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{
class Character;

// --------------------------------------------------------------------------------------------------------------------
class Individual : public Axiom::Referenced
{
public:
	typedef Axiom::SmartPtr<Individual>		Ptr;
	typedef const AP::Reflection::Field*	Parameter;

									Individual();
	virtual							~Individual();

	Axiom::TimeAbsolute				UpdateTime() const; // Time we are advancing to
	Axiom::TimeAbsolute				ActiveTime() const; // Actual time of internal values
	Axiom::Time						ActiveTimeStep() const; // How much time are updating

	void							SetTime(const Axiom::TimeAbsolute& time);

	Recipe&							PoseRecipe(); 
	const Recipe&					PoseRecipe() const; 
	const Character*				GetCharacter() const;
	CharacterIndex					GetCharacterIndex() const;

	void							SetMount(const Gel::Skeleton* skeleton);
	const Gel::Skeleton*			GetMount() const;

	const JointMatrix&				Transform() const;
	void							SetTransform(const JointMatrix& transform);
	const JointMatrix				JointTransform(const int joint, JointMatrix* parent = NULL) const;

	AP::Reflection::Instance		StateData();
	AP::Reflection::Instance		StateData() const;
	const Parameter					FindParameter(const Axiom::StringCRC& name) const;
	template<typename T> T*			GetParameter(const Parameter& parameter) const;

	void							Initialize(const CharacterIndex characterIndex, const AP::Reflection::Type* stateData, SharedSoccer::EntityGUID& PlayerGUID, const Axiom::Memory::HeapId heapId);
	void							Update(const Axiom::TimeAbsolute& updateTime);

	void							SendEvent(Axiom::EventMsg* pEvent);
	SharedSoccer::EntityGUID		GetGUID() const;
	const Axiom::EventMsgBoxHandle & GetMessageBox();

private:
	const bool						Validate() const;
	void							SetCharacter(const CharacterIndex character);
	void							DefineStateData(const AP::Reflection::Type* type, const Axiom::Memory::HeapId heapId);

	friend class Character;
	Axiom::TimeAbsolute				mUpdateTime;	// Review(danc):	Recipe has a start and stop time value, 
	Axiom::TimeAbsolute				mActiveTime;	//					we may want to remove this duplication
	JointMatrix						mTransform;
	Recipe							mPoseRecipe;
	Axiom::EventMsgBoxHandle		mMessageBox;
	SharedSoccer::EntityGUID		mEntityGUID;

	AP::Reflection::AutoInstance	mStateData;
public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#include "animation/source/individual.inl"

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _INDIVIDUAL_H_

// End of file --------------------------------------------------------------------------------------------------------

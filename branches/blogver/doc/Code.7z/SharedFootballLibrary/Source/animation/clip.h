// clip.h - (c) 2006 Action Pants Inc.
// -----------------------------------------------------------------------------

#ifndef _CLIP_H
#define _CLIP_H

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "core/crc.h"
#include "core/time.h"
#include "collections/list.h"
#include "collections/booklet.h" 
#include "animation/animation.h"
#include "animation/generictime.h"
#include "animation/tag.h"

namespace Axiom
{
	class Serializer;
}

namespace Soccer
{
	namespace Animation
	{
		class ClipManager;
		class Skeleton;

		typedef int	ClipId;

		struct ClipTag
		{
			ClipTag() : mKey(-1), mTagId(-1) {}			
			ClipTag(int key, TagId tag) {mKey=key;mTagId=tag;}
			int mKey;
			TagId mTagId;	
			AP_DECLARE_TYPE();
		};

		struct FrameRange
		{
			FrameRange() : mBegin(0), mEnd(0) {}

			FrameRange(unsigned int begin, unsigned int end): 
			mBegin(begin),
				mEnd(end)
			{
				if (mBegin > mEnd)
				{
					unsigned int temp = mBegin;
					mBegin = mEnd;
					mEnd = temp;
				}
			}

			unsigned int mBegin;
			unsigned int mEnd;
			AP_DECLARE_TYPE();

			static const int MAX_NUM_FRAME_RANGE = 10;
		};
		typedef Axiom::Collections::StaticList<FrameRange, FrameRange::MAX_NUM_FRAME_RANGE> FrameRangeList;

		class Clip
		{
		public:
			static const int MAX_NUM_TAGS = 30;

			AP_INLINE const size_t		Size() const			{ return Size(mSkeleton, mNumKeys, mStartJoint, mNumJoints); }
			AP_INLINE const size_t		KeySize() const			{ return KeySize(mSkeleton, mStartJoint, mNumJoints); }
			AP_INLINE const Axiom::Time	Duration() const		{ return mDuration; }
			AP_INLINE const int			NumberOfKeys() const	{ return mNumKeys; }
			AP_INLINE const int			FirstKey() const		{ return 0; }
			AP_INLINE const int			LastKey() const			{ return NumberOfKeys()-1; }
			AP_INLINE const int			NumberOfJoints() const	{ return mNumJoints; }
			AP_INLINE const int			StartJoint() const		{ return mStartJoint; }
			AP_INLINE const Axiom::Time	KeyTime(const int key) const 
			{ 
				AP_ASSERTMESSAGE(0 <= key && key < NumberOfKeys(), "Invalid key index."); 
				return (key * mDuration) / (mNumKeys - 1); 
			}
			AP_INLINE const SkeletonId GetSkeletonID () const { return mSkeleton; }

			void				SetId(ClipId id) {mClipId = id;}
			const ClipId		GetId() const {return mClipId;}
			// Returns the key immediately following the time stamp
			const int			GetNextKey(const Axiom::Time& time) const;

			// Extract a specific joint at time
			const JointMatrix	GetJoint(const int joint, const Axiom::Time& time, const bool mirror = false) const;
			const JointMatrix	GetJoint(const int joint, const int key, const bool mirror = false) const;

			// Extract a joint such that the motion transforms from start time to end time
			const JointMatrix	GetRelativeRootJoint(const Axiom::Time& startTime, const Axiom::Time& endTime, const bool mirror = false, const bool reverse = false) const;

			// Extract all joints at a given time
			void				GetJoints(const Axiom::Time& time, JointMatrix* outputJoints, const bool mirror = false) const;
            void				GetJoints(const GenericTime& time, JointMatrix* outputJoints, const bool mirror = false) const;
			void				GetJoints(const int key, JointMatrix* outputJoints, const bool mirror = false) const;

			// Extract only the given joint and all it's dependencies at a given time
			void				GetRequiredJoints(const int joint, const Axiom::Time& time, JointMatrix* outputJoints, const bool mirror = false) const;
			void				GetRequiredJoints(const int joint, const GenericTime& time, JointMatrix* outputJoints, const bool mirror = false) const;
			void				GetRequiredJoints(const int joint, const int key, JointMatrix* outputJoints, const bool mirror = false) const;

			// Extracts joints such that the motion transforms from start time to end time. 
			void				GetRelativeJoints(const Axiom::Time& startTime, const Axiom::Time& endTime, JointMatrix* outputJoints, const bool mirror = false, const bool reverse = false) const;
			void				GetRelativeRequiredJoints(const int joint, const Axiom::Time& startTime, const Axiom::Time& endTime, JointMatrix* outputJoints, const bool mirror = false, const bool reverse = false) const;

			// tag stuff
			int					NumberOfTags() const;
			bool				AddTag(int key, TagId tagId);
			bool				GetTag(int index, ClipTag& tag) const;
			TagId				GetTagId(int index) const;
			int					GetTagKey(int index) const;
			Axiom::Time			GetTagTime(int index) const;
			void				ClearTags()						{ mTags.Clear(); }
			bool				GetNextKeyWithTag(TagId tagId, int& key, int startKey = 0) const;
			bool				GetNextKeyWithTag(TagId tagId, int& key, const Axiom::Time& startTime = Axiom::Time::Zero()) const;			

			// state stuff
			int					NumberOfStates() const;
			AnimStateId			GetStateId(unsigned int index, const bool mirrored) const;
			int					NumberOfStateFrameRanges(AnimStateId id, const bool mirrored) const;
			const FrameRange*	GetStateFrameRange(AnimStateId id, const bool mirrored, unsigned int index) const;
			void				AddStateFrameRange(AnimStateId id, unsigned int startRange, unsigned int endRange);
			bool				IsStateAtKey(AnimStateId id, const bool mirrored, int key) const;
			bool				IsInFrameRange(const FrameRange* frame, Axiom::Time start, Axiom::Time end) const;
			bool				HasState(AnimStateId id, const bool mirrored) const;
			void				ClearStates();

			// joint reparenting
			unsigned int		NumberOfJointReparents();
			void				SetNumberOfJointReparents(unsigned int size);
			void				AddJointReparent(int joint, int reparent);
			int					GetJointReparent(int joint);
			int					GetReparentingJointAtIndex(unsigned int index);
			int					GetReparentingParentAtIndex(unsigned int index);

			// compression funcs
			static const Axiom::uint				CompressQuatSmallest3(const Axiom::Math::Quaternion& quat);
			static const Axiom::Math::Quaternion	DecompressQuatSmallest3(const Axiom::uint smallest3);

			// not deprecated -- this is used all over the place to create static joint buffers
			static const int MAX_NUM_JOINTS = 75;
		private:
			friend class ClipManager; // Clips can only be created by the ClipManager
			friend Axiom::Serializer& operator&(Axiom::Serializer& stream, Clip*& clip);

			void				SetJointRotation(const int key, const int joint, const float x, const float y, const float z, const float w);
			void				SetJointTranslation(const int key, const int joint, const float x, const float y, const float z);

			const int			JointOffset(const unsigned int joint) const;

			static Clip*		Make(const SkeletonId skeleton, const int numKeys, const float duration, const int startJoint, const int numJoints);
			static const size_t	Size(const SkeletonId skeleton, const int numKeys, const int startJoint, const int numJoints);
			static const size_t	KeySize(const SkeletonId skeleton, const int startJoint, const int numJoints);
			static JointMatrix&	ExtractJoint(const int format, const Axiom::Byte* key, int* startOffset, JointMatrix* matrix);
			static void			MirrorJoint(const int format, JointMatrix& matrix);

			Clip();

			// New clip definition
			ClipId				mClipId;
			SkeletonId			mSkeleton;	// Defines the format for key frame data
			int					mStartJoint; // index into Skeleton joint array for first joint animated by this clip
			unsigned int		mNumJoints; // number of joints animated by the clip
			Axiom::Time			mDuration;	// Duration of the clip
			int					mNumKeys;	// Number of keys
			Axiom::Collections::StaticList<ClipTag, MAX_NUM_TAGS> mTags;
			Axiom::Byte*		mKeys;		// Key frame data

			// states are frame ranges where a state is true -- for example, LeftFootDown
			Axiom::Collections::DynamicBooklet<AnimStateId, FrameRangeList> mStates;

			// joint reparenting
			Axiom::Collections::DynamicBooklet<int, int> mJointReparenting; // Review(danc): Could we use something other then a dynamic collection here?

		// reflection
		public:
			AP_DECLARE_TYPE();
		};
		
	} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _CLIP_H

#ifndef _ANIMATION_GENERICTIME_H
#define _ANIMATION_GENERICTIME_H

#include <core/time.h>

namespace Soccer
{
namespace Animation
{
	class GenericTime
	{
		public:
			GenericTime(const float genericTime = 0.0f) : m_GenericTime(genericTime) { ClampToOne(); }
			GenericTime(const GenericTime& copy) : m_GenericTime(copy.m_GenericTime) {}

			const bool IsInvalid() const { return !IsValid(); }
			const bool IsValid() const  { return m_GenericTime >= 0.0f && m_GenericTime <= 1.0f; }
			const bool IsStillPlaying() const  { return m_GenericTime >= 0.0f && m_GenericTime <= 1.0f; }
			const bool HasCompleted() const  { return m_GenericTime >= 1.0f; }

			GenericTime& ReturnToRange()
			{
				while (m_GenericTime > 1.0f)
				{
					m_GenericTime -= 1.0f;
				}
				while (m_GenericTime < 0.0f)
				{
					m_GenericTime += 1.0f;
				}

				return *this;
			}

			GenericTime& ClampToOne()
			{
				m_GenericTime = Axiom::Math::FClamp(m_GenericTime, 0.f, 1.f);
				return *this;
			}

			const float AsFloat() const { return m_GenericTime; }

			GenericTime& operator=(const GenericTime& rhs) { m_GenericTime = rhs.m_GenericTime; return *this; }

			GenericTime operator+(const GenericTime& rhs) const { return GenericTime(m_GenericTime + rhs.m_GenericTime); }
			GenericTime operator-(const GenericTime& rhs) const { return GenericTime(m_GenericTime - rhs.m_GenericTime); }

			GenericTime& operator+=(const GenericTime& rhs) { m_GenericTime += rhs.m_GenericTime; return *this; }
			GenericTime& operator-=(const GenericTime& rhs) { m_GenericTime -= rhs.m_GenericTime; return *this; }

			const bool operator==(const GenericTime& rhs) const { return m_GenericTime == rhs.m_GenericTime; }
			const bool operator!=(const GenericTime& rhs) const { return m_GenericTime != rhs.m_GenericTime; }
			const bool operator< (const GenericTime& rhs) const { return m_GenericTime <= rhs.m_GenericTime; }
			const bool operator<=(const GenericTime& rhs) const { return m_GenericTime <= rhs.m_GenericTime; }
			const bool operator> (const GenericTime& rhs) const { return m_GenericTime > rhs.m_GenericTime; }
			const bool operator>=(const GenericTime& rhs) const { return m_GenericTime >= rhs.m_GenericTime; }
			static const GenericTime& Invalid() { static const GenericTime sInvalid(0.f, 0.f); return sInvalid; }
			static const GenericTime& Zero() { static const GenericTime sZero(0.0f); return sZero;  }
			static const GenericTime& One() { static const GenericTime sOne(1.0f); return sOne;  }

			friend Axiom::Time operator*(const GenericTime& lhs, const float rhs);
			friend Axiom::Time operator*(const float lhs, const GenericTime& rhs);
			friend Axiom::Time operator*(const GenericTime& lhs, const Axiom::Time& rhs);
			friend Axiom::Time operator*(const Axiom::Time& lhs, const GenericTime& rhs);
			friend Axiom::Serializer& operator& (Axiom::Serializer& stream, GenericTime& t);

		private:
			explicit GenericTime( float, float) : m_GenericTime(-1.f) {}
		protected:
			float		m_GenericTime;

		public:
			AP_DECLARE_TYPE();
	};

	inline Axiom::Time operator*(const GenericTime& lhs, const float rhs)
	{
		return Axiom::Time::CreateFromSeconds(lhs.m_GenericTime * rhs);
	}

	inline Axiom::Time operator*(const GenericTime& lhs, const Axiom::Time& rhs)
	{
		return lhs.m_GenericTime * rhs;
	}

	inline Axiom::Time operator*(const float lhs, const GenericTime& rhs)
	{
		return Axiom::Time::CreateFromSeconds(lhs * rhs.m_GenericTime);
	}

	inline Axiom::Time operator*(const Axiom::Time& lhs, const GenericTime& rhs)
	{
		return lhs * rhs.m_GenericTime;
	}

} // namespace Animation
} // namespace Soccer

#endif

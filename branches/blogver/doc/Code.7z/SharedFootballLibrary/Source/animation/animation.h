// animation.h - (c) 2006 Action Pants Inc.
// -----------------------------------------------------------------------------

#ifndef _ANIMATION_H
#define _ANIMATION_H

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <math/apmath.h>
#include <math/rigidmatrix.h>

#if !CORE_FINAL
//	#define DEBUG_ANIMATION_PARAMETERS 1
//	#define DEBUG_ANIMATION_SWITCH 1
#endif

namespace Axiom
{
	class Serializer;
	class Time;
	namespace Math
	{
		class Vector3;
		class Quaternion;
		class RigidMatrix;
	} // namespace Math
} // namespace Axiom

namespace Soccer
{
	namespace Animation 
	{
		class GenericTime;

		static const int INVALID_ID = -1;
		typedef int					ClipId; // Review(danc): this id does not use the same simantics as CharacterId and motionId we should fix this.
		typedef Axiom::StringCRC	CharacterName;
		typedef Axiom::CRC			CharacterId;
		typedef int					CharacterIndex;
		typedef Axiom::StringCRC	MotionName;
		typedef Axiom::CRC			MotionId;
		typedef int					MotionIndex;

		// ---------------------------------------------------------------------
		//typedef int	SkeletonId;
		class SkeletonId
		{
		public:
			SkeletonId(const int id = -1) : mId(id) {}
			const bool IsValid() const	{ return -1 != mId; }
			const int Value() const		{ return mId; }

		private:
			void Value(const int id)	{ mId = id; }
			int mId;

			friend Axiom::Serializer& operator& (Axiom::Serializer& stream, SkeletonId& id);
		public:
			AP_DECLARE_TYPE();
		};

		// ---------------------------------------------------------------------
		static const int kMaximumAnimatableEntities = 20;
		typedef Axiom::Math::RigidMatrix	JointMatrix;
		typedef Axiom::Math::Quaternion		JointQuaternion;
		typedef Axiom::Math::Vector3		JointVector3;
		typedef Axiom::Math::Vector2		JointVector2;

		static const Axiom::Math::Vector3 DEFAULT_FACING(0.f, -1.f, 0.f);

		Axiom::Math::Angle			AngleBetweenXY(const Axiom::Math::Vector3& v1, const Axiom::Math::Vector3& v2); // Angles should be negitive if CC and positive if CW
		Axiom::Math::Angle			AngleBetweenXY(const Axiom::Math::Vector2& v1, const Axiom::Math::Vector2& v2); // Angles should be negitive if CC and positive if CW
		Axiom::Time					Blend(const float fraction, const Axiom::Time& t1, const Axiom::Time& t2);
		Axiom::Math::Angle			Blend(const float fraction, const Axiom::Math::Angle& a1, const Axiom::Math::Angle& a2);
		Axiom::Math::RigidMatrix	Blend(const float fraction, const Axiom::Math::RigidMatrix& q1, const Axiom::Math::RigidMatrix& q2);
		Axiom::Math::Quaternion		Blend(const float fraction, const Axiom::Math::Quaternion& q1, const Axiom::Math::Quaternion& q2);
		Axiom::Math::Vector3		Blend(const float fraction, const Axiom::Math::Vector3& q1, const Axiom::Math::Vector3& q2);
		float						Blend(const float fraction, const float& q1, const float& q2);
		void						Log(const char* format, ...);

		Axiom::Serializer& operator& (Axiom::Serializer& stream, SkeletonId& id);
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Time& t);
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Math::Vector2& v);
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Math::Angle& a);
	} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _ANIMATION_H


// AdaptStateExtentions.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _ADAPTSTATEEXTENTIONS_H_
#define _ADAPTSTATEEXTENTIONS_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <StEdFast/Scripts/ConditionScript.h>
#include <StEdFast/Scripts/StateScript.h>
#include <StEdFast/Scripts/Data.h>
#include <StEdFast/Scripts/ThisData.h>
#include <animation/animation.h>
#include <eventsystem/eventman.h>
#include <eventsystem/eventmsgbox.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
class Individual;
class IndividualData : public AP::StEdFast::ThisData
{
public:
	IndividualData();
	IndividualData(const IndividualData&);
	explicit IndividualData(int guid);
	virtual ~IndividualData();

	IndividualData& operator=(const IndividualData&);

	Individual* GetIndividual() const			{ return mIndividual; }
	void SetIndividual(Individual* individual)	{ mIndividual = individual; }

protected:
	Individual* mIndividual;
};

// --------------------------------------------------------------------------------------------------------------------
class StEdFastAdaptStateData : public AP::StEdFast::DefaultData<IndividualData, 1>
{
public:
	StEdFastAdaptStateData();
	virtual ~StEdFastAdaptStateData();

protected:
	StEdFastAdaptStateData(const StEdFastAdaptStateData&); // Not implemented
	StEdFastAdaptStateData& operator=(const StEdFastAdaptStateData&); // Not implemented
};

// --------------------------------------------------------------------------------------------------------------------
class IsPlayableMotion : public AP::StEdFast::Condition
{
public:
	IsPlayableMotion();
	~IsPlayableMotion();

	void Init(const Axiom::StringCRC& motionName); 
	bool Evaluate(const AP::StEdFast::ConditionParameters& conditionParameters) const;

protected:
	const char*	MotionName() const;
	void		MotionName(const char* name);

	Axiom::StringCRC mMotionName;

	IsPlayableMotion(const IsPlayableMotion&); // Not implemented
	IsPlayableMotion& operator=(const IsPlayableMotion&) { AP_ASSERTFAIL("Not implemented"); return *this; }

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class PlayMotion : public AP::StEdFast::Track
{
public:
	PlayMotion();

	void Init(const Axiom::StringCRC& motionName); 

	void OnPlay(const AP::StEdFast::TrackParameters& trackParameters) const;
	AP::StEdFast::EPlayStatus Play(const Axiom::Time& timePlaying, const AP::StEdFast::TrackParameters& trackParameters) const;
	void OnInterrupted(const AP::StEdFast::TrackParameters& trackParameters) const;
	void OnDone(const AP::StEdFast::TrackParameters& trackParameters) const;

protected:
	const char*	MotionName() const;
	void		MotionName(const char* name);

	Axiom::StringCRC mMotionName;

	PlayMotion(const PlayMotion&); // Not implemented
	PlayMotion& operator=(const PlayMotion&) { AP_ASSERTFAIL("Not implemented"); return *this; }

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _ADAPTSTATEEXTENTIONS_H_

// End of file --------------------------------------------------------------------------------------------------------

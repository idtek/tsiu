// motion.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _MOTION_H_
#define _MOTION_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/individual.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Axiom
{
class Serializer;
}
namespace Soccer
{
namespace Animation
{
class Recipe;

// --------------------------------------------------------------------------------------------------------------------
class Motion
{
public:
	const Axiom::StringCRC&	Name() const;
	const Axiom::CRC&		HashName() const;

	virtual void			Initialize(const Character* character) {}	// Acquire character specific data
	virtual void			InitializeIndividual(Individual::Ptr&) const {}	// Initialize individual data
	virtual const bool		IsPlayable(const Individual::Ptr&) const = 0; // Is this motion playable
	virtual void			StartPlayback(Individual::Ptr&) const {} // Do you need to initialize anything before we start playing
	virtual const bool 		Play(Individual::Ptr&) const = 0; // Return value indicates if the motion is still playable (ie Play() == IsPlayable())
	virtual void			Serialize(Axiom::Serializer& stream, Character* character); // Serialize required information.  

protected:
							Motion() : mName("NoName") { /*AP_ASSERTFAIL("Should not be implemented");*/ } // Should have an empty implementation
	virtual					~Motion() {}
	explicit				Motion(const Axiom::StringCRC& name);

	void					SetName(const char* name);
	const char*				GetName() const;

	// Warning: The FindCharacter() calls are expensive, do not them when you have an Individual::Ptr!
	Character*				FindCharacter();
	const Character*		FindCharacter() const;

	void					SerializeParameter(Axiom::Serializer& stream, const Character* character, Individual::Parameter& parameter);

private:
	Axiom::StringCRC		mName;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
class MotionList : public Motion
{
public:
	const bool		IsPlayable(const Individual::Ptr&) const;
	void			StartPlayback(Individual::Ptr&) const;
	const bool 		Play(Individual::Ptr&) const;
	void			Serialize(Axiom::Serializer& stream, Character* character);

	unsigned		NumberOfMotions() const;
	void			AddMotion(const Axiom::StringCRC& name);

protected:
	void			AddMotionByName(const char* name);

	Axiom::Collections::StaticList<MotionIndex, 10> mMotions;	// Review(danc): We may want to use a DynamicList<> here.

public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
struct CompositeInfo
{
	CompositeInfo() : depth(0) 
	{ 
		for (int i = 0; i < array_count(childStack); ++i) 
		{ 
			childStack[i] = -1; 
		} 
	}

	int childStack[5];	// What is the child index at this depth
	int depth;			// How deep are we currently in the DAG

	int	GetActive() const { return childStack[depth]; }
	void SetActive(const int index) 
	{ 	
		AP_ASSERT(0 <= depth && depth < static_cast<int>(array_count(childStack)));
		childStack[depth] = index;
	}

	void Push()	{ ++depth; AP_ASSERT(depth < static_cast<int>(array_count(childStack))); }
	void Pop()	{ --depth; AP_ASSERT(0 <= depth); }
	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class CompositeMotion : public Motion
{
public:
	static const int MAX_MOTIONS = 32;
	typedef Axiom::Collections::StaticList<MotionIndex, MAX_MOTIONS> SubMotionList;
					CompositeMotion();
	void			Initialize(const Character*);
	const bool		IsPlayable(const Individual::Ptr&) const;
	void			StartPlayback(Individual::Ptr&) const;
	const bool 		Play(Individual::Ptr&) const;
	void			Serialize(Axiom::Serializer& stream, Character* character);

	unsigned		NumberOfMotions() const;
	void			AddMotion(const Axiom::StringCRC& name);

protected:
	const bool			PlayMotion(CompositeInfo* info, const Motion* motion, Individual::Ptr& individual) const;
	void				SelectMotion(Individual::Ptr& individual) const;
	virtual const int	PlayableIndex(const Individual::Ptr&) const;
	void				AddMotionByName(const char* name);

	
	SubMotionList			mMotions; // Review(danc): We may want to use a DynamicList<> here.
	Individual::Parameter	mCompositeData;
	bool					mSwitchable;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
class RandomCompositeMotion : public CompositeMotion
{
public:
protected:
	const int		PlayableIndex(const Individual::Ptr&) const;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class SequentialMotion : public CompositeMotion
{
public:
	void 			StartPlayback(Individual::Ptr& individual) const;
	
protected:
	const int		PlayableIndex(const Individual::Ptr&) const;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class RandomPlayMotion : public Motion
{
public:
	RandomPlayMotion();

	const bool		IsPlayable(const Individual::Ptr&) const;
	void			StartPlayback(Individual::Ptr&) const;
	const bool 		Play(Individual::Ptr&) const;
	void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
	const char* 	SubMotion() const;
	void			SubMotion(const char* motionName);

	float			mChanceForPlay; // 0.0f to 1.0f
	MotionIndex		mSubMotion;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#include <animation/source/motion.inl>

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _MOTION_H_

// End of file --------------------------------------------------------------------------------------------------------

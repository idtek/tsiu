// clipmanager.h - (c) 2006 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _CLIPMANAGER_H
#define _CLIPMANAGER_H

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "core/singleton.h"
#include "core/autopointer.h"
#include "collections/array.h"

#include "animation/animation.h"
#include "animation/skeleton.h"
#include "animation/clip.h"
#include <math/vector2.h>

#include "core/classedenum.h"


namespace Soccer
{
	namespace Animation
	{
		// ------------------------------------------------------------------------------------------------------------
		class ClipManager : public Axiom::Singleton<ClipManager>
		{
			AP_NON_COPYABLE(ClipManager); 

		public:
			AP_DECLARE_TYPE();

			// Skeleton Management
			SkeletonId		NewSkeleton(const char* name, const int numJoints);
			SkeletonId		FindSkeleton(const char* name) const;
			const int		NumSkeletons() const { return static_cast<int>(mSkeletonSet.Size()); }
			const Skeleton*	GetSkeleton(const SkeletonId id) const { return mSkeletonSet[id.Value()]; }

			// Clip Management
			ClipId			NewClip(const char* name, const char* skeleton, const int numKeys, const float duration);
			ClipId			NewClipV2(const char* name, const char* skeleton, const int numKeys, const float duration, const int startJoint, const int numJoints);
			ClipId			FindClip(const char* name) const;
			const int		NumClips() const { return static_cast<int>(mClipSet.Size()); }
			const Clip*		GetClip(const ClipId id) const { return mClipSet[id].mPointer; }
			Clip*			GetWritableClip(const ClipId id) { return mClipSet[id].mPointer; }

			friend Axiom::Serializer& operator&(Axiom::Serializer& stream, ClipManager& clipmanager);

			void			Clear();
			void			Delete(const ClipId i);
			const char*		ClipName(const ClipId i) const { return mClipSet[i].mName.AsChar(); }

			// Parameter interface
			float			GetSpeed(const ClipId clipId, const bool mirrored) const;
			float			GetSpeedByName(const char* name, const bool mirrored) const;
			float			GetDisplacement(const ClipId clipId, const bool mirrored) const;
			float			GetDisplacementByName(const char* name, const bool mirrored) const;
			float			GetTurningRate(const ClipId clipId, const bool mirrored) const;
			float			GetTurningRateByName(const char* name, const bool mirrored) const;
			float			GetTurningAngle(const ClipId clipId, const bool mirrored) const;
			float			GetTurningAngleByName(const char* name, const bool mirrored) const;
			Axiom::Math::Vector3	GetOffsetToJoint(const ClipId clipId, const bool mirrored, const float position, const int joint) const;
			Axiom::Math::Vector3	GetOffsetToJointByName(const char* name, const bool mirrored, const float position, const char* jointName) const;
			Axiom::Math::Vector2	GetMovementDirection(const ClipId clipId, const bool mirrored) const;
			Axiom::Math::Vector2	GetMovementDirectionByName(const char* name, const bool mirrored) const;
			JointMatrix		GetTransformAtTime(const ClipId clipId, const bool mirrored, const Axiom::Time& time) const;
			JointMatrix		GetTransformAtTimeByName(const char* name, const bool mirrored, const Axiom::Time& time) const;
			JointMatrix		GetStartTransform(const ClipId clipId, const bool mirrored, const int joint) const;
			JointMatrix		GetStartTransformByName(const char* name, const bool mirrored, const char* jointName) const;
			Axiom::Time		GetTagTime(const ClipId clipId, TagId min, TagId max, int whichContact) const;
			Axiom::Time		GetTagTimeByName(const char* name, TagId min, TagId max, int whichContact) const;
			Axiom::Time		GetDuration(const ClipId clipId) const;
			Axiom::Time		GetDurationByName(const char* name) const;
			GenericTime		TimeToGenericTime(const ClipId clipId, const Axiom::Time& time) const;
			GenericTime		TimeToGenericTimeByName(const char* name, const float seconds) const;
			GenericTime		GetStateStartPosition(const ClipId clipId, const bool mirrored, AnimStateId state, int whichContact) const;
			GenericTime		GetStateStartPositionByName(const char* name, const bool mirrored, AnimStateId state, int whichContact) const;

			const Clip&		operator[](const ClipId i) const	{ return *mClipSet[i].mPointer; }
			

			int 			GetNumTagTypes() const;
			TagId 			GetTagValueByIndex(int index) const;
			const char*		GetTagTypeNameByIndex(int index) const;			
			int				GetTagIndexByTagId(TagId tagId) const;
			const char*		GetTagTypeName(TagId tagId) const;

			static void		InitAnimStatesAndTags();
			int				GetNumAnimStateTypes() const;
			AnimStateId		GetAnimStateValueByIndex(int index) const;
			const char*		GetAnimStateTypeNameByIndex(int index) const;
			int				GetAnimStateIndexById(AnimStateId animStateId) const;
			const char*		GetAnimStateTypeName(AnimStateId animStateId) const;

		private:
			friend class Axiom::Singleton<ClipManager>;
			ClipManager();
			~ClipManager();

			// --------------------------------------------------------------------------------------------------------
			template <typename T>
			struct NamedAutoPointer
			{
				NamedAutoPointer() {}
				NamedAutoPointer(const NamedAutoPointer<T>& c)
					: mName(c.mName), mPointer(c.mPointer)
				{}
				explicit NamedAutoPointer(const Axiom::StringCRC& name, T* clip)
					: mName(name), mPointer(clip)
				{}
				Axiom::StringCRC mName;
				Axiom::AutoPointer<T> mPointer;
			};

			friend Axiom::Serializer& operator&(Axiom::Serializer& stream, Skeleton& clipCard);
			typedef Axiom::Collections::Array< Axiom::AutoPointer<Skeleton> > SkeletonLibrary; // Remove Array< AutoPointer<Skeleton> > and use a map
			SkeletonLibrary mSkeletonSet; 

			typedef NamedAutoPointer<Clip> NamedClip;
			friend Axiom::Serializer& operator&(Axiom::Serializer& stream, NamedClip& clipCard);
			static Axiom::Serializer& ClipV3(Axiom::Serializer& stream, Clip*& clip);
			static Axiom::Serializer& ClipV4(Axiom::Serializer& stream, Clip*& clip);
			typedef Axiom::Collections::Array<NamedClip> ClipLibrary; // Remove Array<NamedClip> and use a map
			ClipLibrary mClipSet;
		};
	} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _CLIPMANAGER_H

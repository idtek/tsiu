// nismotion.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------
#pragma once

#ifndef _NISMOTION_H_
#define _NISMOTION_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/individual.h>
#include <animation/motion.h>
#include <animation/playbackmotion.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
class NISMotion : public Motion
{
public:
	/*virtual*/ void			Initialize(const Character*);
	/*virtual*/ const bool		IsPlayable(const Individual::Ptr&) const;
	/*virtual*/ void			StartPlayback(Individual::Ptr&) const;
	/*virtual*/ const bool 		Play(Individual::Ptr&) const;

protected:

	Individual::Parameter		mAnimName;
	Individual::Parameter		mForceStart;
	Individual::Parameter		mPlaybackComplete;
public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
class InitialOffsetMotion : public Motion
{
public:
								InitialOffsetMotion ();
	/*virtual*/ void			Initialize(const Character*);
	/*virtual*/ const bool		IsPlayable(const Individual::Ptr&) const;
	/*virtual*/ void			StartPlayback(Individual::Ptr&) const;
	/*virtual*/ const bool 		Play(Individual::Ptr&) const;
	/*virtual*/ void			Serialize(Axiom::Serializer& , Character* );

protected:
	const char*					SubMotion() const;
	void						SubMotion(const char*);

	JointMatrix					mOffset;
	MotionIndex					mSubMotion;
public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
class CharacterPlayback : public Playback
{
public:
	/*virtual*/ void			Initialize(const Character*);
	/*virtual*/ const bool		IsPlayable(const Individual::Ptr&) const;
	/*virtual*/ void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
	const char*					CharacterName() const;
	void						CharacterName(const char* name);

	Individual::Parameter		mCharacterNameParameter;
	Axiom::StringCRC			mCharacterName;
public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};


// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#include <animation/source/nismotion.inl>

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _NISMOTION_H_

// End of file --------------------------------------------------------------------------------------------------------

// character.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _CHARACTER_H_
#define _CHARACTER_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <core/autopointer.h>
#include <core/singleton.h>
#include <collections/list.h>
#include <animation/animation.h>
#include <animation/individual.h>

class ResourceHandle;

// --------------------------------------------------------------------------------------------------------------------
namespace Gel
{
class Skeleton;
}
namespace Axiom
{
class Serializer;
}

namespace Soccer
{
namespace Animation
{
class Motion;
class Skeleton;

// --------------------------------------------------------------------------------------------------------------------
// Motion list is a hash table based on motion names
class MotionTable
{
public:
					MotionTable();
					~MotionTable();

	const unsigned	Count() const;
	const unsigned	Capacity() const;

	const bool		IsEmpty() const;
	const bool		IsFull() const;

	void			Clear(); 
	void			IncreaseAndRehash(Axiom::Memory::HeapId heapId, const unsigned capacity);
	void			IncreaseAdd(Axiom::Memory::HeapId heapId, AP::Reflection::AutoInstance& motion);

	void			Add(AP::Reflection::AutoInstance& motion);
	void			Rehash(const MotionId& oldHash, const MotionId& newHash); // Searches for the hash name given and re-add's the element to the table

	const int		IndexOf(const MotionId& hash) const;
	Motion*			At(const MotionId& hash);
	const Motion*	At(const MotionId& hash) const;
	Motion*&		At(const unsigned index);
	const Motion*&	At(const unsigned index) const;

	Motion*&		operator[](const unsigned index);
	const Motion*&	operator[](const unsigned index) const;

protected:

	int				Hash(const MotionId& hash) const;
	int				AtIndex(const MotionId& hash) const;
	const bool		EmptySlot(const unsigned index) const;

	struct TableNode
	{
					TableNode() : mIndex(static_cast<unsigned>(-1)) {}
					TableNode(const int index) : mIndex(index) {}
		const bool	IsValid() const { return static_cast<unsigned>(-1) != mIndex; }

		unsigned	mIndex;
	};
	typedef Axiom::AutoPointer<TableNode> SmartIndex;
	typedef Axiom::AutoPointer<AP::Reflection::AutoInstance> SmartData;

	SmartData		mData;
	SmartIndex		mIndex;
	unsigned		mCount;
	unsigned		mCapacity;

public:
	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class Character
{
public:
	const CharacterName&	Name() const;
	const CharacterId&		HashName() const;

	Individual::Ptr			CreateIndividual(SharedSoccer::EntityGUID& PlayerGUID, const Axiom::Memory::HeapId heapId) const;
	const Recipe&			Update(Individual::Ptr&) const;

	const Individual::Parameter	FindParameter(const Axiom::CRC& name) const;

	const Skeleton*			GetSkeleton() const;
	void					SetSkeleton(const Axiom::StringCRC& skeletonName);

	const MotionIndex		FindMotion(const MotionId& id) const;
	// get motion by Index
	Motion*					GetMotion(const MotionIndex& id);
	const Motion*			GetMotion(const MotionIndex& id) const;
	// get motion by Id (uses FindMotion)
	Motion*					GetMotion(const MotionId& id);
	const Motion*			GetMotion(const MotionId& id) const;

	
	const unsigned			NumberOfMotions() const;
	Motion*					operator[](const int index);
	const Motion*			operator[](const int index) const;

	friend Axiom::Serializer& operator&(Axiom::Serializer& stream, Character& character);
protected:
	Character();
	AP_NON_COPYABLE(Character);

private:
	void					Initialize();
	void					InitializeIndividual(Individual::Ptr&);

	const char*				SkeletonName() const;
	void					SkeletonName(const char* skeletonName);
	const char*				CharacterName() const;
	void					CharacterName(const char* characterName);
	const char*				DAGRootName() const;
	void					DAGRootName(const char* motionName);
	const char*				IndividualTypeName() const;
	void					IndividualTypeName(const char* typeName);
	const int				FindIndex(const char* motionName);
	const bool				Validate(Individual::Ptr&) const;
	friend class Motion;
	friend class Individual;
	friend class CharacterLibrary;

	Animation::CharacterName	mName;
	SkeletonId				mSkeleton;
	const AP::Reflection::Type*	mIndividualType;
	MotionIndex				mDAGRoot;
	MotionTable				mMotions;

public:
	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class CharacterLibrary : public Axiom::Singleton<CharacterLibrary>
{
	AP_NON_COPYABLE(CharacterLibrary)
public:
							CharacterLibrary();
	CharacterIndex			FindCharacter(const CharacterId& characterName) const;

	unsigned				NumberOfCharacters() const;
	Character*				GetCharacter(const CharacterIndex id);
	const Character*		GetCharacter(const CharacterIndex id) const;

	Character*				operator[](const CharacterIndex& id);
	const Character*		operator[](const CharacterIndex& id) const;

	void					Clear();
	void					Remove(const CharacterIndex index);

	friend Axiom::Serializer& operator&(Axiom::Serializer& stream, CharacterLibrary& characterLibrary);
protected:
	CharacterIndex			Find(const char* characterName) const;

	typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer<Character> > CharacterList;
	CharacterList			mCharacters;

public:
	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _CHARACTER_H_

// End of file --------------------------------------------------------------------------------------------------------

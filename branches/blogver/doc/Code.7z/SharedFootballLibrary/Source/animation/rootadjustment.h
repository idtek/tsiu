// RootAdjustment.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _ROOT_ADJUSTMENT_H_
#define _ROOT_ADJUSTMENT_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/motion.h>
#include <math/vector2.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{
struct PlaybackInfo;

// --------------------------------------------------------------------------------------------------------------------
struct RootAdjustmentInfo
{
	JointMatrix			mFinalTransform;
	JointMatrix			mActiveTransform;
	Axiom::TimeAbsolute	mStartTime;
	Axiom::TimeAbsolute	mEndTime;

	Axiom::Math::Vector2 mCachedDirection;

	inline const bool IsAdjusting(const Individual::Ptr& individual) const 
	{ 
		return mStartTime < mEndTime && mStartTime <= individual->UpdateTime() && individual->ActiveTime() <= mEndTime; 
	}

	inline void InvalidateAdjustment()
	{
		mEndTime = mStartTime;
	}

	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
//RootAdjustment class only allows setting up once per cycle. we need to eb able to change goal every frame.
class ContinuousRootAdjustment : public Motion
{
public:
							ContinuousRootAdjustment();
	virtual void			Initialize(const Character*);
	virtual const bool		IsPlayable(const Individual::Ptr&) const;
	virtual void			StartPlayback(Individual::Ptr&) const;
	virtual const bool 		Play(Individual::Ptr&) const; 
	virtual void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
	RootAdjustmentInfo*		GetAdjustmentData(Individual::Ptr&) const;
	PlaybackInfo*			GetPlaybackData(Individual::Ptr&) const;
	const Motion*			GetPlaybackMotion(const Individual::Ptr&) const;
	const char*				AngleParameter() const;
	void					AngleParameter(const char* name);
	const char*				SpeedParameter() const;
	void					SpeedParameter(const char* name);
	const char*				PlaybackMotion() const;
	void					PlaybackMotion(const char* name);
	float					AdjustmentRate() const;
	void					AdjustmentRate(float degrees);
	float					PlaybackAngle() const;
	void					PlaybackAngle(float degrees);

	Individual::Parameter	mAdjustmentCache;
	Individual::Parameter	mPlaybackCache;
	Individual::Parameter	mTurningAngle;
	Individual::Parameter	mSpeedValue;
	Axiom::Math::Angle		mPlaybackAngle;
	float					mMax;//angles
	float					mMin;
	float					mMinSpeed;

	MotionIndex				mPlayback;
	Axiom::Math::Angle		mAdjustmentRate;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
//RootAdjustment class only allows setting up once per cycle. we need to eb able to change goal every frame.
class PivotRootAdjustment : public ContinuousRootAdjustment
{
public:
	PivotRootAdjustment();
	virtual void			Initialize(const Character*);
	virtual void			StartPlayback(Individual::Ptr&) const;
	virtual const bool 		Play(Individual::Ptr&) const; 
	virtual void			Serialize(Axiom::Serializer& stream, Character* character);

protected:

	Individual::Parameter	mMovementDirection;
	Individual::Parameter	mDesiredMovementDirection;
	float					mOffsetTime;


public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class RootAdjustment : public Motion
{
public:
							RootAdjustment();

	virtual void			Initialize(const Character*);
	virtual const bool		IsPlayable(const Individual::Ptr&) const;
	virtual void			StartPlayback(Individual::Ptr&) const;
	virtual const bool 		Play(Individual::Ptr&) const; 
	virtual void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
	virtual void			CalculateAdjustment(Individual::Ptr&, RootAdjustmentInfo*) const = 0;

	RootAdjustmentInfo*		GetAdjustmentData(Individual::Ptr&) const;
	const RootAdjustmentInfo*	GetAdjustmentData(const Individual::Ptr&) const;
	PlaybackInfo*			GetPlaybackData(Individual::Ptr&) const;
	const PlaybackInfo*		GetPlaybackData(const Individual::Ptr&) const;
	const Motion*			GetPlaybackMotion(const Individual::Ptr&) const;
	const char*				PlaybackMotion() const;
	void					PlaybackMotion(const char* name);

	Individual::Parameter	mAdjustmentCache;
	Individual::Parameter	mPlaybackCache;
	MotionIndex				mPlayback;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class TurningAngleAdjustment : public RootAdjustment
{
public:
							TurningAngleAdjustment();
	virtual const bool		IsPlayable(const Individual::Ptr&) const;
	virtual const bool 		Play(Individual::Ptr&) const; 
	virtual void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
	virtual void			CalculateAdjustment(Individual::Ptr&, RootAdjustmentInfo*) const;
	const char*				PlaybackMotion() const;
	void					PlaybackMotion(const char* name);
	const char*				AngleParameter() const;
	void					AngleParameter(const char* name);
	float					PlaybackAngle() const;
	void					PlaybackAngle(float degrees);

	Individual::Parameter	mTurningAngle;
	MotionIndex				mPlayback;
	Axiom::Math::Angle		mPlaybackAngle;
	float					mDuration;
	float					mMax;
	float					mMin;
	bool					mIsEntryCondition;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _ROOT_ADJUSTMENT_H_

// End of file --------------------------------------------------------------------------------------------------------

// motion.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------
#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/nismotion.h>
#include <animation/character.h>
#include <animation/playbackmotion.h>
#include <core/serializer.h>
#include <math/mathserializer.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{
// class NISMotion ----------------------------------------------------------------------------------------------------
AP_TYPE(NISMotion)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
void NISMotion::Initialize(const Character* character)
{
	mAnimName			= character->FindParameter("AnimName");
	mForceStart			= character->FindParameter("ForceStart");
	mPlaybackComplete	= character->FindParameter("PlaybackComplete");
}

// --------------------------------------------------------------------------------------------------------------------
const bool NISMotion::IsPlayable(const Individual::Ptr& individual) const
{
	UNUSED_PARAM(individual);
	return true;
}

// --------------------------------------------------------------------------------------------------------------------
void NISMotion::StartPlayback(Individual::Ptr& individual) const
{
	UNUSED_PARAM(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const bool NISMotion::Play(Individual::Ptr& individual) const
{
	const Axiom::StringCRC& motionName = *(individual->GetParameter<Axiom::StringCRC>(mAnimName));
	const Character* character = individual->GetCharacter();
	const MotionIndex motionIndex = character->FindMotion(motionName);

	if (motionIndex < 0)
	{
		return false;
	}

	const Motion* motion = character->GetMotion(motionIndex);
	bool& forceStart = *(individual->GetParameter<bool>(mForceStart));
	if (forceStart)
	{
		motion->StartPlayback(individual);
		forceStart = false;
	}

	bool& playbackComplete = *(individual->GetParameter<bool>(mPlaybackComplete));
	playbackComplete = !motion->Play(individual);
	return playbackComplete;
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(InitialOffsetMotion)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)
	AP_FIELD_USERDEBUG("Offset", mOffset, "How much to we offset the animation for we start.")
	AP_PROPERTY_USERDEBUG("Playback", SubMotion, SubMotion, "")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
InitialOffsetMotion::InitialOffsetMotion()
: mOffset(JointMatrix::IDENTITY)
, mSubMotion(Animation::INVALID_ID)
{
}

// --------------------------------------------------------------------------------------------------------------------
void InitialOffsetMotion::Initialize(const Character*)
{
}

// --------------------------------------------------------------------------------------------------------------------
const bool InitialOffsetMotion::IsPlayable(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	AP_ASSERT(Animation::INVALID_ID != mSubMotion);
	const Motion* subMotion = (*character)[mSubMotion];
	return subMotion->IsPlayable(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void InitialOffsetMotion::StartPlayback(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	AP_ASSERT(Animation::INVALID_ID != mSubMotion);
	const Motion* subMotion = (*character)[mSubMotion];
	subMotion->StartPlayback(individual);

	individual->SetTransform( mOffset * individual->Transform() );
}

// --------------------------------------------------------------------------------------------------------------------
const bool InitialOffsetMotion::Play(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	AP_ASSERT(Animation::INVALID_ID != mSubMotion);
	const Motion* subMotion = (*character)[mSubMotion];
	return subMotion->Play(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void InitialOffsetMotion::Serialize(Axiom::Serializer& stream, Character* character)
{
	Motion::Serialize(stream, character);

	stream & mOffset;
	stream & mSubMotion;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	InitialOffsetMotion::SubMotion() const
{
	const Character* character = Motion::FindCharacter();
	if (Animation::INVALID_ID != mSubMotion)
	{
		const Motion* motion = (*character)[mSubMotion];
		return motion->Name().AsChar();
	}
	return NULL;
}

// --------------------------------------------------------------------------------------------------------------------
void InitialOffsetMotion::SubMotion(const char* motionName)
{
	const Character* character = Motion::FindCharacter();
	mSubMotion = character->FindMotion(motionName);
	AP_ASSERT(Animation::INVALID_ID != mSubMotion);
}


// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(CharacterPlayback)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Playback)
	AP_PROPERTY("CharacterName", CharacterName, CharacterName, "")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
void CharacterPlayback::Initialize(const Character* character)
{
	Playback::Initialize(character);
	mCharacterNameParameter	= character->FindParameter("CharacterName");
}

// --------------------------------------------------------------------------------------------------------------------
const bool CharacterPlayback::IsPlayable(const Individual::Ptr& individual) const
{
	return	mCharacterName == *individual->GetParameter<Axiom::CRC>(mCharacterNameParameter)
			&& Playback::IsPlayable(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void CharacterPlayback::Serialize(Axiom::Serializer& stream, Character* character)
{
	Playback::Serialize(stream, character);

	stream & mCharacterName;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	CharacterPlayback::CharacterName() const
{
	return mCharacterName.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void CharacterPlayback::CharacterName(const char* name)
{
	mCharacterName = name;
}


// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

// TransitionMotions.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------
#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/transitionmotions.h>
#include <animation/character.h>
#include <animation/rootadjustment.h>
#include <core/serializer.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(TransitionInfo)
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(CrossFade)
	AP_BASE_TYPE(Motion)
	AP_DEFAULT_CREATE()
	AP_PROPERTY("Playback", PlaybackMotion, PlaybackMotion, "What motion are we intending to play")
	AP_PROPERTY_USERDEBUG("Duration", Duration, Duration, "How long will the transition last")
	AP_PROPERTY_USERDEBUG("StartPosition", StartPosition, StartPosition, "At what time does the tag occur")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
CrossFade::CrossFade()
:	mPlaybackData(NULL)
,	mActivePlaybackData(NULL)
,	mTransitionData(NULL)
,	mDuration(Axiom::Time::CreateFromSeconds(0.05f)) // 3 frames or 3.f*0.0166666fs
,	mStartPosition(GenericTime::Zero())
{
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::Initialize(const Character* character)
{
	mPlaybackData		= character->FindParameter("PlaybackData");
	mActivePlaybackData	= character->FindParameter("ActivePlaybackData");
	mTransitionData		= character->FindParameter("TransationData");
}

// --------------------------------------------------------------------------------------------------------------------
const bool CrossFade::IsPlayable(const Individual::Ptr& individual) const
{
	const Character* character	= individual->GetCharacter();
	const Motion* motion		= (*character)[mPlayback];
	PlaybackInfo* playback		= individual->GetParameter<PlaybackInfo>(mPlaybackData);
	const GenericTime before	= playback->mInitialProgress;
	playback->mInitialProgress	= mStartPosition;
	playback->mInitialProgress.ReturnToRange();
	const bool isPlayable		= motion->IsPlayable(individual);
	playback->mInitialProgress	= before;
	return isPlayable;
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::StartPlayback(Individual::Ptr& individual) const
{
	// Cache playback information to transition out the previous motion.  
	const Character* character	= individual->GetCharacter();
	PlaybackInfo* playback		= individual->GetParameter<PlaybackInfo>(mPlaybackData);
	TransitionInfo*	transition	= individual->GetParameter<TransitionInfo>(mTransitionData);
	transition->mPlaybackData	= *playback; 
	transition->mPlaybackData.mActiveProgress = transition->mPlaybackData.mPreviousProgress; // the motion has previously been updated 
	transition->mOutMotion		= Axiom::CRC().Value() != transition->mPlaybackData.mActiveMotionName 
									? character->FindMotion(transition->mPlaybackData.mActiveMotionName)
									: -1;
	transition->mStart			= individual->ActiveTime();
	transition->mEnd			= transition->mStart + mDuration;

	// Set playback's initial progress
	playback->mInitialProgress	= mStartPosition;
	playback->mInitialProgress.ReturnToRange();

	const Motion* primary		= (*character)[mPlayback];
	primary->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const bool CrossFade::Play(Individual::Ptr& individual) const
{
	// Update primary motion
	const Character* character		= individual->GetCharacter();
	const Motion* primaryMotion		= (*character)[mPlayback];

	bool stillPlaying = false;
	TransitionInfo* transition		= individual->GetParameter<TransitionInfo>(mTransitionData);
	if (0 <= transition->mOutMotion && transition->mStart <= individual->UpdateTime() && individual->UpdateTime() <= transition->mEnd)
	{
		const float progress		= (individual->UpdateTime() - transition->mStart) / (transition->mEnd - transition->mStart);
		const Motion* outMotion		= (*character)[transition->mOutMotion];
		PlaybackInfo* playback		= individual->GetParameter<PlaybackInfo>(mPlaybackData);

		// Update out motions playback state
		AP::Reflection::Instance activePlaybackData = individual->StateData().GetField(mActivePlaybackData);
		activePlaybackData			= &transition->mPlaybackData;
		const bool playSecondary	= outMotion->Play(individual);
		activePlaybackData			= playback;

		if (playSecondary)
		{	// Combine both recipies
			const Recipe secondary	= individual->PoseRecipe();
			stillPlaying			= primaryMotion->Play(individual);

			Recipe& primary			= individual->PoseRecipe();
			primary.BlendRecipe(1.0f - progress, secondary, false);
		}
		else
		{	// Cancel blend and play the primary
			transition->mOutMotion	= Animation::INVALID_ID;
			stillPlaying			= primaryMotion->Play(individual);
		}
	}
	else
	{
		stillPlaying		= primaryMotion->Play(individual);
	}
	return stillPlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::Serialize(Axiom::Serializer& stream, Character* character)
{
	Motion::Serialize(stream, character);

	stream & mDuration;
	stream & mPlayback;
	stream & mStartPosition;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	CrossFade::PlaybackMotion() const
{
	const Character* character = FindCharacter();
	const Motion* motion = (*character)[mPlayback];
	return motion->Name().AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::PlaybackMotion(const char* motionName)
{
	const Character* character = FindCharacter();
	mPlayback = character->FindMotion(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
float CrossFade::Duration() const
{
	return mDuration.AsFloatInSeconds();
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::Duration(const float seconds)
{
	AP_ASSERT(0.f != seconds);
	mDuration = Axiom::Time::CreateFromSeconds(seconds);
}

// --------------------------------------------------------------------------------------------------------------------
float CrossFade::StartPosition() const
{
	return mStartPosition.AsFloat();
}

// --------------------------------------------------------------------------------------------------------------------
void CrossFade::StartPosition(const float position)
{
	mStartPosition = position;
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(PhaseTransition)
	AP_BASE_TYPE(CrossFade)
	AP_DEFAULT_CREATE()
	AP_PROPERTY_USERDEBUG("StartState", StartState, StartState, "What state do we intend to start at")
	AP_PROPERTY_USERDEBUG("StartRegion", StartRegion, StartRegion, "How far from the tag can we start from?")
	AP_PROPERTY_USERDEBUG("EndRegion", EndRegion, EndRegion, "How far from the tag can we start from?")
	AP_FIELD_USERDEBUG("StartGeneric", mGenericStart, "How far from the tag can we start from?")
	AP_FIELD_USERDEBUG("EndGeneric", mGenericEnd, "How far from the tag can we start from?")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
PhaseTransition::PhaseTransition()
:	mStartState(INVALID_ID)
,	mGenericStart(GenericTime::Zero())
,	mGenericEnd(GenericTime::Zero())
,	mRegionStart(Axiom::Time::CreateFromSeconds(0.05f))
,	mRegionEnd(Axiom::Time::CreateFromSeconds(0.05f))
{
}

// --------------------------------------------------------------------------------------------------------------------
const bool PhaseTransition::IsPlayable(const Individual::Ptr& individual) const
{	// Review(danc): We have a problem here that the current pose Recipe is for the previous frame 
	const Recipe& poseRecipe		= individual->PoseRecipe();
	const Axiom::TimeAbsolute start = individual->ActiveTime() - mRegionStart;
	const Axiom::TimeAbsolute end	= Axiom::Math::Max(individual->ActiveTime() + mRegionEnd, individual->UpdateTime());
	return	poseRecipe.IsPhaseWithin(mStartState, start, end) 
			&& CrossFade::IsPlayable(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void PhaseTransition::StartPlayback(Individual::Ptr& individual) const
{
	// Review(danc): this code suffers from an ambiguity problem where the Start End region could cross the boundry
	//				 of two different phases and may choose the incorrect phase.  Currently the only way to fix this
	//               is to narrow the region to guarontee the ambiguity is removed.  

	// Calculate the starting position
	const Character* character		= individual->GetCharacter();
	const Axiom::TimeAbsolute start = individual->ActiveTime() - mRegionStart;
	const Axiom::TimeAbsolute end	= individual->ActiveTime() + mRegionEnd;
	const Axiom::TimeAbsolute time  = individual->PoseRecipe().PhaseTime(mStartState, start, end);
	AP_ASSERT(start <= time && time <= end);
	const Axiom::Time timeRegion	= end - start;
	const float timeRatio			= (time - start) / timeRegion;
	const float activeRatio			= (individual->ActiveTime() - start) / timeRegion;
	const float toActiveRatio		= activeRatio - timeRatio;

	// time maps to mStartPosition so the initial progress must be offseted by timeRatioDiff
	const GenericTime genericStart	= mStartPosition - mGenericStart;
	const GenericTime genericEnd	= mStartPosition + mGenericEnd;
	const GenericTime genericRegion = genericEnd - genericStart;
	const float startRatio			= (mStartPosition - genericStart).AsFloat() / genericRegion.AsFloat();

	// Setup transition info
	PlaybackInfo* playback			= individual->GetParameter<PlaybackInfo>(mPlaybackData);
	TransitionInfo*	transition		= individual->GetParameter<TransitionInfo>(mTransitionData);
	transition->mPlaybackData		= *playback; 
	transition->mPlaybackData.mActiveProgress = transition->mPlaybackData.mPreviousProgress; // the motion has previously been updated 
	transition->mOutMotion			= Axiom::CRC().Value() != transition->mPlaybackData.mActiveMotionName 
										? character->FindMotion(transition->mPlaybackData.mActiveMotionName)
										: -1;
	transition->mStart				= individual->ActiveTime();
	transition->mEnd				= transition->mStart + mDuration;

	// Setup playback info
	playback->mInitialProgress		= genericStart.AsFloat() + (startRatio + toActiveRatio)*genericRegion.AsFloat();
	playback->mInitialProgress.ReturnToRange();

	// Initialize primary sub motion
	const Motion* primary			= (*character)[mPlayback];
	primary->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void PhaseTransition::Serialize(Axiom::Serializer& stream, Character* character)
{
	CrossFade::Serialize(stream, character);

	stream & mStartState;
	stream & mGenericStart;
	stream & mGenericEnd;
	stream & mRegionStart;
	stream & mRegionEnd;
}

// --------------------------------------------------------------------------------------------------------------------
int	PhaseTransition::StartState() const
{
	return mStartState;
}

// --------------------------------------------------------------------------------------------------------------------
void PhaseTransition::StartState(const int stateId)
{
	mStartState = stateId;
}

// --------------------------------------------------------------------------------------------------------------------
void PhaseTransition::StartRegion(const float seconds)
{
	mRegionStart = Axiom::Time::CreateFromSeconds(seconds);
}

// --------------------------------------------------------------------------------------------------------------------
float PhaseTransition::StartRegion() const
{
	return mRegionStart.AsFloatInSeconds();
}

// --------------------------------------------------------------------------------------------------------------------
void PhaseTransition::EndRegion(const float seconds)
{
	mRegionEnd = Axiom::Time::CreateFromSeconds(seconds);
}

// --------------------------------------------------------------------------------------------------------------------
float PhaseTransition::EndRegion() const
{
	return mRegionEnd.AsFloatInSeconds();
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

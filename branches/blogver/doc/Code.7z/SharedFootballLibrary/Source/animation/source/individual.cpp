// Individual.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/individual.h>
#include <animation/character.h>
#include <kernel/messages.h>
#include <core/singleton.h>// just for send_event
#include <Kernel/componentmanager.h>
#include <Animation/playbackmotion.h>
#include <audiowii/audioeventmessages.h>

using namespace AP::Reflection;
using namespace Soccer;

namespace Soccer
{
namespace Animation
{
// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(Individual)
	AP_FIELD("UpdateTime", mUpdateTime, "The current time to update recipe to.")
	AP_FIELD("ActiveTime", mActiveTime, "The current time the recipe will evaluate to.")
	AP_FIELD("StateData", mStateData, "The active state data.")
		AP_CONVERSION_FIELD()
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
Individual::Individual()
{
}

// --------------------------------------------------------------------------------------------------------------------
Individual::~Individual()
{
	AP::ComponentManager::GetInstance()->ActiveComponent()->GetEventMan().UnRegisterEventMsgBox(mMessageBox);
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::SetMount(const Gel::Skeleton* skeleton)
{
	mPoseRecipe.SetMount(skeleton);
}

// --------------------------------------------------------------------------------------------------------------------
const Gel::Skeleton* Individual::GetMount() const
{
	return mPoseRecipe.GetMount();
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::Initialize(const CharacterIndex characterIndex, const AP::Reflection::Type* stateData, 
							SharedSoccer::EntityGUID& entityGUID, const Axiom::Memory::HeapId heapId)
{
	Axiom::EventMan* eventManager	= &AP::ComponentManager::GetInstance()->ActiveComponent()->GetEventMan();
	Character* character			= CharacterLibrary::GetInstance()->GetCharacter(characterIndex);
	Ptr individual					= this;

	Axiom::ShortString name;
	name.Format("%s%d", character->Name().AsChar(), entityGUID.GetHashID());

	mUpdateTime = Axiom::TimeAbsolute::Zero();
	mActiveTime = mUpdateTime;
	mMessageBox = eventManager->RegisterAndCreateEventMsgBox(	name.AsChar(), 
																heapId,
																24,	// in box size
																12,	// out box size
																8);	// Total events to listen for

	mEntityGUID = entityGUID;
	mPoseRecipe = Recipe(mActiveTime, mUpdateTime, characterIndex);

	DefineStateData(stateData, heapId);
	character->InitializeIndividual(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::Update(const Axiom::TimeAbsolute& updateTime)
{
	// Advance time
	mUpdateTime += (updateTime - mActiveTime);
	AP_ASSERTMESSAGE(mUpdateTime > mActiveTime, "Update time provided cannot be the same as the active time!");

	Ptr individual = this;
	GetCharacter()->Update(individual);

	mActiveTime = mUpdateTime;
	mTransform = mPoseRecipe.GenerateTransform();

	// lost and gone forever
	//mMessageBox->ClearInbox(); //the message reader (eg. a Motion)::Play() needs to clear the individual's inbox
	mMessageBox->ClearOutbox();
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::SetTransform(const JointMatrix& transform)
{
	JointMatrix postTransform = mPoseRecipe.PostTransform();
	postTransform *= mPoseRecipe.GenerateTransform().AsInverse();
	postTransform *= transform;
	mPoseRecipe.SetPostTransform(postTransform);
	mTransform = mPoseRecipe.GenerateTransform();
}

// --------------------------------------------------------------------------------------------------------------------
const Individual::Parameter Individual::FindParameter(const Axiom::StringCRC& name) const
{
	const Individual::Parameter parameter = GetCharacter()->FindParameter(name);
	AP_ASSERT(NULL != parameter);
	return parameter;
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::SendEvent(Axiom::EventMsg* pEvent)
{
	mMessageBox->SendEvent(pEvent);
}

// --------------------------------------------------------------------------------------------------------------------
const Axiom::EventMsgBoxHandle & Individual::GetMessageBox()
{
	return mMessageBox;
}

// --------------------------------------------------------------------------------------------------------------------
void Individual::DefineStateData(const AP::Reflection::Type* type, const Axiom::Memory::HeapId heapId)
{
	mStateData.Set(type->CreateInstance(heapId));

	// Default initialization of simple type
	Individual::Parameter field = type->Fields();
	while (NULL != field)
	{
		if (AP::Reflection::TypeOf<float>() == field->Type())
		{
			*GetParameter<float>(field) = 0.f;
		}
		else if (AP::Reflection::TypeOf<int>() == field->Type())
		{
			*GetParameter<int>(field) = 0;
		}
		else if (AP::Reflection::TypeOf<unsigned>() == field->Type())
		{
			*GetParameter<unsigned>(field) = 0;
		}
		field = field->Next();
	}
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //  (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

// generictime.cpp - (c) 2007 Action Pants Inc.
// -----------------------------------------------------------------------------

#include "animation/generictime.h"
#include "core/serializer.h"

namespace Soccer
{
namespace Animation
{
// -----------------------------------------------------------------------------
AP_TYPE(GenericTime)
	AP_DEFAULT_CREATE()
	AP_FIELD("Value", m_GenericTime, "The current time value (0-1).")
		AP_CONVERSION_FIELD()
	AP_COMMAND_USERDEBUG(ClampToOne, "Clamp the value to one!")
	AP_COMMAND_USERDEBUG(ReturnToRange, "Wraps the value back into the a valid range (0-1).")
	AP_COMMAND(AsFloat, "Returns a value between 0-1.")
	AP_COMMAND_USERDEBUG(IsInvalid, "Is the time invalid?")
	AP_COMMAND_USERDEBUG(IsValid, "Is this time valid?")
	AP_COMMAND_USERDEBUG(IsStillPlaying, "Is the motion still playing?")
	AP_COMMAND_USERDEBUG(HasCompleted, "Has the motion finished?")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// -----------------------------------------------------------------------------
Axiom::Serializer& operator& (Axiom::Serializer& stream, GenericTime& t)
{
	stream & t.m_GenericTime;
	return stream;
}

// -----------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

// End of file -----------------------------------------------------------------

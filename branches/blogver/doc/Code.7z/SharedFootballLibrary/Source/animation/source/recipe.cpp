// recipe.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/recipe.h>
#include <animation/clipmanager.h>
#include <animation/character.h>
#include <animation/generictime.h>
#include <gel/skeleton.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
Recipe::Recipe(const Axiom::TimeAbsolute& start, const Axiom::TimeAbsolute& end, 
			   const CharacterIndex character, const Gel::Skeleton* mount)
:	mStart(start)
,	mEnd(end)
,	mCharacter(character)
,	mMount(mount)
{
}

// --------------------------------------------------------------------------------------------------------------------
const unsigned Recipe::NumberOfBlends() const
{
	return mBlendList.Count();
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::SetClip(const ClipId clipId, const bool mirrored, const bool reversed, const Axiom::Time& start, const Axiom::Time& end)
{
	Ingredient ingredient;
	ingredient.clipId			= clipId;
	ingredient.clipStartTime	= start;
	ingredient.clipEndTime		= end;
	ingredient.weight			= 1.0f;
	ingredient.isMirrored		= mirrored;
    ingredient.isReversed       = reversed;
	ingredient.isRootBlended	= true;

	AP_ASSERT_SUPPORT(const Axiom::Time duration = ClipManager::GetInstance()->GetClip(clipId)->Duration();)
	AP_ASSERT(start >= Axiom::Time::Zero() && end >= Axiom::Time::Zero());
	AP_ASSERT(start <= duration && end <= duration);

	mBlendList.Clear();
	mPhaseList.Clear();
	mBlendList.Add(ingredient);

	// Build phase list
	{
		const ClipManager* clipManager	= ClipManager::GetInstance();
		const Clip* clip				= clipManager->GetClip(ingredient.clipId);
        const Axiom::Time clipStart     = ingredient.isReversed ? ingredient.clipEndTime : ingredient.clipStartTime;
        const Axiom::Time clipEnd       = ingredient.isReversed ? ingredient.clipStartTime : ingredient.clipEndTime;
        const Axiom::Time range			= clipEnd - clipStart;
		const Axiom::Time loopedRange	= Axiom::Select(range, range, clip->Duration() + range);
		const float playbackRate		= loopedRange / (EndTime() - StartTime());

		const unsigned numberOfStates	= clip->NumberOfStates();
		for (unsigned i = 0; i < numberOfStates; ++i)
		{
			Phase phase;
			phase.state = clip->GetStateId(i, ingredient.isMirrored);

			const int EAnimStateLeftFootOnGround	= 1; // Review(danc): value taken from EAnimState::LeftFootOnGround in soccertags.h foot states need to be generic
			const int EAnimStateRightFootOnGround	= 2; // Review(danc): value taken from EAnimState::RightFootOnGround in soccertags.h foot states need to be generic
			const bool validState			= phase.state == EAnimStateLeftFootOnGround || phase.state == EAnimStateRightFootOnGround; 
			const unsigned numberOfRanges	= clip->NumberOfStateFrameRanges(phase.state, ingredient.isMirrored);
			for (unsigned j = 0; validState && j < numberOfRanges; ++j)
			{	
				const FrameRange* frameRange	= clip->GetStateFrameRange(phase.state, ingredient.isMirrored, j);

				phase.start = StartTime() + playbackRate*(clip->KeyTime(frameRange->mBegin) - ingredient.clipStartTime);

				// insert the element and then position the phase into the correct position.  Can we move this sort offline?
				mPhaseList.Add(phase);
				for (unsigned i = mPhaseList.Count() - 1; i-- && mPhaseList[i + 1].start < mPhaseList[i].start; )
				{
					Axiom::Swap(mPhaseList[i + 1], mPhaseList[i]);
				}
			}
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::BlendRecipe(const float weight, const Recipe& recipe, const bool blendRoot, const bool doMergePhases)
{
	AP_ASSERT(0.f <= weight && weight <= 1.f);

	if (1.f == weight || !IsValid())
	{
		*this = recipe;
	}
	else if (0.f != weight && recipe.IsValid() && !recipe.mBlendList.IsEmpty())
	{
		AP_ASSERT(mCharacter == recipe.mCharacter);
		AP_ASSERT((NumberOfBlends() + recipe.NumberOfBlends()) < mBlendList.Capacity());

		Ingredient ingredient;
		if (1 < recipe.mBlendList.Count())
		{
			for (Axiom::uint i = 0; i < recipe.mBlendList.Count() - 1; ++i)
			{
				ingredient					= recipe.mBlendList[i];
				ingredient.weight			= weight * recipe.mBlendList[i + 1].weight;
				ingredient.isRootBlended	&= blendRoot;

				mBlendList.Add(ingredient);
			}

			ingredient						= recipe.mBlendList.LastItem();
			ingredient.weight				= weight * (1.0f - recipe.mBlendList.LastItem().weight);
			ingredient.isRootBlended		&= blendRoot;
		}
		else
		{
			ingredient					= recipe.mBlendList.LastItem();
			ingredient.weight			= weight * recipe.mBlendList.LastItem().weight;
			ingredient.isRootBlended	&= blendRoot;
		}

		mBlendList.Add(ingredient);
		if (doMergePhases)
			MergePhases(recipe.mPhaseList); // Merge blended phases in to the phase list
	}
}

// --------------------------------------------------------------------------------------------------------------------
const bool Recipe::IsValid() const
{
	return INVALID_ID != mCharacter;
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::TimeAbsolute	Recipe::StartTime() const
{
	return mStart;
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::TimeAbsolute Recipe::EndTime() const
{
	return mEnd;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::Reset(const Axiom::TimeAbsolute& start, const Axiom::TimeAbsolute& end)
{
	mBlendList.Clear();
	mPhaseList.Clear();
	mStart = start;
	mEnd = end;
}

// --------------------------------------------------------------------------------------------------------------------
const Character* Recipe::GetCharacter() const
{
	return CharacterLibrary::GetInstance()->GetCharacter(mCharacter);
}

// --------------------------------------------------------------------------------------------------------------------
CharacterIndex Recipe::GetCharacterIndex() const
{
	return mCharacter;
}

// --------------------------------------------------------------------------------------------------------------------
const int Recipe::NumberOfJoints() const
{
	return GetCharacter()->GetSkeleton()->NumberOfJoints();
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix& Recipe::PostTransform()
{
	return mPostTransform;
}

// --------------------------------------------------------------------------------------------------------------------
const JointMatrix& Recipe::PostTransform() const
{
	return mPostTransform;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::SetPostTransform(const JointMatrix& transform)
{
	mPostTransform = transform;
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix& Recipe::PreTransform()
{
	return mPreTransform;
}

// --------------------------------------------------------------------------------------------------------------------
const JointMatrix& Recipe::PreTransform() const
{
	return mPreTransform;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::SetPreTransform(const JointMatrix& transform)
{
	mPreTransform = transform;
}

// --------------------------------------------------------------------------------------------------------------------
const Skeleton* Recipe::GetSkeleton() const
{
	return GetCharacter()->GetSkeleton();
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::SetMount(const Gel::Skeleton* skeleton)
{
	mMount = skeleton;
}

// --------------------------------------------------------------------------------------------------------------------
const Gel::Skeleton* Recipe::GetMount() const
{
	return mMount;
}

// --------------------------------------------------------------------------------------------------------------------
const bool Recipe::IsPhaseWithin(const AnimStateId state, const Axiom::TimeAbsolute& start, const Axiom::TimeAbsolute& end) const
{
	bool result = false;

	// Search through the phase list and find an acceptable phase within the given region
	for (unsigned i = 0; !result && i < mPhaseList.Count() && mPhaseList[i].start < end; ++i)
	{
		const Axiom::TimeAbsolute& phaseStart	= mPhaseList[i].start;
		const Axiom::TimeAbsolute& phaseEnd		= i + 1 == mPhaseList.Count() ? Axiom::TimeAbsolute::MaximumTime() : mPhaseList[i + 1].start;
		const bool inPhase						= state == mPhaseList[i].state;
		const bool inRange						= phaseStart < end && end <= phaseEnd;
		result									= inPhase && inRange;
	}

	return result;
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::TimeAbsolute	Recipe::PhaseTime(const AnimStateId state, const Axiom::TimeAbsolute& start, const Axiom::TimeAbsolute& end) const
{
	// Search through the phase list and find an acceptable phase within the given region
	for (unsigned i = 0; i < mPhaseList.Count() && mPhaseList[i].start < end; ++i)
	{
		const Axiom::TimeAbsolute& phaseStart	= mPhaseList[i].start;
		const Axiom::TimeAbsolute& phaseEnd		= i + 1 == mPhaseList.Count() ? Axiom::TimeAbsolute::MaximumTime() : mPhaseList[i + 1].start;
		const bool inPhase						= state == mPhaseList[i].state;
		const bool inRange						= end >= phaseStart && start < phaseEnd;
		if (inPhase && inRange)
		{	// Camp the start phase time to within the specified range
			return Axiom::Max(start, Axiom::Min(end, mPhaseList[i].start));
		}
	}

	return Axiom::TimeAbsolute::MaximumTime(); // Is there a better value then max time?
}

// --------------------------------------------------------------------------------------------------------------------
const AnimStateId Recipe::ActiveState() const
{
	unsigned i ;
	for (i = 0; mPhaseList[i].start <= StartTime() && i < mPhaseList.Count(); ++i) {} // Intentionally empty

	AP_ASSERT(i != mPhaseList.Count());
	return mPhaseList[i].state;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::GenerateStartEndTransforms(JointMatrix* start, JointMatrix* end, Axiom::Time* duration) const
{
	AP_ASSERT(NumberOfJoints() < Clip::MAX_NUM_JOINTS);
	const ClipManager* clipManager	= ClipManager::GetInstance();

	Axiom::Time clipDuration	= Axiom::Time::Zero();
	JointMatrix clipStart; // We don't actually need to calculate this value! start position is always the same in clip space
	JointMatrix clipEnd;
	JointMatrix clipPos;
	if (0 < mBlendList.Count())
	{
		const Ingredient& base	= mBlendList[0];
		const Clip* clip		= clipManager->GetClip(base.clipId);
		clipDuration			= clip->Duration();
		clipStart				= clip->GetJoint(0, 0, base.isMirrored);
		clipPos					= clip->GetJoint(0, base.clipEndTime, base.isMirrored);
		clipEnd					= clip->GetJoint(0, clip->NumberOfKeys() - 1, base.isMirrored);

		for(unsigned i = 1; i < mBlendList.Count(); ++i)
		{
			const Ingredient& ingredient = mBlendList[i];

			clip				= clipManager->GetClip(ingredient.clipId);
			clipDuration		= Blend(ingredient.weight, clipDuration, clip->Duration());
			if (ingredient.isRootBlended)
			{
				clipStart		= Blend(ingredient.weight, clipStart, clip->GetJoint(0, 0, ingredient.isMirrored));
				clipPos			= Blend(ingredient.weight, clipPos, clip->GetJoint(0, ingredient.clipEndTime, ingredient.isMirrored));
				clipEnd			= Blend(ingredient.weight, clipEnd, clip->GetJoint(0, clip->NumberOfKeys() - 1, ingredient.isMirrored));
			}
		}
	}

	const JointMatrix& offset = clipPos.AsInverse() * mPostTransform;
	if (NULL != start)
	{
		*start = mPreTransform;
		*start *= clipStart;
		*start *= offset;
	}
	
	if (NULL != end)
	{
		*end = mPreTransform;
		*end *= clipEnd;
		*end *= offset;
	}

	if (NULL != duration)
	{
		*duration = clipDuration;
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::GetClipTagEvents(Axiom::Collections::StaticList<ClipTag, 10>& clipEvents) const
{
	const ClipManager* clipManager	= ClipManager::GetInstance();

	unsigned numBlends = mBlendList.Count();
	for(unsigned i = 0; i < numBlends; ++i)
	{
		const Ingredient& ingredient    = mBlendList[i];
        const Axiom::Time clipStart     = ingredient.isReversed ? ingredient.clipEndTime : ingredient.clipStartTime;
        const Axiom::Time clipEnd       = ingredient.isReversed ? ingredient.clipStartTime : ingredient.clipEndTime;
		const Clip* clip                = clipManager->GetClip(ingredient.clipId);

		Axiom::Time clipRelativeTime	= Axiom::Time::Zero();
		for (int x = 0; !clipEvents.IsFull() && clipRelativeTime <= clipEnd && x < clip->NumberOfTags(); x++)
		{
			ClipTag theCurrentTag;
			clip->GetTag(x, theCurrentTag);

			clipRelativeTime = clip->GetTagTime(x);
			if (clipStart < clipRelativeTime && clipRelativeTime <= clipEnd)
			{
				bool alreadyExistsInOutputArray = false;
				for (unsigned test = 0; !alreadyExistsInOutputArray && test < clipEvents.Count (); ++test)
				{
					alreadyExistsInOutputArray = theCurrentTag.mTagId == clipEvents [test].mTagId;
				}
				if (!alreadyExistsInOutputArray)
				{
					clipEvents.Add(theCurrentTag);
				}
			}
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::GetClipStates(AnimStateList& clipStates) const
{
	// for each ingredient (clip)	
	const ClipManager* clipManager	= ClipManager::GetInstance();

	unsigned NumBlends = mBlendList.Count();
	for(unsigned i = 0; i < NumBlends; ++i)
	{
		const Ingredient& ingredient    = mBlendList[i];
        //const Axiom::Time clipStart     = ingredient.isReversed ? ingredient.clipEndTime : ingredient.clipStartTime;
        const Axiom::Time clipEnd       = ingredient.isReversed ? ingredient.clipStartTime : ingredient.clipEndTime;
		const Clip* clip                = clipManager->GetClip(ingredient.clipId);
		const int clipKey				= clip->GetNextKey(clipEnd);

		for (int s = 0; !clipStates.IsFull() && s < clip->NumberOfStates(); ++s)
		{				
			AnimStateId stateId = clip->GetStateId(s, ingredient.isMirrored);
			if (clip->IsStateAtKey(stateId, false, clipKey))
			{
				bool alreadyExistsInOutputArray = false;
				for (unsigned test = 0; !alreadyExistsInOutputArray && test < clipStates.Count(); ++test)
				{
					alreadyExistsInOutputArray = stateId == clipStates[test];
				}
				if (!alreadyExistsInOutputArray)
				{
					clipStates.Add(stateId);
				}
			}
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
const JointMatrix Recipe::GenerateTransform() const
{
	AP_ASSERT(NumberOfJoints() < Clip::MAX_NUM_JOINTS);

	JointMatrix result = mPreTransform;
	JointMatrix transform;
	if (0 < mBlendList.Count())
	{
		const Ingredient& base	= mBlendList[0];
		const Clip* clip		= ClipManager::GetInstance()->GetClip(base.clipId);
        transform				= clip->GetRelativeRootJoint(base.clipStartTime, base.clipEndTime, base.isMirrored, base.isReversed);

		for(unsigned i = 1; i < mBlendList.Count(); ++i)
		{
			const Ingredient& ingredient = mBlendList[i];

			if (ingredient.isRootBlended)
			{
				clip = ClipManager::GetInstance()->GetClip(ingredient.clipId);
				transform = Blend(ingredient.weight, transform, clip->GetRelativeRootJoint(ingredient.clipStartTime, ingredient.clipEndTime, ingredient.isMirrored, ingredient.isReversed));
			}
		}
	}
	result *= transform;
	result *= mPostTransform;
	result.mRotation.Normalize(); // Error accumulates in the root joint, normalizing here compensates for the error
	
	return result;
}

// --------------------------------------------------------------------------------------------------------------------
const JointMatrix Recipe::GenerateJoint(const int joint, JointMatrix* pParent) const
{
	return GenerateJointAtTime(mEnd, joint, pParent);
}

// --------------------------------------------------------------------------------------------------------------------
const JointMatrix Recipe::GenerateJointAtTime(const Axiom::TimeAbsolute& time, const int joint, JointMatrix* pParent, JointMatrix* pRoot) const
{
	AP_ASSERTMESSAGE(NULL != GetMount(), "No body registered a skeletal mount!");
	const Gel::Skeleton& mount = *GetMount();
	const Skeleton& skeleton = *GetSkeleton();
	AP_ASSERTMESSAGE(skeleton.NumberOfJoints() == mount.GetNumJoints(), "Skeletal joint counts are out of sync.");

	JointMatrix joints[Clip::MAX_NUM_JOINTS];
	{	// inlined GenerateLocalPose(joints) to blend only the required joints
		AP_ASSERT(NumberOfJoints() < Clip::MAX_NUM_JOINTS);
		JointMatrix temp[Clip::MAX_NUM_JOINTS];

		AP_ASSERTMESSAGE(mStart <= time, "We cannot predict the past.");
		if (!mBlendList.IsEmpty())
		{
			const Ingredient& base			= mBlendList[0];
			const Clip* clip				= ClipManager::GetInstance()->GetClip(base.clipId);
			const Axiom::Time& range		= time - mStart;
			const float& timeStepInSeconds	= (mEnd - mStart).AsFloatInSeconds();
            const bool noLoop               = (!base.isReversed && base.clipStartTime < base.clipEndTime) 
                                            || (base.isReversed && base.clipStartTime > base.clipEndTime);

            const Axiom::Time& duration     = base.isReversed ? -clip->Duration() : clip->Duration();
            const Axiom::Time& baseOffset	= !noLoop ? duration : Axiom::Time::Zero();
			const Axiom::Time& baseTimeStep = baseOffset + base.clipEndTime - base.clipStartTime;
			const float& toBasePlaybackRate = baseTimeStep.AsFloatInSeconds() / timeStepInSeconds;
			const Axiom::Time& baseEndTime	= base.clipStartTime + range*toBasePlaybackRate;
			const Axiom::Time& loopedBaseEndTime = Axiom::Select(baseEndTime, baseEndTime, baseEndTime + clip->Duration());
			const Axiom::Time& futureBaseEndTime = Axiom::Select(loopedBaseEndTime - clip->Duration(), loopedBaseEndTime - clip->Duration(), loopedBaseEndTime);
            AP_ASSERTMESSAGE(futureBaseEndTime < clip->Duration(), "Cannot predict this far into the future");

            clip->GetRelativeRequiredJoints(joint, base.clipStartTime, futureBaseEndTime, joints, base.isMirrored, base.isReversed);
            //clip->GetRelativeJoints(base.clipStartTime, futureBaseEndTime, joints, base.isMirrored, base.isReversed);

			for(unsigned i = 1; i < mBlendList.Count(); ++i)
			{
				const Ingredient& ingredient	= mBlendList[i];
				clip = ClipManager::GetInstance()->GetClip(ingredient.clipId);

                const bool clipNoLoop           = (!base.isReversed && base.clipStartTime < base.clipEndTime) 
                                                || (base.isReversed && base.clipStartTime > base.clipEndTime);

                const Axiom::Time& clipDuration = base.isReversed ? -clip->Duration() : clip->Duration();
				const Axiom::Time& clipOffset	= !clipNoLoop ? clipDuration : Axiom::Time::Zero();
				const Axiom::Time& clipTimeStep	= clipOffset + ingredient.clipEndTime - ingredient.clipStartTime;
				const float& toClipPlaybackRate	= clipTimeStep.AsFloatInSeconds() / timeStepInSeconds;
				const Axiom::Time& clipEndTime	= ingredient.clipStartTime + range*toClipPlaybackRate;
			    const Axiom::Time& loopedClipEndTime = Axiom::Select(clipEndTime, clipEndTime, clipEndTime + clip->Duration());
			    const Axiom::Time& futureClipEndTime = Axiom::Select(loopedClipEndTime - clip->Duration(), loopedClipEndTime - clip->Duration(), loopedClipEndTime);
				AP_ASSERTMESSAGE(futureClipEndTime < clip->Duration(), "Cannot predict this far into the future");

				clip->GetRelativeRequiredJoints(joint, ingredient.clipStartTime, futureClipEndTime, temp, ingredient.isMirrored, base.isReversed);
				//clip->GetRelativeJoints(ingredient.clipStartTime, futureClipEndTime, temp, ingredient.isMirrored, base.isReversed);

				// Only blend joints requried
				for (int j = joint; Skeleton::INVALID_JOINT != j; j = static_cast<int>(static_cast<char>(skeleton[j].mParent)))
				{
					joints[j] = Blend(ingredient.weight, joints[j], temp[j]);
				}

				if (!ingredient.isRootBlended)
				{
					joints[0] = JointMatrix::IDENTITY;
				}
			}
		}
		joints[0] = mPreTransform * joints[0];
		joints[0] *= mPostTransform;
	}

	// Output the root transform
	JointMatrix noRootTransform;
	JointMatrix &rootTransform = NULL == pRoot ? noRootTransform : *pRoot;
	rootTransform = joints[0];

	// Compute parent and joint transform
	JointMatrix noParentTransform;
	JointMatrix &parentTransform = NULL == pParent ? noParentTransform : *pParent;

	int current = joint;
	int parent = static_cast<int>(static_cast<char>(skeleton[current].mParent));
	JointMatrix resultTransform = joints[current];
	parentTransform.Clear();

	// Build this local joint
	if (Skeleton::INVALID_JOINT != parent)
	{
		resultTransform *= mount[current].mBone;
		current = static_cast<int>(static_cast<char>(skeleton[current].mParent));
		parent = static_cast<int>(static_cast<char>(skeleton[current].mParent));
		parentTransform *= joints[current];
	}

	// Build parent bone
	while (Skeleton::INVALID_JOINT != parent)
	{
		parentTransform *= mount[current].mBone;
		current = static_cast<int>(static_cast<char>(skeleton[current].mParent));
		parent = static_cast<int>(static_cast<char>(skeleton[current].mParent));
		parentTransform *= joints[current];
	}

	resultTransform *= parentTransform;
	return resultTransform;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::GenerateLocalPose(JointMatrix* jointList) const
{
	AP_ASSERT(NumberOfJoints() < Clip::MAX_NUM_JOINTS);
	JointMatrix temp[Clip::MAX_NUM_JOINTS];

	if (!mBlendList.IsEmpty())
	{
		const Ingredient& base = mBlendList[0];
		const Clip* clip = ClipManager::GetInstance()->GetClip(base.clipId);
        clip->GetRelativeJoints(base.clipStartTime, base.clipEndTime, jointList, base.isMirrored, base.isReversed);

		const int numberOfJoints = NumberOfJoints();
		for(unsigned i = 1; i < mBlendList.Count(); ++i)
		{
			const Ingredient& ingredient = mBlendList[i];

			clip = ClipManager::GetInstance()->GetClip(ingredient.clipId);
            clip->GetRelativeJoints(ingredient.clipStartTime, ingredient.clipEndTime, temp, ingredient.isMirrored, ingredient.isReversed);

			if (ingredient.isRootBlended)
			{
				jointList[0] = Blend(ingredient.weight, jointList[0], temp[0]);
			}
			for (int j = 1; j < numberOfJoints; ++j)
			{
				jointList[j] = Blend(ingredient.weight, jointList[j], temp[j]);
			}
		}
	}
	jointList[0] = mPreTransform * jointList[0];
	jointList[0] *= mPostTransform;
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::LocalPoseToWorldPose(JointMatrix* jointList) const
{
	AP_ASSERTMESSAGE(NULL != GetMount(), "No body registered a skeletal mount!");
	const Gel::Skeleton& mount = *GetMount();
	const Skeleton& skeleton = *GetSkeleton();
	AP_ASSERTMESSAGE(skeleton.NumberOfJoints() == mount.GetNumJoints(), "Skeletal joint counts are out of sync.");

	const int numberOfJoints = skeleton.NumberOfJoints();
	for (int i = 1; i < numberOfJoints; ++i)
	{
		AP_ASSERT(static_cast<int>(static_cast<char>(skeleton[i].mParent)) < i);

		jointList[i] *= mount[i].mBone; // Review(danc): shouldn't we apply this matrix in GenerateLocalPose()? 
		jointList[i] *= jointList[skeleton[i].mParent];

		AP_DATAVALIDATION_SUPPORT( jointList[i].Validate() );
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::WorldPoseToSkinPose(JointMatrix* jointList) const
{
	AP_ASSERTMESSAGE(NULL != GetMount(), "No body registered a skeletal mount!");
	const Gel::Skeleton& mount = *GetMount();
	const Skeleton& skeleton = *GetSkeleton();
	AP_ASSERTMESSAGE(skeleton.NumberOfJoints() == mount.GetNumJoints(), "Skeletal joint counts are out of sync.");

	const int numberOfJoints = skeleton.NumberOfJoints();
	for (int i = 0; i < numberOfJoints; ++i)
	{
		jointList[i] = mount[i].mSkin * jointList[i];

		AP_DATAVALIDATION_SUPPORT( jointList[i].Validate() );
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Recipe::MergePhases(const PhaseList& second)
{
	PhaseList first = mPhaseList;
	mPhaseList.Clear();

	unsigned int i = 0;
	unsigned int j = 0;
	while (i < first.Count() && j < second.Count())
	{
		if (first[i].start == second[j].start)
		{	// They are the same remove one
			++i;
		}
		else if (first[i].start < second[j].start)
		{	// Consume first element
			if (mPhaseList.IsEmpty() || mPhaseList.LastItem().state != first[i].state)
			{
				mPhaseList.Add(first[i]);
			}
			++i;
		}
		else
		{	// Consume second element
			if (mPhaseList.IsEmpty() || mPhaseList.LastItem().state != second[j].state)
			{
				mPhaseList.Add(second[j]);
			}
			++j;
		}
	}

	// Just add the remaining elements to the list
	while (i < first.Count())
	{
		mPhaseList.Add(first[i]);
		++i;
	}
	while (j < second.Count())
	{
		mPhaseList.Add(second[j]);
		++j;
	}
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)


// End of file --------------------------------------------------------------------------------------------------------

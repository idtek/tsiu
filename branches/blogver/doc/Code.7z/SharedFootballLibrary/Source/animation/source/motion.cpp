// motion.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/motion.h>
#include <animation/character.h>
#include <core/serializer.h>
#include "system/systemrand.h"

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// class Motion -------------------------------------------------------------------------------------------------------
AP_TYPE(Motion)
	AP_PROPERTY_USERDEBUG("Name", GetName, SetName, "What is the name of the motion.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
Motion::Motion(const Axiom::StringCRC& name)
: mName(name)
{
}

// --------------------------------------------------------------------------------------------------------------------
void Motion::SetName(const char* name)
{
	// We need to reposition ourselve in the character list.
	Character* character = FindCharacter();
	MotionId id = mName;
	mName = name;
	character->mMotions.Rehash(id, mName);
}

// --------------------------------------------------------------------------------------------------------------------
const char*	Motion::GetName() const
{
	return mName.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
const Character* Motion::FindCharacter() const
{
	return const_cast<Motion*>(this)->FindCharacter();
}

// --------------------------------------------------------------------------------------------------------------------
Character* Motion::FindCharacter()
{
	// Warning this is a long search so don't call this regularly or in a tight loop

	CharacterLibrary* library = CharacterLibrary::GetInstance();
	const unsigned numberOfCharacters = library->NumberOfCharacters();

	Character* character = NULL;
	for (unsigned i = 0; NULL == character && i < numberOfCharacters; ++i)
	{
		Character* testCharacter = library->GetCharacter(i);
		const MotionIndex& motionIndex = testCharacter->FindMotion(Name());
		if (-1 == motionIndex)
		{
			continue;
		}

		const Motion* motion = testCharacter->GetMotion(motionIndex);
		if (this == motion)
		{
			character = testCharacter;
		}
	}

	AP_ASSERT(NULL != character);
	return character;
}

// --------------------------------------------------------------------------------------------------------------------
void Motion::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (stream.IsReading())
	{
		//Character* character = FindCharacter();

		MotionId id = mName;
		stream & mName;

		if (NULL == character)
		{
			character = FindCharacter();
		}
		character->mMotions.Rehash(id, mName);
	}
	else
	{
		stream & mName;
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Motion::SerializeParameter(Axiom::Serializer& stream, const Character* character, Individual::Parameter& parameter)
{
	unsigned hashName = stream.IsWriting() && NULL != parameter ? parameter->HashName().Value() : 0;
	stream & hashName;
	if (stream.IsReading())
	{
		Axiom::CRC parameterName;
		parameterName = hashName;
		parameter = 0 != hashName ? character->FindParameter(parameterName) : NULL;
	}
}

// class MotionList ---------------------------------------------------------------------------------------------------
AP_TYPE(MotionList)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)
	AP_COMMAND(NumberOfMotions, "The number of motions in the motion list.")
	AP_NAMED_COMMAND("Add", AddMotionByName, "Add new motions by Name")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
const bool MotionList::IsPlayable(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const unsigned numberOfMotions = mMotions.Count();

	bool valid = true;
	for (unsigned i = 0; valid && i < numberOfMotions; ++i)
	{
		const Motion* motion = (*character)[mMotions.Item(i)];
		valid &= motion->IsPlayable(individual);
	}

	return valid;
}

// --------------------------------------------------------------------------------------------------------------------
void MotionList::StartPlayback(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const unsigned numberOfMotions = mMotions.Count();

	for (unsigned i = 0; i < numberOfMotions; ++i)
	{
		const Motion* motion = (*character)[mMotions.Item(i)];
		motion->StartPlayback(individual);
	}
}

// --------------------------------------------------------------------------------------------------------------------
const bool MotionList::Play(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const unsigned numberOfMotions = mMotions.Count();

	bool valid = true;
	for (unsigned i = 0; i < numberOfMotions; ++i)
	{
		const Motion* motion = (*character)[mMotions.Item(i)];
		valid &= motion->Play(individual);
	}
	return valid;
}

// --------------------------------------------------------------------------------------------------------------------
void MotionList::Serialize(Axiom::Serializer& stream, Character* character)
{
	Motion::Serialize(stream, character);

	unsigned numberOfMotions = mMotions.Count();
	stream & numberOfMotions;
	for (unsigned i = 0; i < numberOfMotions; ++i)
	{
		if (stream.IsWriting())
		{
			stream & mMotions.Item(i);
		}
		else
		{
			MotionIndex motion;
			stream & motion;
			mMotions.Add(motion);
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
void MotionList::AddMotion(const Axiom::StringCRC& name)
{
	const Character* character = FindCharacter();
	const MotionIndex motion = character->FindMotion(name);
	mMotions.Add(motion);
}

// class CompositeMotion ---------------------------------------------------------------------------------------------------
AP_TYPE(CompositeInfo)
AP_TYPE_END()

AP_TYPE(CompositeMotion)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)
	AP_COMMAND(NumberOfMotions, "The number of motions in the motion list.")
	AP_FIELD("Motions", mMotions, "The Submotions of this composite motion") 
	AP_NAMED_COMMAND("Add", AddMotionByName, "Add new motions by Name")
	AP_FIELD_USERDEBUG("Switchable", mSwitchable, "Is the composite free to switch to other internal elements")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
CompositeMotion::CompositeMotion()
: mCompositeData(NULL)
, mSwitchable(true)
{
}

// --------------------------------------------------------------------------------------------------------------------
void CompositeMotion::Initialize(const Character* character)
{
	mCompositeData	= character->FindParameter("CompositeData");
	AP_ASSERT(NULL != mCompositeData);
}

// --------------------------------------------------------------------------------------------------------------------
const bool CompositeMotion::IsPlayable(const Individual::Ptr& individual) const
{
	return 0 <= PlayableIndex(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void CompositeMotion::StartPlayback(Individual::Ptr& individual) const
{
	SelectMotion(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const bool CompositeMotion::Play(Individual::Ptr& individual) const
{
	const Character* character	= individual->GetCharacter();
	CompositeInfo* info	= individual->GetParameter<CompositeInfo>(mCompositeData);
	AP_ASSERT(0 <= info->GetActive());

	const int activeChild	= info->GetActive();
	const Motion* motion	= (*character)[mMotions.Item(activeChild)];
	bool continuePlaying	= PlayMotion(info, motion, individual);
	if (mSwitchable && !continuePlaying)
	{
		int newChild;
		do {
			SelectMotion(individual);
			newChild = info->GetActive();
			if (0 <= newChild)
			{
				motion			= (*character)[mMotions.Item(newChild)];
				continuePlaying	= PlayMotion(info, motion, individual);
			}
		} while (!continuePlaying && 0 <= newChild);
	}

	return continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void CompositeMotion::Serialize(Axiom::Serializer& stream, Character* character)
{
	Motion::Serialize(stream, character);

	unsigned numberOfMotions = mMotions.Count();
	stream & numberOfMotions;
	for (unsigned i = 0; i < numberOfMotions; ++i)
	{
		if (stream.IsWriting())
		{
			stream & mMotions.Item(i);
		}
		else
		{
			MotionIndex motion;
			stream & motion;
			mMotions.Add(motion);
		}
	}
	stream & mSwitchable;
}

// --------------------------------------------------------------------------------------------------------------------
const bool CompositeMotion::PlayMotion(CompositeInfo* info, const Motion* motion, Individual::Ptr& individual) const
{
	AP_ASSERT(NULL != info);
	info->Push();
	const bool continuePlaying = motion->Play(individual);
	info->Pop();
	return continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void CompositeMotion::SelectMotion(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	CompositeInfo* info = individual->GetParameter<CompositeInfo>(mCompositeData);
	const int playableIndex = PlayableIndex(individual);

	if (0 <= playableIndex)
	{
		const Motion* motion = (*character)[mMotions.Item(playableIndex)];
#if DEBUG_ANIMATION_SWITCH
		Animation::Log("%d - CompositeContext: %s", individual->GetGUID(), motion->Name().AsChar());
#endif // DEBUG_ANIM_PARAMETERS
		info->Push();
		motion->StartPlayback(individual);
		info->Pop();
	}

	info->SetActive(playableIndex);
}

// --------------------------------------------------------------------------------------------------------------------
const int CompositeMotion::PlayableIndex(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const unsigned numberOfMotions = mMotions.Count();

	bool valid = false;
	unsigned i;
	for (i = 0; !valid && i < numberOfMotions; ++i)
	{
		const Motion* motion = (*character)[mMotions.Item(i)];
		valid |= motion->IsPlayable(individual);
	}

	return valid ? i - 1 : -1;
}

// --------------------------------------------------------------------------------------------------------------------
void CompositeMotion::AddMotion(const Axiom::StringCRC& name)
{
	const Character* character		= FindCharacter();
	const MotionIndex motionIndex	= character->FindMotion(name);
	AP_ASSERT(INVALID_ID != motionIndex);
	mMotions.Add(motionIndex);
}

// class RandomCompositeMotion ----------------------------------------------------------------------------------------
AP_TYPE(RandomCompositeMotion)
	AP_BASE_TYPE(CompositeMotion)
	AP_DEFAULT_CREATE()
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
const int RandomCompositeMotion::PlayableIndex(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const unsigned numberOfMotions = mMotions.Count();

	Axiom::Collections::StaticList<int, CompositeMotion::MAX_MOTIONS> playableMotions;
	for (unsigned i = 0; i < numberOfMotions; ++i)
	{
		const Motion* motion = (*character)[mMotions.Item(i)];
		if (motion->IsPlayable(individual))
		{
			playableMotions.Add(i);
		}
	}
	const unsigned min = 0;
	const unsigned max = playableMotions.Count() - 1;
	const int choice = ( max != -1 ? RANDINT(min, max) : 0 );
	return -1 != max ? playableMotions[choice] : -1;
}

// class SequentialMotion ----------------------------------------------------------------------------------------
AP_TYPE(SequentialMotion)
	AP_BASE_TYPE(CompositeMotion)
	AP_DEFAULT_CREATE()
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
void SequentialMotion::StartPlayback(Individual::Ptr& individual) const
{
	CompositeInfo* info	= individual->GetParameter<CompositeInfo>(mCompositeData);
	info->SetActive(-1);
	CompositeMotion::StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const int SequentialMotion::PlayableIndex(const Individual::Ptr& individual) const
{
	const int numberOfMotions	= static_cast<int>(mMotions.Count());
	const CompositeInfo* info	= individual->GetParameter<CompositeInfo>(mCompositeData);
	const Character* character	= individual->GetCharacter();

	int next = info->GetActive();
	bool playable = false;
	while(next < (numberOfMotions - 1) && !playable)
	{
		++next;
		const Motion* motion = (*character)[mMotions.Item(next)];
		playable = motion->IsPlayable(individual);
	}

	return numberOfMotions == next ? -1 : next;
}

// class RandomPlayMotion ---------------------------------------------------------------------------------------------
AP_TYPE(RandomPlayMotion)
	AP_BASE_TYPE(Motion)
	AP_DEFAULT_CREATE()
	AP_FIELD_USERDEBUG("ChanceForPlay", mChanceForPlay, "0.0 to 1.0 representing chance this motion will play")
	AP_PROPERTY("Playback", SubMotion, SubMotion, "What motion should be play given when random number condition is met")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
RandomPlayMotion::RandomPlayMotion()
: mChanceForPlay( 1.0f )
{
}

// --------------------------------------------------------------------------------------------------------------------
const bool RandomPlayMotion::IsPlayable(const Individual::Ptr& individual) const
{
	const Character* character				= individual->GetCharacter();
	const Motion* motion					= (*character)[mSubMotion];
	// craigf - it might be desirable to select one random number for each character per update
	// so future tests can work off the same value?
	const bool isPlayback					= RANDFLOAT( 0.0f, 1.0f ) <= mChanceForPlay
											&& motion->IsPlayable(individual);

	return isPlayback;
}

// --------------------------------------------------------------------------------------------------------------------
void RandomPlayMotion::StartPlayback(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const Motion* motion = (*character)[mSubMotion];
	motion->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const bool RandomPlayMotion::Play(Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	const Motion* motion = (*character)[mSubMotion];
	return motion->Play(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void RandomPlayMotion::Serialize(Axiom::Serializer& stream, Character* character)
{
	stream & mSubMotion;
	stream & mChanceForPlay;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	RandomPlayMotion::SubMotion() const
{
	const Character* character = FindCharacter();
	const Motion* motion = (*character)[mSubMotion];
	return motion->Name().AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void RandomPlayMotion::SubMotion(const char* motionName)
{
	const Character* character = FindCharacter();
	mSubMotion = character->FindMotion(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

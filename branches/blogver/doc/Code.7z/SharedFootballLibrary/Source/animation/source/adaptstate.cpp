// AdaptState.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "animation/adaptstate.h"
#include "animation/character.h"
#include "animation/motion.h"
#include "core/serializer.h"
#include <StEdFast/Interpretter/StateMachineScriptManager.h>
#include "string/stringutils.h"

#include "kernel/componentmanager.h"

using namespace AP;

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{
// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(AdaptStateData)
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(AdaptState)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)
	AP_PROPERTY("StateScript", StateScript, SetStateScript, "What state machine is used by this motion.")
	AP_PROPERTY("InitialState", InitialState, InitialState, "What state machine is used by this motion.")
	AP_EXPLICIT_PROXY("AcademyLibrary", "Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AdaptState::AdaptState()
: mStateScript()
, mStateFieldCache(NULL)
{
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::Initialize(const Character* character)
{
	mStateFieldCache = character->FindParameter("AdaptStateData");
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::InitializeIndividual(Individual::Ptr& individual) const
{
	AdaptStateData* adaptStateData = individual->GetParameter<AdaptStateData>(mStateFieldCache);
	adaptStateData->mStateData.SetIndividual(individual.pVal());
	adaptStateData->mStateConditionData.m_pConditionThisData	= &adaptStateData->mStateData;
	adaptStateData->mStateConditionData.m_pMutableThisData		= &adaptStateData->mStateData;
	adaptStateData->mStateTrackData.m_pInputThisData			= &adaptStateData->mStateData;
	adaptStateData->mStateTrackData.m_pMutableThisData			= &adaptStateData->mStateData;
	adaptStateData->mStateTrackData.m_pOutputThisData			= &adaptStateData->mStateData;

	adaptStateData->mStateMachine.Initialize(AP::StEdFast::StateMachineScriptManager::GetInstance().GetScript(mStateScript));
	//adaptStateData->mStateMachine.SetActiveScriptNode();
}

// --------------------------------------------------------------------------------------------------------------------
const bool AdaptState::IsPlayable(const Individual::Ptr& individual) const
{
	const AdaptStateData* adaptStateData = individual->GetParameter<AdaptStateData>(mStateFieldCache);
	return AP::StEdFast::EStateMachineStatus::Uninitialized != adaptStateData->mStateMachine.Status();
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::StartPlayback(Individual::Ptr&) const
{
}

// --------------------------------------------------------------------------------------------------------------------
const bool AdaptState::Play(Individual::Ptr& individual) const
{
	AdaptStateData* adaptStateData = individual->GetParameter<AdaptStateData>(mStateFieldCache);
	adaptStateData->mStateMachine.Update(	individual->ActiveTimeStep(), 
											adaptStateData->mStateConditionData, 
											adaptStateData->mStateTrackData);

	return true;
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::Serialize(Axiom::Serializer& stream, Character* character)
{
	Motion::Serialize(stream, character);

	char temp[128];
	Axiom::StringCopy(temp, mStateScript.AsChar(), array_count(temp));
	stream & temp;
	mStateScript = temp;

	Axiom::StringCopy(temp, mInitialState.AsChar(), array_count(temp));
	stream & temp;
	mInitialState = temp;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	AdaptState::StateScript() const
{
	return mStateScript.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::SetStateScript(const char* name)
{
	mStateScript = name;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	AdaptState::InitialState() const
{
	return mInitialState.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void AdaptState::InitialState(const char* name)
{
	mInitialState = name;
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

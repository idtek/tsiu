// RootAdjustment.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/rootadjustment.h>
#include <animation/character.h>
#include <animation/playbackmotion.h>
#include <math/conversion.h>
#include <core/serializer.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation 
{

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(RootAdjustmentInfo)
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(ContinuousRootAdjustment)
	AP_BASE_TYPE(Motion)
	AP_DEFAULT_CREATE()
	AP_PROPERTY_USERDEBUG("AngleName", AngleParameter, AngleParameter, "What angle do we base this adjustment on.")
	AP_PROPERTY_USERDEBUG("SpeedName", SpeedParameter, SpeedParameter, "What parameter should we use to control speed")
	AP_PROPERTY("Playback", PlaybackMotion, PlaybackMotion, "What motion are we adjusting.")
	AP_PROPERTY_USERDEBUG("AdjustmentRate", AdjustmentRate, AdjustmentRate, "How fast should this adjustment be.")
	AP_PROPERTY_USERDEBUG("PlaybackAngle", PlaybackAngle, PlaybackAngle, "How much will the playback motion turn.")
	AP_FIELD_USERDEBUG("Max", mMax, "Maximum value required from Angle.")
	AP_FIELD_USERDEBUG("Min", mMin, "Minimum value required from Angle.")
	AP_FIELD_USERDEBUG("MinSpeed", mMinSpeed, "Minimum value required from Angle.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
ContinuousRootAdjustment::ContinuousRootAdjustment()
:	mAdjustmentCache(NULL)
,	mPlaybackCache(NULL)
,	mTurningAngle(NULL)
,	mSpeedValue(NULL)
,	mPlaybackAngle(0)
,	mMax(0)
,	mMin(0)
,	mMinSpeed(0)
,	mPlayback()
,	mAdjustmentRate(0.0f)
//,	mTestAngleOnlyOnStartup(false)
{
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::Initialize(const Character* character)
{
	mAdjustmentCache	= character->FindParameter("RootAdjustmentData");
	mPlaybackCache		= character->FindParameter("ActivePlaybackData");
	AP_ASSERT(NULL != mAdjustmentCache);
	AP_ASSERT(NULL != mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
const bool ContinuousRootAdjustment::IsPlayable(const Individual::Ptr& individual) const
{
	const Motion* motion		= GetPlaybackMotion(individual);
	const float turningAngle	= *individual->GetParameter<float>(mTurningAngle);
	const float speed			= *individual->GetParameter<float>(mSpeedValue);
	return motion->IsPlayable(individual) &&  Axiom::Math::InRangeRelative(mMin, mMax, turningAngle) && speed >= mMinSpeed;
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::StartPlayback(Individual::Ptr& individual) const
{
	const Motion* motion = GetPlaybackMotion(individual);
	motion->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const bool ContinuousRootAdjustment::Play(Individual::Ptr& individual) const
{
	const Motion* motion				= GetPlaybackMotion(individual);
	const PlaybackInfo* playbackInfo	= GetPlaybackData(individual);
	const GenericTime initialProgress	= playbackInfo->mActiveProgress;
	const float turning					= *individual->GetParameter<float>(mTurningAngle);
	const float speed					= *individual->GetParameter<float>(mSpeedValue);

	const bool paramsStillGood			= Axiom::Math::InRangeRelative(mMin, mMax, turning) && speed >= mMinSpeed;
	const bool continuePlaying			= paramsStillGood && motion->Play(individual);
	if (continuePlaying && mAdjustmentRate > 0.f)
	{
		const Axiom::Math::Angle& turningAngle	= Axiom::Math::Angle::FromDegrees(turning);
		const Axiom::Math::Angle& clampAngle	= Axiom::Math::FClamp(turningAngle.AsRadians(), -mAdjustmentRate.AsRadians(), mAdjustmentRate.AsRadians());
		JointMatrix adjustment = JointMatrix::IDENTITY;
		adjustment.mRotation.SetYawPitchRoll(clampAngle, 0.f, 0.f);

		Recipe& pose = individual->PoseRecipe();
		pose.SetPostTransform(adjustment * pose.PostTransform());
	}

	return continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}
	Motion::Serialize(stream, character);
	
	Motion::SerializeParameter(stream, character, mAdjustmentCache);
	Motion::SerializeParameter(stream, character, mPlaybackCache);
	Motion::SerializeParameter(stream, character, mTurningAngle);
	Motion::SerializeParameter(stream, character, mSpeedValue);

	AP_ASSERT(NULL != mTurningAngle);

	stream & mPlaybackAngle;
	stream & mMax;
	stream & mMin;
	stream & mMinSpeed;
	stream & mPlayback;
	stream & mAdjustmentRate;
}

// --------------------------------------------------------------------------------------------------------------------
const char* ContinuousRootAdjustment::AngleParameter() const
{
	return mTurningAngle->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::AngleParameter(const char* name)
{
	const Character* character	= FindCharacter();
	mTurningAngle				= character->FindParameter(name);
	AP_ASSERT(NULL != mTurningAngle);
}

// --------------------------------------------------------------------------------------------------------------------
const char*	ContinuousRootAdjustment::SpeedParameter() const
{
	return mSpeedValue->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::SpeedParameter(const char* name)
{
	const Character* character	= FindCharacter();
	mSpeedValue					= character->FindParameter(name);
	AP_ASSERT(NULL != mSpeedValue);
}

// --------------------------------------------------------------------------------------------------------------------
RootAdjustmentInfo*	ContinuousRootAdjustment::GetAdjustmentData(Individual::Ptr& individual) const
{
	return individual->GetParameter<RootAdjustmentInfo>(mAdjustmentCache);
}

// --------------------------------------------------------------------------------------------------------------------
PlaybackInfo* ContinuousRootAdjustment::GetPlaybackData(Individual::Ptr& individual) const
{
	return individual->GetParameter<PlaybackInfo>(mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
const Motion* ContinuousRootAdjustment::GetPlaybackMotion(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	return (*character)[mPlayback];
}

// --------------------------------------------------------------------------------------------------------------------
const char* ContinuousRootAdjustment::PlaybackMotion() const
{
	const Character* character = FindCharacter();
	return (*character)[mPlayback]->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::PlaybackMotion(const char* name)
{
	const Character* character = FindCharacter();
	mPlayback = character->FindMotion(name);
}

// --------------------------------------------------------------------------------------------------------------------
float ContinuousRootAdjustment::AdjustmentRate() const
{
	return mAdjustmentRate.AsDegrees();
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::AdjustmentRate(float rate)
{
	mAdjustmentRate = Axiom::Math::Angle::FromDegrees(rate);
}

// --------------------------------------------------------------------------------------------------------------------
float ContinuousRootAdjustment::PlaybackAngle() const
{
	return mPlaybackAngle.AsDegrees();
}

// --------------------------------------------------------------------------------------------------------------------
void ContinuousRootAdjustment::PlaybackAngle(float degrees)
{
	mPlaybackAngle = Axiom::Math::Angle::FromDegrees(degrees);
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(PivotRootAdjustment)
	AP_BASE_TYPE(ContinuousRootAdjustment)
	AP_DEFAULT_CREATE()
	AP_FIELD_USERDEBUG("OffsetTime", mOffsetTime, "How much will the playback motion turn.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
PivotRootAdjustment::PivotRootAdjustment()
:	ContinuousRootAdjustment()
,	mMovementDirection(NULL)
,	mDesiredMovementDirection(NULL)
,	mOffsetTime(0.0)
{
}

// --------------------------------------------------------------------------------------------------------------------
void PivotRootAdjustment::Initialize(const Character* character)
{
	ContinuousRootAdjustment::Initialize(character);

	mMovementDirection			= character->FindParameter("MovementDirection");
	mDesiredMovementDirection	= character->FindParameter("DesiredMovementDirection");
	AP_ASSERT(NULL != mMovementDirection);
	AP_ASSERT(NULL != mDesiredMovementDirection);
}

// --------------------------------------------------------------------------------------------------------------------
void PivotRootAdjustment::StartPlayback(Individual::Ptr& individual) const
{
	ContinuousRootAdjustment::StartPlayback(individual);

	const Axiom::Math::Vector2& movement	= *individual->GetParameter<Axiom::Math::Vector2>(mMovementDirection);
	RootAdjustmentInfo* rootAdjustment		= GetAdjustmentData(individual);
	rootAdjustment->mStartTime				= individual->ActiveTime() + Axiom::Time::CreateFromSeconds(mOffsetTime);
	rootAdjustment->mCachedDirection		= Axiom::Math::Rotate(movement, mPlaybackAngle);

}

// --------------------------------------------------------------------------------------------------------------------
const bool PivotRootAdjustment::Play(Individual::Ptr& individual) const
{
	RootAdjustmentInfo* rootAdjustment	= GetAdjustmentData(individual);
	const PlaybackInfo* playbackInfo	= GetPlaybackData(individual);


	const Motion* motion				= GetPlaybackMotion(individual);
	const GenericTime initialProgress	= playbackInfo->mActiveProgress;

	const bool canStillPlay				= motion->Play(individual);
	const bool hasLooped				= initialProgress > playbackInfo->mActiveProgress;
	const bool continuePlaying			= canStillPlay && !hasLooped;

	if (continuePlaying && (mAdjustmentRate > 0.f))
	{
		if (rootAdjustment->mStartTime <= individual->UpdateTime())
		{
			const Axiom::Math::Vector2& movementDirection			= *individual->GetParameter<Axiom::Math::Vector2>(mMovementDirection);
			const Axiom::Math::Vector2& desiredMovementDirection	= *individual->GetParameter<Axiom::Math::Vector2>(mDesiredMovementDirection);
			const Axiom::Math::Angle& turningAngle					= Axiom::Math::Angle::FromDegrees(*individual->GetParameter<float>(mTurningAngle));

			const Axiom::Math::Vector2 desiredMovement				= Axiom::Math::Rotate(movementDirection, turningAngle);
			const Axiom::Math::Angle& angleDiff						= Animation::AngleBetweenXY(rootAdjustment->mCachedDirection,
																								desiredMovementDirection);

			// ensure angle diff is snake: 
			if (Axiom::Math::InRangeRelative(-Axiom::Math::Angle::Deg120.AsRadians(), Axiom::Math::Angle::Deg120.AsRadians(), angleDiff.AsRadians()))
			{
				const Axiom::Math::Angle diffAngle = Axiom::Math::FClamp(angleDiff.AsRadians(), -mAdjustmentRate.AsRadians(), mAdjustmentRate.AsRadians());


				JointMatrix adjustment = JointMatrix::IDENTITY;
				adjustment.mRotation.SetYawPitchRoll(diffAngle,0.f,0.f);

				Recipe& pose = individual->PoseRecipe();
				pose.SetPostTransform(adjustment * pose.PostTransform());
				rootAdjustment->mCachedDirection = Axiom::Math::Rotate(rootAdjustment->mCachedDirection, diffAngle);
			}
		}
	}

	return continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void PivotRootAdjustment::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}
	ContinuousRootAdjustment::Serialize(stream, character);

	Motion::SerializeParameter(stream, character, mMovementDirection);
	Motion::SerializeParameter(stream, character, mDesiredMovementDirection);

	stream & mOffsetTime;
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(RootAdjustment)
	AP_BASE_TYPE(Motion)
	AP_PROPERTY("Playback", PlaybackMotion, PlaybackMotion, "What motion are we adjusting.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
RootAdjustment::RootAdjustment()
: mAdjustmentCache(NULL)
, mPlaybackCache(NULL)
, mPlayback(-1)
{
}

// --------------------------------------------------------------------------------------------------------------------
void RootAdjustment::Initialize(const Character* character)
{
	mAdjustmentCache	= character->FindParameter("RootAdjustmentData");
	mPlaybackCache		= character->FindParameter("ActivePlaybackData");
	AP_ASSERT(NULL != mAdjustmentCache);
	AP_ASSERT(NULL != mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
const bool RootAdjustment::IsPlayable(const Individual::Ptr& individual) const
{
	const Motion* motion = GetPlaybackMotion(individual);
	return motion->IsPlayable(individual);
}

// --------------------------------------------------------------------------------------------------------------------
void RootAdjustment::StartPlayback(Individual::Ptr& individual) const
{
	// Root adjustments need relavant information from clips being activated, to provide this information we play the 
	// sub-motion without any adjustments to generate a recipe containing the newly activated clips.
	const Motion* motion				= GetPlaybackMotion(individual);
	PlaybackInfo* playbackInfo			= GetPlaybackData(individual); 
	PlaybackInfo cachePlaybackInfo		= *playbackInfo; 

	// Update playback info and fill recipe with starting pose
	motion->StartPlayback(individual);
	motion->Play(individual);	

	// Restore essential playback information such that a restart will result in the same recipe.
	// Note: mStartTransform, mFinalTransform and mDuration are not reset as they are cached values associated with the current recipe
	playbackInfo->mParameters			= cachePlaybackInfo.mParameters;
	playbackInfo->mActiveMotionName		= cachePlaybackInfo.mActiveMotionName;
	playbackInfo->mInitialProgress		= cachePlaybackInfo.mInitialProgress;
	playbackInfo->mPreviousProgress		= cachePlaybackInfo.mPreviousProgress;
	playbackInfo->mActiveProgress		= cachePlaybackInfo.mActiveProgress;
	playbackInfo->mEndProgress			= cachePlaybackInfo.mEndProgress;
	playbackInfo->mStartTime			= cachePlaybackInfo.mStartTime;
	playbackInfo->mInitialPlaybackRate	= cachePlaybackInfo.mInitialPlaybackRate;
	playbackInfo->mPlaybackRate			= cachePlaybackInfo.mPlaybackRate;
	playbackInfo->mLooped				= cachePlaybackInfo.mLooped;
	motion->StartPlayback(individual);

	// Initialize the root adjustment structure to default
	RootAdjustmentInfo* rootAdjustment	= GetAdjustmentData(individual);
	rootAdjustment->mStartTime			= individual->ActiveTime();
	rootAdjustment->mEndTime			= rootAdjustment->mStartTime;
	rootAdjustment->mFinalTransform		= JointMatrix::IDENTITY;
	rootAdjustment->mActiveTransform	= JointMatrix::IDENTITY;

	CalculateAdjustment(individual, rootAdjustment);
}

// --------------------------------------------------------------------------------------------------------------------
const bool RootAdjustment::Play(Individual::Ptr& individual) const
{
	RootAdjustmentInfo* rootAdjustment	= GetAdjustmentData(individual);
	PlaybackInfo* playbackInfo			= GetPlaybackData(individual);
	const Motion* motion				= GetPlaybackMotion(individual);
	const GenericTime initialProgress	= playbackInfo->mActiveProgress;
	const bool continuePlaying			= motion->Play(individual);
	if (continuePlaying)
	{
		const bool hasLooped			= initialProgress > playbackInfo->mActiveProgress;
		if (hasLooped)
		{
			// On loop reset the root adjustment information
			RootAdjustmentInfo* rootAdjustment	= GetAdjustmentData(individual);
			rootAdjustment->mStartTime			= individual->ActiveTime();
			rootAdjustment->mEndTime			= rootAdjustment->mStartTime;
			rootAdjustment->mFinalTransform		= JointMatrix::IDENTITY;
			rootAdjustment->mActiveTransform	= JointMatrix::IDENTITY;

			CalculateAdjustment(individual, rootAdjustment);
		}

		if (rootAdjustment->IsAdjusting(individual))
		{
			Recipe& pose							= individual->PoseRecipe();
			const Axiom::TimeAbsolute& updateTime	= Axiom::Math::Min(individual->UpdateTime(), rootAdjustment->mEndTime);
			const Axiom::Time& duration				= rootAdjustment->mEndTime - rootAdjustment->mStartTime;
			const float& activeFraction				= (updateTime - rootAdjustment->mStartTime) / duration;

			JointMatrix postTransform;
			postTransform = JointMatrix( rootAdjustment->mActiveTransform.mRotation.AsInverse() );
			postTransform *= pose.PostTransform();
			postTransform *= JointMatrix( -rootAdjustment->mActiveTransform.mTranslation );

			rootAdjustment->mActiveTransform		= Blend(activeFraction, JointMatrix::IDENTITY, rootAdjustment->mFinalTransform);
			postTransform *= JointMatrix( rootAdjustment->mActiveTransform.mTranslation );

			pose.SetPreTransform( JointMatrix(rootAdjustment->mActiveTransform.mRotation) );
			pose.SetPostTransform( postTransform );
		}
	}

	return continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void RootAdjustment::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}
	Motion::Serialize(stream, character);

	Motion::SerializeParameter(stream, character, mAdjustmentCache);
	Motion::SerializeParameter(stream, character, mPlaybackCache);

	stream & mPlayback;
}

// --------------------------------------------------------------------------------------------------------------------
RootAdjustmentInfo*	RootAdjustment::GetAdjustmentData(Individual::Ptr& individual) const
{
	return individual->GetParameter<RootAdjustmentInfo>(mAdjustmentCache);
}

// --------------------------------------------------------------------------------------------------------------------
const RootAdjustmentInfo*	RootAdjustment::GetAdjustmentData(const Individual::Ptr& individual) const
{
	return individual->GetParameter<const RootAdjustmentInfo>(mAdjustmentCache);
}

// --------------------------------------------------------------------------------------------------------------------
PlaybackInfo* RootAdjustment::GetPlaybackData(Individual::Ptr& individual) const
{
	return individual->GetParameter<PlaybackInfo>(mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
const PlaybackInfo* RootAdjustment::GetPlaybackData(const Individual::Ptr& individual) const
{
	return individual->GetParameter<const PlaybackInfo>(mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
const Motion* RootAdjustment::GetPlaybackMotion(const Individual::Ptr& individual) const
{
	const Character* character = individual->GetCharacter();
	return (*character)[mPlayback];
}

// --------------------------------------------------------------------------------------------------------------------
const char* RootAdjustment::PlaybackMotion() const
{
	const Character* character = FindCharacter();
	return (*character)[mPlayback]->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void RootAdjustment::PlaybackMotion(const char* name)
{
	const Character* character = FindCharacter();
	mPlayback = character->FindMotion(name);
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(TurningAngleAdjustment)
	AP_BASE_TYPE(RootAdjustment)
	AP_DEFAULT_CREATE()
	AP_PROPERTY_USERDEBUG("AngleParameter", AngleParameter, AngleParameter, "What angle do we base this adjustment on.")
	AP_PROPERTY_USERDEBUG("PlaybackAngle", PlaybackAngle, PlaybackAngle, "How much will the playback motion turn.")
	AP_FIELD_USERDEBUG("Duration", mDuration, "Maximum value required from Angle.")
	AP_FIELD_USERDEBUG("Max", mMax, "Maximum value required from Angle.")
	AP_FIELD_USERDEBUG("Min", mMin, "Minimum value required from Angle.")
	AP_FIELD_USERDEBUG("IsEntryCondition", mIsEntryCondition, "Flag indicate to only test against angle when starting the motion")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
TurningAngleAdjustment::TurningAngleAdjustment()
:	mTurningAngle(NULL)
,	mPlayback()
,	mPlaybackAngle(0)
,	mDuration(0)
,	mMax(0)
,	mMin(0)
,	mIsEntryCondition(false)
{
}

// --------------------------------------------------------------------------------------------------------------------
const bool TurningAngleAdjustment::IsPlayable(const Individual::Ptr& individual) const
{
	const float& turningAngle		= *individual->GetParameter<float>(mTurningAngle);
	const bool isPlayable			= RootAdjustment::IsPlayable(individual)
									&& Axiom::Math::InRangeRelative(mMin, mMax, turningAngle);
	return isPlayable;
}

// --------------------------------------------------------------------------------------------------------------------
const bool TurningAngleAdjustment::Play(Individual::Ptr& individual) const
{
	const float& turningAngle			= *individual->GetParameter<float>(mTurningAngle);
	const PlaybackInfo* playbackInfo	= GetPlaybackData(individual);
	const GenericTime initialProgress	= playbackInfo->mActiveProgress;
	const bool continuePlaying			= RootAdjustment::Play(individual);
	const bool hasLooped				= initialProgress > playbackInfo->mActiveProgress;
	const bool withinRange				= (!hasLooped && mIsEntryCondition) 
										|| Axiom::Math::InRangeRelative(mMin, mMax, turningAngle);

	return withinRange && continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void TurningAngleAdjustment::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}
	RootAdjustment::Serialize(stream, character);

	Motion::SerializeParameter(stream, character, mTurningAngle);

	stream & mPlayback;
	stream & mPlaybackAngle;
	stream & mDuration;
	stream & mMax;
	stream & mMin;
	stream & mIsEntryCondition;
}

// --------------------------------------------------------------------------------------------------------------------
void TurningAngleAdjustment::CalculateAdjustment(Individual::Ptr& individual, RootAdjustmentInfo* adjustment) const
{
	const Axiom::Math::Angle& turningAngle	= Axiom::Math::Angle::FromDegrees(*individual->GetParameter<float>(mTurningAngle));
	const Axiom::Math::Angle& diff			= turningAngle - mPlaybackAngle;
	//const float degreesDiff					= diff.AsDegrees(); (void)degreesDiff;

	adjustment->mFinalTransform.mRotation.AxisAngle(Axiom::Math::Vector3::ZAxis(), diff);
	adjustment->mStartTime					= individual->ActiveTime();
	adjustment->mEndTime					= adjustment->mStartTime + Axiom::Time::CreateFromSeconds(mDuration);
}

// --------------------------------------------------------------------------------------------------------------------
const char* TurningAngleAdjustment::AngleParameter() const
{
	return mTurningAngle->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void TurningAngleAdjustment::AngleParameter(const char* name)
{
	const Character* character	= FindCharacter();
	mTurningAngle				= character->FindParameter(name);
	AP_ASSERT(NULL != mTurningAngle);
}

// --------------------------------------------------------------------------------------------------------------------
float TurningAngleAdjustment::PlaybackAngle() const
{
	return mPlaybackAngle.AsDegrees();
}

// --------------------------------------------------------------------------------------------------------------------
void TurningAngleAdjustment::PlaybackAngle(float degrees)
{
	mPlaybackAngle = Axiom::Math::Angle::FromDegrees(degrees);
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

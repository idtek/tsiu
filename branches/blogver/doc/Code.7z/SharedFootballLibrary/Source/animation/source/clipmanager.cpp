// clipmanager.cpp - (c) 2006 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "animation/clipmanager.h"
#include "reflection/script.h"
#include <core/serializer.h>
#include <math/conversion.h>
#include "animation/tag.h"

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(ClipManager)
	AP_COMMAND_USERDEBUG(ClipName,		"Get clip id's string name.")
	AP_COMMAND_USERDEBUG(Delete,		"Delete the given clip Id from the library.")
	
	AP_COMMAND_USERDEBUG(NewSkeleton,	"Adds a new skeleton description to the clip manager if one does not already exist with the same name.")
	AP_COMMAND_USERDEBUG(NumSkeletons,	"Gets the total number of skeletons available in the library.")
	AP_COMMAND_USERDEBUG(FindSkeleton,	"Returns an index to a skeleton description based on a string name.")
	AP_COMMAND_USERDEBUG(GetSkeleton,	"Returns a skeleton description stored in the clip manager.")
	AP_COMMAND_USERDEBUG(NewClip,		"Adds a new clip description to the clip manager if one does not already exist with the same name.")
	AP_COMMAND_USERDEBUG(NewClipV2,		"Adds a new clip description to the clip manager, includes start joint and number of joints.")
	AP_COMMAND_USERDEBUG(NumClips,		"Gets the total number of clips available in the library.")
	AP_COMMAND_USERDEBUG(FindClip,		"Returns an index to a clip description based on a string name.")
	AP_COMMAND_USERDEBUG(GetClip,		"Returns a clip description stored in the clip manager.")

	AP_NAMED_COMMAND_USERDEBUG("GetSpeed", GetSpeedByName, "Computes the speed of the given clip.")
	AP_NAMED_COMMAND_USERDEBUG("GetDisplacement", GetDisplacementByName, "Computes the displacement of the given clip.")
	AP_NAMED_COMMAND_USERDEBUG("GetTurningRate", GetTurningRateByName, "Computes the turning rate in the given clip.")
	AP_NAMED_COMMAND_USERDEBUG("GetTurningAngle", GetTurningAngleByName, "Computes the amount of turn in the given clip.")
	AP_NAMED_COMMAND_USERDEBUG("GetOffsetToJoint", GetOffsetToJointByName, "Computes the offset to a specific joint.")
	AP_NAMED_COMMAND_USERDEBUG("GetMovementDirection", GetMovementDirectionByName, "Computes the offset to a specific joint.")
	
	AP_NAMED_COMMAND_USERDEBUG("GetTransformAtTime", GetTransformAtTimeByName, "Computes the root transform at a given time in seconds.")
	AP_NAMED_COMMAND_USERDEBUG("GetStartTransform", GetStartTransformByName, "Computes the transformation matrix of a given joint at time 0.")
	AP_NAMED_COMMAND_USERDEBUG("GetTagTime", GetTagTimeByName, "Computes time from the start of the clip to where the specfied tag occures.")
	AP_NAMED_COMMAND_USERDEBUG("GetDuration", GetDurationByName, "Computes time / duration of specified clip.")
	AP_NAMED_COMMAND_USERDEBUG("TimeToGenericTime", TimeToGenericTimeByName, "Computes generic time given the clip time in seconds.")
	AP_NAMED_COMMAND_USERDEBUG("GetStateStartPosition", GetStateStartPositionByName, "Computes generic time position from the start of the clip to where the specfied state begins.")

	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")

AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
ClipManager::ClipManager()
{ 
	AP::Reflection::Script::Register("ClipManager", AP::Reflection::Instance(this), "Animation clip manager");
}

// --------------------------------------------------------------------------------------------------------------------
ClipManager::~ClipManager()
{
	AP::Reflection::Script::Unregister("ClipManager"); 
}

// --------------------------------------------------------------------------------------------------------------------
SkeletonId ClipManager::NewSkeleton(const char* name, const int numJoints/*, const int numTags, const int numStates*/)
{
	const int numTags = 35; // danc: from soccertags.h
	const int numStates = 28; // danc: from soccertags.h
	Skeleton* skeleton = Skeleton::Make(name, numJoints, numTags, numStates);
	SkeletonId existing = FindSkeleton(name);
	if (!existing.IsValid())
	{
		mSkeletonSet.PushBack(skeleton);
		return (mSkeletonSet.Size() - 1);
	}

	mSkeletonSet[existing.Value()] = skeleton;
	return existing;
}

// --------------------------------------------------------------------------------------------------------------------
SkeletonId ClipManager::FindSkeleton(const char* name) const
{
	int count = 0;
	const Axiom::StringCRC crc = name;
	SkeletonLibrary::Iterator i = const_cast<SkeletonLibrary*>(&mSkeletonSet)->Begin();
	SkeletonLibrary::Iterator end = const_cast<SkeletonLibrary*>(&mSkeletonSet)->End();
	while(i != end && (*i)->Name() != crc)
	{
		++i;
		++count;
	}

	return i == end ? SkeletonId() : count;
}

// --------------------------------------------------------------------------------------------------------------------
ClipId	ClipManager::NewClip(const char* name, const char* skeleton, const int numKeys, const float duration)
{
	// support old clips
	const int  numJoints = 29;
	return NewClipV2(name, skeleton, numKeys, duration, 0, numJoints);
}

// --------------------------------------------------------------------------------------------------------------------
ClipId	ClipManager::NewClipV2(const char* name, const char* skeleton, const int numKeys, const float duration, const int startJoint, const int numJoints)
{
	Axiom::ShortString lowercaseName = Axiom::ShortString(name);
	lowercaseName.ToLower(); 

	SkeletonId id = FindSkeleton(skeleton);
	Clip* clip = Clip::Make(id, numKeys, duration, startJoint, numJoints);
	ClipId existing = FindClip(name);
	if (INVALID_ID == existing)
	{
		mClipSet.PushBack(NamedClip(lowercaseName.AsChar(), clip));
		ClipId id = static_cast<ClipId>(mClipSet.Size() - 1);
		clip->SetId(id);
		return id;
	}

	mClipSet[existing].mPointer = clip;
	clip->SetId(existing);
	return existing;
}

// --------------------------------------------------------------------------------------------------------------------
ClipId	ClipManager::FindClip(const char* name) const
{
	Axiom::ShortString lowercaseString = Axiom::ShortString(name);
	lowercaseString.ToLower(); // Danc: Somebody remove this, only the tool should manage string case 

	int count = 0;
	Axiom::StringCRC crc = lowercaseString.AsChar();
	ClipLibrary::ConstIterator i = mClipSet.Begin();
	const ClipLibrary::ConstIterator iEnd = mClipSet.End();
	
	for( ; i != iEnd && i->mName != crc; ++i )
	{
	    ++count;
	}

	return ( i == iEnd ) ? INVALID_ID : count;
}

// --------------------------------------------------------------------------------------------------------------------
void ClipManager::Clear()
{
	//Remove all the loaded clips and skeletons
	mClipSet.Clear();
	mSkeletonSet.Clear();
}

// --------------------------------------------------------------------------------------------------------------------
void ClipManager::Delete(const ClipId i)
{
	mClipSet.Erase(mClipSet.At(i));
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetSpeed(const ClipId clipId, const bool mirrored) const
{
	AP_ASSERT(INVALID_ID != clipId);
	const Clip* clip = GetClip(clipId);
	const JointMatrix& jointMatrix = clip->GetJoint(0, clip->Duration(), mirrored);
	const float stride = jointMatrix.mTranslation.Magnitude();
	return stride / clip->Duration().AsFloatInSeconds();
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetSpeedByName(const char* name, const bool mirrored) const
{
	return GetSpeed(FindClip(name), mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetDisplacement(const ClipId clipId, const bool mirrored) const
{
	AP_ASSERT(INVALID_ID != clipId);
	const Clip* clip = GetClip(clipId);
	const JointMatrix& jointMatrix = clip->GetJoint(0, clip->Duration(), mirrored);
	const float displacement = jointMatrix.mTranslation.Magnitude();
	return displacement;
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetDisplacementByName(const char* name, const bool mirrored) const
{
	return GetDisplacement(FindClip(name), mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetTurningRate(const ClipId clipId, const bool mirrored) const
{
	AP_ASSERT(INVALID_ID != clipId);
	const Clip* clip = GetClip(clipId);
	const float turningAngleInDegrees = GetTurningAngle(clipId, mirrored);
	return turningAngleInDegrees / clip->Duration().AsFloatInSeconds(); // return a turning rate in degrees/second
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetTurningRateByName(const char* name, const bool mirrored) const
{
	return GetTurningRate(FindClip(name), mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetTurningAngle(const ClipId clipId, const bool mirrored) const
{
	AP_ASSERT(INVALID_ID != clipId);
	const Clip* clip = GetClip(clipId);
	const JointMatrix jointMatrix = clip->GetJoint(0, clip->Duration(), mirrored);
	const Axiom::Math::Vector3 endFacing = DEFAULT_FACING * jointMatrix.mRotation; 
	const Axiom::Math::Angle angle = Axiom::Math::AngleBetweenXY(DEFAULT_FACING, endFacing);

	return angle.AsDegrees();
}

// --------------------------------------------------------------------------------------------------------------------
float ClipManager::GetTurningAngleByName(const char* name, const bool mirrored) const
{
	return GetTurningAngle(FindClip(name), mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
// although there is an actual movement direction bone, I can't trust it for now, so I am calculating diff between root positions.
Axiom::Math::Vector2 ClipManager::GetMovementDirection(const ClipId clipId, const bool mirrored) const
{
	// Review(danc): Assumes that the joint is in world space ... not true for any bone other than the root!
	const Clip* clip				= GetClip(clipId);
	const JointMatrix& transformStart	= clip->GetJoint(0, 0, mirrored);
	const JointMatrix& transformEnd	= clip->GetJoint(0, clip->NumberOfKeys() - 1, mirrored);

	return (Axiom::Math::Vector2FromVector3XY(transformEnd.mTranslation - transformStart.mTranslation).AsNormal());
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Math::Vector2 ClipManager::GetMovementDirectionByName(const char* name, const bool mirrored) const
{
	return GetMovementDirection(FindClip(name), mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Math::Vector3 ClipManager::GetOffsetToJoint(const ClipId clipId, const bool mirrored, const float position, const int joint) const
{
	// Review(danc): Assumes that the joint is in world space ... not true for any bone other than the root!
	const Clip* clip				= GetClip(clipId);
	const JointMatrix& transform	= clip->GetJoint(joint, position*clip->Duration(), mirrored);

	return transform.mTranslation;
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Math::Vector3 ClipManager::GetOffsetToJointByName(const char* name, const bool mirrored, const float position, const char* jointName) const
{
	const ClipId clidId			= FindClip(name);
	const Clip* clip			= GetClip(clidId);
	const SkeletonId skeletonId	= clip->GetSkeletonID();
	const Skeleton* skeleton	= GetSkeleton(skeletonId);
	const int joint				= skeleton->FindJoint(jointName);
	return GetOffsetToJoint(clidId, mirrored, position, joint);
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix	ClipManager::GetTransformAtTime(const ClipId clipId, const bool mirrored, const Axiom::Time& time) const
{
	const Clip* clip = GetClip(clipId);
	Axiom::Time t = time;
	JointMatrix transform = JointMatrix::IDENTITY;
	while (t > clip->Duration())
	{
		transform *= clip->GetJoint(0, clip->Duration(), mirrored);
		t -= clip->Duration();
	}
	transform *= clip->GetJoint(0, t, mirrored);
	return transform;
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix	ClipManager::GetTransformAtTimeByName(const char* name, const bool mirrored, const Axiom::Time& time) const
{
	return GetTransformAtTime(FindClip(name), mirrored, time);
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix	ClipManager::GetStartTransform(const ClipId clipId, const bool mirrored, const int joint) const
{
	// Review(danc): I hope no one expects world space!
	const Clip* clip = GetClip(clipId);
	return clip->GetJoint(joint, 0, mirrored);
}

// --------------------------------------------------------------------------------------------------------------------
JointMatrix	ClipManager::GetStartTransformByName(const char* name, const bool mirrored, const char* jointName) const
{
	const ClipId id = FindClip(name);
	const Clip* clip = GetClip(id);
	return GetStartTransform(id, mirrored, GetSkeleton(clip->GetSkeletonID())->FindJoint(jointName));
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Time	ClipManager::GetTagTime(const ClipId clipId, TagId min, TagId max, int whichContact) const
{
	const Clip* clip = GetClip(clipId);
	const int numTags = clip->NumberOfTags();

	bool success = false;
	int currentContact = -1;
	ClipTag tag;
	for (int i = 0; i < numTags; ++i)
	{
		clip->GetTag(i, tag);
		if (min <= tag.mTagId && tag.mTagId <= max)
		{
			if (++currentContact == whichContact)
			{
				success = true;
				break;
			}
		}
	}

	AP_ASSERT (success);
	return clip->KeyTime(tag.mKey);
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Time	ClipManager::GetTagTimeByName(const char* name, TagId min, TagId max, int whichContact) const
{
	return GetTagTime(FindClip(name), min, max, whichContact);
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Time	ClipManager::GetDuration(const ClipId clipId) const
{
	const Clip* clip = GetClip(clipId);
	AP_ASSERT(clip);
	return clip->Duration();
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Time	ClipManager::GetDurationByName(const char* name) const
{
	return GetDuration(FindClip(name));
}

// --------------------------------------------------------------------------------------------------------------------
GenericTime	ClipManager::TimeToGenericTime(const ClipId clipId, const Axiom::Time& time) const
{
	const Clip* clip = GetClip(clipId);
	return time / clip->Duration();
}

// --------------------------------------------------------------------------------------------------------------------
GenericTime	ClipManager::TimeToGenericTimeByName(const char* name, const float seconds) const
{
	return TimeToGenericTime(FindClip(name), Axiom::Time::CreateFromSeconds(seconds));
}

// --------------------------------------------------------------------------------------------------------------------
GenericTime	ClipManager::GetStateStartPosition(const ClipId clipId, const bool mirrored, AnimStateId state, int whichContact) const
{
	const Clip* clip = GetClip(clipId);
	AP_ASSERT_SUPPORT(const int numStates = clip->NumberOfStateFrameRanges(state, mirrored));
	AP_ASSERT(numStates >= whichContact);
	const FrameRange* range = clip->GetStateFrameRange(state, mirrored, whichContact);
	const Axiom::Time& keyTime = clip->KeyTime(range->mBegin);

	return keyTime / clip->Duration();
}

// --------------------------------------------------------------------------------------------------------------------
GenericTime ClipManager::GetStateStartPositionByName(const char* name, const bool mirrored, AnimStateId state, int whichContact) const
{
	return GetStateStartPosition(FindClip(name), mirrored, state, whichContact);
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Serializer& operator&(Axiom::Serializer& stream, ClipManager::NamedClip& namedClip)
{
	AP_ASSERTMESSAGE(stream.GetVersion() > 2, "Clip versions lower than 3 not supported");

	Clip* clip = static_cast<Clip*>(namedClip.mPointer);
	stream & namedClip.mName;
	
	//Convert name to lower case
	Axiom::ShortString lowercaseString = Axiom::ShortString(namedClip.mName.AsChar());
	lowercaseString.ToLower();
	namedClip.mName = lowercaseString.AsChar();

	if (stream.GetVersion() == 3)
	{
		ClipManager::ClipV3(stream, clip);
	}
	else if (stream.GetVersion() == 4)
	{
		ClipManager::ClipV4(stream, clip);
	}
	else
	{
		stream & clip;
	}

	namedClip.mPointer = clip;
	return stream;
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Serializer& operator&(Axiom::Serializer& stream, ClipManager& clipManager)
{
	// Save skeleton information
	size_t size = clipManager.mSkeletonSet.Size();
	stream & size;
	for ( size_t i = 0; i < size; ++i )
	{
		Skeleton* skeleton = stream.IsWriting() ? clipManager.mSkeletonSet[i] : NULL;
		stream & skeleton;
		if (stream.IsReading())
			clipManager.mSkeletonSet.PushBack(skeleton);
	}

	// Save clip information
	size = clipManager.mClipSet.Size();
	stream & size;
	ClipManager::NamedClip element;
	for ( size_t i = 0; i < size; ++i )
	{
		if (stream.IsReading())
			clipManager.mClipSet.PushBack(element);

		stream & clipManager.mClipSet[i];
		clipManager.mClipSet[i].mPointer->SetId(i);
	}
	return stream;
}

// ------------------------------------------------------------------------------------------------------------
Axiom::Serializer& ClipManager::ClipV3(Axiom::Serializer& stream, Clip*& clip)
{
	AP_ASSERTMESSAGE(stream.IsReading(), "Cannot write version 3 clips.");

	ClipManager* clipManager	= ClipManager::GetInstance();
	SkeletonId id				= NULL == clip	? -1	: clip->mSkeleton;
	int numKeys					= NULL == clip	? -1	: clip->mNumKeys;
	float duration				= NULL == clip	? 0.f	: clip->mDuration.AsFloatInSeconds();
	int startJoint				= NULL == clip	? -1	: clip->mStartJoint;
	int numJoints				= NULL == clip	? 0		: clip->mNumJoints;

	stream & id & numKeys & duration & startJoint & numJoints;

	if (clip == NULL)
	{
		clip = Clip::Make(id, numKeys, duration, startJoint, numJoints);
	}
	const Skeleton& skeleton = *clipManager->GetSkeleton(id);	
	const size_t keySize = clip->KeySize();
	for (int i = 0; i < numKeys; ++i)
	{
		Axiom::Byte* key = clip->mKeys + i*keySize;

		for (int j = 0, offset = 0; j < numJoints; ++j)
		{			
			if (Skeleton::JointInfo::Rotation & skeleton[j+startJoint].mFormat)
			{
				float rot[4];
				stream & rot[0];
				stream & rot[1];
				stream & rot[2];
				stream & rot[3];
				Axiom::Math::Quaternion quat(rot[0], rot[1], rot[2], rot[3]);
				quat.Validate();
				Axiom::uint smallest3 = Clip::CompressQuatSmallest3(quat);
				*reinterpret_cast<Axiom::uint*>(key + offset) = smallest3;
				offset += sizeof(Axiom::uint);
			}
			int element = Skeleton::JointInfo::TranslateX;
			while (element <= Skeleton::JointInfo::TranslateW)
			{
				if (skeleton[j+startJoint].mFormat & element)
				{
					stream & *reinterpret_cast<float*>(key + offset);
					offset += sizeof(float);
				}
				element <<= 1;
			}
		}
	}	

	if(stream.IsWriting())
	{
		// tags
		unsigned int numTags = clip->NumberOfTags();
		stream & numTags;
		for(unsigned int i = 0; i < numTags; ++i)
		{
			ClipTag clipTag;
			AP_ASSERT_SUPPORTASSIGN(bool success, clip->GetTag(i, clipTag));
			AP_ASSERTMESSAGE(success == TRUE, "Error getting clip tag");
			stream & clipTag.mKey & clipTag.mTagId;
		}

		// states
		unsigned int numStates = clip->NumberOfStates();
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId = clip->GetStateId(i, false);
			stream & animStateId;
			unsigned int numStateFrameRanges = clip->NumberOfStateFrameRanges(animStateId, false);
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				const FrameRange* pFrameRange = clip->GetStateFrameRange(animStateId, false, n);
				AP_ASSERT(NULL != pFrameRange);

				stream & pFrameRange->mBegin & pFrameRange->mEnd;
			}
		}
	}
	else
	{
		// tags
		unsigned int numTags = 0;
		stream & numTags;
		AP_ASSERTMESSAGE(numTags <= static_cast<int>(Clip::MAX_NUM_TAGS), "There must be a problem");
		clip->ClearTags();
		for(unsigned int i = 0; i < numTags; ++i)
		{
			int key;
			TagId tag;
			stream & key & tag;
			clip->AddTag(key, tag);
		}

		// states
		unsigned int numStates;
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId;
			stream & animStateId;

			unsigned int numStateFrameRanges;
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				unsigned int begin, end;
				stream & begin & end;
				clip->AddStateFrameRange(animStateId, begin, end);
			}
		}
	}
	return stream;
}

// ------------------------------------------------------------------------------------------------------------
Axiom::Serializer& ClipManager::ClipV4(Axiom::Serializer& stream, Clip*& clip)
{
	AP_ASSERTMESSAGE(stream.IsReading(), "Cannot write version 4 clips.");

	ClipManager* clipManager	= ClipManager::GetInstance();
	SkeletonId id				= NULL == clip	? -1	: clip->mSkeleton;
	int numKeys					= NULL == clip	? -1	: clip->mNumKeys;
	float duration				= NULL == clip	? 0.f	: clip->mDuration.AsFloatInSeconds();
	int startJoint				= NULL == clip	? -1	: clip->mStartJoint;
	int numJoints				= NULL == clip	? 0		: clip->mNumJoints;

	stream & id & numKeys & duration & startJoint & numJoints;

	if (clip == NULL)
	{
		clip = Clip::Make(id, numKeys, duration, startJoint, numJoints);
	}
	const Skeleton& skeleton = *clipManager->GetSkeleton(id);
	const size_t keySize = clip->KeySize();
	for (int i = 0; i < numKeys; ++i)
	{
		Axiom::Byte* key = clip->mKeys + i*keySize;

		for (int j = 0, offset = 0; j < numJoints; ++j)
		{			
			if (Skeleton::JointInfo::Rotation & skeleton[j+startJoint].mFormat)
			{
				float rot[4];
				stream & rot[0];
				stream & rot[1];
				stream & rot[2];
				stream & rot[3];
				Axiom::Math::Quaternion quat(rot[0], rot[1], rot[2], rot[3]);
				quat.Validate();
				Axiom::uint smallest3 = Clip::CompressQuatSmallest3(quat);
				*reinterpret_cast<Axiom::uint*>(key + offset) = smallest3;
				offset += sizeof(Axiom::uint);
			}
			int element = Skeleton::JointInfo::TranslateX;
			while (element <= Skeleton::JointInfo::TranslateW)
			{
				if (skeleton[j+startJoint].mFormat & element)
				{
					stream & *reinterpret_cast<float*>(key + offset);
					offset += sizeof(float);
				}
				element <<= 1;
			}
		}	
	}

	if(stream.IsWriting())
	{
		// tags
		unsigned int numTags = clip->NumberOfTags();
		stream & numTags;
		for(unsigned int i = 0; i < numTags; ++i)
		{
			ClipTag clipTag;
			AP_ASSERT_SUPPORTASSIGN(bool success, clip->GetTag(i, clipTag));
			AP_ASSERTMESSAGE(success == TRUE, "Error getting clip tag");
			stream & clipTag.mKey & clipTag.mTagId;
		}

		// states
		unsigned int numStates = clip->NumberOfStates();
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId = clip->GetStateId(i, false);
			stream & animStateId;
			unsigned int numStateFrameRanges = clip->NumberOfStateFrameRanges(animStateId, false);
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				const FrameRange* pFrameRange = clip->GetStateFrameRange(animStateId, false, n);
				AP_ASSERT(NULL != pFrameRange);

				stream & pFrameRange->mBegin & pFrameRange->mEnd;
			}
		}
	}
	else
	{
		// tags
		unsigned int numTags = 0;
		stream & numTags;
		AP_ASSERTMESSAGE(numTags <= static_cast<int>(Clip::MAX_NUM_TAGS), "There must be a problem");
		clip->ClearTags();
		for(unsigned int i = 0; i < numTags; ++i)
		{
			int key;
			TagId tag;
			stream & key & tag;
			clip->AddTag(key, tag);
		}

		// states
		unsigned int numStates;
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId;
			stream & animStateId;

			unsigned int numStateFrameRanges;
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				unsigned int begin, end;
				stream & begin & end;
				clip->AddStateFrameRange(animStateId, begin, end);
			}
		}
	}

	// joint reparenting
	int numReparenting = clip->NumberOfJointReparents();
	stream & numReparenting;
	if (stream.IsReading() && numReparenting > 0)
	{
		clip->SetNumberOfJointReparents(numReparenting);
	}

	for (int r=0; r < numReparenting; ++r)
	{
		int joint = stream.IsWriting() ? clip->GetReparentingJointAtIndex(r) : -1;
		int reparent = stream.IsWriting() ? clip->GetReparentingParentAtIndex(r) : -1;
		stream & joint;
		stream & reparent;
		if (stream.IsReading())
		{
			clip->AddJointReparent(joint, reparent);
		}
	}

	return stream;
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

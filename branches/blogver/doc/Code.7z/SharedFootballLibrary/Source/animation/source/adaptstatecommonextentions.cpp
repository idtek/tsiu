// AdaptStateExtentions.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "animation/adaptstate.h"
#include "animation/animation.h"
#include "animation/character.h"
#include "animation/motion.h"
#include "math/vector2.h"
#include "string/string.h"

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// IndividualData -----------------------------------------------------------------------------------------------------
IndividualData::IndividualData()
: ThisData()
{
}

// --------------------------------------------------------------------------------------------------------------------
IndividualData::IndividualData(int guid)
: ThisData(guid) 
{
}

// --------------------------------------------------------------------------------------------------------------------
IndividualData::~IndividualData() 
{
}

// --------------------------------------------------------------------------------------------------------------------
IndividualData::IndividualData(const IndividualData& rhs)
: ThisData(rhs.m_GUID)
{
}

// --------------------------------------------------------------------------------------------------------------------
IndividualData& IndividualData::operator=(const IndividualData& rhs)
{
	(void)rhs;
	AP_ASSERTFAIL("Not implemented");
	return *this;
}

// AdaptStateData -----------------------------------------------------------------------------------------------------
StEdFastAdaptStateData::StEdFastAdaptStateData()
{
}

// --------------------------------------------------------------------------------------------------------------------
StEdFastAdaptStateData::~StEdFastAdaptStateData() 
{ 
}

// IsPlayableMotion ----------------------------------------------------------------------------------------------
AP_TYPE(IsPlayableMotion)
	AP_BASE_TYPE(AP::StEdFast::Condition)
	AP_DEFAULT_CREATE()
	AP_PROPERTY("MotionName", MotionName, MotionName, "What character motion does this condition apply to.")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
IsPlayableMotion::IsPlayableMotion()
{
}

// --------------------------------------------------------------------------------------------------------------------
IsPlayableMotion::~IsPlayableMotion()
{
}

// --------------------------------------------------------------------------------------------------------------------
void IsPlayableMotion::Init(const Axiom::StringCRC& motionName)
{
	mMotionName = motionName;
}

// --------------------------------------------------------------------------------------------------------------------
bool IsPlayableMotion::Evaluate(const AP::StEdFast::ConditionParameters& conditionParameters) const
{
	const IndividualData* pThis			= reinterpret_cast<const IndividualData*>(conditionParameters.m_pMutableThisData);
	const Individual::Ptr& individual	= pThis->GetIndividual();
	const Motion* motion				= individual->GetCharacter()->GetMotion(mMotionName);
	const bool isPlayable				= motion->IsPlayable(individual);
	return isPlayable;
}

// --------------------------------------------------------------------------------------------------------------------
const char*	IsPlayableMotion::MotionName() const
{
	return mMotionName.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void IsPlayableMotion::MotionName(const char* name)
{
	mMotionName	= name;
}

// PlayMotion ---------------------------------------------------------------------------------------------------------
AP_TYPE(PlayMotion)
	AP_BASE_TYPE(AP::StEdFast::Track)
	AP_DEFAULT_CREATE()
	AP_PROPERTY("MotionName", MotionName, MotionName, "What character motion does this condition apply to.")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
PlayMotion::PlayMotion()
{
}

// --------------------------------------------------------------------------------------------------------------------
void PlayMotion::Init(const Axiom::StringCRC& motionName)
{
	mMotionName = motionName;
}

// --------------------------------------------------------------------------------------------------------------------
void PlayMotion::OnPlay(const AP::StEdFast::TrackParameters& trackParameters) const
{
	const IndividualData* pThis	= reinterpret_cast<const IndividualData*>(trackParameters.m_pMutableThisData);
	Individual::Ptr individual	= pThis->GetIndividual();
	const Motion* motion		= individual->GetCharacter()->GetMotion(mMotionName);

#if DEBUG_ANIMATION_SWITCH
	Log("%d - StateContext: '%s'", individual->GetGUID(), motion->Name().AsChar());
#endif // DEBUG_ANIMATION_SWITCH
#if DEBUG_ANIMATION_PARAMETERS
	Individual::Parameter field = individual->GetCharacter()->IndividualType()->Fields();
	while (NULL != field)
	{
		if (AP::Reflection::TypeOf<float>() == field->Type())
		{
			const float value = *individual->GetParameter<float>(field);
			Log("\t%s: %f", field->Name(), value);
		}
		else if (AP::Reflection::TypeOf<int>() == field->Type())
		{
			const int value = *individual->GetParameter<int>(field);
			Log("\t%s: %d", field->Name(), value);
		}
		else if (AP::Reflection::TypeOf<Axiom::Math::Vector2>() == field->Type())
		{
			const Axiom::Math::Vector2& value = *individual->GetParameter<Axiom::Math::Vector2>(field);
			Log("\t%s: (%f, %f)", field->Name(), value.X(), value.Y());
		}
		else if (AP::Reflection::TypeOf<Axiom::Math::Angle>() == field->Type())
		{
			const Axiom::Math::Angle& value = *individual->GetParameter<Axiom::Math::Angle>(field);
			Log("\t%s: %f", field->Name(), value.AsDegrees());
		}
		else if (field->Type()->IsEnumerated())
		{
			Axiom::StaticString<64> tmp;
			individual->StateData().GetField(field).AsChar(tmp);
			Log("\t%s: %s", field->Name(), tmp.AsChar());
		}
		field = field->Next();
	}
#endif // DEBUG_ANIMATION_PARAMETERS

	motion->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
AP::StEdFast::EPlayStatus PlayMotion::Play(const Axiom::Time&, const AP::StEdFast::TrackParameters& trackParameters) const
{
	const IndividualData* pThis	= reinterpret_cast<const IndividualData*>(trackParameters.m_pMutableThisData);
	Individual::Ptr individual	= pThis->GetIndividual();

	const Motion* motion		= individual->GetCharacter()->GetMotion(mMotionName);
	const bool continuePlaying	= motion->Play(individual);
	return continuePlaying ? AP::StEdFast::EPlayStatus::Playing : AP::StEdFast::EPlayStatus::Done;
}

// --------------------------------------------------------------------------------------------------------------------
void PlayMotion::OnInterrupted(const AP::StEdFast::TrackParameters& trackParameters) const
{
	(void)trackParameters;
	// Should we start transition out?
}

// --------------------------------------------------------------------------------------------------------------------
void PlayMotion::OnDone(const AP::StEdFast::TrackParameters& trackParameters) const
{
	(void)trackParameters;
	// We never return done we always continue looping
}

// --------------------------------------------------------------------------------------------------------------------
const char*	PlayMotion::MotionName() const
{
	return mMotionName.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void PlayMotion::MotionName(const char* name)
{
	mMotionName	= name;
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

// PlaybackMotion.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/playbackmotion.h>
#include <animation/animation.h>
#include <animation/character.h>
#include <animation/clipmanager.h>
#include <core/serializer.h>

namespace Soccer
{
namespace Animation
{
// ------------------------------------------------------------------------------------------------------------
AP_TYPE(PlaybackInfo)
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
PlaybackInfo::PlaybackInfo()
: mInitialPlaybackRate(1.f)
, mPlaybackRate(1.f)
, mLooped(false)
{
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(Playback)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)

	AP_NAMED_COMMAND_USERDEBUG("AddClip", AddClipByName, "What is the clip we are using.")
	AP_NAMED_COMMAND_USERDEBUG("AddReverseClip",	AddReverseClipByName, "Add a new clip to the blend group played in reverse")
	AP_PROPERTY_USERDEBUG("Parameter",	Parameter, Parameter, "What blend parameter are we using")
	AP_PROPERTY_USERDEBUG("Cyclic",		Cyclic, Cyclic, "Is this motion loopable?")
	AP_FIELD_USERDEBUG("EndPosition",		mEndPosition, "Position to stop playing this motion in generic time.")
	AP_FIELD_USERDEBUG("PlaybackRate",	mPlaybackRate, "How much should the rate of playback be adjusted.")
	AP_FIELD_USERDEBUG("Clips",			mClips, "List of clip descriptions.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(Playback::ClipDescription)
	AP_FIELD_USERDEBUG("Value", mValue, "At what position does this clip appled for.")
	AP_FIELD_USERDEBUG("ClipId", mClipId, "The clip id.")
	AP_FIELD_USERDEBUG("Mirrored", mMirrored, "Is the clip mirrored?")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
Playback::Playback()
: mParameterCache(NULL)
, mPlaybackCache(NULL)
, mEndPosition(GenericTime::Invalid())
, mPlaybackRate(1.f)
{
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::Initialize(const Character* character)
{
	mPlaybackCache = character->FindParameter("ActivePlaybackData"); 
	AP_ASSERT(NULL != mPlaybackCache);
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::InitializeIndividual(Individual::Ptr& individual) const
{
	AP::Reflection::Instance activePlaybackData = individual->StateData().GetField(mPlaybackCache);
	activePlaybackData = individual->GetParameter<PlaybackInfo>(individual->GetCharacter()->FindParameter("PlaybackData")); 
}

// --------------------------------------------------------------------------------------------------------------------
const bool Playback::IsPlayable(const Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData	= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	const float value			= GetParameter(individual);

	unsigned i = 1;
	for (; i < mClips.Count() && !Axiom::Math::InRangeRelative(mClips[i - 1].mValue, mClips[i].mValue, value); ++i)
	{}

	const bool isPlaying		= Name() == playbackData->mActiveMotionName;
	const bool continuePlaying	= !isPlaying || playbackData->ContinuePlayback();
	const bool validConditions	= i != mClips.Count() || 1 == mClips.Count();
	return validConditions && continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::StartPlayback(Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData				= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	playbackData->mActiveMotionName			= Name();
	playbackData->mPlaybackRate				= playbackData->mInitialPlaybackRate*mPlaybackRate;
	playbackData->mParameters				= Axiom::Math::Vector2(GetParameter(individual), 0.f);
	AP_ASSERT( playbackData->mInitialProgress.AsFloat() >= 0.0f );
	playbackData->mActiveProgress			= playbackData->mInitialProgress;
	playbackData->mPreviousProgress			= playbackData->mActiveProgress;
	playbackData->mEndProgress				= mEndPosition;
	playbackData->mStartTime				= individual->ActiveTime();
	playbackData->mLooped					= false;
	playbackData->mInitialProgress			= GenericTime::Zero(); 
	playbackData->mInitialPlaybackRate		= 1.f; 
}

// --------------------------------------------------------------------------------------------------------------------
const bool Playback::Play(Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData				= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	const JointMatrix& transform			= individual->Transform();
	const float value						= GetParameter(individual);
	Recipe& pose							= individual->PoseRecipe();

	unsigned i = 1; // Review(danc): we can do binary search here.
	for (; i < mClips.Count() && !Axiom::Math::InRangeRelative(mClips[i - 1].mValue, mClips[i].mValue, value); ++i)
	{}

	const bool isPlaying					= Name() == playbackData->mActiveMotionName;
	const bool continuePlaying				= !isPlaying || playbackData->ContinuePlayback();
	const bool validConditions				= i != mClips.Count() || 1 == mClips.Count();
	if (!validConditions || !continuePlaying)
	{
		return false;
	}

	playbackData->mPreviousProgress			= playbackData->mActiveProgress;
	const float	activeProgress			    = playbackData->mActiveProgress.AsFloat();
	if (1 != mClips.Count())
	{
		const Clip* clip0					= ClipManager::GetInstance()->GetClip(mClips[i - 1].mClipId);
		const Clip* clip1					= ClipManager::GetInstance()->GetClip(mClips[i].mClipId);
		const float clamp					= Axiom::Math::FClamp(value, mClips[i - 1].mValue, mClips[i].mValue);
		const float fraction				= (clamp - mClips[i - 1].mValue) / (mClips[i].mValue - mClips[i - 1].mValue);
		const Axiom::Time blendDuration		= Blend(fraction, clip0->Duration(), clip1->Duration());
		const Axiom::Time timeStep			= playbackData->mPlaybackRate*individual->ActiveTimeStep();
		const Axiom::Time startTime			= activeProgress * blendDuration;
		const Axiom::Time endTime 			= startTime + timeStep;
		const GenericTime gTimeStep			= (endTime.AsFloatInMicroseconds() / blendDuration.AsFloatInMicroseconds()) - activeProgress;
		const float loopTime				= activeProgress - 1.f + gTimeStep.AsFloat();
		playbackData->mLooped				= playbackData->mLooped || loopTime >= 0.f;
		playbackData->mActiveProgress		= Axiom::Select(loopTime, loopTime, loopTime + 1.f);
		playbackData->mParameters			= Axiom::Math::Vector2(	Axiom::Select(loopTime, value, playbackData->mParameters.X()), 0.f);

        const float startProgress           = activeProgress;
        const float endProgress             = playbackData->mActiveProgress.AsFloat();
		pose.Reset(individual->ActiveTime(), individual->UpdateTime());
		Recipe pose0(	individual->ActiveTime(), individual->UpdateTime(), 
						individual->GetCharacterIndex(), individual->GetMount());
		pose0.SetClip(	mClips[i].mClipId, 
						mClips[i].mMirrored, 
                        mClips[i].mReversed,
                        (mClips[i].mReversed ? (1.f - startProgress) : startProgress) * clip1->Duration(), 
                        (mClips[i].mReversed ? (1.f - endProgress) : endProgress) * clip1->Duration());
		pose.SetClip(	mClips[i - 1].mClipId, 
						mClips[i - 1].mMirrored, 
                        mClips[i - 1].mReversed,
                        (mClips[i - 1].mReversed ? (1.f - startProgress) : startProgress) * clip0->Duration(), 
                        (mClips[i - 1].mReversed ? (1.f - endProgress) : endProgress) * clip0->Duration()); 

		pose.BlendRecipe(fraction, pose0);
		pose.SetPreTransform(JointMatrix::IDENTITY);
		pose.SetPostTransform(transform);
		pose.GenerateStartEndTransforms(&playbackData->mStartTransform, &playbackData->mFinalTransform, &playbackData->mDuration);
	}
	else
	{
		AP_ASSERT(1 == mClips.Count());
		const Clip* clip					= ClipManager::GetInstance()->GetClip(mClips[0].mClipId);
		const Axiom::Time clipDuration		= clip->Duration();
		const Axiom::Time startTime			= activeProgress * clipDuration;
		const Axiom::Time endTime			= startTime + playbackData->mPlaybackRate*individual->ActiveTimeStep();
		const GenericTime timeStep			= (endTime.AsFloatInMicroseconds() / clipDuration.AsFloatInMicroseconds()) 
												- playbackData->mActiveProgress.AsFloat();
		const float loopTime				= playbackData->mActiveProgress.AsFloat() - 1.f + timeStep.AsFloat();
		playbackData->mLooped				= playbackData->mLooped || loopTime >= 0.f;
		playbackData->mActiveProgress		= Axiom::Select(loopTime, loopTime, loopTime + 1.f);

        const float startProgress           = activeProgress;
        const float endProgress             = playbackData->mActiveProgress.AsFloat();

		pose.SetPreTransform(JointMatrix::IDENTITY);
		pose.SetPostTransform(transform);
		pose.Reset(individual->ActiveTime(), individual->UpdateTime());
		pose.SetClip(   mClips[0].mClipId, 
                        mClips[0].mMirrored, 
                        mClips[0].mReversed, 
                        (mClips[0].mReversed ? (1.f - startProgress) : startProgress) * clipDuration, 
                        (mClips[0].mReversed ? (1.f - endProgress) : endProgress) * clipDuration);
		pose.GenerateStartEndTransforms(&playbackData->mStartTransform, &playbackData->mFinalTransform, &playbackData->mDuration);
	}
	return playbackData->ContinuePlayback();
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}	

	Motion::Serialize(stream, character);
	
	Motion::SerializeParameter(stream, character, mPlaybackCache);
	Motion::SerializeParameter(stream, character, mParameterCache);

	stream & mEndPosition;
	stream & mPlaybackRate;	

	unsigned numberOfClips = mClips.Count();
	stream & numberOfClips;
	for (unsigned i = 0; i < numberOfClips; ++i)
	{
		if (stream.IsReading())
		{
			ClipDescription description;
			stream & description.mValue;
			stream & description.mClipId;
			stream & description.mMirrored;
			stream & description.mReversed;

			mClips.Add(description);
		}
		else
		{
			ClipDescription& description = mClips[i];
			stream & description.mValue;
			stream & description.mClipId;
			stream & description.mMirrored;
			stream & description.mReversed;
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::AddClip(ClipId clipId, const bool mirrored, const bool reversed, const float& value)
{
	AP_ASSERT(INVALID_ID != clipId);
	ClipDescription desc;
	desc.mClipId = clipId;
	desc.mMirrored = mirrored;
    desc.mReversed = reversed;
	desc.mValue = value;
	
	mClips.Add(desc);

	// danc: We must ensure sorted order (by mValue) 
	for(int i = mClips.Count() - 1; 0 < i && mClips[i].mValue < mClips[i - 1].mValue; --i)
	{
		Axiom::Swap(mClips[i], mClips[i - 1]); // very inefficent swap
	}
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::AddClipByName(const char* name, const bool mirrored, const float& value)
{
	const ClipManager* clipManager = ClipManager::GetInstance();
	AddClip(clipManager->FindClip(name), mirrored, false, value);
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::AddReverseClipByName(const char* name, const bool mirrored, const float& value)
{
	const ClipManager* clipManager = ClipManager::GetInstance();
	AddClip(clipManager->FindClip(name), mirrored, true, value);
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::Parameter(const char* parameter)
{
	const Character* character = FindCharacter();
	mParameterCache = character->FindParameter(parameter);
	AP_ASSERT(NULL != mParameterCache);
}

// --------------------------------------------------------------------------------------------------------------------
const char*	Playback::Parameter() const
{
	return NULL != mParameterCache ? mParameterCache->Name() : "";
}

// --------------------------------------------------------------------------------------------------------------------
float Playback::GetParameter(const Individual::Ptr& individual) const 
{
	return NULL != mParameterCache ? *individual->GetParameter<float>(mParameterCache) : 0.f;
}

// --------------------------------------------------------------------------------------------------------------------
bool Playback::Cyclic() const
{
	return !mEndPosition.IsValid();
}

// --------------------------------------------------------------------------------------------------------------------
void Playback::Cyclic(bool value)
{
	mEndPosition = value ? GenericTime::Invalid() : GenericTime::One();
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(PlaybackGroup)
	AP_DEFAULT_CREATE()
	AP_BASE_TYPE(Motion)

	AP_COMMAND_USERDEBUG(AddTriangle, "Add a counter-clockwise triangle")
	AP_NAMED_COMMAND_USERDEBUG("AddClip",	AddClipByName, "Add a new clip to the blend group")
	AP_NAMED_COMMAND_USERDEBUG("AddReverseClip",	AddReverseClipByName, "Add a new clip to the blend group played in reverse")
	AP_PROPERTY_USERDEBUG("Width",		WidthParameter, WidthParameter, "Width parameter");
	AP_PROPERTY_USERDEBUG("Length",		LengthParameter, LengthParameter, "Length parameter");
	AP_PROPERTY_USERDEBUG("Cyclic",		Cyclic, Cyclic, "Is this motion loopable?")
	AP_FIELD_USERDEBUG("EndPosition",		mEndPosition, "Position to stop playing this motion in generic time.")
	AP_FIELD_USERDEBUG("PlaybackRate",	mPlaybackRate, "How much should the rate of playback be adjusted.")
	AP_FIELD_USERDEBUG("Clips",			mClips, "List of clip descriptions.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(PlaybackGroup::ClipDescription)
	AP_FIELD_USERDEBUG("Position", mPosition, "At what position does this clip appled for.")
	AP_FIELD_USERDEBUG("ClipId", mClipId, "The clip id.")
	AP_FIELD_USERDEBUG("Mirrored", mMirrored, "Is the clip mirrored?")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
PlaybackGroup::PlaybackGroup()
: Motion()
, mPlaybackCache(NULL)
, mWidthParameterCache(NULL)
, mLengthParameterCache(NULL)
, mEndPosition(GenericTime::Invalid())
, mPlaybackRate(1.f)
{
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::Initialize(const Character* character)
{
	mPlaybackCache = character->FindParameter("ActivePlaybackData"); 
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::InitializeIndividual(Individual::Ptr& individual) const
{
	AP::Reflection::Instance activePlaybackData = individual->StateData().GetField(mPlaybackCache);
	activePlaybackData = individual->GetParameter<PlaybackInfo>(individual->GetCharacter()->FindParameter("PlaybackData")); 
}

// --------------------------------------------------------------------------------------------------------------------
const bool PlaybackGroup::IsPlayable(const Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData	= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	Axiom::Math::Vector2 position(	GetWidth(individual), GetLength(individual));
	Axiom::Math::Vector3 weights;

	unsigned i = 0;
	for (; i < mTriangles.Count() && !PointInTriangle(mTriangles[i], position, weights); ++i)
	{}

	const bool isPlaying		= Name() == playbackData->mActiveMotionName;
	const bool continuePlaying	= !isPlaying || playbackData->ContinuePlayback();
	const bool validConditions	= i != mTriangles.Count();
	return validConditions && continuePlaying;
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::StartPlayback(Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData				= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	playbackData->mActiveMotionName			= Name();
	playbackData->mPlaybackRate				= playbackData->mInitialPlaybackRate*mPlaybackRate;
	playbackData->mParameters				= Axiom::Math::Vector2(GetWidth(individual), GetLength(individual));
	AP_ASSERT( playbackData->mInitialProgress.AsFloat() >= 0.0f );
	playbackData->mActiveProgress			= playbackData->mInitialProgress;
	playbackData->mPreviousProgress			= playbackData->mActiveProgress;
	playbackData->mEndProgress				= mEndPosition;
	playbackData->mStartTime				= individual->ActiveTime();
	playbackData->mLooped					= false;
	playbackData->mInitialProgress			= GenericTime::Zero(); 
	playbackData->mInitialPlaybackRate		= 1.f; 
}

// --------------------------------------------------------------------------------------------------------------------
const bool PlaybackGroup::Play(Individual::Ptr& individual) const
{
	PlaybackInfo* playbackData				= individual->GetParameter<PlaybackInfo>(mPlaybackCache);
	const Axiom::Math::Vector2& position	= Axiom::Math::Vector2(GetWidth(individual), GetLength(individual));

	// Find triangle
	unsigned i = 0;
	Axiom::Math::Vector3 weights;
	for (; i < mTriangles.Count() && !PointInTriangle(mTriangles[i], position, weights); ++i)
	{}

	// Are all conditions right for the triangle?
	const bool isPlaying					= Name() == playbackData->mActiveMotionName;
	const bool continuePlaying				= !isPlaying || playbackData->ContinuePlayback();
	const bool validConditions				= i != mTriangles.Count();
	if (!validConditions || !continuePlaying)
	{
		return false;
	}

	// Compute the blend values to advance the active progress
	Recipe& pose							= individual->PoseRecipe();
	const JointMatrix& transform			= individual->Transform();
	const Triangle& triangle				= mTriangles[i];
	const ClipDescription& clipInfo0		= mClips[triangle.mPoints[0]];
	const ClipDescription& clipInfo1		= mClips[triangle.mPoints[1]];
	const ClipDescription& clipInfo2		= mClips[triangle.mPoints[2]];
	const ClipManager* clipManager			= ClipManager::GetInstance();
	const Clip* clip0						= clipManager->GetClip(clipInfo0.mClipId);
	const Clip* clip1						= clipManager->GetClip(clipInfo1.mClipId);
	const Clip* clip2						= clipManager->GetClip(clipInfo2.mClipId);
	const float	activeProgress				= playbackData->mActiveProgress.AsFloat();
	const Axiom::Time blendDuration			= weights.X()*clip0->Duration() + weights.Y()*clip1->Duration() + weights.Z()*clip2->Duration();
	const Axiom::Time timeStep				= playbackData->mPlaybackRate*individual->ActiveTimeStep();
	const Axiom::Time startTime				= activeProgress * blendDuration;
	const Axiom::Time endTime 				= startTime + timeStep;
	const GenericTime gTimeStep				= (endTime.AsFloatInMicroseconds() / blendDuration.AsFloatInMicroseconds()) - activeProgress;
	const float loopTime					= activeProgress - 1.f + gTimeStep.AsFloat();
	playbackData->mLooped					= playbackData->mLooped || loopTime >= 0.f;
	playbackData->mPreviousProgress			= playbackData->mActiveProgress;
	playbackData->mActiveProgress			= Axiom::Select(loopTime, loopTime, loopTime + 1.f);
	playbackData->mParameters				= Axiom::Math::Vector2(	Axiom::Select(loopTime, GetWidth(individual), playbackData->mParameters.X()), 
																	Axiom::Select(loopTime, GetLength(individual), playbackData->mParameters.Y()));

	// Populate recipe
    const float startProgress               = activeProgress;
    const float endProgress                 = playbackData->mActiveProgress.AsFloat();
	Recipe empty(	individual->ActiveTime(), individual->UpdateTime(), 
					individual->GetCharacterIndex(), individual->GetMount());

	Recipe clip[3] = { empty, empty, empty };
	clip[0].SetClip(clipInfo0.mClipId, 
					clipInfo0.mMirrored, 
                    clipInfo0.mReversed,
                    (clipInfo0.mReversed ? (1.f - startProgress) : startProgress) * clip0->Duration(), 
					(clipInfo0.mReversed ? (1.f - endProgress) : endProgress) * clip0->Duration());
	clip[1].SetClip(clipInfo1.mClipId, 
					clipInfo1.mMirrored, 
                    clipInfo1.mReversed,
					(clipInfo1.mReversed ? (1.f - startProgress) : startProgress) * clip1->Duration(), 
					(clipInfo1.mReversed ? (1.f - endProgress) : endProgress) * clip1->Duration());
	clip[2].SetClip(clipInfo2.mClipId, 
					clipInfo2.mMirrored, 
                    clipInfo2.mReversed,
					(clipInfo2.mReversed ? (1.f - startProgress) : startProgress) * clip2->Duration(), 
					(clipInfo2.mReversed ? (1.f - endProgress) : endProgress) * clip2->Duration());

	const float weight = Axiom::Math::FClamp(weights.Y() + weights.Z(), 0.0f, 1.0f);
	Recipe side[2] = { clip[0], clip[0] };
	side[0].BlendRecipe(weight, clip[1]);
	side[1].BlendRecipe(weight, clip[2]);

	pose = side[0];
	pose.BlendRecipe(0.f != weight ? Axiom::Math::FClamp( weights.Z()/weight, 0.0f, 1.0f ) : 0.f, side[1]);
	pose.SetPreTransform(JointMatrix::IDENTITY);
	pose.SetPostTransform(transform);
	pose.GenerateStartEndTransforms(&playbackData->mStartTransform, &playbackData->mFinalTransform, &playbackData->mDuration);
	return playbackData->ContinuePlayback();
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::Serialize(Axiom::Serializer& stream, Character* character)
{
	if (NULL == character)
	{
		character = FindCharacter();
	}
	Motion::Serialize(stream, character);

	Motion::SerializeParameter(stream, character, mPlaybackCache);
	Motion::SerializeParameter(stream, character, mWidthParameterCache);
	Motion::SerializeParameter(stream, character, mLengthParameterCache);

	stream & mEndPosition;
	stream & mPlaybackRate;

	unsigned numberOfClips = mClips.Count();
	stream & numberOfClips;
	for (unsigned i = 0; i < numberOfClips; ++i)
	{
		if (stream.IsReading())
		{
			ClipDescription description;
			stream & description.mPosition;
			stream & description.mClipId;
			stream & description.mMirrored;
			stream & description.mReversed;
			mClips.Add(description);
		}
		else
		{
			ClipDescription& description = mClips[i];
			stream & description.mPosition;
			stream & description.mClipId;
			stream & description.mMirrored;
			stream & description.mReversed;
		}
	}

	unsigned numberOfTriangles = mTriangles.Count();
	stream & numberOfTriangles;
	for (unsigned i = 0; i < numberOfTriangles; ++i)
	{
		if (stream.IsReading())
		{
			Triangle triangle;
			stream & triangle.mPoints[0];
			stream & triangle.mPoints[1];
			stream & triangle.mPoints[2];
			mTriangles.Add(triangle);
		}
		else
		{
			Triangle& triangle = mTriangles[i];
			stream & triangle.mPoints[0];
			stream & triangle.mPoints[1];
			stream & triangle.mPoints[2];
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::WidthParameter(const char* width)
{
	const Character* character	= FindCharacter();
	mWidthParameterCache		= character->FindParameter(width);
	AP_ASSERT(NULL != mWidthParameterCache);
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::LengthParameter(const char* length)
{
	const Character* character	= FindCharacter();
	mLengthParameterCache		= character->FindParameter(length);
	AP_ASSERT(NULL != mLengthParameterCache);
}

// --------------------------------------------------------------------------------------------------------------------
const char* PlaybackGroup::WidthParameter() const
{
	return NULL != mWidthParameterCache ? mWidthParameterCache->Name() : "";
}

// --------------------------------------------------------------------------------------------------------------------
const char* PlaybackGroup::LengthParameter() const
{
	return NULL != mLengthParameterCache ? mLengthParameterCache->Name() : "";
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::AddClip(ClipId clipId, const bool mirrored, const bool reversed, const Axiom::Math::Vector2& position)
{
	AP_ASSERT(INVALID_ID != clipId);

	ClipDescription desc;
	desc.mClipId	= clipId;
	desc.mMirrored	= mirrored;
    desc.mReversed  = reversed;
	desc.mPosition	= position;

	mClips.Add(desc);
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::AddClipByName(const char* name, const bool mirrored, const Axiom::Math::Vector2& position)
{
	const ClipManager* clipManager = ClipManager::GetInstance();
	AddClip(clipManager->FindClip(name), mirrored, false, position);
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::AddReverseClipByName(const char* name, const bool mirrored, const Axiom::Math::Vector2& position)
{
	const ClipManager* clipManager = ClipManager::GetInstance();
	AddClip(clipManager->FindClip(name), mirrored, true, position);
}

// --------------------------------------------------------------------------------------------------------------------
const float	PlaybackGroup::GetWidth(const Individual::Ptr& individual) const
{
	return NULL != mWidthParameterCache ? *individual->GetParameter<float>(mWidthParameterCache) : 0.f;
}

// --------------------------------------------------------------------------------------------------------------------
const float	PlaybackGroup::GetLength(const Individual::Ptr& individual) const
{
	return NULL != mLengthParameterCache ? *individual->GetParameter<float>(mLengthParameterCache) : 0.f;
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::AddTriangle(const int first, const int second, const int third)
{
	Triangle t;
	t.mPoints[0] = static_cast<Axiom::Byte>(first);
	t.mPoints[1] = static_cast<Axiom::Byte>(second);
	t.mPoints[2] = static_cast<Axiom::Byte>(third);
	mTriangles.Add(t);
}

// --------------------------------------------------------------------------------------------------------------------
const PlaybackGroup::Triangle& PlaybackGroup::FindTriangle(const Axiom::Math::Vector2& position, Axiom::Math::Vector3& barycentric ) const
{
    static const float MAX_FLOAT = static_cast<float>(0x7fffffff);
    const Axiom::Math::Vector2& v = position;
    int triangle = -1;
    float minDistance = MAX_FLOAT;
    for (Axiom::uint i = 0; i < mTriangles.Count(); ++i)
    {
        const Triangle& t = mTriangles[i];
		//const bool isColinear = ColinearTriangle(t);
		//if (isColinear)
		//	continue; // Don't even bother with colinear triangles

        const float distance = (CentreOfTriangle(t) - v).SquareMagnitude();
		if (minDistance > distance)
		{
			minDistance = distance;
			triangle = static_cast<int>(i);
		}
		if (PointInTriangle(t, v, barycentric))
		{
			return t;
		}
    }

    // Compute the nearest value
    const Triangle& t = mTriangles[triangle];
    const Axiom::Math::Vector2 interset = NearestPointInTriangle(t, v);
    PointInTriangle(t, interset, barycentric);
	return t;
}

// --------------------------------------------------------------------------------------------------------------------
const Axiom::Math::Vector2 PlaybackGroup::CentreOfTriangle( const PlaybackGroup::Triangle& triangle ) const
{
    static const float inv3 = 1.f/3.f; // Compute this constant once
    const Axiom::Math::Vector2 p0 = mClips[triangle.mPoints[0]].mPosition;
    const Axiom::Math::Vector2 p1 = mClips[triangle.mPoints[1]].mPosition;
    const Axiom::Math::Vector2 p2 = mClips[triangle.mPoints[2]].mPosition;
    return (p0 + p1 + p2)*inv3;
}

// --------------------------------------------------------------------------------------------------------------------
const bool PlaybackGroup::Intersection(	const Axiom::Math::Vector2& start0, const Axiom::Math::Vector2& end0,
										const Axiom::Math::Vector2& start1, const Axiom::Math::Vector2& end1,
										Axiom::Math::Vector2* intersection) const
{
    const float d = ((end1.Y() - start1.Y())*(end0.X() - start0.X())) -
                    ((end1.X() - start1.X())*(end0.Y() - start0.Y()));
    const float u = ((end1.X() - start1.X())*(start0.Y() - start1.Y()) - 
                     (end1.Y() - start1.Y())*(start0.X() - start1.X()));
    const float v = ((end0.X() - start0.X())*(start0.Y() - start1.Y()) - 
                     (end0.Y() - start0.Y())*(start0.X() - start1.X()));

    const bool isCoincident = 0.f == d && 0.f == u && 0.f == v;
	const float invd = isCoincident ? 0.f : 1.f / d;
	const float uRatio = u*invd;
	const float vRatio = v*invd;
	*intersection =	Axiom::Math::Vector2(	start0.X() + uRatio*(end0.X() - start0.X()), 
											start0.Y() + vRatio*(end0.Y() - start0.Y()));
	return !isCoincident 
			&& Axiom::Math::LessEqualRelative(uRatio, 1.f) 
			&& Axiom::Math::LessEqualRelative(vRatio, 1.f);
}

// --------------------------------------------------------------------------------------------------------------------
const Axiom::Math::Vector2 PlaybackGroup::NearestPointInTriangle(	const PlaybackGroup::Triangle& triangle, 
																	const Axiom::Math::Vector2& point ) const
{
    const Axiom::Math::Vector2& p0 = mClips[triangle.mPoints[0]].mPosition;
    const Axiom::Math::Vector2& p1 = mClips[triangle.mPoints[1]].mPosition;
    const Axiom::Math::Vector2& p2 = mClips[triangle.mPoints[2]].mPosition;
    const Axiom::Math::Vector2& centre = CentreOfTriangle(triangle);
	Axiom::Math::Vector2 intersection; 
    const bool valid =	Intersection(p1, p2, centre, point, &intersection) 
						|| Intersection(p2, p0, centre, point, &intersection) 
						|| Intersection(p0, p1, centre, point, &intersection);
	(void)valid;
	AP_ASSERT(valid);

	return intersection;
}

// --------------------------------------------------------------------------------------------------------------------
const bool PlaybackGroup::PointInTriangle(	const Axiom::Math::Vector2& v0,
											const Axiom::Math::Vector2& v1,
											const Axiom::Math::Vector2& v2,
											const Axiom::Math::Vector2& sample, 
											Axiom::Math::Vector3& barycentric) const
{
	const Axiom::Math::Vector2 e0 = v2 - v0;
	const Axiom::Math::Vector2 e1 = v1 - v0;
	const Axiom::Math::Vector2 e2 = sample - v0;
	const float dot00 = e0.Dot(e0);
	const float dot01 = e0.Dot(e1);
	const float dot02 = e0.Dot(e2);
	const float dot11 = e1.Dot(e1);
	const float dot12 = e1.Dot(e2);
	//const float dot22 = e2.Dot(e2);

	const float denom = dot00 * dot11 - dot01 * dot01;
	const float invDenom = 0.f == denom ? 0.f : 1.f / denom;
	barycentric.Z((dot11 * dot02 - dot01 * dot12) * invDenom);
	barycentric.Y((dot00 * dot12 - dot01 * dot02) * invDenom);
	barycentric.X(1.f - barycentric.Z() - barycentric.Y());

	// Check if point is in the triangle
	return 0 != denom 
		&& Axiom::Math::GreaterEqualRelative(barycentric.Z(), 0.f) 
		&& Axiom::Math::GreaterEqualRelative(barycentric.Y(), 0.f) 
		&& Axiom::Math::LessEqualRelative(barycentric.Z() + barycentric.Y(), 1.f);
}

// --------------------------------------------------------------------------------------------------------------------
const bool PlaybackGroup::PointInTriangle(	const Triangle& triangle,
											const Axiom::Math::Vector2& sample, 
											Axiom::Math::Vector3& barycentric) const
{
	return PointInTriangle(	mClips[triangle.mPoints[0]].mPosition, 
							mClips[triangle.mPoints[1]].mPosition, 
							mClips[triangle.mPoints[2]].mPosition, 
							sample, 
							barycentric);
}

// --------------------------------------------------------------------------------------------------------------------
bool PlaybackGroup::Cyclic() const
{
	return !mEndPosition.IsValid();
}

// --------------------------------------------------------------------------------------------------------------------
void PlaybackGroup::Cyclic(bool value)
{
	mEndPosition = value ? GenericTime::Invalid() : GenericTime::One();
}

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------

// clip.cpp - (c) 2006 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "animation/animation.h"
#include "animation/clip.h"
#include "animation/skeleton.h"
#include "animation/clipmanager.h"
#include "core/serializer.h"
#include <math/mathserializer.h>

using namespace Axiom::Math;
namespace Soccer
{
namespace Animation
{

// ------------------------------------------------------------------------------------------------------------
AP_TYPE(ClipTag)
	AP_FIELD_USERDEBUG("Key", mKey, "The clip key for this tag")
	AP_FIELD_USERDEBUG("Tag", mTagId, "The tag id for this tag")	
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// ------------------------------------------------------------------------------------------------------------
AP_TYPE(FrameRange)
	AP_FIELD_USERDEBUG("Begin", mBegin, "The first key of the frame range")
	AP_FIELD_USERDEBUG("End", mEnd, "The last key of the frame range")	
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// ------------------------------------------------------------------------------------------------------------
AP_TYPE(Clip)
	AP_FIELD_USERDEBUG("Duration", mDuration, "The duration of the clip in seconds")
	AP_FIELD_USERDEBUG("NumKeys", mNumKeys, "The number of keys in this clip")
	AP_COMMAND_USERDEBUG(NumberOfJoints, "returns the number of joints required by this clip");
	AP_COMMAND_USERDEBUG(StartJoint, "returns the index of the first joint in the animation sequence");
	AP_COMMAND_USERDEBUG(SetJointRotation, "Sets a joint's rotation values");
	AP_COMMAND_USERDEBUG(SetJointTranslation, "Sets a joint's translation values");
	AP_COMMAND_USERDEBUG(ClearTags, "Clear all tags");
	AP_COMMAND_USERDEBUG(GetTag, "Gets tag value per key");
	AP_COMMAND_USERDEBUG(NumberOfTags, "Gets the number of animation tags");
	AP_COMMAND_USERDEBUG(AddTag, "Adds a new tag on the specified key");
	AP_COMMAND_USERDEBUG(NumberOfStates, "Gets the number of animation states");
	AP_COMMAND_USERDEBUG(GetStateId, "Gets the id of an animation state by index");
	AP_COMMAND_USERDEBUG(NumberOfStateFrameRanges, "For a state, gets the number of frame ranges where the state is TRUE");
	AP_COMMAND_USERDEBUG(GetStateFrameRange, "Get a frame range for a state by index");
	AP_COMMAND_USERDEBUG(AddStateFrameRange, "Adds a range of frames over which the state is TRUE");
	AP_COMMAND_USERDEBUG(IsStateAtKey, "Gets the boolean state at the specified frame");
	AP_COMMAND_USERDEBUG(HasState, "Whether or not this clip has a TRUE value for this state at any time");
	AP_COMMAND_USERDEBUG(NumberOfJointReparents, "Gets the number of reparented joints");
	AP_COMMAND_USERDEBUG(SetNumberOfJointReparents, "Sets the number of joints to reparent");
	AP_COMMAND_USERDEBUG(AddJointReparent, "Reparents a joint");
	AP_COMMAND_USERDEBUG(GetJointReparent, "Gets the new parent for the specified reparented joint");
	AP_COMMAND_USERDEBUG(GetReparentingJointAtIndex, "Gets the reparented joint at the specified index");
	AP_COMMAND_USERDEBUG(GetReparentingParentAtIndex, "Gets the new parent for the joint at the specified index");
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// ------------------------------------------------------------------------------------------------------------
Clip::Clip()
: mSkeleton(-1)
, mStartJoint(-1)
, mNumJoints(0)
, mDuration(Axiom::Time::Zero())
, mNumKeys(0)
, mKeys(NULL)
{
}

// ------------------------------------------------------------------------------------------------------------
// quat compression helper funcs
//
static const float			SMALLEST_3_ELEMENT_QUANT		= 723.3702371538f; // (511.5f) * Axiom::Math::SquareRoot(2.0f);
static const float			SMALLEST_3_ELEMENT_DEQUANT		= 1.0f / SMALLEST_3_ELEMENT_QUANT;

const Axiom::uint Clip::CompressQuatSmallest3(const Axiom::Math::Quaternion& quat)
{
	float vals[4] = {quat.X(), quat.Y(), quat.Z(), quat.W()};
	float absVals[4] = {Axiom::Math::FloatAbs(vals[0]), Axiom::Math::FloatAbs(vals[1]), Axiom::Math::FloatAbs(vals[2]), Axiom::Math::FloatAbs(vals[3])};

	// determine largest element (absolute value)
	Axiom::uint largest = 3;
	for (Axiom::uint x=0; x < 4; ++x)
	{
		if (Axiom::Math::Greater(absVals[x], absVals[largest]))
		{
			largest = x;
		}
	}

	const bool isNegative = Axiom::Math::Less(vals[largest], 0.0f);
	if (isNegative)
	{
		vals[0] = -vals[0];
		vals[1] = -vals[1];
		vals[2] = -vals[2];
		vals[3] = -vals[3];
	}

	// store largest element index in top two bits
	Axiom::uint smallest3 = largest << 30;

	// get quantized values for stored elements
	// elements being stored are guaranteed to be in the range [-1/sqrt(2), 1/sqrt(2)]
	for (Axiom::uint x=0, q=0; x < 4; ++x)
	{
		if (x == largest) continue;

		// convert the float value to an int in the range [0-1024], then bitshift to pack in the int
		const int offset = 10*q;
		const int value = static_cast<int>(vals[x]*SMALLEST_3_ELEMENT_QUANT + 511.5f);
		AP_ASSERT( 0 <= value && value < 1024 );

		++q;
		smallest3 |= (value << offset);
	}

	return smallest3;	
}

// ------------------------------------------------------------------------------------------------------------
const Axiom::Math::Quaternion Clip::DecompressQuatSmallest3(const Axiom::uint smallest3)
{
	const Axiom::uint SMALLEST_3_ELEMENT_MASK = 0x03FF;
	// get largest element index
	Axiom::uint largest = smallest3 >> 30;

	// decompress elements
	float qVals[4];
	qVals[largest] = 0.0f;
	for (Axiom::uint x=0, q=0; x < 4; ++x)
	{
		if (x == largest) continue;

		const int offset	= 10*q;
		const int value		= (smallest3 >> offset) & SMALLEST_3_ELEMENT_MASK; 
		qVals[x]			= static_cast<float>(value - 511) * SMALLEST_3_ELEMENT_DEQUANT;
		qVals[largest]		+= qVals[x]*qVals[x];
		++q;
	}
	
	AP_ASSERT(Axiom::Math::LessEqual(qVals[largest], 1.0f));

	// calculate largest element
	qVals[largest] = Axiom::Math::SquareRoot(1.0f - qVals[largest]);

	return Axiom::Math::Quaternion(qVals[0], qVals[1], qVals[2], qVals[3]);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::SetJointRotation(const int key, const int joint, const float x, const float y, const float z, const float w)
{
	AP_ASSERTMESSAGE(key < mNumKeys, "This is not a key joint!");
	const Skeleton& skeleton = *ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	const Axiom::Math::Quaternion& rotation = Axiom::Math::Quaternion(x, y, z, w).Normalize(); // ensure we have normalized quaternions

	if (skeleton[joint+StartJoint()].mFormat & Skeleton::JointInfo::Rotation)
	{
		Axiom::uint* offsetPtr = reinterpret_cast<Axiom::uint*>(mKeys + key*KeySize() + JointOffset(joint));		
		*offsetPtr = CompressQuatSmallest3(rotation);
	}
}

// ------------------------------------------------------------------------------------------------------------
void Clip::SetJointTranslation(const int key, const int joint, const float x, const float y, const float z)
{
	AP_ASSERTMESSAGE(key < mNumKeys, "This is not a key joint!");
	const Skeleton& skeleton = *ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	int mask = Skeleton::JointInfo::TranslateX;

	// if joint format is RotationTranslation, offset the ptr by Rotation size
	Axiom::uint *offsetPtr = reinterpret_cast<Axiom::uint*>(mKeys + key*KeySize() + JointOffset(joint));
	if (Skeleton::JointInfo::RotationTranslation == (skeleton[joint+StartJoint()].mFormat & Skeleton::JointInfo::RotationTranslation))
	{		
		offsetPtr++;
	}
	
	float *keyJoint = reinterpret_cast<float*>(offsetPtr);
	while ((skeleton[joint+StartJoint()].mFormat & Skeleton::JointInfo::Translation) && mask < Skeleton::JointInfo::TranslateW)
	{
		*keyJoint =	Skeleton::JointInfo::TranslateX	== (mask & Skeleton::JointInfo::TranslateX)	? x :
					Skeleton::JointInfo::TranslateY	== (mask & Skeleton::JointInfo::TranslateY)	? y :
					Skeleton::JointInfo::TranslateZ	== (mask & Skeleton::JointInfo::TranslateZ)	? z :
					*keyJoint;

		++keyJoint;
		mask <<= 1;
	}
}

// ------------------------------------------------------------------------------------------------------------
int Clip::NumberOfTags() const 
{
	return mTags.Count();
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::AddTag(int key, TagId tagId)
{
	if (mTags.Count() == static_cast<unsigned int>(MAX_NUM_TAGS))
	{
		return false;
	}

	// don't allow multiple of same tag with same key
	for (int i=0; i < NumberOfTags(); ++i)
	{
		if (mTags[i].mTagId == tagId && mTags[i].mKey == key)
		{
			return false;
		}
	}
	mTags.Add(ClipTag(key, tagId));	
	return true;
}

// ------------------------------------------------------------------------------------------------------------
// tag mirroring elsewhere, as it's game-specific
bool Clip::GetTag(int index, ClipTag& tag) const
{
	if (index < 0 || index >= NumberOfTags())
	{
		return false;
	}

	tag = mTags[index];
	return true;
}

// ------------------------------------------------------------------------------------------------------------
TagId Clip::GetTagId(int index) const
{
	AP_ASSERT(0 <= index && index < NumberOfTags());
	return mTags[index].mTagId;
}

// ------------------------------------------------------------------------------------------------------------
int	Clip::GetTagKey(int index) const
{
	AP_ASSERT(0 <= index && index < NumberOfTags());
	return mTags[index].mKey;
}

// ------------------------------------------------------------------------------------------------------------
Axiom::Time Clip::GetTagTime(int index) const
{
	return KeyTime(GetTagKey(index));
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::GetNextKeyWithTag(TagId tagId, int& key, const Axiom::Time& startTime) const
{
	const int nextKey	= GetNextKey(startTime);
	return GetNextKeyWithTag(tagId, key, nextKey);
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::GetNextKeyWithTag(TagId tagId, int& key, int startKey) const
{
	ClipTag tmpTag;
	for (int i=0; i < NumberOfTags(); ++i)
	{
		GetTag(i, tmpTag);
		if (tmpTag.mTagId == tagId && tmpTag.mKey >= startKey)
		{
			key = tmpTag.mKey;
			return true;
		}
	}
	return false;
}

// ------------------------------------------------------------------------------------------------------------
int	Clip::NumberOfStates() const 
{ 
	return mStates.Count(); 
}

// ------------------------------------------------------------------------------------------------------------
AnimStateId Clip::GetStateId(unsigned int index, const bool mirrored) const
{
	AP_ASSERT(index < mStates.Count());
	const Skeleton* skeleton = ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	const AnimStateId storedId = mStates.KeyAt(index);
	return mirrored ? skeleton->MirrorState(storedId) : storedId;;
}

// ------------------------------------------------------------------------------------------------------------
int Clip::NumberOfStateFrameRanges(AnimStateId id, const bool mirrored) const
{
	const Skeleton* skeleton = ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	AnimStateId actualId = mirrored ? skeleton->MirrorState(id) : id;
	if (mStates.ContainsKey(actualId))
	{
		return mStates.Item(actualId)->Count();
	}
	return 0;
}

// ------------------------------------------------------------------------------------------------------------
const FrameRange* Clip::GetStateFrameRange(AnimStateId id, const bool mirrored, unsigned int index) const
{	
	const Skeleton* skeleton = ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	AnimStateId actualId = mirrored ? skeleton->MirrorState(id) : id;
	if (mStates.ContainsKey(actualId))
	{
		AP_ASSERT(index < mStates.Item(actualId)->Count());

		return &(mStates.Item(actualId)->Item(index));
	}
	return NULL;
}

// ------------------------------------------------------------------------------------------------------------
void Clip::AddStateFrameRange(AnimStateId id, unsigned int startRange, unsigned int endRange)
{
	if (!mStates.ContainsKey(id))
	{
		AP_ASSERT(mStates.Count() < mStates.Capacity());
		FrameRangeList list;
		mStates.IncreaseAdd(Axiom::Memory::ANIM_HEAP, id, list);
	}
	AP_ASSERT(mStates.Item(id)->Count() < mStates.Item(id)->Capacity());
	mStates.Item(id)->Add(FrameRange(startRange, endRange));
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::IsStateAtKey(AnimStateId id, const bool mirrored, int key) const
{
	const Skeleton* skeleton = ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	AnimStateId actualId = mirrored ? skeleton->MirrorState(id) : id;

	const FrameRangeList* frameRanges = mStates.Item(actualId);
	unsigned int uKey = static_cast<unsigned int>(key);
	if (NULL != frameRanges)
	{
		for (unsigned int i=0; i < frameRanges->Count(); i++)
		{
			if (uKey >= frameRanges->Item(i).mBegin && uKey <= frameRanges->Item(i).mEnd)
			{
				return true;
			}
		}
	}

	return false;
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::IsInFrameRange(const FrameRange* frame, Axiom::Time start, Axiom::Time end) const
{
	const Axiom::Time beginTime	= KeyTime(frame->mBegin);
	const Axiom::Time endTime	= KeyTime(frame->mEnd);
	return	beginTime <= start && start <= endTime 
			|| beginTime <= end && end <= endTime 
			|| start <= beginTime && beginTime <= end
			|| start <= endTime && endTime <= end;
}

// ------------------------------------------------------------------------------------------------------------
bool Clip::HasState(AnimStateId id, const bool mirrored) const
{
	const Skeleton* skeleton	= ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	AnimStateId actualId		= mirrored ? skeleton->MirrorState(id) : id;
	return mStates.ContainsKey(actualId);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::ClearStates()
{
	mStates.Clear();
}

// ------------------------------------------------------------------------------------------------------------
const int Clip::JointOffset(const unsigned int joint) const
{ 
	AP_ASSERT(joint >= 0 && joint < mNumJoints);
	const Skeleton* skeleton	= ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	return skeleton->JointOffset(joint+StartJoint()) - skeleton->JointOffset(StartJoint());
}

// ------------------------------------------------------------------------------------------------------------
Clip* Clip::Make(const SkeletonId skeleton, const int numKeys, const float duration, const int startJoint, const int numJoints)
{
	AP_ASSERTMESSAGE(skeleton.IsValid(), "This is an invalid skeleton");
	const size_t sizeOfAnim = Size(skeleton, numKeys, startJoint, numJoints);
	const size_t bufferSize = sizeof(Clip) + sizeOfAnim;
	Axiom::Byte* buffer		= AP_ALIGNED_NEW(	Axiom::Memory::ANIM_HEAP, 
										        Clip::TypeId().Alignment(), 
										        Axiom::Byte[bufferSize]);
	Clip* clip				= AP_PLACEMENT_NEW(buffer) Clip();
	clip->mSkeleton			= skeleton;
	clip->mDuration			= Axiom::Time::CreateFromSeconds(duration);
	clip->mNumKeys			= numKeys;
	clip->mStartJoint		= startJoint;
	clip->mNumJoints		= numJoints;

	clip->mKeys				= reinterpret_cast<Axiom::Byte*>(clip + 1);
	clip->mTags.Clear();
	clip->mStates.Resize(Axiom::Memory::ANIM_HEAP, 4); // Review(danc): Remove this booklet in favour of expanding Clip::Make()

	// Initialize the clip to default pose
	for (int i = 0; i < clip->mNumKeys; ++i)
	{
		for (unsigned int j = 0; j < clip->mNumJoints; ++j)
		{
			clip->SetJointRotation(i, j, 0.f, 0.f, 0.f, 1.f);
			clip->SetJointTranslation(i, j, 0.f, 0.f, 0.f);
		}
	}

	clip->mJointReparenting.Clear();
	
	return clip;
}

// ------------------------------------------------------------------------------------------------------------
const size_t Clip::KeySize(const SkeletonId skeleton, const int startJoint, const int numJoints)
{
	const Skeleton* pSkeleton = ClipManager::GetInstance()->GetSkeleton(skeleton);
	size_t startOffset = pSkeleton->JointOffset(startJoint);
	size_t endOffset = pSkeleton->JointOffset(startJoint + numJoints);
	return endOffset - startOffset;
}

// ------------------------------------------------------------------------------------------------------------
const size_t Clip::Size(const SkeletonId skeleton, const int numKeys, const int startJoint, const int numJoints)
{
	return numKeys * KeySize(skeleton, startJoint, numJoints);
}

// ------------------------------------------------------------------------------------------------------------
JointMatrix& Clip::ExtractJoint(const int format, const Axiom::Byte* key, int* startOffset, JointMatrix* matrix)
{
	// Review(danc): Extracting joints takes way to long we need a better format!
	matrix->mRotation = Axiom::Math::Quaternion::IDENTITY;
	if (format & Skeleton::JointInfo::Rotation)
	{
		const Axiom::uint compressedRot = *reinterpret_cast<const Axiom::uint*>(key + *startOffset);		
		matrix->mRotation = DecompressQuatSmallest3(compressedRot);
		(*startOffset) += sizeof(Axiom::uint);
	}

	matrix->mTranslation.X( (format & Skeleton::JointInfo::TranslateX) ? *reinterpret_cast<const float*>(key + *startOffset) : 0.f );
	(*startOffset) += Axiom::Select<int>(((format & Skeleton::JointInfo::TranslateX)-1), sizeof(float), 0);

	matrix->mTranslation.Y( (format & Skeleton::JointInfo::TranslateY) ? *reinterpret_cast<const float*>(key + *startOffset) : 0.f );
	(*startOffset) += Axiom::Select<int>(((format & Skeleton::JointInfo::TranslateY)-1), sizeof(float), 0);

	matrix->mTranslation.Z( (format & Skeleton::JointInfo::TranslateZ) ? *reinterpret_cast<const float*>(key + *startOffset) : 0.f );
	(*startOffset) += Axiom::Select<int>(((format & Skeleton::JointInfo::TranslateZ)-1), sizeof(float), 0);

	//matrix->mTranslation.W( (format & Skeleton::JointInfo::TranslateW) ? *reinterpret_cast<const float*>(key + *startOffset) : 1.f );
	//(*startOffset) += (format & Skeleton::JointInfo::TranslateW) ? sizeof(float) : 0;

	return *matrix;
}

// ------------------------------------------------------------------------------------------------------------
void Clip::MirrorJoint(const int format, JointMatrix& matrix)
{
	// Review(danc): should we be mirroring in local space...Maybe we should not mirror until we have world space matrices?
	if (format & Skeleton::JointInfo::MirrorRotation)
	{
		matrix.mRotation.Z(-1.f*matrix.mRotation.Z());
		matrix.mRotation.X(-1.f*matrix.mRotation.X());
	}

	if (format & Skeleton::JointInfo::MirrorTranslation)	// This test is bogus we need to know what space a joint is in before we know how to mirror it!
	{														// We are lucky right now that currently all joints with translation work out for us.  
		matrix.mTranslation.X(-1.f*matrix.mTranslation.X());
	}
}

// ------------------------------------------------------------------------------------------------------------
// return interpolated state for given joint and clip time
// joint param is index into skeleton list of joints
const JointMatrix Clip::GetJoint(const int joint, const Axiom::Time& time, const bool mirror) const
{
	AP_ASSERT(joint >= StartJoint());
	AP_ASSERT(joint < StartJoint() + NumberOfJoints());
	AP_ASSERT(joint < Clip::MAX_NUM_JOINTS);

	const int nextKey				= GetNextKey(time);
	const int prevKey				= Axiom::Math::Max(0, nextKey - 1);

	const Axiom::Time prevKeyTime	= KeyTime(prevKey);
	const Axiom::Time nextKeyTime	= KeyTime(nextKey);

	if (0 >= nextKey) // very beginning of clip, just apply first keyframe (keyframe 0)
	{
		return GetJoint(joint, nextKey, mirror);
	}
	else if (time >= mDuration) // mClipTime == clip duration, means very end of clip, just apply last keyframe
	{
		return GetJoint(joint, nextKey, mirror);
	}
	else // blend between prevKey and nextKey
	{
		const float fraction			= (time - prevKeyTime) / (nextKeyTime - prevKeyTime);
		const JointMatrix prevMatrix	= GetJoint(joint, prevKey, mirror);
		const JointMatrix nextMatrix	= GetJoint(joint, nextKey, mirror);
		return Blend(fraction, prevMatrix, nextMatrix);
	}
}

// ------------------------------------------------------------------------------------------------------------
const JointMatrix Clip::GetJoint(const int joint, const int key, const bool mirror) const
{
	AP_ASSERT(key < NumberOfKeys());
	AP_ASSERT(joint >= StartJoint());
	AP_ASSERT(joint < StartJoint() + NumberOfJoints());
	AP_ASSERT(joint < Clip::MAX_NUM_JOINTS);

	const Skeleton& skeleton		= *ClipManager::GetInstance()->GetSkeleton(mSkeleton);

	JointMatrix result;
	const int extractJoint			= mirror ? skeleton[joint].mMirror : joint;
	int offset						= key*KeySize() + JointOffset(extractJoint);

	if (StartJoint() <= extractJoint && extractJoint < (StartJoint() + NumberOfJoints()))
	{
		ExtractJoint(skeleton[extractJoint].mFormat, mKeys, &offset, &result);
		if (mirror)
		{
			MirrorJoint(skeleton[extractJoint].mFormat, result);
		}
	}

	return result;
}

// ------------------------------------------------------------------------------------------------------------
const JointMatrix Clip::GetRelativeRootJoint(const Axiom::Time& startTime, const Axiom::Time& endTime, const bool mirrored, const bool reversed) const
{
    const bool useIdentity          = (!reversed && startTime < endTime) || (reversed && startTime > endTime);
	const JointMatrix& clipEnd		= useIdentity ? JointMatrix::IDENTITY : GetJoint(0, Duration(), mirrored);
	const JointMatrix& removeStart	= GetJoint(0, startTime, mirrored).AsInverse();

	JointMatrix result				= GetJoint(0, endTime, mirrored);
	result *= clipEnd;
	result *= removeStart;

	return result;
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetJoints(const Axiom::Time& time, JointMatrix* outputJoints, const bool mirror) const
{
	const Skeleton& skeleton		= *ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	const size_t keySize			= KeySize();
	const int nextKey				= GetNextKey(time);
	const int prevKey				= Axiom::Math::Max(0, nextKey - 1);
	const Axiom::Time nextKeyTime	= KeyTime(nextKey);
	const Axiom::Time prevKeyTime	= KeyTime(prevKey);
	const float fraction			= Axiom::Math::Max((time - prevKeyTime) / (nextKeyTime - prevKeyTime), 0.f);
	const Axiom::Byte* next			= mKeys + nextKey*keySize;
	const Axiom::Byte* prev			= mKeys + prevKey*keySize;
	const int start					= StartJoint();
	const int end					= start + NumberOfJoints();
	int offset						= 0;
	JointMatrix nextMatrix;
	JointMatrix prevMatrix;
	AP_ASSERTMESSAGE(0.0f <= fraction && fraction <= 1.0f, "Blend weight is invalid");
	for (int joint = start; 1.0f == fraction && joint < end; ++joint)
	{	// mClipTime == clip duration, means very end of clip, just apply last keyframe
		const int extractJoint = mirror ? skeleton[joint].mMirror : joint;
		ExtractJoint(skeleton[joint].mFormat, next, &offset, &outputJoints[extractJoint]);
	}

	for (int joint = start; 0.0f == fraction && joint < end; ++joint)
	{	// very beginning of clip, just apply first keyframe (keyframe 0)
		const int extractJoint = mirror ? skeleton[joint].mMirror : joint;
		ExtractJoint(skeleton[joint].mFormat, prev, &offset, &outputJoints[extractJoint]);
	}

	for (int joint = start; 0.0f < fraction && fraction < 1.0f && joint < end; ++joint)
	{	// Blend between frames
		int prevOffset = offset;
		const int extractJoint = mirror ? skeleton[joint].mMirror : joint;
		ExtractJoint(skeleton[joint].mFormat, next, &offset, &nextMatrix);
		ExtractJoint(skeleton[joint].mFormat, prev, &prevOffset, &prevMatrix);
		outputJoints[extractJoint] = Blend(fraction, prevMatrix, nextMatrix);
	}

	// Mirror joints
	for (int joint = start; mirror && joint < end; ++joint)
	{
		MirrorJoint(skeleton[skeleton[joint].mMirror].mFormat, outputJoints[joint]);
	}
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetJoints(const GenericTime& time, JointMatrix* outputJoints, const bool mirror) const
{
	GetJoints(Duration()*time.AsFloat(), outputJoints, mirror);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetJoints(const int key, JointMatrix* outputJoints, const bool mirror) const
{
	const Axiom::Time time = KeyTime(key);
	GetJoints(time, outputJoints, mirror);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetRequiredJoints(const int joint, const Axiom::Time& time, JointMatrix* outputJoints, const bool mirror) const
{
	const Skeleton& skeleton		= *ClipManager::GetInstance()->GetSkeleton(mSkeleton);
	const size_t keySize			= KeySize();
	const int nextKey				= GetNextKey(time);
	const int prevKey				= Axiom::Math::Max(0, nextKey - 1);
	const Axiom::Time nextKeyTime	= KeyTime(nextKey);
	const Axiom::Time prevKeyTime	= KeyTime(prevKey);
	const float fraction			= Axiom::Math::Max((time - prevKeyTime) / (nextKeyTime - prevKeyTime), 0.f);
	const Axiom::Byte* next			= mKeys + nextKey*keySize;
	const Axiom::Byte* prev			= mKeys + prevKey*keySize;
	const int start					= mirror ? skeleton[joint].mMirror : joint;
	const int end					= StartJoint();
	const int startOffset			= skeleton[end].mOffset;
	bool sectionTest				= false;
	int offset						= 0;
	JointMatrix nextMatrix;
	JointMatrix prevMatrix;
	AP_ASSERTMESSAGE(0.0f <= fraction && fraction <= 1.0f, "Blend weight is invalid");
	AP_ASSERTMESSAGE(0 <= end, "We cannot have a negative ending point");

	sectionTest = 1.0f == fraction;
	for (int index = start; sectionTest && index >= end && index < NumberOfJoints(); index = skeleton[index].mParent)
	{	// mClipTime == clip duration, means very end of clip, just apply last keyframe
		const int outIndex = mirror ? skeleton[index].mMirror : index;
		offset = skeleton[index].mOffset - startOffset;
		ExtractJoint(skeleton[index].mFormat, next, &offset, &outputJoints[outIndex]);
	}

	sectionTest = 0.0f == fraction;
	for (int index = start; sectionTest && index >= end && index < NumberOfJoints(); index = skeleton[index].mParent)
	{	// very beginning of clip, just apply first keyframe (keyframe 0)
		const int outIndex = mirror ? skeleton[index].mMirror : index;
		offset = skeleton[index].mOffset - startOffset;
		ExtractJoint(skeleton[index].mFormat, prev, &offset, &outputJoints[outIndex]);
	}

	sectionTest = 0.0f < fraction && fraction < 1.0f;
	int prevOffset;
	for (int index = start; sectionTest && index >= end && index < NumberOfJoints(); index = skeleton[index].mParent)
	{	// Blend between frames
		offset		= skeleton[index].mOffset - startOffset;
		prevOffset	= offset;
		ExtractJoint(skeleton[index].mFormat, next, &offset, &nextMatrix);
		ExtractJoint(skeleton[index].mFormat, prev, &prevOffset, &prevMatrix);

		const int outIndex = mirror ? skeleton[index].mMirror : index;
		outputJoints[outIndex] = Blend(fraction, prevMatrix, nextMatrix);
	}

	// Mirror joints
	for (int index = joint; mirror && index >= end && index < NumberOfJoints(); index = skeleton[index].mParent)
	{
		MirrorJoint(skeleton[skeleton[index].mMirror].mFormat, outputJoints[index]);
	}
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetRequiredJoints(const int joint, const GenericTime& time, JointMatrix* outputJoints, const bool mirror) const
{
	GetRequiredJoints(joint, Duration()*time.AsFloat(), outputJoints, mirror);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetRequiredJoints(const int joint, const int key, JointMatrix* outputJoints, const bool mirror) const
{
	const Axiom::Time time = KeyTime(key);
	GetRequiredJoints(joint, time, outputJoints, mirror);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetRelativeJoints(const Axiom::Time& startTime, const Axiom::Time& endTime, JointMatrix* outputJoints, 
                             const bool mirror, const bool reverse) const
{
    const bool useIdentity          = (!reverse && startTime < endTime) || (reverse && startTime > endTime);
	const JointMatrix& end			= useIdentity ? JointMatrix::IDENTITY : GetJoint(0, Duration(), mirror);
	const JointMatrix& removeStart	= GetJoint(0, startTime, mirror).AsInverse();
	GetJoints(endTime, outputJoints, mirror);

	outputJoints[0] *= end;
	outputJoints[0] *= removeStart;
}

// ------------------------------------------------------------------------------------------------------------
void Clip::GetRelativeRequiredJoints(const int joint, const Axiom::Time& startTime, const Axiom::Time& endTime, 
									 JointMatrix* outputJoints, const bool mirror, const bool reverse) const
{
    const bool useIdentity          = (!reverse && startTime < endTime) || (reverse && startTime > endTime);
	const JointMatrix& end			= useIdentity ? JointMatrix::IDENTITY : GetJoint(0, Duration(), mirror);
	const JointMatrix& removeStart	= GetJoint(0, startTime, mirror).AsInverse();
	GetRequiredJoints(joint, endTime, outputJoints, mirror);

	outputJoints[0] *= end;
	outputJoints[0] *= removeStart;
}

// ------------------------------------------------------------------------------------------------------------
const int Clip::GetNextKey(const Axiom::Time& time) const
{
	const int index	= static_cast<int>((mNumKeys - 1)*time / mDuration) + 1;
	AP_ASSERTMESSAGE(index >=0, "Animation Key Index Overflow producing negative val!");
	return Axiom::Math::Min(mNumKeys - 1, index);
}

// ------------------------------------------------------------------------------------------------------------
unsigned int Clip::NumberOfJointReparents()
{
	return mJointReparenting.Count();
}

// ------------------------------------------------------------------------------------------------------------
void Clip::SetNumberOfJointReparents(unsigned int size)
{
	// allow increase only
	AP_ASSERT(size > mJointReparenting.Capacity());	
	mJointReparenting.IncreaseAndCopy(Axiom::Memory::ANIM_HEAP, size);
}

// ------------------------------------------------------------------------------------------------------------
void Clip::AddJointReparent(int joint, int reparent)
{
	AP_ASSERT(joint > -1 && joint < MAX_NUM_JOINTS);
	AP_ASSERT(reparent > -1 && reparent < MAX_NUM_JOINTS);
	if (mJointReparenting.Capacity() < 1)
	{
		mJointReparenting.Resize(Axiom::Memory::ANIM_HEAP, 1);
	}
	else if (mJointReparenting.IsFull())
	{
		mJointReparenting.IncreaseAndCopy(Axiom::Memory::ANIM_HEAP, mJointReparenting.Capacity() * 2);
	}
	mJointReparenting.Add(joint, reparent);
}

// ------------------------------------------------------------------------------------------------------------
int Clip::GetJointReparent(int joint)
{
	AP_ASSERT(joint > -1 && joint < MAX_NUM_JOINTS);
	if (mJointReparenting.ContainsKey(joint))
	{
		return mJointReparenting[joint];
	}
	return -1;
}

// ------------------------------------------------------------------------------------------------------------
int Clip::GetReparentingJointAtIndex(unsigned int index)
{
	AP_ASSERT_SUPPORTASSIGN(unsigned int count, mJointReparenting.Count());
	AP_ASSERT(index < count);
	return mJointReparenting.KeyAt(index);	
}

// ------------------------------------------------------------------------------------------------------------
int Clip::GetReparentingParentAtIndex(unsigned int index)
{
	AP_ASSERT_SUPPORTASSIGN(unsigned int count, mJointReparenting.Count());
	AP_ASSERT(index < count);
	return mJointReparenting[index];
}

// ------------------------------------------------------------------------------------------------------------
Axiom::Serializer& operator&(Axiom::Serializer& stream, Clip*& clip)
{
	ClipManager* clipManager	= ClipManager::GetInstance();
	SkeletonId id				= NULL == clip	? -1	: clip->mSkeleton;
	int numKeys					= NULL == clip	? -1	: clip->mNumKeys;
	float duration				= NULL == clip	? 0.f	: clip->mDuration.AsFloatInSeconds();
	int startJoint				= NULL == clip	? -1	: clip->mStartJoint;
	unsigned int numJoints		= NULL == clip	? 0		: clip->mNumJoints;

	stream & id & numKeys & duration & startJoint & numJoints;

	if (clip == NULL)
	{
		clip = Clip::Make(id, numKeys, duration, startJoint, numJoints);
	}
	const Skeleton& skeleton = *clipManager->GetSkeleton(id);
	const size_t keySize = clip->KeySize();
	for (int i = 0; i < numKeys; ++i)
	{
		Axiom::Byte* key = clip->mKeys + i*keySize;

		for (unsigned int j = 0, offset = 0; j < numJoints; ++j)
		{
			if (skeleton[j+startJoint].mFormat & Skeleton::JointInfo::Rotation)
			{				
				stream & *reinterpret_cast<Axiom::uint*>(key + offset);
				offset += sizeof(Axiom::uint);
			}
			int element = Skeleton::JointInfo::TranslateX;	
			while (element <= Skeleton::JointInfo::TranslateW)
			{
				if (skeleton[j+startJoint].mFormat & element)
				{
					stream & *reinterpret_cast<float*>(key + offset);
					offset += sizeof(float);
				}
				element <<= 1;
			}
		}
	}

	if(stream.IsWriting())
	{
		// tags
		unsigned int numTags = clip->NumberOfTags();
		stream & numTags;
		for(unsigned int i = 0; i < numTags; ++i)
		{
			ClipTag clipTag;
			AP_ASSERT_SUPPORTASSIGN(bool success, clip->GetTag(i, clipTag));
			AP_ASSERTMESSAGE(success == TRUE, "Error getting clip tag");
			stream & clipTag.mKey & clipTag.mTagId;
		}

		// states
		unsigned int numStates = clip->NumberOfStates();
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId = clip->GetStateId(i, false);
			stream & animStateId;
			unsigned int numStateFrameRanges = clip->NumberOfStateFrameRanges(animStateId, false);
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				const FrameRange* pFrameRange = clip->GetStateFrameRange(animStateId, false, n);
				AP_ASSERT(NULL != pFrameRange);

				stream & pFrameRange->mBegin & pFrameRange->mEnd;
			}
		}
	}
	else
	{
		// tags
		unsigned int numTags = 0;
		stream & numTags;
		AP_ASSERTMESSAGE(numTags <= static_cast<int>(Clip::MAX_NUM_TAGS), "There must be a problem");
		clip->ClearTags();
		for(unsigned int i = 0; i < numTags; ++i)
		{
			int key;
			TagId tag;
			stream & key & tag;
			clip->AddTag(key, tag);
		}

		// states
		unsigned int numStates;
		stream & numStates;
		for (unsigned int i = 0; i < numStates; ++i)
		{
			AnimStateId animStateId;
			stream & animStateId;

			unsigned int numStateFrameRanges;
			stream & numStateFrameRanges;
			for (unsigned int n = 0; n < numStateFrameRanges; ++n)
			{
				unsigned int begin, end;
				stream & begin & end;
				clip->AddStateFrameRange(animStateId, begin, end);
			}
		}
	}

	// joint reparenting
	int numReparenting = clip->NumberOfJointReparents();
	stream & numReparenting;
	if (stream.IsReading() && numReparenting > 0)
	{
		clip->SetNumberOfJointReparents(numReparenting);
	}

	for (int r=0; r < numReparenting; ++r)
	{
		int joint = stream.IsWriting() ? clip->GetReparentingJointAtIndex(r) : -1;
		int reparent = stream.IsWriting() ? clip->GetReparentingParentAtIndex(r) : -1;
		stream & joint;
		stream & reparent;
		if (stream.IsReading())
		{
			clip->AddJointReparent(joint, reparent);
		}
	}

	return stream;
}

// ------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)


// End of file ------------------------------------------------------------------------------------------------


// character.cpp - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/character.h>
#include <animation/individual.h>
#include <animation/skeleton.h>
#include <animation/motion.h>
#include <animation/clipmanager.h>
#include <animation/adaptstate.h>
#include <animation/playbackmotion.h>
#include <animation/rootadjustment.h>
#include <animation/nismotion.h>
#include <core/serializer.h>
#include <core/utils.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(MotionTable)
	AP_INDEX_OPERATOR()
	AP_FIELD("Length",					mCount,			"Length of dynamic list.")
		AP_INDEX_LENGTH_FIELD()
	AP_COMMAND_USERDEBUG(Capacity,				"Returns capacity of the dynamic list.")
	AP_COMMAND_USERDEBUG(Count,					"Returns the number of elements.")
	AP_COMMAND_USERDEBUG(IsEmpty,					"Is the list empty.")
	AP_COMMAND_USERDEBUG(IsFull,					"Is the list full.")
	AP_COMMAND_USERDEBUG(IncreaseAdd,				"Add an element to the list, if full increase the capacity using IncreaseAndCopy.")
	AP_COMMAND_USERDEBUG(Clear,					"Destructor called on all elements.")
	AP_EXPLICIT_PROXY("AcademyLibrary", "Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
MotionTable::MotionTable()
: mCount(0)
, mCapacity(0)
{
}

// --------------------------------------------------------------------------------------------------------------------
MotionTable::~MotionTable()
{
	Axiom::Destruct(static_cast<AP::Reflection::AutoInstance*>(mData), mCount);
	Axiom::Destruct(static_cast<TableNode*>(mIndex), mCapacity);
}

// --------------------------------------------------------------------------------------------------------------------
const unsigned MotionTable::Count() const
{
	return mCount;
}

// --------------------------------------------------------------------------------------------------------------------
const unsigned MotionTable::Capacity() const
{
	return mCapacity;
}

// --------------------------------------------------------------------------------------------------------------------
const bool MotionTable::IsEmpty() const
{
	return 0 == Count();
}

// --------------------------------------------------------------------------------------------------------------------
const bool MotionTable::IsFull() const
{
	return Capacity() == Count();
}

// --------------------------------------------------------------------------------------------------------------------
void MotionTable::Clear()
{
	Axiom::Destruct(static_cast<AP::Reflection::AutoInstance*>(mData), Count());
	for(unsigned i = 0; i < Capacity(); ++i)
	{
		mIndex[i] = TableNode();
	}
	mCount = 0;
}

// --------------------------------------------------------------------------------------------------------------------
void MotionTable::IncreaseAndRehash(Axiom::Memory::HeapId heapId, const unsigned capacity)
{
	AP_SIMPLEASSERTMESSAGE(capacity > mCapacity, "You cannot DecreaseAndRehash with this function");

	// Cache old values
	SmartData	oldData		= mData;
	SmartIndex	oldIndex	= mIndex;
	unsigned	oldCapacity	= mCapacity;
	unsigned	oldCount	= mCount;

	// Acquire new memory
	mData		= reinterpret_cast<AP::Reflection::AutoInstance*>(AP_NEW(heapId, Axiom::Byte[sizeof(AP::Reflection::AutoInstance) * capacity]));
	mIndex		= reinterpret_cast<TableNode*>(AP_NEW(heapId, Axiom::Byte[sizeof(TableNode) * capacity]));
	mCapacity	= capacity;
	mCount		= 0;

	Axiom::Construct(static_cast<TableNode*>(mIndex), mCapacity);

	// Rehash old values into new table
	for (unsigned i = 0; i < oldCount; ++i)
	{
		Add(oldData[i]);
		Axiom::Destruct(static_cast<AP::Reflection::AutoInstance*>(oldData) + i);
	}

	if (0 != oldCapacity)
	{
		Axiom::Destruct(static_cast<TableNode*>(oldIndex), oldCapacity);
	}

	AP_ASSERT(oldCount == mCount);
}

// --------------------------------------------------------------------------------------------------------------------
void MotionTable::IncreaseAdd(Axiom::Memory::HeapId heapId, AP::Reflection::AutoInstance& motion)
{
	AP_ASSERT(motion.Get().IsInstanceOf(AP::Reflection::TypeOf<Motion>()));
	const unsigned threshold = (3*mCapacity) >> 2; // or 3/4 * mCapacity 
	if (mCount >= threshold)
	{
		const unsigned capacity = Axiom::Math::Max<unsigned>(1, mCapacity);
		IncreaseAndRehash(heapId, 2*capacity);
	}

	Add(motion);
}

// --------------------------------------------------------------------------------------------------------------------
void MotionTable::Add(AP::Reflection::AutoInstance& motion)
{
	AP_ASSERT(!IsFull());
	const MotionId& hash = motion.Get().As<Motion*>()->Name();

	// Review(danc): ensuring the position of this motion results in a perfect hash will give use a consistent frame rate
	unsigned index = Hash(hash);
	const unsigned capacity = Capacity();
	const unsigned start = index % capacity;
	const unsigned prelim = 1 + index % (capacity - 1);
	const unsigned stride = prelim + (1 - (prelim & 0x01)); 
	AP_ASSERT((stride & 0x01) == 1); // stride value must be odd.  
	index = start;
	for (unsigned i = 0; !EmptySlot(index); ++i)
	{	// Resolve collision by finding the next empty slot linearly
		index += stride;
		index %= capacity;
		AP_ASSERT(i+1 < capacity);
	}

	AP_ASSERT(!mIndex[index].IsValid());
	mIndex[index] = TableNode(mCount);
	Axiom::CopyConstruct(static_cast<AP::Reflection::AutoInstance*>(mData) + mCount, motion);
	mCount++;
}

// --------------------------------------------------------------------------------------------------------------------
void MotionTable::Rehash(const MotionId& oldHash, const MotionId& newHash)
{
	unsigned oldIndex = Hash(oldHash);
	unsigned newIndex = Hash(newHash);
	const unsigned capacity = Capacity();
	const unsigned oldStart = oldIndex % capacity;
	const unsigned newStart = newIndex % capacity;
	const unsigned oldPrelim = 1 + oldIndex % (capacity - 1);
	const unsigned newPrelim = 1 + newIndex % (capacity - 1);
	const unsigned oldStride = oldPrelim + (1 - (oldPrelim & 0x01));
	const unsigned newStride = newPrelim + (1 - (newPrelim & 0x01));

	// Find the old slot
	AP_ASSERT((oldStride & 0x01) == 1); // stride value must be odd.  
	oldIndex = oldStart;
	for (unsigned i = 0; EmptySlot(oldIndex) || newHash != At(mIndex[oldIndex].mIndex)->Name(); ++i)
	{	
		oldIndex += oldStride;
		oldIndex %= capacity;
		AP_ASSERT(i+1 < capacity);
	}

	// Find the new slot
	AP_ASSERT((newStride & 0x01) == 1); // stride value must be odd.  
	newIndex = newStart;
	for (unsigned i = 0; newIndex != oldIndex && !EmptySlot(newIndex); ++i)
	{	
		newIndex += newStride;
		newIndex %= capacity;
		AP_ASSERT(i+1 < capacity);
	}

	if (newIndex != oldIndex)
	{
		AP_ASSERT(mIndex[oldIndex].IsValid());
		AP_ASSERT(!mIndex[newIndex].IsValid());
		mIndex[newIndex] = mIndex[oldIndex];
		mIndex[oldIndex] = TableNode();
	}
}

// --------------------------------------------------------------------------------------------------------------------
const int MotionTable::IndexOf(const MotionId& hash) const
{
	const unsigned index = AtIndex(hash);
	return index < Capacity() ? mIndex[index].mIndex : -1;
}

// --------------------------------------------------------------------------------------------------------------------
Motion* MotionTable::At(const MotionId& hash)
{
	const unsigned index = AtIndex(hash);
	if (index < Capacity())
	{
		const unsigned int motionIndex = mIndex[index].mIndex;

		if (motionIndex > Capacity())
			return NULL;

		Motion* motion = At(motionIndex);
		if (hash == motion->Name())
		{
			return motion;
		}
	}
	return NULL;
}

// --------------------------------------------------------------------------------------------------------------------
const Motion* MotionTable::At(const MotionId& hash) const
{
	return const_cast<MotionTable*>(this)->At(hash);
}

// --------------------------------------------------------------------------------------------------------------------
Motion*& MotionTable::At(const unsigned index)
{
	AP_ASSERT(mCapacity > index);
	return mData[index].Get().As<Motion*>();
}

// --------------------------------------------------------------------------------------------------------------------
const Motion*& MotionTable::At(const unsigned index) const
{
	AP_ASSERT(mCapacity > index);
	return mData[index].Get().As<const Motion*>();
}

// --------------------------------------------------------------------------------------------------------------------
Motion*& MotionTable::operator[](const unsigned index)
{
	return At(index);
}

// --------------------------------------------------------------------------------------------------------------------
const Motion*& MotionTable::operator[](const unsigned index) const
{
	return At(index);
}

// --------------------------------------------------------------------------------------------------------------------
int MotionTable::AtIndex(const MotionId& hash) const
{
	unsigned index = Hash(hash);
	const unsigned capacity = Capacity();
	const unsigned start = index % capacity;
	const unsigned prelim = 1 + index % (capacity - 1);
	const unsigned stride = prelim + (1 - (prelim & 0x01));
	AP_ASSERT((stride & 0x01) == 1); // stride value must be odd.  
	index = start;
	unsigned i;
	for (i = 0; (EmptySlot(index) || hash != At(mIndex[index].mIndex)->Name()) && i < capacity; ++i)
	{	
		index += stride;
		index %= capacity;
	}

	return i < capacity ? index : capacity;
}

// --------------------------------------------------------------------------------------------------------------------
int MotionTable::Hash(const MotionId& hash) const
{
	// Lets hash the hash result in an effort to improve our poor CRC hash functions
	const unsigned int fnv_prime = 0x811C9DC5;
	unsigned int i = fnv_prime*hash.Value();
	i += ~(i << 9);
	i ^=  ((i >> 14) | (i << 18)); /* >>> */
	i +=  (i << 4);
	i ^=  ((i >> 10) | (i << 22)); /* >>> */

	return i;
}

// --------------------------------------------------------------------------------------------------------------------
const bool MotionTable::EmptySlot(const unsigned index) const
{
	return !mIndex[index].IsValid();
}

// --------------------------------------------------------------------------------------------------------------------
AP_TYPE(Character)
	AP_DEFAULT_CREATE()
	AP_PROPERTY("Name", CharacterName, CharacterName, "What is the character name.")
	AP_PROPERTY("SkeletonName", SkeletonName, SkeletonName, "What skeleton are we using.")
	AP_PROPERTY("IndividualType", IndividualTypeName, IndividualTypeName, "Temperary definition of the individual type.")
	AP_PROPERTY("DAGRoot", DAGRootName, DAGRootName, "What is the base motion to evalutate initially?")
	AP_COMMAND_USERDEBUG(FindIndex, "Find the index of a specific motion.")
	AP_COMMAND_USERDEBUG(Initialize, "Initializes every plugin currently allocated to this character.")
	AP_FIELD_USERDEBUG("Motions", mMotions, "A list of available motions for playback.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
Character::Character()
: mSkeleton(INVALID_ID)
, mDAGRoot()
{
}

// --------------------------------------------------------------------------------------------------------------------
const CharacterName& Character::Name() const
{
	return mName;
}

// --------------------------------------------------------------------------------------------------------------------
const CharacterId& Character::HashName() const
{
	return mName;
}

// --------------------------------------------------------------------------------------------------------------------
Individual::Ptr	Character::CreateIndividual(SharedSoccer::EntityGUID& entityGUID, const Axiom::Memory::HeapId heapId) const
{
	Individual::Ptr individual = AP_NEW(heapId, Individual());
	const CharacterIndex myId = CharacterLibrary::GetInstance()->FindCharacter(Name());

	individual->Initialize(myId, mIndividualType, entityGUID, heapId);
	return individual;
}

// --------------------------------------------------------------------------------------------------------------------
void Character::InitializeIndividual(Individual::Ptr& individual)
{
	AP_ASSERT(Validate(individual));

	// Initialize list
	for (unsigned i = 0; i < mMotions.Count(); ++i)
	{
		Motion* motion = (*this)[i];
		motion->InitializeIndividual(individual);
	}

	const Motion* root = GetMotion(mDAGRoot);
	AP_ASSERT(NULL != root && root->IsPlayable(individual));
	root->StartPlayback(individual);
}

// --------------------------------------------------------------------------------------------------------------------
const Recipe& Character::Update(Individual::Ptr& individual) const
{
	AP_ASSERT(individual.IsValid());
	//AP_ASSERT(Validate(individual));

	const Motion* motion = GetMotion(mDAGRoot);
	AP_ASSERT(motion->IsPlayable(individual));
	motion->Play(individual);
	return individual->PoseRecipe();
}

// --------------------------------------------------------------------------------------------------------------------
void Character::Initialize()
{
	for (unsigned i = 0; i < mMotions.Count(); ++i)
	{
		Motion* motion = (*this)[i];
		motion->Initialize(this); // Review(danc): should be TypeBuilder not Type
	}
}

// --------------------------------------------------------------------------------------------------------------------
const char*	Character::IndividualTypeName() const
{
	return mIndividualType->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void Character::IndividualTypeName(const char* typeName)
{
	mIndividualType = AP::Reflection::Type::TypeOf(typeName);
}

// --------------------------------------------------------------------------------------------------------------------
const Individual::Parameter Character::FindParameter(const Axiom::CRC& name) const
{
	return mIndividualType->FieldDesc(name);
}

// --------------------------------------------------------------------------------------------------------------------
const Skeleton* Character::GetSkeleton() const
{
	return ClipManager::GetInstance()->GetSkeleton(mSkeleton);
}

// --------------------------------------------------------------------------------------------------------------------
void Character::SetSkeleton(const Axiom::StringCRC& skeletonName)
{
	mSkeleton = ClipManager::GetInstance()->FindSkeleton(skeletonName);
	AP_ASSERT(mSkeleton.IsValid());
}

// --------------------------------------------------------------------------------------------------------------------
//const int Character::FindMotion(const MotionId& id) const
const MotionIndex Character::FindMotion(const MotionId& id) const
{
	return mMotions.IndexOf(id);
}

// --------------------------------------------------------------------------------------------------------------------
//Motion* Character::GetMotion(const MotionId& motionName)
Motion* Character::GetMotion(const MotionIndex& motionName)
{
	return mMotions.At(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
//const Motion* Character::GetMotion(const MotionId& motionName) const
const Motion* Character::GetMotion(const MotionIndex& motionName) const
{
	return const_cast<Character*>(this)->GetMotion(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
Motion*	Character::GetMotion(const MotionId& id)
{
	return GetMotion(FindMotion(id));
}

// --------------------------------------------------------------------------------------------------------------------
const Motion* Character::GetMotion(const MotionId& id) const
{
	return GetMotion(FindMotion(id));
}

// --------------------------------------------------------------------------------------------------------------------
const unsigned Character::NumberOfMotions() const
{
	return mMotions.Count();
}

// --------------------------------------------------------------------------------------------------------------------
Motion* Character::operator[](const int index)
{
	return mMotions.At(index);
}

// --------------------------------------------------------------------------------------------------------------------
const Motion* Character::operator[](const int index) const
{
	return mMotions.At(index);
}

// --------------------------------------------------------------------------------------------------------------------
const char*	Character::SkeletonName() const
{
	return GetSkeleton()->Name().AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void Character::SkeletonName(const char* skeletonName)
{
	SetSkeleton(skeletonName);
}

// --------------------------------------------------------------------------------------------------------------------
const char*	Character::CharacterName() const
{
	return mName.AsChar();
}

// --------------------------------------------------------------------------------------------------------------------
void Character::CharacterName(const char* characterName)
{
	mName.Set(characterName);
}

// --------------------------------------------------------------------------------------------------------------------
const char* Character::DAGRootName() const
{
	return GetMotion(mDAGRoot)->Name();
}

// --------------------------------------------------------------------------------------------------------------------
void Character::DAGRootName(const char* motionName)
{
	//mDAGRoot = MotionId(motionName);
	mDAGRoot = FindMotion(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
const int Character::FindIndex(const char* motionName)
{
	return FindMotion(motionName);
}

// --------------------------------------------------------------------------------------------------------------------
const bool Character::Validate(Individual::Ptr& individual) const
{
	return	this == individual->GetCharacter() &&
			mIndividualType == individual->StateData().InstanceType(); 
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Serializer& operator&(Axiom::Serializer& stream, Character& character)
{
	stream & character.mName;
	stream & character.mSkeleton;
	stream & character.mDAGRoot;

	if ( stream.IsWriting() )
	{
		unsigned int hashName = character.mIndividualType->HashName();
		stream & hashName;
	}
	else
	{
		unsigned int hashName = 0;
		stream & hashName;
		character.mIndividualType = AP::Reflection::Type::TypeOf(hashName);
	}

	unsigned int numberOfMotions = character.mMotions.Count();
	unsigned int capacity = character.mMotions.Capacity();
	stream & numberOfMotions;
	stream & capacity; // We store capacity so what an appropriate cushion is maintained for efficent hashing
	if (stream.IsReading())
	{
		character.mMotions.IncreaseAndRehash(Axiom::Memory::ANIM_HEAP, capacity);
	}
	for (unsigned int i = 0; i < numberOfMotions; ++i)
	{
		const AP::Reflection::Type* motionType = NULL;
		if ( stream.IsWriting() )
		{
			motionType = AP::Reflection::TypeOf<Soccer::Animation::Motion*>(character.mMotions[i]);
			unsigned int hashName = motionType->HashName();
			stream & hashName;
		}
		else
		{
			unsigned int hashName = 0;
			stream & hashName;
			motionType = AP::Reflection::Type::TypeOf(hashName);
			AP::Reflection::AutoInstance instance(motionType->CreateInstance(Axiom::Memory::ANIM_HEAP));
			character.mMotions.Add(instance);

			character.mMotions[i]->Initialize(&character); // Review(danc): If things are properly serialized we should not have to do this? 
		}

		character.mMotions[i]->Serialize(stream, &character);
	}

	return stream;
}


// CharacterLibrary ---------------------------------------------------------------------------------------------------
AP_TYPE(CharacterLibrary)
	AP_FIELD("Characters", mCharacters, "A list of all the available characters.")
	AP_COMMAND(Find, "Find the character by name.")
	AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
AP_TYPE_END()

// --------------------------------------------------------------------------------------------------------------------
CharacterLibrary::CharacterLibrary()
{
	const AP::Reflection::Type* adaptState	= AP::Reflection::TypeOf<AdaptState>();					(void)adaptState; // reference to class AdaptState
	const AP::Reflection::Type* playback	= AP::Reflection::TypeOf<Playback>();					(void)playback; // reference to class Playback
	const AP::Reflection::Type* playGroup	= AP::Reflection::TypeOf<PlaybackGroup>();				(void)playGroup; // reference to class PlaybackGroup
	const AP::Reflection::Type* moveList	= AP::Reflection::TypeOf<MotionList>();					(void)moveList; // reference to class MotionList
	const AP::Reflection::Type* moveGroup	= AP::Reflection::TypeOf<CompositeMotion>();			(void)moveGroup; // reference to class CompositeMotion
	const AP::Reflection::Type* randGroup	= AP::Reflection::TypeOf<RandomCompositeMotion>();		(void)randGroup; // reference to class RandomCompositeMotion
	const AP::Reflection::Type* turnAdj		= AP::Reflection::TypeOf<TurningAngleAdjustment>();		(void)turnAdj; // reference to class TurningAngleAdjustment
	const AP::Reflection::Type* contAdj		= AP::Reflection::TypeOf<ContinuousRootAdjustment>();	(void)contAdj; // reference to class ContinuousRootAdjustment
	const AP::Reflection::Type* pivAdj		= AP::Reflection::TypeOf<PivotRootAdjustment>();		(void)pivAdj; // reference to class PivotRootAdjustment
	const AP::Reflection::Type* nisMotion	= AP::Reflection::TypeOf<NISMotion>();					(void)nisMotion; // reference to class NISMotion
}

// --------------------------------------------------------------------------------------------------------------------
CharacterIndex CharacterLibrary::FindCharacter(const CharacterId& characterName) const
{
	int i = 0; 
	const int numberOfCharacters = static_cast<int>(mCharacters.Count());
	for (; i < numberOfCharacters && characterName != mCharacters[i]->Name(); ++i) 
	{
		// intentionly empty
	} 

	const int character = Axiom::Select<int>(numberOfCharacters - i - 1, i, INVALID_ID);
	return static_cast<CharacterIndex>(character);
}

// --------------------------------------------------------------------------------------------------------------------
unsigned CharacterLibrary::NumberOfCharacters() const
{
	return mCharacters.Count();
}

// --------------------------------------------------------------------------------------------------------------------
Character* CharacterLibrary::GetCharacter(const CharacterIndex id)
{
	return mCharacters[id];
}

// --------------------------------------------------------------------------------------------------------------------
const Character* CharacterLibrary::GetCharacter(const CharacterIndex id) const
{
	return mCharacters[id];
}

// --------------------------------------------------------------------------------------------------------------------
Character* CharacterLibrary::operator[](const CharacterIndex& id)
{
	return mCharacters[id];
}

// --------------------------------------------------------------------------------------------------------------------
const Character* CharacterLibrary::operator[](const CharacterIndex& id) const
{
	return mCharacters[id];
}

// --------------------------------------------------------------------------------------------------------------------
CharacterIndex	CharacterLibrary::Find(const char* characterName) const
{
	return FindCharacter(characterName);
}


// --------------------------------------------------------------------------------------------------------------------
void CharacterLibrary::Remove(const CharacterIndex index)
{
	for (unsigned i = index; i < mCharacters.Count() - 1; ++i)
	{
		mCharacters[i] = mCharacters[i + 1];
	}
	mCharacters.RemoveTail();
}

// --------------------------------------------------------------------------------------------------------------------
void CharacterLibrary::Clear()
{
	mCharacters.Clear();
}

// --------------------------------------------------------------------------------------------------------------------
Axiom::Serializer& operator&(Axiom::Serializer& stream, CharacterLibrary& characterLibrary)
{
	// Save skeleton information
	size_t numberOfCharacters = characterLibrary.mCharacters.Count();
	stream & numberOfCharacters;
	if (stream.IsReading())
	{
		characterLibrary.mCharacters.Resize(Axiom::Memory::ANIM_HEAP, numberOfCharacters);
	}
	for ( size_t i = 0; i < numberOfCharacters; ++i )
	{
		Character* character = NULL;
		if (stream.IsWriting())
		{
			character = characterLibrary.mCharacters[i];
			stream & *character;
		}
		else
		{
			character = Character::TypeId().CreateInstance(Axiom::Memory::ANIM_HEAP).As<Character*>(); 
			characterLibrary.mCharacters.Add(character);
			stream & *character;
		}
	}

	return stream;
}
// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of file --------------------------------------------------------------------------------------------------------
 

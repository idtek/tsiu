// animation.h - (c) 2006 Action Pants Inc.
// -----------------------------------------------------------------------------

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "animation/clipmanager.h"
#include "animation/animation.h"
#include "animation/generictime.h"
#include "math/transformutils.h"
#include "core/serializer.h"

namespace Soccer
{
	namespace Animation
	{
		// -----------------------------------------------------------------------------
		namespace 
		{
			void Log(const char* format, va_list vaList)
			{
				(void)format; (void) vaList;
				Axiom::Log(0, "animation", format, vaList);
			}
		}

		// -----------------------------------------------------------------------------
		AP_TYPE(SkeletonId)
			AP_DEFAULT_CREATE()
			AP_FIELD("Value", mId, "What is the id value")
			AP_EXPLICIT_PROXY("AcademyLibrary","Animation")
		AP_TYPE_END()

		// -----------------------------------------------------------------------------
		Axiom::Math::Angle AngleBetweenXY(const Axiom::Math::Vector3& v1, const Axiom::Math::Vector3& v2)
		{
			return -Axiom::Math::AngleBetweenXY(v1, v2);
		}

		// -----------------------------------------------------------------------------
		Axiom::Math::Angle AngleBetweenXY(const Axiom::Math::Vector2& v1, const Axiom::Math::Vector2& v2)
		{
			return -Axiom::Math::AngleBetweenXY(v1, v2);
		}

		// -----------------------------------------------------------------------------
		float Blend(const float fraction, const float& t1, const float& t2)
		{
			AP_ASSERTMESSAGE(0.f <= fraction && 1.f >= fraction, "Fraction must be over the interval of 0 to 1.");
			return (1.f - fraction)*t1 + fraction*t2;
		}

		// -----------------------------------------------------------------------------
		Axiom::Time Blend(const float fraction, const Axiom::Time& t1, const Axiom::Time& t2)
		{
			AP_ASSERTMESSAGE(0.f <= fraction && 1.f >= fraction, "Fraction must be over the interval of 0 to 1.");
			return (1.f - fraction)*t1 + fraction*t2;
		}

		// -----------------------------------------------------------------------------
		Axiom::Math::Quaternion Blend(const float fraction, const Axiom::Math::Quaternion& q1, const Axiom::Math::Quaternion& q2)
		{
			return Axiom::Math::Interpolate(fraction, q1, q2);
		}

		// -----------------------------------------------------------------------------
		Axiom::Math::Vector3 Blend(const float fraction, const Axiom::Math::Vector3& v1, const Axiom::Math::Vector3& v2)
		{
			return Axiom::Math::Interpolate(fraction, v1, v2);
		}

		// -----------------------------------------------------------------------------
		Axiom::Math::RigidMatrix Blend(const float fraction, const Axiom::Math::RigidMatrix& r1, const Axiom::Math::RigidMatrix& r2)
		{
			return Axiom::Math::Interpolate(fraction, r1, r2);
		}

		// -----------------------------------------------------------------------------
		void Log(const char* format, ...)
		{
			va_list args;
			va_start(args, format);
			Log(format, args);
			va_end(args);
		}

		// -----------------------------------------------------------------------------
		Axiom::Serializer& operator& (Axiom::Serializer& stream, SkeletonId& id)
		{
			stream & id.mId;
			return stream;
		}

		// -----------------------------------------------------------------------------
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Time& t)
		{
			float ft = t.AsFloatInSeconds();
			stream & ft;
			t = Axiom::Time::CreateFromSeconds(ft);

			return stream;
		}

		// -----------------------------------------------------------------------------
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Math::Vector2& v)
		{
			float x = v.X(), y = v.Y();
			stream & x & y;
			v.X(x);
			v.Y(y);
			return stream;
		}

		// -----------------------------------------------------------------------------
		Axiom::Serializer& operator& (Axiom::Serializer& stream, Axiom::Math::Angle& a)
		{
			float radians = a.AsRadians();
			stream & radians;
			a = Axiom::Math::Angle::FromRadians(radians);
			return stream;
		}

		// -----------------------------------------------------------------------------
	} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

// End of File ------------------------------------------------------------------------------------------------

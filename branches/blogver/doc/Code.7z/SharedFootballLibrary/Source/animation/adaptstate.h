// AdaptState.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _ADAPTSTATE_H_
#define _ADAPTSTATE_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/motion.h>
#include <animation/adaptstatecommonextentions.h>
#include <StEdFast/Interpretter/StateMachineScriptManager.h>
#include <eventsystem/eventmsgbox.h>
#include <StEdFast/Interpretter/StateMachine.h>

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
struct AdaptStateData
{
	// These are to support the AdaptState motion 
	IndividualData						mStateData;
	AP::StEdFast::StateMachine			mStateMachine;
	AP::StEdFast::ConditionParameters	mStateConditionData;
	AP::StEdFast::TrackParameters		mStateTrackData;

	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class AdaptState : public Motion
{
	AP_NON_COPYABLE(AdaptState);
public:
	virtual ~AdaptState() {}

	void			Initialize(const Character* character); 
	void			InitializeIndividual(Individual::Ptr&) const;
	const bool		IsPlayable(const Individual::Ptr&) const;
	void			StartPlayback(Individual::Ptr&) const;
	const bool		Play(Individual::Ptr&) const;
	void			Serialize(Axiom::Serializer& stream, Character* character);

protected:
					AdaptState();
	const char*		StateScript() const;
	void			SetStateScript(const char* name);
	const char*		InitialState() const;
	void			InitialState(const char* name);

	StEdFastAdaptStateData										mData;
	AP::StEdFast::StateMachineScriptManager::ScriptIdentifier	mStateScript;
	Axiom::ShortString											mInitialState;
	Individual::Parameter										mStateFieldCache;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif //(CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _ADAPTSTATE_H_

// End of file --------------------------------------------------------------------------------------------------------

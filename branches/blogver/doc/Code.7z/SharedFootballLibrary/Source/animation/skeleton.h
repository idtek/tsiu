// skeleton.h - (c) 2007 Action Pants Inc.
// -----------------------------------------------------------------------------

#ifndef _SKELETON_H
#define _SKELETON_H

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include "core/autopointer.h"
#include "animation/animation.h"
#include "animation/tag.h"

namespace Soccer
{
	namespace Animation
	{
		class Skeleton
		{
		public:
			AP_ALIGN_BEGIN(16)
			struct JointInfo
			{
				JointInfo() : mSkin(), mBone(), mName(), mFormat(None), mOffset(-1), mParent(static_cast<Axiom::Byte>(INVALID_JOINT)), mMirror(0){}
				enum Format
				{
					None				= 0x0000000,
					RotateX				= 0x0000001, // 4 bytes
					RotateY				= 0x0000002, // 4 bytes
					RotateZ				= 0x0000004, // 4 bytes
					RotateW				= 0x0000008, // 4 bytes
					TranslateX			= 0x0000010, // 4 bytes
					TranslateY			= 0x0000020, // 4 bytes
					TranslateZ			= 0x0000040, // 4 bytes
					TranslateW			= 0x0000080, // 4 bytes
					Rotation			= RotateX | RotateY | RotateZ | RotateW, // 16 bytes
					Translation			= TranslateX | TranslateY | TranslateZ, // 12 bytes
					RotationTranslation	= Rotation | Translation, // 28 bytes

					// Review(danc): these per joint flags are stupid the must be a better way to mirror joint then flagging!
					MirrorRotation		= 0x0000100, 
					MirrorTranslation	= 0x0000200,
				};

				JointMatrix			mSkin;		// World to local joint space transform
				JointMatrix			mBone;		// local joint space transform
				Axiom::StringCRC	mName;		// The name of the joint
				// Review(danc): use Format type not int, implement reflection of enums
				int 				mFormat; 	// What animation format is used to represent this joint
				int					mOffset;	// Precalculated key offset value
				Axiom::Byte			mParent;	// Parent index of this joint (max 255)
				Axiom::Byte			mMirror;	// index of this joint when mirrored

				AP_DECLARE_TYPE();
			} AP_ALIGN_END(16);

			static const int INVALID_JOINT = -1;

			const Axiom::StringCRC&	Name() const;
			const int				NumberOfJoints() const;
			const size_t			JointOffset(int joint) const;

			const int				FindJoint(const Axiom::CRC name) const;
			const int				ParentJoint(const int joint) const;
			const JointInfo&		GetJoint(const int joint) const;

			const int				NumberOfTags() const;
			const TagId				MirrorTag(const TagId tag) const;
			const int				NumberOfStates() const;
			const AnimStateId		MirrorState(const AnimStateId tag) const;

			JointInfo&				operator[](const int index);
			const JointInfo&		operator[](const int index) const;

		private:
			friend class ClipManager;	// For access to Skeleton::Make()
			friend Axiom::Serializer&	operator&(Axiom::Serializer& stream, Skeleton*& skeleton); // For access to Skeleton::Make()
			static Skeleton*			Make(const Axiom::StringCRC& skeleton, const int numJoints, const int numTags, const int numStates);
			void						PreCalcJointOffsets();
			void						PreCalcMirrorJoints();
			void						PreCalcMirrorTags();

			Axiom::StringCRC		mName;
			unsigned int			mNumJoints;
			int						mNumTags;
			int						mNumStates;
			JointInfo*				mJointInfo;
			TagId*					mMirrorTags;
			AnimStateId*			mMirrorStates;
		public:
			AP_DECLARE_TYPE();
		};
	} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#endif // _SKELETON_H

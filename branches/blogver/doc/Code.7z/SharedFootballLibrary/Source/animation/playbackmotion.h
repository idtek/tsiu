// PlaybackMotion.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _PLAYBACKMOTION_H_
#define _PLAYBACKMOTION_H_

#if (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)

#include <animation/motion.h>
#include <animation/generictime.h>
#include <core/time.h>
#include "math/vector2.h"
#include "shape/rectangle.h"

// --------------------------------------------------------------------------------------------------------------------
namespace Soccer
{
namespace Animation
{

// --------------------------------------------------------------------------------------------------------------------
struct PlaybackInfo
{
	// Review(danc): I would really like to remove these two transforms, only physics depends on them when computing ball displacement
	JointMatrix					mStartTransform;
	JointMatrix					mFinalTransform;

	Axiom::Math::Vector2		mParameters;
	Axiom::StringCRC			mActiveMotionName;
	GenericTime					mInitialProgress; // Note InitialProgress is set to Zero in StartPlayback
	GenericTime					mPreviousProgress;
	GenericTime					mActiveProgress;
	GenericTime					mEndProgress;
	Axiom::TimeAbsolute			mStartTime;
	Axiom::Time					mDuration;
	float						mInitialPlaybackRate;
	float						mPlaybackRate;
	bool						mLooped;

								PlaybackInfo();
	inline const char*			MotionName() const				{ return mActiveMotionName.AsChar(); }
	inline bool					Cyclic() const					{ return mEndProgress.IsInvalid(); }
	inline bool					ContinuePlayback() const		{ return Cyclic() || (mActiveProgress < mEndProgress && !mLooped); }
	inline Axiom::TimeAbsolute	StartTime() const				{ return mStartTime; }
	inline Axiom::TimeAbsolute	ActiveTime() const				{ return StartTime() + mActiveProgress.AsFloat() * Duration(); }
	inline Axiom::TimeAbsolute	EndTime() const					{ return StartTime() + (Cyclic() ? 1.f : mEndProgress.AsFloat()) * Duration(); }
	inline Axiom::Time			Duration() const				{ return mDuration; }
	inline Axiom::Time			RateAdjustedDuration() const	{ return mPlaybackRate*mDuration; }
	inline Axiom::Math::Vector3	Displacement() const			{ return mFinalTransform.mTranslation - mStartTransform.mTranslation; }
	inline float				MotionSpeed() const				{ return Displacement().Magnitude() / Duration().AsFloatInSeconds(); }
	inline float				RateAdjustedMotionSpeed() const { return mPlaybackRate*MotionSpeed(); }

	AP_DECLARE_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
class Playback : public Motion
{
public:
	explicit					Playback(const Axiom::StringCRC& name);

	virtual void				Initialize(const Character*);
	virtual void				InitializeIndividual(Individual::Ptr&) const;
	virtual const bool			IsPlayable(const Individual::Ptr&) const;
	virtual void				StartPlayback(Individual::Ptr&) const;
	virtual const bool 			Play(Individual::Ptr&) const;
	virtual void				Serialize(Axiom::Serializer& stream, Character*);

	void						AddClip(ClipId clipId, const bool mirrored, const bool reversed, const float& value);
	void						AddClipByName(const char* name, const bool mirrored, const float& value);
	void						AddReverseClipByName(const char* name, const bool mirrored, const float& value);

	void						Parameter(const char* parameter);
	const char*					Parameter() const;

	// NOTE: This class is supposed to be protected, but a bug in the Codewarrior compiler (20081217) prevents it from compiling
	// Please move it back should the situation ever change.
	struct ClipDescription
	{
		float					mValue;
		ClipId					mClipId;
		bool					mMirrored;
        bool                    mReversed;

		const bool operator==(const ClipDescription& rhs) const { return rhs.mClipId == mClipId; }
		AP_DECLARE_TYPE();
	};

protected:
								Playback();
	float						GetParameter(const Individual::Ptr&) const;
	void						AdvancePlayback(PlaybackInfo* playbackData) const;

	bool						Cyclic() const;
	void						Cyclic(bool value);

	static const int MAX_CLIPS = 10; // Can be no larger then 256
	typedef Axiom::Collections::StaticList<ClipDescription,MAX_CLIPS> ClipList;

	ClipList					mClips;
	Individual::Parameter		mParameterCache;
	Individual::Parameter		mPlaybackCache;
	GenericTime					mEndPosition;
	float						mPlaybackRate;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();

};

// --------------------------------------------------------------------------------------------------------------------
class PlaybackGroup : public Motion
{
public:
	virtual void				Initialize(const Character*);
	virtual void				InitializeIndividual(Individual::Ptr&) const;
	virtual const bool			IsPlayable(const Individual::Ptr&) const;
	virtual void				StartPlayback(Individual::Ptr&) const;
	virtual const bool 			Play(Individual::Ptr&) const;
	virtual void				Serialize(Axiom::Serializer& stream, Character*);

	void						WidthParameter(const char* width);
	void						LengthParameter(const char* length);
	const char*					WidthParameter() const;
	const char*					LengthParameter() const;

	void						AddClip(ClipId clipId, const bool mirrored, const bool reversed, const Axiom::Math::Vector2& position);
	void						AddClipByName(const char* name, const bool mirrored, const Axiom::Math::Vector2& position);
    void                        AddReverseClipByName(const char* name, const bool mirrored, const Axiom::Math::Vector2& position);
	void						AddTriangle(const int first, const int second, const int third);

	// NOTE: This class is supposed to be protected, but a bug in the Codewarrior compiler (20081217) prevents it from compiling
	// Please move it back should the situation ever change.
	struct ClipDescription
	{
		Axiom::Math::Vector2	mPosition;
		ClipId					mClipId;
		bool					mMirrored;
        bool                    mReversed;

		const bool operator==(const ClipDescription& rhs) const { return rhs.mClipId == mClipId; }
		AP_DECLARE_TYPE();
	};

protected:
								PlaybackGroup();

	struct Triangle
	{
		Axiom::Byte				mPoints[3];
	};
	static const int MAX_CLIPS = 20; // Can be no larger then 255
	typedef Axiom::Collections::StaticList<ClipDescription, MAX_CLIPS> ClipList;
	typedef Axiom::Collections::StaticList<Triangle, MAX_CLIPS> TriangleList;

	const float					GetWidth(const Individual::Ptr&) const;
	const float					GetLength(const Individual::Ptr&) const;
	const Triangle&				FindTriangle(	const Axiom::Math::Vector2& position, Axiom::Math::Vector3& barycentric ) const;
	const bool					Intersection(	const Axiom::Math::Vector2& start0, const Axiom::Math::Vector2& end0,
												const Axiom::Math::Vector2& start1, const Axiom::Math::Vector2& end1,
												Axiom::Math::Vector2* intersection ) const;
	const Axiom::Math::Vector2	CentreOfTriangle( const Triangle& triangle ) const;
	const Axiom::Math::Vector2	NearestPointInTriangle( const Triangle& triangle, const Axiom::Math::Vector2& point ) const;
	const bool					PointInTriangle(const Axiom::Math::Vector2& v0,
												const Axiom::Math::Vector2& v1,
												const Axiom::Math::Vector2& v2,
												const Axiom::Math::Vector2& sample, 
												Axiom::Math::Vector3& barycentric ) const;
	const bool					PointInTriangle(const Triangle& triangle,
												const Axiom::Math::Vector2& sample, 
												Axiom::Math::Vector3& barycentric ) const;
	bool						Cyclic() const;
	void						Cyclic(bool value);

	ClipList					mClips;
	TriangleList				mTriangles;
	Individual::Parameter		mPlaybackCache;
	Individual::Parameter		mWidthParameterCache;
	Individual::Parameter		mLengthParameterCache;
	GenericTime					mEndPosition;
	float						mPlaybackRate;

public:
	AP_DECLARE_POLYMORPHIC_TYPE();
};

// --------------------------------------------------------------------------------------------------------------------
} // namespace Animation
} // namespace Soccer

#endif // (CORE_XBOX360 == CORE_NO) && (CORE_PS3 == CORE_NO)


#endif // _PLAYBACKMOTION_H_

// End of file --------------------------------------------------------------------------------------------------------

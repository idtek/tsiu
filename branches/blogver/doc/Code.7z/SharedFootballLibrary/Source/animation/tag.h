// tag.h - (c) 2008 Action Pants Inc.
// -----------------------------------------------------------------------------

#ifndef _TAG_H
#define _TAG_H

namespace Soccer
{
	namespace Animation
	{
		typedef int TagId;
		struct Tag
		{	
			//Tag() : mId(-1), mName("<NULL>", mMirror(-1), mJointRef(-1), mSkelRef(-1) {}
			TagId		mId;		// id for this tag (some game-specific key)
			const char*	mName;		// tag name
			int			mMirror;	// tag mirror
			//int			mJointRef;	// index of the joint this tag references (-1 if none)
			//int			mSkelRef;	// index of the skeleton containing the joint ref (-1 if none)
			AP_DECLARE_TYPE();
		};

		typedef int AnimStateId;
		struct AnimState
		{
			AnimStateId	mId;		// id for this state (some game-specific key)
			const char* mName;		// state name
			AP_DECLARE_TYPE();
		};
	} // namespace Animation
} // namespace Soccer

#endif // _TAG_H

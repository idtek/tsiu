#ifndef _TOURNAMENTMANAGER_H
#define _TOURNAMENTMANAGER_H

#include "collections/list.h"
#include "collections/sortedlist.h"
#include "core/singleton.h"
#include <string/staticstring.h>
#include <core/classedenum.h>
#include <memory/apmemory.h>

namespace Soccer
{
	const int PointsPerWin = 3;
	const int PointsPerTie = 1;
	class Team
	{
	public:
		Team(Axiom::ShortString teamID, int rating, bool isUserTeam) : m_TeamID(teamID), m_Rating(rating), 
			m_Wins(0), m_Ties(0), m_Losses(0), m_GoalsFor(0), m_GoalsAgainst(0), m_IsUserTeam(isUserTeam)
		{
		}
		Team() : m_TeamID(""), m_Rating(-1), m_Wins(0), m_Ties(0), m_Losses(0), m_GoalsFor(0), m_GoalsAgainst(0), m_IsUserTeam(false)
		{
		}
		friend bool operator==( const Team& lhs, const Team& rhs );
		friend bool operator!=( const Team& lhs, const Team& rhs );
		friend bool operator>( const Team & lhs, const Team & rhs );

		const Axiom::ShortString &GetID() const
		{
			return m_TeamID;
		}

		int GetRating() const
		{
			return m_Rating;
		}

		int GetWins() const
		{
			return m_Wins;
		}

		int GetTies() const
		{
			return m_Ties;
		}

		int GetLosses() const
		{
			return m_Losses;
		}

		int GetGoalsFor() const
		{
			return m_GoalsFor;
		}

		int GetGoalsAgainst() const
		{
			return m_GoalsAgainst;
		}

		int GetPoints() const
		{
			return m_Wins * PointsPerWin + m_Ties * PointsPerTie;
		}

		bool IsUserTeam() const
		{
			return m_IsUserTeam;
		}

	private:
		friend class TournamentManager;

		Axiom::ShortString m_TeamID;
		int m_Rating;
		int m_Wins;
		int m_Ties;
		int m_Losses;
		int m_GoalsFor;
		int m_GoalsAgainst;
		bool m_IsUserTeam;

	public:
		AP_DECLARE_TYPE();
	};

	inline bool operator==( const Team& lhs, const Team& rhs )
	{
		int lhsPoints = lhs.GetPoints();
		int rhsPoints = rhs.GetPoints();

		if ((lhsPoints != 0) || (rhsPoints != 0))
		{
			return (lhsPoints == rhsPoints ? true : false);
		}

		return (lhs.m_Rating == rhs.m_Rating ? true : false);
	}

	inline bool operator!=( const Team& lhs, const Team& rhs )
	{
		return !(lhs == rhs);
	}

	inline bool operator>( const Team & lhs, const Team & rhs ) 
	{
		int lhsPoints = lhs.GetPoints();
		int rhsPoints = rhs.GetPoints();

		if ((lhsPoints != 0) || (rhsPoints != 0))
		{
			return (lhsPoints > rhsPoints ? true : false);
		}

		return (lhs.m_Rating > rhs.m_Rating ? true : false);
	}

	class ScheduledGame
	{
	public:
		ScheduledGame(Team * homeTeam, Team * awayTeam, int homeScore, int awayScore, bool hasBeenPlayed)
			:	m_pHomeTeam(homeTeam), m_pAwayTeam(awayTeam), m_HomeTeamScore(homeScore), m_AwayTeamScore(awayScore), 
			m_Round(0), m_NextGameIndex(-1), m_TeamsKnown(true), m_Played(hasBeenPlayed), m_Spawned(false)
		{
		}
		ScheduledGame() :	m_pHomeTeam(0), m_pAwayTeam(0), m_HomeTeamScore(-1), m_AwayTeamScore(-1), 
			m_Round(0), m_NextGameIndex(-1), m_TeamsKnown(false), m_Played(false), m_Spawned(false)
		{
		}

		const Team & GetHomeTeam()
		{
			return	*m_pHomeTeam;
		}
		const Team & GetAwayTeam()
		{
			return	*m_pAwayTeam;
		}
		int GetHomeTeamScore()
		{
			return m_HomeTeamScore;
		}
		int GetAwayTeamScore()
		{
			return m_AwayTeamScore;
		}
		void SetHomeTeamScore(const int homeTeamScore)
		{
			AP_ASSERT (m_TeamsKnown);
			AP_ASSERT (m_Played == false);
			m_HomeTeamScore = homeTeamScore;
		}
		void SetAwayTeamScore(const int awayTeamScore)
		{
			AP_ASSERT (m_TeamsKnown);
			AP_ASSERT (m_Played == false);
			m_AwayTeamScore = awayTeamScore;
		}
		int GetRound()
		{
			return m_Round;
		}
		bool TeamsKnown()
		{
			return m_TeamsKnown;
		}
		bool Played()
		{
			return m_Played;
		}

		int IntTeamsKnown()
		{
			if( m_TeamsKnown)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

		int IntPlayed()
		{
			if( m_Played)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}


	private:
		friend class TournamentManager;

		Team * m_pHomeTeam;
		Team * m_pAwayTeam;
		int m_HomeTeamScore;
		int m_AwayTeamScore;
		int m_Round;
		int m_NextGameIndex;
		bool m_TeamsKnown;
		bool m_Played;
		bool m_Spawned;

	public:
		AP_DECLARE_TYPE();
	};

	//enum TournamentType
	//{
	//	SingleElimination,
	//	RoundRobin,
	//	Ladder
	//};

	CLASSEDENUM_REFLECTED(  TournamentType,\
		CLASSEDENUM_ITEMSTART(SingleElimination)\
		CLASSEDENUM_ITEM(RoundRobin)\
		CLASSEDENUM_ITEM(Ladder),\
		SingleElimination )

	class TournamentManager : public Axiom::Singleton<TournamentManager>
	{
		AP_NON_COPYABLE(TournamentManager);
	public:
		TournamentManager();

		static const int NUM_MATCHES = 32;

		typedef Axiom::Collections::DynamicList<Team, NUM_MATCHES>  TeamList;
		typedef Axiom::Collections::DynamicList<ScheduledGame, NUM_MATCHES>  GameList;

		void Load(const char* dbName);

		void ClearTeams();

		void AddTeam(Axiom::ShortString team, int rating, bool isUserTeam);

		void AddTeam_Char(char * team, int rating, bool isUserTeam);

		void SetTeams(const TeamList & inputAllTeams);

		TeamList & GetTeams();

		TeamList & GetSortedTeams();

		void GenerateTournament(TournamentType type);

		void SimulateGame(ScheduledGame * inputGame);

		void SubmitGame(ScheduledGame * inputGame);

		GameList & GetGames();

		ScheduledGame * GetNextScheduledGame();

		bool IsTournamentDone();

		Team * GetTournamentWinner();

		bool PossiblyCreateNewGame();

	private:
		void AddGame(Soccer::ScheduledGame & game);

		void DebugPrint();

		TournamentType m_CurrentTournamentType;

		//do not change original order because it is pointed to by games
		TeamList m_TeamsList;

		TeamList m_SortedTeamsList;

		//contains every game in the tournament, whether it is human or AI, whether it has been played yet or not, whether the home/away teams are known yet or not
		GameList m_GamesList; 

	public:
		AP_DECLARE_TYPE();
	};

	inline bool operator==( const ScheduledGame& lhs, const ScheduledGame& rhs )
	{
		return (memcmp(&lhs,&rhs, sizeof(ScheduledGame)) == 0 ? true : false);
	}

	inline bool operator!=( const ScheduledGame& lhs, const ScheduledGame& rhs )
	{
		return !(lhs == rhs);
	}

} // namespace Soccer


#endif

#include "frontend/TournamentManager.h"
#include <core/time.h>
#include <core/random.h>

/// quicksort


template<class _Ty> inline
void swap(_Ty& _Left, _Ty& _Right)
{	// exchange values stored at _Left and _Right
	_Ty _Tmp = _Left;
	_Left = _Right, _Right = _Tmp;
}

template<typename IT, class _Ty> 
IT partition(IT begin, IT end, IT pivot, _Ty& dummy)
{
	_Ty piv(*pivot);
	swap(*pivot, *(end-1));
	IT store=begin;
	for(IT it=begin; it!=end-1; ++it) {
		if(*it > piv) {
			swap(*store, *it);
			++store;
		}
	}
	swap(*(end-1), *store);
	return store;
}

template<typename IT>
IT pivot_median(IT begin, IT end)
{
	IT pivot(begin+(end-begin)/2);
	if(*begin > *pivot && *(end-1) > *begin) pivot=begin;
	else if(*(end-1) > *pivot && *begin > *(end-1)) pivot=end-1;
	return pivot;
}


template<typename IT, typename PF> 
void quick_sort(IT begin, IT end, PF pf)
{
	if((end-begin)>1) {
		IT pivot=pf(begin, end);

		pivot=partition(begin, end, pivot, *pivot);

		quick_sort(begin, pivot, pf);
		quick_sort(pivot+1, end, pf);
	}
}

template<typename IT>
struct pivot_random {
	pivot_random() {
		srand(1);
	}
	IT operator()(IT begin, IT end) {
		return begin+(rand()%(end-begin));
	}
};

template<typename IT>
struct pivot_half {
	IT operator()(IT begin, IT end) {
		return begin+((end-begin) / 2);
	}
};

template<typename IT>
void quick_sort(IT begin, IT end)
{
	//quick_sort(begin, end, pivot_random<IT>());
	quick_sort(begin, end, pivot_half<IT>());
}

/////

static Axiom::Random localRandom;


namespace Soccer {

	AP_TYPE(Team)		
		AP_FIELD("TeamID", m_TeamID, "TeamID of this team, set upon initialization." )
		AP_FIELD("Rating", m_Rating, "Rating of this team, higher means a better team." )
		AP_FIELD("Wins", m_Wins, "Wins recorded so far for this team." )
		AP_FIELD("Ties", m_Ties, "Ties recorded so far for this team." )
		AP_FIELD("Losses", m_Losses, "Losses recorded so far for this team." )
		AP_FIELD("GoalsFor", m_GoalsFor, "Goals For recorded so far for this team." )
		AP_FIELD("GoalsAgainst", m_GoalsAgainst, "Goals Against recorded so far for this team." )
		AP_COMMAND(GetPoints, "Points recorded so far for this team.")		

		AP_FIELD("IsUserTeam", m_IsUserTeam, "Whether this team is a user team." )

		AP_PROXY("SharedFootballLibrary")
		AP_TYPE_END()

		AP_TYPE(TournamentType)
		AP_ENUM()

		AP_PROXY("SharedFootballLibrary")
		AP_TYPE_END()

		AP_TYPE(ScheduledGame)

		AP_FIELD("HomeTeam", m_pHomeTeam, "Home team playing this ScheduledGame." )
		AP_FIELD("AwayTeam", m_pAwayTeam, "Away team playing this ScheduledGame." )
		//alternatively, if too much exposed
		//AP_COMMAND(GetHomeTeam, "Home team playing this ScheduledGame.")
		//AP_COMMAND(GetAwayTeam, "Away team playing this ScheduledGame.")

		AP_FIELD("HomeTeamScore", m_HomeTeamScore, "HomeTeam score." )
		AP_FIELD("AwayTeamScore", m_AwayTeamScore, "AwayTeam score." )

		AP_FIELD("Round", m_Round, "Round this game is contained in, starts counting with 1." )
		AP_FIELD("TeamsKnown", m_TeamsKnown, "Whether the teams to play this game are known yet." )
		AP_FIELD("Played", m_Played, "Whether this game has been played yet. Games may only be played once." )
		AP_COMMAND(IntTeamsKnown, "Reload the tournament currently in the tounament manager.")
		AP_COMMAND(IntPlayed, "Reload the tournament currently in the tounament manager.")

		AP_PROXY("SharedFootballLibrary")
		AP_TYPE_END()

		AP_TYPE(TournamentManager)
		AP_COMMAND(Load, "Reload the tournament currently in the tounament manager.")
		AP_COMMAND(ClearTeams, "Clear teams known to the tournament manager.")
		AP_COMMAND(AddTeam, "Add a team to the tournament manager, where team name is an Axiom::ShortString.")
		AP_COMMAND(AddTeam_Char, "Add a team to the tournament manager, where team name is a char *.")
		AP_COMMAND(SetTeams, "Sets all teams with given input.")
		AP_COMMAND(GetTeams, "Get a dynamic list of all known teams.")
		AP_COMMAND(GetSortedTeams, "Get a dynamic list of all known teams sorted, by points if available, else by initial rating.")
		AP_COMMAND(GenerateTournament, "Generates a new tournament")
		AP_COMMAND(SimulateGame, "Simulates a game")
		AP_COMMAND(SubmitGame, "Submits the results of a game to the tournament manager")
		AP_COMMAND(GetGames, "Get a dyanmic list of all known games in the tournament, whether it has been played yet or not.")
		AP_COMMAND(GetNextScheduledGame, "Get the next scheduled game which can be played.")
		AP_COMMAND(IsTournamentDone, "Whether or not all games in tournament have been played.")
		AP_COMMAND(GetTournamentWinner, "Gets the overall winner of the tournament, if any.");

	AP_PROXY("SharedFootballLibrary")
		AP_TYPE_END()

		TournamentManager::TournamentManager()
	{
		AP::Reflection::Script::Register("TournamentManager", AP::Reflection::Instance(this), "Tournament management system.");

		ClearTeams();

		return;
	}

	void TournamentManager::Load(const char* dbName)
	{
		return;
	}

	void TournamentManager::ClearTeams()
	{
		m_TeamsList.Clear();
		m_SortedTeamsList.Clear();
		m_GamesList.Clear();

		m_TeamsList.Resize(Axiom::Memory::DEFAULT_HEAP,	8);
		m_SortedTeamsList.Resize(Axiom::Memory::DEFAULT_HEAP, 8);
		m_GamesList.Resize(Axiom::Memory::DEFAULT_HEAP, 56); //max for round robin tournament of 8 teams
	}

	void TournamentManager::AddTeam(Axiom::ShortString team, int rating, bool isUserTeam)
	{
		if ( m_TeamsList.Count() + 1 > m_TeamsList.Capacity() )
		{
			m_TeamsList.IncreaseAndCopy (Axiom::Memory::DEFAULT_HEAP, m_TeamsList.Capacity() * 2);
		}

		Team newTeam(team, rating, isUserTeam);
		m_TeamsList.Add(newTeam);
	}

	void TournamentManager::AddTeam_Char(char * team, int rating, bool isUserTeam)
	{
		Axiom::ShortString shortstringTeam(team);

		AddTeam(shortstringTeam, rating, isUserTeam);
	}

	void TournamentManager::AddGame(Soccer::ScheduledGame & game)
	{
		if ( m_GamesList.Count() + 1 > m_GamesList.Capacity() )
		{
			m_GamesList.IncreaseAndCopy (Axiom::Memory::DEFAULT_HEAP, m_GamesList.Capacity() * 2);
		}

		m_GamesList.Add(game);
	}

	TournamentManager::TeamList & TournamentManager::GetSortedTeams()
	{
		//do not change original order of m_TeamsList because it is pointed to by m_GamesList
		return m_SortedTeamsList;
	}

	TournamentManager::TeamList & TournamentManager::GetTeams()
	{
		return m_TeamsList;
	}

	void TournamentManager::SetTeams(const TeamList & inputAllTeams)
	{
		m_GamesList.IncreaseAndCopy (Axiom::Memory::DEFAULT_HEAP, m_TeamsList.Capacity() * 2); //games approximately 2 * teams
		m_TeamsList = inputAllTeams;
	}

	typedef Axiom::Collections::DynamicList<int, 1>  LineupList;

	static void GenerateLineup (LineupList * teamOrdering, int numRoundsLeft)
	{
		if ( teamOrdering->Count() * 2 > teamOrdering->Capacity() )
		{
			teamOrdering->IncreaseAndCopy (Axiom::Memory::DEFAULT_HEAP, teamOrdering->Capacity() * 2); //increase size of d as necesscary
		}
		int numInserts = teamOrdering->Count();
		int newTotalPerRound = teamOrdering->Count() * 2 + 1;
		int i = 0;
		while (numInserts > 0)
		{
			int oldHighRound = (*teamOrdering)[i];
			int vsHighRound = newTotalPerRound - oldHighRound;
			teamOrdering->Insert(i+1, vsHighRound);
			i += 2; //skip over just inserted item + move onto next item
			numInserts -= 1;
		}

		numRoundsLeft -= 1;
		if (numRoundsLeft > 0)
		{
			GenerateLineup(teamOrdering, numRoundsLeft);
		}
	}

	void TournamentManager::GenerateTournament(TournamentType type)
	{
		localRandom.Seed( (int) Axiom::GetEpochTime() );

		m_GamesList.Clear();
		m_CurrentTournamentType = type;

		//before any games are played, sorted games list == unsorted games list
		m_SortedTeamsList.Resize(Axiom::Memory::DEFAULT_HEAP, m_TeamsList.Count());
		m_SortedTeamsList.CloneFrom(m_TeamsList);

		if (m_CurrentTournamentType == TournamentType::SingleElimination)
		{
			float fNumberOfRounds = (log((float) m_TeamsList.Count()) / log(2.0f));
			int numberOfRounds = (int) fNumberOfRounds;

			const float Epsilon = 0.000001f;
			if ( fNumberOfRounds > (float) ((int) fNumberOfRounds) + Epsilon )
			{
				numberOfRounds += 1;
			}

			const unsigned int numberOfFirstRoundSlots = (int) (pow(2.0f, numberOfRounds));
			const unsigned int numberOfFirstRoundGames = numberOfFirstRoundSlots / 2;

			LineupList teamOrdering;
			teamOrdering.Resize(Axiom::Memory::DEFAULT_HEAP, 16);
			teamOrdering.Add(1);

			GenerateLineup(&teamOrdering, numberOfRounds);

			//insert null teams
			if (m_TeamsList.Count() < numberOfFirstRoundSlots)
			{
				Team nullTeam("Bye", -1000, false);
				int numAdditionalNullTeams = numberOfFirstRoundSlots - m_TeamsList.Count();
				while (numAdditionalNullTeams > 0)
				{
					m_TeamsList.Add(nullTeam);
					numAdditionalNullTeams -= 1;
				}
			}

			Team * start = &m_TeamsList.FirstItem();
			Team * end = &m_TeamsList.LastItem() + 1;

			quick_sort(start,end);

			//now, quick_sort Teams
			int nextGameCounter = numberOfFirstRoundSlots;

			for (unsigned int i = 0; i < m_TeamsList.Count(); i += 2)
			{
				Soccer::ScheduledGame & input = *(AP_NEW (Axiom::Memory::DEFAULT_HEAP,ScheduledGame()));

				unsigned int higherRankedTeam = teamOrdering[i+1] - 1;
				unsigned int lowerRankedTeam = teamOrdering[i] - 1;

				AP_ASSERT (higherRankedTeam >= 0);
				AP_ASSERT (lowerRankedTeam >= 0);
				AP_ASSERT (higherRankedTeam < m_TeamsList.Count());
				AP_ASSERT (lowerRankedTeam < m_TeamsList.Count());

				input.m_pHomeTeam = &m_TeamsList[higherRankedTeam];
				input.m_pAwayTeam = &m_TeamsList[lowerRankedTeam];
				input.m_TeamsKnown = true;
				input.m_Played = false;
				input.m_Spawned = false;
				input.m_HomeTeamScore = 0;
				input.m_AwayTeamScore = 0;
				input.m_Round = 1;

				input.m_NextGameIndex = nextGameCounter / 2; //iterating per team so / 2
				nextGameCounter += 1;

				if ((input.m_pHomeTeam->GetRating() < 0) || (input.m_pAwayTeam->GetRating() < 0))
				{
					input.m_Played = true; //for bye games, assume they are played so we can simply skip them
				}

				AddGame(input);
			}

			int latestRound = 1;
			int nextRoundGames = numberOfFirstRoundGames;

			while (latestRound < numberOfRounds)
			{
				latestRound += 1;
				nextRoundGames = nextRoundGames / 2;

				for (int i = 0; i < nextRoundGames; ++i)
				{
					//insert null teams now, when init
					ScheduledGame nullGame;

					nullGame.m_pHomeTeam = 0;
					nullGame.m_pAwayTeam = 0;
					nullGame.m_TeamsKnown = false;
					nullGame.m_Played = false;
					nullGame.m_Spawned = false;
					nullGame.m_HomeTeamScore = 0;
					nullGame.m_AwayTeamScore = 0;
					nullGame.m_Round = latestRound;

					nullGame.m_NextGameIndex = nextGameCounter / 2;
					nextGameCounter += 1; 

					AddGame(nullGame);
				}
			}

			while (PossiblyCreateNewGame()) //advance through all early round byes
			{
			}
		}
		if (m_CurrentTournamentType == TournamentType::RoundRobin)
		{

			//insert one null team
			if (m_TeamsList.Count() % 2 == 1)
			{
				Team nullTeam("Bye", -1000, false);
				m_TeamsList.Add(nullTeam);
			}

			LineupList d;
			d.Resize(Axiom::Memory::DEFAULT_HEAP, m_TeamsList.Count());

			for (unsigned int i = 0; i < m_TeamsList.Count(); ++i)
			{
				d.Add(i);
			}

			int numberOfRounds = m_TeamsList.Count() - 1;

			for (int curRound = 1; curRound <= numberOfRounds; ++curRound)
			{
				for (unsigned int i = 0; i < m_TeamsList.Count() / 2; i += 1)
				{
					Soccer::ScheduledGame & input = *(AP_NEW (Axiom::Memory::DEFAULT_HEAP,ScheduledGame()));

					unsigned int lowerRankedTeam = d[i];
					unsigned int higherRankedTeam = d[m_TeamsList.Count() - 1 - i];

					AP_ASSERT (higherRankedTeam >= 0);
					AP_ASSERT (lowerRankedTeam >= 0);
					AP_ASSERT (higherRankedTeam < m_TeamsList.Count());
					AP_ASSERT (lowerRankedTeam < m_TeamsList.Count());

					input.m_pHomeTeam = &m_TeamsList[higherRankedTeam];
					input.m_pAwayTeam = &m_TeamsList[lowerRankedTeam];
					input.m_TeamsKnown = true;
					input.m_Played = false;
					input.m_Spawned = false;
					input.m_HomeTeamScore = 0;
					input.m_AwayTeamScore = 0;
					input.m_Round = curRound;

					input.m_NextGameIndex = -1; //there is no next game graph in round robin

					AddGame(input);
				}

				//rotate first n-1
				int swapval = d[m_TeamsList.Count() - 2];
				for (int j = (int) m_TeamsList.Count() - 3; j >= 0; j--)
				{
					d[j+1] = d[j];
				}
				d[0] = swapval;

			}

		}
		if (m_CurrentTournamentType == TournamentType::Ladder)
		{
			//the first user team found, plays everyone else

			//For a ladder tournament, we want the best teams to be last
			//must work with m_TeamsList as opposed to m_SortedTeamsList because we want to use the original Team * to write team points to when we play games
			Team * start = &m_TeamsList.FirstItem();
			Team * end = &m_TeamsList.LastItem() + 1;

			quick_sort(start,end);

			//find first user team
			unsigned int userTeamIndex = 0xFFFFFFFF;
			for (unsigned int i = 0; i < m_TeamsList.Count(); ++i)
			{
				if (m_TeamsList[i].IsUserTeam())
				{
					userTeamIndex = i;
					break;
				}
			}

			if (userTeamIndex == 0xFFFFFFFF)
			{
				//if no user team, no games in this tournament
				AP_ASSERT(m_GamesList.Count() == 0);
				return;
			}

			AP_ASSERT (userTeamIndex >= 0);
			AP_ASSERT (userTeamIndex < m_TeamsList.Count());

			int numberOfRounds = m_TeamsList.Count() - 1;

			unsigned int currOpponent = numberOfRounds; //count down

			for (int curRound = 1; curRound <= numberOfRounds; ++curRound)
			{
				Soccer::ScheduledGame & input = *(AP_NEW (Axiom::Memory::DEFAULT_HEAP,ScheduledGame()));

				if (currOpponent == userTeamIndex)
				{
					--currOpponent;
				}

				AP_ASSERT (currOpponent >= 0);
				AP_ASSERT (currOpponent < m_TeamsList.Count());

				input.m_pHomeTeam = &m_TeamsList[currOpponent];
				input.m_pAwayTeam = &m_TeamsList[userTeamIndex]; //user will visit everyone else at home
				input.m_TeamsKnown = true;
				input.m_Played = false;
				input.m_Spawned = false;
				input.m_HomeTeamScore = 0;
				input.m_AwayTeamScore = 0;
				input.m_Round = curRound;

				input.m_NextGameIndex = -1; //there is no next game graph in Ladder, all games are known at the start and there are no feeder games

				--currOpponent;

				AddGame(input);
			}

		}


	}

	//sweep through and define all sub games (need to also resolve byes)
	bool TournamentManager::PossiblyCreateNewGame()
	{
		bool retval = false;

		if (m_CurrentTournamentType == TournamentType::SingleElimination)
		{
			for (unsigned int i = 0; i < m_GamesList.Count() - 1; i += 2) // -1 because do not spawn a game from the last game
			{
				AP_ASSERT (i < m_GamesList.Count());
				AP_ASSERT (i+1 < m_GamesList.Count());

				if ((m_GamesList[i].m_Played) && (m_GamesList[i+1].m_Played) && 
					(m_GamesList[i].m_Spawned == false) && (m_GamesList[i+1].m_Spawned == false))
				{
					Team * upperHomeTeam = m_GamesList[i].m_pHomeTeam;
					Team * upperAwayTeam = m_GamesList[i].m_pAwayTeam;

					Team * lowerHomeTeam = m_GamesList[i+1].m_pHomeTeam;
					Team * lowerAwayTeam = m_GamesList[i+1].m_pAwayTeam;

					Team * upperWinningTeam = upperHomeTeam;
					if (m_GamesList[i].m_HomeTeamScore < m_GamesList[i].m_AwayTeamScore || upperHomeTeam->GetRating() < 0)
					{
						upperWinningTeam = upperAwayTeam;
					}

					Team * lowerWinningTeam = lowerHomeTeam;
					if (m_GamesList[i+1].m_HomeTeamScore < m_GamesList[i+1].m_AwayTeamScore || lowerHomeTeam->GetRating() < 0)
					{
						lowerWinningTeam = lowerAwayTeam;
					}

					//if (upperWinningTeam->GetRating() < lowerWinningTeam->GetRating())
					//{
					//	//eg. std::swap()
					//	Team * swapstore = upperWinningTeam;
					//	upperWinningTeam = lowerWinningTeam;
					//	lowerWinningTeam = swapstore;
					//}

					m_GamesList[i].m_Spawned = true;
					m_GamesList[i+1].m_Spawned = true;

					AP_ASSERT (m_GamesList[i].m_NextGameIndex == m_GamesList[i+1].m_NextGameIndex);
					AP_ASSERT (m_GamesList[i].m_NextGameIndex < (int) m_GamesList.Count());

					Soccer::ScheduledGame & newGame = m_GamesList[m_GamesList[i].m_NextGameIndex];

					newGame.m_pHomeTeam = upperWinningTeam;
					newGame.m_pAwayTeam = lowerWinningTeam;
					newGame.m_TeamsKnown = true;
					newGame.m_Played = false;
					newGame.m_Spawned = false;
					newGame.m_HomeTeamScore = 0;
					newGame.m_AwayTeamScore = 0;
					//note: m_Round already known

					retval = true;
					break;
				}
			}

		}

		return retval;
	}

	void TournamentManager::DebugPrint()
	{
	}

	void TournamentManager::SimulateGame(ScheduledGame * inputGame)
	{
		if (inputGame->m_Played == false && inputGame->m_TeamsKnown == true)
		{
			Team & homeTeam = *(inputGame->m_pHomeTeam);
			Team & awayTeam = *(inputGame->m_pAwayTeam);

			//On Soccer Academy, there are no random scores- better team always wins by 1 goal
			int homeTeamPoints = homeTeam.GetRating();
			int awayTeamPoints = awayTeam.GetRating();
			//int homeTeamPoints = homeTeam.GetRating() + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8);
			//int awayTeamPoints = awayTeam.GetRating() + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8) + localRandom.RandInt(0, 8);

			int basegoals = rand() % 4 + rand() %4 - 2;
			if (basegoals < 0)
			{
				basegoals = 0;
			}
			int goaldifferential = abs (homeTeamPoints - awayTeamPoints) / 10 + 1;

			if (homeTeamPoints >= awayTeamPoints) //"homefield advantage" ties in points go to home team, always a winner generated
			{
				inputGame->m_HomeTeamScore = basegoals + goaldifferential;
				inputGame->m_AwayTeamScore = basegoals;
			}
			else
			{
				inputGame->m_HomeTeamScore = basegoals;
				inputGame->m_AwayTeamScore = basegoals + goaldifferential;
			}

			SubmitGame (inputGame);
		}
	}

	void TournamentManager::SubmitGame(ScheduledGame * inputGame)
	{
		if (inputGame->m_Played == false && inputGame->m_TeamsKnown == true)
		{
			Team & homeTeam = *(inputGame->m_pHomeTeam);
			Team & awayTeam = *(inputGame->m_pAwayTeam);

			inputGame->m_Played = true;
			inputGame->m_Spawned = false; //redundant

			AP_ASSERT (inputGame->m_HomeTeamScore >= 0);
			AP_ASSERT (inputGame->m_AwayTeamScore >= 0);

			homeTeam.m_GoalsFor += inputGame->m_HomeTeamScore;
			homeTeam.m_GoalsAgainst += inputGame->m_AwayTeamScore;
			awayTeam.m_GoalsFor += inputGame->m_AwayTeamScore;
			awayTeam.m_GoalsAgainst += inputGame->m_HomeTeamScore;

			if (inputGame->m_HomeTeamScore > inputGame->m_AwayTeamScore)
			{
				++homeTeam.m_Wins;
				++awayTeam.m_Losses;
			}
			else if (inputGame->m_HomeTeamScore < inputGame->m_AwayTeamScore)
			{
				++homeTeam.m_Losses;
				++awayTeam.m_Wins;
			}
			else
			{
				++homeTeam.m_Ties;
				++awayTeam.m_Ties;
			}

			AP_ASSERT (homeTeam.m_Wins >= 0);
			AP_ASSERT (homeTeam.m_Losses >= 0);
			AP_ASSERT (homeTeam.m_Ties >= 0);
			AP_ASSERT (awayTeam.m_Wins >= 0);
			AP_ASSERT (awayTeam.m_Losses >= 0);
			AP_ASSERT (awayTeam.m_Ties >= 0);

			PossiblyCreateNewGame();

			//update m_SortedTeamsList; do not change original order of m_TeamsList because it is pointed to by m_GamesList
			m_SortedTeamsList.Resize(Axiom::Memory::DEFAULT_HEAP, m_TeamsList.Count());
			m_SortedTeamsList.CloneFrom(m_TeamsList);
			Team * start = &m_SortedTeamsList.FirstItem();
			Team * end = &m_SortedTeamsList.LastItem() + 1;

			quick_sort(start,end);
		}

#if CORE_DEBUG == CORE_YES
		DebugPrint();
#endif
	}

	TournamentManager::GameList & TournamentManager::GetGames()
	{
		return m_GamesList;
	}

	ScheduledGame * TournamentManager::GetNextScheduledGame()
	{
		for (unsigned int i = 0; i < m_GamesList.Count(); ++i)
		{
			if (m_GamesList[i].m_Played == false && m_GamesList[i].m_TeamsKnown)
			{
				return &m_GamesList[i];
			}
		}
		return 0;
	}


	bool TournamentManager::IsTournamentDone()
	{
		bool tournamentDone = true;
		for (unsigned int i = 0; i < m_GamesList.Count(); ++i)
		{
			if (m_GamesList[i].m_Played == false)
			{
				tournamentDone = false;
				break;
			}
		}
		if (m_CurrentTournamentType == TournamentType::Ladder)
		{
			tournamentDone = false;
			for (unsigned int i = 0; i < m_GamesList.Count(); ++i)
			{
				if ( m_GamesList[i].m_HomeTeamScore > m_GamesList[i].m_AwayTeamScore )
				{
					AP_ASSERT(m_GamesList[i].m_Played == true);
					AP_ASSERT(m_GamesList[i].m_pHomeTeam->IsUserTeam() == false);
					AP_ASSERT(m_GamesList[i].m_pAwayTeam->IsUserTeam() == true);
					tournamentDone = true; 
					break;
				}
			}
		}

		return tournamentDone;
	}

	Team * TournamentManager::GetTournamentWinner()
	{
		Team * winner = 0;

		if (IsTournamentDone())
		{
			if (m_CurrentTournamentType == TournamentType::SingleElimination)
			{
				winner = &m_SortedTeamsList.FirstItem();
			}
			else if (m_CurrentTournamentType == TournamentType::RoundRobin)
			{
				winner = &m_SortedTeamsList.FirstItem();
			}
			else if (m_CurrentTournamentType == TournamentType::Ladder)
			{
				winner = &m_SortedTeamsList.FirstItem();
			}
		}
		return winner;
	}
} // namespace Soccer

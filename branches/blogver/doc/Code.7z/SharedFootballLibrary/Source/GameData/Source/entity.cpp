// ------------------------------------------------------------------------ [Entity.cpp]
#ifndef _AP_ENTITY
#include "gamedata/entity.h"
#endif

// ------------------------------------------------------------------------- [Code]
namespace SharedSoccer
{
	// --------------------------------------------------------------------- [Reflection Stuff]
	AP_TYPE(EntityGUID)
		AP_DEFAULT_CREATE()
        AP_CREATE_1(SharedSoccer::EntityGUID)
		AP_COMMAND(IsValid, "Accessor returning whether the guid in question is valid or not (for example default constructed guid is NOT valid)")
		AP_PROXY("SharedFootballLibrary")
		AP_FIELD("GUID", m_GUID, "");
	AP_TYPE_END()

	// --------------------------------------------------------------------- [EntityGUIDManager class]
	class EntityGUIDManager
	{
		public:
			static EntityGUID GetNextEntityGUID()
			{
				return EntityGUID(m_sEntityGUIDManager.m_NextEntityGUID++);
			}

		protected:
			int			m_NextEntityGUID;

		protected:
			EntityGUIDManager(): m_NextEntityGUID(1) {};
			~EntityGUIDManager() {};

		protected:
			EntityGUIDManager(const EntityGUIDManager&);
			EntityGUIDManager& operator=(const EntityGUIDManager&);

		protected:
			static EntityGUIDManager m_sEntityGUIDManager;
	};

	EntityGUIDManager EntityGUIDManager::m_sEntityGUIDManager;

	// ----------------------------------------------------------------------- [Entity]
	Entity::Entity(bool generateGUID) :
		m_GUID(ESpecialEntityGUIDs::Invalid)
	{
		if(generateGUID)
		{
			m_GUID = EntityGUIDManager::GetNextEntityGUID();
		}
	}

	Entity::Entity(const EntityGUID& guid) :
		m_GUID(guid)
	{ }

	Entity::Entity(const Entity& copy)
	{
		m_GUID = copy.m_GUID;
	}

	Entity& Entity::operator=(const Entity& RHS)
	{
		m_GUID = RHS.m_GUID;
		return *this;
	}

}

// -------------------------------------------------------------------------- [Functions]
namespace Axiom
{
	namespace HashFunctions
	{
		int GetHashID (const SharedSoccer::EntityGUID& val)
		{
			const int x = static_cast <int> (val.GetHashID ());
			return x;
		}
	}
}
	

#include "gamedata/commongamedataenums.h"

namespace Soccer {

AP_TYPE(ETeam)
	AP_ENUM()
	AP_PROXY("SharedFootballLibrary")
AP_TYPE_END()

} // namespace Soccer

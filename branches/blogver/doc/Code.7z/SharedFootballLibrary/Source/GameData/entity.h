// ---------------------------------------------------------------------------- [Entity.h]
#pragma once

#ifndef _AP_ENTITY
#define _AP_ENTITY

// ---------------------------------------------------------------------------- [Includes]
#ifndef _CLASSEDENUM_H
#include <core/classedenum.h>
#endif
#ifndef __AP__STRING_CLASSES__
#include <string/string.h>
#endif

// ---------------------------------------------------------------------------- [Declarations]
namespace SharedSoccer
{

	// ------------------------------------------------------------------------ [Enums]
	CLASSEDENUM	(	ESpecialEntityGUIDs, \
					CLASSEDENUM_ITEMWITHVALUE(Invalid, -1) \
					CLASSEDENUM_ITEMWITHVALUE(Dummy, 0), \
					Invalid \
				)
	
	// ------------------------------------------------------------------------ [EntityGUID]
	class EntityGUID
	{
		public:
			AP_DECLARE_TYPE();

		public:

			EntityGUID():m_GUID(ESpecialEntityGUIDs::Invalid){}
			explicit EntityGUID(int guid) : m_GUID(guid)	{}
			EntityGUID(const EntityGUID& copy)				{ m_GUID = copy.m_GUID; }
			static EntityGUID CreateInvalid()				{ return EntityGUID( ESpecialEntityGUIDs::Invalid ); }

			~EntityGUID() {}

			EntityGUID& operator=(const EntityGUID& rhs)
			{
				m_GUID = rhs.m_GUID;
				return *this;
			}

			bool operator==(const EntityGUID& rhs) const	{ return (m_GUID == rhs.m_GUID); }
			bool operator!=(const EntityGUID& rhs) const	{ return (m_GUID != rhs.m_GUID); }
			bool operator==(ESpecialEntityGUIDs rhs) const	{ return (m_GUID == rhs); }
			bool operator!=(ESpecialEntityGUIDs rhs) const	{ return (m_GUID != rhs); }

			int GetHashID() const							{ return m_GUID; }
			bool IsValid() const							{ return m_GUID != ESpecialEntityGUIDs::Invalid; }

		protected:
			int m_GUID;
	};

	// ------------------------------------------------------------------------ [Entity]
	class Entity
	{
		public:
			Entity(bool generateGUID = true);
			Entity(const EntityGUID& guid);
			Entity(const Entity& copy);
			~Entity()											{}

			Entity& operator=(const Entity& RHS);
			bool	operator == ( const Entity& rhs) const	{ return m_GUID == rhs.m_GUID;}

			EntityGUID		GetGUID() const						{ return m_GUID; } 

		public:
			EntityGUID		m_GUID;
	};
}

// --------------------------------------------------------------------------- [Global Functions]
namespace Axiom
{
	namespace HashFunctions
	{
		// add them as we need them... usually this is not a problem
		int GetHashID (const SharedSoccer::EntityGUID& val);
	}
}

#endif // _AP_ENTITY

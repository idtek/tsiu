#ifndef _COMMONGAMEDATAENUMS_H
# define _COMMONGAMEDATAENUMS_H

#include "core/classedenum.h"

namespace Soccer
{
#undef  INVALIDITEMS
#define INVALIDITEMS 1
    
CLASSEDENUM_REFLECTED (	ETeam,                                \
                        CLASSEDENUM_ITEMWITHVALUE(ETeam_NONE, -1)   \
                        CLASSEDENUM_ITEM(ETeam_HOME)                \
                        CLASSEDENUM_ITEM(ETeam_AWAY),               \
                        ETeam_HOME                                  \
  )

#undef  INVALIDITEMS
#define INVALIDITEMS 0
} // namespace Soccer

#endif


#ifndef  _SYSTEM_RAND_H__
# define _SYSTEM_RAND_H__

# ifndef _RANDOM_H___
#  include <core/random.h>
# endif
# ifndef _COMPONENT_MANAGER_H
#  include <kernel/componentmanager.h>
# endif

namespace SharedSoccer
{		
# if DEBUG_SIM_RAND
	#define RANDFLOAT(l,h) SharedSoccer::SysRand()->RandFloat(l, h, __FILE__, __LINE__, true, AP::ComponentManager::GetInstance()->GetCurrentThreadId() )
	#define RANDINT(l,h) SharedSoccer::SysRand()->RandInt(l, h, __FILE__, __LINE__, true, AP::ComponentManager::GetInstance()->GetCurrentThreadId() )
	#define RANDSEED(s) SharedSoccer::SysRand()->Seed(s, __FILE__, __LINE__, true, AP::ComponentManager::GetInstance()->GetCurrentThreadId() )
# else
	#define RANDFLOAT(l,h) SharedSoccer::SysRand()->RandFloat(l, h)
	#define RANDINT(l,h) SharedSoccer::SysRand()->RandInt(l, h)
	#define RANDSEED(s) SharedSoccer::SysRand()->Seed(s)
# endif

	// SimRand is only to be used by the SIMULATION Kernel.  And other users will throw an assertion..
	Axiom::Random* SysRand();
}

#endif

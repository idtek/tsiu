#include <kernel/componentmanager.h>
#include "system/systemrand.h"

namespace SharedSoccer
{
	static const int s_NbKernelsMax = 8;
	static Axiom::Random sSimRandList[s_NbKernelsMax];

	Axiom::Random* SysRand()
	{
		int kernelId = AP::ComponentManager::GetInstance()->GetKernelId();

		AP_ASSERT(kernelId>=0 && kernelId <s_NbKernelsMax);
		return &(sSimRandList[kernelId]);
	}
}

#pragma once

#ifndef _PARTICLE_TRANSFORM_DATA_H
#define _PARTICLE_TRANSFORM_DATA_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: SimParticleSystem
//
//-------------------------------------------------------------------------- [Include]
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef __AXIOM_ARRAY_H
#include <Collections/array.h>
#endif

//-------------------------------------------------------------------------- [FORWARDED CLASS]
namespace SharedSoccer
{
	class ParticleSystemReplayData;
}

//-------------------------------------------------------------------------- [NAMESPACE]
namespace SharedSoccer
{
namespace Particle
{
	class ParticleTransformData
	{
	public:

		ParticleTransformData():
			m_Position(),
			m_Rotation(),
			m_Active(false)
		{}

		ParticleTransformData(const Axiom::Math::Vector3& position, const Axiom::Math::Quaternion& rotation):
			m_Position(position),
			m_Rotation(rotation),
			m_Active(false)
		{}

	public:
		Axiom::Math::Vector3	m_Position;
		Axiom::Math::Quaternion m_Rotation;
		bool					m_Active;
	};

	typedef Axiom::Collections::StaticArray<ParticleTransformData, c_MAX_PARTICLE_TRANSFORM_ELEMENTS> ParticleTransformDataArray;
//--------------------------------------------------------------------------
} // Particle
} // Soccer
#endif

#pragma once

#ifndef _CURVE_INCLUDES_H
#define _CURVE_INCLUDES_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class:  Particle system Includes
// Desc:  Base includes and definitions for the particle system
//
//-------------------------------------------------------------------------- [Include]
//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{

		const float				c_MaxCurveTimeInterpolate = 126.9f; // Must be slightly less than c_NumberEntries-1 
		const Axiom::UInt32		c_NumberEntriesInCurveArray = 128;
		const Axiom::UInt32		c_NumberEntriesInCurveArrayMinusOne = c_NumberEntriesInCurveArray-1;

		enum CURVE_TYPES_e
		{
			START_CURVE_TYPES = 0,
			CURVE_LINEAR = START_CURVE_TYPES,
			CURVE_EASE_IN_EASE_OUT,
			CURVE_EASE_IN_FAST_OUT,
			CURVE_FAST_IN_EASE_OUT,
			CURVE_CUSTOM_1,
			CURVE_CUSTOM_2,
			CURVE_CUSTOM_3,
			CURVE_CUSTOM_4,
			CURVE_CUSTOM_5,
			CURVE_CUSTOM_6,
			CURVE_CUSTOM_7,
			CURVE_CUSTOM_8,
			CURVE_CUSTOM_9,
			CURVE_CUSTOM_10,
			CURVE_CUSTOM_11,
			CURVE_CUSTOM_12,
			NUMBER_CURVE_TYPES,
		};	
	}

}
//--------------------------------------------------------------------------
#endif // #define _CURVE_INCLUDES_H

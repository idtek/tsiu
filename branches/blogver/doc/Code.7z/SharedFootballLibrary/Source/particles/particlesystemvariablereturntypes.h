#pragma once

#ifndef _PARTICLE_VARIABLE_RETURN_TYPES_H
#define _PARTICLE_VARIABLE_RETURN_TYPES_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
// Class: ParticleSystemVariables
//  Base variables used by the particle system. These are set up to 
//			return random values from a certain base, possibly over a certain
//			time.
//
//-------------------------------------------------------------------------- [INCLUDES]

#ifndef __CORE_QUATERNION_H
#include <Math/quaternion.h>
#endif
#ifndef __CORE_VECTOR3_H
#include <Math/vector3.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif

//-------------------------------------------------------------------------- [CLASS]
namespace SharedSoccer
{
namespace Particle
{

//-------------------------------------------------------------------------- [TEMPLATE]
	class ParticleTimeFloat
	{
	public:
		AP_DECLARE_TYPE();

	public:
		ParticleTimeFloat(float val=0.0f):
			m_Value(val)
		{
		}

		float GetValue() const
		{
			return m_Value;
		}

	private:
		float m_Value;
	};

	class ParticleTimeInt
	{
	public:
		AP_DECLARE_TYPE();

	public:
		ParticleTimeInt(float val = 0.0f):
			m_Value(static_cast<int>(val))
		{
		}

		int GetValue() const
		{
			return m_Value;
		}

	private:
		int m_Value;
	};

	class ParticleTimeVector3
	{
	public:
		AP_DECLARE_TYPE();

	public:
		ParticleTimeVector3(const Axiom::Math::Vector3& val = Axiom::Math::Vector3()) :
		   m_Value(val)
		{
		}

		Axiom::Math::Vector3 GetValue() const
		{
			return m_Value;
		}

		void Rotate(const Axiom::Math::Quaternion rot)
		{
			m_Value = m_Value * rot;
		}

	private:
		Axiom::Math::Vector3 m_Value;
	};

	// -------------------------------------------------------------------- [DEV RETURN TYPES]
	class ParticleTimeFloatDev
	{
	public:
		AP_DECLARE_TYPE();

	public:

		  ParticleTimeFloatDev(float deviation = 0.0f, float baseValue = 0.0f) :
			m_Deviation(deviation),
			m_BaseValue(baseValue)
		  {
		  }

		  float GetRandomizedValue() const
		  {
			  float res = ParticleRandomFloat(-m_Deviation, m_Deviation);
			  res += m_BaseValue;
			  return res;
		  }

		  float GetDeviation() const
		  {
			  return m_Deviation;
		  }

		  float GetBaseValue() const
		  {
			  return m_BaseValue;
		  }

	private:
		float m_Deviation;
		float m_BaseValue;
	};

	class ParticleTimeIntDev
	{
	public:
		AP_DECLARE_TYPE();

	public:
		ParticleTimeIntDev(float deviation = 0.0f, float baseValue = 0.0f) :
			m_Deviation(static_cast<int>(deviation)),
			m_BaseValue(static_cast<int>(baseValue))
		{
		}

		int GetRandomizedValue() const
		{
			int ret = ParticleRandomInt(-m_Deviation, m_Deviation);
			ret += m_BaseValue;
			return ret;
		}

		int GetDeviation() const
		{
			return m_Deviation;
		}

		int GetBaseValue() const
		{
			return m_BaseValue;
		}

		int GetMinValue() const
		{
			if(m_Deviation < 0.0f)
			{
				return m_BaseValue + m_Deviation;
			}
			return m_BaseValue - m_Deviation;
		}

		int GetMaxValue() const
		{
			if(m_Deviation < 0.0f)
			{
				return m_BaseValue - m_Deviation;
			}
			return m_BaseValue + m_Deviation;
		}

	private:
		int m_Deviation;
		int m_BaseValue;
	};

	class ParticleTimeVector3Dev
	{
	public:
		AP_DECLARE_TYPE();

	public:
			ParticleTimeVector3Dev(const Axiom::Math::Vector3& deviation = Axiom::Math::Vector3(), const Axiom::Math::Vector3& val = Axiom::Math::Vector3()) :
				m_Deviation(deviation),
			    m_BaseValue(val)
		   {
		   }

		   Axiom::Math::Vector3 GetRandomizedValue() const
		   {
			   Axiom::Math::Vector3 ret;
			   ret.Set(ParticleRandomFloat(-m_Deviation.X(), m_Deviation.X()),
				   ParticleRandomFloat(-m_Deviation.Y(), m_Deviation.Y()),
				   ParticleRandomFloat(-m_Deviation.Z(), m_Deviation.Z()));
			   ret += m_BaseValue;
			   return ret;
		   }

		   Axiom::Math::Vector3 GetDeviation() const
		   {
			   return m_Deviation;
		   }

		   Axiom::Math::Vector3 GetBaseValue() const
		   {
			   return m_BaseValue;
		   }

		   void Rotate(const Axiom::Math::Quaternion rot)
		   {
				m_Deviation = m_Deviation * rot;
				m_BaseValue = m_BaseValue * rot;
		   }

	private:
		Axiom::Math::Vector3 m_Deviation;
		Axiom::Math::Vector3 m_BaseValue;
	};

} // NAMESPACE Particle
} // namespace SharedSoccer
//--------------------------------------------------------------------------
#endif // _PARTICLE_VARIABLE_RETURN_TYPES_H

#pragma once

#ifndef _PARTICLE_H
#define _PARTICLE_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: Particle
// Desc:  Single particle. Contains information about the position
//		velocity, colour, texture, etc of the particle
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_VECTOR3_H
#include <Math/vector3.h>
#endif
#ifndef __CORE_VECTOR4_H
#include <Math/vector4.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		class AP_ALIGN_BEGIN(16) Particle_c
		{
		public:
			Particle_c()
			{ 
				ResetParticle(); 
			}

			PARTICLE_INLINE void ResetParticle() 
			{ 
				mPosition = Axiom::Math::Vector3();
				mVelocity = Axiom::Math::Vector3();
				mTime = 0.0f;
				mDeathTime = 0.0f;
				mScale = 1.0f;
				mTextureIndex = 0.0f;
				mSpawnIndex = 0;
				mNumTextureIndeces = 1;
				mRotation = 0.0f;
				mBlendMode = 0;
			}

			PARTICLE_INLINE bool IsValid() const
			{
				return (mTime < mDeathTime);
			}

			PARTICLE_INLINE float GetSpawnScale() const
			{
				return mPosition.PadData();
			}
			PARTICLE_INLINE void SetSpawnScale(const float f) 
			{
				mPosition.PadData(f);
			}
			PARTICLE_INLINE float GetAlpha() const
			{
				return mVelocity.PadData();
			}
			PARTICLE_INLINE void SetAlpha(const float f) 
			{
				mVelocity.PadData(f);
			}

		public:

			Axiom::Math::Vector3                mPosition;				// 16 Bytes
			Axiom::Math::Vector3                mVelocity;				// 16
			float                               mTime;					// 4
			float                               mDeathTime;				// 4
			float                               mScale;					// 4
			float								mTextureIndex;			// 4
			float								mRotation;				// 4  // Wii only - rotation around z axis for billboarded quads
			unsigned char						mSpawnIndex;			// 1
			unsigned char						mNumTextureIndeces;		// 1
			unsigned char                       mBlendMode;             // 1  // fb blend mode = multiply(0), additive(1), subtractive(2)
			unsigned char                       mPad[1];				// 1  
			float								mPad0;					// 4
			float								mPad1;					// 4

		} AP_ALIGN_END(16) ;
	}
}
//--------------------------------------------------------------------------
#endif // #define _PARTICLE_H

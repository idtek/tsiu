#pragma once

#ifndef _PARTICLE_INCLUDES_H
#define _PARTICLE_INCLUDES_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class:  Particle system Includes
// Desc:  Base includes and definitions for the particle system
//
//-------------------------------------------------------------------------- [Include]
#ifndef _RANDOM_H___
#include "core/random.h"
#endif
#ifndef __CORE_VECTOR3_H
#include "Math/vector3.h"
#endif

//-------------------------------------------------------------------------- [Defines]
#define USE_PARTICLE_INLINE 
#define PARTICLE_INLINE AP_INLINE

#define TEMP_PARTICLE_TIME 0.05f

// MO - on Wii the PARTICLE_HEAP is only 32k in size!
#if CORE_WII
#define PARTICLE_HEAP Axiom::Memory::DEFAULT_HEAP
#else
#define PARTICLE_HEAP Axiom::Memory::PRESENTATION_HEAP
#endif

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		const Axiom::Math::Vector3 c_PARTICLE_DEFAULT_FACING = Axiom::Math::Vector3(1.0f,0.0f,0.0f);
		const int c_MAX_PARTICLE_SYSTEMS = 24;
		const int c_MAX_PARTICLE_TRANSFORM_ELEMENTS = 6;
		const int c_MAX_PARTICLES_PER_SYSTEM = 128;
		const int c_MAX_TEXTURE_INDEX_SPEEDS = 4;
		const int c_MAX_ROTATION_SPEEDS = 4;

		const float c_PLANAR_EPSILON = 1e-3f; ///< How small the dot product must be to declare that a point is in a plane for Within().
		const float P_SQRT2PI = 2.506628274631000502415765284811045253006f;
		const float P_ONEOVERSQRT2PI = (1.0f / P_SQRT2PI);
		const float c_PARTICLE_DEFAULT_FRAME = 0.01666666f;

		//-------------------------------------------------------------------------- [Misc shared function declaration]
		PARTICLE_INLINE void NewBasis(const Axiom::Math::Vector3 &m_DirectionU, const Axiom::Math::Vector3 &m_DirectionV, Axiom::Math::Vector3 &s1, Axiom::Math::Vector3 &s2);
		PARTICLE_INLINE float fsqr(float f); // Float squared
		PARTICLE_INLINE Axiom::Math::Vector3 RandVec(); // Random vector
		PARTICLE_INLINE Axiom::Math::Vector3 RandomVector3(Axiom::Math::Vector3 range = Axiom::Math::Vector3(1.0f,1.0f,1.0f)); // Random vector in range (+/-) provided
		PARTICLE_INLINE float NRandf(float sigma = 1.0f); // Random normalized float
		PARTICLE_INLINE Axiom::Math::Vector3 NRandVec(float sigma); // Random normalized vector

		PARTICLE_INLINE float ParticleRandomFloat( float min, float max );
		PARTICLE_INLINE int ParticleRandomInt( int min, int max );

		//-------------------------------------------------------------------------- [Misc shared function code]
		// Compute the inverse matrix of the plane basis.
		PARTICLE_INLINE void NewBasis(const Axiom::Math::Vector3 &m_DirectionU, const Axiom::Math::Vector3 &m_DirectionV, Axiom::Math::Vector3 &m_S1, Axiom::Math::Vector3 &m_S2)
		{
			Axiom::Math::Vector3 w = m_DirectionU.DeprecatedCrossLeftHanded(m_DirectionV);

			float det = 1.0f / (w.Z()*m_DirectionU.X()*m_DirectionV.Y() - w.Z()*m_DirectionU.Y()*m_DirectionV.X() - m_DirectionU.Z()*w.X()*m_DirectionV.Y() - m_DirectionU.X()*m_DirectionV.Z()*w.Y() + m_DirectionV.Z()*w.X()*m_DirectionU.Y() + m_DirectionU.Z()*m_DirectionV.X()*w.Y());

			m_S1 = Axiom::Math::Vector3((m_DirectionV.Y()*w.Z() - m_DirectionV.Z()*w.Y()), (m_DirectionV.Z()*w.X() - m_DirectionV.X()*w.Z()), (m_DirectionV.X()*w.Y() - m_DirectionV.Y()*w.X()));
			m_S1 *= det;
			m_S2 = Axiom::Math::Vector3((m_DirectionU.Y()*w.Z() - m_DirectionU.Z()*w.Y()), (m_DirectionU.Z()*w.X() - m_DirectionU.X()*w.Z()), (m_DirectionU.X()*w.Y() - m_DirectionU.Y()*w.X()));
			m_S2 *= -det;
		}

		PARTICLE_INLINE float fsqr(float f) {
			return f * f;
		}

		PARTICLE_INLINE Axiom::Math::Vector3 RandVec()
		{
			return Axiom::Math::Vector3(ParticleRandomFloat(0.0f,1.0f), ParticleRandomFloat(0.0f,1.0f), ParticleRandomFloat(0.0f,1.0f));
		}

		PARTICLE_INLINE Axiom::Math::Vector3 RandomVector3(Axiom::Math::Vector3 range)
		{
			return Axiom::Math::Vector3(ParticleRandomFloat(-range[0], range[0]),
				ParticleRandomFloat(-range[1], range[1]),
				ParticleRandomFloat(-range[2], range[2]));
		}


		PARTICLE_INLINE float NRandf(float sigma)
		{
			float x, y, r2;
			do
			{
				x = ParticleRandomFloat(-1.0f,1.0f);
				y = ParticleRandomFloat(-1.0f,1.0f);
				r2 = x*x+y*y;
			}while(r2 > 1.0f || r2 == 0.0f);

			float m = Axiom::Math::SquareRoot(-2.0f * logf(r2)/r2);
			float px = x*m*sigma;
			return px;
		}

		PARTICLE_INLINE Axiom::Math::Vector3 NRandVec(float sigma)
		{
			float x, y, r2;
			do
			{
				x = ParticleRandomFloat(-1.0f,1.0f);
				y = ParticleRandomFloat(-1.0f,1.0f);
				r2 = x*x+y*y;
			}while(r2 > 1.0f || r2 == 0.0f);

			float m = Axiom::Math::SquareRoot(-2.0f * logf(r2)/r2);
			float px = x*m*sigma;
			float py = y*m*sigma;
			return Axiom::Math::Vector3(px, py, NRandf(sigma));
		}

		static Axiom::Random particleGen;

		PARTICLE_INLINE float ParticleRandomFloat( float min, float max )
		{
#if DEBUG_SIM_RAND
			return particleGen.RandFloat( min, max, __FILE__, __LINE__ );
#else
			return particleGen.RandFloat( min, max );
#endif
		}

		PARTICLE_INLINE int ParticleRandomInt( int min, int max )
		{
#if DEBUG_SIM_RAND
			return particleGen.RandInt( min, max, __FILE__, __LINE__ );
#else
			return particleGen.RandInt( min, max );
#endif
		}


	}
}
//--------------------------------------------------------------------------
#endif // _PARTICLE_INCLUDES

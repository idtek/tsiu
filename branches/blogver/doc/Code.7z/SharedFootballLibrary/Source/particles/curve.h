#pragma once

#ifndef _LOOKUP_CURVE_H
#define _LOOKUP_CURVE_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleSystemCurves
// Desc:  
//
//-------------------------------------------------------------------------- [Include]
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _CURVE_INCLUDES_H
#include "particles/curveincludes.h"
#endif
#ifndef __CORE_CRC_H_
#include <core/crc.h>
#endif
#ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#include <collections/list.h>
#endif

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		class LookupCurve : public Axiom::Referenced
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			LookupCurve();
			~LookupCurve();

			PARTICLE_INLINE const Axiom::StripStringCRC&		GetID(void) const;
#if CORE_USERDEBUG == CORE_YES
			void										GenerateCurve(int curveType);
			PARTICLE_INLINE static float				GetCurveValue(int curveType, float t); //this is for creating curves
#endif
			PARTICLE_INLINE float						GetValue(float timeMapped) const;

			PARTICLE_INLINE const float&				ValueAt			(const Axiom::UInt index)		const;
			PARTICLE_INLINE const float&				operator[]		(const Axiom::UInt index)		const;
			PARTICLE_INLINE bool						operator==		(const LookupCurve & rhs)		const;

		private:
			Axiom::Collections::ReflectedList<float>	m_Data;
			Axiom::StripStringCRC						m_ID;
		};
#ifdef USE_PARTICLE_INLINE
	#include "particles/inline/curve.inl"
#endif
	}
}
//--------------------------------------------------------------------------
#endif

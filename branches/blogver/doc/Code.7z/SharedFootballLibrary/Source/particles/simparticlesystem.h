#pragma once

#ifndef _SIM_PARTICLE_SYSTEM_H
#define _SIM_PARTICLE_SYSTEM_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: SimParticleSystem
//
//-------------------------------------------------------------------------- [Include]
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_SYSTEM_DEFINITION_H
#include "particles/particlesystemdefinition.h"
#endif
#ifndef _PARTICLE_ELEMENT_DATA_H
#include "particles/particleelementdata.h"
#endif
#ifndef _PARTICLE_TRANSFORM_DATA_H
#include "particles/particletransformdata.h"
#endif
#ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#include <Collections/list.h>
#endif
#ifndef __AXIOM_ARRAY_H
#include <Collections/array.h>
#endif

//-------------------------------------------------------------------------- [NAMESPACE]
namespace SharedSoccer
{
namespace Particle
{
//-------------------------------------------------------------------------- 
	class SimParticleSystem : public Axiom::Referenced
	{
	public:
		AP_DECLARE_POLYMORPHIC_TYPE();

		SimParticleSystem();
		SimParticleSystem(Axiom::SmartPtr<ParticleSystemDefinition_c> particleDefinition);
		virtual ~SimParticleSystem();

	public:
		// Main Public Control Methods
		void										Update(const SharedSoccer::Presentation::PresentationInput &rInput);
		PARTICLE_INLINE void						UpdateElapsedTime(const float elapsedTime);
		PARTICLE_INLINE void						Reset(bool killParticles);
		PARTICLE_INLINE void						StopSpawningAndFlagForRemoval(bool immediate);

		// Element Updating
		PARTICLE_INLINE void						AddParticleElementData(Axiom::SmartPtr<ParticleElementData> mElement);
		PARTICLE_INLINE void						RemoveParticleElementData(Axiom::SmartPtr<ParticleElementData> mElement, bool removeAllInstancesOfSystem );

		// Misc Public Accessors
		PARTICLE_INLINE const Axiom::StripStringCRC&		GetSystemID() const;
		PARTICLE_INLINE bool						GetSpawning() const;
		PARTICLE_INLINE bool						IsAlive() const;
		PARTICLE_INLINE bool						IsSpawning(float time) const;

		PARTICLE_INLINE char						GetRevisionNumber() const;
		PARTICLE_INLINE float						GetElapsedTime() const;
		PARTICLE_INLINE ParticleSystemDefinition_c*	GetDefinition();
		PARTICLE_INLINE const ParticleTransformData& GetTransformDataAt(const int i) const;
		PARTICLE_INLINE const ParticleTransformDataArray& GetTransformData() const;

#if CORE_USERDEBUG == CORE_YES
		// Method called by reflection or reflected functions
		void										Reset_Reflected();
		void										DebugDraw(const SharedSoccer::Presentation::PresentationInput &rInput, SharedSoccer::Presentation::PresentationOutput *pOutput, const unsigned int channel) const;
#endif

	private:

		void										InitializeElementList();

		// Base control variables for this system
		Axiom::Collections::ReflectedList<Axiom::SmartPtr<ParticleElementData> >
													mElements;
		ParticleTransformDataArray					mTransformData;
		unsigned int								mAddElementIndex;

		Axiom::Byte									mRevisionNumber; // Used for debugging. Will be 0 usually. If someone is using streaker, will increase whenever they reset the system in streaker
		Axiom::SmartPtr<ParticleSystemDefinition_c>	mDefinition;
		Axiom::StripStringCRC							mDefinitionID; 
		Axiom::StripStringCRC							mSystemID;
		float										mElapsedTime;
		float										mInvalidTime;
		bool										mSpawning;

	};

# ifdef USE_PARTICLE_INLINE
#  include "particles/inline/simparticlesystem.inl"
# endif

//--------------------------------------------------------------------------
} // Particle
} // Soccer
#endif // #define _SIM_PARTICLE_SYSTEM_H

#pragma once

#ifndef _PARTICLE_FORCE_H
#define _PARTICLE_FORCE_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleForce
// Desc: Effects the velocity of a particle. Used singly or in groups by the particle
//		 system to update velocity.
//
// If you add a class here, you need to add it into the update method of the particle
// system (particlesystem.cpp)  and to the add force method in ParticleSystemDefinition
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef __CORE_VECTOR3_H
#include <math/vector3.h>
#endif
#ifndef _CLASSEDENUM_H
#include <core/classedenum.h>
#endif
#ifndef __CORE_AUTOPOINTER_H
#include <core/autopointer.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_VARIABLES_H
#include "particles/particlesystemvariables.h"
#endif
#ifndef _PARTICLE_H
#include "particles/particle.h"
#endif
#ifndef _PARTICLE_DOMAIN_H
#include "particles/domain.h"
#endif
#ifndef _PARTICLE_TRANSFORM_DATA_H
#include "particles/particletransformdata.h"
#endif
#ifndef __AXIOM_ARRAY_H
#include <Collections/array.h>
#endif
#ifndef _SIMULATEDPRESENTATION_H_
#include "presentation/simulatedpresentation.h"
#endif


//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		//-------------------------------------------------------------------------- [ParticleForce_c]
		class ParticleForce_c : public Axiom::Referenced
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						ParticleForce_c();
			PARTICLE_INLINE virtual				~ParticleForce_c();

			PARTICLE_INLINE virtual	bool		InitializeForce();

			PARTICLE_INLINE bool				IsActive(float time) const;

			PARTICLE_INLINE bool operator ==(const ParticleForce_c& rhs) const;
			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const = 0;

#if CORE_USERDEBUG == CORE_YES
			virtual void						DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_YELLOW) const = 0;
			virtual float						GetDebugScale(float inputScale = 1.0f) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
            PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif

		protected:
			float								m_Scale;
			float								m_StartTime;
			float								m_EndTime;
			bool								m_Active;
		};



		//-------------------------------------------------------------------------- [DirectionalForce_c]
		class DirectionalForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						DirectionalForce_c();
			PARTICLE_INLINE						DirectionalForce_c(const Axiom::Math::Vector3& dir);
			PARTICLE_INLINE virtual				~DirectionalForce_c();

			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_BLUE) const;
#endif

		private:
			Axiom::Math::Vector3				m_Direction;
		};

		//-------------------------------------------------------------------------- [DirectionalForce_c]
		class RandomDirectionalForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						RandomDirectionalForce_c();
			PARTICLE_INLINE virtual				~RandomDirectionalForce_c();

			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel,  float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_GREEN) const;
#endif

		private:
			Axiom::Math::Vector3				m_Direction;
		};

		//-------------------------------------------------------------------------- [ExplosionForce_c]
		class ExplosionForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						ExplosionForce_c(float radiusSquared = 3.0f, Axiom::Math::Vector3 center = Axiom::Math::Vector3() );
			PARTICLE_INLINE virtual				~ExplosionForce_c();

			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
            /* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_RED) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
			PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif

		private:
			float								m_Speed; // Varies as it moves in distance from the center. Time is radius squared
			float								m_RadiusSquared;
			Axiom::Math::Vector3				m_Position;
		};


		//-------------------------------------------------------------------------- [DampeningForce_c]
		class DampeningForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						DampeningForce_c();
			PARTICLE_INLINE virtual				~DampeningForce_c();

			
			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
            /* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_NAVY) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
			PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif
		private:
			Axiom::Math::Vector3				m_Dampening;	    // Damping constant applied to velocity
			float								m_LowSqr;			// Low cutoff velocities for dampening
		};


		//-------------------------------------------------------------------------- [JetForce_c]
		class JetForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						JetForce_c();
			PARTICLE_INLINE virtual				~JetForce_c();

			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_SKY_BLUE) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
			PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif

		private:
			Axiom::AutoPointer<Domain_c>		m_Area;
			Axiom::Math::Vector3				m_Direction;
		};


		//-------------------------------------------------------------------------- [SpeedBoundForce_c]
		class SpeedBoundForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						SpeedBoundForce_c();
			PARTICLE_INLINE virtual				~SpeedBoundForce_c();

			PARTICLE_INLINE virtual	bool		InitializeForce();
			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
            /* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_VIOLET) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
            PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif

		private:
			float								m_MinSpeed;
			float								m_MaxSpeed;
			float								m_MinSpeedSquared;
			float								m_MaxSpeedSquared;
		};


		//-------------------------------------------------------------------------- [OrbitPointForce_c]
		class OrbitPointForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						OrbitPointForce_c();
			PARTICLE_INLINE virtual				~OrbitPointForce_c();

			PARTICLE_INLINE virtual	bool		InitializeForce();
			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
            /* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_ORANGE) const;
#endif
#if CORE_DATAVALIDATION == CORE_YES
			PARTICLE_INLINE virtual bool		IsValid(bool printDebugInfo) const; // use printDebugInfo on sim thread only
#endif

		private:
			Axiom::Math::Vector3				m_Position;
			float								m_Epsilon;		// Softening parameter
			float								m_MaxRadius;	// Only influence particles within max_radius
			float								m_MaxRadiusSquared;
		};

		//-------------------------------------------------------------------------- [GroundCollideForce_c]
		class GroundCollideForce_c : public ParticleForce_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE						GroundCollideForce_c();
			PARTICLE_INLINE virtual				~GroundCollideForce_c();

			virtual void						ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void					DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale = 1.0f, Gel::Debug::Colors color = Gel::Debug::COLOR_BLUE) const;
#endif

		private:

		};
		
#ifdef USE_PARTICLE_INLINE
	#include "particles/inline/particleforce.inl"
#endif
	}
}
//--------------------------------------------------------------------------
#endif // #define _PARTICLE_FORCE_H

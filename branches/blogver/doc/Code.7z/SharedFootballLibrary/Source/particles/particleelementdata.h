#pragma once

#ifndef _PARTICLE_ELEMENT_DATA_H
#define _PARTICLE_ELEMENT_DATA_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: SimParticleSystem
//
//-------------------------------------------------------------------------- [Include]
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_SYSTEM_DEFINITION_H
#include "particles/particlesystemdefinition.h"
#endif
#ifndef __CORE_CRC_H_
#include <core/crc.h>
#endif
#ifndef _PRESENTATION_TRANSFORMATION_DATA_H_
#include "Presentation/Shared/presentationtransformationdata.h"
#endif

//-------------------------------------------------------------------------- [NAMESPACE]
namespace SharedSoccer
{
namespace Particle
{
//-------------------------------------------------------------------------- 
	class ParticleElementData : public Axiom::Referenced
	{
	public:
		AP_DECLARE_POLYMORPHIC_TYPE();

		ParticleElementData():
			m_SystemID(),
			m_DefinitionID(),
			m_Transform(),
			m_KillParticlesOnExit(false)
		{}
		ParticleElementData(const Axiom::StripStringCRC& systemID, const Axiom::StripStringCRC& definitionID, const Presentation::PresentationTransformationData& transform):
			m_SystemID(systemID),
			m_DefinitionID(definitionID),
			m_Transform(transform),
			m_KillParticlesOnExit(false)
		{}

		virtual ~ParticleElementData(){}

		bool Verify() const
		{
			return (m_SystemID != Axiom::StripStringCRC("SET_THIS") && m_SystemID != Axiom::StripStringCRC());
		}

	public:
		Axiom::StripStringCRC							m_SystemID;
		Axiom::StripStringCRC							m_DefinitionID;
		SharedSoccer::Presentation::PresentationTransformationData m_Transform;
		bool										m_KillParticlesOnExit;
	};

//--------------------------------------------------------------------------
} // Particle
} // Soccer
#endif // #define _SIM_PARTICLE_SYSTEM_H

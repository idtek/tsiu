#pragma once

#ifndef _PARTICLE_VARIABLES_H
#define _PARTICLE_VARIABLES_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
// Class: ParticleSystemVariables
//  Base variables used by the particle system. These are set up to 
//			return random values from a certain base, possibly over a certain
//			time.
//
//-------------------------------------------------------------------------- [INCLUDES]

#ifndef __CORE_VECTOR3_H
#include "Math/vector3.h"
#endif
#ifndef _LOOKUP_CURVE_MANAGER_H
#include "particles/curves.h"
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_VARIABLE_RETURN_TYPES_H
#include "particles/particlesystemvariablereturntypes.h"
#endif

//-------------------------------------------------------------------------- [CLASS]
namespace SharedSoccer
{
namespace Particle
{
	//-------------------------------------------------------------------------- [TEMPLATE]
	template <typename RETURN_TYPE, typename INPUT_TYPE> class ParticleTimeDevVar
	{
	public:
		ParticleTimeDevVar()
		  : m_Time(1.0f),
			m_Curve(0),
			m_DeviationCurve(0)
		{
		}

		ParticleTimeDevVar(INPUT_TYPE start, 
						INPUT_TYPE end, 
						INPUT_TYPE startDeviation, 
						INPUT_TYPE endDeviation,
						float time,
						Axiom::UInt8 curve,
						Axiom::UInt8 deviationCurve) :
			m_Start(start),
			m_End(end),
			m_StartDeviation(startDeviation),
			m_EndDeviation(endDeviation),
			m_Time(time),
			m_Curve(curve),
			m_DeviationCurve(deviationCurve)
		{
		}

	public:
		bool operator==(const ParticleTimeDevVar& rhs) const
		{
			return (m_Start==rhs.m_Start && 
					m_End==rhs.m_End &&
					m_StartDeviation==rhs.m_StartDeviation &&
					m_EndDeviation==rhs.m_EndDeviation &&
					m_Time==rhs.m_Time &&
					m_Curve==rhs.m_Curve &&
					m_DeviationCurve==rhs.m_DeviationCurve);
		}

		RETURN_TYPE GetValue(float time) const
		{
			if(m_Time < 0.00001f)
			{
				return RETURN_TYPE(m_StartDeviation, m_Start);
			}
			if (time>m_Time)
			{
				return GetEndValue();
			}

			return GetValue(time, m_Time);
		}

		RETURN_TYPE GetValue(float time, float range) const
		{
			// Scale time delta so that it falls into curve range

			const LookupCurveManager * curves = LookupCurveManager::GetInstance();
			const LookupCurve * interpCurve = curves->GetCurve(m_Curve);
			const float timeMapped = time / range;
			const float intStart = interpCurve->GetValue(timeMapped);
			const float intEnd = 1.0f - intStart;

			const LookupCurve * devCurve = curves->GetCurve(m_DeviationCurve);
			const float devStr = devCurve->GetValue(timeMapped);
			const float devEnd = 1.0f - devStr;

			return RETURN_TYPE(m_StartDeviation * devStr + m_EndDeviation * devEnd, m_Start * intStart + m_End * intEnd);
		}

		RETURN_TYPE GetEndValue() const
		{
			// Scale time delta so that it falls into curve range
			const LookupCurveManager * curves = LookupCurveManager::GetInstance();
			const LookupCurve * interpCurve = curves->GetCurve(m_Curve);
			const float intEnd = 1.0f - interpCurve->GetValue(1.0f);
			const LookupCurve * devCurve = curves->GetCurve(m_DeviationCurve);
			const float devEnd = 1.0f - devCurve->GetValue(1.0f);

			return RETURN_TYPE(m_EndDeviation * devEnd + m_End * intEnd);
		}

		bool IsAlwaysZero() const
		{
			return (m_Start == 0.0f && m_StartDeviation == 0.0f && (m_Time == 0.0f || (m_End == 0.0f && m_EndDeviation == 0.0f)));
		}

	public:
		INPUT_TYPE m_Start;
		INPUT_TYPE m_End;
		INPUT_TYPE m_StartDeviation;
		INPUT_TYPE m_EndDeviation;
		float m_Time;
		Axiom::UInt8 m_Curve;
		Axiom::UInt8 m_DeviationCurve;

	public:
		AP_DECLARE_TEMPLATE_TYPE_T_T(RETURN_TYPE, INPUT_TYPE);
	};

	//-------------------------------------------------------------------------- [TEMPLATE]
	template <typename RETURN_TYPE, typename INPUT_TYPE> class ParticleTimeVar
	{
	public:
		ParticleTimeVar()
			: m_Time(1.0f),
			m_Curve(0)
		{
		}

		ParticleTimeVar(INPUT_TYPE start, 
						INPUT_TYPE end, 
						float time,
						Axiom::UInt8 curve) :
			m_Start(start),
			m_End(end),
			m_Time(time),
			m_Curve(curve)
		{
		}

	public:
		bool operator==(const ParticleTimeVar& rhs) const
		{
			return (m_Start==rhs.m_Start && 
					m_End==rhs.m_End &&
					m_Time==rhs.m_Time &&
					m_Curve==rhs.m_Curve);
		}

		RETURN_TYPE GetValue(float time) const
		{
			if(m_Time < 0.00001f)
			{
				return RETURN_TYPE(m_Start);
			}
			if (time>m_Time)
			{
				return GetEndValue();
			}

			return GetValue(time, m_Time);
		}

		RETURN_TYPE GetValue(float time, float range) const
		{
			if(range < 0.00001f)
			{
				return RETURN_TYPE(m_Start);
			}
		
			// Scale time delta so that it falls into curve range
			const float timeMapped = time / range;

			const LookupCurve * curve = LookupCurveManager::GetInstance()->GetCurve(m_Curve);
			const float interpolate = curve->GetValue(timeMapped);
			return RETURN_TYPE(m_Start * interpolate + m_End * (1.0f - interpolate));
		}

		RETURN_TYPE GetEndValue() const
		{
			// Scale time delta so that it falls into curve range
			const LookupCurve * curve = LookupCurveManager::GetInstance()->GetCurve(m_Curve);
			const float intEnd = 1.0f - curve->GetValue(1.0f);
			return RETURN_TYPE(m_End * intEnd);
		}

		bool IsAlwaysZero() const
		{
			return (m_Start == 0.0f && (m_Time == 0.0f || m_End == 0.0f));
		}

	public:
		INPUT_TYPE m_Start;
		INPUT_TYPE m_End;
		float m_Time;
		Axiom::UInt8 m_Curve;

	public:
		AP_DECLARE_TEMPLATE_TYPE_T_T(RETURN_TYPE, INPUT_TYPE);
	};
	

	//-------------------------------------------------------------------------- [TEMPLATE]
	template <typename RETURN_TYPE, typename INPUT_TYPE> class ParticleRandomTimeVar : public ParticleTimeVar<RETURN_TYPE, INPUT_TYPE>
	{
	public:
		ParticleRandomTimeVar() : 
			ParticleTimeVar< RETURN_TYPE, INPUT_TYPE >(),
			m_TimeDeviation(0.0f)
		{
		}

		ParticleRandomTimeVar(INPUT_TYPE start, 
								INPUT_TYPE end, 
								float time,
								float timeDeviation,
								Axiom::UInt8 curve)	: 
			ParticleTimeVar< RETURN_TYPE, INPUT_TYPE >(start,end,time,curve),
			m_TimeDeviation(timeDeviation)
		{
		}

	public:
		bool operator==(const ParticleRandomTimeVar& rhs) const
		{
			return (ParticleTimeVar< RETURN_TYPE, INPUT_TYPE >::operator == (rhs) && 
					m_TimeDeviation==rhs.m_TimeDeviation);
		}

		float GetRandomizedTime() const
		{
			return ParticleTimeVar< RETURN_TYPE, INPUT_TYPE >::m_Time + ParticleRandomFloat(-m_TimeDeviation, m_TimeDeviation);
		}

		float GetMaxTime() const
		{
			return ParticleTimeVar< RETURN_TYPE, INPUT_TYPE >::m_Time + m_TimeDeviation;
		}

	public:
		float m_TimeDeviation;

	public:
		AP_DECLARE_TEMPLATE_TYPE_T_T(RETURN_TYPE, INPUT_TYPE);
	};

	//-------------------------------------------------------------------- [Reflection]
#define AP_TEMPLATE_TYPE_PARAM_TEMPLATE	template <typename T, typename U>
#define AP_TEMPLATE_TYPE_PARAM_CLASS ParticleTimeDevVar<T, U>

	AP_TEMPLATE_TYPE_2(ParticleTimeDevVar)
		// Property Reflections
		AP_FIELD("Start", m_Start, "Start Value")
		AP_FIELD("End", m_End, "End Value")
		AP_FIELD("StartDeviation", m_StartDeviation, "Deviation at start of time")
		AP_FIELD("EndDeviation", m_EndDeviation, "Deviation at end of time")
		AP_FIELD("Time", m_Time, "Time For System to Expire")
			AP_FIELD_ATTRIBUTE("Range", "0.0, 32.0")
		AP_FIELD("Curve", m_Curve, "Curve used over time to blend max to min")
			AP_FIELD_ATTRIBUTE("Range", "0, 15")
		AP_FIELD("DeviationCurve", m_DeviationCurve, "Curve used over time to blend start deviation to end deviation")
			AP_FIELD_ATTRIBUTE("Range", "0, 15")
		AP_TEMPLATE_PROXY("SharedFootballLibrary","Particle")
		AP_TYPE_END()

#undef AP_TEMPLATE_TYPE_PARAM_TEMPLATE	
#undef AP_TEMPLATE_TYPE_PARAM_CLASS

		//-------------------------------------------------------------------- [Reflection]
#define AP_TEMPLATE_TYPE_PARAM_TEMPLATE	template <typename T, typename U>
#define AP_TEMPLATE_TYPE_PARAM_CLASS ParticleTimeVar<T, U>

		AP_TEMPLATE_TYPE_2(ParticleTimeVar)
		// Property Reflections
		AP_FIELD("Start", m_Start, "Start Value")
		AP_FIELD("End", m_End, "End Value")
		AP_FIELD("Time", m_Time, "Time For System to Expire")
			AP_FIELD_ATTRIBUTE("Range", "0.0, 32.0")
		AP_FIELD("Curve", m_Curve, "Curve used over time to blend max to min")
			AP_FIELD_ATTRIBUTE("Range", "0, 15")
		AP_TEMPLATE_PROXY("SharedFootballLibrary","Particle")
		AP_TYPE_END()

#undef AP_TEMPLATE_TYPE_PARAM_TEMPLATE	
#undef AP_TEMPLATE_TYPE_PARAM_CLASS

		//-------------------------------------------------------------------- [Reflection]
#define AP_TEMPLATE_TYPE_PARAM_TEMPLATE	template <typename T, typename U>
#define AP_TEMPLATE_TYPE_PARAM_CLASS ParticleRandomTimeVar<T, U>

		AP_TEMPLATE_TYPE_2(ParticleRandomTimeVar)
		AP_BASE_TEMPLATE_TYPE_2(ParticleTimeVar, T, U)

		// Property Reflections
		AP_FIELD("TimeDeviation", m_TimeDeviation, "Time Deviation")
			AP_FIELD_ATTRIBUTE("Range", "0.0, 32.0")
		AP_TEMPLATE_PROXY("SharedFootballLibrary","Particle")
		AP_TYPE_END()

#undef AP_TEMPLATE_TYPE_PARAM_TEMPLATE	
#undef AP_TEMPLATE_TYPE_PARAM_CLASS



	//-------------------------------------------------------------------- [Usefull defines]
	#define PARTICLETIMEDEVFLOATVAR_C ParticleTimeDevVar<ParticleTimeFloatDev, float>
	#define PARTICLETIMEDEVINTVAR_C ParticleTimeDevVar<ParticleTimeIntDev, float>
	#define PARTICLETIMEDEVVECTOR3VAR_C ParticleTimeDevVar<ParticleTimeVector3Dev, Axiom::Math::Vector3>
	#define PARTICLETIMEFLOATVAR_C ParticleTimeVar<ParticleTimeFloat, float>
	#define PARTICLETIMEINTVAR_C ParticleTimeVar<ParticleTimeInt, float>
	#define PARTICLETIMEVECTOR3VAR_C ParticleTimeVar<ParticleTimeVector3, Axiom::Math::Vector3>
	#define PARTICLERANDOMTIMEFLOATVAR_C ParticleRandomTimeVar<ParticleTimeFloat, float>
	#define PARTICLERANDOMTIMEINTVAR_C ParticleRandomTimeVar<ParticleTimeInt, float>
	#define PARTICLERANDOMTIMEVECTOR3VAR_C ParticleRandomTimeVar<ParticleTimeVector3, Axiom::Math::Vector3>

#ifdef USE_PARTICLE_INLINE
	#include "particles/inline/particlesystemvariables.inl"
#endif
	}
}
//--------------------------------------------------------------------------
#endif // _PARTICLE_VARIABLES_H

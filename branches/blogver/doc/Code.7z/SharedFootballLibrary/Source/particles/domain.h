#pragma once

#ifndef _PARTICLE_DOMAIN_H
#define _PARTICLE_DOMAIN_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: All Domain classes
// Desc: Used to generate points in an area.
//		 This code was taken from Domain_c.h in the particle systems api:
//
//						 http://www.ParticleSystems.org
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_VECTOR3_H
#include <Math/vector3.h>
#endif
#ifndef _APMATH_H
#include <Math/apmath.h>
#endif
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef _CLASSEDENUM_H
#include <core/classedenum.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef GEL_DEBUG_H
#include "gel/debug.h"
#endif

//-------------------------------------------------------------------------- [Forward Declaration]
namespace SharedSoccer
{
	namespace Presentation
	{
		class PresentationOutput;
	}
}

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		//-------------------------------------------------------------------------- [Enums]

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef	 INVALIDITEMS
# define INVALIDITEMS 1

		CLASSEDENUM_REFLECTED(PARTICLE_DOMAIN_TYPES_e, \
			CLASSEDENUM_ITEMWITHVALUE(PARTICLE_DOMAIN_INVALID, -1)\
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_POINT) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_LINE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_TRIANGLE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_RECTANGLE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_DISC) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_PLANE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_BOX) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_CYLINDER) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_CONE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_SPHERE) \
			CLASSEDENUM_ITEM(PARTICLE_DOMAIN_BLOB) \
			CLASSEDENUM_ITEM(NUM_PARTICLE_DOMAINS) \
			,PARTICLE_DOMAIN_INVALID)

# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS


		/// A representation of a region of space.
		/// A Domain is a representation of a region of space. For example, the Source action uses a domain to describe the volume in which a particle will be created. A random point within the domain is chosen as the initial position of the particle. The Avoid, Sink and Bounce actions, for example, use domains to describe a volume in space for particles to steer around, die when they enter, or bounce off, respectively.
		/// Domains can be used to describe velocities. Picture the velocity vector as having its tail at the origin and its tip being in the domain. Domains can be used to describe colors in any three-valued color space. They can be used to describe three-valued sizes, such as Length, Width, Height.
		/// Several types of domains can be specified, such as points, lines, planes, discs, spheres, gaussian blobs, etc. Each subclass of the Domain_c class represents a different kind of domain.
		/// All domains support two basic operations. The first is Generate, which returns a random point in the domain.
		/// The second basic operation is Within, which tells whether a given point is within the domain.
		/// The application programmer never calls the Generate or Within functions. The application will use the Domain_c class and its derivatives solely as a way to communicate the domain to the API. The API's action commands will then perform operations on the domain, such as generating particles within it.
		class Domain_c : public Axiom::Referenced
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			virtual bool Within(const Axiom::Math::Vector3 &) const = 0; ///< Returns true if the given point is within the domain.
			virtual Axiom::Math::Vector3 Generate() const = 0; ///< Returns a random point in the domain.
			virtual float Size() const = 0; ///< Returns the size of the domain (length, Area, or volume).
			virtual Domain_c *copy() const = 0; // Returns a pointer to a heap-allocated copy of the derived class

#if CORE_USERDEBUG == CORE_YES
			virtual void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const = 0;
#endif

			PARTICLE_INLINE	Domain_c(PARTICLE_DOMAIN_TYPES_e type);
			PARTICLE_INLINE virtual ~Domain_c();

			PARTICLE_INLINE virtual void Init();

		protected:
			PARTICLE_DOMAIN_TYPES_e			m_Type;
		};

		/// A single point.
		/// Generate always returns this point. Within returns true if the point is exactly equal.
		class DPoint_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DPoint_c();
			PARTICLE_INLINE DPoint_c(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE ~DPoint_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const;
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const;
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE void SetPosition(const Axiom::Math::Vector3 &position);

		private:
			Axiom::Math::Vector3 m_Position;
		};

		/// A line segment.
		/// e0 and e1 are the endpoints of the segment.
		/// Generate returns a random point on this segment. Within returns true for points within epsilon of the line segment.
		class DLine_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DLine_c();
			PARTICLE_INLINE DLine_c(const Axiom::Math::Vector3 &p0, 
									const Axiom::Math::Vector3 &p1);
			PARTICLE_INLINE ~DLine_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const;
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const;
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE void SetStartPosition(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE void SetEndPosition(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			Axiom::Math::Vector3			m_DirectionVector;
			Axiom::Math::Vector3			m_DirectionVectorNormalized;
			float							m_Len;

		};

		/// A Triangle.
		/// p0, p1, and p2 are the vertices of the triangle. The triangle can be used to define an arbitrary geometrical model for particles to bounce off, or generate particles on its surface (and explode them), etc.
		/// Generate returns a random point in the triangle. Within returns true for points within epsilon of the triangle. Currently it is not possible to sink particles that enter/exit a polygonal model. Suggestions?]
		class DTriangle_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DTriangle_c();
			PARTICLE_INLINE DTriangle_c(const Axiom::Math::Vector3 &p0,
										const Axiom::Math::Vector3 &p1,
										const Axiom::Math::Vector3 &p2);
			PARTICLE_INLINE ~DTriangle_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const;
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const;
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE void SetPositionA(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE void SetPositionB(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE void SetPositionC(const Axiom::Math::Vector3 &position);
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			Axiom::Math::Vector3			m_DirectionU;
			Axiom::Math::Vector3			m_DirectionV;
			Axiom::Math::Vector3			m_DirectionUNormalized;
			Axiom::Math::Vector3			m_DirectionVNormalized;
			Axiom::Math::Vector3			m_Normal;
			Axiom::Math::Vector3			m_S1;
			Axiom::Math::Vector3			m_S2;
			float							m_ULen;
			float							m_VLen;
			float							m_D;
			float							m_Area;

		};

		/// Rhombus-shaped planar region.
		/// p0 is a point on the plane. u0 and v0 are (non-parallel) basis vectors in the plane. They don't need to be normal or orthogonal.
		/// Generate returns a random point in the diamond-shaped patch whose corners are o, o+m_DirectionU, o+m_DirectionU+m_DirectionV, and o+m_DirectionV. Within returns true for points within epsilon of the patch.
		class DRectangle_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DRectangle_c();
			PARTICLE_INLINE DRectangle_c(const Axiom::Math::Vector3 &p0,
										 const Axiom::Math::Vector3 &u0,
										 const Axiom::Math::Vector3 &v0);
			PARTICLE_INLINE ~DRectangle_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const;
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const;
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			Axiom::Math::Vector3			m_DirectionU;
			Axiom::Math::Vector3			m_DirectionV;
			Axiom::Math::Vector3			m_DirectionUNormalized;
			Axiom::Math::Vector3			m_DirectionVNormalized;
			Axiom::Math::Vector3			m_Normal;
			Axiom::Math::Vector3			m_S1;
			Axiom::Math::Vector3			m_S2;
			float							m_ULen;
			float							m_VLen;
			float							m_D;
			float							m_Area;
		};

		/// Arbitrarily-oriented disc
		/// The point Center is the center of a disc in the plane with normal Normal. The disc has an OuterRadius. If InnerRadius is greater than 0, the domain is a flat washer, rather than a disc. The normal will get normalized, so it need not already be unit length.
		/// Generate returns a point inside the disc shell. Within returns true for points within epsilon of the disc.
		class DDisc_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DDisc_c();
			PARTICLE_INLINE DDisc_c(const Axiom::Math::Vector3 &Center ,
									const Axiom::Math::Vector3 Normal , 
									const float OuterRadius = 1.0f, 
									const float InnerRadius = 0.0f);
			PARTICLE_INLINE ~DDisc_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const;
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const;
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			Axiom::Math::Vector3			m_DirectionU;
			Axiom::Math::Vector3			m_DirectionV;
			Axiom::Math::Vector3			m_Normal;
			float							m_RadIn;
			float							m_RadOut;
			float							m_RadInSqr;
			float							m_RadOutSqr;
			float							m_Dif;
			float							m_D;
			float							m_Area;
		};

		/// Arbitrarily-oriented plane.
		/// The point p0 is a point on the plane. Normal is the normal vector of the plane. If you have a plane in a,b,c,d form remember that n = [a,b,c] and you can compute a suitable point p0 as p0 = -n*d. The normal will get normalized, so it need not already be unit length.
		/// Generate returns the point p0. Within returns true if the point is in the positive half-space of the plane (in the plane or on the side that Normal points to).
		class DPlane_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DPlane_c();
			PARTICLE_INLINE DPlane_c(const Axiom::Math::Vector3 &p0,
									 const Axiom::Math::Vector3 &Normal);
			PARTICLE_INLINE ~DPlane_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Returns true if the point is in the positive half-space of the plane (in the plane or on the side that Normal points to).
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns the point p0.
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			Axiom::Math::Vector3			m_Normal;
			float							m_D;

		};

		/// Axis-aligned box
		/// e0 and e1 are opposite corners of an axis-aligned box. It doesn't matter which of each coordinate is min and which is max.
		/// Generate returns a random point in this box. Within returns true if the point is in the box.
		/// It is only possible to bounce particles off the outside of the box, not the inside. Likewise, particles can only Avoid the box from the outside. To use the Avoid action inside a box, define the box as six planes.
		class DBox_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DBox_c();
			PARTICLE_INLINE DBox_c(const Axiom::Math::Vector3 &e0,
								   const Axiom::Math::Vector3 &e1);
			PARTICLE_INLINE ~DBox_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Returns true if the point is in the box.
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns a random point in this box.
			PARTICLE_INLINE float Size() const;
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif

			PARTICLE_INLINE Axiom::Math::Vector3 GetCenterPoint() const;
			PARTICLE_INLINE Axiom::Math::Vector3 GetExtents() const;
			
			PARTICLE_INLINE virtual void Init();

		private:
			// m_PositionA is the min corner. m_PositionB is the max corner.
			Axiom::Math::Vector3			m_PositionA;
			Axiom::Math::Vector3			m_PositionB;
			Axiom::Math::Vector3			m_Dif;
			float							m_Volume;

		};

		/// Cylinder
		/// e0 and e1 are the endpoints of the axis of the right cylinder. OuterRadius is the outer radius, and InnerRadius is the inner radius for a cylindrical shell. InnerRadius = 0 for a solid cylinder with no empty space in the middle.
		/// Generate returns a random point in the cylindrical shell. Within returns true if the point is within the cylindrical shell.
		class DCylinder_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DCylinder_c();
			PARTICLE_INLINE DCylinder_c(const Axiom::Math::Vector3 &e0, 
										const Axiom::Math::Vector3 &e1, 
										const float OuterRadius = 1.0f, 
										const float InnerRadius = 0.0f);
			PARTICLE_INLINE ~DCylinder_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Returns true if the point is within the cylindrical shell.
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns a random point in the cylindrical shell.
			PARTICLE_INLINE float Size() const; /// Returns the thick cylindrical shell volume or the thin cylindrical shell Area if OuterRadius==InnerRadius.
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Apex;
			Axiom::Math::Vector3			m_Axis;
			Axiom::Math::Vector3			m_DirectionU;
			Axiom::Math::Vector3			m_DirectionV;
			float							m_RadIn;
			float							m_RadOut;
			float							m_RadInSqr;
			float							m_RadOutSqr;
			float							m_RadDif;
			float							m_AxisLenInvSqr;
			float							m_Volume;
			bool							m_ThinShell;
		};

		///  Cone
		/// e0 is the apex of the cone and e1 is the endpoint of the axis at the cone's base. OuterRadius is the radius of the base of the cone. InnerRadius is the radius of the base of a cone to subtract from the first cone to create a conical shell. This is similar to the cylindrical shell, which can be thought of as a large cylinder with a smaller cylinder subtracted from the middle. Both cones share the same apex and axis, which implies that the thickness of the conical shell tapers to 0 at the apex. InnerRadius = 0 for a solid cone with no empty space in the middle.
		/// Generate returns a random point in the conical shell. Within returns true if the point is within the conical shell.
		class DCone_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DCone_c();
			PARTICLE_INLINE DCone_c(const Axiom::Math::Vector3 &e0, 
									const Axiom::Math::Vector3 &e1, 
									const float OuterRadius = 1.0f, 
									const float InnerRadius = 0.0f);
			PARTICLE_INLINE ~DCone_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Returns true if the point is within the conical shell.
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns a random point in the conical shell.
			PARTICLE_INLINE float Size() const; /// Returns the thick conical shell volume or the thin conical shell Area if OuterRadius==InnerRadius.
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Apex;
			Axiom::Math::Vector3			m_Axis;
			Axiom::Math::Vector3			m_DirectionU;
			Axiom::Math::Vector3			m_DirectionV;
			float							m_RadIn;
			float							m_RadOut;
			float							m_RadInSqr;
			float							m_RadOutSqr;
			float							m_RadDif;
			float							m_AxisLenInvSqr;
			float							m_Volume;
			bool							m_ThinShell;

		};

		/// Sphere
		/// The point Center is the center of the sphere. OuterRadius is the outer radius of the spherical shell and InnerRadius is the inner radius.
		/// Generate returns a random point in the thick shell at a distance between OuterRadius and InnerRadius from point Center. If InnerRadius is 0, then it is the whole sphere. Within returns true if the point lies within the thick shell at a distance between InnerRadius to OuterRadius from point Center.
		class DSphere_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
			
			PARTICLE_INLINE DSphere_c();
			PARTICLE_INLINE DSphere_c(const Axiom::Math::Vector3 &Center, 
									  const float OuterRadius = 1.0f, 
									  const float InnerRadius = 0.0f);
			PARTICLE_INLINE ~DSphere_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Returns true if the point lies within the thick shell.
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns a random point in the thick spherical shell.
			PARTICLE_INLINE float Size() const; /// Returns the thick spherical shell volume or the thin spherical shell Area if OuterRadius==InnerRadius.
			PARTICLE_INLINE Domain_c *copy() const;

			PARTICLE_INLINE float GetRadOutSqr() const;
			PARTICLE_INLINE const Axiom::Math::Vector3& GetPosition() const;



#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			float							m_RadIn;
			float							m_RadOut;
			float							m_RadInSqr;
			float							m_RadOutSqr;
			float							m_RadDif;
			float							m_Volume;
			bool							m_ThinShell;

		};

		/// Gaussian blob
		/// The point Center is the center of a normal probability density of standard deviation StandardDev. The density is radially symmetrical. The blob domain allows for some very natural-looking effects because there is no sharp, artificial-looking boundary at the edge of the domain.
		/// Generate returns a point with normal probability density. Within has a probability of returning true equal to the probability density at the specified point.
		class DBlob_c : public Domain_c
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			PARTICLE_INLINE DBlob_c();
			PARTICLE_INLINE DBlob_c(const Axiom::Math::Vector3 &Center, 
									const float StandardDev);
			PARTICLE_INLINE ~DBlob_c();

			PARTICLE_INLINE bool Within(const Axiom::Math::Vector3 &pos) const; /// Has a probability of returning true equal to the probability density at the specified point.
			PARTICLE_INLINE Axiom::Math::Vector3 Generate() const; /// Returns a point with normal probability density.
			PARTICLE_INLINE float Size() const; /// Returns the probability density integral, which is 1.0.
			PARTICLE_INLINE Domain_c *copy() const;

#if CORE_USERDEBUG == CORE_YES
			/* virtual */ void DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color = Gel::Debug::COLOR_CYAN) const;
#endif
			
			PARTICLE_INLINE virtual void Init();

		private:
			Axiom::Math::Vector3			m_Position;
			float							m_StDev;
			float							m_Scale1;
			float							m_Scale2;
		};



#ifdef USE_PARTICLE_INLINE
#include "particles/inline/domain.inl"
#endif
	}
}
//--------------------------------------------------------------------------

#endif // #define _PARTICLE_DOMAIN_H


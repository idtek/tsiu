#pragma once

#ifndef _PARTICLE_SYSTEM_DEFINITION_H
#define _PARTICLE_SYSTEM_DEFINITION_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleSystemDefinition
// Desc:  Defines a 'type' of particle system. Determines how that system
//		  acts, what forces act on its particles, what textures/data are used.
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_VECTOR3_H
#include <Math/vector3.h>
#endif
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_VARIABLES_H
#include "particles/particlesystemvariables.h"
#endif
#ifndef _PARTICLE_FORCE_H
#include "particles/particleforce.h"
#endif

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{


// particle blend modes (blend, additive, subtractive) ---------------------
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS AP_DECLARE_TYPE();
# undef  INVALIDITEMS
# define INVALIDITEMS 0

		// particle blend modes
		CLASSEDENUM_REFLECTED(PARTICLESYSTEMDEF_BLENDMODE,\
			CLASSEDENUM_ITEM(Blend)\
			CLASSEDENUM_ITEM(Additive)\
			CLASSEDENUM_ITEM(Subtractive),\
			Blend)

# undef  INVALIDITEMS
# define INVALIDITEMS 0
# undef	 REFLECTENUMCLASS
# define REFLECTENUMCLASS

//----------------------------------------------------------------------------

		typedef Axiom::Collections::ReflectedList<float> TextureIndexSpeedList;
		typedef Axiom::Collections::ReflectedList<float> RotationSpeedList;
		typedef Axiom::Collections::ReflectedList <Axiom::SmartPtr<Domain_c> > EmitterList;
		typedef Axiom::Collections::ReflectedList <Axiom::SmartPtr<ParticleForce_c> > ForceList;

		class ParticleSystemDefinition_c : public Axiom::Referenced
		{
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();

			ParticleSystemDefinition_c();
			virtual ~ParticleSystemDefinition_c();

			// Main functions
			PARTICLE_INLINE bool operator ==	(const ParticleSystemDefinition_c& rhs) const;
			bool									Init();
			void									Deallocate();

#if CORE_USERDEBUG == CORE_YES
			void									DebugDraw(const Axiom::Math::Vector3& pos, const float currentTime, const unsigned int channel, SharedSoccer::Presentation::PresentationOutput *pOutput) const;
#endif

			// Accessors to constant data
			PARTICLE_INLINE const Axiom::StripStringCRC&	GetID() const;	
			PARTICLE_INLINE bool					GetContinuesSpawningAfterTimeExpired() const;
			PARTICLE_INLINE const Axiom::StripStringCRC&	GetMaterialName() const;


			// Misc public particle force stuff
			PARTICLE_INLINE Axiom::UInt				GetNumForces() const;
			PARTICLE_INLINE const ParticleForce_c*	GetForce(Axiom::UInt i)	const;

			// Accessors to time based stuff
			PARTICLE_INLINE float					GetEnergy(float time, float deathTime) const;
			PARTICLE_INLINE float					GetScaleModifier(float time) const;
			PARTICLE_INLINE int						GetSpawnTextureIndex(float time) const;
			PARTICLE_INLINE float					GetSpawnRotation(float time) const;
			PARTICLE_INLINE int						GetNumTextureSpeeds() const;
			PARTICLE_INLINE float					GetTextureIndexSpeed(int particleIndex) const;
			PARTICLE_INLINE int						GetNumRotationSpeeds() const;
			PARTICLE_INLINE const RotationSpeedList& GetRotationSpeedList() const;
			PARTICLE_INLINE float					GetRotationSpeed(int particleIndex) const;
			PARTICLE_INLINE unsigned char			GetNumTextureItems() const;
			PARTICLE_INLINE const TextureIndexSpeedList& GetTextureIndexSpeedList() const;
			PARTICLE_INLINE Axiom::uint				GetNumEmitters() const;
			PARTICLE_INLINE float					GetRandomizedLife() const;
			PARTICLE_INLINE float					GetMaximumLife() const;

			PARTICLE_INLINE bool					NumTextureSpeedsIsValid() const;
			PARTICLE_INLINE bool					NumRotationSpeedsIsValid() const;

			// Accessors to randomized data
			PARTICLE_INLINE float					GetRandomizedSpawnRate(float currentTime) const;
			PARTICLE_INLINE float					GetRandomizedSpawnScale(float currentTime) const;
			PARTICLE_INLINE ParticleTimeVector3Dev	GetRandomizedSpawnVelocity(float currentTime) const;
			PARTICLE_INLINE Axiom::Math::Vector3	GetRandomizedSpawnPosition(float currentTime) const;

			// Generate Particle Change from Definition Rules
			PARTICLE_INLINE float					GetRandomizedEnergyDelta(float currentTime) const;

			// Debug functions
			PARTICLE_INLINE bool					SpawnTextureIndexIsValid(float currentTime) const;

			PARTICLE_INLINE unsigned char			GetBlendMode() const;


		private:

			// Constant system variables
			Axiom::StripStringCRC				m_ID;

			// Randomizable variables
			PARTICLETIMEDEVFLOATVAR_C		m_SpawnRate;
			PARTICLETIMEDEVFLOATVAR_C		m_SpawnScale;
			PARTICLETIMEDEVVECTOR3VAR_C		m_SpawnVelocity;
			
			EmitterList						m_Emitters;
			Axiom::StripStringCRC				m_MaterialName;
			PARTICLERANDOMTIMEFLOATVAR_C	m_Energy;
			PARTICLETIMEFLOATVAR_C			m_Scale;
			PARTICLETIMEDEVINTVAR_C			m_SpawnTextureIndex;
			PARTICLETIMEDEVFLOATVAR_C		m_SpawnRotation;
			TextureIndexSpeedList			m_TextureIndexSpeeds;
			RotationSpeedList				m_RotationSpeeds;
			unsigned char					m_NumTextureItems;
			
			ForceList						m_Forces;
			
			PARTICLESYSTEMDEF_BLENDMODE	    m_BlendMode;  // per-particle blend mode (add, subtract, multiply), value set in streaker
		};
#ifdef USE_PARTICLE_INLINE
	#include "particles/inline/particlesystemdefinition.inl"
#endif
	}
}
//--------------------------------------------------------------------------
#endif // #define _PARTICLE_SYSTEM_DEFINITION_H


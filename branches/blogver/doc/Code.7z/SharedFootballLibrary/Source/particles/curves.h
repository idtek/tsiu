#pragma once

#ifndef _LOOKUP_CURVE_MANAGER_H
#define _LOOKUP_CURVE_MANAGER_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleSystemCurves
// Desc:  
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _CURVE_INCLUDES_H
#include "particles/curveincludes.h"
#endif
#ifndef _LOOKUP_CURVE_H
#include "particles/curve.h"
#endif
#ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#include <collections/list.h>
#endif

//-------------------------------------------------------------------------- [Class]
namespace SharedSoccer
{
	namespace Particle
	{
		class LookupCurveManager
		{
		public:
			AP_DECLARE_TYPE();

			LookupCurveManager();
			~LookupCurveManager();

			static						LookupCurveManager*	Init();
			PARTICLE_INLINE static		LookupCurveManager*	GetInstance();
			static						void				Destroy();
#if CORE_USERDEBUG == CORE_YES
			void											GenerateCurves();
#endif
			const LookupCurve*								GetCurve(const Axiom::StripStringCRC& curveID) const;
			PARTICLE_INLINE const LookupCurve*				GetCurve(const Axiom::UInt8 curveIndex) const;

		private:
			static LookupCurveManager*						m_Instance;

			Axiom::Collections::ReflectedList<Axiom::SmartPtr<LookupCurve> > m_Curves;
		};

#ifdef USE_PARTICLE_INLINE
	#include "particles/inline/curves.inl"
#endif
	}
}
//--------------------------------------------------------------------------
#endif

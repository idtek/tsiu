#pragma once

#ifndef _SIM_PARTICLE_MANAGER_H
#define _SIM_PARTICLE_MANAGER_H
//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2008 by Action Pants Inc
//
// Class: SimParticleManager
// Desc:  Main class used to handle all particle systems in the game (singleton)
// Misc:  Kev Rulz!
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#include <collections/list.h>
#endif
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef _PARTICLE_INCLUDES_H
#include "particles/particlesystemincludes.h"
#endif
#ifndef _PARTICLE_SYSTEM_DEFINITION_H
#include "particles/particlesystemdefinition.h"
#endif
#ifndef _PARTICLE_ELEMENT_DATA_H
#include "particles/particleelementdata.h"
#endif

//-------------------------------------------------------------------------- [Class]

//-------------------------------------------------------------------------- [Forwarded Class]
namespace SharedSoccer
{
	namespace Particle
	{
		class SimParticleSystem;
	}
}

//-------------------------------------------------------------------------- NAMESPACE
namespace SharedSoccer
{
namespace Particle
{
//-------------------------------------------------------------------------- CLASS DEFINITION
	class SimParticleManager : public Axiom::Referenced
	{
	public:
		AP_DECLARE_POLYMORPHIC_TYPE();

		SimParticleManager();
		virtual ~SimParticleManager();

	public:
		static void Init();
		static void Destroy();
		static SimParticleManager* GetInstance() { return mMgrInstance; }

	public:
		// System/Controller Handling Functions
		void													AddSystem( Axiom::SmartPtr<Particle::ParticleElementData> );
		void													RemoveSystem( Axiom::SmartPtr<Particle::ParticleElementData>, bool removeAllInstancesOfSystem );
		void													CompletelyRemoveSystem( const Axiom::StripStringCRC& rSystemID, bool obliterateParticles);

		void													Reset();

		// Particle System simulation
		void													Update(const Axiom::TimeAbsolute &rTime, const SharedSoccer::Presentation::PresentationInput &rInput, SharedSoccer::Presentation::PresentationOutput *pOutput, const unsigned int channel);

	protected:
		// Internal functions
		Axiom::SmartPtr<SimParticleSystem>						FindSimParticleSystem(const Axiom::StripStringCRC& systemID);
		Axiom::SmartPtr<ParticleSystemDefinition_c>				FindDefinition(const Axiom::StripStringCRC& id);
		void													InitializeAllDefinitions();

	private:
#if CORE_USERDEBUG == CORE_YES
		// Reflection only functions
		void													AddActiveParticleSystem_Reflection(const char* definitionName, float x, float y, float z, float xRot, float yRot, float zRot);
		void													AddNamedActiveParticleSystem_Reflection(const char* systemName, const char* definitionName, float x, float y, float z, float xRot, float yRot, float zRot);
		void													RemoveNamedActiveParticleSystem_Reflection(const char* systemName, bool obliterateParticles);
		bool													Pause_Reflection();
		bool													Play_Reflection();
		bool													Stop_Reflection();
#endif


		// Member Data
		Axiom::Collections::ReflectedList<Axiom::SmartPtr<SimParticleSystem> >						
																mParticleSystems;
		Axiom::Collections::ReflectedList<Axiom::SmartPtr<ParticleSystemDefinition_c> >	
																mParticleSystemDefinitions;

		bool													mEnabled;
		Axiom::TimeAbsolute										mGameTime;

	private:
		static SimParticleManager*								mMgrInstance;

	};

//--------------------------------------------------------------------------
} // Particle
} // Soccer
#endif // _SIM_PARTICLE_MANAGER_H

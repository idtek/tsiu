//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: Curve Classes
// Desc: 
//
//--------------------------------------------------------------------------
#include "particles/curves.h"
#include "reflection/serialize.h"

//--------------------------------------------------------------------------
namespace SharedSoccer
{
	namespace Particle
	{
		// static instance of particle system curves object ----------------
		LookupCurveManager* LookupCurveManager::m_Instance = NULL;

		// ----------------------------------------------------------------- [Reflection]
		AP_TYPE(LookupCurveManager)
			AP_FIELD("Curves",						m_Curves,		"Curve array")
			AP_COMMAND_USERDEBUG(GenerateCurves,					"Reset all curves to their functional values")
			AP_PROXY("Curves")
		AP_TYPE_END()

		// ----------------------------------------------------------------- [Functions]
		LookupCurveManager::LookupCurveManager()
		{
			m_Curves.Resize(Axiom::Memory::DEFAULT_HEAP, NUMBER_CURVE_TYPES);
			for(int i = START_CURVE_TYPES; i < NUMBER_CURVE_TYPES; i=i+1)
			{
				m_Curves.Add(AP_NEW( Axiom::Memory::DEFAULT_HEAP, LookupCurve() ));
			}
		}

		LookupCurveManager::~LookupCurveManager()
		{
			m_Curves.Clear();
		}

		LookupCurveManager* LookupCurveManager::Init()
		{
			AP_ASSERTMESSAGE(m_Instance == NULL, "LookupCurveManager::Init is being called more than once without deleting! Why?");
			if(m_Instance == NULL)
			{
				m_Instance = AP_NEW( PARTICLE_HEAP, Particle::LookupCurveManager());
				AP_ASSERTMESSAGE(m_Instance != NULL, "Error allocating memory for particle system curves");
				AP::Reflection::Script::Register("LookupCurveManager", AP::Reflection::Instance(m_Instance), "Lookup Curve Manager.");
				AP::Reflection::Deserialize::FromFile("presentation:lookupcurvemanager.rst", m_Instance);
			}
			return m_Instance;
		}

		void LookupCurveManager::Destroy()
		{
			AP_ASSERTMESSAGE(m_Instance != NULL, "Attempting to delete a null particle system instance");
			AP_DELETE(m_Instance);
			m_Instance = NULL;
		}

#if CORE_USERDEBUG == CORE_YES
		void LookupCurveManager::GenerateCurves()
		{
			m_Curves.Clear();
			for(int i = START_CURVE_TYPES; i < NUMBER_CURVE_TYPES; i++)
			{
				m_Curves.Add(AP_NEW( Axiom::Memory::DEFAULT_HEAP, LookupCurve() ));
				m_Curves[i]->GenerateCurve(i);
			}
		}
#endif

		const LookupCurve* LookupCurveManager::GetCurve(const Axiom::StripStringCRC& curveID) const
		{
			for(int i = START_CURVE_TYPES; i < NUMBER_CURVE_TYPES; i++)
			{
				if(m_Curves[i]->GetID() == curveID)
				{
					return m_Curves[i].pVal();
				}
			}

#if CORE_USERDEBUG == CORE_YES
			Axiom::Warn("LookupCurveManager::GetCurve can't find curve '%s'. Using default curve instead", curveID.GetDebugString());
#endif

			return m_Curves[0].pVal();
		}


#ifndef USE_PARTICLE_INLINE
	#include "shape/inline/curves.inl"
#endif
	}
}


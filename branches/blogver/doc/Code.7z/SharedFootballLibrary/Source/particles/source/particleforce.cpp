//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleForce
// Desc: Effects the velocity of a particle. Used singly or in groups by the particle
//		 system to update velocity.
//
//-------------------------------------------------------------------------- [ Includes ]
#ifndef _PARTICLE_FORCE_H
#include "particles/particleforce.h"
#endif
#ifndef  _SIMULATEDPRESENTATION_H_
#include "presentation/simulatedpresentation.h"
#endif
#ifndef  _PRESENTATIONOUTPUT_H_
#include "presentation/presentationoutput.h"
#endif

#define DEBUG_DRAW_MIN_SCALE 0.05f
#define DEBUG_DRAW_MAX_SCALE 1.25f
#define DEBUG_DRAW_SCALE_MODIFIER 2.0f
#define DEBUG_INCREASE_SIZE 0.0015f

//-------------------------------------------------------------------------- [ Code ]
namespace SharedSoccer
{
	namespace Particle
	{

		// ---------------------------------[[Inline Include]]
		#ifndef USE_PARTICLE_INLINE
		#include "particles/inline/particleforce.inl"
		#endif

		// ----------------------------------------------------------------- [ Reflection ]
		AP_TYPE(ParticleForce_c)
			AP_FIELD("Scale",		m_Scale,					"Amount this force is scaled when added to velocity")
			AP_FIELD("StartTime",	m_StartTime,				"Force Start Time")
			AP_FIELD("EndTime",		m_EndTime,					"Force End Time. negative for ignored")
			AP_FIELD("Active",		m_Active,					"Whether force is turned on or not")
			AP_ATTRIBUTE("DefaultValue", "{Scale=1.0,StartTime=0.0,EndTime=-1.0,Active=True}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DirectionalForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Direction",	m_Direction,				"Direction of push force")
			AP_ATTRIBUTE("DefaultValue", "{Direction={X=0.0, Y=0.0, Z=1.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(RandomDirectionalForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Direction",	m_Direction,				"X Y Z Scale applied to random vector")
			AP_ATTRIBUTE("DefaultValue", "{Direction={X=0.25, Y=0.25, Z=0.25}}")
			AP_PROXY("Particle")
		AP_TYPE_END()


		AP_TYPE(ExplosionForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Radius",		m_RadiusSquared,			"Radius squared for the explosion")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 64.0")
			AP_FIELD("Position",	m_Position,					"Position of explosion")
			AP_ATTRIBUTE("DefaultValue", "{Radius=1.0, Position={X=0.0, Y=0.0, Z=0.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DampeningForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Dampening",	m_Dampening,				"Dampening Direction")
			AP_FIELD("LowSpeed",	m_LowSqr,					"Low cutoff (squared)")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 64.0")
			AP_ATTRIBUTE("DefaultValue", "{LowSpeed=0.5, Dampening={X=1.0, Y=1.0, Z=1.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()
 
		AP_TYPE(JetForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Area",		m_Area,						"Area that creates the jet")
			AP_FIELD("Direction",	m_Direction,				"Direction of force")
			AP_ATTRIBUTE("DefaultValue", "{Direction={X=1.0, Y=0.0, Z=0.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(SpeedBoundForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("MinSpeed",	m_MinSpeed,					"Min Speed system is bound to when force is applied")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 64.0")
			AP_FIELD("MaxSpeed",	m_MaxSpeed,					"Max Speed system is bound to when force is applied")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 64.0")
			AP_ATTRIBUTE("DefaultValue", "{MinSpeed=0.25, MaxSpeed=5.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(OrbitPointForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Position",	m_Position,					"Position of orbit point")
			AP_FIELD("Epsilon",		m_Epsilon,					"Epsilon")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 16.0")
			AP_FIELD("MaxRadius",	m_MaxRadius,				"Max Radius of orbit")
				AP_FIELD_ATTRIBUTE("Range", "0.0, 64.0")
			AP_ATTRIBUTE("DefaultValue", "{Position={X=0.0, Y=0.0, Z=0.0}, Epsilon=0.25, MaxRadius=5.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(GroundCollideForce_c)
			AP_BASE_TYPE(ParticleForce_c)
			AP_DEFAULT_CREATE()
			AP_PROXY("Particle")
		AP_TYPE_END()


		// --------------------------------------------------------------------------------------------- [typedefs]
		typedef Axiom::Collections::StaticArray<Axiom::Math::Vector3, c_MAX_PARTICLE_TRANSFORM_ELEMENTS> RotatedTransformArray;

	

		// --------------------------------------------------------------------------------------------- [DirectionalForce_c]
		void DirectionalForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			RotatedTransformArray rotatedScaledDirection;
			const Axiom::Math::Vector3 scaledDirection = m_Direction * m_Scale;

			int i = 0;
			for(;i< c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
			{
				rotatedScaledDirection[i] = scaledDirection * rTransforms[i].m_Rotation;
			}

			for (i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				currentParticle.mVelocity += rotatedScaledDirection[currentParticle.mSpawnIndex];
			}
		}

		// --------------------------------------------------------------------------------------------- [RandomDirectionalForce_c]
		void RandomDirectionalForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			RotatedTransformArray rotatedScaledDirection;
			const Axiom::Math::Vector3 scaledDirection = m_Direction * m_Scale;

			int i = 0;
			for(;i< c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
			{
				rotatedScaledDirection[i] = scaledDirection * rTransforms[i].m_Rotation;
			}

			for (i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				const Axiom::Math::Vector3 vec = RandomVector3(rotatedScaledDirection[currentParticle.mSpawnIndex]);
				currentParticle.mVelocity += vec;
			}
		}


		// --------------------------------------------------------------------------------------------- [ExplosionForce_c]
		void ExplosionForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			RotatedTransformArray positionList;

			int i = 0;
			for(;i< c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
			{
				const ParticleTransformData& currentTransform = rTransforms[i];
				positionList[i] = currentTransform.m_Position + m_Position * currentTransform.m_Rotation;
			}

			for (i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				const Axiom::Math::Vector3 dir = currentParticle.mPosition - positionList[currentParticle.mSpawnIndex];
				const float distanceSquared = dir.SquareMagnitude();
				if(distanceSquared <= m_RadiusSquared)
				{
					currentParticle.mVelocity += dir * (m_RadiusSquared - distanceSquared) / m_RadiusSquared * m_Scale;
				}
			}
		}

		// --------------------------------------------------------------------------------------------- [DampeningForce_c]
		void DampeningForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			const Axiom::Math::Vector3 damp = m_Dampening * m_Scale;

			for (int i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				const float velMag = currentParticle.mVelocity.SquareMagnitude();

				if (velMag >= m_LowSqr)
				{
					currentParticle.mVelocity -= currentParticle.mVelocity * damp;
				}
			}
		}

		// --------------------------------------------------------------------------------------------- [JetForce_c]
		void JetForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			RotatedTransformArray rotatedScaledDirection;
			const Axiom::Math::Vector3 scaledDirection = m_Direction * m_Scale;

			int i = 0;
			for(;i< c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
			{
				rotatedScaledDirection[i] = scaledDirection * rTransforms[i].m_Rotation;
			}

			for (i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];

				// KGF Optimize: Hmm this is probably really expensive
				if(m_Area->Within(currentParticle.mPosition))
				{
					currentParticle.mVelocity += rotatedScaledDirection[currentParticle.mSpawnIndex];
				}
			}
		}



		// --------------------------------------------------------------------------------------------- [SpeedBoundForce_c]
		void SpeedBoundForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			for (int i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				const float magSquared = currentParticle.mVelocity.SquareMagnitude();
				if(magSquared > 0.0f)
				{
					if(magSquared < m_MinSpeed)
					{
						const float mag = Axiom::Math::SquareRoot(magSquared);
						currentParticle.mVelocity *= m_MinSpeed / mag * m_Scale;
					}
					else if(magSquared > m_MaxSpeed)
					{
						const float mag = Axiom::Math::SquareRoot(magSquared);
						currentParticle.mVelocity *= m_MaxSpeed / mag * m_Scale;
					}
				}
			}
		}

		// --------------------------------------------------------------------------------------------- [OrbitPointForce_c]
		void OrbitPointForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			RotatedTransformArray positionList;
			int i = 0;
			for(;i< c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
			{
				const ParticleTransformData& currentTransform = rTransforms[i];
				positionList[i] = currentTransform.m_Position + m_Position * currentTransform.m_Rotation;
			}

			const float cMinDistance = 0.0001;

			for (i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				const Axiom::Math::Vector3 dir = positionList[currentParticle.mSpawnIndex] - currentParticle.mPosition;

				// Distance to gravity well (force drops as 1/r^2, normalize by 1/r)
				// Soften by epsilon to avoid tight encounters to infinity
				const float rSqr = dir.SquareMagnitude();

				// Step velocity with acceleration
				if(rSqr < m_MaxRadiusSquared && rSqr > cMinDistance)
				{
					// KGF Optimize: Hmm Can i get rid of this square root
					currentParticle.mVelocity += dir / (Axiom::Math::SquareRoot(rSqr) * (rSqr + m_Epsilon)) * m_Scale;
				}
			}
		}

		// --------------------------------------------------------------------------------------------- [GroundCollideForce_c]
		void GroundCollideForce_c::ApplyForce(Particle_c* particles, const ParticleTransformDataArray& rTransforms, int particleCount, float time) const
		{
			const Axiom::Math::Vector3 up = Axiom::Math::Vector3(0.0f,0.0f,1.0f);
			
			for (int i=0; i<particleCount; i++)
			{
				Particle_c& currentParticle = particles[i];
				if(currentParticle.mPosition.Z() < 0.0f)
				{
					const float mag = currentParticle.mVelocity.Magnitude();
					const Axiom::Math::Vector3 vel = currentParticle.mVelocity.AsNormal();
					//currentParticle.mVelocity = vel - 2.0f * vel.Dot(up) * up; // proper reflection
					currentParticle.mVelocity = Axiom::Math::Vector3(vel.X(), vel.Y(), vel.Z() - 2.0f * vel.Z()) * mag * m_Scale; // quick way cuz we are using vector 0,0,1
				}
			}
		}
		
		// --------------------------------------------------------------------------------------------- [Debug Draw Functions]
#if CORE_USERDEBUG == CORE_YES
		float ParticleForce_c::GetDebugScale(float scale) const
		{
			// Just vary the scale between two bounds
			float finalScale = m_Scale * DEBUG_DRAW_SCALE_MODIFIER;
			if(finalScale < DEBUG_DRAW_MIN_SCALE) finalScale = DEBUG_DRAW_MIN_SCALE;
			else if(finalScale > DEBUG_DRAW_MAX_SCALE) finalScale = DEBUG_DRAW_MAX_SCALE;
			return finalScale * 0.5f + finalScale * scale;
		}

		void DirectionalForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				pOutput->DrawArrow(position, position + m_Direction * GetDebugScale(scale), color, channel);
			}
		}

		void RandomDirectionalForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				pOutput->DrawArrow(position, position + RandomVector3(m_Direction * m_Scale) * GetDebugScale(scale), color, channel);
				float rad = m_Direction.Magnitude() * m_Scale + DEBUG_INCREASE_SIZE;
				pOutput->DrawSphere(position, rad, color, channel);
			}
		}


		void ExplosionForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				Axiom::Math::Vector3 finalPosition = m_Position + position;
				float finalScale = GetDebugScale(scale);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(1.0f,0.0f,0.0f) * finalScale, color, channel);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(0.0f,1.0f,0.0f) * finalScale, color, channel);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(0.0f,0.0f,1.0f) * finalScale, color, channel);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(-1.0f,0.0f,0.0f) * finalScale, color, channel);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(0.0f,-1.0f,0.0f) * finalScale, color, channel);
				pOutput->DrawArrow(finalPosition, finalPosition + Axiom::Math::Vector3(0.0f,0.0f,-1.0f) * finalScale, color, channel);
				float rad = Axiom::Math::SquareRoot(m_RadiusSquared) + DEBUG_INCREASE_SIZE;
				pOutput->DrawSphere( finalPosition, rad, color, channel );
			}
		}

		void DampeningForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			// Hmm what can I draw here to signify a dampening force
		}

		void JetForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				m_Area->DebugDraw(pOutput, position, channel, Gel::Debug::COLOR_ORANGE);
				pOutput->DrawArrow(position, position + m_Direction * GetDebugScale(scale), color, channel);
			}
		}

		void SpeedBoundForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel,  float scale, Gel::Debug::Colors color ) const
		{
			// Hmm what can I draw here to signify a speed limit?
		}

		void OrbitPointForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel,  float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				pOutput->DrawSphere( position + m_Position, m_MaxRadius + DEBUG_INCREASE_SIZE, color, channel );
			}
		}

		void GroundCollideForce_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, float time, const unsigned int channel, float scale, Gel::Debug::Colors color ) const
		{
			if(IsActive(time))
			{
				pOutput->DrawArrow(position, position + Axiom::Math::Vector3(0.0f,0.0f,1.0f) * GetDebugScale(scale), color, channel);
			}
		}
#endif
	}
}


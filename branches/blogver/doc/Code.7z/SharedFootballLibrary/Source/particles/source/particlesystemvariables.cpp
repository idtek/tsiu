//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleSystemVariables
//  Base variables used by the particle system. These are set up to 
//			return random values from a certain base, possibly over a certain
//			time.
//
//-------------------------------------------------------------------------- [Include]
#ifndef _PARTICLE_VARIABLES_H
#include "particles/particlesystemvariables.h"
#endif

//-------------------------------------------------------------------------- [Code]
namespace SharedSoccer
{
	namespace Particle
	{
#ifndef USE_PARTICLE_INLINE
	#include "particles/inline/particlesystemvariables.inl"
#endif
	}
}


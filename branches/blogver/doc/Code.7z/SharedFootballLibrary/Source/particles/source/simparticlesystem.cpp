//
//
//
#ifndef _SIM_PARTICLE_SYSTEM_H
#include "particles/simparticlesystem.h"
#endif
#ifndef  _PRESENTATIONOUTPUT_H_
#include "presentation/presentationoutput.h"
#endif


//--------------------------------------------------------------------------
using namespace SharedSoccer;
using namespace SharedSoccer::Particle;
using namespace SharedSoccer::Presentation;

# ifndef USE_PARTICLE_INLINE
#  include "particles/inline/simparticlesystem.inl"
# endif

// ------------------------------------------------------------------------- [REFLECTION]
AP_TYPE(SimParticleSystem)
	AP_DEFAULT_CREATE()
	// Property Reflections
	AP_FIELD("Elements",			mElements,						"Contained elements")
	AP_FIELD("DefinitionID",		mDefinitionID,					"Linked Definition ID")
		AP_FIELD_ATTRIBUTE("GuiEditMode", "ReadOnly")
	// Commands
	AP_FIELD_USERDEBUG("RevisionNumber",		mRevisionNumber,				"Change this to kill all particles in the system")
	AP_COMMAND_USERDEBUG(Reset_Reflected,										"Kill all particles, reset time, initialize definition.")
	AP_PROXY("Particle")
AP_TYPE_END()

//--------------------------------------------------------------------------
SimParticleSystem::SimParticleSystem() :
	mElements(),
	mTransformData(),
	mAddElementIndex(0),
	mRevisionNumber(0),
	mDefinition(NULL),
	mDefinitionID(),
	mSystemID(),
	mElapsedTime(0.0f),
	mInvalidTime(0.0f),
	mSpawning(true)
{
	mElements.Resize(PARTICLE_HEAP, c_MAX_PARTICLE_TRANSFORM_ELEMENTS);
	InitializeElementList();
}

SimParticleSystem::SimParticleSystem(Axiom::SmartPtr<ParticleSystemDefinition_c> particleDefinition) :  
	mElements(),
	mTransformData(),
	mAddElementIndex(0),
	mRevisionNumber(0),
	mDefinition(particleDefinition),
	mDefinitionID(),
	mSystemID(),
	mElapsedTime(0.0f),
	mInvalidTime(0.0f),
	mSpawning(true)
{
	AP_ASSERTMESSAGE(mDefinition!=NULL, "Must provide a non null particle definition.");
	mDefinitionID = mDefinition->GetID();
	mElements.Resize(PARTICLE_HEAP, c_MAX_PARTICLE_TRANSFORM_ELEMENTS);
	InitializeElementList();
}

SimParticleSystem::~SimParticleSystem()
{
	mElements.Clear();
}

void SimParticleSystem::InitializeElementList()
{
	mElements.Clear();
	for(int i = 0; i < c_MAX_PARTICLE_TRANSFORM_ELEMENTS; ++i)
	{
		mElements.Add(NULL);
	}
}

//------------------------------------------------------------------

void SimParticleSystem::Update(const PresentationInput &rInput)
{
	AP_SIMPLEASSERTMESSAGE(GetSystemID() != ~0U && mDefinition != NULL, "Error: Uninitialized SimParticleSystem in mParticleSystems list.");

#if CORE_USERDEBUG == CORE_YES
	// Re-init definition (user may have edited things in streaker)
	mDefinition->Init();
#endif

	for(int i = 0; i < c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
	{
		if(mElements[i] != NULL)
		{
			PresentationTransformationData& rTransform = mElements[i]->m_Transform;

			bool needsToUpdate = rTransform.GetUpdatesTransformEveryFrame() || rTransform.GetTransformNeedsToUpdate();
#if CORE_USERDEBUG == CORE_YES
			if(rTransform.GetTransformType() == TRANSFORM_TYPE_e::TRANSFORM_UNLOCKED)
			{
				needsToUpdate |= true;
			}
#endif
			if(needsToUpdate)
			{
				rTransform.SetTransformNeedsToUpdate(false);
				rTransform.GetTranslationAndRotation(rInput, mTransformData[i].m_Position, mTransformData[i].m_Rotation);
			}
			mTransformData[i].m_Active = true;
		}
		else
		{
			mTransformData[i].m_Active = false;
		}
	}
}


//------------------------------------------------------------------
#if CORE_USERDEBUG == CORE_YES
void SimParticleSystem::Reset_Reflected()
{
	AP_ASSERTMESSAGE(mDefinition != NULL, "Particle definition not set on reset for sim particle system.");
	Reset(true);
}

void SimParticleSystem::DebugDraw(const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int channel) const
{
	AP_ASSERT(pOutput != NULL);

	for(int i = 0; i < c_MAX_PARTICLE_TRANSFORM_ELEMENTS; i++)
	{
		if(mElements[i] != NULL)
		{
			Axiom::Math::Vector3 rPosition;
			Axiom::Math::Quaternion rRotation;
			mElements[i]->m_Transform.GetTranslationAndRotation(rInput, rPosition, rRotation);
			mDefinition->DebugDraw(rPosition, mElapsedTime, channel, pOutput);

			pOutput->DrawSphere(rPosition, 0.05f, Gel::Debug::COLOR_YELLOW, channel );
			pOutput->DrawArrow(rPosition, rPosition + c_PARTICLE_DEFAULT_FACING*rRotation, Gel::Debug::COLOR_YELLOW, channel);
		}
	}
}
#endif


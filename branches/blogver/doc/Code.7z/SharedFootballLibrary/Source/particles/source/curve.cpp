//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: Curve Classes
// Desc: 
//
//--------------------------------------------------------------------------
#ifndef __CORE_REFERENCED_H
#include <core/referenced.h>
#endif
#ifndef _LOOKUP_CURVE_H
#include "particles/curve.h"
#endif

//--------------------------------------------------------------------------
namespace SharedSoccer
{
	namespace Particle
	{
		// ----------------------------------------------------------------- [Reflection]
		AP_TYPE(LookupCurve)
			AP_DEFAULT_CREATE()
			AP_FIELD("Data", m_Data, "Curve Data Array")
			AP_FIELD("ID", m_ID, "Identification for this curve")
			AP_PROXY("Curves")
		AP_TYPE_END()

		// ----------------------------------------------------------------- [Functions]
		LookupCurve::LookupCurve() :
			m_Data(),
			m_ID()
		{
		}

		LookupCurve::~LookupCurve()
		{

		}

		// Sets tables containing curves full of the curve data.
		// Custom are just set to a linear curve
#if CORE_USERDEBUG == CORE_YES
		void LookupCurve::GenerateCurve(int curveType)
		{
			for( Axiom::UInt i = 0; i < c_NumberEntriesInCurveArray; i++)
			{
				// Get parameter from 0.0 to 1.0
				const float t = static_cast<float>(i)/static_cast<float>(c_NumberEntriesInCurveArray-1);
				m_Data[i] = GetCurveValue(curveType, t);
			}
		}	
#endif

#ifndef USE_PARTICLE_INLINE
	#include "shape/inline/curve.inl"
#endif
	}
}


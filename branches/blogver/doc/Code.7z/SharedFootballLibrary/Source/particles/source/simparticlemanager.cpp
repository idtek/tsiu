//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: SimParticleManager
// Desc:  Main class used to handle all particle systems in the game (singleton)
//
//-------------------------------------------------------------------------- [INCLUDES]
#ifndef _APMEMORY_H
#include <memory/apmemory.h>
#endif
#ifndef _SCRIPT_H_
#include <reflection/script.h>
#endif
#ifndef  _SIMULATEDPRESENTATION_H_
#include "presentation/simulatedpresentation.h"
#endif
#ifndef _SIM_PARTICLE_MANAGER_H
#include "particles/simparticlemanager.h"
#endif
#ifndef _SIM_PARTICLE_SYSTEM_H
#include "particles/simparticlesystem.h"
#endif
#ifndef AP_SERIALIZE_H
#include "reflection/serialize.h"
#endif
#ifndef  _PRESENTATIONOUTPUT_H_
#include "presentation/presentationoutput.h"
#endif
#include <files/filemanager.h>


//-------------------------------------------------------------------------- [NAMESPACE]
using namespace SharedSoccer;
using namespace SharedSoccer::Particle;
using namespace SharedSoccer::Presentation;

// ------------------------------------------------------------------------- [REFLECTION]
AP_TYPE(SimParticleManager)
	// Property Reflections
	AP_FIELD("Definitions", mParticleSystemDefinitions,		"Particle System Definition List")
	AP_FIELD("ParticleSystems", mParticleSystems,			"Active Particle Systems")
	// Commands
	AP_NAMED_COMMAND_USERDEBUG("AddActiveSystem", AddActiveParticleSystem_Reflection,	"Trigger particle system at provided coordinates, velocity.")
	AP_NAMED_COMMAND_USERDEBUG("AddNamedActiveSystem", AddNamedActiveParticleSystem_Reflection, "Add particle system at provided name, coordinates, velocity.")
	AP_NAMED_COMMAND_USERDEBUG("RemoveNamedActiveSystem", RemoveNamedActiveParticleSystem_Reflection,	"Remove particle system of provided name.")
	AP_NAMED_COMMAND_USERDEBUG("Pause", Pause_Reflection,								"Pause all active particle systems.")
	AP_NAMED_COMMAND_USERDEBUG("Play", Play_Reflection,								"Play all active particle systems.")
	AP_NAMED_COMMAND_USERDEBUG("Stop", Stop_Reflection,								"Stop all active particle systems.")
	AP_COMMAND_USERDEBUG(InitializeAllDefinitions,									"Initialize all active particle definitions")

	AP_PROXY("Particle")
AP_TYPE_END()


// ------------------------------------------------------------------------- 
SimParticleManager* SimParticleManager::mMgrInstance = NULL;

// ------------------------------------------------------------------------- [IMPLEMENTATION]
SimParticleManager::SimParticleManager() 
  : mEnabled(true),
	mGameTime()
{
	mParticleSystems.Resize(PARTICLE_HEAP, c_MAX_PARTICLE_SYSTEMS);
}

SimParticleManager::~SimParticleManager()
{
	mParticleSystems.Clear();
	mParticleSystemDefinitions.Clear();
}

// ------------------------------------------------------------------------- [IMPLEMENTATION]
void SimParticleManager::Init()
{
	if (mMgrInstance!=NULL)
	{
		return;
	}
	
	mMgrInstance = AP_NEW(PARTICLE_HEAP, SimParticleManager);
	AP::Reflection::Script::Register("SimParticleManager", AP::Reflection::Instance(mMgrInstance), "Simulation Particle Manager.");
	mMgrInstance->InitializeAllDefinitions();
}

void SimParticleManager::Destroy()
{
	AP_DELETE(mMgrInstance);
	mMgrInstance = NULL;
	Particle::LookupCurveManager::Destroy();
}

// ------------------------------------------------------------------------- [IMPLEMENTATION]
void SimParticleManager::Update(const Axiom::TimeAbsolute &rTime, const PresentationInput &rInput, PresentationOutput *pOutput, const unsigned int channel)
{
	AP_ASSERT(pOutput!=NULL);

	float deltaTime = 0.0f;

	if (mEnabled)
	{
		const Axiom::Time tDeltaTime = rTime - mGameTime;
		deltaTime = tDeltaTime.AsFloatInSeconds();
		if(deltaTime < 0.0f || deltaTime > c_PARTICLE_DEFAULT_FRAME * 4.0f) // Replay or large drop of frames
		{
			deltaTime = c_PARTICLE_DEFAULT_FRAME;
		}
		mGameTime = rTime;
	}

	for (unsigned int i=0; i<mParticleSystems.Count(); i++)
	{
		if( !mParticleSystems[i]->IsAlive() )
		{
			// Remove empty, dead system
			mParticleSystems.RemoveAt(i);
			i--; // Update index for next iteration
		}
		else
		{
			// Update system
			mParticleSystems[i]->Update(rInput);
			pOutput->ExportParticleData(mParticleSystems[i]->GetSystemID(), 
											mParticleSystems[i]->GetDefinition(),
											mParticleSystems[i]->GetElapsedTime(),
											mParticleSystems[i]->GetTransformData(),
											mParticleSystems[i]->GetRevisionNumber());
			mParticleSystems[i]->UpdateElapsedTime(deltaTime);

#if CORE_USERDEBUG == CORE_YES
			mParticleSystems[i]->DebugDraw(rInput, pOutput, channel);
#endif
		}
	}
}

void SimParticleManager::InitializeAllDefinitions()
{
	AP::Reflection::Deserialize::FromFile("presentation:simparticlemanager.rst", &mParticleSystemDefinitions);

	for(Axiom::UInt i = 0; i < mParticleSystemDefinitions.Count(); ++i)
	{
		mParticleSystemDefinitions[i]->Init();
	}
}

void SimParticleManager::AddSystem( Axiom::SmartPtr<Particle::ParticleElementData> pData )
{
	if(pData == NULL)
	{
		return;
	}

	Axiom::SmartPtr<ParticleSystemDefinition_c> systemDef = FindDefinition(pData->m_DefinitionID);

	if(systemDef == NULL)
	{
#if CORE_USERDEBUG==CORE_YES
		Axiom::ShortString sText("Couldn't find particle system ");
		Axiom::ShortString sParticleDefinitionID(pData->m_DefinitionID.GetDebugString());
		sText += sParticleDefinitionID;
		SimulatedPresentation::GetInstance()->AddDebugText(sText);
#endif
		return;
	}

	// Its possible system is already running and this is a reset
	Axiom::SmartPtr<SimParticleSystem> simParticleSystem = FindSimParticleSystem( pData->m_SystemID );
	if(simParticleSystem == NULL)
	{
		if(mParticleSystems.IsFull())
		{
#if CORE_USERDEBUG==CORE_YES
			Axiom::ShortString sText("No more room. Couldn't add ");
			Axiom::ShortString sParticleDefinitionID(pData->m_DefinitionID.GetDebugString());
			sText += sParticleDefinitionID;
			SimulatedPresentation::GetInstance()->AddDebugText(sText);
#endif
			return;
		}
		SimParticleSystem* newSystem = AP_NEW(PARTICLE_HEAP, SimParticleSystem(systemDef));
		mParticleSystems.Add(newSystem);
		simParticleSystem = mParticleSystems[mParticleSystems.Count() - 1];
	}
	simParticleSystem->AddParticleElementData( pData );
}

void SimParticleManager::RemoveSystem( Axiom::SmartPtr<Particle::ParticleElementData> pData, bool removeAllInstancesOfSystem )
{
	if(pData == NULL)
	{
		return;
	}

	Axiom::SmartPtr<SimParticleSystem> simParticleSystem = FindSimParticleSystem( pData->m_SystemID );
	if(simParticleSystem != NULL)
	{
		simParticleSystem->RemoveParticleElementData(pData, removeAllInstancesOfSystem);
	}
}

void SimParticleManager::CompletelyRemoveSystem( const Axiom::StripStringCRC& rSystemID, bool obliterateParticles )
{
	Axiom::SmartPtr<SimParticleSystem> simParticleSystem = FindSimParticleSystem( rSystemID );
	if(simParticleSystem != NULL)
	{
		simParticleSystem->StopSpawningAndFlagForRemoval(obliterateParticles);
	}
}


void SimParticleManager::Reset()
{
	for(unsigned int i = 0; i < mParticleSystems.Count(); i++)
	{
		mParticleSystems[i]->StopSpawningAndFlagForRemoval(true);
	}
	mEnabled = true;
}

Axiom::SmartPtr<SimParticleSystem> SimParticleManager::FindSimParticleSystem( const Axiom::StripStringCRC& systemID )
{
	for(Axiom::UInt i = 0; i < mParticleSystems.Count(); i++)
	{
		if (mParticleSystems[i]->GetSystemID()==systemID)
		{
			return mParticleSystems[i];
		}
	}
	return NULL;
}

Axiom::SmartPtr<ParticleSystemDefinition_c>	SimParticleManager::FindDefinition(const Axiom::StripStringCRC& id)
{
	for(Axiom::UInt i = 0; i < mParticleSystemDefinitions.Count(); ++i)
	{
		if (mParticleSystemDefinitions[i]->GetID() == id)
		{
			return mParticleSystemDefinitions[i];
		}
	}
	return NULL;
}



// ----------------------------------------------------------- [Reflected Functions]
#if CORE_USERDEBUG == CORE_YES
void SimParticleManager::AddActiveParticleSystem_Reflection(const char* name, float x, float y, float z, float rotX, float rotY, float rotZ)
{
	int id = ParticleRandomInt(0,1000000); // Get random arbitrary id
	char stringVal[64];
	Axiom::StringConvertFromInt(stringVal, array_count(stringVal), id);

	AddNamedActiveParticleSystem_Reflection(stringVal, name, x, y, z, rotX, rotY, rotZ);
}

void SimParticleManager::AddNamedActiveParticleSystem_Reflection(const char* systemName, const char* definitionName, float x, float y, float z, float rotX, float rotY, float rotZ)
{
	Axiom::Math::Vector3 position(x,y,z);
	
	SharedSoccer::Presentation::PresentationTransformationData transform;
	transform.SetTranslation( position );
	transform.SetRotation( rotX, rotY, rotZ );

	Axiom::SmartPtr<ParticleElementData> newElement = Axiom::SmartPtr<ParticleElementData>(AP_NEW(PARTICLE_HEAP, ParticleElementData(Axiom::StripStringCRC(systemName), Axiom::StripStringCRC(definitionName), transform)));
	AddSystem(newElement);
}

void SimParticleManager::RemoveNamedActiveParticleSystem_Reflection(const char* systemName, bool obliterateParticles)
{
	CompletelyRemoveSystem(Axiom::StripStringCRC(systemName), obliterateParticles);
}


bool SimParticleManager::Pause_Reflection()
{
	mEnabled = false;
	return true;
}

bool SimParticleManager::Play_Reflection()
{
	mEnabled = true;
	return true;
}

bool SimParticleManager::Stop_Reflection()
{
	mEnabled = false;
	for(Axiom::UInt i = 0; i < mParticleSystems.Count(); ++i)
	{
		mParticleSystems[i]->Reset(true);
	}
	return true;
}
#endif

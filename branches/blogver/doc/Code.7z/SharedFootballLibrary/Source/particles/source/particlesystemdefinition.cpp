//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: ParticleSystemDefinition
// Desc:  Defines a 'type' of particle system. Determines how that system
//		  acts, what forces act on its particles, what textures/data are used.
//
//-------------------------------------------------------------------------- [Include]
#ifndef __CORE_COLLECTIONS_GENERIC__LIST_H_
#include <collections/list.h>
#endif
#ifndef _PARTICLE_SYSTEM_DEFINITION_H
#include "particles/particlesystemdefinition.h"
#endif
#ifndef _SIMULATEDPRESENTATION_H_
# include "presentation/simulatedpresentation.h"
#endif

//-------------------------------------------------------------------------- [Code]
namespace SharedSoccer
{
	namespace Particle
	{
		AP_TYPE(ParticleSystemDefinition_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("ID",					m_ID,						"ID Number for this definition")
			AP_FIELD("SpawnRate",			m_SpawnRate,				"Emitter Rate")
			AP_FIELD("SpawnScale",			m_SpawnScale,				"Spawn scale (modified by scale modifier)")
			AP_FIELD("SpawnVelocity",		m_SpawnVelocity,			"Emitter Velocity of particles")
			AP_FIELD("Emitters",			m_Emitters,					"Emitters")
				AP_FIELD_ATTRIBUTE("AllowNull", "false")
			AP_FIELD("MaterialName",		m_MaterialName,				"Material Name")
			AP_FIELD("Energy",				m_Energy,					"Energy (alpha) for particle (must be from 0.0 to 1.0)")
			AP_FIELD("Scale",				m_Scale,					"Particle scale modifier over time")
			AP_FIELD("SpawnTextureIndex",	m_SpawnTextureIndex,		"Spawn texture index for particles")
			AP_FIELD("SpawnRotation",		m_SpawnRotation,			"Spawn rotation for particles")
			AP_FIELD("TextureIndexSpeeds",	m_TextureIndexSpeeds,		"Speed that texture index changes at - particles randomly choose if list has several items")
			AP_FIELD("RotationSpeeds",		m_RotationSpeeds,			"Speed that rotation changes at - particles randomly choose if list has several items")
			AP_FIELD("NumTextureItems",		m_NumTextureItems,			"Number of items in texture strip")
				AP_FIELD_ATTRIBUTE("Range", "1.0, 64.0")
			AP_FIELD("Forces",				m_Forces,					"Forces that act on this particle")
				AP_FIELD_ATTRIBUTE("AllowNull", "false")
			AP_FIELD("BlendMode",			m_BlendMode,				"Frame buffer blend mode")
			

			// Functions
			AP_COMMAND(Init,												"Initialize this definition")
			AP_ATTRIBUTE("DefaultValue", "{SpawnRate={Start=10, Time=0}, Scale={Start=1, Time=0}, Energy={Start=1.0, Time=1.0}, NumTextureItems=1, ID={Value=\"SET_THIS\"}, MaterialName={Value=\"fx_particle_SET_THIS\"}}")
			AP_ATTRIBUTE("PrimaryKey", "ID.Value")
			AP_PROXY("Particle")
		AP_TYPE_END()

		// enums
		AP_TYPE(PARTICLESYSTEMDEF_BLENDMODE)
			AP_ENUM()
			AP_PROXY("Presentation")
		AP_TYPE_END()
   		
		ParticleSystemDefinition_c::ParticleSystemDefinition_c():
													m_ID(),
													m_SpawnRate(),
													m_SpawnScale(),
													m_SpawnVelocity(),
													m_Emitters(),
													m_MaterialName(),
													m_Energy(),
													m_Scale(),
													m_SpawnTextureIndex(),
													m_SpawnRotation(),
													m_TextureIndexSpeeds(),
													m_RotationSpeeds(),
													m_NumTextureItems(1),
													m_Forces(),
													m_BlendMode() 												
		{
		}

		ParticleSystemDefinition_c::~ParticleSystemDefinition_c()
		{
			Deallocate();
		}

		void ParticleSystemDefinition_c::Deallocate()
		{
			m_Forces.Clear();
			m_Emitters.Clear();
		}

		bool ParticleSystemDefinition_c::Init()
		{
#if CORE_USERDEBUG == CORE_YES
			const float debugTime = 0.1f;
			if(m_SpawnRate.IsAlwaysZero())
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-System has 0 spawn rate." );
				sSystemName += sMessage;
                SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
            }
			if(m_Emitters.Count() == 0)
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-System has no emitters." );
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
			if(m_Energy.m_Time == 0.0f)
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-Particle lifetime is 0." );
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
			if(m_Energy.IsAlwaysZero())
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-Particles have zero energy." );
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
			if(GetMaximumLife() <= 0.0f)
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-Particles have zero lifetime!" );
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
			if(m_Scale.IsAlwaysZero())
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage( "-Particles have 0 scale." );
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
			if(GetNumTextureItems() <= 0)
			{
				Axiom::ShortString sSystemName(m_ID.GetDebugString());
				Axiom::ShortString sMessage("-num textures must be >=1.");
				sSystemName += sMessage;
				SharedSoccer::Presentation::SimulatedPresentation::GetInstance()->AddDebugText(sSystemName, debugTime);
			}
#endif

			for(Axiom::UInt i = 0; i < m_Forces.Count(); ++i)
			{
				m_Forces[i]->InitializeForce();
			}

			for(Axiom::UInt i = 0; i < m_Emitters.Count(); ++i)
			{
				m_Emitters[i]->Init();
			}
			
			return true;
		}

#if CORE_USERDEBUG == CORE_YES
		void ParticleSystemDefinition_c::DebugDraw(const Axiom::Math::Vector3& pos, const float currentTime, const unsigned int channel, SharedSoccer::Presentation::PresentationOutput *pOutput) const
		{
			AP_ASSERT(pOutput != NULL);

			for(unsigned int i = 0; i < m_Emitters.Count(); i++)
			{
				m_Emitters[i]->DebugDraw(pOutput, pos, channel);
			}

			float scale = 2.0f + (currentTime*2.0f - (Axiom::Math::Floor(currentTime*2.0f)));
			for(unsigned int i = 0; i < m_Forces.Count(); i++)
			{
#if CORE_DATAVALIDATION == CORE_YES
                m_Forces[i]->IsValid(true); // Print debug info if force is invalid
#endif
				if(m_Forces[i]->IsActive(currentTime))
				{
					m_Forces[i]->DebugDraw(pOutput, pos, currentTime, channel, scale);
				}
				else
				{
					m_Forces[i]->DebugDraw(pOutput, pos, currentTime, channel, 2.0f, Gel::Debug::COLOR_GREY);
				}
			}
		}
#endif


#ifndef USE_PARTICLE_INLINE
	#include "particles/inline/particlesystemdefinition.inl"
#endif
	}
}


#include "particles/particleelementdata.h"

//--------------------------------------------------------------------------
using namespace SharedSoccer;
using namespace SharedSoccer::Particle;

// Reflection declaration
AP_TYPE(ParticleElementData)
	AP_DEFAULT_CREATE()
	AP_FIELD("SystemID", m_SystemID, "System Name in the world")
	AP_FIELD("DefinitionID", m_DefinitionID, "ID of the particle definition we use here")
	AP_FIELD("Transform", m_Transform, "System transform")
	AP_FIELD("KillParticlesOnExit", m_KillParticlesOnExit, "Kill Particles on exit")
	AP_PROXY("Presentation")
	AP_ATTRIBUTE("DefaultValue", "{SystemID={Value=\"SET_THIS\"}, DefinitionID={Value=\"Default\"}, KillParticlesOnExit=False}")
AP_TYPE_END()

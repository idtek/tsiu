//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Class: Particle
// Desc:  Single particle. Contains information about the position
//		velocity, colour, texture, etc of the particle
//
//--------------------------------------------------------------------------
#ifndef _PARTICLE_DOMAIN_H
#include "particles/domain.h"
#endif
#ifndef  _PRESENTATIONOUTPUT_H_
#include "presentation/presentationoutput.h"
#endif
#ifndef __CORE_HEADER_CYLINDER_H
#include "shape/cylinder.h"
#endif
#ifndef __CORE_HEADER_BOX_H
#include "shape/box.h"
#endif

#define DEBUG_POINT_SIZE 0.1f
#define DEBUG_MIN_RADIUS 0.025f
#define DEBUG_DISC_HEIGHT 0.125f
#define NUM_DEBUG_SUBDIVISIONS 12
#define DEBUG_PLANE_SCALE 3.0f

//--------------------------------------------------------------------------
namespace SharedSoccer
{
	namespace Particle
	{
		// ----------------------------------------------------------------- Reflection
		AP_TYPE(PARTICLE_DOMAIN_TYPES_e)
			AP_ENUM()
			AP_PROXY("Particle")
		AP_TYPE_END()
 
		AP_TYPE(Domain_c)
			AP_FIELD("Type",			m_Type,				"Type of shape")
				AP_FIELD_ATTRIBUTE("GuiEditMode", "ReadOnly")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DPoint_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Point",				m_Position,			"The point.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_POINT}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DLine_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Point",				m_Position,			"One endpoint of the line")
			AP_FIELD("Extends",				m_DirectionVector,	"Direction and length the line extends")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_LINE, Point={X=0.0, Y=0.0, Z=0.0}, Extends={X=0.0, Y=0.0, Z=1.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DTriangle_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Point",				m_Position,			"The base point.")
			AP_FIELD("DirectionU",			m_DirectionU,		"Direction of a side of the triangle.")
			AP_FIELD("DirectionV",			m_DirectionV,		"Direction of the other sides of the triangle.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_TRIANGLE, Point={X=0.0, Y=0.0, Z=1.0}, DirectionU={X=1.0, Y=0.0, Z=0.0}, DirectionV={X=0.0, Y=1.0, Z=0.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DRectangle_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Point",				m_Position,			"The base point.")
			AP_FIELD("DirectionU",			m_DirectionU,		"Direction of one of the sides of the rectangle.")
			AP_FIELD("DirectionV",			m_DirectionV,		"Direction of one of the sides of the rectangle.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_RECTANGLE, Point={X=0.0, Y=0.0, Z=1.0}, DirectionU={X=1.0, Y=0.0, Z=0.0}, DirectionV={X=0.0, Y=1.0, Z=0.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DDisc_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Center",				m_Position,			"The center point.")
			AP_FIELD("Normal",				m_Normal,			"The normal of the disc.")
			AP_FIELD("RadIn",				m_RadIn,			"The inner radius.")
			AP_FIELD("RadOut",				m_RadOut,			"The outer radius.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_DISC, Center={X=0.0, Y=0.0, Z=0.0}, Normal={X=0.0, Y=0.0, Z=1.0}, RadIn=0.0, RadOut=1.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DPlane_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Center",				m_Position,			"The center point.")
			AP_FIELD("Normal",				m_Normal,			"The normal of the plane.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_PLANE, Center={X=0.0, Y=0.0, Z=0.0}, Normal={X=0.0, Y=0.0, Z=1.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DBox_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("P0",					m_PositionA,		"One corner of the box.")
			AP_FIELD("P1",					m_PositionB,		"One corner of the box.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_BOX, P0={X=0.0, Y=0.0, Z=0.0}, P1={X=1.0, Y=1.0, Z=1.0}}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DCylinder_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Apex",				m_Apex,				"The cylinder's base point (m_Apex).")
			AP_FIELD("Axis",				m_Axis,				"The cylinder's m_Axis.")
			AP_FIELD("RadIn",				m_RadIn,			"The inner radius.")
			AP_FIELD("RadOut",				m_RadOut,			"The outer radius.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_CYLINDER, Apex={X=0.0, Y=0.0, Z=0.0}, Axis={X=0.0, Y=0.0, Z=1.0}, RadIn=0.0, RadOut=1.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DCone_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Apex",				m_Apex,				"The cone's base point (m_Apex).")
			AP_FIELD("Axis",				m_Axis,				"The cone's m_Axis.")
			AP_FIELD("RadIn",				m_RadIn,			"The inner radius.")
			AP_FIELD("RadOut",				m_RadOut,			"The outer radius.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_CONE, Apex={X=0.0, Y=0.0, Z=0.0}, Axis={X=0.0, Y=0.0, Z=1.0}, RadIn=0.0, RadOut=1.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DSphere_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Position",			m_Position,			"The center point.")
			AP_FIELD("RadIn",				m_RadIn,			"The inner radius.")
			AP_FIELD("RadOut",				m_RadOut,			"The outer radius.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_SPHERE, Position={X=0.0, Y=0.0, Z=0.0}, RadIn=0.0, RadOut=1.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

		AP_TYPE(DBlob_c)
			AP_BASE_TYPE(Domain_c)
			AP_DEFAULT_CREATE()
			AP_FIELD("Position",			m_Position,			"The center point.")
			AP_FIELD("StDev",				m_StDev,			"Standard (size) deviation of the blob.")
			AP_ATTRIBUTE("DefaultValue", "{Type=PARTICLE_DOMAIN_BLOB, Position={X=0.0, Y=0.0, Z=0.0}, StDev=1.0}")
			AP_PROXY("Particle")
		AP_TYPE_END()

#if CORE_USERDEBUG == CORE_YES
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DPoint_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			pOutput->DrawSphere( position + m_Position, DEBUG_POINT_SIZE, color, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DLine_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			pOutput->DrawLine( position + m_Position, (position + m_Position + m_DirectionVector), color, channel );
		}

		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DTriangle_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			SharedSoccer::Presentation::LineList list;
			list.Add(position + m_Position);
			list.Add(position + m_Position + m_DirectionU);
			list.Add(position + m_Position + m_DirectionV);
			pOutput->DrawLineList( list, color, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DRectangle_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			SharedSoccer::Presentation::LineList list;
			list.Add(position + m_Position);
			list.Add(position + m_Position + m_DirectionU);
			list.Add(position + m_Position + m_DirectionU + m_DirectionV);
			list.Add(position + m_Position + m_DirectionV);
			pOutput->DrawLineList( list, color, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DDisc_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			Axiom::Math::Vector3 finalPosition = position + m_Position;
			static float x = 0.0f;
			static float y = 0.0f;
			static float z = 1.0f;

			Axiom::Math::Vector3 mod = Axiom::Math::Vector3(x,y,z);
			Axiom::Math::Vector3 normalizedNormal = m_Normal.AsNormal();
			Axiom::Math::Quaternion rot;
			if(normalizedNormal != mod)
			{
				rot = Axiom::Math::CreateQuaternionFromVectors(mod, normalizedNormal);
			}
			
			Axiom::Math::RigidMatrix transf(rot, finalPosition);
			float innerRad = m_RadIn;
			if(innerRad < DEBUG_MIN_RADIUS) innerRad = DEBUG_MIN_RADIUS;
			float outterRad = m_RadOut;
			if(outterRad < DEBUG_MIN_RADIUS) outterRad = DEBUG_MIN_RADIUS;
			SharedSoccer::Shape::Cylinder innerCyl(DEBUG_DISC_HEIGHT, innerRad);
			pOutput->DrawCylinder( transf, innerCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
			SharedSoccer::Shape::Cylinder outterCyl(DEBUG_DISC_HEIGHT, outterRad);
			pOutput->DrawCylinder( transf, outterCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
		}

		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DPlane_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			Axiom::Math::Vector3 up(0.0f,1.0f,0.0f);
			Axiom::Math::Vector3 dir1 = up.Cross(m_Normal);
			Axiom::Math::Vector3 dir2 = m_Normal.Cross(dir1);
			SharedSoccer::Presentation::LineList list;
			list.Add(position + m_Position + dir1 * DEBUG_PLANE_SCALE  );
			list.Add(position + m_Position + dir2 * DEBUG_PLANE_SCALE  );
			list.Add(position + m_Position - dir1 * DEBUG_PLANE_SCALE  );
			list.Add(position + m_Position - dir2 * DEBUG_PLANE_SCALE  );
			pOutput->DrawLineList( list, color, channel );
			pOutput->DrawArrow(m_Position, m_Position+m_Normal, Gel::Debug::COLOR_WHITE, channel);
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DBox_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			Axiom::Math::RigidMatrix transf(Axiom::Math::Quaternion(), position + GetCenterPoint());
			SharedSoccer::Shape::Box box(GetExtents() / 2.0f);
			pOutput->DrawBox(transf, box, color, channel);
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DCylinder_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			Axiom::Math::Vector3 finalPosition = position + m_Apex + m_Axis / 2.0f;
			static float x = 0.0f;
			static float y = 0.0f;
			static float z = 1.0f;

			Axiom::Math::Vector3 mod = Axiom::Math::Vector3(x,y,z);
			Axiom::Math::Vector3 normalizedNormal = m_Axis.AsNormal();
			Axiom::Math::Quaternion rot;
			if(normalizedNormal != mod && normalizedNormal.SquareMagnitude() > Axiom::Math::EPSILON)
			{
				rot = Axiom::Math::CreateQuaternionFromVectors(mod, normalizedNormal);
			}

			Axiom::Math::RigidMatrix transf(rot, finalPosition);
			float innerRad = m_RadIn;
			if(innerRad < DEBUG_MIN_RADIUS) innerRad = DEBUG_MIN_RADIUS;
			float outterRad = m_RadOut;
			if(outterRad < DEBUG_MIN_RADIUS) outterRad = DEBUG_MIN_RADIUS;

			SharedSoccer::Shape::Cylinder innerCyl(m_Axis.Magnitude() / 2.0f, innerRad);
			pOutput->DrawCylinder( transf, innerCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
			SharedSoccer::Shape::Cylinder outterCyl(m_Axis.Magnitude() / 2.0f, outterRad);
			pOutput->DrawCylinder( transf, outterCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DCone_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			Axiom::Math::Vector3 finalPosition = position + m_Apex + m_Axis / 2.0f;
			static float x = 0.0f;
			static float y = 0.0f;
			static float z = 1.0f;

			Axiom::Math::Vector3 mod = Axiom::Math::Vector3(x,y,z);
			Axiom::Math::Vector3 normalizedNormal = m_Axis.AsNormal();
			Axiom::Math::Quaternion rot;
			if(normalizedNormal != mod && normalizedNormal.SquareMagnitude() > Axiom::Math::EPSILON)
			{
				rot = Axiom::Math::CreateQuaternionFromVectors(mod, normalizedNormal);
			}

			Axiom::Math::RigidMatrix transf(rot, finalPosition);
			float innerRad = m_RadIn;
			if(innerRad < DEBUG_MIN_RADIUS) innerRad = DEBUG_MIN_RADIUS;
			float outterRad = m_RadOut;
			if(outterRad < DEBUG_MIN_RADIUS) outterRad = DEBUG_MIN_RADIUS;

			SharedSoccer::Shape::Cylinder innerCyl(m_Axis.Magnitude() / 2.0f, innerRad);
			pOutput->DrawCylinder( transf, innerCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
			SharedSoccer::Shape::Cylinder outterCyl(m_Axis.Magnitude() / 2.0f, outterRad);
			pOutput->DrawCylinder( transf, outterCyl, color, NUM_DEBUG_SUBDIVISIONS, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DSphere_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			float innerRad = m_RadIn;
			if(innerRad < DEBUG_MIN_RADIUS) innerRad = DEBUG_MIN_RADIUS;
			float outterRad = m_RadOut;
			if(outterRad < DEBUG_MIN_RADIUS) outterRad = DEBUG_MIN_RADIUS;

			pOutput->DrawSphere( position + m_Position, innerRad, color, channel );
			pOutput->DrawSphere( position + m_Position, outterRad, color, channel );
		}
		
		// ---------------------------------------------------------------------------------------------- [Point]
		/* virtual */ void DBlob_c::DebugDraw(SharedSoccer::Presentation::PresentationOutput *pOutput, const Axiom::Math::Vector3& position, const unsigned int channel, Gel::Debug::Colors color) const
		{
			float rad = m_StDev * 3.0f; 
			if(rad < DEBUG_MIN_RADIUS)
			{
				rad = DEBUG_MIN_RADIUS;
			}

			pOutput->DrawSphere( position + m_Position, rad, color, channel );
		}
#endif	 // CORE_USERDEBUG == CORE_YES

		
#ifndef USE_PARTICLE_INLINE
	#include "particles/inline/domain.inl"
#endif
	}
}


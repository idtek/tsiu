// SharedFootballLibrary.h - (c) 2008 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------

#ifndef _SHAREDFOOTBALLLIBRARY_H_
#define _SHAREDFOOTBALLLIBRARY_H_

//This _LIBNAME define is required in order to use the AP_PROXY macro for reflecting classes that require a proxy.
#ifdef _LIBNAME
#	error "_LIBNAME is already defined and must only be defined once per library/executable"
#else
#	define _LIBNAME "SharedFootballLibrary"
#endif

// TODO: reference additional headers your program requires here
#include <core/core.h>
#include <collections/list.h>
#include <collections/array.h>
#include <collections/booklet.h>
#include <collections/dictionary.h>
#include <eventsystem/eventman.h>
#include <string/string.h>
#include <kernel/messages.h>
#include <math/rigidmatrix.h>
#include <math/matrix4.h>

using Axiom::Log;
using Axiom::Warn;
using Axiom::Error;

#endif // _SHAREDFOOTBALLLIBRARY_H_

// --------------------------------------------------------------------------------------------------------------------

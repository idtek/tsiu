
#include <UnitTesting.h>
#include <math/vector3.h>
#include <math/vector4.h>
#include <math/matrix4.h>
#include <math/quaternion.h>
#include <math/angle.h>
#include <math/apmath.h>
using namespace Axiom::Math;

static bool	IsEqual (float f1, float f2)
{
	float Epsilon = 0.00002f;
	return (f1 > (f2-Epsilon)) && (f1 <= (f2+Epsilon)); 
}

static bool CheckVector3Epsilon(const Vector3& rv, const Vector3& v, float epsilon)
{
	float rx = rv.X();
	float ry = rv.Y();
	float rz = rv.Z();
	float x = v.X();
	float y = v.Y();
	float z = v.Z();
	bool p1 = Equal(rx,x,epsilon);
	bool p2 = Equal(ry,y,epsilon);
	bool p3 = Equal(rz,z,epsilon);
	return p1 && p2 && p3;
}

BEGIN_UNITTESTGROUP(Math_GenericGroup)
{
	BEGIN_UNITTEST(Vector3RotationTests)
	{
		float yaw = PI/3, pitch = PI/6, roll = PI/2;
		Matrix4 mrot;
		mrot.SetYawPitchRoll (yaw, pitch, roll);
		Vector3 StartVector (0.5, 0.5, 0);

		Vector3 v1 = Rotate (StartVector, yaw, pitch, roll);

		Vector3 v2 = StartVector * mrot;
		UTF_CHECK(Vector3::IsEqual(v1, v2, 0.00001f));

		// testing the other creation routines.
		mrot = 	Matrix4:: RotationZ (yaw);
		Vector3 vz1 = RotateZ (StartVector, yaw);
		Vector3 vz2 = StartVector * mrot;

		UTF_CHECK(CheckVector3Epsilon(vz1, vz2, 1.0f*Axiom::Math::EPSILON));

		mrot = 	Matrix4 :: RotationX (roll);
		Vector3 vx1 = RotateX (StartVector, roll);
		Vector3 vx2 = StartVector * mrot;

		UTF_CHECK(CheckVector3Epsilon(vx1, vx2, 1.0f*Axiom::Math::EPSILON));

		mrot = 	Matrix4 :: RotationY (pitch);
		Vector3 vy1 = RotateY (StartVector, pitch);
		Vector3 vy2 = StartVector * mrot;

		UTF_CHECK(CheckVector3Epsilon(vy1, vy2, 1.0f*Axiom::Math::EPSILON));
	}
	END_UNITTEST

	BEGIN_UNITTEST(AngleClassTests)
	{
		Angle a (PI/4);// these should all be the same value
		Angle b = (PI/4) * 9.0f;
		Angle c = (PI/4) * -7.0f;

		UTF_CHECK(IsEqual (a.AsDegrees(), b.AsDegrees()));
		UTF_CHECK(IsEqual (a.AsDegrees(), c.AsDegrees()));

		Angle TwoPi = PI*2;
		Angle TwoPi2 (PI*2);

		b += TwoPi;
		c += PI*2;

		UTF_CHECK(IsEqual (b.AsDegrees(), c.AsDegrees()));// should be equal
		b -= TwoPi;
		b -= TwoPi;
		UTF_CHECK(IsEqual (b.AsDegrees(), c.AsDegrees()));

		Angle d = a + Angle (PI/3);// these should all be the same value
		Angle e = Angle (PI/3) + a;
		Angle f = Angle (PI/3 + a.AsRadians());

		UTF_CHECK(IsEqual (d.AsDegrees(), e.AsDegrees()));
		UTF_CHECK(IsEqual (e.AsDegrees(), f.AsDegrees()));

		// testing -=
		a = PI/3;
		a -= PI/6;
		UTF_CHECK(a == PI/6);

		a = PI/9;
		a -= PI/18;
		UTF_CHECK(a == PI/18);

		a = PI/3;
		b = a - PI/6;
		UTF_CHECK(a >= b);
		UTF_CHECK(a > b);

		b *= 3; // should PI/2 > a
		UTF_CHECK(a <= b);
		UTF_CHECK(a < b);

		UTF_CHECK(a != b);

	}
	END_UNITTEST
}
END_UNITTESTGROUP(Math_GenericGroup)

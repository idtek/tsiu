// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	array_test.cpp
//!	@brief	gtl_array unit tests
//
//	created:	6:4:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include <unittesting.h>
#include <Collections/set.h>
#include <string/string.h>

using namespace Axiom;
using namespace Axiom::Collections;
typedef ShortString TestString;

TestString 	IntToStringSet (int i)
{
	const int size = 128;
	char buf [size+1];

	StringFormat(buf,size,"%d",i);// don't bother filling the whole thing
	return TestString (buf);
}

struct TestStruct
{
	TestStruct (int i) : mInt(i)
	{
	}

	bool operator== (const TestStruct& ts)
	{
		return mInt == ts.mInt;
	}

	bool operator!= (const TestStruct& ts)
	{
		return mInt != ts.mInt;
	}

	bool operator < (const TestStruct& ts)
	{
		return mInt < ts.mInt;
	}

	int mInt;
};

static TestStruct tsData [] = 
{
	TestStruct(0),
	TestStruct(1),
	TestStruct(2),
	TestStruct(3),
	TestStruct(4),
	TestStruct(5),
	TestStruct(6),
	TestStruct(7),
	TestStruct(8),
	TestStruct(9),
	TestStruct(10),
	TestStruct(11),
	TestStruct(12),
	TestStruct(13),
	TestStruct(14),
	TestStruct(15),
	TestStruct(16),
	TestStruct(17),
	TestStruct(18),
	TestStruct(19),
	TestStruct(20),
	TestStruct(21),
	TestStruct(22),
	TestStruct(23),
	TestStruct(24),
	TestStruct(25),
	TestStruct(26),
	TestStruct(27),
	TestStruct(28),
	TestStruct(29),
	TestStruct(30),
	TestStruct(31),
	TestStruct(32),
	TestStruct(33),
	TestStruct(34),
	TestStruct(35),
	TestStruct(36),
	TestStruct(37),
	TestStruct(38),
	TestStruct(39),
	TestStruct(666),
};

static TestStruct* IntToTestStructSet (int i)
{
	return &tsData[i < 40 ? i : 40];
}

DECLARE_UNITTESTGROUP(SetWithIntegerGroup)
DECLARE_UNITTESTGROUP(SetWithStringGroup)
DECLARE_UNITTESTGROUP(SetWithStructPointerGroup)

BEGIN_UNITTESTGROUP(SetGroup)
{
	RUN_UNITTESTSUBGROUP(SetWithIntegerGroup);
	RUN_UNITTESTSUBGROUP(SetWithStringGroup);
	RUN_UNITTESTSUBGROUP(SetWithStructPointerGroup);
}
END_UNITTESTGROUP(SetGroup)

BEGIN_UNITTESTGROUP(SetWithIntegerGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		IntToTestStructSet (0);
		StaticSet<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticSet<ELEMENT_TYPE, 100> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 100);

		StaticSet<ELEMENT_TYPE, 300> s2;// (10,ELEMENT_CONVERSION(42));
		for (int i=0; i<10; i++)
		{
			s2.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 300);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(s2[i] == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Remove)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(40));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(40));
		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s[40] == ELEMENT_CONVERSION(40));
		s.Remove(40);
		UTF_CHECK(s[40] != ELEMENT_CONVERSION(40));
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(40));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(40));
		for (int i=10; i<50; i++)
		{
			s.Insert (i);
		}

		UTF_CHECK(s[40] == ELEMENT_CONVERSION(40));
		s.Remove(40);
		UTF_CHECK(s[40] != ELEMENT_CONVERSION(40));

		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 50);
		for (int i=10; i<60; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 60);

		for (int i=60; i<70; i++)
		{
			UTF_CHECKASSERT(s.Insert (ELEMENT_CONVERSION (i)));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(40));
		UTF_CHECK (s.IsEmpty () == true);

		s.Insert (1);
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (1)) != s.INVALID_INDEX);// this had better succeed.
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (2)) == s.INVALID_INDEX);// this had better fail

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}

END_UNITTESTGROUP(SetWithIntegerGroup)

//-----------------------------------------------

BEGIN_UNITTESTGROUP(SetWithStringGroup)
{
#define ELEMENT_CONVERSION(x) IntToStringSet((x))
#define ELEMENT_TYPE ShortString 

	BEGIN_UNITTEST(Constructors)
	{
		StaticSet<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticSet<ELEMENT_TYPE, 80> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 80);

		StaticSet<ELEMENT_TYPE, 100> s2;
		for (int i=0; i<10; i++)
		{
			s2.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 100);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(s2[i] == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Remove)
	{
		StaticSet<ELEMENT_TYPE, 50> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (20)));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (20)));
		for (int i=10; i<45; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}

		ELEMENT_TYPE str = s[40];
		// does this seem strange...? consider how strings are sorted.
		UTF_CHECK(s[40] == ELEMENT_CONVERSION(5));
		s.Remove(ELEMENT_CONVERSION (40));
		UTF_CHECK(s[40] != ELEMENT_CONVERSION(5));
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));
		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}

		// does this seem strange...? consider how strings are sorted.
		UTF_CHECK(s[40] == ELEMENT_CONVERSION(45));
		s.Remove(ELEMENT_CONVERSION (40));
		UTF_CHECK(s[40] != ELEMENT_CONVERSION(45));

		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 50);
		for (int i=10; i<60; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 60);

		for (int i=60; i<70; i++)
		{
			UTF_CHECKASSERT(s.Insert (ELEMENT_CONVERSION (i)));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));
		UTF_CHECK (s.IsEmpty () == true);

		s.Insert (ELEMENT_CONVERSION (1));
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (1)) != s.INVALID_INDEX);// this had better succeed.
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (2)) == s.INVALID_INDEX);// this had better fail

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(SetWithStringGroup)

//-----------------------------------------------

BEGIN_UNITTESTGROUP(SetWithStructPointerGroup)
{
#define ELEMENT_CONVERSION(x) IntToTestStructSet((x))
#define ELEMENT_TYPE TestStruct*

	BEGIN_UNITTEST(Constructors)
	{
		StaticSet<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticSet<ELEMENT_TYPE, 70> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 70);

		StaticSet<ELEMENT_TYPE, 45> s2;
		for (int i=0; i<10; i++)
		{
			s2.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 45);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(s2[i] == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Remove)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));
		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s[20] == ELEMENT_CONVERSION(20));
		s.Remove(ELEMENT_CONVERSION (20));
		UTF_CHECKASSERT(s[60]);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));

		for (int i=0; i<10; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));
		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s[35] == ELEMENT_CONVERSION(35));
		s.Remove(ELEMENT_CONVERSION (35));
		UTF_CHECK(s[35] != ELEMENT_CONVERSION(35));
		UTF_CHECKASSERT(s[70]);

		for (int i=10; i<50; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 41);
		for (int i=10; i<60; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 41);

		for (int i=60; i<70; i++)
		{
			s.Insert (ELEMENT_CONVERSION (i));
		}
		UTF_CHECK(s.Count() == 41);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticSet<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Remove(ELEMENT_CONVERSION (40)));
		UTF_CHECK (s.IsEmpty () == true);

		s.Insert (ELEMENT_CONVERSION (1));
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (1)) != s.INVALID_INDEX);// this had better succeed.
		UTF_CHECK (s.Find (ELEMENT_CONVERSION (2)) == s.INVALID_INDEX);// this had better fail

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(SetWithStructPointerGroup)

//-----------------------------------------------

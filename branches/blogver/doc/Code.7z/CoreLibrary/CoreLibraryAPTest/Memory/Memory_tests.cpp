#include <UnitTesting.h>
#include <core/singleton.h>

using namespace Axiom;

struct SmallBlock
{
	enum {FillerSize = 60};
	int Var;
	char ptr [FillerSize];
};
struct MediumBlock
{
	enum {FillerSize = 124};
	int Var;
	char ptr [FillerSize];
};
struct LargeBlock
{
	enum {FillerSize = 252};
	int Var;
	char ptr [FillerSize];
};

BEGIN_UNITTESTGROUP( MemoryTestGroup )
{
#define OneMeg  1024*1024
	//Testing Base case of Singleton Test
	BEGIN_UNITTEST(MemoryAllocationTest)
	{
		char* mem = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [OneMeg]);
		UTF_CHECK(mem != NULL);
		AP_DELETEARRAY(mem);
	}
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryBlockAllocationTest)
	{
		const int AllocationArraySize = 1024;
		
		MediumBlock** memArray = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		for (int i=0; i<AllocationArraySize; i++)
		{
			memArray[i] = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, MediumBlock);
			UTF_CHECK(memArray[i] != NULL);
		}
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(memArray[i]);
		}

		AP_DELETEARRAY(memArray);
	}	
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryAllocationOnEveryHeapTest)
	{
		const int AllocationArraySize = 1024;
		MediumBlock* memArray = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::RESERVED_DEBUG_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::RESERVED_SYSTEMS_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::AI_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::PHYSICS_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::PRESENTATION_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::ONLINE_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::ANIM_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::AUDIO_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::RENDER_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);

		memArray = AP_NEW (Axiom::Memory::INPUTEVENT_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		AP_DELETEARRAY(memArray);
	}	
	END_UNITTEST

	//-----------------------------------

	// this test is to verify that memory aligns well and that deallocated memory refills old holes
	BEGIN_UNITTEST(MemoryAllocationAllignmentTest)
	{
		const int AllocationArraySize = 1024;

		MediumBlock** memArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		for (int i=0; i<AllocationArraySize; i++)
		{
			if (i>0 && i%2==1)// delete the previously allocated block
			{
				AP_DELETE(memArray[i-1]);// delete the previous
				memArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
				memArray[i-1] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);// allocate a new block at the top of the heap
			}
			else
				memArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
		}

		// the result of the above allocations should be something like this
		// +-------------------+
		// 1 0 3 2 5 .....
		// +-------------------+

		// here is where the alignment test takes place. 
		// we verify that every other allocation occurs beyond the previous allocation, and before the following
		for (int i=0; i<AllocationArraySize-1; i++)
		{
			if (i%2 == 0)// every even case
			{
				// prove that all odds come before all evens
				UTF_CHECK (memArray[i+1]<memArray[i]);
			}

			if (i<AllocationArraySize-2)// up until we get close to the end.
			{
				// prove that all n's come before all (n+2)'s
				UTF_CHECK (memArray[i+2]>memArray[i]);
			}
		}
		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(memArray[i]);
		}
		AP_DELETE(memArray);
	}
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryOutsideOfBoundaryTest1)
	{
		const int AllocationArraySize = 1024;

		MediumBlock* memArray = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, MediumBlock[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		for (int i=0; i<AllocationArraySize; i++)
		{
			memArray[i].Var = i;
			Axiom::MemorySet (memArray[i].ptr, 0, MediumBlock::FillerSize);
		}
		for (int i=0; i<AllocationArraySize; i++)
		{
			UTF_CHECK(i == memArray[i].Var);
		}

		memArray[35].ptr[-4] = 1;// should screw up the index
		UTF_CHECK(35 != memArray[35].Var);// if these are equal, there is something wrong with the expected memory allocation

		// now let's mess up the previous item.
		memArray[35].ptr[-5] = 1;// should screw up the char array of the previous item
		UTF_CHECK(0 != memArray[34].ptr[MediumBlock::FillerSize-1]);// check that the last byte is wrong and not 0.

		AP_DELETEARRAY(memArray);
	}
	END_UNITTEST

	//-----------------------------------
/*
	BEGIN_UNITTEST(MemoryOutsideOfBoundaryTest2)
	{
		const int AllocationArraySize = 1024;

		MedBlock** memArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MedBlock*[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		for (int i=0; i<AllocationArraySize; i++)
		{
			memArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MedBlock);
		}
		for (int i=0; i<AllocationArraySize; i++)
		{
			memArray[i]->Var = i;
			memset (memArray[i]->ptr, 0xaa, MedBlock::FillerSize);
		}
		for (int i=0; i<AllocationArraySize; i++)
		{
			UTF_CHECK(i == memArray[i]->Var);
		}

		memArray[35]->ptr[-4] = 1;// should screw up the index
		UTF_CHECK(35 != memArray[35]->Var);// if these are equal, there is something wrong with the expected memory allocation
		memArray[70]->ptr[-4] = 1;// should screw up the index
		UTF_CHECK(70 != memArray[70]->Var);// if these are equal, there is something wrong with the expected memory allocation
		memArray[135]->ptr[-4] = 1;// should screw up the index
		UTF_CHECK(135 != memArray[135]->Var);// if these are equal, there is something wrong with the expected memory allocation

		// now let's mess up the previous item.
		memArray[35]->ptr[-5] = 1;// should screw up the char array of the previous item
		UTF_CHECK(0 != memArray[34]->ptr[MedBlock::FillerSize-1]);// check that the last byte is wrong and not 0.
		memArray[70]->ptr[-5] = 1;// should screw up the char array of the previous item
		UTF_CHECK(0 != memArray[69]->ptr[MedBlock::FillerSize-1]);// check that the last byte is wrong and not 0.
		memArray[135]->ptr[-5] = 1;// should screw up the char array of the previous item
		UTF_CHECK(0 != memArray[134]->ptr[MedBlock::FillerSize-1]);// check that the last byte is wrong and not 0.

		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(memArray[i]);
		}
		AP_DELETE(memArray);
	}
	END_UNITTEST
*/
	//-----------------------------------

	BEGIN_UNITTEST(MemoryInsertAndDeleteInPlaceBasicFragmentationTest)
	{
		const int AllocationArraySize = 1024;

		MediumBlock** memArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(memArray != NULL);
		for (int i=0; i<AllocationArraySize; i++)
		{
			if (i>0)// delete the previously allocated block, and verify that the new memory goes into the same place
			{
				memArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
				AP_DELETE(memArray[i-1]);// delete the previous				
				memArray[i-1] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);// allocate a new block at the top of the heap		

				UTF_CHECK (memArray[i-1] < memArray[i]);
			}
			else
				memArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
		}
		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(memArray[i]);
		}
		AP_DELETE(memArray);
	}
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryVaryingSizesFragmentationTest)
	{
		const int AllocationArraySize = 1024;

		SmallBlock** smallArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock*[AllocationArraySize]);
		UTF_CHECK(smallArray != NULL);

		MediumBlock** mediumArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(mediumArray != NULL);

		LargeBlock** largeArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock*[AllocationArraySize]);
		UTF_CHECK(largeArray != NULL);

		for (int i=0; i<AllocationArraySize; i++)
		{
			// memory should not fragment here.
			if (i>0)
			{
				AP_DELETE(smallArray[i-1]);// delete the previous
				AP_DELETE(mediumArray[i-1]);
				smallArray[i-1] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);// reallocate... should go into the same spots
				mediumArray[i-1] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
			}
			smallArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);
			mediumArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
			largeArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock);
		}

		// here we check the level of fragmentation
		for (int i=0; i<AllocationArraySize-1; i++)
		{
			UTF_CHECK (smallArray[i] < smallArray[i+1]);
			UTF_CHECK (mediumArray[i] < mediumArray[i+1]);
			UTF_CHECK (largeArray[i] < largeArray[i+1]);

			UTF_CHECK ((void*)(smallArray[i]) < (void*)(largeArray[i+1]));
			UTF_CHECK ((void*)(mediumArray[i]) < (void*)(largeArray[i+1]));
		}

		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(smallArray[i]);
			AP_DELETE(mediumArray[i]);
			AP_DELETE(largeArray[i]);
		}
		AP_DELETE(smallArray);
		AP_DELETE(mediumArray);
		AP_DELETE(largeArray);
	}
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryVaryingSizesFragmentationTest2)
	{
		const int AllocationArraySize = 512;

		SmallBlock** smallArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock*[AllocationArraySize]);
		UTF_CHECK(smallArray != NULL);

		MediumBlock** mediumArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(mediumArray != NULL);

		LargeBlock** largeArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock*[AllocationArraySize]);
		UTF_CHECK(largeArray != NULL);

		for (int i=0; i<AllocationArraySize; i++)
		{
			smallArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);
			mediumArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
			largeArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock);
		}

		// delete the smaller items in the middle
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(smallArray[i]);
			AP_DELETE(mediumArray[i]);
		}

		for (int i=0; i<AllocationArraySize; i++)
		{
			// reallocate them in the opposite order (medium first)
			mediumArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
			smallArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);
		}

		// here we check the level of fragmentation
		for (int i=0; i<AllocationArraySize-1; i++)
		{
			UTF_CHECK (smallArray[i] < smallArray[i+1]);
			UTF_CHECK (mediumArray[i] < mediumArray[i+1]);
			UTF_CHECK (largeArray[i] < largeArray[i+1]);

			UTF_CHECK ((void*)(smallArray[i]) < (void*)(largeArray[i+1]));
			UTF_CHECK ((void*)(mediumArray[i]) < (void*)(largeArray[i+1]));


			// memory is being allocated such that small blocks should appear first, regardless.
			UTF_CHECK ((void*)(mediumArray[i]) > (void*)(smallArray[i]) );
		}

		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(smallArray[i]);
			AP_DELETE(mediumArray[i]);
			AP_DELETE(largeArray[i]);
		}
		AP_DELETE(smallArray);
		AP_DELETE(mediumArray);
		AP_DELETE(largeArray);
	}
	END_UNITTEST

	//-----------------------------------

	BEGIN_UNITTEST(MemoryVaryingSizesFragmentationTest3)
	{
		const int AllocationArraySize = 512;

		SmallBlock** smallArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock*[AllocationArraySize]);
		UTF_CHECK(smallArray != NULL);

		MediumBlock** mediumArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock*[AllocationArraySize]);
		UTF_CHECK(mediumArray != NULL);

		LargeBlock** largeArray = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock*[AllocationArraySize]);
		UTF_CHECK(largeArray != NULL);

		for (int i=0; i<AllocationArraySize; i++)
		{
			smallArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);
			mediumArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
			largeArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, LargeBlock);
		}

		// delete the smaller items in the middle
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(smallArray[i]);
			AP_DELETE(mediumArray[i]);
		}

		for (int i=0; i<AllocationArraySize; i++)
		{
			// reallocate where they fit
			mediumArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, MediumBlock);
		}
		for (int i=0; i<AllocationArraySize; i++)
		{
			// reallocate where they fit
			smallArray[i] = AP_NEW (Axiom::Memory::DEFAULT_HEAP, SmallBlock);
		}

		// here we check the level of fragmentation
		for (int i=0; i<AllocationArraySize-1; i++)
		{
			UTF_CHECK (smallArray[i] < smallArray[i+1]);
			UTF_CHECK (mediumArray[i] < mediumArray[i+1]);
			UTF_CHECK (largeArray[i] < largeArray[i+1]);

			UTF_CHECK ((void*)(smallArray[i]) < (void*)(largeArray[i+1]));
			UTF_CHECK ((void*)(mediumArray[i]) < (void*)(largeArray[i+1]));


			// memory is being allocated such that small blocks should appear first, regardless.
			UTF_CHECK ((void*)(mediumArray[i]) > (void*)(smallArray[i]) );
		}

		// cleanup
		for (int i=0; i<AllocationArraySize; i++)
		{
			AP_DELETE(smallArray[i]);
			AP_DELETE(mediumArray[i]);
			AP_DELETE(largeArray[i]);
		}
		AP_DELETE(smallArray);
		AP_DELETE(mediumArray);
		AP_DELETE(largeArray);
	}
	END_UNITTEST
}
END_UNITTESTGROUP( MemoryTestGroup )

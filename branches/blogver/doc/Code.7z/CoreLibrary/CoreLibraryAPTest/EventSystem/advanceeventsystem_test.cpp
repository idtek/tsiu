//==========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
//!	@file 	eventsystem_tests.cpp
//!	@brief	unit tests for the eventsystem class
//
//! The purpose of this test is to proof the correctness of the event system particularily
//  1. Directed Event Msg Communication
//  2. Broadcast event registeration
//  2. Broadcast event sending and recieving works!
//
//	created:	7:4:2007
//	author:		dhoac
//
//	Copyright (c) 2007 by Action Pants Inc
//==========================================================================
#include <UnitTesting.h>
#include "eventsystem/eventmsgbox.h"
#include "eventsystem/eventman.h"
#include "eventsystem/eventmsgdictionary.h"
#include "core/random.h"

using namespace Axiom;

class EventA:public EventMsg
{	
public:

	EVENT_MSG_GUID(EventA);
	
	EventA():EventMsg(EVENT_GUID) {mValue = 0; }
	EventA(int val):EventMsg(EVENT_GUID){mValue = val;}

	int mValue;
};

class EventB:public EventMsg
{
public:
	EVENT_MSG_GUID(EventB);
	
	EventB():EventMsg(EVENT_GUID) {mValue = 0; }
	EventB(int val):EventMsg(EVENT_GUID){mValue = val;}

	int mValue;
};

class BroadEventC:public EventMsg
{
public:
	EVENT_MSG_GUID(BroadEventC);
	
	BroadEventC():EventMsg(EVENT_GUID) {mValue = 0; }
	BroadEventC(int val):EventMsg(EVENT_GUID){mValue = val;}

	int mValue;
};

// Ensure that ListenerA only hears directed eventA and nothing else
void UpdateListenA(EventMsgBoxHandle handle, EventMsgBoxId destMsgId)
{
	int numEvents = handle->GetNumEvents();
	UTF_CHECK(numEvents <= 1);

	for(int i=0;i<numEvents;i++)
	{
		const EventMsg* pEventMsg = handle->GetEvent(i);
		
		// Should not get a broadcast events..  only msg from clientB
		UTF_CHECK(pEventMsg->GetGuidID() !=BroadEventC::EVENT_GUID);
		UTF_CHECK(pEventMsg->GetSenderId() !=  BROAD_CAST_MSG_ID);
		UTF_CHECK(pEventMsg->GetSenderId() ==  destMsgId);
		UTF_CHECK(pEventMsg->GetGuidID() == EventA::EVENT_GUID);
		
	}
	EventB e(0);
	handle->SendEvent(&e,destMsgId);
}

// Ensure that ListenerB only hears directed eventB and nothing else
void UpdateListenB(EventMsgBoxHandle handle, EventMsgBoxId destMsgId)
{
	int numEvents = handle->GetNumEvents();
	UTF_CHECK(numEvents <= 1);

	for(int i=0;i<numEvents;i++)
	{
		const EventMsg* pEventMsg = handle->GetEvent(i);
		
		// Should not get a broadcast events..  only msg from clientA
		UTF_CHECK(pEventMsg->GetGuidID() !=BroadEventC::EVENT_GUID);
		UTF_CHECK(pEventMsg->GetSenderId() !=  BROAD_CAST_MSG_ID);
		UTF_CHECK(pEventMsg->GetSenderId() ==  destMsgId);
		UTF_CHECK(pEventMsg->GetGuidID() == EventB::EVENT_GUID);
	}

	EventA e(0);
	handle->SendEvent(&e,destMsgId);
}

// Ensure that BroadCastListener only hears the registered BroadEventC and nothing else
void UpdateListenBroadCastC(EventMsgBoxHandle handle)
{
	int numEvents = handle->GetNumEvents();
	UTF_CHECK(numEvents == 1);

	for(int i=0;i<numEvents;i++)
	{
		const EventMsg* pEventMsg = handle->GetEvent(i);
		
		// Should not get a broadcast events..  only msg from clientA
		UTF_CHECK(pEventMsg->GetGuidID() ==BroadEventC::EVENT_GUID);
		UTF_CHECK(pEventMsg->GetRecieverId() ==  BROAD_CAST_MSG_ID);
		UTF_CHECK(pEventMsg->GetGuidID() != EventB::EVENT_GUID);
		UTF_CHECK(pEventMsg->GetGuidID() != EventB::EVENT_GUID);
		
	}
}

BEGIN_UNITTESTGROUP( AdvanceEventSystemTestGroup )
{
	// Test all construction!!
	BEGIN_UNITTEST(AdvanceEventSystemSendEventTest)
	{		
			EventMan eventMan;
			eventMan.Init();

			EventMsgBoxHandle msgBoxA = eventMan.RegisterAndCreateEventMsgBox();
			EventMsgBoxHandle msgBoxB = eventMan.RegisterAndCreateEventMsgBox();
			EventMsgBoxHandle msgBoxC = eventMan.RegisterAndCreateEventMsgBox();

			msgBoxC->RegisterListenBroadcastEvent(BroadEventC::EVENT_GUID);

			EventMsgBoxHandle msgBoxMain = eventMan.RegisterAndCreateEventMsgBox();

			for(int i=0;i<1000;i++)
			{
				BroadEventC eventC(0);
				msgBoxMain->SendEvent(&eventC);
				msgBoxMain->ClearOutbox();
				msgBoxMain->ClearInbox();
				

				UpdateListenA(msgBoxA, msgBoxB->GetId());
				msgBoxA->ClearOutbox();
				msgBoxA->ClearInbox();
				UpdateListenB(msgBoxB, msgBoxA->GetId());
				msgBoxB->ClearOutbox();
				msgBoxB->ClearInbox();
				UpdateListenBroadCastC(msgBoxC);
				msgBoxC->ClearOutbox();
				msgBoxC->ClearInbox();
			}

			eventMan.UnRegisterEventMsgBox(msgBoxA);
			eventMan.UnRegisterEventMsgBox(msgBoxB);
			eventMan.UnRegisterEventMsgBox(msgBoxC);
			eventMan.UnRegisterEventMsgBox(msgBoxMain);

			eventMan.Destroy();
	}	
	END_UNITTEST
}
END_UNITTESTGROUP( EventSystemTestGroup )

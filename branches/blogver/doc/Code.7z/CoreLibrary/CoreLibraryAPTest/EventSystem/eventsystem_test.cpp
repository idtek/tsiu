//==========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
//!	@file 	eventsystem_tests.cpp
//!	@brief	unit tests for the eventsystem class
//
//! The purpose of this test is to proof the correctness of the event system particularily
//  1. Ensure eventmsgbox registeration and un-registeration is correct
//  2. Ensure that events are sent in-order and broadcasted to the correct msgbox!
//  3. Ensure that events are sent and recieved and not lost!
//  4. Ensure that there is a miminum number of memcpy!  (No mem copy code!)
//  5. Ensure that events can be destroyed by client and system does not crash!
//
//	created:	7:4:2007
//	author:		dhoac
//
//	Copyright (c) 2007 by Action Pants Inc
//==========================================================================

#include <UnitTesting.h>
#include "eventsystem/eventmsgbox.h"
#include "eventsystem/eventman.h"
#include "eventsystem/eventmsgdictionary.h"
#include "core/random.h"

using namespace Axiom;

class EventMsgA:public EventMsg
{	
public:

	EVENT_MSG_GUID(EventMsgA);
	
	EventMsgA():EventMsg(EVENT_GUID) {mValue = 0; }
	EventMsgA(int val):EventMsg(EVENT_GUID){mValue = val;}

	int mValue;
};

class EventMsgB:public EventMsg
{
public:
	EVENT_MSG_GUID(EventMsgB);
	
	EventMsgB():EventMsg(EVENT_GUID) {mValue = 0; }
	EventMsgB(int val):EventMsg(EVENT_GUID){mValue = val;}

	int mValue;
};

EventMsgBoxHandle sHandleA = NULL;
EventMsgBoxHandle sHandleB = NULL;
EventMsgBoxHandle sHandleC = NULL;

static Random sRandom;

void ClientAUpdate()
{
	static int expectSequence = 0;
	static int sendSequence = 0;
	UTF_CHECK(sHandleA !=NULL);

	// Traverse through EventMsgA
	int numMsg = sHandleA->GetNumEvents();

	for(int i =0;i<numMsg;i++)
	{
		const EventMsg* eventMsg = sHandleA->GetEvent(i);
		UTF_CHECK(eventMsg->GetGuidID() == EventMsgA::EVENT_GUID);

		const EventMsgA* pEventB = eventMsg->GetClass<EventMsgA>();
		
		// Ensure that the events are in sequence
		UTF_CHECK(pEventB->mValue == expectSequence);
		expectSequence++;
	}


	// Randomly send events with a sequence number
	int numSend = sRandom.RandInt(0, 15);
	for(int i=0;i<numSend;i++)
	{
		// Usage 1: create and event and send it
		EventMsgB eventB(sendSequence);
		sHandleA->SendEvent(&eventB);

		sendSequence++;
		// Usage 2: allocate an event, send it and destroy it
		// Ensure that if client holds event and deletes the memory, we will not crash!
		EventMsgA *eventA = AP_NEW(0,EventMsgA)(sendSequence);
		sHandleA->SendEvent(eventA);

		AP_DELETE(eventA);
		eventA = NULL;
		sendSequence++;
	}
}

void ClientBUpdate()
{
	static int expectSequence = 0;
	static int sendSequence = 0;
	UTF_CHECK(sHandleB !=NULL);

	// Traverse through EventMsgA
	int numMsg = sHandleB->GetNumEvents();
	for(int i =0;i<numMsg;i++)
	{
		const EventMsg* eventMsg = sHandleB->GetEvent(i);
		
		// Check what type of event exist, and process it!!
		if(eventMsg->GetGuidID() == EventMsgA::EVENT_GUID)
		{
			const EventMsgA* pEventA = eventMsg->GetClass<EventMsgA>();
			UTF_CHECK(pEventA->mValue == expectSequence);
		} 
		else if(eventMsg->GetGuidID() == EventMsgB::EVENT_GUID)
		{
			const EventMsgB* pEventB = eventMsg->GetClass<EventMsgB>();
			UTF_CHECK(pEventB->mValue == expectSequence);
		}

		expectSequence++;
	}

	// Randomly send events with a sequence number
	int numSend = sRandom.RandInt(0, 20);
	for(int i=0;i<numSend;i++)
	{
		// Usage 2: allocate an event, send it and destroy it
		// Ensure that if client holds event and deletes the memory, we will not crash!
		EventMsgA eventA(sendSequence);
		sHandleB->SendEvent(&eventA);
		sendSequence++;
	}

	sHandleB->ClearOutbox();
	sHandleB->ClearInbox();

}


void ClientCUpdate()
{
	static int expectSequence = 0;
	UTF_CHECK(sHandleC !=NULL);

	// Traverse through EventMsgA
	int numMsg = sHandleC->GetNumEvents();
	for(int i =0;i<numMsg;i++)
	{
		const EventMsg* eventMsg = sHandleC->GetEvent(i);

		// Check what type of event exist, and process it!!
		if(eventMsg->GetGuidID() == EventMsgA::EVENT_GUID)
		{
			const EventMsgA* pEventA = eventMsg->GetClass<EventMsgA>();
			UTF_CHECK(pEventA->mValue == expectSequence);
		} 
		else if(eventMsg->GetGuidID() == EventMsgB::EVENT_GUID)
		{
			const EventMsgB* pEventB = eventMsg->GetClass<EventMsgB>();
			UTF_CHECK(pEventB->mValue == expectSequence);
		}

		expectSequence++;
	}

	sHandleC->ClearOutbox();
	sHandleC->ClearInbox();

}

BEGIN_UNITTESTGROUP( EventSystemTestGroup )
{
	// Test all construction!!
	BEGIN_UNITTEST(EventSystemConstuctTest)
	{		
		{
			EventMan eventMan;
			eventMan.Init();
			eventMan.Destroy();
			EventMan *pEventMan = AP_NEW(0, EventMan)();
			pEventMan->Init();
			pEventMan->Destroy();
			AP_DELETE(pEventMan);
		}
	}	
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(EventSystemFunctionalTest)
	{
		EventMan eventMan;
		eventMan.Init();

		UTF_CHECK(sHandleA == NULL);
		UTF_CHECK(sHandleB == NULL);

		sHandleA = eventMan.RegisterAndCreateEventMsgBox("HANDLE_A");
		sHandleB = eventMan.RegisterAndCreateEventMsgBox("HANDLE_B");
		sHandleC = sHandleA;

		sHandleA->OverrideFilterAndListenAllEvents(true);
		sHandleA->OverrideFilterAndListenAllEvents(true);

		UTF_CHECK(sHandleA != NULL && sHandleB!=NULL);
		sRandom.Seed(666);

		int numRuns = 1000;
		for(int i=0;i< numRuns;i++)
		{
			ClientAUpdate();		
			ClientCUpdate();
			ClientBUpdate();
		}

		UTF_CHECK(sHandleA != NULL);
		UTF_CHECK(sHandleB != NULL);

		eventMan.UnRegisterEventMsgBox(sHandleA);
		
		// Still got one more reference handle!!
		UTF_CHECK(sHandleC != NULL);
		eventMan.UnRegisterEventMsgBox(sHandleB);
		eventMan.UnRegisterEventMsgBox(sHandleC);

		UTF_CHECK(sHandleC == NULL);
		UTF_CHECK(sHandleA == NULL);
		UTF_CHECK(sHandleB == NULL);

		eventMan.Destroy();
	}
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(QuickEventMsgDictionaryFunctionalTest)
	{
		EventMsgDictionary::Init(Axiom::Memory::RESERVED_CORE_HEAP);

		EventMsgDictionary *pDictionary = EventMsgDictionary::GetInstance();
		pDictionary->SetMaxNumberOfEvents( 12, Axiom::Memory::DEFAULT_HEAP );

		AP_ASSERT(pDictionary!=NULL);
		pDictionary->AddEvent<EventMsgA>();

		EventMsgA msgA(100);
		void* pData = reinterpret_cast<void*>(reinterpret_cast<EventMsgA*>(&msgA));

		// EventMsgA in dictionary, should return the same object!
		const EventMsgA* newMsgA = reinterpret_cast<const EventMsgA*>(pDictionary->CreateEvent(EventMsgA::EVENT_GUID, pData));
		UTF_CHECK(newMsgA->mValue == msgA.mValue);

		// Not in dictionary, should return NULL
		const EventMsgA* newMsgB =  reinterpret_cast<const EventMsgA*>(pDictionary->CreateEvent(EventMsgB::EVENT_GUID, pData));
		UTF_CHECK(newMsgB == NULL);

	}
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(EventSystemBoundaryTest)
	{
		// Testing the event manager API init and destroy!
		EventMan eventMan;
		const unsigned int numBoxes = 24;
		eventMan.Init( numBoxes );

		// Stress test the registration process
		EventMsgBoxHandle handles[numBoxes+1];

		for(unsigned int i=0;i<numBoxes;i++)
		{
			handles[i] = eventMan.RegisterAndCreateEventMsgBox();
		}
// 		UTF_CHECKASSERT(handles[EventMan::MAX_EVENT_MSGBOX] = eventMan.RegisterAndCreateEventMsgBox());

		for( unsigned int i=0;i<numBoxes;i++)
		{
			eventMan.UnRegisterEventMsgBox(handles[i]);
		}
		UTF_CHECKASSERT(eventMan.UnRegisterEventMsgBox(handles[numBoxes]));

		// Uncalled for usage with auto un-registration of event msg box..
		EventMsgBoxHandle newHandle = eventMan.RegisterAndCreateEventMsgBox();
		newHandle = eventMan.RegisterAndCreateEventMsgBox();
		
		UTF_CHECKASSERT(eventMan.Destroy());
		newHandle = 0;
	
		// When destroy, this one should pass!!  if Things were all good!
		eventMan.Destroy();
	}
	END_UNITTEST


	BEGIN_UNITTEST(EventSystemEventMsgBoundaryTest)
	{
		EventMan eventMan;

		const unsigned int numEvents = 200;

		eventMan.Init();
		EventMsgBoxHandle msgBox1 = eventMan.RegisterAndCreateEventMsgBox( "msgbox1", Axiom::Memory::DEFAULT_HEAP, numEvents );
		EventMsgBoxHandle msgBox2 = eventMan.RegisterAndCreateEventMsgBox( "msgbox2", Axiom::Memory::DEFAULT_HEAP, numEvents );

		UTF_CHECK(msgBox1->GetNumEvents()==0);
		UTF_CHECKASSERT(msgBox1->GetEvent(0));
		UTF_CHECKASSERT(msgBox1->GetEvent(10));

		for(unsigned int i=0;i<numEvents;i++)
		{
			EventMsgA msgA(i);
			msgBox1->SendEvent(&msgA);
		}

		msgBox1->ClearOutbox();
		msgBox1->ClearInbox();
		UTF_CHECK(msgBox1->GetNumEvents()==0);
		UTF_CHECKASSERT(msgBox1->GetEvent(0));
		UTF_CHECKASSERT(msgBox1->GetEvent(10));
	}
	END_UNITTEST
}
END_UNITTESTGROUP( EventSystemTestGroup )

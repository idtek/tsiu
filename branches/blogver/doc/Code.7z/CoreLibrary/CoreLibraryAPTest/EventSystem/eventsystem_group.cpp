//====================================================================
//
//!	@file 	thread_group.cpp
//!	@brief	Master group for Thread unit tests
//
//	created:	
//	author:		duongh
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include "unittesting.h"

// Declare all test
DECLARE_UNITTESTGROUP(EventSystemTestGroup)
DECLARE_UNITTESTGROUP(AdvanceEventSystemTestGroup)

// Declare Groups
BEGIN_UNITTESTGROUP(EventSystemGroup)
{
	RUN_UNITTESTSUBGROUP(EventSystemTestGroup)
	RUN_UNITTESTSUBGROUP(AdvanceEventSystemTestGroup)

}
END_UNITTESTGROUP(EventSystemGroup)


#include <UnitTesting.h>
#include <core/crc.h>
#include "core/utils.h"

using namespace Axiom;
using namespace Axiom::Math;

class TestClass
{
public:
	TestClass(){}
	~TestClass(){}
	size_t GetSize(){ return sizeof(TestClass);}
};

BEGIN_UNITTESTGROUP( GltUtilsTestGroup )
{
	// Test all other functional use
	BEGIN_UNITTEST(GltUtilsFunctionalTest)
	{
		int a=1, b=2;

		Axiom::Swap<int>(a,b);
		UTF_CHECK(a== 2 && b == 1);

		int minVal = Axiom::Min<int>(a,b);
		UTF_CHECK(minVal == 1);

		int maxVal = Axiom::Max<int>(a,b);
		UTF_CHECK(maxVal == 2);

		bool imp = AP_IMPLIES(true,false);
		UTF_CHECK(imp == false);
		imp = AP_IMPLIES(true,true);
		UTF_CHECK(imp == true);

		int alignVal = AlignUp<int>(10, 16);
		UTF_CHECK(alignVal == 16);
		alignVal = AlignUp<int>(-10, 16);
		UTF_CHECK(alignVal == 0);
		alignVal = AlignUp<int>(-129, 16);
		UTF_CHECK(alignVal == -128);

		alignVal = AlignDown<int>(133, 16);
		UTF_CHECK(alignVal == 128);
		alignVal = AlignDown<int>(-123, 16);
		UTF_CHECK(alignVal == -128);

		Byte tempData[10000];
		Byte *pTempDataPtr = tempData;

		pTempDataPtr = AlignMem<Byte>(pTempDataPtr, 16);
		UTF_CHECK((int)pTempDataPtr % 16 == 0);
		pTempDataPtr = AlignMem<Byte>(pTempDataPtr + sizeof(Byte)*30, 32);
		UTF_CHECK((int)pTempDataPtr % 32 == 0);

		pTempDataPtr = tempData;

		TestClass *pTemp = reinterpret_cast<TestClass *>(pTempDataPtr);
		Construct<TestClass>(pTemp);
		UTF_CHECK(pTemp && pTemp->GetSize() == sizeof(TestClass));

		Destruct<TestClass>(pTemp);
	
		Construct<TestClass>(pTemp, 1);
		UTF_CHECK(pTemp && pTemp->GetSize() == sizeof(TestClass));

		Destruct<TestClass>(pTemp, sizeof(TestClass));

		UTF_CHECKASSERT(Destruct<TestClass>(0));
		UTF_CHECKASSERT(Destruct<TestClass>(NULL, 1));

	}	
	END_UNITTEST

}
END_UNITTESTGROUP( GltUtilsTestGroup )

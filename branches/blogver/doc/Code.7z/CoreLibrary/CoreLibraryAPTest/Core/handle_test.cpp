#include <UnitTesting.h>
#include <core/handle.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( HandleTestGroup )
{
	//Testing Base case of Handle Test
	BEGIN_UNITTEST(HandleBaseContructorDestructorTest)
	{
		// Testing constructor/destructor
		{
			uint value = 1;
			Handle h0;
			Handle h1(value);
			Handle h2((void*)value);
			h2 = h1;
			h2 = h0;
		}

		// Testing constructor/destructor via new
		{
			int value = 1;
			Handle *p0 = AP_NEW(0,Handle());
			Handle *p1 = AP_NEW(0,Handle(value));
			Handle *p2 = AP_NEW(0,Handle((void*)value));
			p0=p1;
			p0=p2;
			
			AP_DELETE(p0);
			AP_DELETE(p1);
			AP_DELETE(p2);
		}

	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(HandleFunctionalTest)
	{
		uint value = 1;
		Handle h0;
		Handle h1(value);
		Handle h2((void*)value);
		h2 = h1;

		uint val1 = static_cast<uint>(h1);
		uint val2 = static_cast<uint>(h2);
		UTF_CHECK(val1 == val2);

		h1 = 2;
		val1 = static_cast<uint>(h1);
		UTF_CHECK(val1 != val2 && val1 == 2);
		
		h2 = static_cast<void*>(h1);

		void* pVal1 = static_cast<void*>(h1);
		void* pVal2 = static_cast<void*>(h2);
		UTF_CHECK(pVal1 == pVal2);

		value = 2;
		Handle *p0 = AP_NEW(0,Handle());
		Handle *p1 = AP_NEW(0,Handle(value));

		val1 =  static_cast<uint>(*p0);
		val2 =  static_cast<uint>(*p1);
		UTF_CHECK(val1 != val2);

		*p0 = *p1;
		val1 =  static_cast<uint>(*p0);
		val2 =  static_cast<uint>(*p1);
		UTF_CHECK(val1 == val2);

		pVal1 = static_cast<void*>(*p0);
		pVal2 = static_cast<void*>(*p1);

		UTF_CHECK(pVal1 == pVal2);
		UTF_CHECK(p0 &&p1);

		AP_DELETE(p0);
		AP_DELETE(p1);

	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(HandleBoundaryTest)
	{
	}
	END_UNITTEST
}
END_UNITTESTGROUP( HandleTestGroup )

#include <UnitTesting.h>
#include <debug/log.h>
#include <encode/base64.h>
#include <string/string.h>
#include <core/smartptr.h>
#include <core/random.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( EncodeTestGroup )
{
	const int OutputBufferSize = 10000;
	//Testing Base case of String Test
	BEGIN_UNITTEST(EncodeDecodeContructorDestructorTest)
	{
		// Testing contructor/destructor
		Base64Encoder  encode;
		Base64Decoder	 decode;
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(EncodeDecodeFunctionalTest)
	{
		Axiom::ShortString str0("String0");

		char* EncodedBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [OutputBufferSize]);
		Base64Encoder  encode;
		int EncodedBufferSize;
		encode.Encode (str0.AsChar (), str0.Length (), EncodedBuffer, EncodedBufferSize);


		char* DecodedBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [OutputBufferSize]);
		Axiom::MemorySet (DecodedBuffer, 0, OutputBufferSize);
		Base64Decoder  decode;
		int DecodedBufferSize;
		decode.Decode (EncodedBuffer, EncodedBufferSize, DecodedBuffer, DecodedBufferSize);

		AP_DELETEARRAY (EncodedBuffer);

		UTF_CHECK(str0 == DecodedBuffer);
		
		AP_DELETEARRAY (DecodedBuffer);
	}	
	END_UNITTEST


	// Test all boundary cases
	BEGIN_UNITTEST (EncodeDecodeLargeBufferTest)// testing large buffers.
	{
		const int BigBufferSize = 300*1024;
		Random Randomizer;

		char* StartBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [BigBufferSize/2]);
		for(int i=0; i<BigBufferSize/2; i++)
		{
			StartBuffer[i] = static_cast <char> (Randomizer.RandInt (0, 255));
		}

		char* EncodedBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [BigBufferSize]);
		Base64Encoder  encode;
		int EncodedBufferSize;
		encode.Encode (StartBuffer, BigBufferSize/2, EncodedBuffer, EncodedBufferSize);


		char* DecodedBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [BigBufferSize]);
		Axiom::MemorySet (DecodedBuffer, 0, BigBufferSize);
		Base64Decoder  decode;
		int DecodedBufferSize;
		decode.Decode (EncodedBuffer, EncodedBufferSize, DecodedBuffer, DecodedBufferSize);

		for(int i=0; i<BigBufferSize/2; i++)
		{
			UTF_CHECK(StartBuffer[i] == DecodedBuffer[i]);
		}

		AP_DELETEARRAY (EncodedBuffer);
		AP_DELETEARRAY (DecodedBuffer);
		AP_DELETEARRAY (StartBuffer);
	}
	END_UNITTEST

	BEGIN_UNITTEST (EncodeDecodeBoundaryTest)// testing bad buffers.
	{
		const int BufferSize = 1024;
		Random Randomizer;

		char* StartBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [BufferSize]);
		for(int i=0; i<BufferSize; i++)
		{
			StartBuffer[i] = static_cast <char> (Randomizer.RandInt (0, 255));
		}

		char* DecodedBuffer = AP_NEW (Axiom::Memory::RESERVED_CORE_HEAP, char [BufferSize*2]);
		Axiom::MemorySet (DecodedBuffer, 0, BufferSize*2);
		Base64Decoder  decode;
		int DecodedBufferSize;
		decode.Decode (StartBuffer, BufferSize, DecodedBuffer, DecodedBufferSize);
		AP_DELETEARRAY (StartBuffer);

		bool FoundNegativeOne = false;
		for(int i=0; i<BufferSize; i++)
		{
			if (DecodedBuffer[i] == -1)// bad decoded value, this isn't a very good test and should be improved.
			{
				FoundNegativeOne = true;
				break;
			}
		}
		UTF_CHECK (FoundNegativeOne == true);
		AP_DELETEARRAY (DecodedBuffer);		
	}
	END_UNITTEST
}
END_UNITTESTGROUP( EncodeTestGroup )

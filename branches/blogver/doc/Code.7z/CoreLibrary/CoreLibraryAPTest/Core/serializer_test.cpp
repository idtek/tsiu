#include <UnitTesting.h>
#include "core/serializer.h"

using namespace Axiom;

struct TestStruct
{
	TestStruct():mInt(100), mFloat(-10.f){}

	int mInt;
	float mFloat;
};

BEGIN_UNITTESTGROUP( SerializerTestGroup )
{
	//Testing Base case of Serialize Test
	BEGIN_UNITTEST(SerializerBaseContructorDestructorTest)
	{
		// Quick construct/destruct test!
		{			
			// Writing serialize
			Serializer serial0(1,Serializer::BINARY, 0);
			Serializer serial1(1,1000, Serializer::BINARY, 0);

			// Reading serialize
			Byte pData[1000];
			Serializer serial2(pData,1000, 0);
			Serializer serial3(pData,1000, Serializer::BINARY,0);
		}
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(SerializerFunctionalTest)
	{
		////////////////////////////////////////////////////////////////////////////////
		// Serialize write test
		////////////////////////////////////////////////////////////////////////////////
		TestStruct constTestData;
		const unsigned int constSeperateId = 0xbadebade;

		int numEntries=5;
		size_t totalSize = sizeof(int)*numEntries + sizeof(TestStruct)*numEntries;
		Serializer serialWrite(1,totalSize, Serializer::BINARY, 0);

		serialWrite.Reset();
		serialWrite.Offset(0);
		UTF_CHECK(serialWrite.GetVersion()==1);
		UTF_CHECK(serialWrite.IsWriting()==true);
		UTF_CHECK(serialWrite.IsReading()==false);
		UTF_CHECK(serialWrite.GetFormat()==Serializer::BINARY);
		UTF_CHECK(serialWrite.Heap()==0);
		UTF_CHECK(serialWrite.Peek()!=NULL);
		UTF_CHECK(serialWrite.Capacity() >= totalSize);
		UTF_CHECK(serialWrite.Size() == (size_t)(serialWrite.Peek()-serialWrite.Start()))
		
		for(int i=0;i<numEntries;i++)
		{
			serialWrite.Serialize(&constTestData, sizeof(TestStruct));
			serialWrite.Serialize((void*)&constSeperateId, sizeof(unsigned int));
		}

		////////////////////////////////////////////////////////////////////////////////
		// Serialize read test
		////////////////////////////////////////////////////////////////////////////////
		int size  = serialWrite.Size();
		Serializer serialRead(serialWrite.AcquireBuffer(),size,0);

		for(int i=0;i<numEntries;i++)
		{
			TestStruct testData;
			testData.mFloat = 0;
			testData.mInt = 0;
			unsigned int seperateId;

			serialRead.Serialize(&testData, sizeof(TestStruct));
			serialRead.Serialize((void*)&seperateId, sizeof(unsigned int));

			UTF_CHECK(testData.mFloat == constTestData.mFloat);
			UTF_CHECK(testData.mInt == constTestData.mInt);
			UTF_CHECK(seperateId == constSeperateId);
		}

	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(SerializerBoundaryTest)
	{
		AP_ASSERT_SUPPORT(Byte data[100]);
		
		UTF_CHECKASSERT(Serializer serial1(1,0, Serializer::BINARY, 0));
		UTF_CHECKASSERT(Serializer serial2(1,0, Serializer::BINARY, 0));
		UTF_CHECKASSERT(Serializer serial3((Byte*)NULL,1000, 0));
		UTF_CHECKASSERT(Serializer serial4((Byte*)NULL,1000, Serializer::BINARY,0));

		UTF_CHECKASSERT(Serializer serial5((Byte*)data,0, 0));
		UTF_CHECKASSERT(Serializer serial6((Byte*)data,0, Serializer::BINARY,0));

		Serializer serial(1,10, Serializer::BINARY, 0);
		serial.Reset();
		serial.Reset();
		
		UTF_CHECKASSERT(serial.Serialize(NULL, 100));
		UTF_CHECKASSERT(serial.Serialize(data, 0));
		UTF_CHECKASSERT(serial.Offset(1000));
	}
	END_UNITTEST
}
END_UNITTESTGROUP( SerializerTestGroup )

#include <UnitTesting.h>
#include <core/classedenum.h>

using namespace Axiom;

#define LIST_OF_ENUMS TEST_A, TEST_B, TEST_C,

CLASSEDENUM(TestClass, LIST_OF_ENUMS, TEST_A)
CLASSEDENUMSAFE(SafeTestClass, LIST_OF_ENUMS, TEST_A)

//CLASSEDENUMSAFEEXTRAS(TestClass)
//CLASSEDENUMSAFEEXTRAS(SafeTestClass)

BEGIN_UNITTESTGROUP( ClassEnumPointerTestGroup )
	{
	//Testing Base case of CRC Test
	BEGIN_UNITTEST(ClassEnumPointerBaseContructorDestructorTest)
	{
		// Testing constructor and destructor for unsafe version
		{
			TestClass test0;
			TestClass test1(TestClass::TEST_B);
			TestClass test2(test1);

		}

		// Testing constructor and destructor for safe version
		{
			SafeTestClass safeTest0;
			SafeTestClass safeTest1(SafeTestClass::TEST_B);
			SafeTestClass safeTest2(safeTest1);	
		}
	}
	END_UNITTEST


		// Test all other functional use
	BEGIN_UNITTEST(ClassEnumPointerFunctionalTest)
	{
		// Test unsafe version
		{
			TestClass test0;
			test0.m_Value = TestClass::TEST_B;

			TestClass test1(test0);

			int val = test0;

			UTF_CHECK(test0 == val && val == test0 && val == test0.m_Value)
			UTF_CHECK(test0 == test1)

			test1.m_Value = TestClass::TEST_C;

			UTF_CHECK(test1 !=test0  && val != TestClass::TEST_C && val !=test1)

			test0 = test1;
			UTF_CHECK(test0 == test1)

		}
	
		// Test safe version
		{
			SafeTestClass safeTest0;
			safeTest0.m_Value = SafeTestClass::TEST_B;

			SafeTestClass safeTest1(safeTest0);

			int safeVal = safeTest0;

			UTF_CHECK(safeTest0 == safeVal && safeVal == safeTest0 && safeVal == safeTest0.m_Value)
			UTF_CHECK(safeTest0 == safeTest1)

			safeTest1.m_Value = SafeTestClass::TEST_C;

			UTF_CHECK(safeTest1 !=safeTest0  && safeVal != SafeTestClass::TEST_C && safeVal !=safeTest1)

			safeTest0 = safeTest1;
			UTF_CHECK(safeTest0 == safeTest1)
		}
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(ClassEnumPointerBoundaryTest)
	{
		TestClass test1(TestClass::TEST_C);
		UTF_CHECKASSERT(test1 = 100);
		UTF_CHECKASSERT(TestClass test2(100))
	}
	END_UNITTEST
	}
END_UNITTESTGROUP( ClassEnumPointerTestGroup )

#include <UnitTesting.h>
#include <core/datapool.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( DataPoolTestGroup )
{
	//Testing Base case of DataPool Test
	BEGIN_UNITTEST(DataPoolBaseContructorDestructorTest)
	{
		DataPool<4,5> dataPool;

		UTF_CHECK(!dataPool.IsEmpty());
		UTF_CHECK(dataPool.Count()==dataPool.Capacity());
		UTF_CHECK(dataPool.Capacity()==5);
		
		const int kNumBlocks = 5;
		void* buffer[kNumBlocks];

		for(int i=0;i<kNumBlocks;i++)
			buffer[i]= dataPool.Acquire();

		UTF_CHECK(dataPool.IsEmpty());
		UTF_CHECK(dataPool.Count()==0);
		
		for(int i=0;i<kNumBlocks;i++)
			dataPool.Release(buffer[i]);
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(DataPoolFunctionalTest)
	{
		DataPool<4,2> dataPool;
		void* pBlock1 = dataPool.Acquire();
		int* pBlock2 = reinterpret_cast<int*>(dataPool.Acquire());
		
		AP_ASSERT_SUPPORT(void* pBlock4 = NULL;)
		UTF_CHECKASSERT(pBlock4 = dataPool.Acquire());
		UTF_CHECKASSERT(pBlock4 = dataPool.Acquire());

		UTF_CHECK(dataPool.IsEmpty());
		UTF_CHECK(dataPool.Count()==0);
		UTF_CHECK(dataPool.Capacity()==2);

		dataPool.Release(pBlock1);	
		dataPool.Release<int>(pBlock2);
		
		UTF_CHECK(!dataPool.IsEmpty());
		UTF_CHECK(dataPool.Count()==dataPool.Capacity());
		UTF_CHECK(dataPool.Capacity()==2);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(DataPoolBoundaryTest)
	{
		DataPool<4,2> dataPool;
		void* pBlock1 = dataPool.Acquire();
		void* pBlock2 = dataPool.Acquire();
	
		// Acquire more than what we have in pool
		AP_ASSERT_SUPPORT(void* pBlock3;)
		UTF_CHECKASSERT(pBlock3 = dataPool.Acquire());
		UTF_CHECKASSERT(pBlock3 = dataPool.Acquire());

		dataPool.Release(pBlock1);
		dataPool.Release(pBlock2);

		AP_ASSERT_SUPPORT(int val;)
		UTF_CHECKASSERT(dataPool.Release(NULL));
		UTF_CHECKASSERT(dataPool.Release<int>(&val));

	}
	END_UNITTEST
}
END_UNITTESTGROUP( DataPoolTestGroup )

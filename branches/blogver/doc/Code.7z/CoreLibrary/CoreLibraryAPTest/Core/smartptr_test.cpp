#include <UnitTesting.h>
#include <core/smartptr.h>

using namespace Axiom;

//---------------------------------------------------------

class SmartIntObj
{
public:
	SmartIntObj();
	SmartIntObj(int val);
	int GetValue() const { return mValue; }

	int AddReference( void* pAdder ) 
	{ 
		UNUSED_PARAM( pAdder );
		return ++mRefCount; 
	}
	bool ReleaseReference( void* pRemover ) 
	{
		UNUSED_PARAM( pRemover );
		AP_ASSERT(mRefCount>0); 
		--mRefCount; 
		return 0 == mRefCount; 
	}
private:
	int mValue;
	int mRefCount;
};

SmartIntObj::SmartIntObj()
{
	AP_ASSERTFAIL("Don't use this!");
}

SmartIntObj::SmartIntObj(int val)
:	mValue(val)
,   mRefCount(0)
{
	AP_ASSERT(0 == mRefCount);
}

//---------------------------------------------------------

BEGIN_UNITTESTGROUP( SmartPtrTestGroup )
{
//Testing Base case of SmartPointer Test
	BEGIN_UNITTEST(SmartPtrBaseContructorDestructorTest)
	{
		// Quick Construct/Destruct test		
		{
			SmartIntObj* pObj = AP_NEW(Axiom::Memory::DEFAULT_HEAP, SmartIntObj(10));
			SmartPtr<SmartIntObj> ptr0;
			SmartPtr<SmartIntObj> ptr1(pObj);
			SmartPtr<SmartIntObj> ptr2(ptr0);
		}
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(SmartPtrFunctionalTest)
	{
		SmartIntObj* pObj = AP_NEW(Axiom::Memory::DEFAULT_HEAP, SmartIntObj(10));
		SmartPtr<SmartIntObj> ptr0(pObj);
		const SmartPtr<SmartIntObj> ptr1(pObj);

		UTF_CHECK(ptr0 == ptr1);			
		UTF_CHECK(ptr0->GetValue() == pObj->GetValue());
		UTF_CHECK(ptr1->GetValue() == pObj->GetValue());

		SmartIntObj *pPointer = ptr0.pVal();
		SmartIntObj objVal1 = ptr0.Val();
		SmartIntObj objVal2 = *ptr0;

		const SmartIntObj *pConstPointer = ptr1.pVal();
		SmartIntObj constObjVal1 = ptr1.Val();
		SmartIntObj constObjVal2 = *ptr1;

		UTF_CHECK(pPointer !=NULL && ptr0.IsValid());
		UTF_CHECK(pConstPointer !=NULL && ptr1.IsValid());
		
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(SmartPtrBoundaryTest)
	{
		SmartPtr<SmartIntObj> ptr0(NULL);
		const SmartPtr<SmartIntObj> ptr1(NULL);

		UTF_CHECKASSERT(ptr0->GetValue());
		UTF_CHECKASSERT(*ptr0);
		
		UTF_CHECKASSERT(ptr1->GetValue());
		UTF_CHECKASSERT(*ptr1);


	}
	END_UNITTEST
}
END_UNITTESTGROUP( SmartPtrTestGroup )

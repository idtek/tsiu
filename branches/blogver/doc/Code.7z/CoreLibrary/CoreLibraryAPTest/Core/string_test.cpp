#include <UnitTesting.h>
#include <string/string.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( StringTestGroup )
{
	//Testing Base case of String Test
	BEGIN_UNITTEST(StringBaseContructorDestructorTest)
	{
		// Testing contructor/destructor
		{
			String str0;
		  	String str1(1000);
			String str2(str1);
			String str3("Test");
			String str4("Test", sizeof("Test"));
		}
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(StringFunctionalTest)
	{
		String str0("String0");
		String str1("String1");

		UTF_CHECK(!str0.IsEmpty());
		UTF_CHECK(str0.Length() == 7 && str1.Length()==7);
		UTF_CHECK(str0.Capacity()>0 && str1.Capacity()>0);

		UTF_CHECK(str0.CStr() && StringCompare(str0.CStr(),					"String0", str0.Length()) == 0);
		UTF_CHECK(str1.CStr() && StringCompare(str1.CStr(),					"String1", str1.Length()) == 0);
		UTF_CHECK(StringCompare(str1.Left(3).CStr(),							"Str", 3) == 0);
		UTF_CHECK(StringCompare(str1.Right(3).CStr(),							"ng1", 3) == 0);
		
		UTF_CHECK(StringCompare(str1.Mid(0,3).CStr(),						str1.Left(3).CStr(), str0.Length()) == 0);
		UTF_CHECK(StringCompare(str1.Mid(str1.Length()-3,str1.Length()).CStr(),	str1.Right(3).CStr(), str0.Length()) == 0);
	
// Temporary skip string class because we're redoing strings for dynamic and static string!
//		str0.Replace("String0","NewString1");
//		UTF_CHECK(str0.CStr() && Crt_StrCompare(str0.CStr(),		"NewString1") == 0);

//		String str2("MyString");

//		char buffer[256];
//		str2.Extract(buffer, str2.Length()+1);
//		UTF_CHECK(str2.CStr() && Crt_StrCompare(str2.CStr(), buffer) == 0);
			
//		str2.Extract(buffer, buffer + (1+str2.Length())*sizeof(char));
//		UTF_CHECK(str2.CStr() && Crt_StrCompare(str2.CStr(), buffer) == 0);

//		str2.Clear();
//		UTF_CHECK(str2.Length() == 0);
        // Do some find tests



	}	
	END_UNITTEST


    BEGIN_UNITTEST(FindTests)
    {
        String string("this is my find test");

        int found = string.Find("this");
        UTF_CHECK(found == 0);

        found = string.Find("is");
        UTF_CHECK(found == 2);

        found = string.Find("my");
        UTF_CHECK(found == 8);

        found = string.Find("test");
        UTF_CHECK(found == 16);

        found = string.Find("ball");
        UTF_CHECK(found == -1);

        String LookIn;
        String LookFor;

        // Part of the search string matched before it�s actual real position
        LookIn = "animatiosomelongcrap:animation";
        int index = LookIn.Find( "animation" );
        UTF_CHECK(index == 21);

        // starting characters matched and overlap actual string to find  
        LookIn = "eeeeeeeeeeeen";
        index = LookIn.Find( "een" );
        UTF_CHECK(index == 10);

        // only 1 character matched before actual find
        LookIn = "asnimatiosomelongcrap:animation";
        index = LookIn.Find( "animation" );
        UTF_CHECK(index == 22);


        // partial string matched multiple times
        LookIn = "animatiosomelanimonganimacrap:animation";
        index = LookIn.Find( "animation" );
        UTF_CHECK(index == 30);

        // same tests case insensitive
        
        // Part of the search string matched before it�s actual real position
        LookIn = "animatiosomelongcrap:animation";
        index = LookIn.Find( "animation" );
        UTF_CHECK(index == 21);

        // starting characters matched and overlap actual string to find  
        LookIn = "eeeeeeeeeeeen";
        index = LookIn.Find( "een" );
        UTF_CHECK(index == 10);

        // only 1 character matched before actual find
        LookIn = "asnimatiosomelongcrap:animation";
        index = LookIn.Find( "animation" );
        UTF_CHECK(index == 22);


        // partial string matched multiple times
        LookIn = "animatiosomelanimonganimacrap:animation";
        index = LookIn.Find( "animation" );
        UTF_CHECK(index == 30);

       
    }
    END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(StringBoundaryTest)
	{
		
	}
	END_UNITTEST
}
END_UNITTESTGROUP( StringTestGroup )

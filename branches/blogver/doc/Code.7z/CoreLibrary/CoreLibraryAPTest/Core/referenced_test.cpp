#include <UnitTesting.h>
#include <core/referenced.h>
#include <thread/thread.h>

using namespace Axiom;

class NonThreadSafeRef: public Referenced
{
public:
	virtual ~NonThreadSafeRef(){};
};

class ThreadSafeRef: public Referenced
{
public:
	virtual ~ThreadSafeRef(){};
};


void ThreadMain0(Thread::ThreadParam data)
{
	Referenced *pRef = reinterpret_cast<Referenced*>(data);
	
	while(pRef->ReferenceCount()>50)
	{
		pRef->ReleaseReference( NULL );
	}
}


BEGIN_UNITTESTGROUP( ReferencedTestGroup )
{
	//Testing Base case of REference Test
	BEGIN_UNITTEST(ReferencedBaseContructorDestructorTest)
	{
		//Non-thread safe ref..
		{
			NonThreadSafeRef ref1;
			NonThreadSafeRef ref2(ref1);
			ref1=ref2;

			ThreadSafeRef threadSafeRef1;
			ThreadSafeRef threadSafeRef2(threadSafeRef1);
			threadSafeRef1=threadSafeRef2;
		}

	}
	END_UNITTEST

//DAY 10/23/2008 9:39:57 AM  Test kills ps3 unit tests.  Removing for now
#if CORE_PS3==CORE_NO
	// Test all other functional use
	BEGIN_UNITTEST(ReferencedFunctionalTest)
	{
		// Testing for multi-thread safety and ref variable on the stack
		{
			ThreadSafeRef threadSafeRef;

			for(int i=0;i<10000;i++)
			{
				threadSafeRef.AddReference( NULL );
			}

			UTF_CHECK(threadSafeRef.ReferenceCount() == 10000);

			Thread::CreateThread(ThreadMain0, (Thread::ThreadParam)(&threadSafeRef), Thread::TP_HIGH, 0, "ThreadMain0");

			// Waiting until the thread has 
			int count = 0;
			while(threadSafeRef.ReferenceCount()>9000)
			{			
				++count;
				Thread::Sleep(0);
			}
			UTF_CHECK(count < 1000);

			// Reduce the count at full speed with both threads
			while(threadSafeRef.ReferenceCount()>0)
			{			
				threadSafeRef.ReleaseReference( NULL );
				Thread::Sleep(0);
			}
			
			UTF_CHECK(threadSafeRef.ReferenceCount() == 0);
			Thread::Sleep(100);
		}

		// Testing for multi-thread safety and ref variable on the heap!!
		{
			ThreadSafeRef threadSafeRef;

			for(int i=0;i<10000;i++)
			{
				threadSafeRef.AddReference( NULL );
			}

			UTF_CHECK(threadSafeRef.ReferenceCount() == 10000);

			Thread::CreateThread(ThreadMain0, (Thread::ThreadParam)(&threadSafeRef), Thread::TP_HIGH, 0, "ThreadMain0");

			while(threadSafeRef.ReferenceCount()>0)
			{			
				threadSafeRef.ReleaseReference( NULL );
				Thread::Sleep(0);
			}
			
			UTF_CHECK(threadSafeRef.ReferenceCount() == 0);
		}

		// Testing normal, non-threadsafe version with ref variable on stack
		{			
			NonThreadSafeRef nonThreadSafeRef;

			for(int i=0;i<10000;i++)
			{
				nonThreadSafeRef.AddReference( NULL );
			}

			UTF_CHECK(nonThreadSafeRef.ReferenceCount() == 10000);

			for(int i=0;i<10000;i++)
			{
				nonThreadSafeRef.ReleaseReference( NULL );
			}

			UTF_CHECK(nonThreadSafeRef.ReferenceCount() == 0);
		}

		// Testing normal, non-threadsafe version with ref variable on heap
		{			
			NonThreadSafeRef* pNonThreadSafeRef = AP_NEW(0,NonThreadSafeRef());

			for(int i=0;i<10000;i++)
			{
				pNonThreadSafeRef->AddReference( NULL );
			}

			UTF_CHECK(pNonThreadSafeRef->ReferenceCount() == 10000);

			for(int i=0;i<10000;i++)
			{
				if(i == 9999)
				{
					UTF_CHECK(pNonThreadSafeRef->ReferenceCount() == 1);
				}
	
				pNonThreadSafeRef->ReleaseReference( NULL );
			}		
			
		}
	}	
	END_UNITTEST
#endif

	// Test all boundary cases
	BEGIN_UNITTEST(ReferencedBoundaryTest)
	{
		ThreadSafeRef threadSafeRef;
		threadSafeRef.AddReference( NULL );
		UTF_CHECK(threadSafeRef.ReferenceCount() == 1);
		threadSafeRef.ReleaseReference( NULL );
		//UTF_CHECKASSERT(threadSafeRef.ReleaseReference( NULL ));

	}
	END_UNITTEST
}
END_UNITTESTGROUP( ReferencedTestGroup )

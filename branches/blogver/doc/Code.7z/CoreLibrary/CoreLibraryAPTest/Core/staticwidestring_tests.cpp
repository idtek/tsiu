// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	staticstring_tests.cpp
//!	@brief	Unit tests for the StaticString Class
//
//	created:	5:25:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include "unittesting.h"
#include "string/string.h"

using namespace AP::UnitTestingFramework;

// --------------------------------------------------------------------------
BEGIN_UNITTESTGROUP(StaticWideStringGroup)
{
	BEGIN_UNITTEST(UnboundedEmptyConstruction)
    {
		using Axiom::StaticString;
		StaticString <10,wchar_t> string;
		UTF_CHECK(string == L"");
		UTF_CHECK(string.IsEmpty() == true);
		UTF_CHECK(string.Length() == 0);

		StaticString <10,wchar_t> string2;
		UTF_CHECK(string2 == L"");
		UTF_CHECK(string2.IsEmpty() == true);
		UTF_CHECK(string2.Length() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(UnboundedStringTests)
	{
		{
			using Axiom::StaticString;
			StaticString <Axiom::NORMAL_STATIC_STRING_LENGTH,wchar_t> string;  // default length
			UTF_CHECKASSERT(string = L"this String Is way too big, no way the legal length, and should cause The Test To Fail");
			string = L"12345678901234567890123456789012345678901234567890123456789012";
			UTF_CHECKASSERT(string += string);
			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == L"1234567890123456789012345678901234567890123456789012345678901*");
			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == L"1234567890123456789012345678901234567890123456789012345678901_");
			string[0] = '_';
			UTF_CHECK(string == L"_234567890123456789012345678901234567890123456789012345678901_");
			string[1] = '_';
			UTF_CHECK(string == L"__34567890123456789012345678901234567890123456789012345678901_");

			UTF_CHECK( string.Right(10) == L"345678901_" );
			UTF_CHECK( string.Right(string.Length()) == L"__34567890123456789012345678901234567890123456789012345678901_" );
			UTF_CHECKASSERT(string.Right(string.Length()+1));

			UTF_CHECK(string.Left(4) == L"__34");
			UTF_CHECK(string.Left(string.Length()) == string);
			UTF_CHECKASSERT(string.Left(string.Length() +1));
		}

		{
			using Axiom::StaticString;
			StaticString <10, wchar_t> string, secondString;
			string = L"1234567890";
			UTF_CHECKASSERT(string = L"this String Is way too big, no way the legal length, and should cause The Test To Fail");
			UTF_CHECKASSERT(string = L"12345678901");

			string = L"1234567890";
			UTF_CHECKASSERT(string += string);

			UTF_CHECKASSERT(string[string.Length()] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == L"123456789*");
			UTF_CHECKASSERT(string[string.Length()] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == L"123456789_");
			string[0] = '_';
			UTF_CHECK(string == L"_23456789_");
			string[1] = '_';
			UTF_CHECK(string == L"__3456789_");

			UTF_CHECK( string.Right(4) == L"789_" );
			UTF_CHECK( string.Right(string.Length()) == string );
			UTF_CHECKASSERT(string.Right(string.Length()+1));

			UTF_CHECK(string.Left(4) == L"__34");
			UTF_CHECK(string.Left(string.Length()) == string);
			UTF_CHECKASSERT(string.Left(string.Length() +1));
			
            string = L"12345";
            secondString = L"12345";
            string = string + secondString;
            string = L"12345";
            string += secondString;

            string = L"12345";
            secondString = L"123456";
            UTF_CHECKASSERT(string += secondString);
		}
	}	
	END_UNITTEST
}
END_UNITTESTGROUP(StaticWideStringGroup)

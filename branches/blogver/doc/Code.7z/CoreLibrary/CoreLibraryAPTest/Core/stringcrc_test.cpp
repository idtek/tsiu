#include <UnitTesting.h>
#include <core/crc.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( StringCrcTestGroup )
{
	//Testing Base case of StringCRC Test
	BEGIN_UNITTEST(StringCrcBaseContructorDestructorTest)
	{
		// Normal constructor cases
		StringCRC crc0;
		UTF_CHECK( crc0.Value()== 0);

		StringCRC crcStr("Testing_Crc");
		UTF_CHECK( crcStr.Value() == 1524136894);

		StringCRC crc1(crcStr);
		UTF_CHECK(crc1.Value() == crcStr.Value());
	}
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(StringCrcFunctionalTest)
	{
		// Testing unconst version
		StringCRC c1("C1");
		StringCRC c2("C2");
		c1 = c2;
		UTF_CHECK(c1.Value() == c2.Value());

		UTF_CHECK(c1.Value() == c2.Value() && 
			      c1.Value() == c2 &&
				  c1 == c2.Value() &&
				  c1 == c2);

		const uint value = (const uint)c2;
		UTF_CHECK(value == c2.Value());
	
		c2 = "C3";
		UTF_CHECK(c2 != c1);

		c1.Set("C3");

#if CORE_DEBUG
		UTF_CHECK(StringCompare(c1.AsChar(), c2.AsChar(), StringCRC::kStringLength)==0)
#endif
		// Testing const version
		const StringCRC constC1("ConstC1");
		const StringCRC constC2("ConstC2");

		UTF_CHECK(constC1 !=constC2);
		const StringCRC constC3 = constC2;
		UTF_CHECK(constC3 == constC2);
#if CORE_DEBUG
		UTF_CHECK(StringCompare(constC3.AsChar(), constC2.AsChar(), StringCRC::kStringLength)==0)
#endif
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(StringCrcBoundaryTest)
	{
		// Boundary cases for constructor & destructor
		StringCRC crc(NULL);
		UTF_CHECK(crc.Value() == 0);
	
		StringCRC crc2 = NULL;
		UTF_CHECK(crc2.Value() == 0);

		crc.Set(NULL);
		UTF_CHECK(crc2.Value() == 0);

#if CORE_DEBUG
		const char* pChar = crc2.AsChar();
		UTF_CHECK(StringLength(pChar) == 0);
#endif
	}
	END_UNITTEST
}
END_UNITTESTGROUP( StringCrcTestGroup )

#include <UnitTesting.h>
#include <core/autopointer.h>

using namespace Axiom;

class IntObj
{
public:
	IntObj(int val):mValue(val){}
	int GetValue()const {return mValue;}
private:
	int mValue;
};

BEGIN_UNITTESTGROUP( AutoPointerTestGroup )
	{
		//Testing Base case of Autopointer Test
		BEGIN_UNITTEST(AutoPointerBaseContructorDestructorTest)
		{			
			AutoPointer<int> ptr0(AP_NEW(0,int()));
			AutoPointer<int> ptr1;
			int val = *ptr0;
			UTF_CHECK(val == *ptr0);

			ptr1 = ptr0;
			UTF_CHECK(val == *ptr1);

			AutoPointer<int> ptr3(ptr1);
			UTF_CHECK(ptr1 != ptr3);
		}
		END_UNITTEST


		// Test all other functional use
		BEGIN_UNITTEST(AutoPointerFunctionalTest)
		{
			IntObj *pVal = AP_NEW(0, IntObj(100));
			AutoPointer<IntObj> ptr1(pVal);
			AutoPointer<IntObj> ptr2(ptr1);

			UTF_CHECK(ptr1 != ptr2);

			if(ptr1 != ptr2)
			{
				*ptr2 = IntObj(1);
				UTF_CHECK(ptr2->GetValue()==1);
			}

			const int constVal = ptr2->GetValue();
			int noConstVal = ptr2->GetValue();
			UTF_CHECK(noConstVal == constVal);
			
			const AutoPointer<IntObj> constAuto(ptr2);
			int newVal = constAuto->GetValue();

			IntObj obj = *constAuto;
			UTF_CHECK(newVal ==obj.GetValue());

		}	
		END_UNITTEST

		// Test all boundary cases
		BEGIN_UNITTEST(AutoPointerBoundaryTest)
		{
			AutoPointer<IntObj> ptr(NULL);
			ptr = NULL;
			UTF_CHECKASSERT(ptr->GetValue());
						
			const AutoPointer<IntObj> ptrConst(NULL);
			UTF_CHECKASSERT(ptrConst->GetValue());

		}
		END_UNITTEST
	}
END_UNITTESTGROUP( AutoPointerTestGroup )

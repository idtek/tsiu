#include <UnitTesting.h>
#include <core/singleton.h>

using namespace Axiom;

class MySingleton: public Singleton<MySingleton>
{
public:

};

BEGIN_UNITTESTGROUP( SingletonTestGroup )
{
	//Testing Base case of Singleton Test
	BEGIN_UNITTEST(SingletonBaseContructorDestructorTest)
	{
		UTF_CHECK(!MySingleton::IsInit())
		UTF_CHECKASSERT(MySingleton::GetInstance());

		MySingleton::Init(Axiom::Memory::RESERVED_CORE_HEAP);

		UTF_CHECK(MySingleton::IsInit())
		UTF_CHECKASSERT(MySingleton::Init(Axiom::Memory::RESERVED_CORE_HEAP));
	}
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(SingletonFunctionalTest)
	{
		UTF_CHECK(MySingleton::IsInit())
	
		MySingleton* pSingleton = MySingleton::GetInstance();
		UTF_CHECK(pSingleton!=NULL);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(SingletonBoundaryTest)
	{
		UTF_CHECKASSERT(MySingleton::Init(Axiom::Memory::RESERVED_CORE_HEAP));
		MySingleton::Destroy();
		UTF_CHECKASSERT(MySingleton::Destroy());

	}
	END_UNITTEST
	}
END_UNITTESTGROUP( SingletonTestGroup )

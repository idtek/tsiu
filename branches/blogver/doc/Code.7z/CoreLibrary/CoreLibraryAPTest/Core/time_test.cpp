#include <UnitTesting.h>
#include <core/time.h>
#include <math/apmath.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( TimeTestGroup )
{
	//Testing Base case of Time Test
	BEGIN_UNITTEST(TimeBaseContructorDestructorTest)
	{
		// Quick destructor and constructor test!
		{
			// Normal Time
			Time time0;
			Time time2(time0);
			time2 = Time::CreateFromDays(1);
			
			UTF_CHECK(Math::EqualRelative(time2.AsFloatInMilliseconds(),24.f*60.f*60.f*1000.f));
			UTF_CHECK(Math::EqualRelative(time2.AsFloatInSeconds(),24.f*60.f*60.f));
			UTF_CHECK(Math::EqualRelative(time2.AsFloatInMinutes(),24.f*60.f));
			UTF_CHECK(Math::EqualRelative(time2.AsFloatInHours(),24.f));
			UTF_CHECK(Math::EqualRelative(time2.AsFloatInDays(), 1.f));

			UTF_CHECK(time2.AsIntInMilliseconds() == 24*60*60*1000);
			UTF_CHECK(time2.AsIntInSeconds() == 24*60*60);
			UTF_CHECK(time2.AsIntInMinutes() == 24*60);
			UTF_CHECK(time2.AsIntInHours() == 24);
			UTF_CHECK(time2.AsIntInDays() == 1);

			// Absolute Time
			TimeAbsolute absTime0;
			TimeAbsolute absTime1(absTime0);
			absTime1 = TimeAbsolute::CreateFromDays(1);
			
			UTF_CHECK(Math::EqualRelative(absTime1.AsFloatInMilliseconds(), 24.f*60.f*60.f*1000.f));
			UTF_CHECK(Math::EqualRelative(absTime1.AsFloatInSeconds(),24.f*60.f*60.f));
			UTF_CHECK(Math::EqualRelative(absTime1.AsFloatInMinutes(),24.f*60.f));
			UTF_CHECK(Math::EqualRelative(absTime1.AsFloatInHours(),24.f));
			UTF_CHECK(Math::EqualRelative(absTime1.AsFloatInDays(), 1.f));

			UTF_CHECK(absTime1.AsIntInMilliseconds() == 24*60*60*1000);
			UTF_CHECK(absTime1.AsIntInSeconds() == 24*60*60);
			UTF_CHECK(absTime1.AsIntInMinutes() == 24*60);
			UTF_CHECK(absTime1.AsIntInHours() == 24);
			UTF_CHECK(absTime1.AsIntInDays() == 1);
			UTF_CHECK(absTime1.AsPositiveTime().AsFloatInHours()>0.f);

			Timer timer;
			//TimeServer timeServer1;
			TimeServer timeServer2;

		}
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(TimeFunctionalTest)
	{
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		// Test Basic time functionality
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		Time time1 = Time::CreateFromDays(1);
		Time time2 = Time::CreateFromDays(1);

		Time time0 = Time::Zero();
		UTF_CHECK(Math::EqualRelative(time0.AsFloatInMilliseconds(),0));
		UTF_CHECK(time1.AsPositiveTime().AsFloatInMilliseconds()>=0.f);

		Time	dayInMilliFloat   	=	Time::CreateFromMilliseconds(24*60*60*1000);
		Time	dayInSecondFloat  	=	Time::CreateFromSeconds(24*60*60);
		Time	dayInMinutesFloat 	=	Time::CreateFromMinutes(24*60);
		Time	dayInHourFloat    	=	Time::CreateFromHours(24);
		Time	dayInDayFloat	  	=	Time::CreateFromDays(1);

		UTF_CHECK(Math::EqualRelative(dayInMilliFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(dayInSecondFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(dayInMinutesFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(dayInHourFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(dayInDayFloat.AsFloatInDays(),1.f));
		
		UTF_CHECK(dayInDayFloat == dayInMilliFloat);

		Time	dayInMilliInt   	=	Time::CreateFromMilliseconds(24.f*60.f*60.f*1000.f);
		Time	dayInSecondInt  	=	Time::CreateFromSeconds( 24*60*60);
		Time	dayInMinutesInt 	=	Time::CreateFromMinutes( 24*60);
		Time	dayInHourInt    	=	Time::CreateFromHours(24);
		Time	dayInDayInt			=	Time::CreateFromDays(1);

		UTF_CHECK(Math::EqualRelative(dayInMilliInt.AsFloatInDays(),1));
		UTF_CHECK(Math::EqualRelative(dayInSecondInt.AsFloatInDays(),1));
		UTF_CHECK(Math::EqualRelative(dayInMinutesInt.AsFloatInDays(),1));
		UTF_CHECK(Math::EqualRelative(dayInHourInt.AsFloatInDays(),1));
		UTF_CHECK(Math::EqualRelative(dayInDayInt.AsFloatInDays(),1));

		Time time3 = time1 + time2;
		UTF_CHECK(Math::EqualRelative(time3.AsFloatInDays(),2.f));

		Time zeroTime = time1 - time2;
		UTF_CHECK(Math::EqualRelative(zeroTime.AsFloatInMilliseconds(),0));

		zeroTime += time1;
		UTF_CHECK(Math::EqualRelative(zeroTime.AsFloatInDays(),1));
		zeroTime -= time1;
		UTF_CHECK(Math::EqualRelative(zeroTime.AsFloatInDays(),0));

		UTF_CHECK(time3>zeroTime || time3>= zeroTime );
		UTF_CHECK(zeroTime<time3 || zeroTime<=time3  );
		UTF_CHECK(zeroTime==Time::Zero());
		
		Time oneWeek = Time::CreateFromDays(7);
		float ratio = Time::CalculateRatio(dayInDayInt,oneWeek);
		UTF_CHECK(Axiom::Math::Equal(ratio,1.f/7.f));

		float sameRatio = dayInDayInt/oneWeek;
		UTF_CHECK(Axiom::Math::Equal(ratio,sameRatio));

		Time backToDay = oneWeek / 7.f;
		UTF_CHECK(Math::EqualRelative(backToDay.AsFloatInDays(),1));
		backToDay = oneWeek / 7;
		UTF_CHECK(Math::EqualRelative(backToDay.AsFloatInDays(),1));
	
		Time weekFrom7Days = dayInDayInt * 7;
		UTF_CHECK(Axiom::Math::EqualRelative(weekFrom7Days.AsFloatInDays(),7.f));
		weekFrom7Days = dayInDayInt * 7.f;
		UTF_CHECK(Math::EqualRelative(weekFrom7Days.AsFloatInDays(),7));

		Time accumTime = dayInDayInt;
		accumTime*=7.f;
		UTF_CHECK(Math::EqualRelative(accumTime.AsFloatInDays(),7.f));
		accumTime*=2;
		UTF_CHECK(Math::EqualRelative(accumTime.AsFloatInDays(),14.f));
		accumTime/=2;
		UTF_CHECK(Math::EqualRelative(accumTime.AsFloatInDays(),7.f));
		accumTime/=7.f;
		UTF_CHECK(Math::EqualRelative(accumTime.AsFloatInDays(),1.f));


		//////////////////////////////////////////////////////////////////////////////////////////////////////
		// Test absolute time functionality
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		TimeAbsolute absTime = TimeAbsolute::CreateFromMicroseconds(dayInDayInt.AsInt64InMicroseconds());
		UTF_CHECK(Math::EqualRelative(absTime.AsFloatInDays(),1.f));

		TimeAbsolute	absDayInMilliInt   	=	TimeAbsolute::CreateFromMilliseconds(24*60*60*1000);
		TimeAbsolute	absDayInSecondInt  	=	TimeAbsolute::CreateFromSeconds(24*60*60);
		TimeAbsolute	absDayInMinutesInt 	=	TimeAbsolute::CreateFromMinutes(24*60);
		TimeAbsolute	absDayInHourInt    	=	TimeAbsolute::CreateFromHours(24);
		TimeAbsolute	absDayInDayInt	  	=	TimeAbsolute::CreateFromDays(1);

		UTF_CHECK(absDayInMilliInt.AsIntInDays() == 1);
		UTF_CHECK(absDayInSecondInt.AsIntInDays() == 1);
		UTF_CHECK(absDayInMinutesInt.AsIntInDays() == 1);
		UTF_CHECK(absDayInHourInt.AsIntInDays() == 1);
		UTF_CHECK(absDayInDayInt.AsIntInDays() == 1);

		TimeAbsolute	absDayInMilliFloat   	=	TimeAbsolute::CreateFromMilliseconds(24.f*60.f*60.f*1000.f);
		TimeAbsolute	absDayInSecondFloat  	=	TimeAbsolute::CreateFromSeconds(24.f*60.f*60.f);
		TimeAbsolute	absDayInMinutesFloat 	=	TimeAbsolute::CreateFromMinutes(24.f*60.f);
		TimeAbsolute	absDayInHourFloat    	=	TimeAbsolute::CreateFromHours(24.f);
		TimeAbsolute	absDayInDayFloat	  	=	TimeAbsolute::CreateFromDays(1.f);

		UTF_CHECK(Math::EqualRelative(absDayInMilliFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(absDayInSecondFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(absDayInMinutesFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(absDayInHourFloat.AsFloatInDays(),1.f));
		UTF_CHECK(Math::EqualRelative(absDayInDayFloat.AsFloatInDays(),1.f));

		absTime = TimeAbsolute::Zero();
		UTF_CHECK(absTime == TimeAbsolute::Zero() && absTime.AsFloatInMilliseconds() == 0.f);

		absTime += dayInMilliInt;

		UTF_CHECK(absTime.AsFloatInDays()==1.f && absTime>=TimeAbsolute::Zero() && TimeAbsolute::Zero()<=absTime);
		UTF_CHECK(absTime != TimeAbsolute::CreateFromMilliseconds(10));
		UTF_CHECK( TimeAbsolute::CreateFromDays(0.9f) < absTime);
		UTF_CHECK( TimeAbsolute::CreateFromDays(1.1f) > absTime);

		absTime-=dayInMilliInt;
		UTF_CHECK(absTime.AsFloatInDays() == 0.f && absTime == TimeAbsolute::Zero());

		absTime = TimeAbsolute::Zero();

		TimeAbsolute newTime = absTime + dayInMilliInt;
		UTF_CHECK(newTime.AsFloatInDays()==1.f && newTime != TimeAbsolute::Zero());

		newTime = newTime - dayInMilliInt;
		UTF_CHECK(newTime.AsFloatInDays()==0.f );
		
		Time testTime = absTime - absTime;
		UTF_CHECK(testTime.AsFloatInDays()==0.f );
	}	
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(TimerFunctionalTest)
	{
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		// Test Timer class
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		Timer timer;
		timer.Start();

		const float oneOver60Sec = 1.f/60.f;
		const int numFrameTillError = 100000;// we may need to increase this for new firmware or hardware.

		int failTest = 0;
		while(timer.GetTime().AsFloatInSeconds() <=(oneOver60Sec))
		{
			if(failTest >= numFrameTillError)
				break;
			Axiom::Thread::Sleep(1000);
			//Sleep (0);
			failTest++;
		}


		timer.End();
		UTF_CHECK(failTest<=numFrameTillError);
		float value = timer.GetEndTime().AsFloatInSeconds();
		UTF_CHECK(value>=oneOver60Sec);


		//////////////////////////////////////////////////////////////////////////////////////////////////////
		// Test Timer class
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		const float freq = 60.0f;
		TimeServer timeServer;

		for(int i=0;i<static_cast<int>(freq);i++)
		{
			timeServer.Tick();
		}
		
		UTF_CHECK(Math::EqualRelative(timeServer.GetTime().AsFloatInSeconds(),TimeAbsolute::CreateFromSeconds(1.0f/freq).AsFloatInSeconds()*freq));
		//UTF_CHECK(Math::EqualRelative(timeServer.GetTimeStep().AsFloatInSeconds(),Time::CreateFromSeconds(1000.f/freq).AsFloatInSeconds()));

        const float scale = 0.5f;
        timeServer.Reset();
        timeServer.SetTimeScale(scale);

        for( int i = 0; i < static_cast<int>(freq); ++i )
        {
            timeServer.Tick();
        }

        UTF_CHECK(Math::EqualRelative(timeServer.GetTime().AsFloatInSeconds(), TimeAbsolute::CreateFromSeconds(1.0f/freq).AsFloatInSeconds()*freq*scale));
	}	
	END_UNITTEST


	// Test all boundary cases
	BEGIN_UNITTEST(TimeBoundaryTest)
	{
		// Testing normal time boundaries
		{
			Time time0 = Time::CreateFromDays(-1);
			UTF_CHECK(time0.AsFloatInMilliseconds()<0 && time0.AsFloatInDays()==-1);
			
			UTF_CHECKASSERT(Time::CalculateRatio(time0, Time::Zero()));

			UTF_CHECKASSERT(time0 / Time::Zero());
			UTF_CHECKASSERT(time0 / 0);
			UTF_CHECKASSERT(time0 / 0.f);
		
			UTF_CHECKASSERT(time0/= 0.f);
			UTF_CHECKASSERT(time0/= 0);
		}
	
		// Testing normal time boundaries
		{
			TimeAbsolute time0 = TimeAbsolute::CreateFromDays(-1);
			UTF_CHECK(time0.AsFloatInMilliseconds()<0 && time0.AsFloatInDays()==-1);

			UTF_CHECK(time0.AsPositiveTime().AsFloatInMilliseconds()>0.f);
		}
	}
	END_UNITTEST


	BEGIN_UNITTEST(TimerBoundaryTest)
	{
// 		TimeServer timeServer;
// 		UTF_CHECKASSERT(timeServer.Reset(0.f));
// 		UTF_CHECKASSERT(timeServer.GetTime());
// 		UTF_CHECKASSERT(timeServer.GetTimeStep());
	}
	END_UNITTEST
}
END_UNITTESTGROUP( TimeTestGroup )

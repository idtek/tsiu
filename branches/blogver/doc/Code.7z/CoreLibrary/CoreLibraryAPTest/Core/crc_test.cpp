#include <UnitTesting.h>
#include <core/crc.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( CrcTestGroup )
{
	//Testing Base case of CRC Test
	BEGIN_UNITTEST(CrcBaseContructorDestructorTest)
	{
		// Normal constructor cases
		CRC crc0;
		UTF_CHECK( crc0.Value()== 0);

		CRC crcStr("Testing_Crc");
		UTF_CHECK( crcStr.Value() == 1524136894);

		CRC crc1(crcStr);
		UTF_CHECK(crc1.Value() == crcStr.Value());

		int v[] = {1,1};
		CRC crc2(v,sizeof(int)*2);
#if CORE_WIN32
		UTF_CHECK( crc2.Value() == 288667794);
#else
		UTF_CHECK( crc2.Value() == 793101903);
		
#endif
	}
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(CrcFunctionalTest)
	{
		// = operator test
		CRC c1("C1");
		CRC c2("C2");
		c1 = c2;
		UTF_CHECK(c1 == c2);
		
		c2 = "C2";
		UTF_CHECK(c1.Value() == c2 && c1 == c2.Value());
		
		const uint value = (const uint)c2;

		UTF_CHECK(value == c2.Value());
	}	
	END_UNITTEST
	
	BEGIN_UNITTEST(CrcIntegerAssignmentCaseTest)
	{
		// = operator test
		CRC c1; 		
		CRC c2 ("SRCH");

		unsigned int TestValue = 1337;

#if CORE_WIN32 == CORE_YES
		TestValue = 1212371539;//htonl ('SRCH');
#else

#endif
		c1 = TestValue;

		UTF_CHECK(c1 == TestValue);

		c1 = 31337;

		UTF_CHECK(c1 != TestValue);

	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(CrcBoundaryTest)
	{
		// Boundary cases for constructor & destructor
		char* ptr = NULL;
		CRC crc(ptr);
		UTF_CHECK(crc.Value() == 0);

		CRC crc1(NULL, 0);
		UTF_CHECK(crc1.Value() == 0);

		CRC crc2 = "";
		UTF_CHECK(crc2.Value() == 0);

	}
	END_UNITTEST
}
END_UNITTESTGROUP( CrcTestGroup )

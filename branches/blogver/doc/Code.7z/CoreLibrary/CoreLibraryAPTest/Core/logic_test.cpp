#include <UnitTesting.h>
#include <core/crc.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( LogicTestGroup )
{
	// Test all other functional use
	BEGIN_UNITTEST(LogicFunctionalTest)
	{
		bool b = Bool2Type<true>::Type::value;
		UTF_CHECK(b == true);
		b = Bool2Type<false>::Type::value;
		UTF_CHECK(b == false);
		
		b = Type2Bool<int>();
		UTF_CHECK(b == false);
		b = Type2Bool<true_t>();
		UTF_CHECK(b == true);

		b=MetaOr<false, false>::value;
		UTF_CHECK(b == false);
		b=MetaOr<false, true>::value;
		UTF_CHECK(b == true);
		b=MetaOr<true, true>::value;
		UTF_CHECK(b == true);

		b=MetaAnd<false, false>::value;
		UTF_CHECK(b == false);
		b=MetaAnd<false, true>::value;
		UTF_CHECK(b == false);
		b=MetaAnd<true, true>::value;
		UTF_CHECK(b == true);

		b=MetaNot<false>::value;
		UTF_CHECK(b == true);
		b=MetaNot<true>::value;
		UTF_CHECK(b == false);
	
		b = MetaIf<true,true_t, false_t>::Type::value;
		UTF_CHECK(b == true);

		b = MetaIf<false,true_t, false_t>::Type::value;
		UTF_CHECK(b == false);

	}
	END_UNITTEST
}
END_UNITTESTGROUP( LogicTestGroup )

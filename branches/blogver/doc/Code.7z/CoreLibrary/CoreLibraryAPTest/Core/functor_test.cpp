#include <UnitTesting.h>
#include <core/functor.h>

using namespace Axiom;


const int ID_A0 = 0;
const int ID_A1 = 10;
const int ID_B = 100;
const int ID_C = 200;
const int ID_D = 300;
const int ID_STATIC = 10000;


// the virtual d'tors here are not strictly necessary, but do reduce compiler warnings.
class A0
{
public:
	A0(){}
	virtual ~A0(){}

	virtual int GetId(){return ID_A0;}
};

class A1
{
public:
	A1(){}
	virtual ~A1(){}
	
	virtual int GetOtherId(){return ID_A1;}
};

class B: public A0
{
public:
	B():A0(){}
	virtual ~B(){}

	virtual int GetId(){return ID_B;}
};


class C: public A0, public A1
{
public:
	C():A0(), A1(){}
	virtual ~C(){}

	int GetId(){return ID_C;}
	int GetOtherId(){return ID_C;}
};

// Static function
int TestGetId()
{
	return ID_STATIC;
}

class TestAllParam
{
public:
	int GetId1(int a){ return a;}
	int GetId2(int a, int b){ return a+b;}
	int GetId3(int a, int b, int c){ return a+b+c;}
	int GetId4(int a, int b, int c,int d){ return a+b+c+d;}
	int GetId5(int a, int b, int c,int d, int e){ return a+b+c+d+e;}
	int GetId6(int a, int b, int c,int d, int e,int f){ return a+b+c+d+e+f;}
	int GetId7(int a, int b, int c,int d, int e,int f,int g){ return a+b+c+d+e+f+g;}
	int GetId8(int a, int b, int c,int d, int e,int f,int g,int h){ return a+b+c+d+e+f+g+h;}
	int GetId9(int a, int b, int c,int d, int e,int f,int g,int h, int i){ return a+b+c+d+e+f+g+h+i;}
	int GetId10(int a, int b, int c,int d, int e,int f,int g,int h, int i,int j){ return a+b+c+d+e+f+g+h+i+j;}
	int GetId11(int a, int b, int c,int d, int e,int f,int g,int h, int i,int j, int k){ return a+b+c+d+e+f+g+h+i+j+k;}

};

typedef Delegate<int ()>	DelegateType0;
typedef Axiom::Delegate<int (int)>	DelegateType1;
typedef Axiom::Delegate<int (int,int)>	DelegateType2;
typedef Axiom::Delegate<int (int,int,int)>	DelegateType3;
typedef Axiom::Delegate<int (int,int,int,int)>	DelegateType4;
typedef Axiom::Delegate<int (int,int,int,int,int)>	DelegateType5;
typedef Axiom::Delegate<int (int,int,int,int,int,int)>	DelegateType6;
typedef Axiom::Delegate<int (int,int,int,int,int,int,int)>	DelegateType7;
typedef Axiom::Delegate<int (int,int,int,int,int,int,int,int)>	DelegateType8;
typedef Axiom::Delegate<int (int,int,int,int,int,int,int,int,int)>	DelegateType9;
typedef Axiom::Delegate<int (int,int,int,int,int,int,int,int,int,int)>	DelegateType10;
typedef Axiom::Delegate<int (int,int,int,int,int,int,int,int,int,int,int)>	DelegateType11;

BEGIN_UNITTESTGROUP( FunctorTestGroup )
{
	//Testing Base case of Functor Test
	BEGIN_UNITTEST(FunctorBaseContructorDestructorTest)
	{
		// Test construction of delegate
		{
			A0 testClass;
			DelegateType0 myFunctor0;
			myFunctor0.Bind(&testClass, &A0::GetId);

			DelegateType0 myFunctor1(myFunctor0);
			UTF_CHECK(myFunctor0() == myFunctor1());
			
			DelegateType0 myFunctor2(&testClass, &A0::GetId);
			UTF_CHECK(myFunctor0() == myFunctor2());

		}
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(FunctorFunctionalTest)
	{
		// Test class with no inheritance 
		{
			A0 classA0;
			A0 classA1;

			DelegateType0 myFunctor0;
			myFunctor0.Bind(&classA0, &A0::GetId);
			UTF_CHECK(myFunctor0() == ID_A0);

			DelegateType0 myFunctor1;
			myFunctor1=myFunctor0;
			UTF_CHECK(myFunctor0 == myFunctor1);
			UTF_CHECK(myFunctor0() == myFunctor1());

			DelegateType0 myFunctor2;
			myFunctor2.Bind(&classA1, &A0::GetId);
			UTF_CHECK(myFunctor2() == ID_A0);
			UTF_CHECK(myFunctor2 != myFunctor1);

#if CORE_WIN32 || CORE_WII
			UTF_CHECK(myFunctor2 < myFunctor1);
			UTF_CHECK(myFunctor1 > myFunctor2);
#else
			UTF_CHECK(myFunctor2 > myFunctor1);
			UTF_CHECK(myFunctor1 < myFunctor2);
#endif
		}

		// Test class with single inheritance
		{
			B classB0;
			DelegateType0 myFunctor1;
			myFunctor1.Bind(&classB0, &B::GetId);
			UTF_CHECK(myFunctor1() == ID_B);

			DelegateType0 myFunctor2;
			myFunctor2.Bind(&classB0, &A0::GetId);
			UTF_CHECK(myFunctor2() == ID_B);
		}

		// Test class with multiple inheritance
		{
			C classC;
			DelegateType0 myFunctor0(&classC, &C::GetId);
			UTF_CHECK(myFunctor0() == ID_C);

			DelegateType0 myFunctor1(&classC, &A0::GetId);
			UTF_CHECK(myFunctor1() == ID_C);

			const DelegateType0 myFunctor2(&classC, &A1::GetOtherId);
			UTF_CHECK(myFunctor2() == ID_C);

			const DelegateType0 myFunctor3(&classC, &A1::GetOtherId);
			UTF_CHECK(myFunctor3() == ID_C);

			const DelegateType0 myFunctor4(myFunctor3);
			UTF_CHECK(myFunctor3() == ID_C);
		}
	
		// Test static function delegate
		{
			DelegateType0 myFuctor0(TestGetId);
			UTF_CHECK(myFuctor0() == ID_STATIC);
			
			const DelegateType0 myFuctor1 = TestGetId;
			UTF_CHECK(myFuctor1() == ID_STATIC);

			DelegateType0 myFuctor2;
			myFuctor2.Bind(TestGetId);
			UTF_CHECK(myFuctor2() == ID_STATIC);
		}

		// Test all params up to 11 params
		{
			TestAllParam allClass;
			DelegateType1 f1(&allClass, &TestAllParam::GetId1);
			UTF_CHECK(f1(1) == 1);

			DelegateType2 f2(&allClass, &TestAllParam::GetId2);
			UTF_CHECK(f2(1,1) == 2);

			DelegateType3 f3(&allClass, &TestAllParam::GetId3);
			UTF_CHECK(f3(1,1,1) == 3);

			DelegateType4 f4(&allClass, &TestAllParam::GetId4);
			UTF_CHECK(f4(1,1,1,1) == 4);

			DelegateType5 f5(&allClass, &TestAllParam::GetId5);
			UTF_CHECK(f5(1,1,1,1,1) == 5);

			DelegateType6 f6(&allClass, &TestAllParam::GetId6);
			UTF_CHECK(f6(1,1,1,1,1,1) == 6);

			DelegateType7 f7(&allClass, &TestAllParam::GetId7);
			UTF_CHECK(f7(1,1,1,1,1,1,1) == 7);

			DelegateType8 f8(&allClass, &TestAllParam::GetId8);
			UTF_CHECK(f8(1,1,1,1,1,1,1,1) == 8);

			DelegateType9 f9(&allClass, &TestAllParam::GetId9);
			UTF_CHECK(f9(1,1,1,1,1,1,1,1,1) == 9);

			DelegateType10 f10(&allClass, &TestAllParam::GetId10);
			UTF_CHECK(f10(1,1,1,1,1,1,1,1,1,1) == 10);

			DelegateType11 f11(&allClass, &TestAllParam::GetId11);
			UTF_CHECK(f11(1,1,1,1,1,1,1,1,1,1,1) == 11);

		}
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(FunctorBoundaryTest)
	{
		C classC;
		DelegateType0 myFunctor0;

		UTF_CHECKASSERT(myFunctor0.Bind(NULL));

		// There's seems to be issues with UTF_CHECKASSERT not working with Template code and construction of classes
		// So can't test this
		//UTF_CHECKASSERT(myFunctor0 = DelegateType0(NULL,&A0::GetId));
		//UTF_CHECKASSERT(DelegateType0 myFuctor0(NULL));
		
	}
	END_UNITTEST
}
END_UNITTESTGROUP( FunctorTestGroup )

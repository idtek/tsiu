//====================================================================
//
//!	@file 	core_group.cpp
//!	@brief	Master group for Core unit tests
//
//	created:	5:25:2007
//	author:		duongh
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include "unittesting.h"

// Declare all test
DECLARE_UNITTESTGROUP(AutoPointerTestGroup)
DECLARE_UNITTESTGROUP(BitArrayTestGroup)
DECLARE_UNITTESTGROUP(ClassEnumPointerTestGroup)
DECLARE_UNITTESTGROUP(CrcTestGroup)
DECLARE_UNITTESTGROUP(DataPoolTestGroup)
DECLARE_UNITTESTGROUP(FunctorTestGroup)
DECLARE_UNITTESTGROUP(GltUtilsTestGroup)
DECLARE_UNITTESTGROUP(HandleTestGroup)
DECLARE_UNITTESTGROUP(LogicTestGroup)
DECLARE_UNITTESTGROUP(ReferencedTestGroup)
DECLARE_UNITTESTGROUP(SerializerTestGroup)
DECLARE_UNITTESTGROUP(SingletonTestGroup)
DECLARE_UNITTESTGROUP(SmartPtrTestGroup)
DECLARE_UNITTESTGROUP(StringTestGroup)
DECLARE_UNITTESTGROUP(StringCrcTestGroup)
DECLARE_UNITTESTGROUP(TimeTestGroup)
DECLARE_UNITTESTGROUP(TypesTestGroup)
DECLARE_UNITTESTGROUP(TypeTraitsTestGroup)
DECLARE_UNITTESTGROUP(StaticStringGroup)
DECLARE_UNITTESTGROUP(StaticWideStringGroup)


// Declare Groups
BEGIN_UNITTESTGROUP(CoreGroup)
{
	RUN_UNITTESTSUBGROUP(AutoPointerTestGroup)
	RUN_UNITTESTSUBGROUP(BitArrayTestGroup)
	RUN_UNITTESTSUBGROUP(ClassEnumPointerTestGroup)
	RUN_UNITTESTSUBGROUP(CrcTestGroup)
	RUN_UNITTESTSUBGROUP(DataPoolTestGroup)
	RUN_UNITTESTSUBGROUP(FunctorTestGroup)
	RUN_UNITTESTSUBGROUP(GltUtilsTestGroup)
	RUN_UNITTESTSUBGROUP(HandleTestGroup)
	RUN_UNITTESTSUBGROUP(LogicTestGroup)
	RUN_UNITTESTSUBGROUP(ReferencedTestGroup)
	RUN_UNITTESTSUBGROUP(SerializerTestGroup)
	RUN_UNITTESTSUBGROUP(SingletonTestGroup)
	RUN_UNITTESTSUBGROUP(SmartPtrTestGroup)
	RUN_UNITTESTSUBGROUP(StringTestGroup)
	RUN_UNITTESTSUBGROUP(StaticStringGroup)
	RUN_UNITTESTSUBGROUP(StaticWideStringGroup)
	RUN_UNITTESTSUBGROUP(StringCrcTestGroup)
	RUN_UNITTESTSUBGROUP(TimeTestGroup)
	RUN_UNITTESTSUBGROUP(TypesTestGroup)
	RUN_UNITTESTSUBGROUP(TypeTraitsTestGroup)
}
END_UNITTESTGROUP(CoreGroup)


#include <UnitTesting.h>
#include <core/system.h>
#include <core/typetraits.h>

using namespace Axiom;

// Enum test
enum TestEnum
{
	TE_A,
	TE_B,
	TE_C
};

// Test abstract class
class TestAbstractClass
{
public:
	virtual void ImplementThis() =0;

private:
	TestAbstractClass(){}
	virtual ~TestAbstractClass() {}
};

// Class with non-trivial constructor
class TestClass
{
public:
	typedef void (*MemFuncType)();
	TestClass(int val):mValue(val){}

	TestClass(){}
	virtual ~TestClass(){}

	TestClass(const TestClass &newObj){ mValue = newObj.mValue;}
	TestClass& operator=(const TestClass& obj){ mValue = obj.mValue; return *this;}

	void TestMember(){}
private:
	int mValue;
};

// Class with trivial constructor
class TestClassBasic
{
private:
	int mValue;
};

// Test pod
struct TestPodStruct
{
};

// Test union
union TestUnion
{
	int ix;	
	float fx;	
};

// Test type compare with addReference and removeReference
template<typename T, typename U> 
struct IsTypeEqual
{
	static const bool value = false;
};

template<typename T> 
struct IsTypeEqual<T,T>
{
	static const bool value = true;
};


BEGIN_UNITTESTGROUP( TypeTraitsTestGroup )
{
#if CORE_VISUALC
	//Testing Base case of typetraits Test
	BEGIN_UNITTEST(HasTrivialConstructorTest)
	{
		// trivial contructor test
		bool b = HasTrivialConstructor<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasTrivialConstructor<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasTrivialCopyTest)
	{
		// Test copy constructor
		bool b = HasTrivialCopy<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasTrivialCopy<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasTrivialAssignTest)
	{
		bool b = HasTrivialAssign<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasTrivialAssign<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasTrivialDestructorTest)
	{
		bool b = HasTrivialDestructor<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasTrivialDestructor<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasNoThrowCopyTest)
	{
		bool b = HasNoThrowCopy<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasNoThrowCopy<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasNoThrowConstructorTest)
	{
		bool b = HasNoThrowConstructor<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasNoThrowConstructor<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasNoThrowAssignTest)
	{
		bool b = HasNoThrowAssign<TestClassBasic>::value;
		UTF_CHECK(b);
		b = HasNoThrowAssign<TestClass>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(HasVirtualDestructorTest)
	{
		bool b = HasVirtualDestructor<TestClassBasic>::value;
		UTF_CHECK(!b);
		b = HasVirtualDestructor<TestClass>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST
	
	BEGIN_UNITTEST(IsUnionTest)
	{
		bool b = IsUnion<int>::value;
		UTF_CHECK(!b);
		b = IsUnion<TestUnion>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsPodTest)
	{
		bool b = IsPod<TestClass>::value;
		UTF_CHECK(!b);
		b = IsPod<TestPodStruct>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST
#endif // CORE_VISUALC

	BEGIN_UNITTEST(IsVoidTest)
	{
		bool b = IsVoid<int>::value;
		UTF_CHECK(!b);
		b = IsVoid<void>::value;
		UTF_CHECK(b);
		b = IsVoid<void const>::value;
		UTF_CHECK(b);
		b = IsVoid<void volatile>::value;
		UTF_CHECK(b);
		b = IsVoid<void const volatile>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsIntegralTest)
	{
		bool b = IsIntegral<TestClass>::value;
		UTF_CHECK(!b);
		b = IsIntegral<unsigned char>::value;
		UTF_CHECK(b);
		b = IsIntegral<unsigned short>::value;
		UTF_CHECK(b);
		b = IsIntegral<unsigned int>::value;
		UTF_CHECK(b);
		b = IsIntegral<unsigned long>::value;
		UTF_CHECK(b);
		b = IsIntegral<signed char>::value;
		UTF_CHECK(b);
		b = IsIntegral<signed short>::value;	
		UTF_CHECK(b);
		b = IsIntegral<signed int>::value;
		UTF_CHECK(b);
		b = IsIntegral<signed long>::value;
		UTF_CHECK(b);
		UTF_CHECK(b);
		b = IsIntegral<bool>::value;	
		UTF_CHECK(b);
		b = IsIntegral<char>::value;		
		UTF_CHECK(b);
		b = IsIntegral<wchar_t>::value;	
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsFloatTest)
	{
		bool b = IsFloat<float>::value;
		UTF_CHECK(b);
		b = IsFloat<double>::value;
		UTF_CHECK(b);
		b = IsFloat<long double>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsArithmeticTest)
	{
		bool b = IsArithmetic<TestClass>::value;
		UTF_CHECK(!b);	
		b = IsArithmetic<float>::value;
		UTF_CHECK(b);
		b = IsArithmetic<int>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsReferenceTest)
	{
		bool b = IsReference<int&>::value;
		UTF_CHECK(b);
		b = IsReference<int>::value;
		UTF_CHECK(!b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsArrayTest)
	{
		bool b = IsArray<int>::value;
		UTF_CHECK(!b);
		b = IsArray<int[100]>::value;
		UTF_CHECK(b);
		b = IsArray<const int[100]>::value;
		UTF_CHECK(b);
		b = IsArray<volatile int[100]>::value;
		UTF_CHECK(b);
		b = IsArray<const volatile int[100]>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsClassTest)
	{
		bool b = IsClass<int>::value;
		UTF_CHECK(!b);
		b = IsClass<TestClass>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsAbstractTest)
	{
		bool b = IsAbstract<int>::value;
		UTF_CHECK(!b);
		b = IsAbstract<TestClass>::value;
		UTF_CHECK(!b);
		b = IsAbstract<TestAbstractClass>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsConvertibleTest)
	{
		bool b = IsConvertible<int, TestAbstractClass>::value;
		UTF_CHECK(!b);
		b = IsConvertible<int, float>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsEnumTest)
	{
		bool b = IsEnum<int>::value;
		UTF_CHECK(!b);
		b= IsEnum<TestEnum>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsPointerTest)
	{
		bool b = IsPointer<int>::value;
		UTF_CHECK(!b);
		b = IsPointer<int*>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsScalarTest)
	{
		bool b = IsScalar<TestClass>::value;
		UTF_CHECK(!b);
		b = IsScalar<int>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsConstTest)
	{
		bool b = IsConstant<TestClass>::value;
		UTF_CHECK(!b);
		b = IsConstant<const int>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST

	BEGIN_UNITTEST(IsTypeEqualTest)
	{
		bool b = IsTypeEqual<float&, AddReference<int>::Type>::value;
		UTF_CHECK(!b);
		b = IsTypeEqual<int&, AddReference<int>::Type>::value;
		UTF_CHECK(b);

		b = IsTypeEqual<int&, RemoveReference<int&>::Type>::value;
		UTF_CHECK(!b);
		b = IsTypeEqual<int, RemoveReference<int&>::Type>::value;
		UTF_CHECK(b);
	}
	END_UNITTEST
}
END_UNITTESTGROUP( TypeTraitsTestGroup )

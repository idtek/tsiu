#include <UnitTesting.h>
#include <core/types.h>

using namespace Axiom;

template<typename T, typename U>
struct IsEqualType
{
	static const bool Value = false;
};

template<typename T>
struct IsEqualType<T,T>
{
	static const bool Value = true;
};


typedef IntegralConstant<uint, 0>				Zero_t;
typedef IntegralConstant<uint, 4294967295ul>	Inifinit_t;

typedef IntegralConstant<bool, true>			True_t;
typedef IntegralConstant<bool, false>			False_t;
typedef TypeConstant<bool>						Bool_t;


BEGIN_UNITTESTGROUP( TypesTestGroup )
{
	//Testing Base case of Types Test
	BEGIN_UNITTEST(TypesBaseContructorDestructorTest)
	{
		bool b = IsEqualType<True_t::ValueType,False_t::ValueType>::Value;
		UTF_CHECK(b);

		b = IsEqualType<True_t::Type,False_t::Type>::Value;
		UTF_CHECK(b== false);

		b = IsEqualType<True_t::ValueType,True_t::ValueType>::Value;
		UTF_CHECK(b== true);
	}
	END_UNITTEST


	// Test all other functional use
	BEGIN_UNITTEST(TypesFunctionalTest)
	{
		// Not much to test with these types
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(TypesBoundaryTest)
	{
		// Not much to test with these types
	}
	END_UNITTEST
}
END_UNITTESTGROUP( TypesTestGroup )

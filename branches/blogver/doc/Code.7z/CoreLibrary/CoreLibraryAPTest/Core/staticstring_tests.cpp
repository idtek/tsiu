// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	staticstring_tests.cpp
//!	@brief	Unit tests for the StaticString Class
//
//	created:	5:25:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include "unittesting.h"
#include "string/string.h"

using namespace AP::UnitTestingFramework;

DECLARE_UNITTESTGROUP(ConstructorDeconstructorGroup)
DECLARE_UNITTESTGROUP(FunctionalTestGroup)
DECLARE_UNITTESTGROUP(FunctionalFindTestGroup)
DECLARE_UNITTESTGROUP(FunctionalFileStringTestGroup)
DECLARE_UNITTESTGROUP(BoundaryTestGroup)


BEGIN_UNITTESTGROUP(StaticStringGroup)
{
	RUN_UNITTESTSUBGROUP(ConstructorDeconstructorGroup);
	RUN_UNITTESTSUBGROUP(FunctionalTestGroup);
	RUN_UNITTESTSUBGROUP(FunctionalFindTestGroup);
	RUN_UNITTESTSUBGROUP(FunctionalFileStringTestGroup);
	RUN_UNITTESTSUBGROUP(BoundaryTestGroup);
}
END_UNITTESTGROUP(StaticStringGroup)

// --------------------------------------------------------------------------

BEGIN_UNITTESTGROUP(ConstructorDeconstructorGroup)
{

	BEGIN_UNITTEST(UnboundedEmptyConstruction)
    {
		using Axiom::StaticString;
		StaticString <> string;
		UTF_CHECK(string == "");
		UTF_CHECK(string.IsEmpty() == true);
		UTF_CHECK(string.Length() == 0);

		StaticString <10> string2;
		UTF_CHECK(string2 == "");
		UTF_CHECK(string2.IsEmpty() == true);
		UTF_CHECK(string2.Length() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringEmptyConstruction)
	{
		using Axiom::ShortString;
		ShortString string;
		UTF_CHECK(string == "");
		UTF_CHECK(string.IsEmpty() == true);
		UTF_CHECK(string.Length() == 0);
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringConstruction)
	{
		using Axiom::ShortString;
		ShortString string = ShortString("thing");
		UTF_CHECK(string.IsEmpty() == false);
		UTF_CHECK(string.Length() == 5);
		UTF_CHECK(string == "thing");
		UTF_CHECK(!(string == "banana"));
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringConstructionFromAnotherEmptyString)
	{
		using Axiom::ShortString;
		ShortString string;
		ShortString string2 = string;
		UTF_CHECK(string2 == "");
		UTF_CHECK(string2.IsEmpty() == true);
		UTF_CHECK(string2.Length() == 0);
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringConstructionFromInt)
	{
		using Axiom::ShortString;
		ShortString string = ShortString(128);
		UTF_CHECK(string.IsEmpty() == false);
		UTF_CHECK(string.Length() == 3);
		UTF_CHECK(string == "128");
		UTF_CHECK(!(string == "banana"));
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringConstructionFromAssignment)
	{
		using Axiom::ShortString;
		{
			ShortString string = "thing";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 5);
			UTF_CHECK(string == "thing");
			UTF_CHECK(!(string == "banana"));

			ShortString	string2 = ShortString(string);
			UTF_CHECK(string2.IsEmpty() == false);
			UTF_CHECK(string2.Length() == 5);
			UTF_CHECK(string2 == "thing");
			UTF_CHECK(!(string2 == "banana"));
		}
		{
			ShortString string("testing constructor 12345", 19);
			UTF_CHECK(string == "testing constructor");
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringConstructionFromChar)
	{
		using Axiom::ShortString;
		{
			ShortString string = ShortString("x");
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			UTF_CHECK(string == "x");
			UTF_CHECK(string == "x");
		}

		{
			ShortString string = "y";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			UTF_CHECK(string == "y");
			UTF_CHECK(string == "y");
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(FileStringEmptyConstruction)
	{
		using Axiom::FileString;
		FileString fileString;
		UTF_CHECK(fileString == "");
		UTF_CHECK(fileString.IsEmpty() == true);
		UTF_CHECK(fileString.Length() == 0);
	}	
	END_UNITTEST

	BEGIN_UNITTEST(FileStringConstruction)
	{
		using Axiom::FileString;
		{
			FileString string = FileString("thing");
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 5);
			UTF_CHECK(string == "thing");
			UTF_CHECK(!(string == "banana"));
		}
		{
			FileString string("testing constructor 12345", 19);
			UTF_CHECK(string == "testing constructor");
		}
	}	
	END_UNITTEST

	BEGIN_UNITTEST(FileStringConstructionFromInt)
	{
		using Axiom::FileString;
		FileString string = FileString(128);
		UTF_CHECK(string.IsEmpty() == false);
		UTF_CHECK(string.Length() == 3);
		UTF_CHECK(string == "128");
		UTF_CHECK(!(string == "banana"));
	}	
	END_UNITTEST

	BEGIN_UNITTEST(FileStringConstructionFromChar)
	{
		using Axiom::FileString;
		{
			FileString string = FileString("x");
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			UTF_CHECK(string == "x");
			UTF_CHECK(string == "x");
		}

		{
			FileString string = "y";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			UTF_CHECK(string == "y");
			UTF_CHECK(string == "y");
		}
	}
	END_UNITTEST

}
END_UNITTESTGROUP(ConstructorDeconstructorGroup)


BEGIN_UNITTESTGROUP(FunctionalTestGroup)
{
	BEGIN_UNITTEST(ShortStringTests)
	{
		using Axiom::ShortString;
		{
			ShortString string("thing");
			ShortString string2 = "thing";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 5);
			UTF_CHECK(string == "thing");
			UTF_CHECK((string != "banana"));
			UTF_CHECK(!(string != "thing"));
			UTF_CHECK(string == string2);

			string2 = "banana";
			UTF_CHECK(string != string2);

			const char* rawStr = string.AsChar();
			UTF_CHECK(Axiom::StringCompare(rawStr, "thing", 5) == 0);

			ShortString left = string.Left(3);
			UTF_CHECK( left == "thi" );
			UTF_CHECK(string.Right(3) == "ing");

			string[2] = 'o';
			UTF_CHECK(string == "thong");

			string.ToUpper();
			UTF_CHECK(string == "THONG");

			string.ToLower();
			UTF_CHECK(string == "thong");

			ShortString string3 = string2 +" "+ string;
			UTF_CHECK(string3 == "banana thong");

			string += string2;
			UTF_CHECK(string == "thongbanana");

			string += ShortString(32);
			UTF_CHECK(string == "thongbanana32");

			// more Substring access:
			string3 = "banana tiny thong";
			ShortString mid = string3.SubString(7, 4);
			UTF_CHECK(mid == "tiny");
			UTF_CHECK(string3 == "banana tiny thong");

			mid = string3.SubString(3, 9);
			UTF_CHECK(mid == "ana tiny ");
			UTF_CHECK(string3 == "banana tiny thong");

			// destructive substring stuff
			{
				// Trim tests:
				ShortString string = "test this string thing";
				string.Trim(0,5);
				UTF_CHECK(string == "this string thing");
			}
			{
				ShortString string = "test this string thing";
				string.Trim(5,5);
				UTF_CHECK(string == "test string thing");
			}
			{
				ShortString string = "test this string thing";
				string.Trim(17,5);
				UTF_CHECK(string == "test this string ");
			}
		}

		// Scoping tests.  make sure that returned values are still good after the original goes out of scope:
		BEGIN_UNITTEST(ScopedTests)
		{
			ShortString left;
			ShortString right;
			ShortString mid;
			{
				ShortString string = "test string here.";
				left = string.Left(4);
				right = string.Right(5);
				mid = string.SubString(5, 6);

				UTF_CHECK(left == "test");
				UTF_CHECK(right == "here.");
				UTF_CHECK(mid == "string");
			}
			// verify these are still valid:
			UTF_CHECK(left == "test");
			UTF_CHECK(right == "here.");
			UTF_CHECK(mid == "string");
		}
		END_UNITTEST

		BEGIN_UNITTEST(OperatorTests)
		{
			ShortString string1 = "apple";
			ShortString string2 = "orange";
			ShortString string3 = "apple";
			ShortString string4 = "orange";

			UTF_CHECK(string1 < string2);
			UTF_CHECK(string2 > string1);
			UTF_CHECK(string1 == string3);
			UTF_CHECK(string1 != string2);
			UTF_CHECK(string1 <= string2);
			UTF_CHECK(string1 <= string3);
			UTF_CHECK(string2 >= string1);
			UTF_CHECK(string2 >= string4);

			UTF_CHECK(string1 < "orange");
			UTF_CHECK(string2 > "apple");
			UTF_CHECK(string1 == "apple");
			UTF_CHECK(string1 != "banana");
			UTF_CHECK(string1 <= "orange");
			UTF_CHECK(string1 <= "apple");
			UTF_CHECK(string2 >= "apple");
			UTF_CHECK(string2 >= "orange");
		}
		END_UNITTEST
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringAssignToNULLOfPreviouslyAssignedString)
	{
		using Axiom::ShortString;
		ShortString string = "Hello";
		string = "";// this failed in production code, hence we added this test.

		UTF_CHECK(string == "");
		UTF_CHECK(string.IsEmpty() == true);
		UTF_CHECK(string.Length() == 0);
	}	
	END_UNITTEST
}
END_UNITTESTGROUP(FunctionalTestGroup)

BEGIN_UNITTESTGROUP(FunctionalFileStringTestGroup)
{
	BEGIN_UNITTEST(FileStringTests)
	{
		using Axiom::FileString;
		{
			FileString string("thing");
			FileString string2 = "thing";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 5);
			UTF_CHECK(string == "thing");
			UTF_CHECK((string != "banana"));
			UTF_CHECK(!(string != "thing"));
			UTF_CHECK(string == string2);

			string2 = "banana";
			UTF_CHECK(string != string2);

			const char* rawStr = string.AsChar();
			UTF_CHECK(Axiom::StringCompare(rawStr, "thing", 5) == 0);

			FileString left = string.Left(3);
			UTF_CHECK( left == "thi" );
			UTF_CHECK(string.Right(3) == "ing");

			string[2] = 'o';
			UTF_CHECK(string == "thong");

			string.ToUpper();
			UTF_CHECK(string == "THONG");

			string.ToLower();
			UTF_CHECK(string == "thong");

			FileString string3 = string2 +" "+ string;
			UTF_CHECK(string3 == "banana thong");

			string += string2;
			UTF_CHECK(string == "thongbanana");

			string += FileString(32);
			UTF_CHECK(string == "thongbanana32");

			// more Substring access:
			string3 = "banana tiny thong";
			FileString mid = string3.SubString(7, 4);
			UTF_CHECK(mid == "tiny");
			UTF_CHECK(string3 == "banana tiny thong");

			mid = string3.SubString(3, 9);
			UTF_CHECK(mid == "ana tiny ");
			UTF_CHECK(string3 == "banana tiny thong");

			// destructive substring stuff
			// destructive substring stuff
			{
				// Trim tests:
				FileString string = "test this string thing";
				string.Trim(0,5);
				UTF_CHECK(string == "this string thing");
			}
			{
				FileString string = "test this string thing";
				string.Trim(5,5);
				UTF_CHECK(string == "test string thing");
			}
			{
				FileString string = "test this string thing";
				string.Trim(17,5);
				UTF_CHECK(string == "test this string ");
			}
		}

		// Scoping tests.  make sure that returned values are still good after the original goes out of scope:
		BEGIN_UNITTEST(ScopedTests)
		{
			FileString left;
			FileString right;
			FileString mid;
			FileString rightAsSubstring;
			{
				FileString string = "test string here.";
				left = string.Left(4);
				right = string.Right(5);
				mid = string.SubString(5, 6);
				rightAsSubstring = string.SubString( 12, 5 );

				UTF_CHECK(left == "test");
				UTF_CHECK(right == "here.");
				UTF_CHECK(mid == "string");
				UTF_CHECK(rightAsSubstring == "here.");
			}
			// verify these are still valid:
			UTF_CHECK(left == "test");
			UTF_CHECK(right == "here.");
			UTF_CHECK(mid == "string");
			UTF_CHECK(rightAsSubstring == "here.");
		}
		END_UNITTEST

		BEGIN_UNITTEST(OperatorTests)
		{
			FileString string1 = "apple";
			FileString string2 = "orange";
			FileString string3 = "apple";
			FileString string4 = "orange";

			UTF_CHECK(string1 < string2);
			UTF_CHECK(string2 > string1);
			UTF_CHECK(string1 == string3);
			UTF_CHECK(string1 != string2);
			UTF_CHECK(string1 <= string2);
			UTF_CHECK(string1 <= string3);
			UTF_CHECK(string2 >= string1);
			UTF_CHECK(string2 >= string4);

			UTF_CHECK(string1 < "orange");
			UTF_CHECK(string2 > "apple");
			UTF_CHECK(string1 == "apple");
			UTF_CHECK(string1 != "banana");
			UTF_CHECK(string1 <= "orange");
			UTF_CHECK(string1 <= "apple");
			UTF_CHECK(string2 >= "apple");
			UTF_CHECK(string2 >= "orange");
		}
		END_UNITTEST
	}	
	END_UNITTEST

	BEGIN_UNITTEST(CharTests)
	{
		using Axiom::ShortString;
		{
			ShortString string = "y";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			string = "x";
			string += "y";
			string += "z"; 
			string += " test";
			UTF_CHECK(string == "xyz test");
			UTF_CHECK(string[0] == 'x');

			string = string + "A";
			string += "z";
			UTF_CHECK(string == "xyz testAz");
		}
		{
			ShortString string = "test";
			char* str = " string";
			string += str;
			string += ", ";
			string += ShortString(123);
			UTF_CHECK(string == "test string, 123");
		}
	}	
	END_UNITTEST
}
END_UNITTESTGROUP(FunctionalFileStringTestGroup)
	
BEGIN_UNITTESTGROUP(FunctionalFindTestGroup)
{
	BEGIN_UNITTEST(FindTests)
	{
		using Axiom::ShortString;
		ShortString string("this is my find test");

		int found = string.Find("this");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 0);

		found = string.Find("is");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 2);

		found = string.Find("my");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 8);

		found = string.Find("test");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 16);

		found = string.Find("ball");
		UTF_CHECK(found == -1);

        ShortString LookIn;
        ShortString LookFor;

        // Part of the search string matched before it�s actual real position
        LookIn = "animatiosomelongcrap:animation";
        LookFor = "animation";
        int index = LookIn.Find( LookFor );
        UTF_CHECK( index == 21 );

        // starting characters matched and overlap actual string to find  
        LookIn = "eeeeeeeeeeeen";
        LookFor = "een";
        index = LookIn.Find( LookFor );
        UTF_CHECK( index == 10 );

        // only 1 character matched before actual find
        LookIn = "asnimatiosomelongcrap:animation";
        LookFor = "animation";

        index = LookIn.Find( LookFor );
        UTF_CHECK( index == 22 );


        // partial string matched multiple times
        LookIn = "animatiosomelanimonganimacrap:animation";
        LookFor = "animation";

        index = LookIn.Find( LookFor );
        UTF_CHECK( index == 30 );


		// with static string argument:
		ShortString target("test");
		found = string.Find(target);
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 16);

		ShortString target2("ball");
		found = string.Find(target2);
		UTF_CHECK(found == -1);

		ShortString target3("string that is too damn big to be a substring of source string");
		found = string.Find(target3);
		UTF_CHECK(found == -1);

		// Reverse Find:
		found = string.ReverseFind("this");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 0);

		found = string.ReverseFind("is");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 5);

		found = string.ReverseFind("my");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 8);

		found = string.ReverseFind("test");
		UTF_CHECK(found >= 0);
		UTF_CHECK(found == 16);

		found = string.ReverseFind("ball");
		UTF_CHECK(found == -1);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringWithLongFind)
	{
		using Axiom::ShortString;
		ShortString string = "";
		int found = string.Find ("test");
		UTF_CHECK (found == -1);
		found = string.ReverseFind ("test");
		UTF_CHECK (found == -1);

		string = "this is a long string";

		char* ptr = "string that is too damn big to be a substring of source string";
		found = string.Find (ptr);
		UTF_CHECK(found == -1);

		found = string.ReverseFind (ptr);
		UTF_CHECK(found == -1);
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ReplaceSubstringTests)
	{
		{
			using Axiom::ShortString;

			ShortString string("testThing.txt");

			string.Replace("test", "____");
			UTF_CHECK(string == "____Thing.txt");

			string.Replace("______", "aaaaaa");
			UTF_CHECK(string == "____Thing.txt");

			ShortString string2( "mine_txt");
			string2.Replace( "_", "." );

			UTF_CHECK( string2=="mine.txt" );

			ShortString stringAgain( "replace.txt" );
			stringAgain.Replace( "replace", "me" );

			UTF_CHECK( stringAgain == "me.txt" );

			stringAgain.Replace( "me", "replace" );
			UTF_CHECK( stringAgain == "replace.txt" );
		}

		{
			using Axiom::FileString;

			FileString string("testThing.txt");

			string.Replace("test", "____");
			UTF_CHECK(string == "____Thing.txt");

			string.Replace("______", "aaaaaa");
			UTF_CHECK(string == "____Thing.txt");

			FileString path( "file:/Media/scripts/fe/BootStartUp.lua" );
			path.Replace( "file:", "/app_home" );

			UTF_CHECK(path == "/app_home/Media/scripts/fe/BootStartUp.lua");
		}
	}	
	END_UNITTEST

	BEGIN_UNITTEST(RemoveSubstringTests)
	{
		{
			using Axiom::ShortString;
			{ // in middle
				ShortString string = "something is here";
				string.Remove(" is");
				UTF_CHECK(string == "something here");
			}

			{  //from start
				ShortString string = "something is here";
				string.Remove("some");
				UTF_CHECK(string == "thing is here");
			}

			{ // from end
				ShortString string = "something is here";
				string.Remove("here");
				UTF_CHECK(string == "something is ");
			}

			{  // substr not found
				ShortString string = "something is here";
				string.Remove("nothing");
				UTF_CHECK(string == "something is here");
			}
		}

		{
			using Axiom::FileString;
			{
				FileString string = "something.txt";
				string.Remove("thing");
				UTF_CHECK(string == "some.txt");
			}

			{
				FileString string = "something.txt";
				string.Remove("some");
				UTF_CHECK(string == "thing.txt");
			}

			{
				FileString string = "something.txt";
				string.Remove(".txt");
				UTF_CHECK(string == "something");
			}

			{
				FileString string = "something.txt";
				string.Remove("nothing");
				UTF_CHECK(string == "something.txt");
			}
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(AssignFromSubstringTests)
	{
		using Axiom::ShortString;

		ShortString string("test");
		string.AssignFromSubstring("this is a long string", 7);
		UTF_CHECK(string == "this is");
	}	
	END_UNITTEST
}
END_UNITTESTGROUP(FunctionalFindTestGroup)


BEGIN_UNITTESTGROUP(BoundaryTestGroup)
{

	BEGIN_UNITTEST(UnboundedStringTests)
	{
		{
			using Axiom::StaticString;
			StaticString <> string;  // default length
			UTF_CHECKASSERT(string = "this String Is way too big, no way the legal length, and should cause The Test To Fail");
			string = "12345678901234567890123456789012345678901234567890123456789012";
			UTF_CHECKASSERT(string += string);
			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == "1234567890123456789012345678901234567890123456789012345678901*");
			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == "1234567890123456789012345678901234567890123456789012345678901_");
			string[0] = '_';
			UTF_CHECK(string == "_234567890123456789012345678901234567890123456789012345678901_");
			string[1] = '_';
			UTF_CHECK(string == "__34567890123456789012345678901234567890123456789012345678901_");

			UTF_CHECK( string.Right(10) == "345678901_" );
			UTF_CHECK( string.Right(string.Length()) == "__34567890123456789012345678901234567890123456789012345678901_" );
			UTF_CHECKASSERT(string.Right(string.Length()+1));

			UTF_CHECK(string.Left(4) == "__34");
			UTF_CHECK(string.Left(string.Length()) == string);
			UTF_CHECKASSERT(string.Left(string.Length() +1));
		}

		{
			using Axiom::StaticString;
			StaticString <10> string, secondString;
			string = "1234567890";
			UTF_CHECKASSERT(string = "this String Is way too big, no way the legal length, and should cause The Test To Fail");
			UTF_CHECKASSERT(string = "12345678901");

			string = "1234567890";
			UTF_CHECKASSERT(string += string);

			UTF_CHECKASSERT(string[string.Length()] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == "123456789*");
			UTF_CHECKASSERT(string[string.Length()] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == "123456789_");
			string[0] = '_';
			UTF_CHECK(string == "_23456789_");
			string[1] = '_';
			UTF_CHECK(string == "__3456789_");

			UTF_CHECK( string.Right(4) == "789_" );
			UTF_CHECK( string.Right(string.Length()) == string );
			UTF_CHECKASSERT(string.Right(string.Length()+1));

			UTF_CHECK(string.Left(4) == "__34");
			UTF_CHECK(string.Left(string.Length()) == string);
			UTF_CHECKASSERT(string.Left(string.Length() +1));
			
            string = "12345";
            secondString = "12345";
            string = string + secondString;
            string = "12345";
            string += secondString;

            string = "12345";
            secondString = "123456";
            UTF_CHECKASSERT(string += secondString);
		}
	}	
	END_UNITTEST

	BEGIN_UNITTEST(ShortStringTests)
	{
		using Axiom::ShortString;
		{
			ShortString string;
			UTF_CHECKASSERT(string = "this String Is way too big, no way the legal length, and should cause The Test To Fail");

			string = "12345678901234567890123456789012345678901234567890123456789012";
			UTF_CHECKASSERT(string += string);

			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == "1234567890123456789012345678901234567890123456789012345678901*");

			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == "1234567890123456789012345678901234567890123456789012345678901_");

			string[0] = '_';
			UTF_CHECK(string == "_234567890123456789012345678901234567890123456789012345678901_");

			string[1] = '_';
			UTF_CHECK(string == "__34567890123456789012345678901234567890123456789012345678901_");


			UTF_CHECK( string.Right(10) == "345678901_");
			UTF_CHECK( string.Right(string.Length()) == "__34567890123456789012345678901234567890123456789012345678901_" );
		}
		{
			ShortString string("testing constructor 12345", 40);
			UTF_CHECK(string == "testing constructor 12345");
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(FileStringTests)
	{
		{
			using Axiom::FileString;
			FileString string;
			UTF_CHECKASSERT(string = "2BIG_1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456");

			string = "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456";
			UTF_CHECKASSERT(string += string);

			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '*';
			UTF_CHECK(string == "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345*");

			UTF_CHECKASSERT(string[string.Length()+1] = '_');
			string[string.Length()-1] = '_';
			UTF_CHECK(string == "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345_");

			string[0] = '_';
			UTF_CHECK(string == "_23456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345_");

			string[1] = '_';
			UTF_CHECK(string == "__3456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345_");

			UTF_CHECK( string.Right(20) == "7890123456789012345_" );
			UTF_CHECK( string.Right(string.Length()) == string );
			UTF_CHECKASSERT(string.Right(string.Length()+1));

			UTF_CHECK(string.Left(20) == "__345678901234567890");
			UTF_CHECK(string.Left(string.Length()) == string);
			UTF_CHECKASSERT(string.Left(string.Length() +1));
		}
	}	
	END_UNITTEST


	BEGIN_UNITTEST(CharTests)
	{
		using Axiom::ShortString;
		{
			ShortString string = "y";
			UTF_CHECK(string.IsEmpty() == false);
			UTF_CHECK(string.Length() == 1);
			string = "x";
			string += "y";
			string += "z";
			string += " test";
			UTF_CHECK(string == "xyz test");
			UTF_CHECK(string[0] == 'x');

			string = string + "A";
			string += "z";
			UTF_CHECK(string == "xyz testAz");
		}
		{
			ShortString string = "test";
			char* str = " string";
			string += str;
			string += ", ";
			string += ShortString(123);
			UTF_CHECK(string == "test string, 123");
		}
	}	
	END_UNITTEST
	
	BEGIN_UNITTEST(FloatTests)
    {
        using Axiom::ShortString;
        {
            ShortString string = ShortString(12.345f);
            UTF_CHECK(string == "12.345000");
            string = ShortString(12.345f, 2);
            UTF_CHECK(string == "12.34");
			string.Format( "Pos:[%.2f,%.2f,%.3f]", 1.23f, 4.5f, 6.789f );
            UTF_CHECK(string == "Pos:[1.23,4.50,6.789]");
        }
    }	
    END_UNITTEST

}
END_UNITTESTGROUP(BoundaryTestGroup)

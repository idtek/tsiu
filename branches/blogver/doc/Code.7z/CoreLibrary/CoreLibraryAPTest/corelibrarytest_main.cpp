//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
//!	@file 	corelibrarytest_main.cpp
//!	@brief	Test Driver for all Core library unit tests.
//
//	created:	5:25:2007
//	author:		ruic
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================

#include <unittesting.h>
#include "debug/assert.h"
#if CORE_WIN32
	#include <conio.h>
#endif

#if CORE_PS3
#define THREAD_MAIN_PRIORITY 1500
SYS_PROCESS_PARAM(THREAD_MAIN_PRIORITY,0x30000);
#include <cell/sysmodule.h>
#include <cell/cell_fs.h>
#endif

using namespace AP::UnitTestingFramework;

#if !CORE_WII
USING_UNITTESTGROUP(JobManagerTestGroup)
#endif // CORE_WII
USING_UNITTESTGROUP(EventSystemGroup)
USING_UNITTESTGROUP(ThreadGroup)
USING_UNITTESTGROUP(CollectionsGroup)
USING_UNITTESTGROUP(MemoryTestGroup)
USING_UNITTESTGROUP(CoreGroup)
USING_UNITTESTGROUP(FilesGroup)
USING_UNITTESTGROUP(MathsGroup)
USING_UNITTESTGROUP(ReflectionGroup)
USING_UNITTESTGROUP(StackGroup)
USING_UNITTESTGROUP(StackBlowerGroup)
USING_UNITTESTGROUP(LoggingTestGroup)
USING_UNITTESTGROUP(EncodeTestGroup)

//predeclares:
void AllocateHeaps();
void OverrideGlobalAssertions();

//-------------------------------------------------------

// The Unit tests have been broken up into individual functions to accommodate the PS3
// A single function calling all of the unittests sets up a dramatically larger stack
// frame (you should see the assembly code for it) which crashes straight-away before
// any real unit tests are performed.

void	StackBlowerTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(StackBlowerGroup, output);
}

void	MathTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(MathsGroup, output);
}
void	ReflectionTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(ReflectionGroup, output);
}

// #if !CORE_WII
// void	JobManagerTest (Win32OutputObject& output)
// {
// 	RUN_UNITTESTGROUP(JobManagerTestGroup, output);
// }
// #endif // !CORE_WII

void	EventSystemTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(EventSystemGroup, output);
}

void	ThreadTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(ThreadGroup, output);
}

void	MemoryTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(MemoryTestGroup, output);
}

void 	FileTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(FilesGroup, output);
}

void	CollectionTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(CollectionsGroup, output);
}

void	CoreTests (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(CoreGroup, output);
}

void	StackTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(StackGroup, output);
}

void LoggingTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(LoggingTestGroup,output)
}

void EncodingTest (Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(EncodeTestGroup,output)
}

//-------------------------------------------------------
Win32OutputObject output;

void RunAllTests()
{
	UNITTEST_HEADER("Core Library Unit Tests", output);	

	CollectionTest		(output);
	CoreTests			(output);
	EventSystemTest		(output);

	MathTest			(output);
	MemoryTest			(output);

	FileTest			(output);
	
	ReflectionTest		(output);	
	//DAY 10/23/2008 10:49:36 AM  Thread tests don't seem to work on ps3
#if CORE_PS3==CORE_NO
	ThreadTest			(output);
#endif	

	StackTest			(output);
	LoggingTest			(output);

	EncodingTest		(output);
	UNITTEST_FOOTER("Core Library Unit Tests", output);
}

#if CORE_PS3

void InitPs3Modules( char** argv )
{
	if(cellSysmoduleLoadModule(CELL_SYSMODULE_FS) != CELL_OK)
	{
		AP_ASSERTFAIL("FAIL TO LOAD FILE SYS MODULE");
	}

	const CellFsErrno err = cellFsAioInit("/app_home");

	if(err != CELL_FS_SUCCEEDED)
	{
		AP_ASSERTMESSAGE(err == CELL_FS_SUCCEEDED, "FAIL TO START THE CELLFSAIOINIT CALL!!");
	}
}

#endif

int main(int argc, char** argv)
{
#if CORE_WII
	OSInit();
#endif 

#if CORE_PS3
	InitPs3Modules( argv );
#endif

	AllocateHeaps();
	Axiom::InitLogging(Axiom::Memory::RESERVED_DEBUG_HEAP, 0);
	OverrideGlobalAssertions();

	RunAllTests();

	Axiom::Memory::Destroy();

	if ((argc == 2) && (0 == Axiom::StringCompare(argv[1], "dev", 3)))
	{
	#if CORE_WIN32
		_getch();
	#endif
	}

#if CORE_WII
	OSRebootSystem();
#endif 
	return 0;
}


void AllocateHeaps()
{
	// Todo: Probably not necessary to create so many heaps.
	Axiom::Memory::Init(PLATFORM_MAXALLOC);
	Axiom::Memory::RESERVED_CORE_HEAP		= Axiom::Memory::CreateHeap("RESERVED_CORE_HEAP",		IN_MB(2) );
	Axiom::Memory::RESERVED_DEBUG_HEAP		= Axiom::Memory::CreateHeap("RESERVED_DEBUG_HEAP",		IN_MB(1) );
	Axiom::Memory::RESERVED_SYSTEMS_HEAP	= Axiom::Memory::CreateHeap("RESERVED_SYSTEMS_HEAP",	IN_MB(1) );
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(30) );
	Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_KB(512) );
	Axiom::Memory::PHYSICS_HEAP				= Axiom::Memory::CreateHeap("PHYSICS_HEAP",				IN_KB(512) );
	Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_KB(512) );
	Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_KB(512) );
	Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_KB(512) );
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_KB(512) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_KB(512) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_KB(512) );
}

// ensure that our UnitTest asserts are handled.
void UnitTestAssert(const char* conditionString, const char* filename, const int line, const char* comment)
{
	UNUSED_PARAM(comment);
	UNUSED_PARAM(filename);
	UNUSED_PARAM(line);

	// Throw your exception
#if CORE_PS3
	Axiom::Log("System","Assert failure: %s, at file '%s', line %d",conditionString,filename,line);
	abort();
#else
	throw AP::UnitTestingFramework::TestFailedException("UN-HANDLED ASSERTION in: ", conditionString, filename, line);
#endif
}

void OverrideGlobalAssertions()
{
	AssertOptions assertOption;
	assertOption.m_overrideAssertCallBack = UnitTestAssert;
	assertOption.m_debugBreak = false;
	assertOption.m_callstackTrace = false;
	SetAssertOptions( assertOption );
}


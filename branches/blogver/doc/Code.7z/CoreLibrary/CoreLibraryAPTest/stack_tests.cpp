// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	stack_tests.cpp
//!	@brief	stack unit tests
//
//	created:	6:4:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include <unittesting.h>
#include <Collections/stack.h>
#include <string/string.h>

using namespace Axiom;
using namespace Axiom::Collections;
typedef ShortString TestString;

TestString 	IntToStringStack (int i)
{
	const int size = 128;
	char buf [size+1];
	StringFormat(buf,size,"%d",i);// don't bother filling the whole thing
	return TestString (buf);
}

struct TestStruct
{
	TestStruct (int i) : mInt(i)
	{
	}

	bool operator== (const TestStruct& ts)
	{
		return mInt == ts.mInt;
	}

	bool operator!= (const TestStruct& ts)
	{
		return mInt != ts.mInt;
	}

	bool operator < (const TestStruct& ts)
	{
		return mInt < ts.mInt;
	}

	int mInt;
};

static TestStruct tsData [] = 
{
	TestStruct(0),
	TestStruct(1),
	TestStruct(2),
	TestStruct(3),
	TestStruct(4),
	TestStruct(5),
	TestStruct(6),
	TestStruct(7),
	TestStruct(8),
	TestStruct(9),
	TestStruct(10),
	TestStruct(11),
	TestStruct(12),
	TestStruct(13),
	TestStruct(14),
	TestStruct(15),
	TestStruct(16),
	TestStruct(17),
	TestStruct(18),
	TestStruct(19),
	TestStruct(20),
	TestStruct(21),
	TestStruct(22),
	TestStruct(23),
	TestStruct(24),
	TestStruct(25),
	TestStruct(26),
	TestStruct(27),
	TestStruct(28),
	TestStruct(29),
	TestStruct(30),
	TestStruct(31),
	TestStruct(32),
	TestStruct(33),
	TestStruct(34),
	TestStruct(35),
	TestStruct(36),
	TestStruct(37),
	TestStruct(38),
	TestStruct(39),
	TestStruct(666),
};

static TestStruct* IntToTestStructStack (int i)
{
	return &tsData[i < 40 ? i : 40];
}

DECLARE_UNITTESTGROUP(StackWithIntegerGroup)
DECLARE_UNITTESTGROUP(StackWithStringGroup)
DECLARE_UNITTESTGROUP(StackWithStructPointerGroup)

BEGIN_UNITTESTGROUP(StackGroup)
{
	RUN_UNITTESTSUBGROUP(StackWithIntegerGroup);
	RUN_UNITTESTSUBGROUP(StackWithStringGroup);
	RUN_UNITTESTSUBGROUP(StackWithStructPointerGroup);
}
END_UNITTESTGROUP(StackGroup)

BEGIN_UNITTESTGROUP(StackWithIntegerGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		IntToTestStructStack (0);
		StaticStack<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticStack<ELEMENT_TYPE, 100> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 100);

		StaticStack<ELEMENT_TYPE, 300> s2;// (10,ELEMENT_CONVERSION(42));
		for (int i=0; i<10; i++)
		{
			s2.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 300);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Remove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top());
		UTF_CHECKASSERT(s.Pop());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<50; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		for (int i = 49; i >=10; --i)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
		s.Clear ();
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<60; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
			
		// too many items
		UTF_CHECKASSERT(s.Push (60));

		// pop a few items
		for (int i=10; i<60; i++)
		{
			s.Pop ();
		}
		UTF_CHECK(s.Count() == 10);

		for (int i=100; i<150; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s.Count() == 60);

		for (int i=60; i<70; i++)
		{
			UTF_CHECKASSERT(s.Push (ELEMENT_CONVERSION (i)));
		}

		// pop a few items
		for (int i=149; i>=120; i--)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());
		UTF_CHECK (s.IsEmpty () == true);

		s.Push (1);
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}

END_UNITTESTGROUP(StackWithIntegerGroup)

//-------------------------------------------------------------

BEGIN_UNITTESTGROUP(StackWithStringGroup)
{
#define ELEMENT_CONVERSION(x) IntToStringStack((x))
#define ELEMENT_TYPE ShortString 

	BEGIN_UNITTEST(Constructors)
	{
		IntToTestStructStack (0);
		StaticStack<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticStack<ELEMENT_TYPE, 75> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 75);

		StaticStack<ELEMENT_TYPE, 100> s2;
		for (int i=0; i<10; i++)
		{
			s2.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 100);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Remove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top());
		UTF_CHECKASSERT(s.Pop());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<50; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		for (int i = 49; i >=10; --i)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
		s.Clear ();
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<60; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		// too many items
		UTF_CHECKASSERT(s.Push (ShortString(60)));

		// pop a few items
		for (int i=10; i<60; i++)
		{
			s.Pop ();
		}
		UTF_CHECK(s.Count() == 10);

		for (int i=100; i<150; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s.Count() == 60);

		for (int i=60; i<70; i++)
		{
			UTF_CHECKASSERT(s.Push (ELEMENT_CONVERSION (i)));
		}

		// pop a few items
		for (int i=149; i>=120; i--)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());
		UTF_CHECK (s.IsEmpty () == true);

		s.Push (ShortString(1));
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}

END_UNITTESTGROUP(StackWithIntegerGroup)

//-------------------------------------------------------------

BEGIN_UNITTESTGROUP(StackWithStructPointerGroup)
{
#define ELEMENT_CONVERSION(x) IntToTestStructStack((x))
#define ELEMENT_TYPE TestStruct*

	BEGIN_UNITTEST(Constructors)
	{
		IntToTestStructStack (0);
		StaticStack<ELEMENT_TYPE, 50> s0;
		UTF_CHECK(s0.Count() == 0);
		UTF_CHECK(s0.Capacity() == 50);

		StaticStack<ELEMENT_TYPE, 100> s1;
		UTF_CHECK(s1.Count() == 0);
		UTF_CHECK(s1.Capacity() == 100);

		StaticStack<ELEMENT_TYPE, 300> s2;// (10,ELEMENT_CONVERSION(42));
		for (int i=0; i<10; i++)
		{
			s2.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s2.Count() == 10);
		UTF_CHECK(s2.Capacity() == 300);
	}
	END_UNITTEST

		BEGIN_UNITTEST(Remove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top());
		UTF_CHECKASSERT(s.Pop());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<50; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		for (int i = 49; i >=10; --i)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
		s.Clear ();
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertAndRemove)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());

		for (int i=0; i<10; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}
		for (int i=10; i<60; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		// too many items
		UTF_CHECKASSERT(s.Push (ELEMENT_CONVERSION(60)));

		// pop a few items
		for (int i=10; i<60; i++)
		{
			s.Pop ();
		}
		UTF_CHECK(s.Count() == 10);

		for (int i=100; i<150; i++)
		{
			s.Push (ELEMENT_CONVERSION (i));
		}

		UTF_CHECK(s.Count() == 60);

		for (int i=60; i<70; i++)
		{
			UTF_CHECKASSERT(s.Push (ELEMENT_CONVERSION (i)));
		}

		// pop a few items
		for (int i=149; i>=120; i--)
		{
			ELEMENT_TYPE val = s.Top ();
			UTF_CHECK(val == ELEMENT_CONVERSION(i));
			s.Pop ();
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		StaticStack<ELEMENT_TYPE, 60> s;
		UTF_CHECKASSERT(s.Top ());
		UTF_CHECKASSERT(s.Pop ());
		UTF_CHECK (s.IsEmpty () == true);

		s.Push (ELEMENT_CONVERSION(1));
		UTF_CHECK (s.IsEmpty () == false);
		UTF_CHECK (s.Contains (ELEMENT_CONVERSION (1)) == true);

		s.Clear	();
		UTF_CHECK (s.IsEmpty () == true);
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}

END_UNITTESTGROUP(StackWithIntegerGroup)

//---------------------------------------------------------------------------------------------------------------------------------
// Maths Level 1 PS3 Unit Tests
//---------------------------------------------------------------------------------------------------------------------------------

#include <UnitTesting.h>

#define MATHS_UNIT_TESTS CORE_YES

// here we include the XBox libraries and we rename the the classes. Notice all of the undefs here 
// to fool the compiler to include the same file twice.
#ifdef USE_REFERENCE_MATH_LIBRARY
#undef USE_REFERENCE_MATH_LIBRARY
#endif
#define USE_REFERENCE_MATH_LIBRARY 0

#define Vector3 Vector3_PS3
#define Vector4 Vector4_PS3
#define Matrix4 Matrix4_PS3
#define Quaternion Quat_PS3
#include <math/vector3.h>
#undef __CORE_VECTOR3_H
#include <math/vector4.h>
#undef __CORE_VECTOR4_H
#include <math/matrix4.h>
#undef __CORE_MATRIX4_H
#include <math/quaternion.h>
#undef __CORE_QUATERNION_H
#undef Vector3
#undef Vector4
#undef Matrix4
#undef Quaternion

// we left the undefs in the middle here in case we need to reorder the includes
#undef USE_REFERENCE_MATH_LIBRARY 
#define USE_REFERENCE_MATH_LIBRARY 1
#define Vector3 Vector3_Ref
#define Vector4 Vector4_Ref
#define Matrix4 Matrix4_Ref
#define Quaternion Quat_Ref
#include <math/vector3.h>
#undef __CORE_VECTOR3_H
#include <math/vector4.h>
#undef __CORE_VECTOR4_H
#include <math/matrix4.h>
#undef __CORE_MATRIX4_H
#include <math/quaternion.h>
#undef __CORE_QUATERNION_H
#undef Vector3
#undef Vector4
#undef Matrix4
#undef Quaternion

#include <math/apmath.h>
using namespace Axiom::Math;
const Vector3_PS3	Vector3_PS3::ZERO	(0.0f,0.0f,0.0f);
const Vector3_Ref	Vector3_Ref::ZERO	(0.0f,0.0f,0.0f);

static bool CheckVector3 (const Vector3_Ref& rv, const Vector3_PS3& v)
{
	float rx = rv.X();
	float ry = rv.Y();
	float rz = rv.Z();
	float x = v.X();
	float y = v.Y();
	float z = v.Z();
	bool p1 = EqualRelative(rx,x);
	bool p2 = EqualRelative(ry,y);
	bool p3 = EqualRelative(rz,z);
	return p1 && p2 && p3;
}

static bool CheckVector4 (const Vector4_Ref& rv, const Vector4_PS3& v)
{
	float rx = rv.X();
	float ry = rv.Y();
	float rz = rv.Z();
	float rw = rv.W();
	float x = v.X();
	float y = v.Y();
	float z = v.Z();
	float w = v.W();
	bool p1 = EqualRelative(rx,x);
	bool p2 = EqualRelative(ry,y);
	bool p3 = EqualRelative(rz,z);
	bool p4 = EqualRelative(rw,w);
	return p1 && p2 && p3 && p4;
}

static bool CheckMatrix4 (const Matrix4_Ref& rm, const Matrix4_PS3& m)
{
// 	struct Ps3FakeMatrix
// 	{
// 		float _11, _21, _31, _41;
// 		float _12, _22, _32, _42;
// 		float _13, _23, _33, _43;
// 		float _14, _24, _34, _44;
// 	};

	struct RefFakeMatrix
	{
		float _11, _12, _13, _14;
		float _21, _22, _23, _24;
		float _31, _32, _33, _34;
		float _41, _42, _43, _44;
	};

	const RefFakeMatrix* rfm = reinterpret_cast<const RefFakeMatrix*>(&rm);
	const RefFakeMatrix* fm = reinterpret_cast<const RefFakeMatrix*>(&m);

	bool p11 = EqualRelative(rfm->_11,fm->_11);
	bool p12 = EqualRelative(rfm->_12,fm->_12);
	bool p13 = EqualRelative(rfm->_13,fm->_13);
	bool p14 = EqualRelative(rfm->_14,fm->_14);
	bool p21 = EqualRelative(rfm->_21,fm->_21);
	bool p22 = EqualRelative(rfm->_22,fm->_22);
	bool p23 = EqualRelative(rfm->_23,fm->_23);
	bool p24 = EqualRelative(rfm->_24,fm->_24);
	bool p31 = EqualRelative(rfm->_31,fm->_31);
	bool p32 = EqualRelative(rfm->_32,fm->_32);
	bool p33 = EqualRelative(rfm->_33,fm->_33);
	bool p34 = EqualRelative(rfm->_34,fm->_34);
	bool p41 = EqualRelative(rfm->_41,fm->_41);
	bool p42 = EqualRelative(rfm->_42,fm->_42);
	bool p43 = EqualRelative(rfm->_43,fm->_43);
	bool p44 = EqualRelative(rfm->_44,fm->_44);

	return
		p11 && p12 && p13 && p14 &&
		p21 && p22 && p23 && p24 &&
		p31 && p32 && p33 && p34 &&
		p41 && p42 && p43 && p44;
}

static bool CheckMatrix (const Matrix4_PS3& m, float* fakeMatrix)
{
	return (Axiom::MemoryCompare(&m,fakeMatrix,sizeof(Matrix4_PS3)) == 0);
}

static bool CheckQuaternion (const Quat_PS3& qx, const Quat_Ref& qr)
{
	return (
		Equal(qx.X(),qr.X()),
		Equal(qx.Y(),qr.Y()),
		Equal(qx.Z(),qr.Z()),
		Equal(qx.W(),qr.W())
		);
}


BEGIN_UNITTESTGROUP(Maths_PS3_Vector)
{
	BEGIN_UNITTEST(PS3Vector3ConstructorTests)
	{
		Vector3_PS3 v0;
		Vector3_PS3 v1 (1.0f, 2.0f, -3.0f);
		Vector3_PS3 v2 (v1);
		Vector3_Ref rv0;
		Vector3_Ref rv1 (1.0f, 2.0f, -3.0f);
		Vector3_Ref rv2 (rv1);

		// Test read-only X(), Y(), Z()
		struct FakeVector
		{
			float x, y, z, w;
		};
		FakeVector* fv1 = reinterpret_cast<FakeVector*>(&v1);
		UTF_CHECK(fv1->x == v1.X());
		UTF_CHECK(fv1->y == v1.Y());
		UTF_CHECK(fv1->z == v1.Z());

		// Testing constructors
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);

		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == -3.0f);

		UTF_CHECK(v2.X() == 1.0f);
		UTF_CHECK(v2.Y() == 2.0f);
		UTF_CHECK(v2.Z() == -3.0f);
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3Vector3BasicOperationsTests)
	{
		Vector3_PS3 v0 (NoInitializer);
		Vector3_PS3 v1 (1.0f, 2.0f, -3.0f);
		Vector3_PS3 v2 (v1);
		Vector3_Ref rv0 (NoInitializer);
		Vector3_Ref rv1 (1.0f, 2.0f, -3.0f);
		Vector3_Ref rv2 (rv1);

		// Test operator =
		v0 = v2;
		rv0 = rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator +=
		v0 += v2;
		rv0 += rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator -=
		v0 -= v2;
		rv0 -= rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator *=
		v0 *= v2;
		rv0 *= rv2;
		UTF_CHECK(CheckVector3(rv0,v0));
		v0 *= 4.0f;
		rv0 *= 4.0f;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator /=
		v0 /= v2;
		rv0 /= rv2;
		UTF_CHECK(CheckVector3(rv0,v0));
		v0 /= 2.0f;
		rv0 /= 2.0f;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test unary operator -
		v0 = -v2;
		rv0 = -rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test binary operator +
		v0 = v1 + v2;
		rv0 = rv1 + rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test binary operator -
		v0 = v1 - v2;
		rv0 = rv1 - rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator *
		v0 = v1 * v2;
		rv0 = rv1 * rv2;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Test operator == and !=
		UTF_CHECK(v1 == v2);
		UTF_CHECK(v0 != v1);

		// Read/write versions of X(), Y() & Z()
		v0.X(1.0f);
		v0.Y(2.0f);
		v0.Z(3.0f);
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == 3.0f);

		// Check SetZero()
		v0.SetZero();
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.IsZero());
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3Vector3MathOperationsTests)
	{
		Vector3_PS3 v0 (NoInitializer);
		Vector3_PS3 v1 (1.0f, 2.0f, -3.0f);
		Vector3_PS3 v2 (v1);
		Vector3_Ref rv0 (NoInitializer);
		Vector3_Ref rv1 (1.0f, 2.0f, -3.0f);
		Vector3_Ref rv2 (rv1);

		// Check Square Magnitude
		float sqlen = v1.SquareMagnitude();
		float rsqlen = rv1.SquareMagnitude();
		UTF_CHECK(Equal(sqlen,rsqlen));

		// Check AsNormal()
		v0 = v1.AsNormal();
		rv0 = rv1.AsNormal();
		UTF_CHECK(CheckVector3(rv0,v0));

		// Check Cross
		v0 = v1.Cross(v2);
		rv0 = rv1.Cross(rv2);
		UTF_CHECK(CheckVector3(rv0,v0));

		// Check Dot
		UTF_CHECK(Equal(v1.Dot(v2),rv1.Dot(rv2)));

		// Check Normalize()
		v0 = v1;
		v0.Normalize();
		UTF_CHECK(v0.IsNormal());
		rv0 = rv1;
		rv0.Normalize();
		UTF_CHECK(rv0.IsNormal());
		UTF_CHECK(CheckVector3(rv0,v0));

		// Check Reciprocal and AsReciprocal
		v0 = v1.AsReciprocal();
		rv0 = rv1.AsReciprocal();
		UTF_CHECK(CheckVector3(rv0,v0));
		v0 = v1;
		v0.Reciprocal();
		rv0 = rv1;
		rv0.Reciprocal();
		UTF_CHECK(CheckVector3(rv0,v0));

		// Check Global * & /
		v0 = v1 * 2.0f;
		rv0 = rv1 * 2.0f;
		UTF_CHECK(CheckVector3(rv0,v0));
		v0 = 3.0f * v1;
		rv0 = 3.0f * rv1;
		UTF_CHECK(CheckVector3(rv0,v0));
		v0 = v1 / 2.0f;
		rv0 = rv1 / 2.0f;
		UTF_CHECK(CheckVector3(rv0,v0));

		// Check ProjectOn
		v1.Set(1.0f,0.0f,0.0f);
		v2.Set(0.0f,1.0f,0.0f);
		v0 = v1.ProjectOn(v2);
		UTF_CHECK(v0.IsZero());
		rv1.Set(1.0f,0.0f,0.0f);
		rv2.Set(0.0f,1.0f,0.0f);
		rv0 = rv1.ProjectOn(rv2);
		UTF_CHECK(rv0.IsZero());
		UTF_CHECK(CheckVector3(rv0,v0));
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3Vector4ConstructorTests)
	{
		Vector4_PS3 v0;
		Vector4_PS3 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_PS3 v2 (v1);
		Vector4_Ref rv0;
		Vector4_Ref rv1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_Ref rv2 (rv1);

		// Test read-only X(), Y(), Z()
		struct FakeVector
		{
			float x, y, z, w;
		};
		FakeVector* fv1 = reinterpret_cast<FakeVector*>(&v1);
		UTF_CHECK(fv1->x == v1.X());
		UTF_CHECK(fv1->y == v1.Y());
		UTF_CHECK(fv1->z == v1.Z());
		UTF_CHECK(fv1->w == v1.W());

		// Testing constructors
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.W() == 1.0f);

		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == -3.0f);
		UTF_CHECK(v1.W() == 5.0f);

		UTF_CHECK(v2.X() == 1.0f);
		UTF_CHECK(v2.Y() == 2.0f);
		UTF_CHECK(v2.Z() == -3.0f);
		UTF_CHECK(v2.W() == 5.0f);
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3Vector4BasicOperationsTests)
	{
		Vector4_PS3 v0 (NoInitializer);
		Vector4_PS3 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_PS3 v2 (v1);
		Vector4_Ref rv0 (NoInitializer);
		Vector4_Ref rv1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_Ref rv2 (rv1);

		// Test operator =
		v0 = v2;
		rv0 = rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator +=
		v0 += v2;
		rv0 += rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator -=
		v0 -= v2;
		rv0 -= rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator *=
		v0 *= v2;
		rv0 *= rv2;
		UTF_CHECK(CheckVector4(rv0,v0));
		v0 *= 4.0f;
		rv0 *= 4.0f;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator /=
		v0 /= v2;
		rv0 /= rv2;
		UTF_CHECK(CheckVector4(rv0,v0));
		v0 /= 2.0f;
		rv0 /= 2.0f;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test unary operator -
		v0 = -v2;
		rv0 = -rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test binary operator +
		v0 = v1 + v2;
		rv0 = rv1 + rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test binary operator -
		v0 = v1 - v2;
		rv0 = rv1 - rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator *
		v0 = v1 * v2;
		rv0 = rv1 * rv2;
		UTF_CHECK(CheckVector4(rv0,v0));

		// Test operator == and !=
		UTF_CHECK(v1 == v2);
		UTF_CHECK(v0 != v1);

		// Read/write versions of X(), Y() & Z()
		v0.X() = 23.0f;
		v0.Y() = 13.5f;
		v0.Z() = 67.46f;
		v0.W() = 36.92f;
		UTF_CHECK(v0.X() == 23.0f);
		UTF_CHECK(v0.Y() == 13.5f);
		UTF_CHECK(v0.Z() == 67.46f);
		UTF_CHECK(v0.W() == 36.92f);
		v0.X(1.0f);
		v0.Y(2.0f);
		v0.Z(3.0f);
		v0.W(4.0f);
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == 3.0f);
		UTF_CHECK(v0.W() == 4.0f);

		// Read-only Get()
		UTF_CHECK(v0.Get(0) == 1.0f);
		UTF_CHECK(v0.Get(1) == 2.0f);
		UTF_CHECK(v0.Get(2) == 3.0f);
		UTF_CHECK(v0.Get(3) == 4.0f);

		// Read/write Get()
		v0.Get(0) = 2.0f;
		v0.Get(1) = 4.0f;
		v0.Get(2) = 6.0f;
		v0.Get(3) = 8.0f;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == 6.0f);
		UTF_CHECK(v0.W() == 8.0f);

		// Check both versions of GetAddress()
		float* addv0 = reinterpret_cast<float*>(&v0);
		const Vector4_PS3 cv0;
		const float* caddv0 = reinterpret_cast<const float*>(&cv0);
		for (int i = 0; i < 4; ++i)
		{
			float *a = v0.GetAddress(i);
			const float *b = cv0.GetAddress(i);
			UTF_CHECK(a == addv0+i);
			UTF_CHECK(b == caddv0+i);
		}

		// Check Clear()
		v0.Clear();
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.W() == 0.0f);
		}
		END_UNITTEST

	BEGIN_UNITTEST (PS3Vector4MathOperationsTests)
	{
		Vector4_PS3 v0 (NoInitializer);
		Vector4_PS3 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_PS3 v2 (v1);
		Vector4_Ref rv0 (NoInitializer);
		Vector4_Ref rv1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4_Ref rv2 (rv1);

		// Check Magnitude, SquareMagnitude, DistanceTo
		float sqlen = v1.SquareMagnitude();
		float rsqlen = rv1.SquareMagnitude();
		UTF_CHECK(EqualRelative(sqlen,rsqlen));
		float len = v1.Magnitude();
		UTF_CHECK(Equal(len, Axiom::Math::SquareRoot(sqlen)));
		len = rv1.Magnitude();
		UTF_CHECK(Equal(len, Axiom::Math::SquareRoot(rsqlen)));
		UTF_CHECK(Equal(v1.DistanceTo(v2), v2.DistanceTo(v1)));

		// Check Normalized()
		v0 = v1.Normalized();
		rv0 = rv1.Normalized();
		UTF_CHECK(CheckVector4(rv0,v0));

		// Check Dot
		UTF_CHECK(EqualRelative(v1.Dot(v2),rv1.Dot(rv2)));

		// Check Normalize()
		v0 = v1;
		v0.Normalize();
		rv0 = rv1;
		rv0.Normalize();
		UTF_CHECK(CheckVector4(rv0,v0));

		// Check NormalizeSafe()
		v0 = v1;
		v0.NormalizeSafe();
		rv0 = rv1;
		rv0.NormalizeSafe();
		UTF_CHECK(CheckVector4(rv0,v0));
		v0.Clear();
		v0.NormalizeSafe();
		rv0.Clear();
		rv0.NormalizeSafe();
		UTF_CHECK(CheckVector4(rv0,v0));

		// Check Swap()
		v0.Swap(v1);
		rv0.Swap(rv1);
		UTF_CHECK(CheckVector4(rv0,v0));
		v0.Swap(v1);
		rv0.Swap(rv1);
		UTF_CHECK(CheckVector4(rv0,v0));

		// Check Reciprocal and AsReciprocal
		v0= v1.AsReciprocal();
		rv0 = rv1.AsReciprocal();
		UTF_CHECK(CheckVector4(rv0,v0));
		v0 = v1;
		v0.Reciprocal();
		rv0 = rv1;
		rv0.Reciprocal();
		UTF_CHECK(CheckVector4(rv0,v0));


		// Check Global * & /
		v0 = v1 * 2.0f;
		rv0 = rv1 * 2.0f;
		UTF_CHECK(CheckVector4(rv0,v0));
		v0 = 3.0f * v1;
		rv0 = 3.0f * rv1;
		UTF_CHECK(CheckVector4(rv0,v0));
		v0 = v1 / 2.0f;
		rv0 = rv1 / 2.0f;
		UTF_CHECK(CheckVector4(rv0,v0));
	}
	END_UNITTEST
}
END_UNITTESTGROUP(Maths_PS3_Vector)
	
BEGIN_UNITTESTGROUP(Maths_PS3_Matrix4)
{
	float gMatrixIdentity [] = 
	{
		1.0f,0.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,0.0f,
		0.0f,0.0f,1.0f,0.0f,
		0.0f,0.0f,0.0f,1.0f,
	};

	BEGIN_UNITTEST(PS3Matrix4ConstructorTest)
	{
		// Check constructors
		Matrix4_Ref rm1;
		Matrix4_Ref rm2 (1.0f,2.0f,3.0f,4.0f,
			5.0f,6.0f,7.0f,8.0f,
			9.0f,10.0f,11.0f,12.0f,
			13.0f,14.0f,15.0f,16.0f);
		Matrix4_Ref rm3(rm2);
		Matrix4_PS3 m1;
		Matrix4_PS3 m2 (1.0f,2.0f,3.0f,4.0f,
			5.0f,6.0f,7.0f,8.0f,
			9.0f,10.0f,11.0f,12.0f,
			13.0f,14.0f,15.0f,16.0f);
		Matrix4_PS3 m3(m2);

		UTF_CHECK(CheckMatrix4(rm1,m1));
		UTF_CHECK(CheckMatrix4(rm2,m2));
		UTF_CHECK(CheckMatrix4(rm3,m3));
	}
	END_UNITTEST


	BEGIN_UNITTEST(PS3Matrix4OperationsTest)
	{
		int i, j;
		// Check constructors
		Matrix4_Ref rm1 (NoInitializer);
		Matrix4_Ref rm2 (1.0f,2.0f,3.0f,4.0f,
						 5.0f,6.0f,7.0f,8.0f,
						 9.0f,10.0f,11.0f,12.0f,
						 13.0f,14.0f,15.0f,16.0f);
		Matrix4_Ref rm3(rm2);
		Matrix4_PS3 m1 (NoInitializer);
		Matrix4_PS3 m2 (1.0f,2.0f,3.0f,4.0f,
						 5.0f,6.0f,7.0f,8.0f,
						 9.0f,10.0f,11.0f,12.0f,
						 13.0f,14.0f,15.0f,16.0f);
		Matrix4_PS3 m3(m2);

		// Check assignment operator
		m1 = m2;
		rm1 = rm2;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check operator +=
		m1 += m2;
		rm1 += rm2;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check operator -=
		m1 -= m2;
		rm1 -= rm2;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check operator *=
		m1 *= m2;
		rm1 *= rm2;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check operator /=
		m1 /= 2.0f;
		rm1 /= 2.0f;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check unary -
		m1 = -m1;
		rm1 = -rm1;
		UTF_CHECK(CheckMatrix4(rm1,m1));

		// Check == and != 
		m1 = m2;
		UTF_CHECK(m1 == m2);
		UTF_CHECK(!(m1 != m2));

		// Check Clear(), Get() and Set()
		m1.SetIdentity();
		UTF_CHECK(CheckMatrix(m1,gMatrixIdentity));
		for (i = 0; i < 4; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				m1.SetE(i,j,m2.GetE(i,j));
				UTF_CHECK(Equal(m1.GetE(i,j),m2.GetE(i,j)));
			}
		}

		// Check GetRow() and SetRow()
		Vector3_PS3 v1 = m2.GetRow(0);
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == 3.0f);
		m2.SetRow(0,2.0f,4.0f,6.0f,4.0f);
		v1 = m2.GetRow(0);
		UTF_CHECK(v1.X() == 2.0f);
		UTF_CHECK(v1.Y() == 4.0f);
		UTF_CHECK(v1.Z() == 6.0f);
		v1.Set(1.0f,2.0f,3.0f);
		m2.SetRow(0,v1);
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == 3.0f);

		// Check (Get/Set)(X/Y/Z)basis functions
		v1 = m2.GetXbasis();
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 5.0f);
		UTF_CHECK(v1.Z() == 9.0f);
		v1 = m2.GetYbasis();
		UTF_CHECK(v1.X() == 2.0f);
		UTF_CHECK(v1.Y() == 6.0f);
		UTF_CHECK(v1.Z() == 10.0f);
		v1 = m2.GetZbasis();
		UTF_CHECK(v1.X() == 3.0f);
		UTF_CHECK(v1.Y() == 7.0f);
		UTF_CHECK(v1.Z() == 11.0f);
		Vector3_PS3 v2 (20.0f,21.0f,22.0f);
		m2.SetXbasis(v2);
		m2.SetYbasis(v2);
		m2.SetZbasis(v2);
		v1 = m2.GetXbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);
		v1 = m2.GetYbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);
		v1 = m2.GetZbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);

		// SetYawPitchRoll
		Matrix4_Ref rmrot;
		Matrix4_PS3 mrot;

		rmrot.SetYawPitchRoll(PI_DIV_TWO*0.5f,PI_DIV_TWO,PI_DIV_TWO*1.5f);
		mrot.SetYawPitchRoll(PI_DIV_TWO*0.5f,PI_DIV_TWO,PI_DIV_TWO*1.5f);
		UTF_CHECK(CheckMatrix4(rmrot,mrot));

		// SetEulerXYZ
		rmrot.SetEulerXYZ(PI_DIV_TWO*0.5f,PI_DIV_TWO,PI_DIV_TWO*1.5f);
		mrot.SetEulerXYZ(PI_DIV_TWO*0.5f,PI_DIV_TWO,PI_DIV_TWO*1.5f);
		UTF_CHECK(CheckMatrix4(rmrot,mrot));

		// SetTranslation
		rmrot.SetIdentity();
		rmrot.SetTranslation(0.5f,1.0f,1.5f);
		mrot.SetIdentity();
		mrot.SetTranslation(0.5f,1.0f,1.5f);
		UTF_CHECK(CheckMatrix4(rmrot,mrot));

		Vector3_Ref rtv;
		Vector3_PS3 tv;
		rtv.Set(0.5f,1.0f,1.5f);
		tv.Set(0.5f,1.0f,1.5f);
		rmrot.SetIdentity();
		rmrot.SetTranslation(rtv);
		mrot.SetIdentity();
		mrot.SetTranslation(tv);
		UTF_CHECK(CheckMatrix4(rmrot,mrot));

		// Check Transpose
		m1 = m2.Transpose();
		for (i = 0; i < 4; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				UTF_CHECK(Equal(m1.GetE(i,j), m2.GetE(j,i)));
			}
		}
		rm1 = rm2.Transpose();
		for (i = 0; i < 4; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				UTF_CHECK(Equal(rm1.GetE(i,j), rm2.GetE(j,i)));
			}
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3Matrix4TranslateAndScaleTest)
	{
		Matrix4_PS3 mrot = Matrix4_PS3::Scale (2, 4, 6);
		Vector3_PS3 tv (100, 200, 300);
		mrot.SetTranslation(tv);
		Vector3_PS3 rettv = mrot.GetTranslation ();
		Vector3_PS3 ScaleVal = mrot.GetScale ();

		UTF_CHECK(rettv == tv);
		UTF_CHECK(ScaleVal == Vector3_PS3 (2, 4, 6));
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3MatrixQuaternionConversion)
	{
		//float x = PI/2, y = PI/4, z = -PI/3;
		float yaw = 0, pitch = 0, roll = PI/2;
		Vector3_PS3 vect1 (1, 0, 0);// basis vector
		Vector3_PS3 vect2 (0, 1, 0);// basis vector
		Vector3_PS3 vect3 (0, 0, 1);// basis vector
		Quat_PS3	Quat (yaw, pitch, roll);

		Matrix4_PS3 mrot1 = Matrix4_PS3 :: Rotation	(Quat);
		Matrix4_PS3 mrot2;
		mrot2.SetYawPitchRoll(yaw, pitch, roll);

		Vector3_PS3 result1 = vect1 * mrot1;
		Vector3_PS3 result2 = vect2 * mrot1;
		Vector3_PS3 result3 = vect3 * mrot1;

		Vector3_PS3 result4 = vect1 * mrot2;
		Vector3_PS3 result5 = vect2 * mrot2;
		Vector3_PS3 result6 = vect3 * mrot2;

		UTF_CHECK(Axiom::Math::Vector3_PS3::IsEqual (result1, result4, 0.0001f));
		UTF_CHECK(Axiom::Math::Vector3_PS3::IsEqual (result2, result5, 0.0001f));
		UTF_CHECK(Axiom::Math::Vector3_PS3::IsEqual (result3, result6, 0.0001f));
	}
	END_UNITTEST
}
END_UNITTESTGROUP(Maths_PS3_Matrix4)

BEGIN_UNITTESTGROUP(Maths_PS3_Quaternion)
{

	BEGIN_UNITTEST(PS3QuaternionConstructorTests)
	{
		// Check constructors
		Quat_PS3	qx0;
		Quat_Ref	qr0;

		UTF_CHECK(CheckQuaternion(qx0,qr0));

		Vector3_PS3 vx0 (1.0f,2.0f,3.0f);
		Vector3_Ref vr0 (1.0f,2.0f,3.0f);
		Quat_PS3 qx1 (vx0,2.0f);
		Quat_Ref qr1 (vr0,2.0f);
		UTF_CHECK(CheckQuaternion(qx1,qr1));

		Quat_PS3 qx2 = qx1;
		Quat_Ref qr2 = qr1;
		UTF_CHECK(CheckQuaternion(qx2,qr2));
	}
	END_UNITTEST

	BEGIN_UNITTEST(PS3QuaternionTests)
	{
		Quat_PS3	qx0;
		Quat_Ref	qr0;
		Vector3_PS3 vx0 (1.0f,2.0f,3.0f);
		Vector3_Ref vr0 (1.0f,2.0f,3.0f);
		Quat_PS3 qx1 (vx0,2.0f);
		Quat_Ref qr1 (vr0,2.0f);
		Quat_PS3 qx2 = qx1;
		Quat_Ref qr2 = qr1;

		// Check assignment operators
		Quat_PS3 qx3 (NoInitializer);
		Quat_Ref qr3 (NoInitializer);
		qx3 = qx1;
		qr3 = qr1;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 += qx1;
		qr3 += qr1;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 -= qx1;
		qr3 -= qr1;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 *= 2.5f;
		qr3 *= 2.5f;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 /= 2.5f;
		qr3 /= 2.5f;
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		// Unary operators
		qx3 = -qx1;
		qr3 = -qr1;
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		// Binary operators
		qx3 = qx1 + qx2;
		qr3 = qr1 + qr2;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 = qx1 - qx2;
		qr3 = qr1 - qr2;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 = qx1 * 2.5f;
		qr3 = qr1 * 2.5f;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3 = qx1 / 2.5f;
		qr3 = qr1 / 2.5f;
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		UTF_CHECKASSERT(qx3 / 0.0f);
		qx3 = 2.5f * qx3;
		qr3 = 2.5f * qr3;
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		// Comparison operators
		qx3 = qx1;
		bool bx = (qx3 == qx1);
		bool br = (qr3 == qr1);
		UTF_CHECK(bx == br);
		bx = (qx3 != qx1);
		br = (qr3 != qr1);
		UTF_CHECK(bx == br);

		//
		// Set operator
		//
		qx3.Set(1.0f,2.0f,3.0f,4.0f);
		qr3.Set(1.0f,2.0f,3.0f,4.0f);
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Clear operator
		//
		qx3.SetIdentity();
		qr3.SetIdentity();
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Check Magnitude and SquareMagnitude
		//
		float x = qx1.Magnitude();
		float r = qr1.Magnitude();
		UTF_CHECK(Equal(x,r));
		x = qx1.SquareMagnitude();
		r = qr1.SquareMagnitude();
		UTF_CHECK(Equal(x,r));

		//
		// Check Normalise
		//
		qx3 = qx1;
		qr3 = qr1;
		UTF_CHECK(CheckQuaternion(qx3.AsNormal(),qr3.AsNormal()));
		qx3.Normalize();
		qr3.Normalize();
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Conjugate
		//
		qx3 = qx1.AsConjugate();
		qr3 = qr1.AsConjugate();
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Yaw, pitch & roll
		//
		qx3.SetYawPitchRoll(PI_DIV_TWO,0.0f,0.0f);
		qr3.SetYawPitchRoll(PI_DIV_TWO,0.0f,0.0f);
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3.SetYawPitchRoll(0.0f,PI_DIV_TWO,0.0f);
		qr3.SetYawPitchRoll(0.0f,PI_DIV_TWO,0.0f);
		UTF_CHECK(CheckQuaternion(qx3,qr3));
		qx3.SetYawPitchRoll(0.0f,0.0f,PI_DIV_TWO);
		qr3.SetYawPitchRoll(0.0f,0.0f,PI_DIV_TWO);
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		qx3.SetYawPitchRoll(PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		qr3.SetYawPitchRoll(PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Quaternion multiplication
		//
		Quat_PS3 xyaw (PI_DIV_TWO,0.0f,0.0f);
		Quat_PS3 xpitch (0.0f,PI_DIV_TWO,0.0f);
		Quat_PS3 xroll (0.0f,0.0f,PI_DIV_TWO);
		Quat_Ref ryaw (PI_DIV_TWO,0.0f,0.0f);
		Quat_Ref rpitch (0.0f,PI_DIV_TWO,0.0f);
		Quat_Ref rroll (0.0f,0.0f,PI_DIV_TWO);

		qx3 = xroll;
		qx3 *= xpitch;
		qx3 *= xyaw;
		qr3 = rroll;
		qr3 *= rpitch;
		qr3 *= ryaw;
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		qx3 = xroll * xpitch * xyaw;
		qr3 = rroll * rpitch * ryaw;
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		// Axis Angle
		vx0.Normalize();
		vr0.Normalize();

		qx3.AxisAngle(vx0,PI_DIV_TWO);
		qr3.AxisAngle(vr0,PI_DIV_TWO);
		UTF_CHECK(CheckQuaternion(qx3,qr3));

		//
		// Slerp
		//
		vx0.Set(0.0f,0.0f,1.0f);
		vr0.Set(0.0f,0.0f,1.0f);

		qx0.AxisAngle(vx0,PI_DIV_TWO);
		qr0.AxisAngle(vr0,PI_DIV_TWO);
		qx1.AxisAngle(vx0,PI);
		qr1.AxisAngle(vr0,PI);

		for (float t = 0.0f; t < 1.0f; t += 0.1f)
		{
			qx2 = Slerp(t,qx0,qx1);
			qr2 = Slerp(t,qr0,qr1);
			UTF_CHECK(CheckQuaternion(qx2,qr2));
			UTF_CHECK(qx2.IsNormal());
			UTF_CHECK(qr2.IsNormal());
		}
		qx2 = Slerp(1.0f,qx0,qx1);
		qr2 = Slerp(1.0f,qr0,qr1);
		UTF_CHECK(CheckQuaternion(qx2,qr2));
		UTF_CHECK(qx2.IsNormal());
		UTF_CHECK(qr2.IsNormal());

		// non-unit Slerp
		qx0.Set(0.488191247f, 0.695494533f, -8.76896422e-008f, 0.477401644f);
		qx1.Set(0.189944863f, -0.270602316f, -3.31423742e-008f, 0.876215339f);
		qr0.Set(0.488191247f, 0.695494533f, -8.76896422e-008f, 0.477401644f);
		qr1.Set(0.189944863f, -0.270602316f, -3.31423742e-008f, 0.876215339f);
		qx2 = Slerp(0.0f,qx0,qx1);
		qr2 = Slerp(0.0f,qr0,qr1);
		UTF_CHECK(CheckQuaternion(qx2,qr2));
		UTF_CHECK(!qx2.IsNormal());
		UTF_CHECK(!qr2.IsNormal());
		qx2.Normalize();
		qr2.Normalize();
		UTF_CHECK(CheckQuaternion(qx2,qr2));

		//
		// Invert & AsInverse
		//
		UTF_CHECK(CheckQuaternion(qx0.AsInverse(),qr0.AsInverse()));
		qx0.Invert();
		qr0.Invert();
		UTF_CHECK(CheckQuaternion(qx0,qr0));

		//
		// IsNormal
		//
		qx0.AxisAngle(vx0,PI_DIV_TWO);
		qx0 *= 2.0f;
		qr0.AxisAngle(vr0,PI_DIV_TWO);
		qr0 *= 2.0f;

		UTF_CHECK(qx0.IsNormal() == qr0.IsNormal());
		qx0.Normalize();
		qr0.Normalize();
		UTF_CHECK(qx0.IsNormal() == qr0.IsNormal());
	}
	END_UNITTEST
}
END_UNITTESTGROUP(Maths_PS3_Quaternion)

BEGIN_UNITTESTGROUP(Maths_PS3_CameraTests)
{
	BEGIN_UNITTEST(CameraTests)
	{
		// Generate the view matrix
		Matrix4_Ref refLookAt = Matrix4_Ref::Translation(10.0f,0.5f,5.0f);
		refLookAt *= Matrix4_Ref::RotationZ(PI_DIV_TWO);
		refLookAt *= Matrix4_Ref::RotationY(PI_DIV_FOUR);
		refLookAt *= Matrix4_Ref::RotationX(PI_DIV_TWO);

		Vector3_Ref refFront = refLookAt.GetZbasis();
		Vector3_Ref refSide = refLookAt.GetXbasis();
		Vector3_Ref refUp = refLookAt.GetZbasis();

		refFront.Normalize();
		refSide.Normalize();
		refUp.Normalize();

		Matrix4_PS3 ps3LookAt = Matrix4_PS3::Translation(10.0f,0.5f,5.0f);
		ps3LookAt *= Matrix4_PS3::RotationZ(PI_DIV_TWO);
		ps3LookAt *= Matrix4_PS3::RotationY(PI_DIV_FOUR);
		ps3LookAt *= Matrix4_PS3::RotationX(PI_DIV_TWO);

		Vector3_PS3 ps3Front = ps3LookAt.GetZbasis();
		Vector3_PS3 ps3Side = ps3LookAt.GetXbasis();
		Vector3_PS3 ps3Up = ps3LookAt.GetZbasis();

		ps3Front.Normalize();
		ps3Side.Normalize();
		ps3Up.Normalize();

		UTF_CHECK(CheckVector3(refFront,ps3Front));
		UTF_CHECK(CheckVector3(refSide,ps3Side));
		UTF_CHECK(CheckVector3(refUp,ps3Up));

	}
	END_UNITTEST
}
END_UNITTESTGROUP(Maths_PS3_CameraTests)


//---------------------------------------------------------------------------------------------------------------------------------
// Maths Level 1 Reference Unit Tests
//---------------------------------------------------------------------------------------------------------------------------------

#include <UnitTesting.h>


#include <math/vector3.h>
#include <math/vector4.h>
#include <math/matrix4.h>
#include <math/quaternion.h>

#include <math/apmath.h>

using namespace Axiom::Math;

static bool CheckMatrix (const Matrix4& m, float* fakeMatrix)
{
	return (Axiom::MemoryCompare(&m,fakeMatrix,sizeof(Matrix4)) == 0);
}

/*static bool CheckMatrix (const Matrix4& m1, const Matrix4& m2)
{
	return (Axiom::MemoryCompare(&m1,&m2,sizeof(Matrix4)) == 0);
}*/

static bool CheckQuat (const Axiom::Math::Quaternion& q, float x, float y, float z, float w)
{
	return
		Equal(q.X(),x) &&
		Equal(q.Y(),y) &&
		Equal(q.Z(),z) &&
		Equal(q.W(),w);
}

static bool CheckQuat (const Axiom::Math::Quaternion& q1, const Axiom::Math::Quaternion& q2)
{
	return
		Equal(q1.X(),q2.X()) &&
		Equal(q1.Y(),q2.Y()) &&
		Equal(q1.Z(),q2.Z()) &&
		Equal(q1.W(),q2.W());
}

static bool CheckVector (const Vector3& v, float x, float y, float z)
{
	return
		Equal(v.X(),x) &&
		Equal(v.Y(),y) &&
		Equal(v.Z(),z);
}

static bool CheckVector (const Vector3& v0, const Vector3& v1)
{
	return
		Equal(v0.X(),v1.X()) &&
		Equal(v0.Y(),v1.Y()) &&
		Equal(v0.Z(),v1.Z());
}

BEGIN_UNITTESTGROUP( Maths_Reference_Vector )

	BEGIN_UNITTEST(ReferenceVector3ConstructorTests)
	{
		Vector3 v0;
		Vector3 v1 (1.0f, 2.0f, -3.0f);
		Vector3 v2 (v1);

		// Test read-only X(), Y(), Z()
		struct FakeVector
		{
			float x, y, z, w;
		};
		FakeVector *fv1 = reinterpret_cast<FakeVector*>(&v1);
		UTF_CHECK(fv1->x == v1.X());
		UTF_CHECK(fv1->y == v1.Y());
		UTF_CHECK(fv1->z == v1.Z());

		// Testing constructors
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);

		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == -3.0f);

		UTF_CHECK(v2.X() == 1.0f);
		UTF_CHECK(v2.Y() == 2.0f);
		UTF_CHECK(v2.Z() == -3.0f);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceVector3BasicOperationsTests)
	{
		Vector3 v0 (NoInitializer);
		Vector3 v1 (1.0f, 2.0f, -3.0f);
		Vector3 v2 (v1);

		// Test operator =
		v0 = v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == -3.0f);

		// Test operator +=
		v0 += v2;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == -6.0f);

		// Test operator -=
		v0 -= v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == -3.0f);

		// Test operator *=
		v0 *= v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == 9.0f);

		v0 *= 4.0f;
		UTF_CHECK(v0.X() == 4.0f);
		UTF_CHECK(v0.Y() == 16.0f);
		UTF_CHECK(v0.Z() == 36.0f);

		// Test operator /=
		v0 /= v2;
		UTF_CHECK(v0.X() == 4.0f);
		UTF_CHECK(v0.Y() == 8.0f);
		UTF_CHECK(v0.Z() == -12.0f);

		v0 /= 2.0f;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == -6.0f);

		// Test unary operator -
		v0 = -v2;
		UTF_CHECK(v0.X() == -1.0f);
		UTF_CHECK(v0.Y() == -2.0f);
		UTF_CHECK(v0.Z() == 3.0f);

		// Test binary operator +
		Vector3 v3 (2.0f, 4.0f, 9.0f);
		v0 = v2 + v3;
		UTF_CHECK(v0.X() == 3.0f);
		UTF_CHECK(v0.Y() == 6.0f);
		UTF_CHECK(v0.Z() == 6.0f);

		// Test binary operator -
		v0 = v2 - v3;
		UTF_CHECK(v0.X() == -1.0f);
		UTF_CHECK(v0.Y() == -2.0f);
		UTF_CHECK(v0.Z() == -12.0f);

		// Test operator *
		v0 = v2 * v3;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 8.0f);
		UTF_CHECK(v0.Z() == -27.0f);

		// Test operator == and !=
		UTF_CHECK(v1 == v2);
		UTF_CHECK(v0 != v3);

		// Read/write versions of X(), Y() & Z()
		v0.X(1.0f);
		v0.Y(2.0f);
		v0.Z(3.0f);
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == 3.0f);

		// Check SetZero()
		v0.SetZero();
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.IsZero());
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceVector3MathOperationsTests)
	{
		Vector3 v0 (NoInitializer);
		Vector3 v1 (1.0f, 2.0f, -3.0f);
		Vector3 v2 (v1);
		Vector3 v3 (2.0f, 4.0f, 9.0f);
		// Check SquareMagnitude
		float sqlen = v1.SquareMagnitude();
		UTF_CHECK(sqlen == 14.0f);
		float len = v1.Magnitude();
		UTF_CHECK(Equal(len,Axiom::Math::SquareRoot(sqlen)));

		// Check Normalized()
		v0 = v1.AsNormal();
		UTF_CHECK(Equal(v0.X(),1.0f/len));
		UTF_CHECK(Equal(v0.Y(),2.0f/len));
		UTF_CHECK(Equal(v0.Z(),-3.0f/len));
		UTF_CHECK(Equal(v0.Magnitude(),1.0f));

		// Check Cross
		v1.Set(1.0f,0.0f,0.0f);
		v2.Set(0.0f,1.0f,0.0f);
		v0 = v1.DeprecatedCrossLeftHanded(v2);
		UTF_CHECK(v0 == Vector3(0.0f,0.0f,1.0f));

		// Check Dot
		v1.Set(1.0f,2.0f,-3.0f);
		UTF_CHECK(Equal(v1.Dot(v3),-17.0f));

		// Check Normalize()
		v0 = v3;
		v0.Normalize();
		UTF_CHECK(v0.IsNormal());
		UTF_CHECK(Equal(v0.Magnitude(),1.0f));

		// Check Reciprocal and AsReciprocal
		v0 = v1.AsReciprocal();
		UTF_CHECK(v0 == Vector3(1.0f/v1.X(), 1.0f/v1.Y(), 1.0f/v1.Z()));
		v0 = v1;
		v0.Reciprocal();
		UTF_CHECK(v0 == Vector3(1.0f/v1.X(), 1.0f/v1.Y(), 1.0f/v1.Z()));

		// Check Global * & /
		v0 = v3 * 2.0f;
		UTF_CHECK(v0 == Vector3(4.0f,8.0f,18.0f));
		v0 = 3.0f * v3;
		UTF_CHECK(v0 == Vector3(6.0f,12.0f,27.0f));
		v0 = v3 / 2.0f;
		UTF_CHECK(Equal(v0.X(),1.0f));
		UTF_CHECK(Equal(v0.Y(),2.0f));
		UTF_CHECK(Equal(v0.Z(),4.5f));

		// Check ProjectOn
		v1.Set(1.0f,0.0f,0.0f);
		v2.Set(0.0f,1.0f,0.0f);
		v0 = v1.ProjectOn(v2);
		UTF_CHECK(v0.IsZero());
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceVector4ConstructorTests)
	{
		Vector4 v0;
		Vector4 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4 v2 (v1);

		// Test read-only X(), Y(), Z()
		struct FakeVector
		{
			float x, y, z, w;
		};
		FakeVector *fv1 = reinterpret_cast<FakeVector*>(&v1);
		UTF_CHECK(fv1->x == v1.X());
		UTF_CHECK(fv1->y == v1.Y());
		UTF_CHECK(fv1->z == v1.Z());
		UTF_CHECK(fv1->w == v1.W());

		// Testing constructors
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.W() == 1.0f);

		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == -3.0f);
		UTF_CHECK(v1.W() == 5.0f);

		UTF_CHECK(v2.X() == 1.0f);
		UTF_CHECK(v2.Y() == 2.0f);
		UTF_CHECK(v2.Z() == -3.0f);
		UTF_CHECK(v2.W() == 5.0f);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceVector4BasicOperationsTests)
	{
		Vector4 v0 (NoInitializer);
		Vector4 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4 v2 (v1);

		// Test operator =
		v0 = v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == -3.0f);
		UTF_CHECK(v0.W() == 5.0f);

		// Test operator +=
		v0 += v2;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == -6.0f);
		UTF_CHECK(v0.W() == 10.0f);

		// Test operator -=
		v0 -= v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == -3.0f);
		UTF_CHECK(v0.W() == 5.0f);

		// Test operator *=
		v0 *= v2;
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == 9.0f);
		UTF_CHECK(v0.W() == 25.0f);

		v0 *= 4.0f;
		UTF_CHECK(v0.X() == 4.0f);
		UTF_CHECK(v0.Y() == 16.0f);
		UTF_CHECK(v0.Z() == 36.0f);
		UTF_CHECK(v0.W() == 100.0f);

		// Test operator /=
		v0 /= v2;
		UTF_CHECK(v0.X() == 4.0f);
		UTF_CHECK(v0.Y() == 8.0f);
		UTF_CHECK(v0.Z() == -12.0f);
		UTF_CHECK(v0.W() == 20.0f);

		v0 /= 2.0f;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == -6.0f);
		UTF_CHECK(v0.W() == 10.0f);

		// Test unary operator -
		v0 = -v2;
		UTF_CHECK(v0.X() == -1.0f);
		UTF_CHECK(v0.Y() == -2.0f);
		UTF_CHECK(v0.Z() == 3.0f);
		UTF_CHECK(v0.W() == -5.0f);

		// Test binary operator +
		Vector4 v3 (2.0f, 4.0f, 9.0f, 3.0f);
		v0 = v2 + v3;
		UTF_CHECK(v0.X() == 3.0f);
		UTF_CHECK(v0.Y() == 6.0f);
		UTF_CHECK(v0.Z() == 6.0f);
		UTF_CHECK(v0.W() == 8.0f);

		// Test binary operator -
		v0 = v2 - v3;
		UTF_CHECK(v0.X() == -1.0f);
		UTF_CHECK(v0.Y() == -2.0f);
		UTF_CHECK(v0.Z() == -12.0f);
		UTF_CHECK(v0.W() == 2.0f);

		// Test operator *
		v0 = v2 * v3;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 8.0f);
		UTF_CHECK(v0.Z() == -27.0f);
		UTF_CHECK(v0.W() == 15.0f);

		// Test operator == and !=
		UTF_CHECK(v1 == v2);
		UTF_CHECK(v0 != v3);

		// Read/write versions of X(), Y() & Z()
		v0.X() = 23.0f;
		v0.Y() = 13.5f;
		v0.Z() = 67.46f;
		v0.W() = 36.92f;
		UTF_CHECK(v0.X() == 23.0f);
		UTF_CHECK(v0.Y() == 13.5f);
		UTF_CHECK(v0.Z() == 67.46f);
		UTF_CHECK(v0.W() == 36.92f);
		v0.X(1.0f);
		v0.Y(2.0f);
		v0.Z(3.0f);
		v0.W(4.0f);
		UTF_CHECK(v0.X() == 1.0f);
		UTF_CHECK(v0.Y() == 2.0f);
		UTF_CHECK(v0.Z() == 3.0f);
		UTF_CHECK(v0.W() == 4.0f);

		// Read-only Get()
		UTF_CHECK(v0.Get(0) == 1.0f);
		UTF_CHECK(v0.Get(1) == 2.0f);
		UTF_CHECK(v0.Get(2) == 3.0f);
		UTF_CHECK(v0.Get(3) == 4.0f);

		// Read/write Get()
		v0.Get(0) = 2.0f;
		v0.Get(1) = 4.0f;
		v0.Get(2) = 6.0f;
		v0.Get(3) = 8.0f;
		UTF_CHECK(v0.X() == 2.0f);
		UTF_CHECK(v0.Y() == 4.0f);
		UTF_CHECK(v0.Z() == 6.0f);
		UTF_CHECK(v0.W() == 8.0f);

		// Check both versions of GetAddress()
		float* addv0 = reinterpret_cast<float*>(&v0);
		const Vector4 cv0;
		const float* caddv0 = reinterpret_cast<const float*>(&cv0);
		for (int i = 0; i < 4; ++i)
		{
			float *a = v0.GetAddress(i);
			const float *b = cv0.GetAddress(i);
			UTF_CHECK(a == addv0+i);
			UTF_CHECK(b == caddv0+i);
		}

		// Check Clear()
		v0.Clear();
		UTF_CHECK(v0.X() == 0.0f);
		UTF_CHECK(v0.Y() == 0.0f);
		UTF_CHECK(v0.Z() == 0.0f);
		UTF_CHECK(v0.W() == 0.0f);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceVector4MathOperationsTests)
	{
		Vector4 v0 (NoInitializer);
		Vector4 v1 (1.0f, 2.0f, -3.0f, 5.0f);
		Vector4 v2 (v1);
		Vector4 v3 (2.0f, 4.0f, 9.0f, 3.0f);

		// Check Magnitude, SquareMagnitude, DistanceTo
		float sqlen = v1.SquareMagnitude();
		UTF_CHECK(sqlen == 39.0f);
		float len = v1.Magnitude();
		UTF_CHECK(len == Axiom::Math::SquareRoot(sqlen));
		UTF_CHECK(Equal(v1.DistanceTo(v2), v2.DistanceTo(v1)));

		// Check Normalized()
		v0 = v1.Normalized();
		UTF_CHECK(Equal(v0.X(),1.0f/len));
		UTF_CHECK(Equal(v0.Y(),2.0f/len));
		UTF_CHECK(Equal(v0.Z(),-3.0f/len));
		UTF_CHECK(Equal(v0.W(),5.0f/len));
		UTF_CHECK(Equal(v0.Magnitude(),1.0f));

		// Check Dot
		v1.Set(1.0f,2.0f,-3.0f,5.0f);
		UTF_CHECK(Equal(v1.Dot(v3),-2.0f));

		// Check Normalize()
		v0 = v3;
		v0.Normalize();
		UTF_CHECK(Equal(v0.Magnitude(),1.0f));

		// Check NormalizeSafe()
		v0 = v3;
		v0.NormalizeSafe();
		UTF_CHECK(Equal(v0.Magnitude(),1.0f));
		v0.Clear();
		v0.NormalizeSafe();
		UTF_CHECK(Equal(v0.X(),1.0f));
		UTF_CHECK(Equal(v0.Y(),0.0f));
		UTF_CHECK(Equal(v0.Z(),0.0f));

		// Check Swap()
		v1.Swap(v3);
		UTF_CHECK(v1 == Vector4(2.0f,4.0f,9.0f,3.0f));
		UTF_CHECK(v3 == Vector4(1.0f,2.0f,-3.0f,5.0f));

		// Check Reciprocal and AsReciprocal
		v0= v1.AsReciprocal();
		UTF_CHECK(v0 == Vector4(1.0f/v1.X(), 1.0f/v1.Y(), 1.0f/v1.Z(), 1.0f/v1.W()));
		v0 = v1;
		v0.Reciprocal();
		UTF_CHECK(v0 == Vector4(1.0f/v1.X(), 1.0f/v1.Y(), 1.0f/v1.Z(), 1.0f/v1.W()));

		// Check Global * & /
		v0 = v3 * 2.0f;
		UTF_CHECK(v0 == Vector4(2.0f,4.0f,-6.0f,10.0f));
		v0 = 3.0f * v3;
		UTF_CHECK(v0 == Vector4(3.0f,6.0f,-9.0f,15.0f));
		v0 = v3 / 2.0f;
		UTF_CHECK(Equal(v0.X(),0.5f));
		UTF_CHECK(Equal(v0.Y(),1.0f));
		UTF_CHECK(Equal(v0.Z(),-1.5f));
		UTF_CHECK(Equal(v0.W(),2.5f));
	}
	END_UNITTEST
END_UNITTESTGROUP( Maths_Reference_Vector )

BEGIN_UNITTESTGROUP( Maths_Reference_Matrix4 )
	float gMatrixData [] = 
	{
		1.0f,2.0f,3.0f,4.0f,
		5.0f,6.0f,7.0f,8.0f,
		9.0f,10.0f,11.0f,12.0f,
		13.0f,14.0f,15.0f,16.0f,
	};

	float gMatrixMinusData [] = 
	{
		-1.0f,-2.0f,-3.0f,-4.0f,
		-5.0f,-6.0f,-7.0f,-8.0f,
		-9.0f,-10.0f,-11.0f,-12.0f,
		-13.0f,-14.0f,-15.0f,-16.0f,
	};

	float gMatrixData2 [] =
	{
		2.0f,4.0f,6.0f,8.0f,
		10.f,12.0f,14.0f,16.0f,
		18.0f,20.0f,22.0f,24.0f,
		26.0f,28.0f,30.0f,32.0f,
	};

	float gMatrixData3 [] =
	{
		90.0f,100.0f,110.0f,120.0f,
		202.0f,228.0f,254.0f,280.0f,
		314.0f,356.0f,398.0f,440.0f,
		426.0f,484.0f,542.0f,600.0f,
	};

	float gMatrixIdentity [] = 
	{
		1.0f,0.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,0.0f,
		0.0f,0.0f,1.0f,0.0f,
		0.0f,0.0f,0.0f,1.0f,
	};

	BEGIN_UNITTEST(ReferenceMatrix4ConstructorTests)
	{
		// Check constructors
		Matrix4 m1;
		Matrix4 m2 (1.0f,2.0f,3.0f,4.0f,
			5.0f,6.0f,7.0f,8.0f,
			9.0f,10.0f,11.0f,12.0f,
			13.0f,14.0f,15.0f,16.0f);
		Matrix4 m3(m2);

		UTF_CHECK(CheckMatrix(m1,gMatrixIdentity));
		UTF_CHECK(CheckMatrix(m2,gMatrixData));
		UTF_CHECK(CheckMatrix(m3,gMatrixData));
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceMatrix4OperationsTests)
	{
		int i, j;
		// Check constructors
		Matrix4 m1 (NoInitializer);
		Matrix4 m2 (1.0f,2.0f,3.0f,4.0f,
			5.0f,6.0f,7.0f,8.0f,
			9.0f,10.0f,11.0f,12.0f,
			13.0f,14.0f,15.0f,16.0f);
		Matrix4 m3(m2);

		// Check assignment operator
		m1 = m2;
		UTF_CHECK(CheckMatrix(m1,gMatrixData));

		// Check operator +=
		m1 += m2;
		UTF_CHECK(CheckMatrix(m1,gMatrixData2));

		// Check operator -=
		m1 -= m2;
		UTF_CHECK(CheckMatrix(m1,gMatrixData));

		// Check operator *=
		m1 *= m2;
		UTF_CHECK(CheckMatrix(m1,gMatrixData3));

		// Check operator *=
		m1 = m2;
		m1 *= 2.0f;
		UTF_CHECK(CheckMatrix(m1,gMatrixData2));

		// Check operator /=
		m1 /= 2.0f;
		UTF_CHECK(CheckMatrix(m1,gMatrixData));

		// Check unary -
		m1 = -m2;
		UTF_CHECK(CheckMatrix(m1,gMatrixMinusData));

		// Check == and !=
		m1 = m2;
		UTF_CHECK(m1 == m2);
		UTF_CHECK(!(m1 != m2));

		// Check Clear(), Get() and Set()
		m1.SetIdentity();
		UTF_CHECK(CheckMatrix(m1,gMatrixIdentity));
		for (i = 0; i < 4; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				m1.SetE(i,j,m2.GetE(i,j));
				UTF_CHECK(Equal(m1.GetE(i,j),m2.GetE(i,j)));
			}
		}

		// Check GetRow() and SetRow()
		Vector3 v1 = m2.GetRow(0);
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == 3.0f);
		m2.SetRow(0,Vector3(2.0f,4.0f,6.0f));
		v1 = m2.GetRow(0);
		UTF_CHECK(v1.X() == 2.0f);
		UTF_CHECK(v1.Y() == 4.0f);
		UTF_CHECK(v1.Z() == 6.0f);
		v1.Set(1.0f,2.0f,3.0f);
		m2.SetRow(0,v1);
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 2.0f);
		UTF_CHECK(v1.Z() == 3.0f);

		// Check (Get/Set)(X/Y/Z)basis functions
		v1 = m2.GetXbasis();
		UTF_CHECK(v1.X() == 1.0f);
		UTF_CHECK(v1.Y() == 5.0f);
		UTF_CHECK(v1.Z() == 9.0f);
		v1 = m2.GetYbasis();
		UTF_CHECK(v1.X() == 2.0f);
		UTF_CHECK(v1.Y() == 6.0f);
		UTF_CHECK(v1.Z() == 10.0f);
		v1 = m2.GetZbasis();
		UTF_CHECK(v1.X() == 3.0f);
		UTF_CHECK(v1.Y() == 7.0f);
		UTF_CHECK(v1.Z() == 11.0f);
		Vector3 v2 (20.0f,21.0f,22.0f);
		m2.SetXbasis(v2);
		m2.SetYbasis(v2);
		m2.SetZbasis(v2);
		v1 = m2.GetXbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);
		v1 = m2.GetYbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);
		v1 = m2.GetZbasis();
		UTF_CHECK(v1.X() == 20.0f);
		UTF_CHECK(v1.Y() == 21.0f);
		UTF_CHECK(v1.Z() == 22.0f);

		// Check the SetYawPitchRoll
		Matrix4 mrot;
		mrot.SetYawPitchRoll(PI_DIV_TWO,0.f,0.f);
		v1.Set(1.0f,0.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,0.0f,1.0f,0.0f));

		mrot.SetYawPitchRoll(0.f,PI_DIV_TWO,0.f);
		v1.Set(0.0f,1.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,0.0f,0.0f,1.0f));

		mrot.SetYawPitchRoll(0.f,0.f,PI_DIV_TWO);
		v1.Set(0.0f,0.0f,1.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,1.0f,0.0f,0.0f));

		mrot.SetYawPitchRoll(PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		v1.Set(1.0f,0.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,1.0f,0.0f,0.0f));

		// Check the SetEulerXYZ
		mrot.SetEulerXYZ(PI_DIV_TWO,0.f,0.f);
		v1.Set(0.0f,1.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,0.0f,0.0f,1.0f));

		mrot.SetEulerXYZ(0.f,PI_DIV_TWO,0.f);
		v1.Set(0.0f,0.0f,1.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,1.0f,0.0f,0.0f));

		mrot.SetEulerXYZ(0.f,0.f,PI_DIV_TWO);
		v1.Set(1.0f,0.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,0.0f,1.0f,0.0f));

		mrot.SetEulerXYZ(PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		v1.Set(0.0f,1.0f,0.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,0.0f,1.0f,0.0f));

		// Check SetTranslation
		mrot.SetIdentity();
		mrot.SetTranslation(0.5f,1.0f,1.5f);
		v1.Set(1.0f,2.0f,3.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,1.5f,3.0f,4.5f));

		mrot.SetIdentity();
		v2.Set(0.5f,1.0f,1.5f);
		mrot.SetTranslation(v2);
		v1.Set(1.0f,2.0f,3.0f);
		v1 = v1 * mrot;
		UTF_CHECK(CheckVector(v1,1.5f,3.0f,4.5f));

		// Check Transpose
		m1 = m2.Transpose();
		for (i = 0; i < 4; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				UTF_CHECK(Equal(m1.GetE(i,j), m2.GetE(j,i)));
			}
		}
	}
	END_UNITTEST

	
	BEGIN_UNITTEST(ReferenceMatrix4TranslateAndScaleTest)
	{
		Matrix4 mrot = Matrix4::Scale (2, 4, 6);
		Vector3 tv (100, 200, 300);
		mrot.SetTranslation(tv);
		Vector3 rettv = mrot.GetTranslation ();
		Vector3 ScaleVal = mrot.GetScale ();

		UTF_CHECK(rettv == tv);
		UTF_CHECK(ScaleVal == Vector3 (2, 4, 6));
	}
	END_UNITTEST
END_UNITTESTGROUP( Maths_Reference_Matrix4 )

BEGIN_UNITTESTGROUP( Maths_Reference_Quaternion )
	BEGIN_UNITTEST(ReferenceMatrixQuaternionConversion)
	{
		//float x = PI/2, y = PI/4, z = -PI/3;
		float yaw = 0, pitch = 0, roll = PI/2;
		Vector3 vect1 (1, 0, 0);// basis vector
		Vector3 vect2 (0, 1, 0);// basis vector
		Vector3 vect3 (0, 0, 1);// basis vector
		Axiom::Math::Quaternion	Quat (yaw, pitch, roll);

		Matrix4 mrot1 = Matrix4 :: Rotation	(Quat);
		Matrix4 mrot2;
		mrot2.SetYawPitchRoll(yaw, pitch, roll);

		Vector3 result1 = vect1 * mrot1;
		Vector3 result2 = vect2 * mrot1;
		Vector3 result3 = vect3 * mrot1;

		Vector3 result4 = vect1 * mrot2;
		Vector3 result5 = vect2 * mrot2;
		Vector3 result6 = vect3 * mrot2;

		UTF_CHECK(Axiom::Math::Vector3::IsEqual (result1, result4, 0.0001f));
		UTF_CHECK(Axiom::Math::Vector3::IsEqual (result2, result5, 0.0001f));
		UTF_CHECK(Axiom::Math::Vector3::IsEqual (result3, result6, 0.0001f));

		//UTF_CHECK(mrot1 == mrot2);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ReferenceQuaternionConstructorTests)
	{
		//
		// Check constructors
		//
		Axiom::Math::Quaternion q0;
		UTF_CHECK(CheckQuat(q0,0.f,0.f,0.f,1.f));

		Vector3 v0 (1.f,2.f,3.f);
		Axiom::Math::Quaternion q1 (v0,2.0f);
		UTF_CHECK(CheckQuat(q1,1.f,2.f,3.f,2.f));

		Axiom::Math::Quaternion q2 = q1;
		UTF_CHECK(CheckQuat(q2,1.f,2.f,3.f,2.f));
	}
	END_UNITTEST

	BEGIN_UNITTEST( ReferenceQuaternionBasicTests)
	{
		Axiom::Math::Quaternion q0;
		Vector3 v0 (1.f,2.f,3.f);
		Axiom::Math::Quaternion q1 (v0,2.0f);
		Axiom::Math::Quaternion q2 = q1;

		//
		// Check assignment operators
		//
		Axiom::Math::Quaternion q3 (NoInitializer);
		q3 = q1;
		UTF_CHECK(CheckQuat(q3,1.f,2.f,3.f,2.f));
		q3 += q1;
		UTF_CHECK(CheckQuat(q3,2.f,4.f,6.f,4.f));
		q3 -= q1;
		UTF_CHECK(CheckQuat(q3,1.f,2.f,3.f,2.f));
		q3 *= 2.5f;
		UTF_CHECK(CheckQuat(q3,2.5f,5.0f,7.5f,5.0f));
		q3 /= 2.5f;
		UTF_CHECK(CheckQuat(q3,1.f,2.f,3.f,2.f));

		//
		// Unary operators
		//
		q3 = -q1;
		UTF_CHECK(CheckQuat(q3,-1.f,-2.f,-3.f,-2.f));

		//
		// Binary operators
		//
		q3 = q1 + q2;
		UTF_CHECK(CheckQuat(q3,2.f,4.f,6.f,4.f));
		q3 = q1 - q2;
		UTF_CHECK(CheckQuat(q3,0.f,0.f,0.f,0.f));
		q3 = q1 * 2.5f;
		UTF_CHECK(CheckQuat(q3,2.5f,5.0f,7.5f,5.0f));
		q3 = q3 / 2.5f;
		UTF_CHECK(CheckQuat(q3,1.f,2.f,3.f,2.f));
		UTF_CHECKASSERT(q3 / 0.0f);
		q3 = 2.5f * q3;
		UTF_CHECK(CheckQuat(q3,2.5f,5.0f,7.5f,5.0f));

		//
		// Comparison operators
		//
		q3 = q1;
		UTF_CHECK(q3 == q1);
		UTF_CHECK(!(q3 != q1));

		//
		// Set operator
		//
		q3.Set(1.f,2.f,3.f,4.f);
		UTF_CHECK(CheckQuat(q3,1.f,2.f,3.f,4.f));

		//
		// Clear
		//
		q3.SetIdentity();
		UTF_CHECK(CheckQuat(q3,0.f,0.f,0.f,1.f));

		//
		// Check Magnitude and Squared magnitude
		//
		Vector4 v1 (q1.X(),q1.Y(),q1.Z(),q1.W());
		UTF_CHECK(Equal(v1.Magnitude(),q1.Magnitude()));
		UTF_CHECK(Equal(v1.SquareMagnitude(),q1.SquareMagnitude()));

		//
		// Check Normalize/AsNormalize
		//
		UTF_CHECK(Equal(v1.Normalized().Magnitude(),q1.AsNormal().Magnitude()));
		UTF_CHECK(Equal(q1.AsNormal().Magnitude(),1.0f));
		v1.Normalize();
		q3 = q1;
		q3.Normalize();
		UTF_CHECK(q3.IsNormal());
		UTF_CHECK(Equal(v1.Magnitude(),q3.Magnitude()));
		UTF_CHECK(Equal(q3.Magnitude(),1.0f));

		//
		// Conjugate test
		//
		q3 = q1.AsConjugate();
		UTF_CHECK(CheckQuat(q3,-1.0f,-2.0f,-3.0f,2.0));

		//
		// Yaw, pitch & roll test and quaternion*vector test
		//
		v0.Set(1.0f,0.0f,0.0f);
		q3.SetYawPitchRoll(PI_DIV_TWO,0.f,0.f);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,0.0f,1.0f,0.0f));
		q3.SetYawPitchRoll(0.f,PI_DIV_TWO,0.f);
		v0.Set(0.f,1.f,0.f);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,0.f,0.f,1.f));				/// INCONSISTENT RESULT!!!!!!  See Matt D
		q3.SetYawPitchRoll(0.f,0.f,PI_DIV_TWO);
		v0.Set(0.f,0.f,1.f);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,1.f,0.f,0.f));

		// Confirms yaw, pitch, roll order
		v0.Set(1.0f,0.0f,0.0f);
		q3.SetYawPitchRoll(PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,1.f,0.f,0.f));

		Axiom::Math::Quaternion q4 (PI_DIV_TWO,PI_DIV_TWO,PI_DIV_TWO);
		UTF_CHECK(CheckQuat(q4,q3));

		//
		// Quaternion multiplication
		//
		Axiom::Math::Quaternion ryaw (PI_DIV_TWO,0.f,0.f);
		Axiom::Math::Quaternion rpitch (0.f,PI_DIV_TWO,0.f);
		Axiom::Math::Quaternion rroll (0.f,0.f,PI_DIV_TWO);
		q3 = ryaw;
		q3 *= rpitch;
		q3 *= rroll;
		UTF_CHECK(CheckQuat(q3,q4));						/// *= is pre-multiply instead of post-multiply

		q3 = ryaw * rpitch * rroll;
		UTF_CHECK(CheckQuat(q3,q4));

		//
		// Axis Angle
		//
		Vector3 vx (1.0f,0.0f,0.0f);
		Vector3 vy (0.0f,1.0f,0.0f);
		Vector3 vz (0.0f,0.0f,1.0f);

		v0.Set(1.0f,0.0f,0.0f);			// X axis
		q3.AxisAngle(vz,-PI_DIV_TWO);	// Rotate +90		/// Axis-Angle breaks standard!!!
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,0.0f,-1.0f,0.0f));
		v0.Set(0.0f,-1.0f,0.f);
		q3.AxisAngle(vx,-PI_DIV_TWO);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,0.0f,0.0f,1.0f));
		v0.Set(0.0f,0.0f,1.0f);
		q3.AxisAngle(vy,-PI_DIV_TWO);
		v0 = v0 * q3;
		UTF_CHECK(CheckVector(v0,-1.0f,0.0f,0.0f));

		//
		// Slerp
		//
		{
			Vector3 v1 (0.0f,1.0f,0.0f);
			Vector3 v2 (-1.0f,0.0f,0.0f);
			v0.Set(1.0f,0.0f,0.0f);

			// Generate a quaternion Q1 which rotates from v0->v1 and Q2 which rotates v0->v2
			q1.AxisAngle(vz,PI_DIV_TWO);
			q2.AxisAngle(vz,PI);
			// Check that q1 is correct
			Vector3 v3 = v0 * q1;
			UTF_CHECK(CheckVector(v3,v1.X(),v1.Y(),v1.Z()));
			// Check that q2 is correct
			v3 = v0 * q2;
			UTF_CHECK(CheckVector(v3,v2.X(),v2.Y(),v2.Z()));
			// Loop through various ts
			for (float t = 0.0f; t < 1.0f; t += 0.1f)
			{
				// Calculate the vector through conventional means
				float theta = (PI_DIV_TWO * t);
				float x = -sinf(theta);
				float y = Axiom::Math::Cosine(theta);
				// Calculate the quaternion via slerp
				q0 = Slerp(t,q1,q2);
				// Apply it to v0
				v0.Set(1.0f,0.0f,0.0f);
				v0 = v0 * q0;
				// Compare results
				UTF_CHECK(Equal(x,v0.X()));
				UTF_CHECK(Equal(y,v0.Y()));
			}
		}

		//
		// Inverse
		//
		v0.Set(1.0f,2.0f,3.0f);
		q0.AxisAngle(vz,PI_DIV_FOUR);
		v0 = v0 * q0;
		q0 = q0.AsInverse();
		v0 = v0 * q0;
		UTF_CHECK(CheckVector(v0,1.0f,2.0f,3.0f));

		v0.Set(1.0f,2.0f,3.0f);
		q0.AxisAngle(vz,PI_DIV_FOUR);
		v0 = v0 * q0;
		q0.Invert();
		v0 = v0 * q0;
		UTF_CHECK(CheckVector(v0,1.0f,2.0f,3.0f));

		//
		// CreateQuaternionFromVectors
		//
		Vector3 vR0(-18.0f,1.0f,4.0f);
		vR0.Normalize();
		Vector3 vR1(1.0f,4.0f,10.0f);
		vR1.Normalize();
		Axiom::Math::Quaternion rotate = Axiom::Math::CreateQuaternionFromVectors(vR0, vR1);
		vR0 = vR0 * rotate;
		UTF_CHECK(CheckVector(vR0, vR1));

	}
	END_UNITTEST

END_UNITTESTGROUP( Maths_Reference_Quaternion )


//====================================================================
//
//!	@file 	math_tests_group.cpp
//!	@brief	Master group definition for all Maths unit tests
//
//	created:	5:25:2007
//	author:		mattd
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include <UnitTesting.h>

DECLARE_UNITTESTGROUP(Maths_Reference_Vector)
DECLARE_UNITTESTGROUP(Maths_Reference_Matrix4)
DECLARE_UNITTESTGROUP(Maths_Reference_Quaternion)

#if CORE_XBOX360
	DECLARE_UNITTESTGROUP(Maths_Xbox360_Vector)
	DECLARE_UNITTESTGROUP(Maths_Xbox360_Matrix4)
	DECLARE_UNITTESTGROUP(Maths_Xbox360_Quaternion)
	DECLARE_UNITTESTGROUP(Maths_Xbox360_CameraTests)
#endif
#if CORE_PS3
	DECLARE_UNITTESTGROUP(Maths_PS3_Vector)
	DECLARE_UNITTESTGROUP(Maths_PS3_Matrix4)
	DECLARE_UNITTESTGROUP(Maths_PS3_Quaternion)
	DECLARE_UNITTESTGROUP(Maths_PS3_CameraTests)
#endif
DECLARE_UNITTESTGROUP(Math_GenericGroup)

BEGIN_UNITTESTGROUP(MathsGroup)
	RUN_UNITTESTSUBGROUP(Maths_Reference_Vector)
	RUN_UNITTESTSUBGROUP(Maths_Reference_Matrix4)
	RUN_UNITTESTSUBGROUP(Maths_Reference_Quaternion)
	#if CORE_XBOX360
		RUN_UNITTESTSUBGROUP(Maths_Xbox360_Vector)
		RUN_UNITTESTSUBGROUP(Maths_Xbox360_Matrix4)
		RUN_UNITTESTSUBGROUP(Maths_Xbox360_Quaternion)
		RUN_UNITTESTSUBGROUP(Maths_Xbox360_CameraTests)
	#endif
	#if CORE_PS3
		RUN_UNITTESTSUBGROUP(Maths_PS3_Vector)
		RUN_UNITTESTSUBGROUP(Maths_PS3_Matrix4)
		RUN_UNITTESTSUBGROUP(Maths_PS3_Quaternion)
		RUN_UNITTESTSUBGROUP(Maths_PS3_CameraTests)
	#endif
	RUN_UNITTESTSUBGROUP(Math_GenericGroup)
END_UNITTESTGROUP(MathsGroup)


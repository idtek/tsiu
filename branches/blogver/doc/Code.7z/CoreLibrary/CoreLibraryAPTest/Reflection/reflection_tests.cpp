// CoreReflectionUnitTest.cpp - (c) 2006 Action Pants Inc.
// --------------------------------------------------------------------------------------------------------------------
#include "unittesting.h"

#if !CORE_PS3
#include "collections/list.h"

#include "core/core.h"

namespace ReflectionTest
{

	class Test
	{
		public:
			Test(int i, unsigned u, float f)
				: mInt(i)
				, mUInt(u)
				, mString("Test")
				, mFloat(f)
				, mPointerArray(NULL)
				, mPointerArrayCount(25)
				, mSelfTest(NULL)
			{
				for (const char* i = mString; *i != '\0'; ++i)
					mStringArray.Add(*i);
				mStringArray.Add('\0');

				mPointerArray = AP_NEW(Axiom::Memory::RESERVED_SYSTEMS_HEAP, float[mPointerArrayCount]);
				mSelfTest = this;
			}
			~Test()
			{
				delete mPointerArray;
			}

			int size() const 
			{ 
				return mPointerArrayCount; 
			}

			void DoSomething()
			{ 
			}

			float& operator[](const int index) 
			{ 
				return mPointerArray[index]; 
			}

			AP_DECLARE_TYPE(); 

		public:
			int mInt;
			unsigned mUInt;
			const char* mString;
			float mFloat;
			Axiom::Collections::StaticList<char, 64> mStringArray;
			float* mPointerArray;
			unsigned mPointerArrayCount;
			Test* mSelfTest;
	};

	AP_TYPE(Test)
		AP_INDEX_OPERATOR()
		AP_FIELD("mPointerArrayCount", mPointerArrayCount, "Number of elements we can index")
			AP_INDEX_LENGTH_FIELD()
		AP_FIELD("mInt", mInt, "Test integer")
		AP_FIELD("mUInt", mUInt, "Test unsigned integer")
		AP_FIELD("mFloat", mFloat, "Test float")
		AP_FIELD("mString", mString, "Test String Pointer")
		AP_FIELD("mStringArray", mStringArray, "Test String array")
		AP_FIELD("mSelfTest", mSelfTest, "Test object recursion")
		AP_COMMAND(size, "Get the size of the array.")
		AP_COMMAND(DoSomething, "This command does something.")
	AP_TYPE_END()

} // namespace ReflectionTest;


BEGIN_UNITTESTGROUP(ReflectionGroup)
{
	using namespace AP::Reflection;
	using namespace ReflectionTest;

	BEGIN_UNITTEST(ReflectionEngineTest)
	{ 
		// Reflection Unit tests
		char hello[] = "Hello";
		//AP::Collections::StaticList<char, sizeof("Hello")> hello = "Hello";
		ReflectionTest::Test gTest(1, 2, 12.5f);
		Instance gTestInstance(&gTest);
		Instance mInt = gTestInstance.GetField("mInt");
		Instance mFloat = gTestInstance.GetField("mFloat");
		Instance mString = gTestInstance.GetField("mString");
		Instance mStringArray = gTestInstance.GetField("mStringArray");
		Instance mSelfTest = gTestInstance.GetField("mSelfTest");
		Instance mErrorTest = gTestInstance.GetField("mErrorTest");
		Instance mSelfTestInt = mSelfTest.GetField("mInt");
		Instance mSelfTestString = mSelfTest.GetField("mString");
		Instance mSelfTestStringArray = mSelfTest.GetField("mStringArray");

		Instance mSelfTestInstance = mSelfTest.As<Instance>();
		UTF_CHECK(mSelfTestInstance == mSelfTest);
		Instance mSelfTestInstanceRef = mSelfTest.As<Instance&>();
		UTF_CHECK(mSelfTestInstanceRef == mSelfTest);

		for (int i = gTest.size(); i--; )
			mSelfTest[i] = i * 0.1f;

		UTF_CHECK(1 == mInt.As<int>());
		mInt = 5;
		UTF_CHECK(mSelfTestInt == gTest.mInt);
		UTF_CHECK(12.5f == mFloat.As<float>());
		mFloat = 2.5f;
		UTF_CHECK(2.5f == gTest.mFloat);
		UTF_CHECK(Axiom::StringCompare("Test", mString.As<char*>(), 4) == 0);
		UTF_CHECK(Axiom::StringCompare("Test", &mStringArray[0].As<char>(), 4) == 0);
		mString = &hello[0];
		gTest.mStringArray.Clear(); //mStringArray.GetCommand<void ()>("Clear")();
		for (int i = 0; i < (sizeof(hello) / sizeof(hello[0])); ++i )
		{
			gTest.mStringArray.AddDefault(); //mStringArray.GetCommand<void ()>("AddDefault")();
			mStringArray[i] = hello[i];
		}
		hello[3] = 'p';
		UTF_CHECK(Axiom::StringCompare("Helpo", gTest.mString, 5) == 0);
		UTF_CHECK(Axiom::StringCompare("Hello", &gTest.mStringArray[0], 5) == 0);
		mStringArray[0] = 'y';
		UTF_CHECK(Axiom::StringCompare("Helpo", mSelfTestString.As<const char*>(), 5) == 0);
		UTF_CHECK(Axiom::StringCompare("yello", &mSelfTestStringArray[0].As<char>(), 5) == 0);
		for (unsigned i = mSelfTest.GetField("mPointerArrayCount").As<unsigned>(); i--; )
		{
			const float value = i * 0.1f;
			UTF_CHECK(value == mSelfTest[i].As<float>());
		}
		UTF_CHECK(!mErrorTest.IsValid());
		//UTF_CHECK(static_cast<int>(mSelfTest.GetField("mPointerArrayCount").As<unsigned>()) == mSelfTest.GetCommand<int ()>("size")());

		// Test lua reflection
		const char* reflectionTest = 
			" Test.mInt = ((Test.mFloat * Test[10] + Test.mSelfTest[20] + Test.mSelfTest[20]) / Test.mUInt) - Test.mUInt "
			" Test.mFloat = 3.5 "
			" return Test.mInt, Test.mUInt, Test.mFloat, Test.size() ";
		const char* pairsTest = 
			" local count = 0 "
			" for key, value in pairs(Test) do "
			// "   print('' .. key) "
			"   count = count + 1 "
			" end "
			" return count ";
		const char* ipairsTest = 
			" local count = 0 "
			" for key, value in ipairs(Test) do "
			// "   print('' .. key) "
			"   count = count + 1 "
			" end "
			" return count ";
		Script::Init();
		Script::Register("Test", Instance(&gTest), "This is a test object");
		{	// There is currently a bug that if any Result structure is not cleaned up 
			// before destroying the scripting system the application will crash when 
			// cleaning up your script result
			Script::Result r = Script::Execute(reflectionTest);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<int>(0) == gTest.mInt);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<unsigned>(1) == gTest.mUInt);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<float>(2) == gTest.mFloat);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<int>(3) == gTest.size());
			char buffer[80]; 
			Axiom::StringFormat(buffer, array_count(buffer), "%d, %d, %3.1f, %d", gTest.mInt, gTest.mUInt, gTest.mFloat, gTest.size());
			UTF_CHECK(Script::SUCCESS == r.Error() && 0 == Axiom::StringCompare(r.ToString(), buffer, array_count(buffer)));
			Script::GarbageCollect(Script::GCM_FullCollection, Script::GCM_TunedCollectionValue);
			
			r = Script::Execute(pairsTest);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<int>(0) == gTest.size() + 7); // 32
			Script::GarbageCollect(Script::GCM_FullCollection, Script::GCM_TunedCollectionValue);
			
			r = Script::Execute(ipairsTest);
			UTF_CHECK(Script::SUCCESS == r.Error() && r.Get<int>(0) == gTest.size()); // 25
			Script::GarbageCollect(Script::GCM_FullCollection, Script::GCM_TunedCollectionValue);
		}
		Script::Unregister("Test");
		Script::Destroy();
	}
	END_UNITTEST

}	
END_UNITTESTGROUP(ReflectionGroup)

#else
BEGIN_UNITTESTGROUP(ReflectionGroup)
{
}
END_UNITTESTGROUP(ReflectionGroup)

#endif

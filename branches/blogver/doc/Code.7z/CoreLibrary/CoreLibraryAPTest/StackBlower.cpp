//#include <UnitTesting.h>
#include "unittesting.h"
#include <Collections/linkedlistarray.h>
#include <string/string.h>
#include "debug/assert.h"
#if CORE_WIN32
#include <conio.h>
#endif

using namespace Axiom;
using namespace Axiom::Collections;
typedef ShortString TestString;

//--------------------------------------------

DECLARE_UNITTESTGROUP(StackBlowerGroupTest)


BEGIN_UNITTESTGROUP(StackBlowerGroup)
{
	RUN_UNITTESTSUBGROUP(StackBlowerGroupTest);
}
END_UNITTESTGROUP(StackBlowerGroup)
//--------------------------------------------

BEGIN_UNITTESTGROUP( StackBlowerGroupTest )
{
	BEGIN_UNITTEST(Constructors)
	{
		LinkedListArray <int, 27> Array;

		int Size = sizeof (Array);

		/*UTF_CHECK(Array.Capacity () == 1000);
		UTF_CHECK(Array.RemainingCapacity () == 1000);*/
		UTF_CHECK(Size != 1);
	}
	END_UNITTEST
 
	BEGIN_UNITTEST(InsertingLinks)
	{
		int x = 3 * 2;
		UTF_CHECK (x != 0);
	}
	END_UNITTEST
}
END_UNITTESTGROUP( StackBlowerGroupTest )


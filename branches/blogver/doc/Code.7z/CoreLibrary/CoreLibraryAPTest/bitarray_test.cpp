#include <UnitTesting.h>
#include <core/bitarray.h>

using namespace Axiom;

BEGIN_UNITTESTGROUP( BitArrayTestGroup )
{
	
	//Testing Base case of BitArray Test
	BEGIN_UNITTEST(BitArrayBaseContructorDestructorTest)
	{
		const int size = 100;
		BitArray ba (size);
		int x = ba.GetAllocatedSize ();
		UTF_CHECK (x == 168);
		UTF_CHECK (ba.Count () == 0);
		UTF_CHECK (ba.Capacity () == size);
	}
	END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(BitArrayFunctionalTest)
	{
		const int size = 100;
		BitArray ba (size);
		UTF_CHECK (ba.GetAllocatedSize () == 168);
		UTF_CHECK (ba.Count () == 0);
		UTF_CHECK (ba.Capacity () == size);

		bool	Flag = ba[10];
		UTF_CHECK (Flag == false);
		ba.SetAll ();
		Flag = ba.Get (10);
		UTF_CHECK (Flag == true);
		Flag = ba.Get (21);
		UTF_CHECK (Flag == true);

		ba.Set (21);
		Flag = ba.Get (21);
		UTF_CHECK (Flag == true);

		ba.Clear (21);
		Flag = ba.Get (21);
		UTF_CHECK (Flag == false);	

		ba.Flip (21);
		Flag = ba.Get (21);
		UTF_CHECK (Flag == true);

		UTF_CHECK (ba.Count () == size);

		for (int i=0; i<100; i++)
		{
			ba.Clear (i);
			UTF_CHECK (ba.Count () == size - i - 1);
		}

		ba.Set (21);
		int FoundBit = ba.FindSetBit ();
		UTF_CHECK (FoundBit == 21);

		ba.SetAll ();
		ba.Clear (21);
		FoundBit = ba.FindOpenBit ();
		UTF_CHECK (FoundBit == 21);

	}	
	END_UNITTEST

	BEGIN_UNITTEST(BitArraySearchTest)
	{
		const int size = 100;
		BitArray ba (size);
		UTF_CHECK (ba.GetAllocatedSize () == 168);
		UTF_CHECK (ba.Count () == 0);
		UTF_CHECK (ba.Capacity () == size);

		ba.Set (21);
		int FoundBit = ba.FindSetBit ();
		UTF_CHECK (FoundBit == 21);

		ba.SetAll ();
		ba.Clear (21);
		FoundBit = ba.FindOpenBit ();
		UTF_CHECK (FoundBit == 21);

	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BitArrayBoundaryTest)
	{
		const int size = 100;
		BitArray ba (size);
		UTF_CHECK (ba.GetAllocatedSize () == 168);
		UTF_CHECK (ba.Count () == 0);
		UTF_CHECK (ba.Capacity () == size);

		ba.Set (-1);
		ba.Set (101);

		UTF_CHECK (ba.Count () == 0);
		UTF_CHECK (ba.Capacity () == size);

		UTF_CHECKASSERT (ba.Get (-1));
		UTF_CHECKASSERT (ba [-1]);
	}
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BitArrayMemoryOverwriteTest)
	{
		const Byte ValueSet = 0x11;
		const int MemorySize = 2048;
		const int MemoryOffsetForBitarray = 512;
		const int size = 100;
		Byte* Buffer = new Byte [MemorySize];
		memset (Buffer, ValueSet, MemorySize);

		Byte* BufferPointer = &Buffer [MemoryOffsetForBitarray];
		BitArray* ba = new (BufferPointer) BitArray (size, (BufferPointer));
		int AllocatedSize = ba->GetAllocatedSize ();

		ba->Set (-1);
		ba->Set (101);

		UTF_CHECK (ba->Count () == 0);
		UTF_CHECK (ba->Capacity () == size);

		UTF_CHECKASSERT (ba->Get (-1));
		UTF_CHECKASSERT ((*ba) [-1]);

		for (int i=0; i<size; i++)
		{
			ba->Set (i);
		}

		// validate that there is no memory overwrite
		for (int i=0; i<MemoryOffsetForBitarray; i++)
		{
			UTF_CHECK (Buffer[i] == ValueSet);
		}

		for (int i=MemoryOffsetForBitarray+AllocatedSize; i<MemorySize; i++)
		{
			Byte val = Buffer[i];
			if (val != ValueSet)
				i = i;
			UTF_CHECK (Buffer[i] == ValueSet);
		}

		ba->~BitArray ();
		delete Buffer;
	}
	END_UNITTEST
}
END_UNITTESTGROUP( CrcTestGroup )

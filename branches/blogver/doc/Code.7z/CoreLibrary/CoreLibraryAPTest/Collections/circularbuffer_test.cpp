#include <UnitTesting.h>
#include <string/string.h>
#include <collections/circularbuffer.h>

using namespace Axiom;
using namespace Axiom::Collections;

String CreateStringFromInt (int i)
{
	char buf [32];
	sprintf(buf,"%d",i);
	return String(buf);
}

struct MisalignedBigStruct
{
	int x;
	int y;
	int z;
	bool TestValue;
	int A, B, C;
	MisalignedBigStruct(int value = 0) 
		: x(value), y(value), z(value), TestValue(true) {}
};

DECLARE_UNITTESTGROUP(CircularBufferFromIntGroup)
DECLARE_UNITTESTGROUP(CircularBufferFromStringGroup)
DECLARE_UNITTESTGROUP(CircularBufferFromIntPointerGroup)
DECLARE_UNITTESTGROUP(CircularBufferFromMisalignedBigStructGroup)

BEGIN_UNITTESTGROUP(CircularBufferGroup)
{
	RUN_UNITTESTSUBGROUP(CircularBufferFromIntGroup);
	RUN_UNITTESTSUBGROUP(CircularBufferFromStringGroup);
	RUN_UNITTESTSUBGROUP(CircularBufferFromIntPointerGroup);
	RUN_UNITTESTSUBGROUP(CircularBufferFromMisalignedBigStructGroup);
}
END_UNITTESTGROUP(CircularBufferGroup)

const int numTestElements = 16;

BEGIN_UNITTESTGROUP(CircularBufferFromIntGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int
	// Testing basic constructor/destructor
	BEGIN_UNITTEST(Constructors)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		DynamicCircularBuffer<ELEMENT_TYPE> col1;
		col1.Resize(0, 100);
	}
	END_UNITTEST
	
    // Testing copy ctor
    BEGIN_UNITTEST(CopyConstructors)
    {
        DynamicCircularBuffer<ELEMENT_TYPE> cBuf;
        cBuf.Resize( 0, numTestElements );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            cBuf.Add( ELEMENT_CONVERSION(i) );
        }
        
        DynamicCircularBuffer<ELEMENT_TYPE> cBufCopy( cBuf );

        for( int i = 0; i < numTestElements; ++i )
        {
            int testValue = cBufCopy[i];
            int expectedValue = ( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
        
        cBuf.Add( ELEMENT_CONVERSION (99) );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            int testValue = cBufCopy[i];
            int expectedValue = ( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
    }
    END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(FunctionalTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
		UTF_CHECK(col0.Capacity() == 0);

		const uint bufferSize = 4;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		//Add a single item and retrieve it
		col0.Add(ELEMENT_CONVERSION (1));
		
		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 1);
		UTF_CHECK(col0[0] == 1);
		UTF_CHECKASSERT(col0[1]);
		UTF_CHECKASSERT(col0[2]);
		UTF_CHECKASSERT(col0[3]);

		//Add a second item
		col0.Add(ELEMENT_CONVERSION (2));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 2);
		UTF_CHECK(col0[0] == 2);
		UTF_CHECK(col0[1] == 1);
		UTF_CHECKASSERT(col0[2]);
		UTF_CHECKASSERT(col0[3]);

		//Add a third item
		col0.Add(ELEMENT_CONVERSION (3));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 3);
		UTF_CHECK(col0[0] == 3);
		UTF_CHECK(col0[1] == 2);
		UTF_CHECK(col0[2] == 1);
		UTF_CHECKASSERT(col0[3]);

		//Add a fourth item
		col0.Add(ELEMENT_CONVERSION (4));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0] == 4);
		UTF_CHECK(col0[1] == 3);
		UTF_CHECK(col0[2] == 2);
		UTF_CHECK(col0[3] == 1);

		//Check wrap around
		col0.Add(ELEMENT_CONVERSION (5));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0] == 5);
		UTF_CHECK(col0[1] == 4);
		UTF_CHECK(col0[2] == 3);
		UTF_CHECK(col0[3] == 2);

		//Check full wrap
		col0.Add(ELEMENT_CONVERSION (6));
		col0.Add(ELEMENT_CONVERSION (7));
		col0.Add(ELEMENT_CONVERSION (8));
		col0.Add(ELEMENT_CONVERSION (9));
		col0.Add(ELEMENT_CONVERSION (10));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0] == 10);
		UTF_CHECK(col0[1] == 9);
		UTF_CHECK(col0[2] == 8);
		UTF_CHECK(col0[3] == 7);

		//Check out of range
		UTF_CHECKASSERT(col0[4]);

		col0.Clear();
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BoundaryTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize(0, 0);
		UTF_CHECKASSERT(col0[0]);
	}
	END_UNITTEST

	// Test ctor only, all other tests are performed elsewhere
	BEGIN_UNITTEST(CopyCtorTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0; 
		const uint bufferSize = 4;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		//Add a single item and retrieve it
		col0.Add(ELEMENT_CONVERSION (1));
		col0.Add(ELEMENT_CONVERSION (2));
		col0.Add(ELEMENT_CONVERSION (3));
		col0.Add(ELEMENT_CONVERSION (4));// it's circular so it wraps here
		col0.Add(ELEMENT_CONVERSION (5));
		col0.Add(ELEMENT_CONVERSION (6));

		DynamicCircularBuffer<ELEMENT_TYPE> col1 = col0;
		
		UTF_CHECK(col1.IsEmpty() == false);
		UTF_CHECK(col1.Count() == 4);
		UTF_CHECK(col1[0] == ELEMENT_CONVERSION (6));
		UTF_CHECK(col1[1] == ELEMENT_CONVERSION (5));
		UTF_CHECK(col1[2] == ELEMENT_CONVERSION (4)); 
		UTF_CHECK(col1[3] == ELEMENT_CONVERSION (3));
		UTF_CHECKASSERT(col1[4]);
		UTF_CHECKASSERT(col1[5]);
		
		// let's check for a real copy and not simply a reference.
		col1.Clear();
		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() != 0);

		// are the values in the original still valid
		UTF_CHECK(col0[0] == ELEMENT_CONVERSION (6));
		UTF_CHECK(col0[1] == ELEMENT_CONVERSION (5));
		UTF_CHECK(col0[2] == ELEMENT_CONVERSION (4)); 
		UTF_CHECK(col0[3] == ELEMENT_CONVERSION (3));
	}	
	END_UNITTEST

	BEGIN_UNITTEST(EqualsOperator)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize( 0, numTestElements );

		for( int i = 0; i < numTestElements; ++i )
        {
            col0.Add( ELEMENT_CONVERSION (i) );
        }
		DynamicCircularBuffer<ELEMENT_TYPE> col1 (col0);// copy c'tor
		DynamicCircularBuffer<ELEMENT_TYPE> col2;
		col2 = col1;

		for (int i=0; i < numTestElements; i++)
		{
			UTF_CHECK (col0[i] == col2[i]);
		}
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP( CircularBufferFromIntGroup );

//----------------------------------------------------------------------

BEGIN_UNITTESTGROUP(CircularBufferFromStringGroup)
{
#define ELEMENT_CONVERSION(x) CreateStringFromInt (x)
#define ELEMENT_TYPE String
	// Testing basic constructor/destructor
	BEGIN_UNITTEST(Constructors)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		DynamicCircularBuffer<ELEMENT_TYPE> col1;
		col1.Resize(0, 100);
	}
	END_UNITTEST

	// Testing copy ctor
    BEGIN_UNITTEST(CopyConstructors)
    {
        DynamicCircularBuffer<ELEMENT_TYPE> cBuf;
        cBuf.Resize( 0, numTestElements );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            cBuf.Add( ELEMENT_CONVERSION(i) );
        }
        
        DynamicCircularBuffer<ELEMENT_TYPE> cBufCopy( cBuf );

        for( int i = 0; i < numTestElements; ++i )
        {
            ELEMENT_TYPE testValue = cBufCopy[i];
            ELEMENT_TYPE expectedValue = ELEMENT_CONVERSION( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
        
        cBuf.Add( ELEMENT_CONVERSION (99) );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            ELEMENT_TYPE testValue = cBufCopy[i];
            ELEMENT_TYPE expectedValue = ELEMENT_CONVERSION( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
    }
    END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(FunctionalTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
		UTF_CHECK(col0.Capacity() == 0);

		const uint bufferSize = 3;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		// Add data to col0 twice around the buffer
		col0.Add(ELEMENT_CONVERSION (0));
		col0.Add(ELEMENT_CONVERSION (1));
		col0.Add(ELEMENT_CONVERSION (2));
		col0.Add(ELEMENT_CONVERSION (3));
		col0.Add(ELEMENT_CONVERSION (4));
		col0.Add(ELEMENT_CONVERSION (5));

		//Check the data
		UTF_CHECK(col0[0] == ELEMENT_CONVERSION (5));
		UTF_CHECK(col0[1] == ELEMENT_CONVERSION (4));
		UTF_CHECK(col0[2] == ELEMENT_CONVERSION (3));
		UTF_CHECKASSERT(col0[3]);

		col0.Clear();
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BoundaryTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize(0, 0);
		UTF_CHECKASSERT(col0[0]);
	}
	END_UNITTEST

	// Test ctor only, all other tests are performed elsewhere
	BEGIN_UNITTEST(CopyCtorTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0; 
		const uint bufferSize = 4;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		//Add a single item and retrieve it
		col0.Add(ELEMENT_CONVERSION (1));
		col0.Add(ELEMENT_CONVERSION (2));
		col0.Add(ELEMENT_CONVERSION (3));
		col0.Add(ELEMENT_CONVERSION (4));// it's circular so it wraps here
		col0.Add(ELEMENT_CONVERSION (5));
		col0.Add(ELEMENT_CONVERSION (6));

		DynamicCircularBuffer<ELEMENT_TYPE> col1 = col0;
		
		UTF_CHECK(col1.IsEmpty() == false);
		UTF_CHECK(col1.Count() == 4);
		UTF_CHECK(col1[0] == ELEMENT_CONVERSION (6));
		UTF_CHECK(col1[1] == ELEMENT_CONVERSION (5));
		UTF_CHECK(col1[2] == ELEMENT_CONVERSION (4)); 
		UTF_CHECK(col1[3] == ELEMENT_CONVERSION (3));
		UTF_CHECKASSERT(col1[4]);
		UTF_CHECKASSERT(col1[5]);
		
		// let's check for a real copy and not simply a reference.
		col1.Clear();
		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() != 0);

		// are the values in the original still valid
		UTF_CHECK(col0[0] == ELEMENT_CONVERSION (6));
		UTF_CHECK(col0[1] == ELEMENT_CONVERSION (5));
		UTF_CHECK(col0[2] == ELEMENT_CONVERSION (4)); 
		UTF_CHECK(col0[3] == ELEMENT_CONVERSION (3));
	}	
	END_UNITTEST

	BEGIN_UNITTEST(EqualsOperator)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize( 0, numTestElements );

		for( int i = 0; i < numTestElements; ++i )
        {
            col0.Add( CreateStringFromInt(i) );
        }
		DynamicCircularBuffer<ELEMENT_TYPE> col1 (col0);// copy c'tor
		DynamicCircularBuffer<ELEMENT_TYPE> col2;
		col2 = col1;

		for (int i=0; i < numTestElements; i++)
		{
			UTF_CHECK (col0[i] == col2[i]);
		}
	}
	END_UNITTEST
#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(CircularBufferFromStringGroup)

	//----------------------------------------------------------------------

BEGIN_UNITTESTGROUP(CircularBufferFromIntPointerGroup)
{
	#define ELEMENT_CONVERSION(x) &x
	#define ELEMENT_TYPE int*
	// Testing basic constructor/destructor
	BEGIN_UNITTEST(Constructors)
	{
		// Quick con/des test
		{
			DynamicCircularBuffer<ELEMENT_TYPE> col0;
			DynamicCircularBuffer<ELEMENT_TYPE> col1;
			col1.Resize(0, 100);
		}
	}
	END_UNITTEST

		// Testing copy ctor
    BEGIN_UNITTEST(CopyConstructors)
    {
        DynamicCircularBuffer<ELEMENT_TYPE> cBuf;
        cBuf.Resize( 0, numTestElements );
		int bufferPool[numTestElements*2];
		for (int i=1; i<=numTestElements; i++)
			bufferPool[i-1] = i;
        
        for( int i = 0; i < numTestElements; ++i )
        {
            cBuf.Add( ELEMENT_CONVERSION(bufferPool[i]) );
        }
        
        DynamicCircularBuffer<ELEMENT_TYPE> cBufCopy( cBuf );

        for( int i = 0; i < numTestElements; ++i )
        {
            ELEMENT_TYPE testValue = cBufCopy[i];
            ELEMENT_TYPE expectedValue = ELEMENT_CONVERSION(bufferPool[numTestElements-i-1]);
            UTF_CHECK( testValue == expectedValue );
        }
        
        cBuf.Add( ELEMENT_CONVERSION (bufferPool[numTestElements]) );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            ELEMENT_TYPE testValue = cBufCopy[i];
            ELEMENT_TYPE expectedValue = ELEMENT_CONVERSION(bufferPool[numTestElements-i-1]);
            UTF_CHECK( testValue == expectedValue );
        }
    }
    END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(FunctionalTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
		UTF_CHECK(col0.Capacity() == 0);

		const uint bufferSize = 5;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		int bufferPool[bufferSize*2];

		// Add data to col0 twice around the buffer
		for(unsigned i=0;i<bufferSize*2;i++)
		{
			bufferPool[i] = i;
			col0.Add( ELEMENT_CONVERSION(bufferPool[i]));
		}

		UTF_CHECK(col0.Count()==bufferSize);
		UTF_CHECK(!col0.IsEmpty());

		// Confirm data is correct
		UTF_CHECK(col0[0] == ELEMENT_CONVERSION(bufferPool[9]));
		UTF_CHECK(col0[1] == ELEMENT_CONVERSION(bufferPool[8]));
		UTF_CHECK(col0[2] == ELEMENT_CONVERSION(bufferPool[7]));
		UTF_CHECK(col0[3] == ELEMENT_CONVERSION(bufferPool[6]));
		UTF_CHECK(col0[4] == ELEMENT_CONVERSION(bufferPool[5]));
		UTF_CHECKASSERT(col0[5]);

		//Clear and check
		col0.Clear();
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BoundaryTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize(0, 0);
		UTF_CHECKASSERT(col0[0]);
	}
	END_UNITTEST

	BEGIN_UNITTEST(EqualsOperator)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize( 0, numTestElements );
		int bufferPool[numTestElements*2];

		for( int i = 0; i < numTestElements; ++i )
        {
            col0.Add( ELEMENT_CONVERSION (bufferPool[i]) );
        }
		DynamicCircularBuffer<ELEMENT_TYPE> col1 (col0);// copy c'tor
		DynamicCircularBuffer<ELEMENT_TYPE> col2;
		col2 = col1;

		for (int i=0; i < numTestElements; i++)
		{
			UTF_CHECK (col0[i] == col2[i]);
		}
	}
	END_UNITTEST
	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(CircularBufferFromIntPointerGroup)

	//----------------------------------------------------------------------

BEGIN_UNITTESTGROUP(CircularBufferFromMisalignedBigStructGroup)
{
	#define ELEMENT_CONVERSION(x) MisalignedBigStruct(x)
	#define ELEMENT_TYPE MisalignedBigStruct
	// Testing basic constructor/destructor
	BEGIN_UNITTEST(Constructors)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		DynamicCircularBuffer<ELEMENT_TYPE> col1;
		col1.Resize(0, 100);
	}
	END_UNITTEST
	
    // Testing copy ctor
    BEGIN_UNITTEST(CopyConstructors)
    {
        DynamicCircularBuffer<ELEMENT_TYPE> cBuf;
        cBuf.Resize( 0, numTestElements );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            cBuf.Add( ELEMENT_CONVERSION(i) );
        }
        
        DynamicCircularBuffer<ELEMENT_TYPE> cBufCopy( cBuf );

        for( int i = 0; i < numTestElements; ++i )
        {
            int testValue = cBufCopy[i].x;
            int expectedValue = ( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
        
        cBuf.Add( ELEMENT_CONVERSION(99) );
        
        for( int i = 0; i < numTestElements; ++i )
        {
            int testValue = cBufCopy[i].x;
            int expectedValue = ( ( numTestElements - 1 ) - i );
            UTF_CHECK( testValue == expectedValue );
        }
    }
    END_UNITTEST

	// Test all other functional use
	BEGIN_UNITTEST(FunctionalTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
		UTF_CHECK(col0.Capacity() == 0);

		const uint bufferSize = 4;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		//Add a single item and retrieve it
		col0.Add( ELEMENT_CONVERSION (1));
		
		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 1);
		UTF_CHECK(col0[0].x == 1);
		UTF_CHECKASSERT(col0[1]);
		UTF_CHECKASSERT(col0[2]);
		UTF_CHECKASSERT(col0[3]);

		//Add a second item
		col0.Add(ELEMENT_CONVERSION(2));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 2);
		UTF_CHECK(col0[0].x == 2);
		UTF_CHECK(col0[1].x == 1);
		UTF_CHECKASSERT(col0[2]);
		UTF_CHECKASSERT(col0[3]);

		//Add a third item
		col0.Add(ELEMENT_CONVERSION(3));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 3);
		UTF_CHECK(col0[0].x == 3);
		UTF_CHECK(col0[1].x == 2);
		UTF_CHECK(col0[2].x == 1);
		UTF_CHECKASSERT(col0[3]);

		//Add a fourth item
		col0.Add(ELEMENT_CONVERSION(4));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0].x == 4);
		UTF_CHECK(col0[1].x == 3);
		UTF_CHECK(col0[2].x == 2);
		UTF_CHECK(col0[3].x == 1);

		//Check wrap around
		col0.Add(ELEMENT_CONVERSION(5));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0].x == 5);
		UTF_CHECK(col0[1].x == 4);
		UTF_CHECK(col0[2].x == 3);
		UTF_CHECK(col0[3].x == 2);

		//Check full wrap
		col0.Add(ELEMENT_CONVERSION(6));
		col0.Add(ELEMENT_CONVERSION(7));
		col0.Add(ELEMENT_CONVERSION(8));
		col0.Add(ELEMENT_CONVERSION(9));
		col0.Add(ELEMENT_CONVERSION(10));

		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() == 4);
		UTF_CHECK(col0[0].x == 10);
		UTF_CHECK(col0[1].x == 9);
		UTF_CHECK(col0[2].x == 8);
		UTF_CHECK(col0[3].x == 7);

		//Check out of range
		UTF_CHECKASSERT(col0[4]);

		col0.Clear();
		UTF_CHECK(col0.IsEmpty());
		UTF_CHECK(col0.Count() == 0);
	}	
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(BoundaryTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize(0, 0);
		UTF_CHECKASSERT(col0[0]);
	}
	END_UNITTEST

	// Test ctor only, all other tests are performed elsewhere
	BEGIN_UNITTEST(CopyCtorTest)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0; 
		const uint bufferSize = 4;
		col0.Resize(0, bufferSize);
		UTF_CHECK(col0.Capacity() == bufferSize);
		UTF_CHECK(col0.Count() == 0);

		//Add a single item and retrieve it
		col0.Add(ELEMENT_CONVERSION(1));
		col0.Add(ELEMENT_CONVERSION(2));
		col0.Add(ELEMENT_CONVERSION(3));
		col0.Add(ELEMENT_CONVERSION(4));// it's circular so it wraps here
		col0.Add(ELEMENT_CONVERSION(5));
		col0.Add(ELEMENT_CONVERSION(6));

		DynamicCircularBuffer<ELEMENT_TYPE> col1 = col0;
		
		UTF_CHECK(col1.IsEmpty() == false);
		UTF_CHECK(col1.Count() == 4);
		UTF_CHECK(col1[0].x == 6);
		UTF_CHECK(col1[1].x == 5);
		UTF_CHECK(col1[2].x == 4); 
		UTF_CHECK(col1[3].x == 3);
		UTF_CHECKASSERT(col1[4]);
		UTF_CHECKASSERT(col1[5]);
		
		// let's check for a real copy and not simply a reference.
		col1.Clear();
		UTF_CHECK(col0.IsEmpty() == false);
		UTF_CHECK(col0.Count() != 0);

		// are the values in the original still valid
		UTF_CHECK(col0[0].x == 6);
		UTF_CHECK(col0[1].x == 5);
		UTF_CHECK(col0[2].x == 4); 
		UTF_CHECK(col0[3].x == 3);
	}	
	END_UNITTEST

	BEGIN_UNITTEST(EqualsOperator)
	{
		DynamicCircularBuffer<ELEMENT_TYPE> col0;
		col0.Resize( 0, numTestElements );

		for( int i = 0; i < numTestElements; ++i )
        {
            col0.Add( ELEMENT_CONVERSION (i) );
        }
		DynamicCircularBuffer<ELEMENT_TYPE> col1 (col0);// copy c'tor
		DynamicCircularBuffer<ELEMENT_TYPE> col2;
		col2 = col1;

		for (int i=0; i < numTestElements; i++)
		{
			UTF_CHECK (col0[i].x == col2[i].x);
		}
	}
	END_UNITTEST

	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(CircularBufferFromMisalignedBigStructGroup)
//----------------------------------------------------------------------

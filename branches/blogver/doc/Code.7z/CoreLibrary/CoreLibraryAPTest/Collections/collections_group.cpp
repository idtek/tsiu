//====================================================================
//
//!	@file 	collections_group.cpp
//!	@brief	master group for all Collections class unit tests
//
//	created:	5:25:2007
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include <unittesting.h>

USING_UNITTESTGROUP(GtlArrayGroup)
USING_UNITTESTGROUP(FixedArray)
USING_UNITTESTGROUP(StaticArrayGroup)
USING_UNITTESTGROUP(StaticBookletGroup)
USING_UNITTESTGROUP(StaticSortedListGroup)
USING_UNITTESTGROUP(CircularBufferGroup)
USING_UNITTESTGROUP(DynamicListGroup)
USING_UNITTESTGROUP(DynamicCircularListGroup)
USING_UNITTESTGROUP(StaticListGroup)
USING_UNITTESTGROUP(StaticCircularListGroup)
USING_UNITTESTGROUP(ReflectedListGroup)
USING_UNITTESTGROUP(ListSortingGroup)
USING_UNITTESTGROUP(QueueGroup)
USING_UNITTESTGROUP(SetGroup)
USING_UNITTESTGROUP(LinkedListArrayGroup)


BEGIN_UNITTESTGROUP(CollectionsGroup)
{
	RUN_UNITTESTSUBGROUP(FixedArray);
	RUN_UNITTESTSUBGROUP(GtlArrayGroup);
	RUN_UNITTESTSUBGROUP(StaticArrayGroup);
	RUN_UNITTESTSUBGROUP(CircularBufferGroup);
	RUN_UNITTESTSUBGROUP(StaticBookletGroup);
	RUN_UNITTESTSUBGROUP(StaticSortedListGroup);
	RUN_UNITTESTSUBGROUP(DynamicListGroup);
	RUN_UNITTESTSUBGROUP(DynamicCircularListGroup)
	RUN_UNITTESTSUBGROUP(StaticListGroup);
	RUN_UNITTESTSUBGROUP(StaticCircularListGroup);
	RUN_UNITTESTSUBGROUP(ReflectedListGroup);
	RUN_UNITTESTSUBGROUP(ListSortingGroup);
	RUN_UNITTESTSUBGROUP(QueueGroup);
	RUN_UNITTESTSUBGROUP(SetGroup);
	RUN_UNITTESTSUBGROUP(LinkedListArrayGroup);
}
END_UNITTESTGROUP(CollectionsGroup)

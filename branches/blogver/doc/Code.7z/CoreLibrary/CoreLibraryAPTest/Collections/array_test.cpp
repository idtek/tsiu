// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	array_test.cpp
//!	@brief	gtl_array unit tests
//
//	created:	6:4:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include <unittesting.h>
#include <Collections/array.h>
#include <string/string.h>

using namespace Axiom;
using namespace Axiom::Collections;
typedef String TestString;

DECLARE_UNITTESTGROUP(WithIntegerGroup)
DECLARE_UNITTESTGROUP(WithStringGroup)
DECLARE_UNITTESTGROUP(WithStructPointerGroup)

static TestString IntToString (int i)
{
	char buf [32];
	sprintf(buf,"%d",i);
	return TestString(buf);
}

struct TestStruct
{
	TestStruct (int i)
		: mInt(i)
	{
	}

	int mInt;
};

static TestStruct tsData [] = 
{
	TestStruct(0),
	TestStruct(1),
	TestStruct(2),
	TestStruct(3),
	TestStruct(4),
	TestStruct(5),
	TestStruct(6),
	TestStruct(7),
	TestStruct(8),
	TestStruct(9),
	TestStruct(666),
};

static TestStruct* IntToTestStruct (int i)
{
	return &tsData[i < 10 ? i : 10];
}

BEGIN_UNITTESTGROUP(GtlArrayGroup)
{
	RUN_UNITTESTSUBGROUP(WithIntegerGroup);
	RUN_UNITTESTSUBGROUP(WithStringGroup);
	RUN_UNITTESTSUBGROUP(WithStructPointerGroup);
}
END_UNITTESTGROUP(GtlArrayGroup)

BEGIN_UNITTESTGROUP(WithIntegerGroup)
{
	#define ELEMENT_CONVERSION(x) x
	#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		Array<ELEMENT_TYPE> a0;
		UTF_CHECK(a0.Size() == 0);
		UTF_CHECK(a0.Capacity() == 0);

		Array<ELEMENT_TYPE> a1 (100);
		UTF_CHECK(a1.Size() == 0);
		UTF_CHECK(a1.Capacity() == 100);

		Array<ELEMENT_TYPE> a2 (10,ELEMENT_CONVERSION(42));
		UTF_CHECK(a2.Size() == 10);
		UTF_CHECK(a2.Capacity() == 10);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a2[i] == ELEMENT_CONVERSION(42));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		// Making assumption that PushBack works - although it is tested later
		Array<ELEMENT_TYPE> a0;
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));

		Array<ELEMENT_TYPE>::Iterator it;
		Array<ELEMENT_TYPE>::ConstIterator cit;

		// Test Begin
		it = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));
		cit = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));

		// Test End
		it = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));
		cit = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));

		// Test IsEmpty
		UTF_CHECK(false == a0.IsEmpty());
		Array<ELEMENT_TYPE> a1;
		UTF_CHECK(true == a1.IsEmpty());

		// Check Begin() == End() on an empty list
		UTF_CHECK(a1.Begin() == a1.End());

		// Test Size
		UTF_CHECK(a0.Size() == 3);

		// Test Capacity
		UTF_CHECK(a0.Capacity() == AlignUp(3U,8));

		// Test Full
		Array<ELEMENT_TYPE> a2 (3);
		a2.PushBack(ELEMENT_CONVERSION(1));
		a2.PushBack(ELEMENT_CONVERSION(2));
		UTF_CHECK(!a2.Full());
		a2.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a2.Full());

		// Test Front
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(1));
		a2.Front() = ELEMENT_CONVERSION(42);
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(42));
		UTF_CHECKASSERT(a1.Front());

		// Test Back
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(3));
		a2.Back() = ELEMENT_CONVERSION(69);
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(69));
		UTF_CHECKASSERT(a1.Back());
	}
	END_UNITTEST

	BEGIN_UNITTEST(PushPop)
	{
		Array<ELEMENT_TYPE> a0 (10);

		// Test PushBack
		Array<ELEMENT_TYPE>::Iterator it;

		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushBack(ELEMENT_CONVERSION(i));
			UTF_CHECK(it+1 == a0.End());
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PushFront
		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushFront(ELEMENT_CONVERSION(i));
			UTF_CHECK(*a0.Begin() == ELEMENT_CONVERSION(i));
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PopBack
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopBack() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size()==10);

		// Test PopFront
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertErase)
	{
		Array<ELEMENT_TYPE> a0 (10);
		Array<ELEMENT_TYPE>::Iterator it;

		// Test Insert
		it = a0.Insert(a0.Begin(),ELEMENT_CONVERSION(1));
		it = a0.Insert(a0.End(),ELEMENT_CONVERSION(3));
		a0.Insert(it,ELEMENT_CONVERSION(2));
		for (int i = 0; i < 3; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(i+1));
		}

		// Test Erase
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.Erase(a0.Begin());
		UTF_CHECK(a0.Front() == ELEMENT_CONVERSION(2));
		a0.Erase(a0.Begin(),a0.End());
		UTF_CHECK(a0.Size() == 0);

		// Test EraseBack
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.EraseBack(a0.Begin());
		UTF_CHECK(a0.Size() == 2);
		UTF_CHECK(*(a0.Begin()) == ELEMENT_CONVERSION(3));

		// Test Clear
		a0.Clear();
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Resizing)
	{
		Array<ELEMENT_TYPE> a1;
		Array<ELEMENT_TYPE> a2;
		Array<ELEMENT_TYPE> a3;

		// Test Expand
		a1.Expand(1);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a1.Expand(2,false);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a2.Expand(2,false,false);
		UTF_CHECK(a2.Size() == 0);
		UTF_CHECK(a2.Capacity() == 2);

		// Test Reserve
		a3.Reserve(10);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 0);

		// Test Resize
		a3.Resize(3);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 3);
		a3.Resize(20);
		UTF_CHECK(a3.Capacity() == 24);
		UTF_CHECK(a3.Size() == 20);

	}
	END_UNITTEST

	BEGIN_UNITTEST(Swap)
	{
		Array<ELEMENT_TYPE> a4;
		Array<ELEMENT_TYPE> a5;

		// Test Swap
		a4.PushBack(ELEMENT_CONVERSION(1));
		a4.PushBack(ELEMENT_CONVERSION(2));
		a4.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a4.Size() == 3);
		UTF_CHECK(a4.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			a5.PushBack(ELEMENT_CONVERSION(i));
		}
		UTF_CHECK(a5.Size() == 10);
		UTF_CHECK(a5.Capacity() == 16);
		a4.Swap(a5);
		UTF_CHECK(a4.Size() == 10);
		UTF_CHECK(a4.Capacity() == 16);
		UTF_CHECK(a5.Size() == 3);
		UTF_CHECK(a5.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a4.PopFront() == ELEMENT_CONVERSION(i));
		}
		for (int i = 1; i < 4; ++i)
		{
			UTF_CHECK(a5.PopFront() == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.At(i);
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.At(i);

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == a0[i]);
			UTF_CHECK(*cit == a0[i]);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Find)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.Find(ELEMENT_CONVERSION(i));
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.Find(ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(CopyAll)
	{
		const int NumItems = 100;
		Array<ELEMENT_TYPE> a0 (NumItems - 5);
		ELEMENT_TYPE x[NumItems];
		
		for (int i=0; i<NumItems; i++)
		{
			x[i] = ELEMENT_CONVERSION (i);
		}

		a0.CopyAll (x, NumItems);
		// check that everything expanded alright
		UTF_CHECK (static_cast<int>(a0.Size ()) == NumItems);
		UTF_CHECK (static_cast<int>(a0.Capacity ()) >= NumItems);
		for (int i=0; i<NumItems; i++)
		{
			UTF_CHECK (a0[i] == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithIntegerGroup)

BEGIN_UNITTESTGROUP(WithStringGroup)
{
	#define ELEMENT_CONVERSION(x) IntToString(x)
	#define ELEMENT_TYPE TestString

	BEGIN_UNITTEST(Constructors)
	{
		Array<ELEMENT_TYPE> a0;
		UTF_CHECK(a0.Size() == 0);
		UTF_CHECK(a0.Capacity() == 0);

		Array<ELEMENT_TYPE> a1 (100);
		UTF_CHECK(a1.Size() == 0);
		UTF_CHECK(a1.Capacity() == 100);

		Array<ELEMENT_TYPE> a2 (10,ELEMENT_CONVERSION(42));
		UTF_CHECK(a2.Size() == 10);
		UTF_CHECK(a2.Capacity() == 10);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a2[i] == ELEMENT_CONVERSION(42));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		// Making assumption that PushBack works - although it is tested later
		Array<ELEMENT_TYPE> a0;
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));

		Array<ELEMENT_TYPE>::Iterator it;
		Array<ELEMENT_TYPE>::ConstIterator cit;

		// Test Begin
		it = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));
		cit = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));

		// Test End
		it = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));
		cit = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));

		// Test IsEmpty
		UTF_CHECK(false == a0.IsEmpty());
		Array<ELEMENT_TYPE> a1;
		UTF_CHECK(true == a1.IsEmpty());

		// Check Begin() == End() on an empty list
		UTF_CHECK(a1.Begin() == a1.End());

		// Test Size
		UTF_CHECK(a0.Size() == 3);

		// Test Capacity
		UTF_CHECK(a0.Capacity() == AlignUp(3U,8));

		// Test Full
		Array<ELEMENT_TYPE> a2 (3);
		a2.PushBack(ELEMENT_CONVERSION(1));
		a2.PushBack(ELEMENT_CONVERSION(2));
		UTF_CHECK(!a2.Full());
		a2.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a2.Full());

		// Test Front
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(1));
		a2.Front() = ELEMENT_CONVERSION(42);
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(42));
		UTF_CHECKASSERT(a1.Front());

		// Test Back
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(3));
		a2.Back() = ELEMENT_CONVERSION(69);
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(69));
		UTF_CHECKASSERT(a1.Back());
	}
	END_UNITTEST

	BEGIN_UNITTEST(PushPop)
	{
		Array<ELEMENT_TYPE> a0 (10);

		// Test PushBack
		Array<ELEMENT_TYPE>::Iterator it;

		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushBack(ELEMENT_CONVERSION(i));
			UTF_CHECK(it+1 == a0.End());
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PushFront
		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushFront(ELEMENT_CONVERSION(i));
			UTF_CHECK(*a0.Begin() == ELEMENT_CONVERSION(i));
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PopBack
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopBack() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size()==10);

		// Test PopFront
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertErase)
	{
		Array<ELEMENT_TYPE> a0 (10);
		Array<ELEMENT_TYPE>::Iterator it;

		// Test Insert
		it = a0.Insert(a0.Begin(),ELEMENT_CONVERSION(1));
		it = a0.Insert(a0.End(),ELEMENT_CONVERSION(3));
		a0.Insert(it,ELEMENT_CONVERSION(2));
		for (int i = 0; i < 3; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(i+1));
		}

		// Test Erase
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.Erase(a0.Begin());
		UTF_CHECK(a0.Front() == ELEMENT_CONVERSION(2));
		a0.Erase(a0.Begin(),a0.End());
		UTF_CHECK(a0.Size() == 0);

		// Test EraseBack
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.EraseBack(a0.Begin());
		UTF_CHECK(a0.Size() == 2);
		UTF_CHECK(*(a0.Begin()) == ELEMENT_CONVERSION(3));

		// Test Clear
		a0.Clear();
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Resizing)
	{
		Array<ELEMENT_TYPE> a1;
		Array<ELEMENT_TYPE> a2;
		Array<ELEMENT_TYPE> a3;

		// Test Expand
		a1.Expand(1);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a1.Expand(2,false);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a2.Expand(2,false,false);
		UTF_CHECK(a2.Size() == 0);
		UTF_CHECK(a2.Capacity() == 2);

		// Test Reserve
		a3.Reserve(10);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 0);

		// Test Resize
		a3.Resize(3);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 3);
		a3.Resize(20);
		UTF_CHECK(a3.Capacity() == 24);
		UTF_CHECK(a3.Size() == 20);

	}
	END_UNITTEST

	BEGIN_UNITTEST(Swap)
	{
		Array<ELEMENT_TYPE> a4;
		Array<ELEMENT_TYPE> a5;

		// Test Swap
		a4.PushBack(ELEMENT_CONVERSION(1));
		a4.PushBack(ELEMENT_CONVERSION(2));
		a4.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a4.Size() == 3);
		UTF_CHECK(a4.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			a5.PushBack(ELEMENT_CONVERSION(i));
		}
		UTF_CHECK(a5.Size() == 10);
		UTF_CHECK(a5.Capacity() == 16);
		a4.Swap(a5);
		UTF_CHECK(a4.Size() == 10);
		UTF_CHECK(a4.Capacity() == 16);
		UTF_CHECK(a5.Size() == 3);
		UTF_CHECK(a5.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a4.PopFront() == ELEMENT_CONVERSION(i));
		}
		for (int i = 1; i < 4; ++i)
		{
			UTF_CHECK(a5.PopFront() == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.At(i);
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.At(i);

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == a0[i]);
			UTF_CHECK(*cit == a0[i]);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Find)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.Find(ELEMENT_CONVERSION(i));
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.Find(ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(CopyAll)
	{
		const unsigned int NumItems = 20;
		Array<ELEMENT_TYPE> a0 (NumItems - 5);
		ELEMENT_TYPE x[NumItems];
		
		for (unsigned i=0; i<NumItems; i++)
		{
			x[i] = ELEMENT_CONVERSION (i);
		}

		a0.CopyAll (x, NumItems);
		// check that everything expanded alright
		UTF_CHECK (a0.Size () == NumItems);
		UTF_CHECK (a0.Capacity () >= NumItems);
		for (unsigned i=0; i<NumItems; i++)
		{
			UTF_CHECK (a0[i] == ELEMENT_CONVERSION (i));
		}
	}
	END_UNITTEST

	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithStringGroup)

BEGIN_UNITTESTGROUP(WithStructPointerGroup)
{
	#define ELEMENT_CONVERSION(x) IntToTestStruct(x)
	#define ELEMENT_TYPE TestStruct*

	BEGIN_UNITTEST(Constructors)
	{
		Array<ELEMENT_TYPE> a0;
		UTF_CHECK(a0.Size() == 0);
		UTF_CHECK(a0.Capacity() == 0);

		Array<ELEMENT_TYPE> a1 (100);
		UTF_CHECK(a1.Size() == 0);
		UTF_CHECK(a1.Capacity() == 100);

		Array<ELEMENT_TYPE> a2 (10,ELEMENT_CONVERSION(42));
		UTF_CHECK(a2.Size() == 10);
		UTF_CHECK(a2.Capacity() == 10);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a2[i] == ELEMENT_CONVERSION(42));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Attributes)
	{
		// Making assumption that PushBack works - although it is tested later
		Array<ELEMENT_TYPE> a0;
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));

		Array<ELEMENT_TYPE>::Iterator it;
		Array<ELEMENT_TYPE>::ConstIterator cit;

		// Test Begin
		it = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));
		cit = a0.Begin();
		UTF_CHECK(*it == ELEMENT_CONVERSION(1));

		// Test End
		it = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));
		cit = a0.End();
		UTF_CHECK(*(it-1) == ELEMENT_CONVERSION(3));

		// Test IsEmpty
		UTF_CHECK(false == a0.IsEmpty());
		Array<ELEMENT_TYPE> a1;
		UTF_CHECK(true == a1.IsEmpty());

		// Check Begin() == End() on an empty list
		UTF_CHECK(a1.Begin() == a1.End());

		// Test Size
		UTF_CHECK(a0.Size() == 3);

		// Test Capacity
		UTF_CHECK(a0.Capacity() == AlignUp(3U,8));

		// Test Full
		Array<ELEMENT_TYPE> a2 (3);
		a2.PushBack(ELEMENT_CONVERSION(1));
		a2.PushBack(ELEMENT_CONVERSION(2));
		UTF_CHECK(!a2.Full());
		a2.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a2.Full());

		// Test Front
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(1));
		a2.Front() = ELEMENT_CONVERSION(42);
		UTF_CHECK(a2.Front() == ELEMENT_CONVERSION(42));
		UTF_CHECKASSERT(a1.Front());

		// Test Back
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(3));
		a2.Back() = ELEMENT_CONVERSION(69);
		UTF_CHECK(a2.Back() == ELEMENT_CONVERSION(69));
		UTF_CHECKASSERT(a1.Back());
	}
	END_UNITTEST

	BEGIN_UNITTEST(PushPop)
	{
		Array<ELEMENT_TYPE> a0 (10);

		// Test PushBack
		Array<ELEMENT_TYPE>::Iterator it;

		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushBack(ELEMENT_CONVERSION(i));
			UTF_CHECK(it+1 == a0.End());
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PushFront
		for (int i = 0; i < 10; ++i)
		{
			it = a0.PushFront(ELEMENT_CONVERSION(i));
			UTF_CHECK(*a0.Begin() == ELEMENT_CONVERSION(i));
			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
		}

		// Test PopBack
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopBack() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size()==10);

		// Test PopFront
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(9-i));
		}
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertErase)
	{
		Array<ELEMENT_TYPE> a0 (10);
		Array<ELEMENT_TYPE>::Iterator it;

		// Test Insert
		it = a0.Insert(a0.Begin(),ELEMENT_CONVERSION(1));
		it = a0.Insert(a0.End(),ELEMENT_CONVERSION(3));
		a0.Insert(it,ELEMENT_CONVERSION(2));
		for (int i = 0; i < 3; ++i)
		{
			UTF_CHECK(a0.PopFront() == ELEMENT_CONVERSION(i+1));
		}

		// Test Erase
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.Erase(a0.Begin());
		UTF_CHECK(a0.Front() == ELEMENT_CONVERSION(2));
		a0.Erase(a0.Begin(),a0.End());
		UTF_CHECK(a0.Size() == 0);

		// Test EraseBack
		a0.PushBack(ELEMENT_CONVERSION(1));
		a0.PushBack(ELEMENT_CONVERSION(2));
		a0.PushBack(ELEMENT_CONVERSION(3));
		a0.EraseBack(a0.Begin());
		UTF_CHECK(a0.Size() == 2);
		UTF_CHECK(*(a0.Begin()) == ELEMENT_CONVERSION(3));

		// Test Clear
		a0.Clear();
		UTF_CHECK(a0.Size() == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(Resizing)
	{
		Array<ELEMENT_TYPE> a1;
		Array<ELEMENT_TYPE> a2;
		Array<ELEMENT_TYPE> a3;

		// Test Expand
		a1.Expand(1);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a1.Expand(2,false);
		UTF_CHECK(a1.Size() == 1);
		UTF_CHECK(a1.Capacity() == 8);
		a2.Expand(2,false,false);
		UTF_CHECK(a2.Size() == 0);
		UTF_CHECK(a2.Capacity() == 2);

		// Test Reserve
		a3.Reserve(10);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 0);

		// Test Resize
		a3.Resize(3);
		UTF_CHECK(a3.Capacity() == 16);
		UTF_CHECK(a3.Size() == 3);
		a3.Resize(20);
		UTF_CHECK(a3.Capacity() == 24);
		UTF_CHECK(a3.Size() == 20);

	}
	END_UNITTEST

	BEGIN_UNITTEST(Swap)
	{
		Array<ELEMENT_TYPE> a4;
		Array<ELEMENT_TYPE> a5;

		// Test Swap
		a4.PushBack(ELEMENT_CONVERSION(1));
		a4.PushBack(ELEMENT_CONVERSION(2));
		a4.PushBack(ELEMENT_CONVERSION(3));
		UTF_CHECK(a4.Size() == 3);
		UTF_CHECK(a4.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			a5.PushBack(ELEMENT_CONVERSION(i));
		}
		UTF_CHECK(a5.Size() == 10);
		UTF_CHECK(a5.Capacity() == 16);
		a4.Swap(a5);
		UTF_CHECK(a4.Size() == 10);
		UTF_CHECK(a4.Capacity() == 16);
		UTF_CHECK(a5.Size() == 3);
		UTF_CHECK(a5.Capacity() == 8);
		for (int i = 0; i < 10; ++i)
		{
			UTF_CHECK(a4.PopFront() == ELEMENT_CONVERSION(i));
		}
		for (int i = 1; i < 4; ++i)
		{
			UTF_CHECK(a5.PopFront() == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.At(i);
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.At(i);

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == a0[i]);
			UTF_CHECK(*cit == a0[i]);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(Find)
	{
		Array<ELEMENT_TYPE> a0;
		for (int i = 0; i < 10; ++i)
		{
			a0.PushBack(ELEMENT_CONVERSION(i));
		}
		for (int i = 0; i < 10; ++i)
		{
			Array<ELEMENT_TYPE>::Iterator it = a0.Find(ELEMENT_CONVERSION(i));
			Array<ELEMENT_TYPE>::ConstIterator cit = a0.Find(ELEMENT_CONVERSION(i));

			UTF_CHECK(*it == ELEMENT_CONVERSION(i));
			UTF_CHECK(*cit == ELEMENT_CONVERSION(i));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(CopyAll)
	{
		const unsigned int NumItems = 20;
		Array<ELEMENT_TYPE> a0 (NumItems - 5);
		ELEMENT_TYPE x[NumItems];
		
		for (unsigned i=0; i<NumItems; i++)
		{
			x[i] = ELEMENT_CONVERSION (i);
		}

		a0.CopyAll (x, NumItems);
		// check that everything expanded alright
		UTF_CHECK (a0.Size () == NumItems);
		UTF_CHECK (a0.Capacity () >= NumItems);
		for (unsigned i=0; i<NumItems; i++)
		{
			UTF_CHECK (a0[i] == ELEMENT_CONVERSION (i));
		}
	}
	END_UNITTEST

	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithStructPointerGroup)

#include "unittesting.h"
#include "collections/sortedlist.h"

using namespace AP::UnitTestingFramework;
using namespace AP;

DECLARE_UNITTESTGROUP(StaticSortedListGroup)

BEGIN_UNITTESTGROUP(SortedLists)
	RUN_UNITTESTSUBGROUP(StaticSortedListGroup);
END_UNITTESTGROUP(SortedLists)

class TestKey
{
public:
	TestKey(): 
		value1(0)
	{}
	explicit TestKey(int i): 
		value1(i)
	{}
	TestKey(const TestKey& copy);

	TestKey& operator=(const TestKey& rhs)
	{
		value1 = rhs.value1;

		return *this;
	}

	bool operator==(const TestKey& k) const 
	{ 
		return value1 == k.value1; 
	}

	bool operator!=(const TestKey& k) const 
	{ 
		return !operator==(k); 
	}

	int GetHashID() const { return value1; }
	int value1;
};

TestKey::TestKey(const TestKey& copy)
{
	value1 = copy.value1;
}

BEGIN_UNITTESTGROUP( StaticSortedListGroup )
{
	using Axiom::Collections::StaticSortedList;

	BEGIN_UNITTEST(Constructors)
		StaticSortedList<TestKey, 100> mySortedList;
		UTF_CHECK(mySortedList.Capacity() == 100);
		UTF_CHECK(mySortedList.Count() == 0);
		UTF_CHECKASSERT(mySortedList.ConstItem(1));
	END_UNITTEST

	StaticSortedList<TestKey, 100> mySortedList;
	mySortedList.Add(TestKey(12));
	mySortedList.Add(TestKey(14));
	mySortedList.Add(TestKey(7));
	mySortedList.Add(TestKey(13));
	UTF_CHECKASSERT(mySortedList.Add(TestKey(13)));
	UTF_CHECK(mySortedList[0].value1 == 7);
	UTF_CHECK(mySortedList[1].value1 == 12);
	UTF_CHECK(mySortedList[2].value1 == 13);
	UTF_CHECK(mySortedList[3].value1 == 14);

	mySortedList.Remove(TestKey(12));
	UTF_CHECK(mySortedList[0].value1 == 7);
	UTF_CHECK(mySortedList[1].value1 == 13);
	UTF_CHECK(mySortedList[2].value1 == 14);

	mySortedList.Remove(TestKey(14));
	UTF_CHECK(mySortedList[0].value1 == 7);
	UTF_CHECK(mySortedList[1].value1 == 13);
	/*
	{
		StaticBooklet<TestKey, TestValue, void, 100> myBooklet;

		BEGIN_UNITTEST(AddItems)
			for(Axiom::uint i = 0; i < myBooklet.Capacity() / 2; ++i)
			{
				UTF_CHECK(!myBooklet.IsFull());
				myBooklet.Add(TestKey(static_cast<int>(i)), TestValue(static_cast<int>(i)));
			}
			UTF_CHECK(myBooklet.Capacity() / 2 == myBooklet.Count());
			for(Axiom::uint i = myBooklet.Capacity() / 2; i < myBooklet.Capacity(); ++i)
			{
				UTF_CHECK(!myBooklet.IsFull());
				myBooklet.Add(TestKey(static_cast<int>(i)), TestValue(static_cast<int>(i)));
			}
			UTF_CHECK(myBooklet.IsFull());
		END_UNITTEST

		BEGIN_UNITTEST(AccessItems)
			UTF_CHECK(myBooklet.Item(TestKey(52))->value1 == 52);
			UTF_CHECK(myBooklet.Item(TestKey(72))->value1 == 72);
			UTF_CHECK(myBooklet.Item(TestKey(59))->value1 == 59);
		END_UNITTEST

		BEGIN_UNITTEST(RemoveItems)
			TestValue ref = myBooklet[53];
			myBooklet.RemoveAt(52);
			UTF_CHECK(myBooklet.Count() == myBooklet.Capacity() - 1);
			UTF_CHECK(myBooklet[52] == ref);

			TestValue keyRef = *myBooklet.Item(TestKey(79));
			myBooklet.RemoveKey(TestKey(79));
			UTF_CHECK(myBooklet.Count() == myBooklet.Capacity() - 2);
		END_UNITTEST

		BEGIN_UNITTEST(CopyItems)
			StaticBooklet<TestKey, TestValue, void, 100> bookletCopy;

			bookletCopy = myBooklet;
			UTF_CHECK(myBooklet.Count() == bookletCopy.Count());
			for (Axiom::uint i = 0; i < myBooklet.Count(); ++i)
			{
				UTF_CHECK(myBooklet[i] == bookletCopy[i]);
				UTF_CHECK(myBooklet.GetItemByIndex(i) == bookletCopy.GetItemByIndex(i));
				UTF_CHECK(myBooklet.KeyAt(i) == bookletCopy.KeyAt(i));
			}
		END_UNITTEST

		BEGIN_UNITTEST(ContainsItems)
			UTF_CHECK(!myBooklet.ContainsKey(TestKey(79)));
			UTF_CHECK(!myBooklet.ContainsValue(TestValue(79)));
			UTF_CHECK(myBooklet.ContainsKey(TestKey(12)));
			UTF_CHECK(myBooklet.ContainsValue(TestValue(23)));
			UTF_CHECK(!myBooklet.ContainsKey(TestKey(52)));
			UTF_CHECK(!myBooklet.ContainsValue(TestValue(52)));
			UTF_CHECK(myBooklet.ContainsKey(TestKey(87)));
			UTF_CHECK(myBooklet.ContainsValue(TestValue(63)));
		END_UNITTEST

		BEGIN_UNITTEST(Clear)
			UTF_CHECK(!myBooklet.IsEmpty());
			myBooklet.Clear();
			UTF_CHECK(myBooklet.IsEmpty());
			UTF_CHECKASSERT(myBooklet[10]);
		END_UNITTEST

		BEGIN_UNITTEST(KeyReference)
			myBooklet.Add(TestKey(static_cast<int>(21)), TestValue(static_cast<int>(21)));
			myBooklet.Add(TestKey(static_cast<int>(35)), TestValue(static_cast<int>(35)));
			myBooklet.Add(TestKey(static_cast<int>(48)), TestValue(static_cast<int>(48)));
			myBooklet.Add(TestKey(static_cast<int>(61)), TestValue(static_cast<int>(61)));
			myBooklet.Add(TestKey(static_cast<int>(75)), TestValue(static_cast<int>(75)));

			TestKey Key (75);
			UTF_CHECK(myBooklet[Key] == TestValue(static_cast<int>(75)));
			TestKey Key2 (35);
			UTF_CHECK(myBooklet[Key2] == TestValue(static_cast<int>(35)));
			TestKey Key3 (95);
			UTF_CHECKASSERT(myBooklet[Key3] == TestValue(static_cast<int>(95)));
		END_UNITTEST
	}
	*/
}
END_UNITTESTGROUP( StaticBookletGroup )

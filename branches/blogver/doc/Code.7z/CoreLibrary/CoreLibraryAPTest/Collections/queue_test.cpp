//---------------------------------------------------------------------------------------------------------------------------------
// Queue unit tests
//---------------------------------------------------------------------------------------------------------------------------------

#include "unittesting.h"
#include "Collections/queue.h"
#include "string/string.h"

using namespace Axiom;
using Collections::Queue;

static String IntToString (int i)
{
	char buf [32];
	StringFormat(buf,32,"%d",i);
	return String(buf);
}

struct TestStruct
{
	TestStruct (int i)
		: mInt(i)
	{
	}

	bool operator== (const TestStruct& ts)
	{
		return mInt == ts.mInt;
	}

	bool operator!= (const TestStruct& ts)
	{
		return mInt != ts.mInt;
	}

	int mInt;
};

static TestStruct tsData [] = 
{
	TestStruct(0),
	TestStruct(1),
	TestStruct(2),
	TestStruct(3),
	TestStruct(4),
	TestStruct(5),
	TestStruct(6),
	TestStruct(7),
	TestStruct(8),
	TestStruct(9),
	TestStruct(10),
	TestStruct(11),
	TestStruct(12),
	TestStruct(13),
	TestStruct(14),
	TestStruct(15),
	TestStruct(16),
	TestStruct(17),
	TestStruct(18),
	TestStruct(19),
	TestStruct(666),
};

static TestStruct* IntToTestStruct (int i)
{
	return &tsData[i < 20 ? i : 20];
}


BEGIN_UNITTESTGROUP(QueueGroup)
{

	//---------------------------------------------------------------------------------------------------------------------------------
	// Integer type tests
	//---------------------------------------------------------------------------------------------------------------------------------

	#undef INT
	#undef TYPE
	#define INT(x) x
	#define TYPE int

	BEGIN_UNITTEST(int)
	{
		BEGIN_UNITTEST(Constructors)
		{
			Queue<TYPE,6> q0;
			UTF_CHECK(q0.IsEmpty());
			UTF_CHECK(q0.Count() == 0);
			UTF_CHECK(q0.Capacity() == 6);

			q0.PushBack(INT(1));
			UTF_CHECK(!q0.IsEmpty());
			UTF_CHECK(q0.Count() == 1);

			Queue<TYPE,6> q1 = q0;

			UTF_CHECK(q1.Count() == 1);
			UTF_CHECK(q1.PopBack() == INT(1));
		}
		END_UNITTEST

		BEGIN_UNITTEST(Attributes)
		{
			Queue<TYPE,6> q0;

			for (int i = 0; i < 6; i+=2)
			{
				q0.PushBack(INT(i));
				UTF_CHECK(q0.Item(i) == q0.Back());
				q0.PushFront(INT(i+1));
				UTF_CHECK(q0.Count() == uint(i+2));
				UTF_CHECK(q0.Item(i) == q0.Front());

				UTF_CHECK(q0.Front() == INT(i+1));
				UTF_CHECK(q0.Back() == INT(i));

				q0.Front() = INT(42);
				q0.Back() = INT(43);
				UTF_CHECK(q0.Front() == INT(42));
				UTF_CHECK(q0.Back() == INT(43));
			}

		}
		END_UNITTEST

		BEGIN_UNITTEST(Operations)
		{
			Queue<TYPE,6> q0;
			Queue<TYPE,6> q1;

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
				q1.PushFront(INT(i));

				UTF_CHECK(q0.Back() == INT(i));
				UTF_CHECK(q0.Front() == INT(0));
				UTF_CHECK(q1.Front() == INT(i));
				UTF_CHECK(q1.Back() == INT(0));

				UTF_CHECK(q0.Count() == uint(i+1));
				UTF_CHECK(q1.Count() == uint(i+1));
			}

			for (int i = 0; i < 6; ++i)
			{
				UTF_CHECK(q0.PopFront() == INT(i));
				UTF_CHECK(q1.PopBack() == INT(i));
				UTF_CHECK(q0.Count() == uint(5-i));
				UTF_CHECK(q1.Count() == uint(5-i));
			}

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
			}
			UTF_CHECK(q0.Count() == 6);
			q0.Clear();
			UTF_CHECK(q0.Count() == 0);
		}
		END_UNITTEST

	}
	END_UNITTEST // int

	//---------------------------------------------------------------------------------------------------------------------------------
	// String type tests
	//---------------------------------------------------------------------------------------------------------------------------------

	#undef INT
	#undef TYPE
	#define INT(x) IntToString(x)
	#define TYPE String

	BEGIN_UNITTEST(String)
	{
		BEGIN_UNITTEST(Constructors)
		{
			Queue<TYPE,6> q0;
			UTF_CHECK(q0.IsEmpty());
			UTF_CHECK(q0.Count() == 0);
			UTF_CHECK(q0.Capacity() == 6);

			q0.PushBack(INT(1));
			UTF_CHECK(!q0.IsEmpty());
			UTF_CHECK(q0.Count() == 1);

			Queue<TYPE,6> q1 = q0;

			UTF_CHECK(q1.Count() == 1);
			UTF_CHECK(q1.PopBack() == INT(1));
		}
		END_UNITTEST

		BEGIN_UNITTEST(Attributes)
		{
			Queue<TYPE,6> q0;

			for (int i = 0; i < 6; i+=2)
			{
				q0.PushBack(INT(i));
				q0.PushFront(INT(i+1));
				UTF_CHECK(q0.Count() == uint(i+2));

				UTF_CHECK(q0.Front() == INT(i+1));
				UTF_CHECK(q0.Back() == INT(i));

				q0.Front() = INT(42);
				q0.Back() = INT(43);
				UTF_CHECK(q0.Front() == INT(42));
				UTF_CHECK(q0.Back() == INT(43));
			}

		}
		END_UNITTEST

		BEGIN_UNITTEST(Operations)
		{
			Queue<TYPE,6> q0;
			Queue<TYPE,6> q1;

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
				q1.PushFront(INT(i));

				UTF_CHECK(q0.Back() == INT(i));
				UTF_CHECK(q0.Front() == INT(0));
				UTF_CHECK(q1.Front() == INT(i));
				UTF_CHECK(q1.Back() == INT(0));

				UTF_CHECK(q0.Count() == uint(i+1));
				UTF_CHECK(q1.Count() == uint(i+1));
			}

			for (int i = 0; i < 6; ++i)
			{
				UTF_CHECK(q0.PopFront() == INT(i));
				UTF_CHECK(q1.PopBack() == INT(i));
				UTF_CHECK(q0.Count() == uint(5-i));
				UTF_CHECK(q1.Count() == uint(5-i));
			}

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
			}
			UTF_CHECK(q0.Count() == 6);
			q0.Clear();
			UTF_CHECK(q0.Count() == 0);
		}
		END_UNITTEST

	}
	END_UNITTEST // String

	//---------------------------------------------------------------------------------------------------------------------------------
	// TestStruct pointer type tests
	//---------------------------------------------------------------------------------------------------------------------------------

	#undef INT
	#undef TYPE
	#define INT(x) IntToTestStruct(x)
	#define TYPE TestStruct*

	BEGIN_UNITTEST(TestStructPointer)
	{
		BEGIN_UNITTEST(Constructors)
		{
			Queue<TYPE,6> q0;
			UTF_CHECK(q0.IsEmpty());
			UTF_CHECK(q0.Count() == 0);
			UTF_CHECK(q0.Capacity() == 6);

			q0.PushBack(INT(1));
			UTF_CHECK(!q0.IsEmpty());
			UTF_CHECK(q0.Count() == 1);

			Queue<TYPE,6> q1 = q0;

			UTF_CHECK(q1.Count() == 1);
			UTF_CHECK(q1.PopBack() == INT(1));
		}
		END_UNITTEST

		BEGIN_UNITTEST(Attributes)
		{
			Queue<TYPE,6> q0;

			for (int i = 0; i < 6; i+=2)
			{
				q0.PushBack(INT(i));
				q0.PushFront(INT(i+1));
				UTF_CHECK(q0.Count() == uint(i+2));

				UTF_CHECK(q0.Front() == INT(i+1));
				UTF_CHECK(q0.Back() == INT(i));

				q0.Front() = INT(42);
				q0.Back() = INT(43);
				UTF_CHECK(q0.Front() == INT(42));
				UTF_CHECK(q0.Back() == INT(43));
			}

		}
		END_UNITTEST

		BEGIN_UNITTEST(Operations)
		{
			Queue<TYPE,6> q0;
			Queue<TYPE,6> q1;

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
				q1.PushFront(INT(i));

				UTF_CHECK(q0.Back() == INT(i));
				UTF_CHECK(q0.Front() == INT(0));
				UTF_CHECK(q1.Front() == INT(i));
				UTF_CHECK(q1.Back() == INT(0));

				UTF_CHECK(q0.Count() == uint(i+1));
				UTF_CHECK(q1.Count() == uint(i+1));
			}

			for (int i = 0; i < 6; ++i)
			{
				UTF_CHECK(q0.PopFront() == INT(i));
				UTF_CHECK(q1.PopBack() == INT(i));
				UTF_CHECK(q0.Count() == uint(5-i));
				UTF_CHECK(q1.Count() == uint(5-i));
			}

			for (int i = 0; i < 6; ++i)
			{
				q0.PushBack(INT(i));
			}
			UTF_CHECK(q0.Count() == 6);
			q0.Clear();
			UTF_CHECK(q0.Count() == 0);
		}
		END_UNITTEST

	}
	END_UNITTEST // TestStruct*

}
END_UNITTESTGROUP(QueueGroup)


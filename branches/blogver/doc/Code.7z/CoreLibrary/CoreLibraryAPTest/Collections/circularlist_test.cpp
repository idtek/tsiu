#include <UnitTesting.h>
#include <collections/circularbuffer.h>

using namespace Axiom;
using namespace Axiom::Collections;

DECLARE_UNITTESTGROUP(DCLIntGroup)
DECLARE_UNITTESTGROUP(SCLIntGroup)

BEGIN_UNITTESTGROUP(DynamicCircularListGroup)
{
	RUN_UNITTESTSUBGROUP(DCLIntGroup);
}
END_UNITTESTGROUP(DynamicCircularListGroup)

BEGIN_UNITTESTGROUP(StaticCircularListGroup)
{
	RUN_UNITTESTSUBGROUP(SCLIntGroup);
}
END_UNITTESTGROUP(StaticCircularListGroup)

//The tests

BEGIN_UNITTESTGROUP(DCLIntGroup)
{
	BEGIN_UNITTEST(Constructors)
	{
		DynamicCircularList<int> list;
		UTF_CHECK(list.Count() == 0);
		UTF_CHECK(list.Capacity() == 0);
		UTF_CHECK(list.IsEmpty());
		UTF_CHECK(!list.IsFull());
	}
	END_UNITTEST

	BEGIN_UNITTEST(Adding)
	{
		DynamicCircularList< unsigned int> list;
		const unsigned int MaxNumbers = 10;
		list.Resize( Axiom::Memory::DEFAULT_HEAP, MaxNumbers );

		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
			UTF_CHECK( list.LastItem() == i );
		}

		UTF_CHECK( list.Count() == MaxNumbers );
		UTF_CHECK( list.IsFull() );

		UTF_CHECK( list.FirstItem() == 0 );
		UTF_CHECK( list.LastItem() == MaxNumbers - 1 );
	}
	END_UNITTEST

	BEGIN_UNITTEST(Clearing)
	{
		DynamicCircularList< unsigned int> list;
		const unsigned int MaxNumbers = 10;
		list.Resize( Axiom::Memory::DEFAULT_HEAP, MaxNumbers );

		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
		}

		list.Clear();
		UTF_CHECK(list.Count() == 0);
		UTF_CHECK(list.IsEmpty());
		UTF_CHECK(!list.IsFull());
	}
	END_UNITTEST

	BEGIN_UNITTEST(Popping)
	{
		DynamicCircularList< unsigned int> list;
		const unsigned int MaxNumbers = 10;
		list.Resize( Axiom::Memory::DEFAULT_HEAP, MaxNumbers );

		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
			UTF_CHECK( list.LastItem() == i );
		}

		UTF_CHECK( list.FirstItem() == 0 );
		UTF_CHECK( list.IsFull() );

		unsigned int value;
		list.Pop( value );

		UTF_CHECK( value == 0 );
		
		UTF_CHECK( list.FirstItem() == 1 );
		UTF_CHECK( list.Count() == MaxNumbers - 1 );
		UTF_CHECK( !list.IsFull() );

		//3rd most recent item
		unsigned int* verifyAddress = &list[ 3 ];
		list.Pop();

		//1 less item, but address still the same
		UTF_CHECK( verifyAddress == &list[2] );
	}
	END_UNITTEST
}
END_UNITTESTGROUP(DCLIntGroup)

BEGIN_UNITTESTGROUP(SCLIntGroup)
{
	BEGIN_UNITTEST(Constructors)
	{
		DynamicCircularList<int> list;
		UTF_CHECK(list.Count() == 0);
		UTF_CHECK(list.Capacity() == 0);
		UTF_CHECK(list.IsEmpty());
		UTF_CHECK(!list.IsFull());
	}
	END_UNITTEST

	BEGIN_UNITTEST(Adding)
	{
		const unsigned int MaxNumbers = 10;
		StaticCircularList< unsigned int, MaxNumbers > list;
	
		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
			UTF_CHECK( list.LastItem() == i );
		}

		UTF_CHECK( list.Count() == MaxNumbers );
		UTF_CHECK( list.IsFull() );

		UTF_CHECK( list.FirstItem() == 0 );
		UTF_CHECK( list.LastItem() == MaxNumbers - 1 );
	}
	END_UNITTEST

	BEGIN_UNITTEST(Clearing)
	{
		const unsigned int MaxNumbers = 10;
		StaticCircularList< unsigned int, MaxNumbers > list;
		
		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
		}

		list.Clear();
		UTF_CHECK(list.Count() == 0);
		UTF_CHECK(list.IsEmpty());
		UTF_CHECK(!list.IsFull());
	}
	END_UNITTEST

	BEGIN_UNITTEST(Popping)
	{
		const unsigned int MaxNumbers = 10;
		StaticCircularList< unsigned int, MaxNumbers> list;
		UTF_CHECK( list.Capacity() == MaxNumbers );

		for( unsigned int i = 0; i < MaxNumbers; ++i )
		{
			list.Push( i );
			UTF_CHECK( list.LastItem() == i );
		}

		UTF_CHECK( list.FirstItem() == 0 );
		UTF_CHECK( list.IsFull() );

		unsigned int value;
		list.Pop( value );

		UTF_CHECK( value == 0 );
		
		UTF_CHECK( list.FirstItem() == 1 );
		UTF_CHECK( list.Count() == MaxNumbers - 1 );
		UTF_CHECK( !list.IsFull() );

		//3rd most recent item
		unsigned int* verifyAddress = &list[ 3 ];
		list.Pop();

		//1 less item, but address still the same
		UTF_CHECK( verifyAddress == &list[2] );
	}
	END_UNITTEST
}
END_UNITTESTGROUP(SCLIntGroup)
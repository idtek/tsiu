#include <collections/array.h>

#include "unittesting.h"
#include "testcontainmentclasses.h"
// c:\Projects\SoccerSuperstar\CoreLibrary\CoreLibraryAPTest\testcontainmentclasses.h
// c:\Projects\SoccerSuperstar\CoreLibrary\CoreLibraryAPTest\staticarraytests.cpp
using Axiom::Collections::StaticArray;
using namespace AP::UnitTestingFramework;
using namespace Axiom::Math;


BEGIN_UNITTESTGROUP(StaticArrayGroup)
{
	#define ELEMENT_CONVERSION(x) x
	#define ELEMENT_TYPE int

	static const size_t TEST_ARRAY_SIZE = 50;

	BEGIN_UNITTEST(ConstructorTest)
		StaticArray<int, TEST_ARRAY_SIZE> testArray;

		UTF_CHECK( TEST_ARRAY_SIZE == testArray.Size() );
		UTF_CHECK( TEST_ARRAY_SIZE == testArray.Capacity() );

		testArray.~StaticArray();
	END_UNITTEST

	BEGIN_UNITTEST(DestructorTest)
		StaticArray<int, TEST_ARRAY_SIZE> testArray;
		testArray.~StaticArray();
	END_UNITTEST

	StaticArray<int, TEST_ARRAY_SIZE> arrayFixture;  // will be exercised in subsequent tests

	BEGIN_UNITTEST(SwapItemTest)
		StaticArray<int, TEST_ARRAY_SIZE> testArray2;
		for (size_t i=0; i<arrayFixture.Size(); i++)
		{
			arrayFixture[i]=i;
			testArray2[i] = testArray2.Size()-i-1;
		}

		// Test swap
		Swap(arrayFixture, testArray2);
		UTF_CHECK( arrayFixture[0] == static_cast<int>( (arrayFixture.Size()-1)) );
		Swap(arrayFixture, testArray2);

		int first = arrayFixture.Front();
		UTF_CHECK( first == 0);
		int last = arrayFixture.Back();
		UTF_CHECK( last == static_cast<int>(arrayFixture.Size()-1) );
		UTF_CHECK( static_cast<int>(false) == static_cast<int>(arrayFixture.IsEmpty()) );
	END_UNITTEST

	BEGIN_UNITTEST(IterTest)
		StaticArray<int, TEST_ARRAY_SIZE>::Iterator it;
		static const int HALF_SIZE = static_cast<int>(TEST_ARRAY_SIZE/2);

		it = arrayFixture.At(HALF_SIZE);

		UTF_CHECK( (*it) == HALF_SIZE);

		int testVal = arrayFixture[HALF_SIZE];

		UTF_CHECK( testVal == HALF_SIZE);
	END_UNITTEST

// 	BEGIN_UNITTEST(ComplexObjectFillTests)
// 		StaticArray<BigClass*, TEST_ARRAY_SIZE> testArray;

//		size_t size = testArray.Size();
// 		for (size_t i=0; i < size; ++i)
// 		{
// 			BigClass* data = AP_NEW(AP::Memory::RESERVED_DEBUG_HEAP, BigClass());
// 			testArray[i] = data;
// 			//testArray[i]->SetOK(false);
// 		}
// 
// 		StaticArray<BigClass*, TEST_ARRAY_SIZE>::Iterator it2;
// 
// 		BigClass *ptr = testArray[12];
// 		it2=testArray.At(12);
// 		int index1=(*it2)->GetIndex(), index2=ptr->GetIndex();
// 
// 		UTF_CHECK( index1 == index2);
// 
// 		for (size_t i=0; i < testArray.Size(); ++i)
// 		{
// 			ptr=testArray[i];
// 			ptr->SetOK(true);
// 			delete ptr;
// 		}
// 		UTF_CHECKASSERT(testArray[testArray.Size()+1]);
// 
// 		UTF_CHECKASSERT(testArray.At(testArray.Size()+1));
// 
// 		StaticArray<BigClass*, TEST_ARRAY_SIZE>::ConstIterator cit;
// 		cit=testArray.At(12);
// 		UTF_CHECKASSERT((cit=testArray.At(testArray.Size()+1)));
// 
// 		const StaticArray<BigClass*, TEST_ARRAY_SIZE> cArray(testArray);
// 		UTF_CHECKASSERT((cit=cArray.At(cArray.Size()+1)));
// 
// 		testArray.~testArray();
// 	END_UNITTEST

	BEGIN_UNITTEST(cleanup)
		arrayFixture.~StaticArray();
	END_UNITTEST

	BEGIN_UNITTEST(CopyAll)
	{
		const int NumItems = 20;
		StaticArray<ELEMENT_TYPE, NumItems-5> a0;
		ELEMENT_TYPE x[NumItems];
		
		for (int i=0; i<NumItems; i++)
		{
			x[i] = ELEMENT_CONVERSION (i);
		}

		UTF_CHECKASSERT (a0.CopyAll (x, NumItems));// this had better assert
		a0.CopyAll (x, NumItems-5);// this had better NOT assert

		for (int i=0; i<NumItems-5; i++)
		{
			UTF_CHECK (a0[i] == ELEMENT_CONVERSION (i));
		}
		UTF_CHECKASSERT (a0[NumItems-5]);// accessing beyond the boundaries
		UTF_CHECKASSERT (a0[NumItems-4]);
		UTF_CHECKASSERT (a0[0xffffffff]);
	}
	END_UNITTEST

	#undef ELEMENT_CONVERSION
	#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(StaticArrayGroup)

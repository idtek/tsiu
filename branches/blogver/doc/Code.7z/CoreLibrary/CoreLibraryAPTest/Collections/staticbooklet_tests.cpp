#include "unittesting.h"
#include "collections/booklet.h"

using namespace AP::UnitTestingFramework;
using namespace AP;

DECLARE_UNITTESTGROUP(StaticBookletGroup)

BEGIN_UNITTESTGROUP(Booklets)
	RUN_UNITTESTSUBGROUP(StaticBookletGroup);
END_UNITTESTGROUP(Booklets)

struct TestKey
{
	TestKey(): 
		value1(0)
	{}
	explicit TestKey(int i): 
		value1(i)
	{}

	bool operator==(const TestKey& k) const 
	{ 
		return value1 == k.value1; 
	}

	bool operator!=(const TestKey& k) const 
	{ 
		return !operator==(k); 
	}

	int GetHashID() const { return value1; }
	int value1;
};

struct TestValue
{
	TestValue(): 
		value1(0),
		value2(0.f)
	{}

	explicit TestValue(int i): 
		value1(i), 
		value2(static_cast<float>(i)) 
	{}

	bool operator==(const TestValue& v) const 
	{ 
		return value1 == v.value1 && value2 == v.value2; 
	}

	bool operator!=(const TestValue& v) const 
	{ 
		return !operator==(v); 
	}

	int value1;
	float value2;
};


BEGIN_UNITTESTGROUP( StaticBookletGroup )
{

	using Axiom::Collections::StaticBooklet;

	BEGIN_UNITTEST(Constructors)
		StaticBooklet<TestKey, TestValue, void, 100> myBooklet;
		UTF_CHECK(myBooklet.Capacity() == 100);
		UTF_CHECK(myBooklet.Count() == 0);
		UTF_CHECKASSERT(myBooklet[1]);
	END_UNITTEST

	{
		StaticBooklet<TestKey, TestValue, void, 100> myBooklet;

		BEGIN_UNITTEST(AddItems)
			for(Axiom::uint i = 0; i < myBooklet.Capacity() / 2; ++i)
			{
				UTF_CHECK(!myBooklet.IsFull());
				myBooklet.Add(TestKey(static_cast<int>(i)), TestValue(static_cast<int>(i)));
			}
			UTF_CHECK(myBooklet.Capacity() / 2 == myBooklet.Count());
			for(Axiom::uint i = myBooklet.Capacity() / 2; i < myBooklet.Capacity(); ++i)
			{
				UTF_CHECK(!myBooklet.IsFull());
				myBooklet.Add(TestKey(static_cast<int>(i)), TestValue(static_cast<int>(i)));
			}
			UTF_CHECK(myBooklet.IsFull());
		END_UNITTEST

		BEGIN_UNITTEST(AccessItems)
			UTF_CHECK(myBooklet.Item(TestKey(52))->value1 == 52);
			UTF_CHECK(myBooklet.Item(TestKey(72))->value1 == 72);
			UTF_CHECK(myBooklet.Item(TestKey(59))->value1 == 59);
		END_UNITTEST

		BEGIN_UNITTEST(RemoveItems)
			TestValue ref = myBooklet[53];
			myBooklet.RemoveAt(52);
			UTF_CHECK(myBooklet.Count() == myBooklet.Capacity() - 1);
			UTF_CHECK(myBooklet[52] == ref);

			TestValue keyRef = *myBooklet.Item(TestKey(79));
			myBooklet.RemoveKey(TestKey(79));
			UTF_CHECK(myBooklet.Count() == myBooklet.Capacity() - 2);
		END_UNITTEST

		BEGIN_UNITTEST(CopyItems)
			StaticBooklet<TestKey, TestValue, void, 100> bookletCopy;

			bookletCopy = myBooklet;
			UTF_CHECK(myBooklet.Count() == bookletCopy.Count());
			for (Axiom::uint i = 0; i < myBooklet.Count(); ++i)
			{
				UTF_CHECK(myBooklet[i] == bookletCopy[i]);
				UTF_CHECK(myBooklet.GetItemByIndex(i) == bookletCopy.GetItemByIndex(i));
				UTF_CHECK(myBooklet.KeyAt(i) == bookletCopy.KeyAt(i));
			}
		END_UNITTEST

		BEGIN_UNITTEST(ContainsItems)
			UTF_CHECK(!myBooklet.ContainsKey(TestKey(79)));
			UTF_CHECK(!myBooklet.ContainsValue(TestValue(79)));
			UTF_CHECK(myBooklet.ContainsKey(TestKey(12)));
			UTF_CHECK(myBooklet.ContainsValue(TestValue(23)));
			UTF_CHECK(!myBooklet.ContainsKey(TestKey(52)));
			UTF_CHECK(!myBooklet.ContainsValue(TestValue(52)));
			UTF_CHECK(myBooklet.ContainsKey(TestKey(87)));
			UTF_CHECK(myBooklet.ContainsValue(TestValue(63)));
		END_UNITTEST

		BEGIN_UNITTEST(Clear)
			UTF_CHECK(!myBooklet.IsEmpty());
			myBooklet.Clear();
			UTF_CHECK(myBooklet.IsEmpty());
			UTF_CHECKASSERT(myBooklet[10]);
		END_UNITTEST

		BEGIN_UNITTEST(KeyReference)
			myBooklet.Add(TestKey(static_cast<int>(21)), TestValue(static_cast<int>(21)));
			myBooklet.Add(TestKey(static_cast<int>(35)), TestValue(static_cast<int>(35)));
			myBooklet.Add(TestKey(static_cast<int>(48)), TestValue(static_cast<int>(48)));
			myBooklet.Add(TestKey(static_cast<int>(61)), TestValue(static_cast<int>(61)));
			myBooklet.Add(TestKey(static_cast<int>(75)), TestValue(static_cast<int>(75)));

			TestKey Key (75);
			UTF_CHECK(myBooklet[Key] == TestValue(static_cast<int>(75)));
			TestKey Key2 (35);
			UTF_CHECK(myBooklet[Key2] == TestValue(static_cast<int>(35)));
			TestKey Key3 (95);
			UTF_CHECKASSERT(myBooklet[Key3] == TestValue(static_cast<int>(95)));
		END_UNITTEST
	}

}
END_UNITTESTGROUP( StaticBookletGroup )

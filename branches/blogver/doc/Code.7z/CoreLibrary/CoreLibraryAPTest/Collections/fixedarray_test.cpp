#include <UnitTesting.h>
#include <string/string.h>
#include <collections/fixedszarray.h>

using namespace Axiom;
using namespace Axiom::Collections;

String StrFromInt (int i)
{
	char buf [32];
	sprintf(buf,"%d",i);
	return String(buf);
}

BEGIN_UNITTESTGROUP(FixedArray )
{
	BEGIN_UNITTEST(int)
	{
		// Testing basic constructor/destructor
		BEGIN_UNITTEST(Constructors)
		{
			// Quick con/des test
			{
				FixedSizeArray<int, 100> array0;
				FixedSizeArray<int, 100> array1 = array0;
			}
		}
		END_UNITTEST

		// Test all other functional use
		BEGIN_UNITTEST(FunctionalTest)
		{
			const uint numEntries = 5;
			FixedSizeArray<int, numEntries> array0;
			FixedSizeArray<int, numEntries> array1;

			UTF_CHECK(array0.Capacity() == numEntries);
			UTF_CHECK(array1.Capacity() == numEntries);
			UTF_CHECK(!array0.IsAtCapacity() && !array1.IsAtCapacity());

			for(int i=0; i<(int)numEntries;i++)
			{
				array0.PushBack(i);
			}

			array1 = array0;
			
			for(int i=0; i<(int)numEntries;i++)
			{
				UTF_CHECK(array0[i] == array1[i]);
				UTF_CHECK(*(array0.At(i)) == *(array1.At(i)));

				const int val0 = array0[i];
				const int val1 = array1[i];
				UTF_CHECK(val0 == val1);

				const int* it0 = array0.At(i);
				const int* it1 = array1.At(i);
				UTF_CHECK(*it0 == *it1);
			}

			UTF_CHECK(array0.IsAtCapacity()==true && !array0.IsEmpty());
			const FixedSizeArray<int, numEntries> constArray0(array0);

			int i2=0;
			for(FixedSizeArray<int, numEntries>::Iterator it = array0.Begin(); it!=array0.End();it++)
			{
				UTF_CHECK(*it == i2);
				i2++;
			}

			UTF_CHECK(array0.Front() == 0);
			UTF_CHECK(array0.Back() == numEntries - 1);
			const int frVal = array0.Front();
			const int bkVal = array0.Back();
			UTF_CHECK(frVal == 0 && bkVal == (numEntries - 1));

			int* it0 = array0.Find(2);
			UTF_CHECK(it0 && (*it0 == 2));

			const int* it1 = array0.Find(3);
			UTF_CHECK(it1 && (*it1 == 3));

			int* newIt = array0.EraseBack(it0);
			UTF_CHECK(newIt && (*newIt == 4) && array0.Size() == numEntries -1);

			UTF_CHECK(!array0.IsAtCapacity());

			int val = array0.PopBack();
			UTF_CHECK(val == (numEntries -2));

			array0.Clear();
			UTF_CHECK(array0.Size()==0 && array0.IsEmpty());
		}	
		END_UNITTEST

		// Test all boundary cases
		BEGIN_UNITTEST(BoundaryTest)
		{
			FixedSizeArray<int, 1> array0;
			array0.PushBack(0);
			UTF_CHECKASSERT(array0.PushBack(0));

			array0.PopBack();
			UTF_CHECKASSERT(array0.PopBack());

			array0.Clear();
			array0.Clear();
			UTF_CHECKASSERT(array0[0]);

		}
		END_UNITTEST
	}
	END_UNITTEST

	BEGIN_UNITTEST(String)
	{
		// Testing basic constructor/destructor
		BEGIN_UNITTEST(Constructors)
		{
			// Quick con/des test
			{
				FixedSizeArray<String, 100> array0;
				FixedSizeArray<String, 100> array1 = array0;
			}
		}
		END_UNITTEST

		// Test all other functional use
		BEGIN_UNITTEST(FunctionalTest)
		{
		
			const size_t numEntries = 5;
			FixedSizeArray<String, numEntries> array0;
			FixedSizeArray<String, numEntries> array1;

			UTF_CHECK(array0.Capacity() == numEntries);
			UTF_CHECK(array1.Capacity() == numEntries);
			UTF_CHECK(!array0.IsAtCapacity() && !array1.IsAtCapacity());

			for(int i=0; i<(int)numEntries;i++)
			{
				array0.PushBack(StrFromInt(i));
			}

			array1 = array0;
			
			for(int i=0; i<(int)numEntries;i++)
			{
				UTF_CHECK(array0[i] == array1[i]);
				UTF_CHECK(*(array0.At(i)) == *(array1.At(i)));

				const String val0 = array0[i];
				const String val1 = array1[i];
				UTF_CHECK(val0 == val1);

				const String* it0 = array0.At(i);
				const String* it1 = array1.At(i);
				UTF_CHECK(*it0 == *it1);
			}

			UTF_CHECK(array0.IsAtCapacity()==true && !array0.IsEmpty());
			const FixedSizeArray<String, numEntries> constArray0(array0);
	
			int i2=0;
			for(FixedSizeArray<String, numEntries>::Iterator it = array0.Begin(); it!=array0.End();it++)
			{
				UTF_CHECK(*it == StrFromInt(i2));
				i2++;
			}

			UTF_CHECK(array0.Front() == StrFromInt(0));
			UTF_CHECK(array0.Back() == StrFromInt(numEntries - 1));
			const String frVal = array0.Front();
			const String bkVal = array0.Back();
			UTF_CHECK(frVal == StrFromInt(0) && bkVal == StrFromInt(numEntries - 1));

			String* it0 = array0.Find(StrFromInt(2));
			UTF_CHECK(it0 && (*it0 == StrFromInt(2)));

			const String* it1 = array0.Find(StrFromInt(3));
			UTF_CHECK(it1 && (*it1 == StrFromInt(3)));

			String* newIt = array0.EraseBack(it0);
			UTF_CHECK(newIt && (*newIt == StrFromInt(4)) && array0.Size() == numEntries -1);

			UTF_CHECK(!array0.IsAtCapacity());

			String val = array0.PopBack();
			UTF_CHECK(val == StrFromInt(numEntries -2));

			array0.Clear();
			UTF_CHECK(array0.Size()==0 && array0.IsEmpty());
		
		}	
		END_UNITTEST

		// Test all boundary cases
		BEGIN_UNITTEST(BoundaryTest)
		{
		
			FixedSizeArray<String, 1> array0;
			array0.PushBack(StrFromInt(0));
			UTF_CHECKASSERT(array0.PushBack(StrFromInt(0)));

			array0.PopBack();
			UTF_CHECKASSERT(array0.PopBack());

			array0.Clear();
			array0.Clear();
			UTF_CHECKASSERT(array0[0]);

		}
		END_UNITTEST
	}
	END_UNITTEST

	BEGIN_UNITTEST(Pointer)
	{
		// Testing basic constructor/destructor
		BEGIN_UNITTEST(Constructors)
		{
			// Quick con/des test
			{
				FixedSizeArray<int*, 100> array0;
				FixedSizeArray<int*, 100> array1 = array0;
			}
		}
		END_UNITTEST

		// Test all other functional use
		BEGIN_UNITTEST(FunctionalTest)
		{
			const size_t numEntries = 5;
			int intBuf[numEntries] ={0,1,2,3,4};

			FixedSizeArray<int*, numEntries> array0;
			FixedSizeArray<int*, numEntries> array1;

			UTF_CHECK(array0.Capacity() == numEntries);
			UTF_CHECK(array1.Capacity() == numEntries);
			UTF_CHECK(!array0.IsAtCapacity() && !array1.IsAtCapacity());

			for(int i=0; i<(int)numEntries;i++)
			{
				array0.PushBack(&intBuf[i]);
			}

			array1 = array0;
			
			for(int i=0; i<(int)numEntries;i++)
			{
				UTF_CHECK(array0[i] == array1[i]);
				UTF_CHECK(*(array0.At(i)) == *(array1.At(i)));

				const int* val0 = array0[i];
				const int* val1 = array1[i];
				UTF_CHECK(val0 == val1);
			}

			UTF_CHECK(array0.IsAtCapacity()==true && !array0.IsEmpty());
			const FixedSizeArray<int*, numEntries> constArray0(array0);

			int i2=0;
			for(FixedSizeArray<int*, numEntries>::Iterator it = array0.Begin(); it!=array0.End();it++)
			{
				UTF_CHECK(*it == &intBuf[i2]);
				i2++;
			}

			UTF_CHECK(array0.Front() == &intBuf[0]);
			UTF_CHECK(array0.Back() == &intBuf[numEntries - 1]);
			const int* frVal = array0.Front();
			const int* bkVal = array0.Back();
			UTF_CHECK(frVal == &intBuf[0] && bkVal == &intBuf[numEntries - 1]);

			FixedSizeArray<int*, numEntries>::Iterator it0 = array0.Find(&intBuf[2]);
			UTF_CHECK(it0 && (*it0 == &intBuf[2]));

			FixedSizeArray<int*, numEntries>::ConstIterator it1= array0.Find(&intBuf[3]);
			UTF_CHECK(it1 && (*it1 == &intBuf[3]));

			FixedSizeArray<int*, numEntries>::Iterator newIt = array0.EraseBack(it0);
			UTF_CHECK(newIt && (*newIt == &intBuf[4]) && array0.Size() == (numEntries -1));

			UTF_CHECK(!array0.IsAtCapacity());

			int* val = array0.PopBack();
			UTF_CHECK(val == &intBuf[numEntries -2]);

			array0.Clear();
			UTF_CHECK(array0.Size()==0 && array0.IsEmpty());

		}	
		END_UNITTEST

		// Test all boundary cases
		BEGIN_UNITTEST(BoundaryTest)
		{
			FixedSizeArray<int, 1> array0;
			array0.PushBack(NULL);
			UTF_CHECKASSERT(array0.PushBack(NULL));

			array0.PopBack();
			UTF_CHECKASSERT(array0.PopBack());

			array0.Clear();
			array0.Clear();
			UTF_CHECKASSERT(array0[0]);

		}
		END_UNITTEST
	}
	END_UNITTEST

}
END_UNITTESTGROUP( FixedArray )

// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	linkecdlistarray_test.cpp
//!	@brief	
//
//	created:	6:4:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include <unittesting.h>
#include <Collections/linkedlistarray.h>
#include <string/string.h>

using namespace Axiom;
using namespace Axiom::Collections;
typedef ShortString TestString;


DECLARE_UNITTESTGROUP(WithIntegerLinkedListArrayGroup)
DECLARE_UNITTESTGROUP(WithStringLinkedListArrayGroup)
DECLARE_UNITTESTGROUP(WithStringLinkedListArrayGroup2)
DECLARE_UNITTESTGROUP(WithIntegerLinkedListContinuousArrayGroup)
DECLARE_UNITTESTGROUP(WithIntegerStaticLinkedListArrayGroup)
DECLARE_UNITTESTGROUP(WithIntegerDynamicLinkedListArrayGroup)

struct EventStructure
{
	int				ID;
	unsigned int	DateTime;
	uint			SenderID;
};

static TestString IntToStringLLA (int i)
{
	char buf [32];
	sprintf(buf,"%d",i);
	return TestString(buf);
}



BEGIN_UNITTESTGROUP(LinkedListArrayGroup)
{
	RUN_UNITTESTSUBGROUP(WithIntegerLinkedListArrayGroup);
	RUN_UNITTESTSUBGROUP(WithStringLinkedListArrayGroup);
	RUN_UNITTESTSUBGROUP(WithStringLinkedListArrayGroup2);
	RUN_UNITTESTSUBGROUP(WithIntegerLinkedListContinuousArrayGroup);
	RUN_UNITTESTSUBGROUP(WithIntegerStaticLinkedListArrayGroup);
	RUN_UNITTESTSUBGROUP(WithIntegerDynamicLinkedListArrayGroup);
}
END_UNITTESTGROUP(LinkedListArrayGroup)

//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------

BEGIN_UNITTESTGROUP(WithIntegerLinkedListArrayGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE, 200> Array2;

		UTF_CHECK(Array2.Capacity () == 200);
		UTF_CHECK(Array2.RemainingCapacity () == 200);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingLinks)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default
		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 2;
		Array.SetData (BaseLink, Data);
		 
		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE>::NodeId Link = Array.AllocateNode ();
			UTF_CHECK(Link != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
 
			ELEMENT_TYPE Data = 2;
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		UTF_CHECK(Array.RemainingCapacity () == 79);// 20 in the loop + the initial
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinks)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 2;
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2+i;
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		BaseLink = Array.RemoveNode(BaseLink, 2);
		BaseLink = Array.RemoveNode(BaseLink, 5);
		BaseLink = Array.RemoveNode(BaseLink, 8);
		BaseLink = Array.RemoveNode(BaseLink, 0);
		UTF_CHECK(BaseLink == 1);
		BaseLink = Array.RemoveNode(BaseLink, 1);
		UTF_CHECK(BaseLink == 4);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomInsertion)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 2;
		Array.SetData (BaseLink, Data);

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink2 = Array.AllocateNode ();
		Data = 98;
		Array.SetData (BaseLink2, Data);

		for (int i=0; i<25; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link2 = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2+i;
			Array.SetData (Link1, Data);
			Array.SetData (Link2, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
			BaseLink2 = Array.AddNode (BaseLink2, Link2);
		}

		UTF_CHECK(Array.RemainingCapacity () == 48);
	}
	END_UNITTEST

	BEGIN_UNITTEST(WalkingLinkedLists)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 98;
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE LastPieceOfData = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = 2 * i+ 2;
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		LastPieceOfData = Data;

		LinkedListArray <ELEMENT_TYPE> ::NodeId id = BaseLink;
		do 
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId temp = Array.GetNextNode (id);
			if (temp == LinkedListArray <ELEMENT_TYPE> ::INVALID_LINK_ID)
				break;
			id = temp;
		}while (1);// id == 0 is our biggest element

		// point to the last link and make sure that the order is correct
		UTF_CHECK (LastPieceOfData == Array.GetData (id));
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingSorted)
	{
		LinkedListArray <ELEMENT_TYPE, 100, InsertSorted> Array;// a sorted array

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 98;
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE FirstPieceOfData = Data;
		
		// insert 10 items in reverse order
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data -= 2;
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		ELEMENT_TYPE	LastPieceOfData = Data;

		// now validate that the items are in the proper order
		LinkedListArray <ELEMENT_TYPE>::NodeId	WorkingLink = BaseLink;
		ELEMENT_TYPE InitialData = Array.GetData (BaseLink);
		UTF_CHECK (LastPieceOfData == InitialData);// since we inserted values in reverse value, we'd expect the smallest values to appear first.

		//LastPieceOfData = Array.GetData (WorkingLink);
		while (WorkingLink != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID)
		{
			ELEMENT_TYPE CurrentData = Array.GetData (WorkingLink);
			UTF_CHECK (CurrentData >= LastPieceOfData);
			LastPieceOfData = CurrentData;
			WorkingLink = Array.GetNextNode (WorkingLink);
		}
		UTF_CHECK (FirstPieceOfData == LastPieceOfData);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default
		
		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 0;
		Array.SetData (BaseLink, Data);

		for (int i=1; i<100; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = ELEMENT_CONVERSION(i*2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		// verify that they are allocated in order. Also, verify that all values are accessible
		for (ELEMENT_TYPE i=99; i>=0; i--)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId id = (LinkedListArray <ELEMENT_TYPE>::NodeId) ELEMENT_CONVERSION(i);
			ELEMENT_TYPE value = Array.GetData (id);
			UTF_CHECK(value == ELEMENT_CONVERSION (i*2));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingBeyondTheBoundaries)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId LastLink = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2;
			Array.SetData (Link1, Data);
			if (LastLink)
				LastLink = Array.AddNode (LastLink, Link1);
			LastLink = Link1;
		}

		UTF_CHECKASSERT (Array.AllocateNode ());
	}
	END_UNITTEST

	/*BEGIN_UNITTEST(SortingWithTypesThatDoNotSupportLessThan)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default
	}
	END_UNITTEST*/

	BEGIN_UNITTEST(AccessingLinksThatAreNotAllocated)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		// random numbers
		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		AP_ASSERT_SUPPORT(int Data = 3;)
		UTF_CHECKASSERT (Array.SetData(34, Data));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingMoreLinksThanAreAvailable)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
		BaseLink = Array.AddNode (BaseLink, Link1);

		Array.RemoveNode (BaseLink, Link1);
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, Link1));// this link is no longer available in the linked list
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, 34));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinksThatAreNotAvailable)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		int Data = 2;
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			int Data = 2;
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 3));// this link is not here anymore and should assert
		BaseLink = Array.RemoveNode(BaseLink, 2);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 2));// this link is not here anymore and should assert

	}
	END_UNITTEST

	BEGIN_UNITTEST(FindingItems)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 2;
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2 * i;
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Data = 2;
		LinkedListArray <ELEMENT_TYPE>::NodeId FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
		Data = 5;// Shouldn't exist
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex == LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);

		Data = 8;
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
	}
	END_UNITTEST

	BEGIN_UNITTEST(VerifyingClearAll)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = 2;
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2 * i;
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Array.ClearAllLinks ();

		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		Data = 3;
		UTF_CHECKASSERT (Array.SetData(34, Data));
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithIntegerLinkedListArrayGroup)

//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------

BEGIN_UNITTESTGROUP(WithStringLinkedListArrayGroup)
{
#define ELEMENT_CONVERSION(x)  IntToStringLLA((x))
#define ELEMENT_TYPE ShortString 

	BEGIN_UNITTEST(Constructors)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);// default
		UTF_CHECK(Array.RemainingCapacity () == 10);// default

		LinkedListArray <ELEMENT_TYPE, 50> Array2;

		UTF_CHECK(Array2.Capacity () == 50);
		UTF_CHECK(Array2.RemainingCapacity () == 50);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingLinks)
	{
		LinkedListArray <ELEMENT_TYPE, 30> Array;

		UTF_CHECK(Array.Capacity () == 30);// default
		UTF_CHECK(Array.RemainingCapacity () == 30);// default
		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE>::NodeId Link = Array.AllocateNode ();
			UTF_CHECK(Link != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);

			ELEMENT_TYPE Data = ELEMENT_TYPE(2);
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		
		UTF_CHECK(Array.RemainingCapacity() == 9);// 20 in the loop + the initial
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinks)
	{
		LinkedListArray <ELEMENT_TYPE, 30> Array;

		UTF_CHECK(Array.Capacity () == 30);// default
		UTF_CHECK(Array.RemainingCapacity () == 30);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2+i);
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		BaseLink = Array.RemoveNode(BaseLink, 2);
		BaseLink = Array.RemoveNode(BaseLink, 5);
		BaseLink = Array.RemoveNode(BaseLink, 8);
		BaseLink = Array.RemoveNode(BaseLink, 0);
		UTF_CHECK(BaseLink == 1);
		BaseLink = Array.RemoveNode(BaseLink, 1);
		UTF_CHECK(BaseLink == 4);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomInsertion)
	{
		LinkedListArray <ELEMENT_TYPE, 60> Array;

		UTF_CHECK(Array.Capacity () == 60);// default
		UTF_CHECK(Array.RemainingCapacity () == 60);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink2 = Array.AllocateNode ();
		Data = ELEMENT_TYPE(98);
		Array.SetData (BaseLink2, Data);

		for (int i=0; i<25; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link2 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2+i);
			Array.SetData (Link1, Data);
			Array.SetData (Link2, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
			BaseLink2 = Array.AddNode (BaseLink2, Link2);
		}

		UTF_CHECK(Array.RemainingCapacity () == 8);
	}
	END_UNITTEST

	BEGIN_UNITTEST(WalkingLinkedLists)
	{
		LinkedListArray <ELEMENT_TYPE, 30> Array;

		UTF_CHECK(Array.Capacity () == 30);// default
		UTF_CHECK(Array.RemainingCapacity () == 30);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(98);
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE LastPieceOfData = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = ELEMENT_TYPE(2 * i+ 2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		LastPieceOfData = Data;

		LinkedListArray <ELEMENT_TYPE> ::NodeId id = BaseLink;
		do 
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId temp = Array.GetNextNode (id);
			if (temp == LinkedListArray <ELEMENT_TYPE> ::INVALID_LINK_ID)
				break;
			id = temp;
		}while (1);// id == 0 is our biggest element

		// point to the last link and make sure that the order is correct
		UTF_CHECK (LastPieceOfData == Array.GetData (id));
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingSorted)
	{
		LinkedListArray <ELEMENT_TYPE, 30, InsertSorted> Array;// a sorted array

		UTF_CHECK(Array.Capacity () == 30);// default
		UTF_CHECK(Array.RemainingCapacity () == 30);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		int value = 98;
		ELEMENT_TYPE Data = ELEMENT_CONVERSION(value);
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE FirstPieceOfData = Data;

		// insert 10 items in reverse order
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			value -= 2;
			Data = ELEMENT_CONVERSION(value);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		ELEMENT_TYPE	LastPieceOfData = Data;

		// now validate that the items are in the proper order
		LinkedListArray <ELEMENT_TYPE>::NodeId	WorkingLink = BaseLink;
		ELEMENT_TYPE InitialData = Array.GetData (BaseLink);
		UTF_CHECK (LastPieceOfData == InitialData);// since we inserted values in reverse value, we'd expect the smallest values to appear first.

		//LastPieceOfData = Array.GetData (WorkingLink);
		while (WorkingLink != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID)
		{
			ELEMENT_TYPE CurrentData = Array.GetData (WorkingLink);
			UTF_CHECK (CurrentData >= LastPieceOfData);
			LastPieceOfData = CurrentData;
			WorkingLink = Array.GetNextNode (WorkingLink);
		}
		UTF_CHECK (FirstPieceOfData == LastPieceOfData);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = "0";
		Array.SetData (BaseLink, Data);

		for (int i=1; i<100; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = ELEMENT_TYPE (i*2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		// verify that they are allocated in order. Also, verify that all values are accessible
		for (int i=99; i>0; i--)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId id = (LinkedListArray <ELEMENT_TYPE>::NodeId) i;
			ELEMENT_TYPE value = Array.GetData (id);
			UTF_CHECK(value == ELEMENT_TYPE(i*2));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingBeyondTheBoundaries)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId LastLink = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2);
			Array.SetData (Link1, Data);
			if (LastLink)
				LastLink = Array.AddNode (LastLink, Link1);
			LastLink = Link1;
		}

		UTF_CHECKASSERT (Array.AllocateNode ());
	}
	END_UNITTEST
}
END_UNITTESTGROUP(WithStringLinkedListArrayGroup)

BEGIN_UNITTESTGROUP(WithStringLinkedListArrayGroup2)
{
	BEGIN_UNITTEST(AccessingLinksThatAreNotAllocated)
	{
		LinkedListArray <ELEMENT_TYPE, 50> Array;

		UTF_CHECK(Array.Capacity () == 50);// default
		UTF_CHECK(Array.RemainingCapacity () == 50);// default

		// random numbers
		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		AP_ASSERT_SUPPORT(int Data = 3;)
		UTF_CHECKASSERT (Array.SetData(34, ELEMENT_TYPE(Data)));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingMoreLinksThanAreAvailable)
	{
		LinkedListArray <ELEMENT_TYPE, 50> Array;

		UTF_CHECK(Array.Capacity () == 50);// default
		UTF_CHECK(Array.RemainingCapacity () == 50);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
		BaseLink = Array.AddNode (BaseLink, Link1);

		Array.RemoveNode (BaseLink, Link1);
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, Link1));// this link is no longer available in the linked list
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, 34));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinksThatAreNotAvailable)
	{
		LinkedListArray <ELEMENT_TYPE, 50> Array;

		UTF_CHECK(Array.Capacity () == 50);// default
		UTF_CHECK(Array.RemainingCapacity () == 50);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		int Data = 2;
		Array.SetData (BaseLink, ELEMENT_TYPE(Data));

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			int Data = 2;
			Array.SetData (Link, ELEMENT_TYPE(Data));
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 3));// this link is not here anymore and should assert
		BaseLink = Array.RemoveNode(BaseLink, 2);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 2));// this link is not here anymore and should assert

	}
	END_UNITTEST

	BEGIN_UNITTEST(FindingItems)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2 * i);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Data = ELEMENT_TYPE(2);
		LinkedListArray <ELEMENT_TYPE>::NodeId FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
		Data = ELEMENT_TYPE(5);// Shouldn't exist
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex == LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);

		Data = ELEMENT_TYPE(8);
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
	}
	END_UNITTEST

	BEGIN_UNITTEST(VerifyingClearAll)
	{
		LinkedListArray <ELEMENT_TYPE, 50> Array;

		UTF_CHECK(Array.Capacity () == 50);// default
		UTF_CHECK(Array.RemainingCapacity () == 50);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2 * i);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Array.ClearAllLinks ();

		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		Data = ELEMENT_TYPE(3);
		UTF_CHECKASSERT (Array.SetData(34, Data));
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithStringLinkedListArrayGroup)


BEGIN_UNITTESTGROUP(WithIntegerLinkedListContinuousArrayGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE, 200> Array2;

		UTF_CHECK(Array2.Capacity () == 200);
		UTF_CHECK(Array2.RemainingCapacity () == 200);
	}
	END_UNITTEST

		BEGIN_UNITTEST(InsertingLinks)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default
		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE>::NodeId Link = Array.AllocateNode ();
			UTF_CHECK(Link != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);

			ELEMENT_TYPE Data = ELEMENT_TYPE(2);
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		UTF_CHECK(Array.RemainingCapacity () == 79);// 20 in the loop + the initial
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinks)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2+i);
			Array.SetData (Link, Data);
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		BaseLink = Array.RemoveNode(BaseLink, 2);
		BaseLink = Array.RemoveNode(BaseLink, 5);
		BaseLink = Array.RemoveNode(BaseLink, 8);
		BaseLink = Array.RemoveNode(BaseLink, 0);
		UTF_CHECK(BaseLink == 1);
		BaseLink = Array.RemoveNode(BaseLink, 1);
		UTF_CHECK(BaseLink == 4);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomInsertion)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink2 = Array.AllocateNode ();
		Data = 98;
		Array.SetData (BaseLink2, Data);

		for (int i=0; i<25; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link2 = Array.AllocateNode ();

			ELEMENT_TYPE Data = 2+i;
			Array.SetData (Link1, Data);
			Array.SetData (Link2, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
			BaseLink2 = Array.AddNode (BaseLink2, Link2);
		}

		UTF_CHECK(Array.RemainingCapacity () == 48);
	}
	END_UNITTEST

	BEGIN_UNITTEST(WalkingLinkedLists)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(98);
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE LastPieceOfData = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = ELEMENT_TYPE(2 * i+ 2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		LastPieceOfData = Data;

		LinkedListArray <ELEMENT_TYPE> ::NodeId id = BaseLink;
		do 
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId temp = Array.GetNextNode (id);
			if (temp == LinkedListArray <ELEMENT_TYPE> ::INVALID_LINK_ID)
				break;
			id = temp;
		}while (1);// id == 0 is our biggest element

		// point to the last link and make sure that the order is correct
		UTF_CHECK (LastPieceOfData == Array.GetData (id));
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingSorted)
	{
		LinkedListArray <ELEMENT_TYPE, 100, InsertSorted> Array;// a sorted array

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(98);
		Array.SetData (BaseLink, Data);

		ELEMENT_TYPE FirstPieceOfData = Data;

		// insert 10 items in reverse order
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data -= ELEMENT_TYPE(2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}
		ELEMENT_TYPE	LastPieceOfData = Data;

		// now validate that the items are in the proper order
		LinkedListArray <ELEMENT_TYPE>::NodeId	WorkingLink = BaseLink;
		ELEMENT_TYPE InitialData = Array.GetData (BaseLink);
		UTF_CHECK (LastPieceOfData == InitialData);// since we inserted values in reverse value, we'd expect the smallest values to appear first.

		//LastPieceOfData = Array.GetData (WorkingLink);
		while (WorkingLink != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID)
		{
			ELEMENT_TYPE CurrentData = Array.GetData (WorkingLink);
			UTF_CHECK (CurrentData >= LastPieceOfData);
			LastPieceOfData = CurrentData;
			WorkingLink = Array.GetNextNode (WorkingLink);
		}
		UTF_CHECK (FirstPieceOfData == LastPieceOfData);
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(0);
		Array.SetData (BaseLink, Data);

		for (int i=1; i<100; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			Data = ELEMENT_TYPE(i*2);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		// verify that they are allocated in order. Also, verify that all values are accessible
		for (ELEMENT_TYPE i=99; i>=0; i--)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId id = (LinkedListArray <ELEMENT_TYPE>::NodeId) ELEMENT_CONVERSION(i);
			ELEMENT_TYPE value = Array.GetData (id);
			UTF_CHECK(value == ELEMENT_TYPE(i*2));
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingBeyondTheBoundaries)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId LastLink = 0;
		for (int i=0; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2);
			Array.SetData (Link1, Data);
			if (LastLink)
				LastLink = Array.AddNode (LastLink, Link1);
			LastLink = Link1;
		}

		UTF_CHECKASSERT (Array.AllocateNode ());
	}
	END_UNITTEST

	BEGIN_UNITTEST(AccessingLinksThatAreNotAllocated)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		// random numbers
		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		AP_ASSERT_SUPPORT(int Data = 3;)
		UTF_CHECKASSERT (Array.SetData(34, ELEMENT_TYPE(Data)));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingMoreLinksThanAreAvailable)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();
		BaseLink = Array.AddNode (BaseLink, Link1);

		Array.RemoveNode (BaseLink, Link1);
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, Link1));// this link is no longer available in the linked list
		UTF_CHECKASSERT (Array.RemoveNode (BaseLink, 34));
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingLinksThatAreNotAvailable)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId	BaseLink = Array.AllocateNode ();
		int Data = 2;
		Array.SetData (BaseLink, ELEMENT_TYPE(Data));

		for (int i=0; i<20; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link = Array.AllocateNode ();

			int Data = ELEMENT_TYPE(2);
			Array.SetData (Link, ELEMENT_TYPE(Data));
			BaseLink = Array.AddNode (BaseLink, Link);
		}

		BaseLink = Array.RemoveNode(BaseLink, 3);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 3));// this link is not here anymore and should assert
		BaseLink = Array.RemoveNode(BaseLink, 2);
		UTF_CHECKASSERT (BaseLink = Array.RemoveNode(BaseLink, 2));// this link is not here anymore and should assert

	}
	END_UNITTEST

	BEGIN_UNITTEST(FindingItems)
	{
		LinkedListArray <ELEMENT_TYPE, 10> Array;

		UTF_CHECK(Array.Capacity () == 10);
		UTF_CHECK(Array.RemainingCapacity () == 10);

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2 * i);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Data = 2;
		LinkedListArray <ELEMENT_TYPE>::NodeId FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
		Data = 5;// Shouldn't exist
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex == LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);

		Data = 8;
		FoundIndex = Array.Find (Data);
		UTF_CHECK (FoundIndex != LinkedListArray <ELEMENT_TYPE>::INVALID_LINK_ID);
	}
	END_UNITTEST

	BEGIN_UNITTEST(VerifyingClearAll)
	{
		LinkedListArray <ELEMENT_TYPE> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.RemainingCapacity () == 100);// default

		LinkedListArray <ELEMENT_TYPE> ::NodeId BaseLink = Array.AllocateNode ();
		ELEMENT_TYPE Data = ELEMENT_TYPE(2);
		Array.SetData (BaseLink, Data);

		for (int i=1; i<10; i++)
		{
			LinkedListArray <ELEMENT_TYPE> ::NodeId Link1 = Array.AllocateNode ();

			ELEMENT_TYPE Data = ELEMENT_TYPE(2 * i);
			Array.SetData (Link1, Data);
			BaseLink = Array.AddNode (BaseLink, Link1);
		}

		Array.ClearAllLinks ();

		UTF_CHECKASSERT (Array.GetNextNode (-1));
		UTF_CHECKASSERT (Array.GetNextNode (9));
		UTF_CHECKASSERT (Array.AddNode (3, 25));

		Data = ELEMENT_TYPE(3);
		UTF_CHECKASSERT (Array.SetData(34, Data));
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithIntegerLinkedListContinuousArrayGroup)

//-----------------------------------------------------------------------
BEGIN_UNITTESTGROUP(WithIntegerStaticLinkedListArrayGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default

		StaticLinkedListArray <ELEMENT_TYPE, 200> Array2;

		UTF_CHECK(Array2.Capacity () == 200);
		UTF_CHECK(Array2.Count () == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingData)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> testArray;

		UTF_CHECK(testArray.Capacity () == 100);// default
		UTF_CHECK(testArray.Count () == 0);// default

		for (int i = 0; i < 5; ++i)
		{
			testArray.Add(i);
		}

		int* pZero =	&testArray[0];
		int* pOne =		&testArray[1];
		int* pTwo =		&testArray[2];
		int* pThree =	&testArray[3];
		int* pFour =	&testArray[4];

		UTF_CHECK(testArray.Count() == 5);

		testArray.Remove(2);

		UTF_CHECK(testArray.Count() == 4);
		UTF_CHECK(testArray[0] == 0);
		UTF_CHECK(testArray[1] == 1);
		UTF_CHECK(testArray[2] == 3);
		UTF_CHECK(testArray[3] == 4);
		UTF_CHECK(&(testArray[0]) == pZero);
		UTF_CHECK(&(testArray[1]) == pOne);
		UTF_CHECK(&(testArray[2]) == pThree);
		UTF_CHECK(&(testArray[3]) == pFour);

		testArray.Add(42);
		UTF_CHECK(testArray.Count() == 5);
		UTF_CHECK(testArray[0] == 0);
		UTF_CHECK(testArray[1] == 1);
		UTF_CHECK(testArray[2] == 3);
		UTF_CHECK(testArray[3] == 4);
		UTF_CHECK(testArray[4] == 42);
		UTF_CHECK(&(testArray[0]) == pZero);
		UTF_CHECK(&(testArray[1]) == pOne);
		UTF_CHECK(&(testArray[2]) == pThree);
		UTF_CHECK(&(testArray[3]) == pFour);
		UTF_CHECK(&(testArray[4]) == pTwo);
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingItemsFromTheFrontOfTheQueue)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default

		int ValueToCheck = 100;
		Array.Add (ValueToCheck);

		for (int i=0; i<20; i++)
		{
			Array.Add (i);
		}
		//int head = Array.GetHead ();
		UTF_CHECK(Array.Count () == 21);// 20 in the loop + the initial
		Array.Remove(0);
		UTF_CHECK (Array.Count() == 20);	// these better be equal

		int NumToRemove = 5; // remove the next 5 items
		for (int i=0; i<NumToRemove; i++)
		{
			Array.Remove(0);
		}
		int ValueNow = Array[0];
		UTF_CHECK (NumToRemove == ValueNow);
		
		UTF_CHECK(Array.Count () == 15);

		Array.Clear();
		AP_ASSERT_SUPPORT(int id;)
		UTF_CHECKASSERT (id = Array[0]);// should fail
	}
	END_UNITTEST
	
	BEGIN_UNITTEST(DeletingItemsFromTheMiddleOfTheQueue)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default
		
		for( int i = 0; i < 10; ++i )
		{
		    Array.Add( i );
		}
		
		for( int i = 0; i < 10; ++i )
		{
		    UTF_CHECK( Array[ i ] == i )
		}
		
		UTF_CHECK( Array[ 4 ] == 4 );
		UTF_CHECK( Array.Count() == 10 );
		
		Array.Remove( 4 );
		
		UTF_CHECK( Array.Count() == 9 );
		AP_ASSERT_SUPPORT(int id;)
		UTF_CHECKASSERT (id = Array[9]);// should fail; there should not be an element 9
		UTF_CHECK( Array[ 4 ] != 4 );
		
		for( int i = 0; i < 4; ++i )
		{
		    UTF_CHECK( Array[ i ] == i )
		}
		
		for( int i = 4; i < 9; ++i )
		{
		    UTF_CHECK( Array[ i ] == ( i + 1 ) )
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default		

		for (int i=0; i<25; i++)
		{
			Array.Add (i);
		}
		UTF_CHECK(Array.Count() == 25);

		for (int i=24; i>=0; i--)
		{
			int val = Array[i];
			UTF_CHECK (val == i);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(WalkingTheQueue)
	{
		StaticLinkedListArray <ELEMENT_TYPE, 100> Array;

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default

		for (int i=0; i<40; i++)
		{
			Array.Add (i*2);
		}

		int NumToRemove = 5; // remove the next 5 items
		for (int i=0; i<NumToRemove; i++)
		{
			int Val1 = Array.LastItem();
			int Val2 = Array[Array.Count() - 1];
			UTF_CHECK (Val1 == Val2);
			Array.Remove(Array.Count() - 1);
		}

		UTF_CHECK(Array.Count () == 35);
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithIntegerSimpleLinkedListGroup)


BEGIN_UNITTESTGROUP(WithIntegerDynamicLinkedListArrayGroup)
{
#define ELEMENT_CONVERSION(x) x
#define ELEMENT_TYPE int

	BEGIN_UNITTEST(Constructors)
	{
		DynamicLinkedListArray <ELEMENT_TYPE > Array;
		UTF_CHECK(Array.Capacity () == 0);
		UTF_CHECK(Array.Count () == 0);

		Array.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(Array.Capacity () == 100);
		UTF_CHECK(Array.Count () == 0);

		DynamicLinkedListArray <ELEMENT_TYPE > Array2;
		UTF_CHECK(Array2.Count () == 0);
		UTF_CHECK(Array2.Capacity () == 0);

		Array2.Resize( Axiom::Memory::DEFAULT_HEAP, 200 );

		UTF_CHECK(Array2.Capacity () == 200);
		UTF_CHECK(Array2.Count () == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(InsertingData)
	{
		DynamicLinkedListArray <ELEMENT_TYPE> testArray;
		testArray.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(testArray.Capacity () == 100);// default
		UTF_CHECK(testArray.Count () == 0);// default

		for (int i = 0; i < 5; ++i)
		{
			testArray.Add(i);
		}

		int* pZero =	&testArray[0];
		int* pOne =		&testArray[1];
		int* pTwo =		&testArray[2];
		int* pThree =	&testArray[3];
		int* pFour =	&testArray[4];

		UTF_CHECK(testArray.Count() == 5);

		testArray.Remove(2);

		UTF_CHECK(testArray.Count() == 4);
		UTF_CHECK(testArray[0] == 0);
		UTF_CHECK(testArray[1] == 1);
		UTF_CHECK(testArray[2] == 3);
		UTF_CHECK(testArray[3] == 4);
		UTF_CHECK(&(testArray[0]) == pZero);
		UTF_CHECK(&(testArray[1]) == pOne);
		UTF_CHECK(&(testArray[2]) == pThree);
		UTF_CHECK(&(testArray[3]) == pFour);

		testArray.Add(42);
		UTF_CHECK(testArray.Count() == 5);
		UTF_CHECK(testArray[0] == 0);
		UTF_CHECK(testArray[1] == 1);
		UTF_CHECK(testArray[2] == 3);
		UTF_CHECK(testArray[3] == 4);
		UTF_CHECK(testArray[4] == 42);
		UTF_CHECK(&(testArray[0]) == pZero);
		UTF_CHECK(&(testArray[1]) == pOne);
		UTF_CHECK(&(testArray[2]) == pThree);
		UTF_CHECK(&(testArray[3]) == pFour);
		UTF_CHECK(&(testArray[4]) == pTwo);
	}
	END_UNITTEST

	BEGIN_UNITTEST(DeletingItemsFromTheFrontOfTheQueue)
	{
		DynamicLinkedListArray <ELEMENT_TYPE > Array;
		Array.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default

		int ValueToCheck = 100;
		Array.Add (ValueToCheck);

		for (int i=0; i<20; i++)
		{
			Array.Add (i);
		}
		//int head = Array.GetHead ();
		UTF_CHECK(Array.Count () == 21);// 20 in the loop + the initial
		Array.Remove(0);
		UTF_CHECK (Array.Count() == 20);	// these better be equal

		int NumToRemove = 5; // remove the next 5 items
		for (int i=0; i<NumToRemove; i++)
		{
			Array.Remove(0);
		}
		int ValueNow = Array[0];
		UTF_CHECK (NumToRemove == ValueNow);
		
		UTF_CHECK(Array.Count () == 15);

		Array.Clear();
		AP_ASSERT_SUPPORT(int id;)
		UTF_CHECKASSERT (id = Array[0]);// should fail
	}
	END_UNITTEST
	
	BEGIN_UNITTEST(DeletingItemsFromTheMiddleOfTheQueue)
	{
		DynamicLinkedListArray <ELEMENT_TYPE> Array;
		Array.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default
		
		for( int i = 0; i < 10; ++i )
		{
		    Array.Add( i );
		}
		
		for( int i = 0; i < 10; ++i )
		{
		    UTF_CHECK( Array[ i ] == i )
		}
		
		UTF_CHECK( Array[ 4 ] == 4 );
		UTF_CHECK( Array.Count() == 10 );
		
		Array.Remove( 4 );
		
		UTF_CHECK( Array.Count() == 9 );
		AP_ASSERT_SUPPORT(int id;)
		UTF_CHECKASSERT (id = Array[9]);// should fail; there should not be an element 9
		UTF_CHECK( Array[ 4 ] != 4 );
		
		for( int i = 0; i < 4; ++i )
		{
		    UTF_CHECK( Array[ i ] == i )
		}
		
		for( int i = 4; i < 9; ++i )
		{
		    UTF_CHECK( Array[ i ] == ( i + 1 ) )
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(RandomAccess)
	{
		DynamicLinkedListArray <ELEMENT_TYPE> Array;
		Array.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default		

		for (int i=0; i<25; i++)
		{
			Array.Add (i);
		}
		UTF_CHECK(Array.Count() == 25);

		for (int i=24; i>=0; i--)
		{
			int val = Array[i];
			UTF_CHECK (val == i);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(WalkingTheQueue)
	{
		DynamicLinkedListArray <ELEMENT_TYPE> Array;
		Array.Resize( Axiom::Memory::DEFAULT_HEAP, 100 );

		UTF_CHECK(Array.Capacity () == 100);// default
		UTF_CHECK(Array.Count () == 0);// default

		for (int i=0; i<40; i++)
		{
			Array.Add (i*2);
		}

		int NumToRemove = 5; // remove the next 5 items
		for (int i=0; i<NumToRemove; i++)
		{
			int Val1 = Array.LastItem();
			int Val2 = Array[Array.Count() - 1];
			UTF_CHECK (Val1 == Val2);
			Array.Remove(Array.Count() - 1);
		}

		UTF_CHECK(Array.Count () == 35);
	}
	END_UNITTEST

#undef ELEMENT_CONVERSION
#undef ELEMENT_TYPE
}
END_UNITTESTGROUP(WithIntegerSimpleLinkedListGroup)

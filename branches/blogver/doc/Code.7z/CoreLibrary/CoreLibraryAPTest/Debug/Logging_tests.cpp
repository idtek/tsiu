#include <unittesting.h>
#include <debug/log.h>

using namespace Axiom;
using namespace Axiom::Math;

static char* srcmessages [] =
{
	"This is a test message.",
	"So is this one - deal with it!",
	"One more test message, last one I promise...",
	"Ok, maybe this is the last one",
	"Or is it?",
	"To be continued...",
};

static char* dstmessages [] =
{
	"[c:test1][p:0]This is a test message.",
	"[c:test1][p:0]So is this one - deal with it!",
	"[c:test1][p:0]One more test message, last one I promise...",
	"[c:test2][p:0]Ok, maybe this is the last one",
	"[c:test2][p:0]Or is it?",
	"[c:test2][p:0]To be continued...",
};

static char srcwarning [] = "This is a warning!";
static char dstwarning [] = "[c:warning][p:0]This is a warning!";
static char srcerror [] = "This is a error!";
static char dsterror [] = "[c:error][p:0]This is a error!";


class TestOutput
	: public OutputHandler
{
public:
	TestOutput (uint numMessages, uint maxMessageLength)
		: mBuffer(0)
		, mNumMessages(numMessages)
		, mCurrentMessage(0)
		, mMaxMessageLength(maxMessageLength)
	{
		mBuffer = AP_NEW(Memory::RESERVED_DEBUG_HEAP,char* [numMessages]);
		for (uint i = 0; i < numMessages; ++i)
		{
			mBuffer[i] = AP_NEW(Memory::RESERVED_DEBUG_HEAP,char [maxMessageLength]);
		}
	}

	~TestOutput ()
	{
		for (uint i = 0; i < mNumMessages; ++i)
		{
			AP_DELETEARRAY(mBuffer[i]);
		}
		AP_DELETEARRAY(mBuffer);
	}

	virtual void Log (ConstStr message)
	{
		AP_ASSERT(mCurrentMessage < mNumMessages);
		StringCopy(mBuffer[mCurrentMessage++],message,mMaxMessageLength-1);
	}

	const char* Message (uint index)
	{
		AP_ASSERT(index < mCurrentMessage);
		return mBuffer[index];
	}

private:
	char**		mBuffer;
	uint		mNumMessages;
	uint		mCurrentMessage;
	uint		mMaxMessageLength;
};


BEGIN_UNITTESTGROUP(LoggingTestGroup)
{
	uint maxMessageLength = 0;
	for (uint i = 0; i < array_count(srcmessages); ++i)
	{
		uint len = StringLength(srcmessages[i]);
		maxMessageLength = Axiom::Max(len,maxMessageLength);
	}
	maxMessageLength += 1;		// Cater for null terminator
	TestOutput output(100,256);
	UTF_CHECK(maxMessageLength < 256);
	InstallLogHandler(&output);
	int checkedMsg = 0;

	BEGIN_UNITTEST(LogTest)
	{
		int i;
		for (i = 0; i < 3; ++i)
		{
			Log("Test1",srcmessages[i]);
		}
		for (; i < 6; ++i)
		{
			Log("Test2",srcmessages[i]);
		}

		checkedMsg = 0;
		for (i = 0; i < 6; ++i)
		{
			UTF_CHECK(StringCompare(dstmessages[i],output.Message(checkedMsg++), sizeof(dstmessages[i])) == 0);
		}
	}
	END_UNITTEST

	BEGIN_UNITTEST(WarnTest)
	{
		Warn(srcwarning);
		UTF_CHECK(StringCompare(dstwarning,output.Message(checkedMsg++), sizeof(dstwarning)) == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(ErrorTest)
	{
		Error(srcerror);
		UTF_CHECK(StringCompare(dsterror,output.Message(checkedMsg++), sizeof(dsterror)) == 0);
	}
	END_UNITTEST

	BEGIN_UNITTEST(BoundaryTest)
	{
		static char badmsg [3000];

		for (int i = 0; i < 2999; ++i)
		{
			badmsg[i] = 'X';
		}
		badmsg[2999] = 0;

//		UTF_CHECKASSERT(Log("Bad",badmsg));
	}
	END_UNITTEST

	InstallLogHandler(0);
}
END_UNITTESTGROUP(LoggingTestGroup)


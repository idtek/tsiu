#include <UnitTesting.h>
#include <thread/atomic.h>
#include <thread/thread.h>
#include <core/time.h>

using namespace Axiom;
using namespace Axiom::Thread;

static const float ATOMIC_FAILURE_TIMER_THRESHOLD = 100.0f;

// Wait on this mutexed flag and if it passes the threshold time, then the test fails!!
#define WAIT_FOR_ATOMIC_FLAG( checkFlag, sleepAmount )											\
{																								\
	Timer timer; timer.Start();																	\
	while(timer.GetTime().AsFloatInSeconds() < ATOMIC_FAILURE_TIMER_THRESHOLD && checkFlag==0 )	\
	{																							\
		Thread::Sleep(sleepAmount);																\
	}																							\
	UTF_CHECK(timer.GetTime().AsFloatInSeconds() < ATOMIC_FAILURE_TIMER_THRESHOLD)				\
}


const UInt32 MAX_LAST_LOG_NUM = 100;
const UInt32 MAX_BUFFER_SIZE = MAX_LAST_LOG_NUM/2;

struct TestBuffer
{
	UInt32* 				pauseFlag;
	UInt32 					storeNum;
	UInt32 					writeBufIndex;
	UInt32 					evenBuffer[MAX_BUFFER_SIZE];
	UInt32 					oddBuffer[MAX_BUFFER_SIZE];

	UInt32*					pEvenThreadDone;
	UInt32*					pOddThreadDone;

	Thread::ThreadId		sEvenThreadHandle;
	Thread::ThreadId		sOddThreadHandle;
};


TestBuffer sWriteBuffer;
UInt32 dummyMemDataForInt = 1;
UInt32 sStartCleanUpFlag = 0;


struct TestIntInterpret
{	
	TestIntInterpret(int val){mValue = val;}
	int mValue;
};

struct TestInt
{	
	TestInt(int val){mValue = val;}
	int mValue;
};


// This thread only add even numbers to the buffer
void Thread_Odd_Main( ThreadParam )
{
	UInt32 nLastIndex=0;
	UInt32 nLastLogNum=99999999;

	while(AtomicRead(&sWriteBuffer.storeNum)< MAX_LAST_LOG_NUM)
	{
		if( AtomicRead(&sWriteBuffer.writeBufIndex) == 1 && 
			AtomicRead(&sWriteBuffer.storeNum) != nLastLogNum && 
			nLastIndex < MAX_BUFFER_SIZE)
		{
			UTF_CHECK(AtomicRead(&sWriteBuffer.writeBufIndex) == 1);
			UTF_CHECK(nLastIndex < MAX_BUFFER_SIZE);
			AtomicExchange(&sWriteBuffer.oddBuffer[nLastIndex], AtomicRead(&sWriteBuffer.storeNum));
			nLastIndex++;
			nLastLogNum = AtomicRead(&sWriteBuffer.storeNum);

			AtomicExchange(&sWriteBuffer.writeBufIndex, 2);
		}
		Thread::Sleep(0);
	}

	Thread::Sleep(200);
	AtomicExchangePointer(reinterpret_cast<void**>(&sWriteBuffer.pOddThreadDone), reinterpret_cast<void*>(&dummyMemDataForInt));
	Thread::Sleep(200);

	WAIT_FOR_ATOMIC_FLAG(AtomicRead(&sStartCleanUpFlag), 15);

	// Wait until thread get's clean up call
	UTF_CHECK(AtomicReadPointer(reinterpret_cast<void**>(&sWriteBuffer.pOddThreadDone)) == NULL);

	// verify that the old buffer has only odd values and the even buffer has only even values
	for(int i=0;i<MAX_BUFFER_SIZE;i++)
	{
		UTF_CHECK(sWriteBuffer.oddBuffer[i] % 2 != 0);
		AtomicDecrement(&sWriteBuffer.storeNum);
		AtomicExchangeAdd(&sWriteBuffer.storeNum, 1);
	}

	Thread::Sleep(200);
	AtomicExchangePointer(reinterpret_cast<void**>(&sWriteBuffer.pOddThreadDone), reinterpret_cast<void*>(&dummyMemDataForInt));
}

// This thread only add odd numbers to the buffer
void Thread_Even_Main( ThreadParam)
{
	UInt32 nLastIndex=0;
	UInt32 nLastLogNum=99999999;

	while(AtomicRead(&sWriteBuffer.storeNum)< MAX_LAST_LOG_NUM)
	{
		if( AtomicRead(&sWriteBuffer.writeBufIndex) == 0 && 
			AtomicRead(&sWriteBuffer.storeNum) != nLastLogNum &&
			nLastIndex < MAX_BUFFER_SIZE)
		{
			UTF_CHECK(AtomicRead(&sWriteBuffer.writeBufIndex) == 0);
			UTF_CHECK(nLastIndex < MAX_BUFFER_SIZE);
			AtomicExchange(&sWriteBuffer.evenBuffer[nLastIndex], AtomicRead(&sWriteBuffer.storeNum));
			nLastIndex++;
			nLastLogNum = AtomicRead(&sWriteBuffer.storeNum);
			
			AtomicExchange(&sWriteBuffer.writeBufIndex, 2);
		}
		Thread::Sleep(0);
	}

	Thread::Sleep(10);
	AtomicExchangePointer((void**)&sWriteBuffer.pEvenThreadDone, (void*)&dummyMemDataForInt);
	Thread::Sleep(10);
	
	// Wait until thread get's clean up call
	WAIT_FOR_ATOMIC_FLAG(AtomicRead(&sStartCleanUpFlag), 15);

	UTF_CHECK(AtomicReadPointer((void**)&sWriteBuffer.pEvenThreadDone)==NULL);

	// verify that the old buffer has only odd values and the even buffer has only even values
	for(int i=0; i < MAX_BUFFER_SIZE; i++)
	{
		UTF_CHECK(sWriteBuffer.evenBuffer[i] % 2 == 0);
		AtomicDecrement(&sWriteBuffer.storeNum);
		AtomicExchangeSubtract(&sWriteBuffer.storeNum, 1);
		AtomicExchangeAdd(&sWriteBuffer.storeNum, 1);
		AtomicExchangeAdd(&sWriteBuffer.storeNum, 1);
	}

	Thread::Sleep(100);
	AtomicExchangePointer((void**)&sWriteBuffer.pEvenThreadDone, (void*)&dummyMemDataForInt);
}

BEGIN_UNITTESTGROUP( ThreadAtomicTestGroup )
{
	// Test all other functional use
	BEGIN_UNITTEST(ThreadAtomicFunctionalTest)
	{		
		AtomicExchange(&sWriteBuffer.writeBufIndex, 0);

		// Spawn the threads
		sWriteBuffer.sEvenThreadHandle = Thread::CreateThread(Thread_Even_Main,(Thread::ThreadParam)0,Thread::TP_NORMAL,0,"EVENT_ATOMIC_THREAD");
		UTF_CHECK(sWriteBuffer.sEvenThreadHandle != Thread::AP_INVALID_THREADID);
		
		sWriteBuffer.sOddThreadHandle  = Thread::CreateThread(Thread_Odd_Main,(Thread::ThreadParam)0,Thread::TP_NORMAL,0,"ODD_ATOMIC_THREAD");
		UTF_CHECK(sWriteBuffer.sOddThreadHandle != Thread::AP_INVALID_THREADID);

		// Reset done flags
		sWriteBuffer.pEvenThreadDone = NULL;
		sWriteBuffer.pOddThreadDone = NULL;

		// Run the test and use this loop to control the threads
		while(AtomicRead(&sWriteBuffer.storeNum)<MAX_LAST_LOG_NUM)
		{			
			AtomicIncrement(&sWriteBuffer.storeNum);

			// Interlock switching write indexes..
			if(AtomicRead(&sWriteBuffer.storeNum) % 2 == 0)
			{
				AtomicAnd(&sWriteBuffer.writeBufIndex, 0);
				UTF_CHECK(AtomicRead(&sWriteBuffer.writeBufIndex) ==0);
			}
			else
			{
				AtomicExchange(&sWriteBuffer.writeBufIndex, 1);
				UTF_CHECK(AtomicRead(&sWriteBuffer.writeBufIndex) ==1);
			}

			// Wait until the value is written!!
			while(AtomicRead(&sWriteBuffer.storeNum)<MAX_LAST_LOG_NUM && AtomicRead(&sWriteBuffer.writeBufIndex) != 2)
			{
				Thread::Sleep(5);
			}
		}

		// Ensure both threads returns within a good amount of time
		WAIT_FOR_ATOMIC_FLAG(AtomicReadPointer((void**)&sWriteBuffer.pEvenThreadDone), 15);
		WAIT_FOR_ATOMIC_FLAG(AtomicReadPointer((void**)&sWriteBuffer.pOddThreadDone), 15);

		UTF_CHECK(AtomicReadPointer((void**)&sWriteBuffer.pEvenThreadDone) != NULL);
		UTF_CHECK(AtomicReadPointer((void**)&sWriteBuffer.pOddThreadDone) != NULL);

		AtomicCompareExchangePointer((void**)&sWriteBuffer.pEvenThreadDone, NULL, (void*)&dummyMemDataForInt);
		AtomicCompareExchangePointer((void**)&sWriteBuffer.pOddThreadDone, NULL, (void*)&dummyMemDataForInt);

		UTF_CHECK(AtomicReadPointer((void**)&sWriteBuffer.pEvenThreadDone) != (void*)&dummyMemDataForInt);
		UTF_CHECK(AtomicReadPointer((void**)&sWriteBuffer.pOddThreadDone) != (void*)&dummyMemDataForInt);
		
		AtomicCompareExchange(&sStartCleanUpFlag, 1, 0);
		UTF_CHECK(AtomicRead(&sStartCleanUpFlag) == 1);
		UTF_CHECK(AtomicRead(&sWriteBuffer.storeNum) == 100);
		
		// Testing atomic xor
		UInt32 val=0;
		AtomicXor(&val,1);
		UTF_CHECK(AtomicRead(&val) == 1);
		AtomicXor(&val,1);
		UTF_CHECK(AtomicRead(&val) == 0);

		// verify that the old buffer has only odd values and the even buffer has only even values
		for(int i=0; i < MAX_BUFFER_SIZE; i++)
		{
			UTF_CHECK(sWriteBuffer.evenBuffer[i] % 2 == 0);
			UTF_CHECK(sWriteBuffer.oddBuffer[i] % 2 != 0);
		}

		// Ensure both threads returns within a good amount of time
		WAIT_FOR_ATOMIC_FLAG(AtomicReadPointer((void**)&sWriteBuffer.pEvenThreadDone),15);
		WAIT_FOR_ATOMIC_FLAG(AtomicReadPointer((void**)&sWriteBuffer.pOddThreadDone),15);

	}	
	END_UNITTEST


	// Test all boundary cases
	BEGIN_UNITTEST(AtomicClassTest)
	{
		// Testing the functional correctness of Atomic class
		// on a single thread.  The atomic calls are all tested.  
		// If the atomic class is correct, the atomic behaviour should retain.

		Atomic<int> atomicObj0(100);
		Atomic<int> atomicObj1(atomicObj0);
		const Atomic<int> atomicObj2 = atomicObj1;
		const Atomic<int> atomicObj3(1);
		Atomic<int> atomicObj4;

		atomicObj4 = 10;
		UTF_CHECK(atomicObj4 == 10);

		UTF_CHECK(atomicObj2 == atomicObj2);
		UTF_CHECK(atomicObj3 != atomicObj2);

		UTF_CHECK(atomicObj2 == 100);
		UTF_CHECK(atomicObj2 == atomicObj1);
		UTF_CHECK(atomicObj3 != 100);

		UTF_CHECK(static_cast<UInt32>(atomicObj2) == 100);

		++atomicObj1;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 101);

		--atomicObj1;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 100);

		atomicObj1 &= 1;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 0);

		atomicObj1 |= 0xff;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 0xff);

		atomicObj1 &= 0xf0;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 0xf0);

		atomicObj1 ^= 0x0f;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 0xff);

		atomicObj1 ^= atomicObj1;
		UTF_CHECK(static_cast<UInt32>(atomicObj1) == 0x0);

		atomicObj1 = atomicObj0;
		UTF_CHECK(atomicObj1 == atomicObj0);

		atomicObj0 = 101;
		UTF_CHECK(atomicObj1 != atomicObj0);

		atomicObj0.CompareExchange(101,0);
		UTF_CHECK(atomicObj0 == 0);
	
		atomicObj0 += 101;
		UTF_CHECK(atomicObj0 == 101);
		atomicObj0 -= 101;
		UTF_CHECK(atomicObj0 == 0);	
	}
	END_UNITTEST

	// Test all boundary cases
	BEGIN_UNITTEST(AtomicPtrClassTest)
	{
		TestInt test0(0);
		TestInt test1(1);
		TestInt test11(11);

		AtomicPointer<TestInt> atomicObj0;
		atomicObj0 = &test0;

		const AtomicPointer<TestInt> constAtomicObj0(atomicObj0);
		const AtomicPointer<TestInt> constAtomicObj00(&test0);
		const AtomicPointer<TestInt> constAtomicObj11(&test11);
		UTF_CHECK(constAtomicObj00 == constAtomicObj0);
		UTF_CHECK(constAtomicObj00 != constAtomicObj11);

		AtomicPointer<TestInt> atomicObj11(&test11);
		AtomicPointer<TestInt> atomicObj1(&test1);
		AtomicPointer<TestInt> atomicObj1_1 = atomicObj1;
		
		const TestInt *t0 = constAtomicObj0;
		TestInt *t1 = atomicObj1;

		UTF_CHECK(t0->mValue == 0 && t1->mValue == 1);

		UTF_CHECK(atomicObj1 != atomicObj11);
		UTF_CHECK(atomicObj1 == atomicObj1);
		
		UTF_CHECK(atomicObj1 == &test1);
		UTF_CHECK(atomicObj1->mValue == 1);

		atomicObj1 = &test11;
		atomicObj1_1 = atomicObj1;
		
		UTF_CHECK(atomicObj1_1 == atomicObj1_1);
		UTF_CHECK(atomicObj1_1->mValue != 1);
		UTF_CHECK(atomicObj1_1->mValue == 11);
		UTF_CHECK(constAtomicObj0->mValue == 0);

		atomicObj1.CompareExchange(&test11, &test0);
		UTF_CHECK(atomicObj1 == &test0);
	}
	END_UNITTEST
}
END_UNITTESTGROUP( ThreadAtomicTestGroup )

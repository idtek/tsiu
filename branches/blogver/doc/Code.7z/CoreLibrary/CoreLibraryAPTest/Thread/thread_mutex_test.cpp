#include <UnitTesting.h>
#include <thread/thread.h>
#include <thread/mutex.h>
#include <core/time.h>

using namespace Axiom;

///////////////////////////////////////////////////////////////////////////////////////////////
// MACROS AND CONST
///////////////////////////////////////////////////////////////////////////////////////////////

static const int 	NUM_THREAD_SPAWN = 2; //20;
static const float 	FAILURE_TIMER_THRESHOLD = 100.0f;

// Wait on this mutexed flag and if it passes the threshold time, then the test fails!!
#define WAIT_FOR_WAKE( checkFlag, sleepAmount)											\
{																						\
	Timer timer; timer.Start();															\
	while(timer.GetTime().AsFloatInSeconds() <FAILURE_TIMER_THRESHOLD && !checkFlag )	\
	{																					\
		Thread::Sleep(sleepAmount);														\
	}																					\
	UTF_CHECK(timer.GetTime().AsFloatInSeconds() <FAILURE_TIMER_THRESHOLD)				\
}


///////////////////////////////////////////////////////////////////////////////////////////////
// Buffer to allow us to do mutex testing with threads
///////////////////////////////////////////////////////////////////////////////////////////////
class ThreadSafeBuffer
{
	public:
		ThreadSafeBuffer()
		{
			Axiom::MemorySet(mFlagBuffer,0, sizeof(bool)*NUM_THREAD_SPAWN);
		}

		void SetFlag(int index, bool flag)
		{
			UTF_CHECK(index >=0 && index < NUM_THREAD_SPAWN);
			mLock.Lock();
			mFlagBuffer[index] = flag;
			mLock.Unlock();
		}

		bool GetFlag(int index)
		{
			mLock.Lock();
			bool flag = mFlagBuffer[index];
			mLock.Unlock();

			return flag;
		}

		bool IsAllFlagSetTo(bool b)
		{			
			for(int i=0;i<NUM_THREAD_SPAWN;i++)
			{
				if(GetFlag(i)!=b)
				{
					return false;
				}
			}
			return true;
		}

		void SetAllFlagSetTo(bool b)
		{			
			for(int i=0;i<NUM_THREAD_SPAWN;i++)
			{
				SetFlag(i,b);
			}
		}

		void Lock()
		{
			mLock.Lock();
		}

		void UnLock()
		{
			mLock.Unlock();
		}
	private:
		Thread::Mutex	mLock;
		bool			mFlagBuffer[NUM_THREAD_SPAWN];
};


///////////////////////////////////////////////////////////////////////////////////////////////
// Global variables
///////////////////////////////////////////////////////////////////////////////////////////////
ThreadSafeBuffer		sCheckInitBeginFlags;
ThreadSafeBuffer		sCheckInitEndFlags;
ThreadSafeBuffer		sCheckUpdateBeginFlags;
ThreadSafeBuffer		sCheckUpdateEndFlags;
ThreadSafeBuffer		sCheckDoneEndFlags;

Thread::ThreadId		sThreadIds[NUM_THREAD_SPAWN];
Thread::Mutex			sThreadIdMutex;

int						sCounter = 0;


///////////////////////////////////////////////////////////////////////////////////////////////
// Thread main implementation
///////////////////////////////////////////////////////////////////////////////////////////////
// Test blocking mutex with multiple thread access
void Thread_Main_Blocking( Thread::ThreadParam threadParam )
{
	int flagIndexId = (int) threadParam;

	Thread::Sleep(1);

	sThreadIdMutex.Lock();
	UTF_CHECK(sThreadIds[flagIndexId] == Thread::GetThreadId());
	sThreadIdMutex.Unlock();
	UTF_CHECK(sCheckUpdateBeginFlags.GetFlag(flagIndexId) == false);

	// Spin wait for init flag before init with sleep yield
	WAIT_FOR_WAKE(sCheckInitBeginFlags.GetFlag(flagIndexId), 100)
	sCheckInitEndFlags.SetFlag(flagIndexId, true);

	Thread::Sleep(300);

	// Spin wait for Update Begin with lots of sleeps!
	WAIT_FOR_WAKE(sCheckUpdateBeginFlags.GetFlag(flagIndexId), 100)
	sCheckUpdateEndFlags.SetFlag(flagIndexId, true);

	Thread::Sleep(300);
	sCheckDoneEndFlags.SetFlag(flagIndexId,true);
}

// Test non-blocking mutexes
void Thread_Main_NonBlocking( Thread::ThreadParam threadParam)
{
	Thread::Mutex *pLock = (Thread::Mutex *)threadParam;

	int numInc = 0;
	while(numInc<100)
	{
		Thread::Sleep(10);
		if(pLock->TryLock())
		{
			sCounter++;
			numInc++;
			pLock->Unlock();
		}
		Thread::Sleep(10);
	}
}

BEGIN_UNITTESTGROUP( ThreadMutexTestGroup )
{
	// Test BLOCKING mutex with threads
	BEGIN_UNITTEST(ThreadMutexBlockingFunctionalTest)
	{
		sThreadIdMutex.Lock();
		for(int i =0; i <NUM_THREAD_SPAWN; i++)
		{
			sThreadIds[i] = Thread::CreateThread(Thread_Main_Blocking, reinterpret_cast<Thread::ThreadParam>(i), Thread::TP_NORMAL, 0, "BLOCKING_MUTEX_THREAD");		
		}
		sThreadIdMutex.Unlock();

		// ADVANCE TO START: Get Thread to initialize
		sCheckInitBeginFlags.SetAllFlagSetTo(true);

		// CHECK INIT DONE: Waiting for all thread to be fully initialized
		WAIT_FOR_WAKE(sCheckInitEndFlags.IsAllFlagSetTo(true), 100);
		UTF_CHECK(sCheckInitEndFlags.IsAllFlagSetTo(true) && sCheckInitBeginFlags.IsAllFlagSetTo(true));
		
		Thread::Sleep(0);
		// ADVANCE TO UPDATE: Get Thread to update step
		sCheckUpdateBeginFlags.SetAllFlagSetTo(true);
		
		Thread::Sleep(0);
		// CHECK UPDATE DONE: Waiting for all thread to be fully done with update step
		WAIT_FOR_WAKE(sCheckUpdateEndFlags.IsAllFlagSetTo(true), 100);
		UTF_CHECK(sCheckUpdateEndFlags.IsAllFlagSetTo(true));

		Thread::Sleep(0);
		// CHECK THREAD EXIT DONE: Waiting for all thread to be fully done and exited
		WAIT_FOR_WAKE(sCheckDoneEndFlags.IsAllFlagSetTo(true), 100);

		// Ensure all threads have finished
		UTF_CHECK(sCheckDoneEndFlags.IsAllFlagSetTo(true));
	}	
	END_UNITTEST

	// Test NON-BLOCKING mutex with threads
	BEGIN_UNITTEST(ThreadMutexNonBlockingFunctionalTest)
	{
		sCounter = 0;

		Thread::Mutex noBlockLock;
		// Check if sleep yields the correct amount of time
		Timer timer;
		timer.Start();
		Thread::Sleep(1000);
		float elapseTime = timer.GetTime().AsFloatInSeconds();
		UTF_CHECK(elapseTime>=0.8f && elapseTime <= 1.2f);

		timer.Start();
		Thread::Sleep(2000);
		elapseTime = timer.GetTime().AsFloatInSeconds();
		UTF_CHECK(elapseTime >=1.8f && elapseTime <= 2.2f);

		timer.Start();
		Thread::Sleep(0);
		elapseTime = timer.GetTime().AsFloatInSeconds();
		UTF_CHECK(elapseTime >=0.f && elapseTime <=0.2f);
		
		// Test non-blocking thread with mutexes and ensure it returns correctly!!
		Thread::CreateThread(Thread_Main_NonBlocking,(Thread::ThreadParam)&noBlockLock,Thread::TP_NORMAL,0,"NON_BLOCKING_MUTEX_THREADS");
		
		int numInc = 0;
		const float FAIL_TEST_TIME = 30.f;
		timer.Start();
		
		while(timer.GetTime().AsFloatInSeconds() < FAIL_TEST_TIME  && sCounter<200)
		{
			if(numInc<100)
			{
				noBlockLock.Lock();
				sCounter++;
				numInc++;
				noBlockLock.Unlock();
			}
			Thread::Sleep(10);
		}
		elapseTime = timer.GetTime().AsFloatInSeconds();
		UTF_CHECK(elapseTime <FAIL_TEST_TIME);
		UTF_CHECK(sCounter == 200);
	}	
	END_UNITTEST
}
END_UNITTESTGROUP( ThreadMutexTestGroup )

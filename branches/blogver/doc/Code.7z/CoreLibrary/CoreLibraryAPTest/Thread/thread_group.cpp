//====================================================================
//
//!	@file 	thread_group.cpp
//!	@brief	Master group for Thread unit tests
//
//	created:	
//	author:		duongh
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include "unittesting.h"

// Declare all test
DECLARE_UNITTESTGROUP(ThreadAtomicTestGroup)
DECLARE_UNITTESTGROUP(ThreadMutexTestGroup)

// Declare Groups
BEGIN_UNITTESTGROUP(ThreadGroup)
{
RUN_UNITTESTSUBGROUP(ThreadAtomicTestGroup)
RUN_UNITTESTSUBGROUP(ThreadMutexTestGroup)
}
END_UNITTESTGROUP(ThreadGroup)


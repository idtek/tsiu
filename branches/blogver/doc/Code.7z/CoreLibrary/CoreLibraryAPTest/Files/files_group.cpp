//====================================================================
//
//!	@file 	files_group.cpp
//!	@brief	Master group for Files unit tests
//
//	created:	
//	author:		duongh
//
//	Copyright (c) 2007 by Action Pants Inc
//====================================================================
#include "unittesting.h"

// Declare all test
DECLARE_UNITTESTGROUP(FileManagerGroup)

// Declare Groups
BEGIN_UNITTESTGROUP(FilesGroup)
{
RUN_UNITTESTSUBGROUP(FileManagerGroup)
}
END_UNITTESTGROUP(FilesGroup)


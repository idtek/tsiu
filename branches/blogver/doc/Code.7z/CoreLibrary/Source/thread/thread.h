//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Lib:   Core Library
// Desc:  Functions to deal with threading: creating, exiting, sleep etc.
//--------------------------------------------------------------------------
#ifndef _THREAD_H
#define _THREAD_H

namespace Axiom
{
	namespace Thread
	{
		//--------------------------------------------------------------------------
		enum ThreadPriority
		{
			TP_HIGH				=	0,
			TP_NORMAL			=	1,
			TP_LOW				=	2,
            TP_KERNEL_SIMULATION = 3,
            TP_KERNEL_PRESENTATION = 4,
			TP_FORCE_32_BITS	=	0x7FFFFFFF
		};

		typedef void			(*ThreadFunction)(void*);
		typedef void*			ThreadParam;
		typedef UInt64			ThreadId;

		//--------------------------------------------------------------------------
		const ThreadId			AP_INVALID_THREADID = 0;

		
		ThreadId				GetThreadId();														//!< Get thread id for current thread.
		void					Sleep(unsigned int millisecond);									//!< Suspends the execution of the current thread for at least the specified interval.
		void					Yield();															//!< Suspends the execution of the current thread letting the next thread in queue have a go.
		void					SetCurrentThreadPriority(ThreadPriority priority);					//!< priority 

		ThreadId				CreateThread(	ThreadFunction fn, 
												void* param, 
												ThreadPriority priority,
												int processorIndex=0,								// XBOX360[0..5] PS3[0] WII[0]
												char* szThreadName="MAIN");							//!< Creates a thread to execute given the hwThread(XBOX360[0,1] PS3[0]) and processor(XBOX360[0,1,2] PS3[0]) id.  Execution starts immediately.  Priority ranges from 0 to 100 where 0 is the highest.

	} //namespace Thread
} //namespace AP

#endif //_THREAD_H

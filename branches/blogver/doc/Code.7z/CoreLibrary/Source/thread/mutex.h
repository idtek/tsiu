//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Lib:   Core Library
// Class: Mutex
// Desc:  A mutex is used to protect data accessible by multiple threads,
//        allowing only one thread to manipulate the data at any one time 
//        via the Lock method.
//
//		 example #1
//        void MyObjectUsedInMultipleThreads::ThreadSafeFunction()
//		  {
//            m_Mutex.Lock(); // Make function thread safe
//            m_OtherData.Change(); // Change the object level data
//            m_Mutex.Unlock(); // We've finished. Allow other threads to proceed
//        }
//
//		 example #2
//        void ThreadSafeFunction()
//		  {
//            static Mutex sMutex
//			  sMutex.Lock(); // Make function thread safe
//            m_OtherData.Change(); // Change the object level data
//            m_Mutex.Unlock(); // We've finished. Allow other threads to proceed
//        }
//--------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		Thread\mutex.h
//! @brief		API for thread mutex locking and unlocking
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------
#ifndef __CORE_MUTEX_H
#define __CORE_MUTEX_H

#include "core/system.h"

#if CORE_WIN32
#	include "winbase.h"
#elif CORE_PS3
#	include <sys/synchronization.h>
#elif CORE_WII
#	include <revolution/os/OSMutex.h>
#endif

namespace Axiom
{
namespace Thread
{

//---------------------------------------------------------------------------------------------------------------------------------
//! @class	Mutex
//! @brief	API for thread mutex locking and unlocking 
//!
//! A mutex is used to protect data or code section from being accessed by multiple threads,
//! allowing only one thread to manipulate the data at any one time 
//---------------------------------------------------------------------------------------------------------------------------------
class Mutex
{
public:
				Mutex();
				~Mutex();

	void		Lock();								//!< Lock the mutex and block other thread accessing the section of code or data after the the lock
	bool		TryLock();							//!< Try locking the mutex if it is not locked, but return false if not successful

	void		Unlock();							//!< Unlock the mutex so other threads can access the secion of code or data after the unlock

private:
	bool		IsInitialized() const;				//!< Is the mutex initialized

private:

	// Data members
#	if CORE_WIN_BASED_OS
	CRITICAL_SECTION	m_Mutex;					//!< System level mutex object
#	elif CORE_PS3
	sys_mutex_t			m_Mutex;					//!< System level mutex object
#	elif CORE_WII
	OSMutex				m_Mutex;
#	endif //CORE_PS3
};

//-----------------------------------------------------------------------------------------
//! @class	MockMutex
//! @brief	API for thread mutex locking and unlocking that does nothing
//!
//-----------------------------------------------------------------------------------------

typedef class MockMutex
{
public:
   MockMutex(){}
   ~MockMutex(){}

   //Obtains exclusive ownership of the mutex (empty)
   void Lock(){}

   //Will attempt to obtain exclusive ownership of
   //the mutex (always succeeds)
   bool TryLock(){  return true;  }

   //Will release exclusive ownership of the mutex (empty)
   void Unlock() {}
private:
//Non-copyable
   MockMutex(const MockMutex &m);
   //Non-assignable
   MockMutex &operator=(const MockMutex &m);
}
MockMutex, NullMutex, NonFunctionalMutex;

//-----------------------------------------------------------------------------------------
//! @class	ScopedLock
//! @brief	API for thread mutex locking and unlocking that auto-unlocks.
//!
//-----------------------------------------------------------------------------------------

template <typename MutexType = Mutex>
class ScopedLock
{
public:
   //Constructs the ScopedLock and locks the mutex using lock()
   explicit ScopedLock(MutexType& m)
      : m_mutex(&m), m_locked(false)
   {  
	   m_mutex->Lock();   
	   m_locked = true;  
   }


   //Destroys the ScopedLock. If the mutex was not released and
   //the mutex is locked, unlocks it using unlock() function
   ~ScopedLock()
   {
	  if(m_locked && m_mutex)   
		m_mutex->Unlock();  
   }

//protected:// left for reference
   //Locks the mutex using. If it was locked throws an exception
   void Lock()
   {  
      if(!m_mutex || m_locked)
		return;

      m_mutex->Lock();
      m_locked = true;
   }

   //Unlock the mutex. If it was already unlocked throw an exception
   void Unlock()
   {
      if(!m_mutex || !m_locked)
         return;

      m_mutex->Unlock();
      m_locked = false;
   }
private:
   //Non-copyable
   ScopedLock(ScopedLock const&);
   //Non-assignable
   ScopedLock& operator=  (ScopedLock const&);

private:
   MutexType *	m_mutex; 
   bool			m_locked;
};

} //namespace Thread
} //namespace Axiom

#endif //__CORE_MUTEX_H

//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		Thread\atomic.h
//! @brief		API for atomic read and write 
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------

#ifndef __CORE_ATOMIC_H
#define __CORE_ATOMIC_H

#include "core/cmn.h"

//---------------------------------------------------------------------------------------------------------------------------------
//!	@namespace	Axiom::Thread
//!	@brief		An API to atomically read and write in a thread safe manner
//!
//! Atomic functions used to create lock free thread safe code 
//---------------------------------------------------------------------------------------------------------------------------------	

namespace Axiom
{
namespace Thread
{
	//! Performs a logical AND operation between what the target points to and the value.  The result is stored in target and returned
	AP_INLINE UInt32 AtomicAnd(UInt32 volatile *target, UInt32 value);				

	//! Performs a logical OR operation between what the target points to and the value.  The result is stored in target and returned
	AP_INLINE UInt32 AtomicOr(UInt32 volatile *target, UInt32 value);

	//! Performs a logical XOR operation between what the target points to and the value. The result is stored in target and returned
	AP_INLINE UInt32 AtomicXor(UInt32 volatile *target, UInt32 value);

	//! Increments what the target points to by 1.	The result is stored in target and returned
	AP_INLINE UInt32 AtomicIncrement(UInt32* target);

	//! Decrements what the target points to by 1.	The result is stored in target and returned
	AP_INLINE UInt32 AtomicDecrement(UInt32* target);

	//! Returns the value stored in target	The value returned is what is stored in target
	AP_INLINE UInt32 AtomicRead(UInt32* target);

	//! Returns the pointer value stored in the target pointer	The pointer value returned is what is stored in the target pointer
	AP_INLINE void* AtomicReadPointer(void** target);

	//! Sets the target pointer to the value 	Returns the previous value of the target pointer, the target pointer stores the new value
	AP_INLINE UInt32 AtomicExchange(UInt32* target, UInt32 value);

	//! Sets the target pointer to the value 	Returns the previous value of the target pointer, the target pointer stores the new value
	AP_INLINE void* AtomicExchangePointer(void** target, void* value);

	//! Sets the target pointer to the sum of the value and target pointer.  Returns the previous value of the target pointer, the target pointer stores sum of the pointer and value
	AP_INLINE UInt32 AtomicExchangeAdd(UInt32* target, UInt32 value);

	//! Sets the target pointer to the difference of the target pointer and value.	Returns the previous value of the target pointer, the target pointer stores the difference of the target pointer and value
	AP_INLINE UInt32 AtomicExchangeSubtract(UInt32* target, UInt32 value);

	//! Sets the target pointer to the value only if the target pointer is equivalent to equalTo.  Returns the previous value of the target pointer, the target pointer stores the new value if the target pointer is equivalent to equalTo
	AP_INLINE UInt32 AtomicCompareExchange(UInt32* target, UInt32 value, UInt32 equalTo);

	//! Sets the target pointer to the value only if the target pointer is equivalent to equalTo.  Returns the previous value of the target pointer, the target pointer stores the new value if the target pointer is equivalent to equalTo
	AP_INLINE void* AtomicCompareExchangePointer(void** target, void* value, void* equalTo);

	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		Atomic
	//!	@brief		An API to create atomic thread safe object
	//!
	//! This class should really be more specialized for different types.  In it's current ints and uints will function, however, floats 
	//!	would not function for all operations (decrement and increment for example).
	//---------------------------------------------------------------------------------------------------------------------------------	
	template<typename T>
	class Atomic
	{
	public:
					Atomic();
					Atomic(const T& value);
					Atomic(const Atomic<T>& value);
					
					operator T();											//!< AtomicRead
					operator const T() const;								//!< AtomicRead

		Atomic<T>&	operator ++();											//!< AtomicIncrement
		Atomic<T>&	operator --();											//!< AtomicDecrement

		Atomic<T>&	operator &=(const T& _and);								//!< AtomicAnd
		Atomic<T>&	operator |=(const T& _or);								//!< AtomicOr
		Atomic<T>&	operator ^=(const T& _xor);								//!< AtomicXor

		Atomic<T>&	operator +=(const T& increment);						//!< AtomicExchangeAdd
		Atomic<T>&	operator -=(const T& decrement);						//!< AtomicExchangeSubtract

		Atomic<T>&	operator =(const Atomic<T>& value);						//!< AtomicExchange
		Atomic<T>&	operator =(const T& value);								//!< AtomicExchange

		const bool	operator ==(const Atomic<T>& value) const;				//!< AtomicRead
		const bool	operator !=(const Atomic<T>& value) const;				//!< AtomicRead
		const bool	operator ==(const T& value) const;						//!< AtomicRead
		const bool	operator !=(const T& value) const;						//!< AtomicRead

		Atomic<T>&	CompareExchange(const T& equal, const T& value);		//!< AtomicCompareExchange

	protected:
		static AP::CompileTimeError<sizeof(UInt32) == sizeof(T)> err;		//!< The atomic type must be a 32 bit wide value!
		mutable T mValue;													//!< This must be a 32 bit type
	};

	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		AtomicPointer
	//!	@brief		An API to create atomic thread safe pointer to a piece of memory
	//!
	//! This is a simple object wrapper to implement thread safe pointer access across multiple threads
	//---------------------------------------------------------------------------------------------------------------------------------	
	template<typename T>
	class AtomicPointer
	{
	public:
							AtomicPointer();
							AtomicPointer(T* const pointee);
							AtomicPointer(const AtomicPointer<T>& pointee);

		AtomicPointer<T>&	operator=(const AtomicPointer<T>& pointee);			//!< Atomic equal operator for pointer
		AtomicPointer<T>&	operator=(T* const pointee);						//!< Atomically equal operator for a dereferenced pointer

		T*					operator->();										//!< Atomic accessing the pointer members
		const T*			operator->() const;									//!< Atomic accessing the pointer members

							operator T*();										//!< Atomic pointer dereferencing
							operator const T*() const;							//!< Atomic pointer dereferencing


		const bool			operator==(const AtomicPointer<T>& pointee) const;	//!< Atomically compare if the given pointer is same as current pointer in class object
		const bool			operator!=(const AtomicPointer<T>& pointee) const;	//!< Atomically check if the given pointer is not equal to the current pointer in class object
		const bool			operator==(T* const pointee) const;					//!< Atomically compare if the given pointer is same as current pointer in class object
		const bool			operator!=(T* const pointee) const;					//!< Atomically check if the given pointer is not equal to the current pointer in class object

		AtomicPointer<T>&	CompareExchange(T* const equalTo, T* const value);	//!< Compare and exchange the given pointer with the current pointer in class object

		// AtomicPointer<T>& operator+=(const uint offset); // Increment by sizeof(T)
		// AtomicPointer<T>& operator-=(const uint offset); // Decrement by sizeof(T)

	private:

		mutable void*				mPointee;									//!< The currently stored pointer that needs to be atomic
	};

} // namespace Thread

} // namespace Axiom
#include "thread/source/atomic.inl"

#endif // __CORE_ATOMIC_H

//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Lib:   Core Library
// Class: Mutex
// Desc:  A mutex is used to protect data accessible by multiple threads,
//        allowing only one thread to manipulate the data at any one time 
//        via the Lock method.
//--------------------------------------------------------------------------
#include "core/system.h"
#include "thread/mutex.h"

#if CORE_PS3
#include <sys/ppu_thread.h>
#include <sys/synchronization.h>
#elif CORE_WIN_BASED_OS
#elif CORE_WII
#endif 

namespace Axiom
{
namespace Thread
{

//--------------------------------------------------------------------------
// PS3 Implementation of Mutex class
#if CORE_PS3

Mutex::Mutex()
{
	sys_mutex_attribute_t mutex_attr;
	sys_mutex_attribute_initialize(mutex_attr);
	mutex_attr.attr_adaptive = SYS_SYNC_ADAPTIVE;
	mutex_attr.attr_protocol = SYS_SYNC_FIFO;
	mutex_attr.attr_recursive = SYS_SYNC_RECURSIVE;
	int ret = sys_mutex_create(&m_Mutex, &mutex_attr);

	if(ret != CELL_OK)
	{
		AP_ASSERTMESSAGE(ret == CELL_OK, "ERROR: Mutex not create properly!");
		sys_ppu_thread_exit(ret);
	}

	AP_POSTCONDITION( IsInitialized() );
}

Mutex::~Mutex()
{
	AP_PRECONDITION( IsInitialized() );
	int ret = sys_mutex_destroy(m_Mutex);

	if(ret!= CELL_OK)
	{
		AP_ASSERTMESSAGE(ret == CELL_OK, "ERROR: Unable to lock mutex!");
		sys_ppu_thread_exit(ret);
	}
}

void Mutex::Lock()
{
	AP_PRECONDITION( IsInitialized() );
	int ret = sys_mutex_lock(m_Mutex,0);

	if(ret!= CELL_OK)
	{
		AP_ASSERTMESSAGE(ret == CELL_OK, "ERROR: Unable to lock mutex!");
		sys_ppu_thread_exit(ret);
	}
}

bool Mutex::TryLock()
{
	AP_PRECONDITION( IsInitialized() );
	return (sys_mutex_trylock(m_Mutex) == CELL_OK);
}

void Mutex::Unlock()
{
	AP_PRECONDITION( IsInitialized() );
	int ret = sys_mutex_unlock(m_Mutex);
	AP_ASSERT(ret == CELL_OK);

}

bool Mutex::IsInitialized() const
{
	// Due to use of static mutex objects in code this function should
	// help find problems whereby a function is called on an uninitialised mutex.
	AP_ASSERT( this != NULL ); // A general isPointerValid check would be better
	return m_Mutex != 0;
}

//--------------------------------------------------------------------------
// Windows based implementation of Mutex class
#elif CORE_WIN_BASED_OS

Mutex::Mutex()
{
	InitializeCriticalSection(&m_Mutex);

	AP_POSTCONDITION( IsInitialized() );
}

Mutex::~Mutex()
{
	AP_PRECONDITION( IsInitialized() );
	DeleteCriticalSection(&m_Mutex);
}

void Mutex::Lock()
{
	AP_PRECONDITION( IsInitialized() );
	EnterCriticalSection(&m_Mutex);
}

bool Mutex::TryLock()
{
	AP_PRECONDITION( IsInitialized() );
	return TryEnterCriticalSection(&m_Mutex) != 0;
}

void Mutex::Unlock()
{
	AP_PRECONDITION( IsInitialized() );
	LeaveCriticalSection(&m_Mutex);
}

bool Mutex::IsInitialized() const
{
	// Due to use of static mutex objects in code this function should
	// help find problems whereby a function is called on an uninitialised mutex.
	AP_ASSERT( this != NULL ); // A general isPointerValid check would be better
#	if CORE_WIN32
	return m_Mutex.DebugInfo != NULL;
#	else //!CORE_WIN32
	return true; // Is there any way to tell if a CRITICAL_SECTION on X360 is initialised?
#	endif //!CORE_WIN32
}

//--------------------------------------------------------------------------
#elif CORE_WII
Mutex::Mutex()
{
	OSInitMutex(&m_Mutex);

	AP_POSTCONDITION( IsInitialized() );
}

Mutex::~Mutex()
{
	AP_PRECONDITION( IsInitialized() );
}

void Mutex::Lock()
{
	AP_PRECONDITION( IsInitialized() );
	OSLockMutex(&m_Mutex);
}

bool Mutex::TryLock()
{
	AP_PRECONDITION( IsInitialized() );
	return OSTryLockMutex(&m_Mutex) != 0;
}

void Mutex::Unlock()
{
	AP_PRECONDITION( IsInitialized() );
	OSUnlockMutex(&m_Mutex);
}

bool Mutex::IsInitialized() const
{
	// Due to use of static mutex objects in code this function should
	// help find problems whereby a function is called on an uninitialised mutex.
	AP_ASSERT( this != NULL ); // A general isPointerValid check would be better
#	if CORE_WIN32
	return m_Mutex.DebugInfo != NULL;
#	else //!CORE_WIN32
	return true; // Is there any way to tell if a CRITICAL_SECTION on X360 is initialised?
#	endif //!CORE_WIN32
}

//--------------------------------------------------------------------------
#else //Platform undefined
#	error Please implement Mutex class for this platform
#endif

} //namespace Thread
} //namespace AP

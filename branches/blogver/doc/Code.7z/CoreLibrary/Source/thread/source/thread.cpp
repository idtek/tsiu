//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Lib:   Core Library
// Class: Thread
// Desc:  A Thread is an independent execution function 
//--------------------------------------------------------------------------

#if CORE_PS3
#include <sys/timer.h>
#include <sys/ppu_thread.h>
#include <core/datapool.h>
#elif CORE_WII
#include <core/datapool.h>
#include <revolution/os/osthread.h>
#endif

#include "core/system.h"
#include "thread/thread.h"

namespace Axiom
{
	namespace Thread
	{
		namespace 
		{
			static const int MAX_THREADS = 2;
#if CORE_PS3
			struct PS3Thread
			{
				Axiom::ShortString name;
				ThreadFunction fn; // thread function
				ThreadParam user;

				static void ThreadMain(uint64_t user);
			};
			static Axiom::DataPool<sizeof(PS3Thread), MAX_THREADS> sThreadPool;
			static int sThreadPriorities[] = 
			{
				0,			// TP_HIGH		= 0
				500,		// TP_NORMAL	= 1
				1500,		// TP_LOW		= 2
                1000,       // TP_KERNEL_SIMULATION = 3
                1001,       // TP_KERNEL_PRESENTATION = 4

			};
			void PS3Thread::ThreadMain(uint64_t user)
			{
				PS3Thread* data = reinterpret_cast<PS3Thread*>(user);
				PS3Thread thread = *data; // copy the thread data so we can release the pool resource
				sThreadPool.Release(data);

				(*thread.fn)(thread.user);
			}

#elif CORE_WII
			struct WiiThread : public OSThread
			{
#if CORE_FINAL == CORE_YES
				static const int DEFAULT_STACK_SIZE = 256*1024;//128*1024; // MO reduced from 512*1024;
#else
				static const int DEFAULT_STACK_SIZE = 256*1024; // (chrisg) increase stack size for debug for now (StEdFast used a bunch of debug stack variables and is overflowing);
#endif
				static void* ThreadMain(void* param);
				
				void (*fn)(ThreadParam); // thread function
				ThreadParam user;
				Axiom::ShortString name;
			    Axiom::Byte* pThreadStack;
			};
			static Axiom::DataPool<sizeof(WiiThread), MAX_THREADS> sThreadPool;
			void* WiiThread::ThreadMain(void* param)
			{
				WiiThread* data = reinterpret_cast<WiiThread*>(param);
				(*data->fn)(data->user);
				sThreadPool.Release(data); // Review(danc): Warning this memory is still in use until the thread exits completely
				return 0;
			}
			static OSPriority sThreadPriorities[] = 
			{
				0,		// TP_HIGH		= 0
				16,		// TP_NORMAL	= 1
				31,		// TP_LOW		= 2
			};
#elif CORE_WIN_BASED_OS
			static const int DEFAULT_STACK_SIZE = 512*1024;
			static int sThreadPriorities[] = 
			{
				THREAD_PRIORITY_HIGHEST,	// TP_HIGH		= 0
				THREAD_PRIORITY_NORMAL,		// TP_NORMAL	= 1
				THREAD_PRIORITY_LOWEST,		// TP_LOW		= 2
			};
#endif
		} // anonymous namespace

		ThreadId GetThreadId()
		{
#if CORE_WIN_BASED_OS
			return static_cast<ThreadId>(GetCurrentThreadId());
#elif CORE_PS3
			sys_ppu_thread_t threadId;
			int result = sys_ppu_thread_get_id(&threadId);

			AP_ASSERTMESSAGE(result == CELL_OK, "Can't get the thread ID!!  Invalid thread Id address specified!");
			return static_cast<ThreadId>(threadId);
#elif CORE_WII
			return reinterpret_cast<ThreadId>(OSGetCurrentThread());
#else
#error "NO IMPLEMENTATION!!";
#endif
		}

		void Sleep(unsigned int millisecond)
		{
#if CORE_WIN_BASED_OS
			::Sleep(millisecond);
#elif CORE_WII
			if(millisecond==0) // If 0, then yield right away!!
			{
				Yield();
			}
			else
			{
				OSSleepMilliseconds(millisecond);
			}
#elif CORE_PS3
			if(millisecond==0) // If 0, then yield right away!!
			{
				Yield();
			}
			else
			{
				sys_timer_usleep(millisecond*1000);
			}
#else
#error "NO IMPLEMENTATION!!";
#endif
		}

		void Yield() // We don't call this function Yield() because Microsoft has defined a macro that evaluates Yield() to nothingness
		{
#if CORE_WIN_BASED_OS
			::Sleep(0);
#elif CORE_WII
			OSYieldThread();
#elif CORE_PS3
			sys_ppu_thread_yield();
#else
#error "NO IMPLEMENTATION!!";
#endif
		}

		ThreadId CreateThread(ThreadFunction fn, void* param, ThreadPriority priority, int processorIndex, char* szThreadName)
		{
			AP_ASSERT( priority >= 0 && priority <= 100 );

			AP_ASSERT( szThreadName != NULL && fn != NULL );
#if CORE_WIN32 
			AP_FORCEASSERT( processorIndex==0, "Unknown thread id" );
			DWORD dwThreadId;
			AP_ASSERT_SUPPORTASSIGN(HANDLE h, ::CreateThread(0,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(*fn),param,0,&dwThreadId));
			AP_ASSERT(0 != h);
			//SetThreadName(dwThreadId, szThreadName);
			SetCurrentThreadPriority(priority);

			return static_cast<ThreadId>(dwThreadId);;
#elif CORE_XBOX360
			DWORD dwThreadId;
			HANDLE h = ::CreateThread(0,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(*fn),param,0,&dwThreadId);
			AP_ASSERT(0 != h);

			// Switch to the correct processor
			AP_ASSERT(0 <= processorIndex && processorIndex < 6);

			AP_ASSERT_SUPPORTASSIGN(DWORD ret, ::XSetThreadProcessor(h, processorIndex));
			AP_ASSERT(ret>=0);

			SetCurrentThreadPriority(priority);

			//SetThreadName(&dwThreadId, szThreadName);
			::ResumeThread(h);

			return static_cast<ThreadId>(dwThreadId);
#elif CORE_PS3
			(void)processorIndex;
			ThreadId threadId = AP_INVALID_THREADID;
			if (!sThreadPool.IsEmpty())
			{
				PS3Thread* thread = sThreadPool.Create<PS3Thread>();
				thread->fn = fn;
				thread->user = param;
				thread->name = szThreadName;
				int result = sys_ppu_thread_create(	&threadId,
													PS3Thread::ThreadMain,
													reinterpret_cast<uint64_t>(thread),
													sThreadPriorities[priority],
													0x80000,
													SYS_PPU_THREAD_CREATE_JOINABLE,
													szThreadName);

				AP_ASSERT(result == CELL_OK);
			}

			return threadId;
#elif CORE_WII
			(void)processorIndex;
			ThreadId threadId = AP_INVALID_THREADID;
			if (!sThreadPool.IsEmpty())
			{
				AP_FORCEASSERT(processorIndex==0, "Unknown thread id" );
				WiiThread* thread = sThreadPool.Create<WiiThread>(); 
				thread->fn = fn;
				thread->user = param;
				thread->name = szThreadName;

				// allocate thread stack in MEM1
				// MO note: this memory is never explicitly freed - it will be freed when the application exits
		    	thread->pThreadStack = NULL;
				thread->pThreadStack = (Byte*)AP_ALIGNED_ALLOC(Axiom::Memory::THREAD_HEAP, WiiThread::DEFAULT_STACK_SIZE, 32);
		
				AP_ASSERT(thread->pThreadStack);
				const bool result = OSCreateThread(	thread,
									&WiiThread::ThreadMain,
									thread,
									(void*)(thread->pThreadStack + WiiThread::DEFAULT_STACK_SIZE), 
									WiiThread::DEFAULT_STACK_SIZE,
									sThreadPriorities[priority],
									OS_THREAD_ATTR_DETACH );

				//-----------------------------------------------------------------

				AP_ASSERTMESSAGE(result, "Couldn't create thread");
				threadId = reinterpret_cast<ThreadId>(thread);
				
				AP_ASSERT(OSIsThreadSuspended(thread));
#if !CORE_SHIP
				//this should prevent any false positives on the protection error when the stack is flushed.
				DCStoreRange(thread->pThreadStack, WiiThread::DEFAULT_STACK_SIZE);
				
				//Protects the last 1024 bytes of the thread stack
				static int protectNum = 1;  //0 is reserved for the main stack.

			   	unsigned int end_of_stack = (unsigned int)(thread->pThreadStack);

				end_of_stack = (end_of_stack + 1023) & ~1023;  // round up to nearest 1K boundary

				unsigned int bad_start = OSCachedToPhysical(reinterpret_cast<void*>(end_of_stack));

				AP_ASSERT(protectNum < 4);
				OSProtectRange(protectNum, reinterpret_cast<void*>(bad_start), 1024, OS_PROTECT_CONTROL_NONE);
				protectNum++;
#endif   			
				OSResumeThread ( thread );
			}
			return threadId;
#else
#error "NO IMPLEMENTATION"
			return 0;
#endif
		}

		void SetCurrentThreadPriority(ThreadPriority priority)
		{	
#if CORE_PS3
			sys_ppu_thread_set_priority(GetThreadId(), sThreadPriorities[priority]);
#elif CORE_WIN_BASED_OS
			::SetThreadPriority(GetCurrentThread(), sThreadPriorities[priority]);
#elif CORE_WII
			OSSetThreadPriority(OSGetCurrentThread(), sThreadPriorities[priority]);
#else
#	error "NO IMPLEMENTATION"
#endif
		}
	}
}

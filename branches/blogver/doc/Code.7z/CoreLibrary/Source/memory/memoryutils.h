#if !defined( AP_MEMORY_UTILS_H )
#define AP_MEMORY_UTILS_H

#include "memory/apmemory.h"
#include "string/stringbuilder.h"

namespace Axiom
{
	namespace Memory
	{
		static const unsigned int MAX_MEM_DUMP_SIZE			= 3000000;
		static const unsigned int MAX_MEM_HEAP_STR_LENGTH	= MAX_MEM_DUMP_SIZE/4;
		static const unsigned int MAX_MEM_DUMP_LINE_SIZE	= 512;

		typedef Axiom::StringBuilder< MAX_MEM_DUMP_SIZE > MemoryBuffer;

		// Memory debugging api
		AP_API void		MemoryReport();
		AP_API void		MemoryValidate();																			//!< Validate memory to check for memory stomps
		AP_API void		MemoryValidate( Axiom::Memory::HeapId );

		AP_API void		MemDump();																					//!< Dump all memory to console
		AP_API void		MemDump(const HeapId heapId);																//!< Dump one heap to console

		AP_API void		MemDumpToPassedBuffer( MemoryBuffer& buffer );
		AP_API void		MemDumpToPassedBuffer( const HeapId heapId, MemoryBuffer& buffer );

		AP_API void		MemGetHeapInfo( const HeapId heapId, unsigned int& maxSize, unsigned int& memFree );

	}	//namespace Memory
}	//namespace Axiom

#endif //AP_MEMORY_UTILS_H

//------------------------------------------------------------------------------
//
//!  @file apmemory.h
//!	 @brief	API for allocating/destroying memory
//--------------------------------------------------------------------------

#ifndef _APMEMORY_H
#define _APMEMORY_H

#include <stdio.h>

//! Including the right memory configurations to the build
#if CORE_XBOX360 
#	define PLATFORM_MAXALLOC IN_MB(425)
#elif CORE_PS3  // Please do not change the memory size before creating media build.  Media may break!!
#	define PLATFORM_MAXALLOC IN_MB(185)
#elif CORE_WII
#	define PLATFORM_MAXALLOC IN_MB(110)
#elif CORE_WIN32
#	define PLATFORM_MAXALLOC IN_MB(660)
#else
#	error "Unsupported platform"
#endif

#if CORE_XBOX360
#pragma warning(disable:4985)
#endif

//--------------------------------------------------------------------------
#if CORE_TOOLS == CORE_NO
//! New/Delete macros
#	define AP_NEW(heap, obj)						new (heap, __FILE__, __LINE__, true) obj
#	define AP_PLACEMENT_NEW(mem)					new (true, static_cast<void*>(mem))
#	define AP_ALIGNED_NEW(heap, alignment, obj)		new (heap, alignment, __FILE__, __LINE__, true) obj
#	define AP_DELETE(mem)							delete (mem)
#	define AP_DELETEARRAY(mem)						delete [](mem)
#	define AP_DELETEZERO(mem)						delete (mem); mem = NULL
#	define AP_DELETEARRAYZERO(mem)					delete [](mem); mem = NULL
//! Alloc/Free/ReAlloc macros
#	define AP_ALLOC(heap, size)						Axiom::Memory::Alloc(heap, size, __FILE__, __LINE__)
#	define AP_ALIGNED_ALLOC(heap, size, alignment)	Axiom::Memory::Alloc(heap, size, alignment, __FILE__, __LINE__)
#	define AP_REALLOC(heap, mem, size)				Axiom::Memory::ReAlloc(heap, mem, size, __FILE__, __LINE__)
#	define AP_FREE(mem)								Axiom::Memory::Free(mem)
#else
#	include <new>
#	define AP_NEW(heap, obj)						new obj
#	define AP_PLACEMENT_NEW(mem)					new (static_cast<void*>(mem))
#	define AP_ALIGNED_NEW(heap, alignment, obj)		new obj
#	define AP_DELETE(mem)							delete (mem)
#	define AP_DELETEARRAY(mem)						delete [](mem)
#	define AP_DELETEZERO(mem)						delete (mem); mem = NULL
#	define AP_DELETEARRAYZERO(mem)					delete [](mem); mem = NULL
#	define AP_ALLOC(heap, size)						_aligned_malloc(size, 0)
#	define AP_ALIGNED_ALLOC(heap, size, alignment)	_aligned_malloc(size, alignment)
#	define AP_REALLOC(heap, mem, size)				_aligned_realloc(mem, size, 0)
#	define AP_FREE(mem)								_aligned_free(mem)
#endif

//--------------------------------------------------------------------------
//! Alignment macros
#if CORE_WII
#define AP_MEM_DEFAULT_ALIGNED					32
#else 
#define AP_MEM_DEFAULT_ALIGNED					16
#endif

#define AP_MIN_ALIGNED							AP_MEM_DEFAULT_ALIGNED
#define AP_MIN_ALLOC							AP_MEM_DEFAULT_ALIGNED
#define AP_CHECK_ALIGNED_TO(value, alignment)	AP_ASSERT(((static_cast<size_t>(value) % alignment)==0))
#define AP_CHECK_ALIGNED(value)					AP_CHECK_ALIGNED_TO(value, AP_MIN_ALLOC)
#define AP_ALIGN_TO(value, alignment)			(((value + (alignment - 1)) ^ (alignment - 1)) & ~(alignment - 1))
#define AP_ALIGN_VALUE(value)					AP_ALIGN_TO(value, AP_MIN_ALLOC)

//--------------------------------------------------------------------------
//! Misc macros
#define AP_INVALID_HEAPID						HeapId(-1)
#define AP_MAX_NUM_HEAPS						32
#define AP_MEMALLOC_MIN_SIZE					AP_MIN_ALLOC
#define AP_MEMALLOC_MAX_SIZE					2048
#define IN_KB(a)								((a)*1024)
#define IN_MB(a)								(IN_KB(a)*1024)
#define AP_MEM_SMALLBLOCK_DEFAULT_SIZE			(IN_KB(256))

//--------------------------------------------------------------------------
extern bool AP_API g_AllowGlobalAllocations;

//---------------------------------------------------------------------------------------------------------------------------------
//!	@namespace	Axiom::Memory
//!	@brief		API for managing system memory
//!
//! The Memory API is wrapper for system level memory allocation/destruction.  
//---------------------------------------------------------------------------------------------------------------------------------	

//--------------------------------------------------------------------------
namespace Axiom
{
namespace Memory
{
typedef unsigned int Alignment;																				//!< Memory alignment type
typedef int HeapId;																							//!< Heap Id Type

// Todo: This is NOT the right place to define HeapIds, move them to libs that require them. The
// only HeapIds that should be defined here are the ones that Core requires.
extern HeapId AP_API RESERVED_CORE_HEAP;																	//!< Reserved memory heap id
extern HeapId AP_API RESERVED_DEBUG_HEAP;																	//!< Reserved debug memory heap id
extern HeapId AP_API RESERVED_SYSTEMS_HEAP;																	//!< Reserved system memory heap id
extern HeapId AP_API DEFAULT_HEAP;																			//!< Default memory heap id
extern HeapId AP_API ANIM_HEAP;																				//!< Animation memory heap id
extern HeapId AP_API AUDIO_HEAP;																			//!< Audio memory heap id
extern HeapId AP_API RENDER_HEAP;																			//!< Render memory heap id
extern HeapId AP_API SCALEFORM_HEAP;																		//!< Render memory heap id
extern HeapId AP_API THREAD_HEAP;																			//!< thread memory heap id

//TODO.  Sort This out.  At least for now this will work.
#if CORE_WII==CORE_NO
extern 	HeapId AP_API 		PRESENTATION_HEAP;													   			//!< Presentation memory heap id
extern 	HeapId AP_API 		ONLINE_HEAP;																	//!< Online memory heap id
extern 	HeapId AP_API 		INPUTEVENT_HEAP;																//!< Input memory heap id
extern 	HeapId AP_API 		PHYSICS_HEAP;																	//!< Physic memory heap id
extern  HeapId AP_API		AI_HEAP;
#define OVERFLOW_HEAP 		DEFAULT_HEAP
#else
extern 	HeapId AP_API 		OVERFLOW_HEAP;																	//!< Overflow for default heap. In mem2 on wii.
#if !CORE_FINAL
extern HeapId				AP_API RSO_HEAP;																//!< RSO memory heap id
#else
#define RSO_HEAP			DEFAULT_HEAP
#endif
#define	PRESENTATION_HEAP 	DEFAULT_HEAP
#define	ONLINE_HEAP 		DEFAULT_HEAP
#define	INPUTEVENT_HEAP 	DEFAULT_HEAP
#define	PHYSICS_HEAP 		DEFAULT_HEAP
#define	AI_HEAP				DEFAULT_HEAP
#endif

#define HEAPFLAG_USEASGLOBALSBA 	0x01
#define HEAPFLAG_USEALTERNATEMEM	0x02

//--------------------------------------------------------------------------
AP_API void		Init(size_t totalMemSizeInBytes, size_t totalMemSize2InBytes = 0);							//!< This initialises the entire memory - this must be called before any memory can be used

AP_API void		Destroy();																					//!< Destroy the memory manager at shut down.

AP_API HeapId	CreateHeap(char* pHeapName, size_t heapSize, 
						   size_t smallBlockHeapSize = AP_MEM_SMALLBLOCK_DEFAULT_SIZE,
						   int flags = 0,
						   size_t fixedAllocSize = AP_MEMALLOC_MIN_SIZE, 
						   size_t maxFixedAllocs = AP_MEMALLOC_MAX_SIZE, 
						   Thread::ThreadId = Thread::AP_INVALID_THREADID);									//!< Create a heap, specifying name and size (in bytes).
																											//!< Optional: Specify fixed alloc size (in bytes). 
																											//!< Optional: Specify max fixed allocs (in bytes). 
																											//!< Optional: specify a thread id that has access to this heap in order to restrict access to other running threads. 
																											//!< You can specify additional threads that have access to a heap via the SetThreadAllowed api.

AP_API bool		IsEnabled();																				//!< Check to see if memory allocation is allowed.

AP_API void		StartThreadDetection();																		//!< Turn on the thread safety detection

AP_API void		SetThreadAllowed(const Thread::ThreadId, const HeapId);										//!< Allow a thread access to the heap. Accessing a heap that is associated with other threads without first calling this api will cause a runtime assert.

//--------------------------------------------------------------------------
// Allocators api
AP_API void*	ReAlloc(const HeapId, void* ptrToMem, const int newSize, const char* filename, int line);	//!< Reallocate memory to a given heap
AP_API void*	Alloc(const HeapId, const size_t);															//!< Allocate memory to a given heap and size
AP_API void*	Alloc(const HeapId, const size_t, const char* filename, int line);							//!< Allocate memory to a given heap, size, and debug info about file and line number
AP_API void*	Alloc(const HeapId, const size_t, const size_t alignment, const char* filename, int line);	//!< Allocate memory with alignment to a given heap, size, and debug info about file and line number
AP_API void		Free(void*);																				//!< Free memory from memory pool

AP_API bool		IsMemoryInAddressSpace(const void * mem);													//!< Check if memory address is in memory pool range

//--------------------------------------------------------------------------

AP_API size_t	GetHeapStartAddress();																		//!< Get the start heap address
AP_API size_t	GetHeapEndAddress();																		//!< Get the end heap address
AP_API size_t	GetLargestFreeChunkSize(const HeapId);														//!< Get the size of the biggest free chunk
AP_API bool		CanAlloc(const HeapId, const size_t numBytes);												//!< Find out if an alloc() will succeed before calling it

} // namespace Memory
} // namespace AP

#if CORE_TOOLS == CORE_NO

#if CORE_PS3
    #define NOINLINE_ON_PS3 __attribute__((noinline));
#else
    #define NOINLINE_ON_PS3 
#endif

//--------------------------------------------------------------------------
void* operator new(size_t size) AP_THROW NOINLINE_ON_PS3; 
AP_API void* operator new(size_t, void*const) AP_THROW NOINLINE_ON_PS3;
#if CORE_WIN32 == CORE_YES
AP_API void* operator new(size_t, bool, void*const) AP_THROW;
#endif // CORE_WIN32
AP_API void* operator new(size_t, int, const char*, int) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new(size_t, int, size_t, const char*, int) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new(size_t, bool) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new(size_t, const Axiom::Memory::HeapId) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new(size_t, const Axiom::Memory::HeapId, const char* filename, int line, bool) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new(size_t, const Axiom::Memory::HeapId, size_t alignment, const char* filename, int line, bool) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new (size_t , bool, void*const p) AP_THROW NOINLINE_ON_PS3;

//--------------------------------------------------------------------------
AP_API void* operator new[](size_t size) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new[](size_t, bool, void*const) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new[](size_t, const Axiom::Memory::HeapId, const char* filename, int line, bool) AP_THROW NOINLINE_ON_PS3;
AP_API void* operator new[](size_t, const Axiom::Memory::HeapId, size_t alignment, const char* filename, int line, bool) AP_THROW NOINLINE_ON_PS3;

//--------------------------------------------------------------------------
AP_API void operator delete(void*) NOINLINE_ON_PS3;
AP_API void operator delete(void*, void*const) NOINLINE_ON_PS3;
#if CORE_WIN32 == CORE_YES
AP_API void operator delete(void*, bool, void*const); // placement delete?
#endif // CORE_WIN32
AP_API void operator delete(void*, const Axiom::Memory::HeapId, bool) NOINLINE_ON_PS3;
AP_API void operator delete(void*, const Axiom::Memory::HeapId, const char* filename, int line, bool) NOINLINE_ON_PS3;
AP_API void operator delete(void*, const Axiom::Memory::HeapId, size_t alignment, const char* filename, int line, bool) NOINLINE_ON_PS3;

//--------------------------------------------------------------------------
AP_API void operator delete[](void*) NOINLINE_ON_PS3;
#if CORE_WIN32 == CORE_YES
AP_API void operator delete[]( void*const, bool, void*const); // placement delete?
#endif // CORE_WIN32
AP_API void operator delete[](void*, const Axiom::Memory::HeapId, size_t alignment, const char* filename, int line, bool) NOINLINE_ON_PS3;
AP_API void operator delete[](void*, const Axiom::Memory::HeapId, const char* filename, int line, bool) NOINLINE_ON_PS3;

//--------------------------------------------------------------------------
// Avoid conflicts with STL 'new' file header
#ifndef __PLACEMENT_NEW_INLINE
#	define __PLACEMENT_NEW_INLINE
#endif

#ifndef __PLACEMENT_VEC_NEW_INLINE
#	define __PLACEMENT_VEC_NEW_INLINE
#endif

#if CORE_PS3 == CORE_NO
//--------------------------------------------------------------------------
inline void operator delete(void* p)
{
	Axiom::Memory::Free(p);
}

//--------------------------------------------------------------------------
inline void operator delete[](void* p)
{
	Axiom::Memory::Free(p);
}

#if CORE_PLACEMENT_NEW
//--------------------------------------------------------------------------
inline void operator delete(void*, void*const)
{
	//delete for placement new - do not free memory
}
#endif

//--------------------------------------------------------------------------
inline void operator delete[]( void*, bool, void*const)
{
	//delete for placement new - do not free memory
}

//--------------------------------------------------------------------------
inline void operator delete (void*, bool, void*const) 
{
	//delete for placement new - do not free memory
}

//--------------------------------------------------------------------------
inline void operator delete(void* p, const Axiom::Memory::HeapId, const char*, int, bool)
{
	Axiom::Memory::Free(p);
}

//--------------------------------------------------------------------------
inline void operator delete(void* p, const Axiom::Memory::HeapId, size_t, const char*, int, bool)
{
	Axiom::Memory::Free(p);
}

//--------------------------------------------------------------------------
inline void operator delete(void* p, const Axiom::Memory::HeapId , bool)
{
	Axiom::Memory::Free(p);
}

//--------------------------------------------------------------------------
inline void operator delete[](void* p, const Axiom::Memory::HeapId, size_t, const char*, int , bool)
{	
	Axiom::Memory::Free(p);
}

//--------------------------------------------------------------------------
inline void operator delete[](void* p, const Axiom::Memory::HeapId , const char* , int , bool)
{
	Axiom::Memory::Free(p);
}

#if CORE_PLACEMENT_NEW
//--------------------------------------------------------------------------
inline	void* operator new (size_t , void*const p) AP_THROW
{ 
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    return p; 
}
#endif

//--------------------------------------------------------------------------
inline void* operator new (size_t size) AP_THROW
{
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    if (!g_AllowGlobalAllocations)
    {
        AP_ASSERTFAIL("Use the AP_NEW operator instead of new");
    }
    return Axiom::Memory::Alloc(Axiom::Memory::DEFAULT_HEAP, size);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t size, bool) AP_THROW
{
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    if (!g_AllowGlobalAllocations)
    {
        AP_ASSERTFAIL("Use the AP_NEW operator instead of new");
    }
    return Axiom::Memory::Alloc(Axiom::Memory::DEFAULT_HEAP, size);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t size, int, const char*, int) AP_THROW
{
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    if (!g_AllowGlobalAllocations)
    {
        AP_ASSERTFAIL("Use the AP_NEW operator instead of new");
    }
    return Axiom::Memory::Alloc(Axiom::Memory::DEFAULT_HEAP, size);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t size, const Axiom::Memory::HeapId id) AP_THROW 
{
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    if (!g_AllowGlobalAllocations)
    {
        AP_ASSERTFAIL("Use the AP_NEW operator instead of new");
    }
    return Axiom::Memory::Alloc(id, size);
}

//--------------------------------------------------------------------------
inline  void* operator new[](size_t, bool, void*const p) AP_THROW
{
    return p; 
}

//--------------------------------------------------------------------------
inline void* operator new[](size_t size) AP_THROW 
{
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    //	if (!Axiom::Memory::IsEnabled())
    //        printf("Allocation is disabled ... this function is probably being called outside the main loop\n");
    return Axiom::Memory::Alloc(Axiom::Memory::DEFAULT_HEAP, size, __FILE__, __LINE__);
}

//--------------------------------------------------------------------------
inline void* operator new[](size_t size, const Axiom::Memory::HeapId heapId, const char* filename, int line, bool) AP_THROW 
{
    AP_FORCEASSERT( heapId != Axiom::Memory::AP_INVALID_HEAPID, "" );
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    return Axiom::Memory::Alloc(heapId, size, filename, line);
}

//--------------------------------------------------------------------------
inline void* operator new[](size_t size, const Axiom::Memory::HeapId heapId, size_t alignment, const char* filename, int line, bool) AP_THROW 
{
    AP_FORCEASSERT( heapId != Axiom::Memory::AP_INVALID_HEAPID, "" );
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    return Axiom::Memory::Alloc(heapId, size,  alignment, filename, line);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t size, const Axiom::Memory::HeapId heapId, const char* filename, int line, bool) AP_THROW 
{
    AP_FORCEASSERT( heapId != Axiom::Memory::AP_INVALID_HEAPID, "" );
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    return Axiom::Memory::Alloc(heapId, size, filename, line);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t size, const Axiom::Memory::HeapId heapId, size_t alignment, const char* filename, int line, bool) AP_THROW
{
    AP_FORCEASSERT( heapId != Axiom::Memory::AP_INVALID_HEAPID, "" );
    AP_ASSERTMESSAGE(Axiom::Memory::IsEnabled(), "Allocation is disabled ... this function is probably being called outside the main loop");
    return Axiom::Memory::Alloc(heapId, size, alignment, filename, line);
}

//--------------------------------------------------------------------------
inline void* operator new (size_t , bool, void*const p) AP_THROW
{ 
    //Placement new
    return p; 
}
#endif

#endif // CORE_TOOLS

#endif //_APMEMORY_H

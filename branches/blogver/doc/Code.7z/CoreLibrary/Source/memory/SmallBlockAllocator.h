// SmallBlockAllocator.h

#pragma once
#include <core/BitArray.h>

namespace Axiom
{
class SmallBlockMemoryArray;
//----------------------------------------------------------------------

enum {SBASentinel = 0xA5};
struct SBAHeader
{
	SBAHeader (int num):
					NumBlocks (static_cast <UInt16> (num)), 
					Sentinel (SBASentinel)
					{}
	SBAHeader (Byte* ptr)
					{memcpy (this, ptr, sizeof (this));}
	UInt16	NumBlocks;
	UInt16	Sentinel;
};

//----------------------------------------------------------------------

struct SBAFooter
{
	SBAFooter ():
					Sentinel (SBASentinel),
					Zero (0)
					{}
	UInt16 Sentinel;
	UInt16 Zero;
};
//----------------------------------------------------------------------
// this class assumes that larger memory blocks are more rare.
///this is a Fixed-size-blocks allocation similar to 
// a Buddy memory allocator and I use bits to track usage.
// http://en.wikipedia.org/wiki/Buddy_memory_allocation
//--------------------------------------------
class SmallBlockAllocator
{
public:
	SmallBlockAllocator ();
	~SmallBlockAllocator ();

	void	Init (Byte* StartAddr, const int TotalBytes);//  minimum size is 1 meg
	Byte*	Allocate (int size);
	Byte*	Allocate (int size, int alignment);
	void	Free (Byte*);

	bool	AnyRamUsed () const;
	int		GetLargestSizeAvailable () const {return SIZE_MEDIUM_LARGE - MINIMUM_HEADER_OVERHEAD;}
	bool	IsFull () const;// are there any blocks available
	bool	IsYours (Byte* mem) const;
	int		GetBlockSize(Byte* mem) const;
	void	GetFree(int* a, int* b, int* c, int* d, int* e, int* f );

	enum 
	{
		AP_MINALLOC = 16, 
		BOUNDARY = 4, 
		MINIMUM_HEADER_OVERHEAD = sizeof (SBAHeader) + sizeof (SBAFooter)
	};

protected:	
	
	enum 
	{
		MINIATURE=0, 
		TINY, 
		SMALL, 
		MEDIUM_SMALL, 
		MEDIUM_MEDIUM, 
		MEDIUM_LARGE, 
		NUM_SIZES
	};
	enum 
	{	
#if CORE_WII
		// make sure that all values are multiples 32
		SIZE_MINIATURE =		 32,
		SIZE_TINY =				 64,
		SIZE_SMALL =			 96,
		SIZE_MEDIUM_SMALL =		 160,
		SIZE_MEDIUM_MEDIUM =	 192,
		SIZE_MEDIUM_LARGE =		 256,
#else
		// make sure that all values are multiples of 16 minus 8 (n*16 - 8)
		SIZE_MINIATURE =		  24 + MINIMUM_HEADER_OVERHEAD,// blocks of  32
		SIZE_TINY =				  40 + MINIMUM_HEADER_OVERHEAD,// blocks of  48
		SIZE_SMALL =			  56 + MINIMUM_HEADER_OVERHEAD,// blocks of  64
		SIZE_MEDIUM_SMALL =		  88 + MINIMUM_HEADER_OVERHEAD,// blocks of  96
		SIZE_MEDIUM_MEDIUM =	 136 + MINIMUM_HEADER_OVERHEAD,// blocks of 144
		SIZE_MEDIUM_LARGE =		 184 + MINIMUM_HEADER_OVERHEAD,// blocks of 192
#endif
	};
	SmallBlockMemoryArray*	Memory [NUM_SIZES];
	Byte*	BeginAddress;
	Byte*	FinalAddress;
};
//--------------------------------------------
}

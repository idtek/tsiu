//---------------------------------------------------------------------------------------------------------------------------------
//! @file		Memory/Memory.h
//! @brief		CRT function replacements for standard memory.h
//
//	Copyright (C)2007 Action Pants Inc
//---------------------------------------------------------------------------------------------------------------------------------

#pragma once

#include <string.h>

namespace Axiom
{

	void		MemoryCopy		(void* dst, const void* src, uint size);
	void		MemorySet		(void* dst, int value, uint size);
	int			MemoryCompare	(const void* src1, const void* src2, uint size);

	//---------------------------------------------------------------------------------------------------------------------------------
	// Implementation
	//---------------------------------------------------------------------------------------------------------------------------------

	inline void MemoryCopy (void* dst, const void* src, uint size)
	{
#if CORE_XBOX360 == CORE_YES
		XMemCpy( dst, src, size );
#elif CORE_PS3 == CORE_YES
		__builtin_memcpy( dst, src, size );
#else
		memcpy(dst,src,size);
#endif
	}

	inline void OverlappingMemoryCopy (void* dst, const void* src, uint size)
	{
		memcpy( dst, src, size);
	}

	inline void MemorySet (void* dst, int value, uint size)
	{
#if CORE_XBOX360 == CORE_YES
		XMemSet( dst, value, size );
#elif CORE_PS3 == CORE_YES
		__builtin_memset( dst, value, size );
#else
		memset(dst,value,size);
#endif
	}

	inline int MemoryCompare (const void* src1, const void* src2, uint size)
	{
		return memcmp(src1,src2,size);
	}

	//---------------------------------------------------------------------------------------------------------------------------------
	//---------------------------------------------------------------------------------------------------------------------------------

}

//---------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------

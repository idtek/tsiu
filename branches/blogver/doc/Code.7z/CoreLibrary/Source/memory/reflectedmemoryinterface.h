#ifndef MEMORY_INTERFACE_H__
#define MEMORY_INTERFACE_H__
#include "core/singleton.h"
#include "reflection/script.h"

namespace Axiom
{
	namespace Memory
	{
		class ReflectedMemoryInterface: public Axiom::Singleton<ReflectedMemoryInterface>
		{
			AP_NON_COPYABLE(ReflectedMemoryInterface);
		public:
			AP_DECLARE_TYPE();

			ReflectedMemoryInterface();
			~ReflectedMemoryInterface();

			AP::Reflection::Script::Binary MemPrint();

		private:
			
		};

	}
}
#endif

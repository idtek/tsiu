
#ifndef _SOCKET_GAMESERVER_H_
#define _SOCKET_GAMESERVER_H_

#include "Socket/GameDefines.h"
#include "Socket/Server.h"
#include "Socket/Slot.h"

namespace Axiom
{
	namespace Socket
	{
		class GameEventTranslater_c;

		class GamePendingSlot : public Slot
		{
		public:

			// Constructor and virtual destructor
			GamePendingSlot(Socket*);
			/* virtual */ ~GamePendingSlot(void);

			// Public virtual methods
			/* virtual */ bool OnReceiveInstruction(ReadHeader*);

		};

		class GameServer : public Server
		{
		public:

			// Constructor and virtual destructor
			GameServer(void);
			/* virtual */ ~GameServer(void);

			// Public virtual methods
			/* virtual */ void OnAccept(Socket*,Socket*);

			void BroadcastLogMessage(const char* message);
		};
	}
}

#endif

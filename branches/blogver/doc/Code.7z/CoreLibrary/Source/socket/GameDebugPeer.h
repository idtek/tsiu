
#ifndef _SOCKET_GAMEDEBUGPEER_H_
#define _SOCKET_GAMEDEBUGPEER_H_

#include "Socket/GameDefines.h"

namespace Axiom
{
	namespace Socket
	{
		struct ReadHeader;

		class GameDebugPeer
		{
		public:

			// Constructor and virtual destructor
			GameDebugPeer(void);
			/* virtual */~GameDebugPeer(void);
			
			// Public functions
			inline const float	GetProgessDebugFlowMemory(void) const;
			inline const bool		IsDebugFlowMemoryAllocated(void) const;

			// These used to be protected member variables but are now public because the multiple inheritance of STFGameDebugClient had to be eliminated.
			// There is bad coupling here with STFManaged.cpp!!!

			// Debug flow memory
			unsigned char		*m_pDebugFlowMemory;
			int					m_DebugFlowMemoryLength;
			int					m_CurrentDebugFlowMemoryIndex;
			int					m_CurrentDebugFlowPage;

			// Echo & activity
			

			// Protected methods
			bool				InitDebugFlowMemory(int);
			bool				AddToDebugFlowMemory(ReadHeader*);
			bool				RemoveFromDebugFlowMemory(int);
			void				ReleaseDebugFlowMemory(void);

		};

		// Inline public implementation
		inline const float GameDebugPeer::GetProgessDebugFlowMemory(void) const
		{ 
			return ( 0.f == m_DebugFlowMemoryLength ? 1.f : static_cast<float>(m_CurrentDebugFlowMemoryIndex) / static_cast<float>(m_DebugFlowMemoryLength) );
		};

		inline const bool GameDebugPeer::IsDebugFlowMemoryAllocated(void) const
		{
			return m_pDebugFlowMemory != NULL;
		};
	}
}

#endif

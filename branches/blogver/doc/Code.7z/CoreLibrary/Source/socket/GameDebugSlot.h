
#ifndef _SOCKET_GAMEDEBUGSLOT_H_
#define _SOCKET_GAMEDEBUGSLOT_H_

#include "Socket/GameDefines.h"
#include "Socket/Slot.h"
#include "Socket/GameDebugPeer.h"
#include "eventsystem/eventmsgbox.h"

namespace Axiom
{
	class Timer;

	namespace Socket
	{
		struct ReadHeader;

		class GameDebugSlot : public Slot, public GameDebugPeer
		{
		public:

			// Constructor and virtual destructor
			GameDebugSlot(Slot*);
			/* virtual */ ~GameDebugSlot(void);

			// Public methods
			void				SendFlow(int,unsigned char*,int);
			void				SendFlow(Instruction_t);

			// Public virtual methods
			/* virtual */ void Init(void);
			/* virtual */ bool	OnReceiveInstruction(ReadHeader*);
			/* virtual */ void	OnReceive(unsigned char*,int);
			void ResetKeepAliveTimeout(void);
			void UpdateKeepAlive(void);
			void UpdateEvents(void);
			void KillIfNotAlive(void);
			void QueueLogMessage(const char* message);

		private:
			Axiom::EventMsgBoxHandle m_EventMessageBoxHandle;
			bool m_bCheckAlive;

			float				m_KillElapsed;
			float				m_NopElapsed;
			Axiom::Timer*		m_UpdateTimer;
			
			static const int	LOG_MESSAGE_BUFFER_SIZE = 1024*16;
			char		mLogMessageBuffer[LOG_MESSAGE_BUFFER_SIZE];
			int			mLogMessageBufferLength;
		};
	}
}

#endif


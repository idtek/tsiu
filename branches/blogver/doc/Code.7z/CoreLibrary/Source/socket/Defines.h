
#ifndef _SOCKET_DEFINES_H_
#define _SOCKET_DEFINES_H_

#define SOCKET_WII_DEBUGMODE 	0
#define SOCKET_GAMEINSTRUCTIONS_DEBUGMODE 0

//SOCKETMANAGER_NBSOCKETS_MAX
#if CORE_WII
#	define SOCKETMANAGER_NBSOCKETS_MAX				1	 							//!< Max number of sockets
#else 
#	define SOCKETMANAGER_NBSOCKETS_MAX				32								//!< Max number of sockets
#endif

//Socket Constants
#define SOCKET_IPV4_URL_LENGTH						128								//!< length of url address in a string
#define SOCKET_IPV4_IPADDRESS_LENGTH				16								//!< length of ip address in a string
#define SOCKET_IPV4_MACADDRESS_LENGTH				18								//!< length of mac address in a string
#define SOCKET_SOCKET_RECEIVINGMEMORY_LENGTH		4096							//!< This is currently set to match SHAREDMEMORY_SIZE for Socket_Wii, to optimize USB transfers.
#define SOCKET_SLOT_RECEIVINGMEMORY_LENGTH			16384							//!< Recommendation: This should match SOCKET_DEBUGSENDBUFFER_LENGTH in GameDefines.h
#define SOCKET_CLIENT_RECEIVINGMEMORY_LENGTH		16384   						//!< Recommendation: This should match SOCKET_DEBUGSENDBUFFER_LENGTH in GameDefines.h
#define SOCKET_SENDBUFFER_LENGTH					16384							//!< Recommendation: This number should be the same as SOCKET_XXX_RECEIVINGMEMORY_LENGTH
#define SOCKET_SERVER_NBSLOTS_MAX					16								//!< Max number of server slots
#define SOCKET_TEMPBUFFER_LENGTH					64								//!< Temporary buffer size

// Error enumeration
//---------------------------------------------------------------------------------------------------------------------------------
//!	@enum		SocketError
//!	@brief		List of socket error codes
//! @ingroup	Socket
//---------------------------------------------------------------------------------------------------------------------------------	
enum SocketError
{
	SOCKET_ERROR_CANTOPENSOCKET = -1,					//!< can't opened socket
	SOCKET_ERROR_CANTBINDSOCKET = -2,					//!< Can't bind to socket
	SOCKET_ERROR_CANTLISTENSOCKET = -3,					//!< Can't listen to socket
	SOCKET_ERROR_CANTCONNECTSOCKET = -4,				//!< Can't connect to socket
	SOCKET_ERROR_CANTRECEIVESOCKET = -5,				//!< Can't receive from socket
	SOCKET_ERROR_CANTSENDSOCKET = -6,					//!< Can't send via socket
	SOCKET_ERROR_DISCONNECTEDSOCKET = -7,				//!< Socket disconnected
	SOCKET_ERROR_CANTGETADDRESSINFO = -8,				//!< Can't get address information of socket
	SOCKET_ERROR_CANTRESOLVEURL = -9,					//!< Can't resolve the url address
	SOCKET_ERROR_CANTGETHOSTNAME = -10,					//!< Can't get host name
	SOCKET_ERROR_BADDATARECIEVED = -11,					//!< Unexpected data recieved
	SOCKET_ERROR_CANTCLOSESOCKET = -12,					//!< Can't close socket
	SOCKET_ERROR_UNKNOWN = -13,							//!< Can't get host name
	SOCKET_ERROR_OK = 0,								//!< Success

	SOCKET_ERROR_PASSED									//!< Passed
};

#if CORE_TOOLS
#include <assert.h>
#include <memory.h>
#include <string.h>
#include <stdio.h>
#include <malloc.h>
void client_socket_print(char *s);
#	define SOCKET_PRINT(message)							client_socket_print(message);
#	define SOCKET_MEMCPY(a,b,c)								memcpy(a,b,c)
#	define SOCKET_MEMSET(dest, value, size)					memset(dest,value,size)
#	define SOCKET_STRINGCOPY(dest,src,n)					strncpy_s(dest,n,src,n)
#	define SOCKET_STRINGLENGTH(str)							strlen(str)
#	define SOCKET_STRINGFORMAT1(dest, n, format, p1)			sprintf_s(dest, format, p1)
#	define SOCKET_STRINGFORMAT2(dest, n, format, p1, p2)		sprintf_s(dest, format, p1, p2)
#	define SOCKET_STRINGFORMAT3(dest, n, format, p1, p2, p3)	sprintf_s(dest, format, p1, p2, p3)
#	define SOCKET_STRINGFORMAT4(dest, n, format, p1, p2, p3, p4)	sprintf_s(dest, format, p1, p2, p3, p4)
#	define SOCKET_STRINGFORMAT5(dest, n, format, p1, p2, p3, p4, p5)	sprintf_s(dest, format, p1, p2, p3, p4, p5)
#	define SOCKET_STRINGFORMAT6(dest, n, format, p1, p2, p3, p4, p5, p6)	sprintf_s(dest, format, p1, p2, p3, p4, p5, p6)
#	define SOCKET_ASSERTMESSAGE(__CONDITION__,__COMMENT__)	assert(__CONDITION__)
#	define SOCKET_NEW(__CREATOR__)					new __CREATOR__
#	define SOCKET_PLACEMENT_NEW(__DATA__)					new(__DATA__)							
#	define SOCKET_DELETEARRAY(__DATA__)						delete [] __DATA__
#	define SOCKET_DELETE(__DATA__)							delete __DATA__
#	define SOCKET_ALLOC(size)								malloc(size)
#	define SOCKET_ALIGNED_ALLOC(size, alignment)			_aligned_malloc(size, alignment)   
#	define SOCKET_FREE(mem)									free(mem) 
#	define SOCKET_THREAD_SLEEP(milliseconds)				Sleep(milliseconds)
#	define NULL 0
#ifndef CORE_BIGENDIAN
#	define CORE_BIGENDIAN		0
#endif
#ifndef CORE_LITTLEENDIAN
#	define CORE_LITTLEENDIAN	1
#endif
#ifndef CORE_WIN32
#	define CORE_WIN32			1
#endif
#else
#include <string/stringutils.h>
#include <thread/mutex.h>
#	define SOCKET_PRINT(message)							Axiom::Log("SOCKET", message);
#	define SOCKET_MEMCPY(a,b,c)								Axiom::MemoryCopy(a,b,c)
#	define SOCKET_MEMSET(dest, value, size)					Axiom::MemorySet(dest,value,size)
#	define SOCKET_STRINGCOPY(dest,src,n)					Axiom::StringCopy(dest,src,n)
#	define SOCKET_STRINGLENGTH(str)							Axiom::StringLength(str)
#	define SOCKET_STRINGFORMAT1(dest, n, format, p1)		Axiom::StringFormat(dest, n, format, p1)
#	define SOCKET_STRINGFORMAT2(dest, n, format, p1, p2)	Axiom::StringFormat(dest, n, format, p1, p2)
#	define SOCKET_STRINGFORMAT3(dest, n, format, p1, p2, p3) Axiom::StringFormat(dest, n, format, p1, p2, p3)
#	define SOCKET_STRINGFORMAT4(dest, n, format, p1, p2, p3, p4) Axiom::StringFormat(dest, n, format, p1, p2, p3, p4)
#	define SOCKET_STRINGFORMAT5(dest, n, format, p1, p2, p3, p4, p5) Axiom::StringFormat(dest, n, format, p1, p2, p3, p4, p5)
#	define SOCKET_STRINGFORMAT6(dest, n, format, p1, p2, p3, p4, p5, p6) Axiom::StringFormat(dest, n, format, p1, p2, p3, p4, p5, p6)
#	define SOCKET_ASSERTMESSAGE(__CONDITION__,__COMMENT__)	AP_ASSERTMESSAGE(__CONDITION__,__COMMENT__)
#	define SOCKET_NEW(__CREATOR__)							AP_NEW(Axiom::Memory::RESERVED_DEBUG_HEAP,__CREATOR__)
#	define SOCKET_PLACEMENT_NEW(__DATA__)					AP_PLACEMENT_NEW(__DATA__)							
#	define SOCKET_DELETEARRAY(__DATA__)						AP_DELETEARRAY(__DATA__)
#	define SOCKET_DELETE(__DATA__)							AP_DELETE(__DATA__)
#	define SOCKET_ALLOC(size)								AP_ALLOC(Axiom::Memory::RESERVED_DEBUG_HEAP, size)
#	define SOCKET_ALIGNED_ALLOC(size, alignment)			AP_ALIGNED_ALLOC(Axiom::Memory::RESERVED_DEBUG_HEAP, size, alignment)
#	define SOCKET_FREE(mem)									AP_FREE(mem)
#	define SOCKET_THREAD_SLEEP(milliseconds)				Axiom::Thread::Sleep(milliseconds)
#endif


#endif

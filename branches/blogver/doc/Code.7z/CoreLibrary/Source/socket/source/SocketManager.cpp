#include "Socket/SocketManager.h" 
#include "Socket/source/Socket.h" 
#include "Socket/Slot.h" 

// Namespace usage
using namespace Axiom::Socket;

// Static private methods
/* static */ const unsigned long SocketManager::GetLongFromAddress(char *pAddress)
{
	unsigned long uAddress = 0;

	if( pAddress != NULL )
	{
		unsigned char	u = 0;
		char			c = *pAddress++;
		while( c != '\0' )
		{
			if( c == '.' )
			{
				uAddress |= u;			
				uAddress <<= 8;
				u = 0;
			}
			else if( c >= '0' && c <= '9' )
			{
				u *= 10;
				u += c - '0';
			}
			else
			{
				SOCKET_ASSERTMESSAGE(false,"STF Error: Illegal character passed in IP address string!\n");
			}
			c = *pAddress++;
		}
		uAddress |= u;			
	}

	return uAddress;
}

/* static */ const bool SocketManager::GetAddressIsURL(char *pAddress)
{
	SOCKET_ASSERTMESSAGE( pAddress != NULL, "STF Error: NULL pointer passed!\n" );

	char c = *pAddress++;
	while( c != '\0' )
	{
		if( !( ( c >= '0' && c <= '9' ) || c == '.' ) )
		{
			return true;
		}

		c = *pAddress++;
	}
	
	return false;
}

// Private methods
void SocketManager::ResetSocketList(void)
{
	// Linearize the list
	SocketNode_s	*pNode;
	int				i;
	for( i = 0, pNode = m_pSocketNodes ; i < ( m_MaxNbSockets - 1 ) ; ++i, ++pNode )
	{
		pNode->m_pSocket = NULL;
		pNode->m_pNextNode = pNode+1;
	}
	pNode->m_pSocket = NULL;
	pNode->m_pNextNode = NULL;

	// Init the head, free nodes and length
	m_pSocketHeadNode = NULL;
	m_pSocketFreeNode = m_pSocketNodes;
	m_NbSockets = 0;
}

void SocketManager::DestroySocketList(void)
{
	// Go through the list...
	SocketNode_s *pNode;
	for( pNode = m_pSocketHeadNode ; pNode != NULL ; pNode = pNode->m_pNextNode )
	{
		Socket *pSocket = pNode->m_pSocket;
		// Destroy the socket
		if( pSocket != NULL )
		{
			delete pSocket;
			pNode->m_pSocket = NULL;
		}
	}
}

SocketManager::SocketNode_s* SocketManager::AddInSocketList(Socket *pSocket)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	// Use the free node
	SocketNode_s *pNode = m_pSocketFreeNode;
	if( pNode != NULL )
	{
		// Update the node list
		m_pSocketFreeNode = pNode->m_pNextNode;
		pNode->m_pNextNode = m_pSocketHeadNode;
		m_pSocketHeadNode = pNode;
		m_NbSockets++;

		// Assign the socket
		pNode->m_pSocket = pSocket;

		return pNode;
	}

	return NULL;
}

SocketManager::SocketNode_s* SocketManager::RemoveFromSocketList(Socket *pSocket)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );
	
	SocketNode_s	*pPreviousNode = NULL;
	SocketNode_s	*pNode;
	int				i;
	for( i = 0, pNode = m_pSocketHeadNode ; i < m_NbSockets && pNode != NULL ; ++i, pPreviousNode = pNode, pNode = pNode->m_pNextNode )
	{
		if( pNode->m_pSocket == pSocket )
		{
			// Save the next node 
			SocketNode_s *pNextNode = pNode->m_pNextNode;
			
			// Update the node list
			if( pPreviousNode == NULL )
			{
				m_pSocketHeadNode = pNextNode;
			}
			else
			{
				pPreviousNode->m_pNextNode = pNextNode;
			}
			pNode->m_pNextNode = m_pSocketFreeNode;
			m_pSocketFreeNode = pNode;
			m_NbSockets--;

			// Destroy the socket
			delete pNode->m_pSocket;
			pNode->m_pSocket = NULL;

			return pNextNode;
		}
	}

	return NULL;
}

// Constructor and virtual destructor
SocketManager::SocketManager(const int iMaxNbSockets /*= STFSYSTEM_NBSOCKETS_MAX*/) :
	m_MaxNbSockets(iMaxNbSockets)
{
	// Allocate the socket nodes
	m_pSocketNodes = (SocketNode_s*)SOCKET_ALLOC( sizeof(SocketNode_s)*m_MaxNbSockets );
	ResetSocketList();
}

/* virtual */ SocketManager::~SocketManager(void)
{
	// Make sure to destroy all the socket nodes
	DestroySocketList();
	SOCKET_FREE(m_pSocketNodes);
	m_pSocketNodes = NULL;
}

// Public methods
void SocketManager::Update(void)
{
	SocketNode_s	*pNode;
	int				i;
	for( i = 0, pNode = m_pSocketHeadNode ; i < m_NbSockets && pNode != NULL ; ++i, pNode = pNode->m_pNextNode )
	{
		Socket *pSocket = pNode->m_pSocket;
		if( pSocket != NULL )
		{
			Socket::SOCKET_CLASS_e eClass;
			eClass = pSocket->GetClass();

			// Handle the remove state
			if( pSocket->GetState() == Socket::SOCKET_STATE_REMOVE )
			{
				RemoveSocket( pSocket );
			}
			else
			{
				pSocket->Update();
			}
		}
	}
}

Socket* SocketManager::AddSocket(void)
{
	// Create the socket
	Socket *pSocket = CreateSocket();
	if( pSocket == NULL )
	{
		return NULL;
	}

	// Add the created socket to the list
	AddInSocketList(pSocket);

	return pSocket;
}

void SocketManager::RemoveSocket(Socket *pSocket)
{
	// Find the socket
	RemoveFromSocketList(pSocket);
}


#include "Socket/Defines.h"
#include "Socket/source/Socket.h"

#if CORE_WIN32

#include <Socket/Source/Win32/Socket_Win32.h>
#include <Socket/SocketManager.h>

#include <nb30.h>

// Defines
#define SOCKET_NBADAPTERS_MAX	10

namespace Axiom
{
	namespace Socket
	{
		typedef struct Adapter_s
		{
			ADAPTER_STATUS  m_AdapterStatus;
			NAME_BUFFER     m_aNameBuffers[SOCKET_NBADAPTERS_MAX];

		} Adapter_s;
	}
}

// Namespace usage
using namespace Axiom::Socket;

// Static local variables
static int s_aSocketFamilyLookUpTable[Socket::SOCKET_NBFAMILIES] = { AF_UNSPEC,   // SOCKET_FAMILY_UNKNOWN
																	   AF_INET,		// SOCKET_FAMILY_IPV4
																	   AF_INET6,	// SOCKET_FAMILY_IPV6
																	   AF_IRDA };	// SOCKET_FAMILY_IRDA

static int s_aSocketTypeLookUpTable[Socket::SOCKET_NBTYPES] = { SOCK_STREAM,		// SOCKET_TYPE_STREAM
																  SOCK_DGRAM,		// SOCKET_TYPE_DATAGRAM
																  SOCK_RAW };		// SOCKET_TYPE_RAW

static int s_aSocketProtocolLookUpTable[Socket::SOCKET_NBPROTOCOLS] = { IPPROTO_TCP,		// SOCKET_PROTOCOL_TCP 
																		  IPPROTO_UDP };	// SOCKET_PROTOCOL_UDP

// Private methods
SocketError Socket_Win32::GetAddressInfoFromAddress(addrinfo **ppAddressInfo, char *pAddress /*= 0*/, int iPort /*= 0*/)
{
	SOCKET_ASSERTMESSAGE( ppAddressInfo != NULL, "STF Error: NULL pointer passed!\n" );

	// Put the port (Class' if 0) in a character string
	if( iPort == 0 )
	{
		SOCKET_ASSERTMESSAGE( m_Port != 0, "STF Error: 0 is an unsupported port!\n" );

		iPort = m_Port;
	}
	char aPort[6];
	SOCKET_STRINGFORMAT1(aPort, array_count(aPort), "%i", iPort);

	// Put the address (Class' if 0)
	if( pAddress == 0 /*&& m_aAddress[0] != '\0'*/ )
	{
		pAddress = m_aAddress;
	}

	// Prepare the structure 
	addrinfo tHints;
	SOCKET_MEMSET( &tHints, 0, sizeof(tHints) );
	tHints.ai_family = s_aSocketFamilyLookUpTable[m_Family];
	tHints.ai_socktype = s_aSocketTypeLookUpTable[m_Type];
	tHints.ai_protocol = s_aSocketProtocolLookUpTable[m_Protocol];
	tHints.ai_flags = AI_PASSIVE;

	// Get the address info
	int iResult = getaddrinfo(pAddress, aPort, &tHints, ppAddressInfo);
	if( iResult == SOCKET_ERROR )
	{
/*
		// Get the error
		int iError = WSAGetLastError();
		if( iError == )
		{
		}
*/
		return SOCKET_ERROR_CANTGETADDRESSINFO;
	}

	return SOCKET_ERROR_OK;
}

SocketError Socket_Win32::GetAddressInfoFromURL(addrinfo **ppAddressInfo, char *pURL /*= 0*/, int iPort /*= 0*/)
{
	SOCKET_ASSERTMESSAGE( ppAddressInfo != NULL, "STF Error: NULL pointer passed!\n" );

	// Put the port (Class' if 0) in a character string
	if( iPort == 0 )
	{
		SOCKET_ASSERTMESSAGE( m_Port != 0, "STF Error: 0 is an unsupported port!\n" );

		iPort = m_Port;
	}
	char aPort[6];
	SOCKET_STRINGFORMAT1(aPort, array_count(aPort), "%i", iPort);

	// Put the address (Class' if 0)
	if( pURL == 0 /*&& m_aAddress[0] != '\0' && m_AddressIsURL*/ )
	{
		pURL = m_aAddress;
	}

	// Resolve the name
	hostent *pHostEntity = gethostbyname(pURL);
	if( pHostEntity == NULL )
	{
/*
		// Get the error
		int iError = WSAGetLastError();
		if( iError == )
		{
		}
*/
		return SOCKET_ERROR_CANTRESOLVEURL;
	}
	// Compute the first given IP address in an in_addr structure 
	in_addr tAddress;
	SOCKET_MEMCPY(&tAddress,pHostEntity->h_addr_list[0],sizeof(unsigned char)*4);
	// Get the final IP address as a string
	char *pAddress = inet_ntoa(tAddress);

	// Prepare the structure 
	addrinfo tHints;
	SOCKET_MEMSET( &tHints, 0, sizeof(tHints) );
	tHints.ai_family = s_aSocketFamilyLookUpTable[m_Family];
	tHints.ai_socktype = s_aSocketTypeLookUpTable[m_Type];
	tHints.ai_protocol = s_aSocketProtocolLookUpTable[m_Protocol];
	tHints.ai_flags = AI_PASSIVE;

	// Get the address info
	int iResult = getaddrinfo(pAddress, aPort, &tHints, ppAddressInfo);
	if( iResult == SOCKET_ERROR )
	{
/*
		// Get the error
		int iError = WSAGetLastError();
		if( iError == )
		{
		}
*/
		return SOCKET_ERROR_CANTGETADDRESSINFO;
	}

	return SOCKET_ERROR_OK;
}

// Protected virtual functions
/* virtual */ SocketError Socket_Win32::Open(void)
{
	// Call the base method
	Socket::Open();

	if( m_Handle == INVALID_SOCKET )
	{
		// Open on local address
		addrinfo *pAddressInfo = NULL;
		GetAddressInfoFromAddress(&pAddressInfo);

		// Make sure to convert the arguments accordingly to the platform
		m_Handle = socket(pAddressInfo->ai_family,pAddressInfo->ai_socktype,pAddressInfo->ai_protocol);
		if( m_Handle == INVALID_SOCKET )
		{
/*
			// Get the error
			int iError = WSAGetLastError();
			if( iError == )
			{
			}
*/
			return SOCKET_ERROR_CANTOPENSOCKET;
		}

		// Set this socket to non-blocking
		unsigned long uMode = 1;
		ioctlsocket( m_Handle, FIONBIO, &uMode );
		
		// Allow broadcast for UDP
		if( m_Type == SOCKET_TYPE_DATAGRAM )
		{
			setsockopt(m_Handle, SOL_SOCKET, SO_BROADCAST, (char*)&uMode, sizeof(uMode));
		}
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Close(void)
{
	if( m_Handle != INVALID_SOCKET )
	{
		SocketError result = Socket::Close();

		if( m_Class == SOCKET_CLASS_CLIENT || m_Class == SOCKET_CLASS_SLOT )
		{
			SetConnected(false);
		}

		// Perform callback
		CallDisconnectCallback();

		// Close winsock socket
		shutdown( m_Handle, SD_BOTH );
		closesocket(m_Handle);
		m_Handle = INVALID_SOCKET;

		// Call the base method
		return result; 
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Bind(void)
{
	if( m_Handle != INVALID_SOCKET )
	{
		// Bind on local address
		addrinfo *pAddressInfo = NULL;
		GetAddressInfoFromAddress(&pAddressInfo);

		// Start binding 
		sockaddr_in	*pAddress = (sockaddr_in*)pAddressInfo->ai_addr;
		int			iAddressLength = (int)pAddressInfo->ai_addrlen;
		int			iResult = bind(m_Handle,(sockaddr*)pAddress,iAddressLength);
		if( iResult == SOCKET_ERROR )
		{
			// Get the error
			int iError = WSAGetLastError();
			char error[256];
			SOCKET_STRINGFORMAT1(error, array_count(error), "WSA error: %d", iError);
			SOCKET_PRINT(error);

			Close();
			return SOCKET_ERROR_CANTBINDSOCKET;
		}

		// Call the base method
//		return Socket::Bind();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Listen(void)
{
	if( m_MaxNbConnections > 0 && m_Handle != INVALID_SOCKET )
	{
		int iResult = listen( m_Handle, m_MaxNbConnections );
		if( iResult == SOCKET_ERROR )
		{
			// Get the error
			int iError = WSAGetLastError();
			char error[256];
			SOCKET_STRINGFORMAT1(error, array_count(error), "WSA error: %d", iError);
			SOCKET_PRINT(error);

			Close();
			return SOCKET_ERROR_CANTBINDSOCKET;
		}

		// Call the base method
//		return Socket::Listen();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Accept(void)
{
	if( m_Handle != INVALID_SOCKET )
	{
		// Get the client socket handle from the server socket
		SOCKET iSocket = accept( m_Handle, NULL, NULL );
		if( iSocket == INVALID_SOCKET )
		{
			// Check if no connection is getting through
			int iError = WSAGetLastError();
			if( iError == WSAEWOULDBLOCK )
			{
				return SOCKET_ERROR_PASSED;
			}

			Close();
			return SOCKET_ERROR_CANTLISTENSOCKET;
		}

		// Set this socket to non-blocking
		unsigned long uMode = 1;
		ioctlsocket( iSocket, FIONBIO, &uMode );

		// Allow broadcast for UDP
		if( m_Type == SOCKET_TYPE_DATAGRAM )
		{
			setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, (char*)&uMode, sizeof(uMode));
		}

		// Add one of our socket to the process
		Socket_Win32 *pSocket = (Socket_Win32*)GetSocketManager()->AddSocket();
		pSocket->SetHandle(iSocket);

		// Make sure it's a client one
		pSocket->SetProperties( SOCKET_CLASS_SLOT, (SOCKET_FAMILY_e)m_Family, (SOCKET_TYPE_e)m_Type, (SOCKET_PROTOCOL_e)m_Protocol );

		// Call the base class open method
		pSocket->Socket::Open();

		// Set the client socket up on the right state
		pSocket->SetState(SOCKET_STATE_CLIENT_RECEIVE);

		// Perform callback
		CallAcceptCallback(pSocket);

		// Call the base method
//		return Socket::Accept();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Connect(void)
{
	if( m_Handle != INVALID_SOCKET )
	{
		// Connect on given address
		addrinfo *pAddressInfo = NULL;
		if( m_AddressIsURL )
		{
			GetAddressInfoFromURL(&pAddressInfo,m_aAddress);
		}
		else
		{
			GetAddressInfoFromAddress(&pAddressInfo,m_aAddress);
		}

		// Start the connection
		sockaddr_in	*pAddress = (sockaddr_in*)pAddressInfo->ai_addr;
		int			iAddressLength = (int)pAddressInfo->ai_addrlen;
		int iResult = connect(m_Handle,(sockaddr*)pAddress,iAddressLength);
		if( iResult == SOCKET_ERROR )
		{
			// Get the error
			int iError = WSAGetLastError();
			if( iError == WSAEWOULDBLOCK /* Non-blocking */ || iError == WSAEALREADY /* In progress */ || iError == WSAEINVAL /* Invalid, can happen on non-blocking */ )
			{
				return SOCKET_ERROR_PASSED;
			}
			if( iError == WSAEISCONN /* Socket is already connected */ )
			{
				SetConnected(true);

				// Perform callback
				CallConnectCallback();

				// Call the base method
//				return Socket::Connect();
				return SOCKET_ERROR_OK;
			}
			
			// Get the error
			char error[256];
			SOCKET_STRINGFORMAT1(error, array_count(error), "WSA error: %d", iError);
			SOCKET_PRINT(error);

			Close();
			return SOCKET_ERROR_CANTCONNECTSOCKET;
		}

		// NOTE: Because the socket is non-blocking, it should never get to this point.
		SetConnected(true);

		// Perform callback
		CallConnectCallback();

		// Call the base method
//		return Socket::Connect();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Win32::Receive(void)
{
	if( m_Handle != INVALID_SOCKET )
	{
		int iResult = recv(m_Handle,(char*)m_pReceivingMemory,SOCKET_SOCKET_RECEIVINGMEMORY_LENGTH,0);
		if( iResult == SOCKET_ERROR )
		{
			// Get the error
			int iError = WSAGetLastError();
			if( iError == WSAEWOULDBLOCK )
			{
				return SOCKET_ERROR_PASSED;
			}
			
			// Get the error
			char error[256];
			SOCKET_STRINGFORMAT1(error, array_count(error), "WSA error: %d", iError);
			SOCKET_PRINT(error);

			Close();
			return SOCKET_ERROR_CANTRECEIVESOCKET;
		}
		if( iResult == 0 )
		{
			Close();
			return SOCKET_ERROR_DISCONNECTEDSOCKET;
		}

		// Asign memory length
		m_ReceivingMemoryLength = iResult;

		// Perform callback	
		CallReceiveCallback();

		// Call the base method
//		return Socket::Receive();
	}

	return SOCKET_ERROR_OK;
}

// Constructor and virtual destructor
Socket_Win32::Socket_Win32(SocketManager* socketManager) :
	Socket(socketManager),
	m_Handle(INVALID_SOCKET)
{
}

/* virtual */ Socket_Win32::~Socket_Win32(void)
{
}

// Public methods
void Socket_Win32::SetHandle(SOCKET uHandle)
{
	m_Handle = uHandle;
}

// Public virtual functions
/* virtual */ void Socket_Win32::GetLocalAddress(IPV4Address *pIPAddress)
{
	// The info of an empty host
	addrinfo *pAddressInfo = NULL;
	GetAddressInfoFromURL(&pAddressInfo,"");

	sockaddr_in *pSockAddress = (sockaddr_in*)pAddressInfo->ai_addr;
	SOCKET_MEMCPY(pIPAddress, &( pSockAddress->sin_addr.S_un.S_un_b ), 4);
}

/* virtual */ void Socket_Win32::GetLocalMACAddress(MACAddress_s *pMACAddress)
{
    NCB	ncb;
	
	// Clear up the address
	SOCKET_MEMSET(pMACAddress, 0, sizeof(MACAddress_s));

	// Clear up the structure and fill up the command
    SOCKET_MEMSET(&ncb, 0, sizeof(ncb));
    ncb.ncb_command = NCBRESET;

    // Try to find a net adapter
    for( ncb.ncb_lana_num = 0 ; ncb.ncb_lana_num < SOCKET_NBADAPTERS_MAX ; ++ncb.ncb_lana_num )
    {
	    int	iError = Netbios(&ncb);
        if( iError != NRC_GOODRET )
        {
            if( iError != 0x23 )
            {
				SOCKET_ASSERTMESSAGE( false, "STF Error: Can't find adapter!\n" );
			}
        }
        else
        {
            break;
        }
    }

    // Did we find one?
    if( ncb.ncb_lana_num < SOCKET_NBADAPTERS_MAX )
    {
        int iNbAdaptors = ncb.ncb_lana_num;

		// Clear-up the structure, fill up the command and the number of adapters
        SOCKET_MEMSET(&ncb, 0, sizeof(ncb));
        ncb.ncb_command = NCBASTAT;
        ncb.ncb_lana_num = (unsigned char)iNbAdaptors;

		Adapter_s tAdapter;
        SOCKET_MEMCPY( (char*)ncb.ncb_callname, "*               ", NCBNAMSZ );
        ncb.ncb_buffer = (unsigned char*)&tAdapter;
        ncb.ncb_length = sizeof(Adapter_s);

        if( Netbios(&ncb) == NRC_GOODRET )
        {
            SOCKET_MEMCPY(pMACAddress, &( tAdapter.m_AdapterStatus.adapter_address ), 6);
		}
    }
    else
    {
		SOCKET_ASSERTMESSAGE( false, "STF Error: Can't find adapter!\n" );
	}
}

/* virtual */ SocketError Socket_Win32::Send(unsigned char *pMemory /*= 0*/, int iMemoryLength /*=0*/)
{
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );

	if( m_Handle != INVALID_SOCKET )
	{
		int iResult = send(m_Handle,(char*)pMemory,iMemoryLength,0);
		if( iResult == SOCKET_ERROR )
		{
			// Get the error
			int iError = WSAGetLastError();
			if( iError == WSAEWOULDBLOCK )
			{
				return SOCKET_ERROR_PASSED;
			}
			
			// Get the error
			char error[256];
			SOCKET_STRINGFORMAT1(error, array_count(error), "WSA error: %d", iError);
			SOCKET_PRINT(error);

			Close();
			return SOCKET_ERROR_CANTSENDSOCKET;
		}

		// Call the base method
//		return Socket::Send(pMemory,iMemoryLength);
	}

	return SOCKET_ERROR_OK;
}

#endif

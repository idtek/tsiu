#include "Socket/Server.h"
#include "Socket/Slot.h"
#include "Socket/SocketManager.h"
#include "Socket/source/Socket.h"

// Namespace usage
using namespace Axiom::Socket;

// Callbacks to stuff the sockets with! ;]
void server_disconnect(Socket *pThisSocket, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual disconnect function
	Server *pServer = (Server*)pData;
	pServer->OnDisconnect(pThisSocket);
}

void server_receive(Socket *pThisSocket, void *pData, unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual receive function
	Server *pServer = (Server*)pData;
	pServer->OnReceive(pThisSocket,pMemory,iMemoryLength);
}

void server_accept(Socket *pThisSocket, void *pData, Socket *pConnectedSocket)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Set the callbacks
	pConnectedSocket->SetDisconnectCallback(server_disconnect,pData);
	pConnectedSocket->SetReceiveCallback(server_receive,pData);

	// Call the virtual accept function
	Server *pServer = (Server*)pData;
	pServer->OnAccept(pThisSocket,pConnectedSocket);
}

// Private methods
void Server::ResetSlotList(void)
{
	// Linearize the list
	SlotNode_s	*pNode = m_pSlotNodes;
	int			i;
	for( i = 0 ; i < ( m_MaxNbSlots - 1 ) ; ++i, ++pNode )
	{
		pNode->m_pSlot = NULL;
		pNode->m_pNextNode = pNode+1;
	}
	pNode->m_pSlot = NULL;
	pNode->m_pNextNode = NULL;

	// Init the head, free nodes and length
	m_pSlotHeadNode = NULL;
	m_pSlotFreeNode = m_pSlotNodes;
	m_NbSlots = 0;
}

void Server::DestroySlotList(void)
{
	// Go through the list...
	SlotNode_s *pNode;
	for( pNode = m_pSlotHeadNode ; pNode != NULL ; pNode = pNode->m_pNextNode )
	{
		Slot *pSlot = pNode->m_pSlot;
		// Destroy the slot
		if( pSlot != NULL )
		{
			delete pSlot;
			pNode->m_pSlot = NULL;
		}
	}
}

// Constructor and virtual destructor
Server::Server(const int iMaxNbSlots /*= STFSYSTEM_SERVER_NBSLOTS_MAX*/) :
	m_pSlotNodes(NULL),
	m_pSlotHeadNode(NULL),
	m_pSlotFreeNode(NULL),	
	m_NbSlots(0),
	m_MaxNbSlots(iMaxNbSlots),
	m_pListenSocket(NULL)
{
	// Allocate the Slot nodes
	m_pSlotNodes = (SlotNode_s*)SOCKET_ALLOC( sizeof(SlotNode_s)*m_MaxNbSlots );
	ResetSlotList();
}

/* virtual */ Server::~Server(void)
{
	// Make sure we're calling the release function
	Release();

	// Make sure to destroy all the socket nodes
	DestroySlotList();
	SOCKET_FREE(m_pSlotNodes);
	m_pSlotNodes = NULL;
}

// Public methods

// Helpers
void Server::GetLocalAddress(IPV4Address *pIPAddress)
{
	SOCKET_ASSERTMESSAGE( pIPAddress != NULL, "STF Error: NULL pointer passed!\n" );

	m_pListenSocket->GetLocalAddress(pIPAddress);
}

const int Server::GetPort(void)
{
	return m_pListenSocket->GetPort();
}

// Data transfer functions

// Default Disconnect function: Remove the slot that contains the disconnected socket.
/* virtual */void Server::Init(SocketManager* socketManager, int iPort, int iProtocol)
{
	SOCKET_ASSERTMESSAGE( iPort > 0, "STF Error: Port has to be greater than 0!\n" );

	// Create the socket
	m_pListenSocket = socketManager->AddSocket();
	SOCKET_ASSERTMESSAGE( m_pListenSocket != NULL, "STF Error: Can't create a socket!\n" );

	// Set the properties
	m_pListenSocket->SetProperties(Socket::SOCKET_CLASS_SERVER,Socket::SOCKET_FAMILY_IPV4,Socket::SOCKET_TYPE_STREAM,(Socket::SOCKET_PROTOCOL_e)iProtocol);
	// Set the maximum connections
	m_pListenSocket->SetMaxNbConnections(m_MaxNbSlots);

	// Set the callbacks
	m_pListenSocket->SetAcceptCallback((Axiom::Socket::AcceptCallback)&server_accept,(void*)this);

	// Set the port
	m_pListenSocket->SetPort(iPort);

	// Set the state
	m_pListenSocket->SetState(Socket::SOCKET_STATE_SERVER_OPEN);
}

/* virtual */void Server::Release(void)
{
	// Make sure the socket is removed from the system
	if( m_pListenSocket != NULL )
	{
		m_pListenSocket->Close();
		m_pListenSocket = NULL;
	}
}

/* virtual */ void Server::OnDisconnect(Socket* pSocket)											
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	// Remove the slot
	RemoveSlot( pSocket );
}

// Default Accept function: Add the a base class slot that contains the connected socket.
/* virtual */ void Server::OnAccept(Socket* /*pSocket*/, Socket *pConnectedSocket)
{
//	SOCKET_ASSERTMESSAGE( pSocket == NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pConnectedSocket == NULL, "STF Error: NULL pointer passed!\n" );

	// Create the slot associated with the new socket
	Slot *pSlot = SOCKET_NEW( Slot(pConnectedSocket) );

	// Add a slot
	AddSlot( pSlot );
	pSlot->Init();
}

// Default Receive function: Send the data straight to the slot that contains the reception socket.
/* virtual */ void Server::OnReceive(Socket *pSocket, unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );

	// Find the slot and treat the instruction
	Slot *pSlot = FindSlot( pSocket );	
	SOCKET_ASSERTMESSAGE( pSlot != NULL, "STF Error: No slot has been found!\n" );
	
	pSlot->OnReceive( pMemory, iMemoryLength );

/*
	// If this slot has been substitued, remove it from our list
	if( pSlot->GetSubstitued() )
	{
		RemoveSlot(pSlot);
	}
*/
}

// Slots
void /* Server::SlotNode_s* */ Server::RemoveSlot(Socket *pSocket)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	SlotNode_s	*pPreviousNode = NULL;
	SlotNode_s	*pNode;
	int			i;
	for( i = 0, pNode = m_pSlotHeadNode ; i < m_NbSlots && pNode != NULL ; ++i, pPreviousNode = pNode, pNode = pNode->m_pNextNode )
	{
		Slot *pSlot = pNode->m_pSlot;
		if( pSlot != NULL && pSlot->GetSocket() == pSocket )
		{
			// Save the next node 
			SlotNode_s *pNextNode = pNode->m_pNextNode;
			
			// Update the node list
			if( pPreviousNode == NULL )
			{
				m_pSlotHeadNode = pNextNode;
			}
			else
			{
				pPreviousNode->m_pNextNode = pNextNode;
			}
			pNode->m_pNextNode = m_pSlotFreeNode;
			m_pSlotFreeNode = pNode;
			m_NbSlots--;

			// Destroy the slot
			delete pNode->m_pSlot;
			pNode->m_pSlot = NULL;

			return /*pNextNode*/;
		}
	}

//	return NULL;
}

void /* Server::SlotNode_s* */ Server::AddSlot(Slot *pSlot)
{
	SOCKET_ASSERTMESSAGE( pSlot != NULL, "STF Error: NULL pointer passed!\n" );

	// Use the free node
	SlotNode_s	*pNode = m_pSlotFreeNode;
	if( pNode != NULL )
	{
		// Update the node list
		m_pSlotFreeNode = pNode->m_pNextNode;
		pNode->m_pNextNode = m_pSlotHeadNode;
		m_pSlotHeadNode = pNode;
		m_NbSlots++;

		// Assign the socket
		pNode->m_pSlot = pSlot;

//		return pNode;
	}

//	return NULL;
}

void /* Server::SlotNode_s* */ Server::RemoveSlot(Slot *pSlot)
{
	SOCKET_ASSERTMESSAGE( pSlot != NULL, "STF Error: NULL pointer passed!\n" );

	SlotNode_s	*pPreviousNode = NULL;
	SlotNode_s	*pNode;
	int			i;
	for( i = 0, pNode = m_pSlotHeadNode ; i < m_NbSlots && pNode != NULL ; ++i, pPreviousNode = pNode, pNode = pNode->m_pNextNode )
	{
		if( pNode->m_pSlot == pSlot )
		{
			// Save the next node 
			SlotNode_s *pNextNode = pNode->m_pNextNode;
			
			// Update the node list
			if( pPreviousNode == NULL )
			{
				m_pSlotHeadNode = pNextNode;
			}
			else
			{
				pPreviousNode->m_pNextNode = pNextNode;
			}
			pNode->m_pNextNode = m_pSlotFreeNode;
			m_pSlotFreeNode = pNode;
			m_NbSlots--;

			// Destroy the slot
			delete pNode->m_pSlot;
			pNode->m_pSlot = NULL;

			return /*pNextNode*/;
		}
	}

//	return NULL;
}

Slot* Server::FindSlot(Socket *pSocket)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	SlotNode_s	*pNode;
	for( pNode = m_pSlotHeadNode ; pNode != NULL ; pNode = pNode->m_pNextNode )
	{
		Slot *pSlot = pNode->m_pSlot;
		if( pSlot != NULL && pSlot->GetSocket() == pSocket )
		{
			return pSlot;
		}
	}

	return NULL;
}

Slot* Server::FindSlot(unsigned int iClientID)
{
	return FindNextSlot(NULL, iClientID);
}

Slot* Server::FindNextSlot(Slot* pLastFound, unsigned int iClientID)
{
	SlotNode_s	*pNode = m_pSlotHeadNode;
	if (pLastFound!=NULL)
	{
		for(; pNode != NULL ; pNode = pNode->m_pNextNode )
		{
			if (pNode->m_pSlot == pLastFound)
			{
				pNode = pNode->m_pNextNode;
				break;
			}
		}
	}

	for(; pNode != NULL ; pNode = pNode->m_pNextNode )
	{
		Slot *pSlot = pNode->m_pSlot;
		if( pSlot != NULL && pSlot->GetClientID() == iClientID )
		{
			return pSlot;
		}
	}

	return NULL;
}


#include "Socket/Game.h"
#include "Socket/GameServer.h"
#include "Socket/GameDebugSlot.h"
#include "Socket/GameDebugInstructions.h"
#include "Socket/source/Socket.h"
#include "Socket/SocketManager.h"

void STFPrint(char *pString)
{
	static bool entered = false;
	if (entered)
		return;
	entered = true;
//#ifdef STFGAME_PRINTF
	SOCKET_ASSERTMESSAGE( pString != NULL, "STF Game Error: NULL pointer passed!\n" );

	//Ignore empty strings
	if (pString[0]==0)
		return;

	if( !Axiom::Socket::Game::IsInit() )
	{
		return;
	}

	Axiom::Socket::Game *pGame = Axiom::Socket::Game::GetInstance();
	if( pGame != NULL && pGame->PrintBroadcastingEnabled())
	{
		Axiom::Socket::GameServer *pServer = (Axiom::Socket::GameServer*)pGame->GetServer();
		if( pServer != NULL )
		{
			if( pGame->IsDebugClientConnected() )
			{
				pServer->BroadcastLogMessage(pString);
			}
		}
	}
//#endif
	entered=false;
}

// Namespace usage
using namespace Axiom;
using namespace Socket;


class SocketOutput
	: public Axiom::OutputHandler
{
	inline void Log (Axiom::ConstStr message)
	{
		STFPrint(const_cast<char*>(message));
	}

};
static SocketOutput g_SocketOutput;

// Constructor and virtual destructor

Game::Game() :
	m_pSocketManager(NULL),
	m_pServer(NULL),
	m_EventMan(NULL),
#if SOCKET_WII_DEBUGMODE
	//Turn off the sending of debug prints to Streaker for debug mode (makes it really hard to debug!)
	m_EnablePrintBroadcasting(false)
#else
	m_EnablePrintBroadcasting(true)
#endif
{
#if CORE_TOOLS
	SOCKET_ASSERTMESSAGE(false, "Game server not supported on tools side");
#else
	Axiom::InstallLogHandler(&g_SocketOutput);

	// Get/Create the native socket manager for this platform
	m_pSocketManager = SocketManager::GetNativeSocketManager();
	SOCKET_ASSERTMESSAGE(m_pSocketManager != NULL, "STF Game Error: Can't create system!\n" );

	// The game servers
	m_pServer = SOCKET_NEW( GameServer() );
	SOCKET_ASSERTMESSAGE(m_pServer != NULL, "STF Game Error: Can't create host server!\n" );

	// Get the servers alive
	m_pServer->Init(m_pSocketManager, STFGAMESERVER_TCPPORT,Socket::SOCKET_PROTOCOL_TCP);
#endif
}

/* virtual */ Game::~Game(void)
{
	SOCKET_DELETE(m_pServer);
	m_pServer = NULL;

	SOCKET_DELETE(m_pSocketManager);
	m_pSocketManager = NULL;
}


Server* Game::GetServer(void)
{ 
	return m_pServer; 
}

bool Game::IsDebugClientConnected(void)
{
	if( m_pServer != NULL )
	{
		return m_pServer->FindSlot(STFGAMESLOT_DEBUG_ID) != NULL;
	}

	return false;
}

void Game::KillInactiveGameDebugSlots(void)
{
	if( m_pServer != NULL )
	{
		Slot* slot = NULL;
		do
		{
			slot = m_pServer->FindNextSlot(slot, STFGAMESLOT_DEBUG_ID);
			if (slot!=NULL)
			{
				GameDebugSlot* gameDebugSlot = reinterpret_cast<GameDebugSlot*>(slot);
				gameDebugSlot->KillIfNotAlive();
			}
		} while (slot!=NULL);
	}
}

void Game::Update(void)
{
	m_pSocketManager->Update();
	
	int i;
	for (i=0;i<static_cast<int>(m_UpdateCallbacks.Count());i++)
	{
		m_UpdateCallbacks[i]();
	}
}

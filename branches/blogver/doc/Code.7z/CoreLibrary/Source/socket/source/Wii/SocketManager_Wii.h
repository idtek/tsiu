
#ifndef _SOCKET_SOCKETMANAGER_WII_H_
#define _SOCKET_SOCKETMANAGER_WII_H_

#include "Socket/Defines.h"

#if CORE_WII || CORE_TOOLS

#  ifndef  _SOCKET_SOCKETMANAGER_H_
#include "Socket/SocketManager.h"
#  endif

namespace Axiom
{
	namespace Socket
	{
		class SocketManager_Wii : public SocketManager
		{
		public:

			SocketManager_Wii(const int iMaxNbSockets = SOCKETMANAGER_NBSOCKETS_MAX);
			/* virtual */ ~SocketManager_Wii(void);
		
		protected:
			virtual Socket*					CreateSocket(void);									//!< Create a platform-specific socket		
		};
	}
}

# endif

#endif

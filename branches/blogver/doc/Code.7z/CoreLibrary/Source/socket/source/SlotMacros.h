
#ifndef _SOCKET_SLOTMACROS_H_
#define _SOCKET_SLOTMACROS_H_

#include "Socket/Server.h"

// Macro definitions
#define STFSLOT_SEND_INITBUFFER(__DATA__)	unsigned char aBuffer[SOCKET_TEMPBUFFER_LENGTH], *pSize, *pStart, *pBuffer;\
											Instruction_t tInstruction = static_cast<Instruction_t>(__DATA__);\
											pBuffer = Server::PushBuffer(aBuffer,&tInstruction);\
											Control_t tControl = static_cast<Control_t>(0);\
											pSize = Server::PushBuffer(pBuffer,&tControl);\
											pStart = pSize + sizeof(TransactionSize_t) + sizeof(FinalSize_t) + sizeof(PageIndex_t)

#define STFSLOT_SEND_CLOSEBUFFER			TransactionSize_t tTransactionSize = static_cast<TransactionSize_t>(pBuffer-pStart);\
											pSize = Server::PushBuffer(pSize,&tTransactionSize);\
											FinalSize_t	tFinalSize = static_cast<FinalSize_t>(tTransactionSize);\
											pSize = Server::PushBuffer(pSize,&tFinalSize);\
											PageIndex_t tPageIndex = static_cast<PageIndex_t>(0);\
											Server::PushBuffer(pSize,&tPageIndex);\
											Send(aBuffer,static_cast<int>(pBuffer-aBuffer))						

#endif

#include "Socket/GameDebugPeer.h"
#include "Socket/Slot.h"

// Namespace usage
using namespace Axiom;
using namespace Socket;

// Protected methods
bool GameDebugPeer::InitDebugFlowMemory(int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( iMemoryLength != NULL, "STF Game Error: 0 length memory passed!\n" );
	SOCKET_ASSERTMESSAGE( m_pDebugFlowMemory == NULL, "STF Game Error: Debug flow is already assigned!\n" );

	m_DebugFlowMemoryLength = iMemoryLength;
	m_pDebugFlowMemory = (unsigned char *)SOCKET_ALLOC( m_DebugFlowMemoryLength );
	m_CurrentDebugFlowMemoryIndex = 0;
	m_CurrentDebugFlowPage = 0;

	return m_pDebugFlowMemory != NULL;
}

bool GameDebugPeer::AddToDebugFlowMemory(ReadHeader *pReadHeader)
{
	SOCKET_ASSERTMESSAGE( pReadHeader != NULL, "STF Game Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( m_pDebugFlowMemory != NULL, "STF Game Error: Debug flow is not assigned!\n" );

	int iMemoryLength = pReadHeader->m_TransactionSize;

	SOCKET_MEMCPY(&m_pDebugFlowMemory[m_CurrentDebugFlowMemoryIndex],pReadHeader->m_pMemory,iMemoryLength);
	m_CurrentDebugFlowMemoryIndex += iMemoryLength;
	m_CurrentDebugFlowPage = pReadHeader->m_PageIndex;

	return m_CurrentDebugFlowMemoryIndex == m_DebugFlowMemoryLength;
}

bool GameDebugPeer::RemoveFromDebugFlowMemory(int iMemorySize)
{
	m_CurrentDebugFlowMemoryIndex += iMemorySize;
	m_CurrentDebugFlowPage++;

	return m_CurrentDebugFlowMemoryIndex == m_DebugFlowMemoryLength;
}

void GameDebugPeer::ReleaseDebugFlowMemory(void)
{
	SOCKET_ASSERTMESSAGE( m_pDebugFlowMemory != NULL, "STF Managed Error: Debug flow is not enabled!\n" );

	SOCKET_FREE( m_pDebugFlowMemory );
	m_pDebugFlowMemory = NULL;
	m_DebugFlowMemoryLength = 0;
	m_CurrentDebugFlowMemoryIndex = 0;
	m_CurrentDebugFlowPage = 0;
}

// Constructor & virtual destructor
GameDebugPeer::GameDebugPeer(void) :
	m_pDebugFlowMemory(NULL),
	m_DebugFlowMemoryLength(0),
	m_CurrentDebugFlowMemoryIndex(0),
	m_CurrentDebugFlowPage(0)
{
}

/* virtual */ GameDebugPeer::~GameDebugPeer(void)
{
}


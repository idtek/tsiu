#include "Socket/Slot.h"
#include "Socket/Instructions.h"
#include "Socket/source/Socket.h"
#include "Socket/SocketManager.h"
#include "Socket/source/SlotMacros.h"

// Namespace usage
using namespace Axiom::Socket;

/*
// Callbacks to stuff the sockets with! ;]
void slot_disconnect(Socket* pThisSocket, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual disconnect function
	Slot *pSlot = (Slot*)pData;
	pSlot->OnDisconnect();
}

void slot_connect(Socket* pThisSocket, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual connect function
	Slot *pSlot = (Slot*)pData;
	pSlot->OnConnect();
}
*/

// Protected methods
void Slot::SendInstruction(int iInstruction)
{
	Header tHeader;
	tHeader.m_Instruction = (Instruction_t)iInstruction;
	tHeader.m_Control = (Control_t)0;
	tHeader.m_TransactionSize = (TransactionSize_t)0;
	tHeader.m_FinalSize = (FinalSize_t)0;
	tHeader.m_PageIndex = (PageIndex_t)0;
	int iHeaderSize = sizeof(Header);
	Send((unsigned char*)&tHeader,iHeaderSize);
}

void Slot::ReceiveInstruction(ReadHeader *pReadHeader, unsigned char *pReceivingMemory)
{
	SOCKET_ASSERTMESSAGE( pReadHeader != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pReceivingMemory != NULL, "STF Error: NULL pointer passed!\n" );

	pReadHeader->m_pMemory = Server::PopBuffer(pReceivingMemory,(Header*)pReadHeader);
}

// Constructor and virtual destructor
Slot::Slot(Socket *pSocket) :
	m_pSocket(pSocket),
	//m_pReceivingMemory (NULL),// init in body
	m_ReceivingMemoryLength(0),
	m_ClientID(0),
	m_Substitued(false)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	// Empty the client info
	m_aClientAddress[0] = '\0';
	m_aClientMACAddress[0] = '\0';

/*
	// Add disconnect and connect callbacks
	m_pSocket->SetDisconnectCallback((Axiom::Socket::DisconnectCallback)&slot_disconnect,(void*)this);
	m_pSocket->SetConnectCallback((Axiom::Socket::ConnectCallback)&slot_connect,(void*)this);
*/

	// Allocate the buffer 32 byte aligned for Wii
	m_pReceivingMemory = (unsigned char *)SOCKET_ALLOC(SOCKET_SLOT_RECEIVINGMEMORY_LENGTH);
}

Slot::Slot(Slot *pSlot):
	m_pSocket (NULL),
	m_pReceivingMemory (NULL),
	m_ReceivingMemoryLength(0),
	m_ClientID (0),
	m_Substitued(false)	
{
	SOCKET_ASSERTMESSAGE( pSlot != NULL, "STF Error: NULL pointer passed!\n" );

	// Grab the info from the slot
	m_pSocket = pSlot->m_pSocket;
	m_ClientID = pSlot->m_ClientID;
	SOCKET_STRINGCOPY( m_aClientAddress, pSlot->m_aClientAddress, SOCKET_IPV4_IPADDRESS_LENGTH );
	SOCKET_STRINGCOPY( m_aClientMACAddress, pSlot->m_aClientMACAddress, SOCKET_IPV4_MACADDRESS_LENGTH );
	pSlot->m_Substitued = true;

/*
	// Add disconnect and connect callbacks
	m_pSocket->SetDisconnectCallback((Axiom::Socket::DisconnectCallback)&slot_disconnect,(void*)this);
	m_pSocket->SetConnectCallback((Axiom::Socket::ConnectCallback)&Slotonnect,(void*)this);
*/

	// Allocate the buffer
	// Don't copy the memory over cause it will be treated right after this...
	m_pReceivingMemory = (unsigned char *)SOCKET_ALLOC(SOCKET_SLOT_RECEIVINGMEMORY_LENGTH);
}

/* virtual */ Slot::~Slot(void)
{
	// Make sure to remove the socket (system will close it)
	if( m_pSocket != NULL )
	{
		if( !m_Substitued )
		{
			m_pSocket->Close();
		}
		m_pSocket = NULL;
	}

	// Free the receiving buffer
	SOCKET_FREE(m_pReceivingMemory);
	m_pReceivingMemory = NULL;
}

// Public methods
const bool Slot::IsClientConnected(void)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer!\n" );

	return m_pSocket->IsConnected();
}

// Public virtual methods
/* virtual */ void	Slot::Init(void)
{
}

/* virtual */ void Slot::Release(void)
{
}

/* virtual */ bool Slot::OnReceiveInstruction(ReadHeader *pReadHeader)
{
	SOCKET_ASSERTMESSAGE( pReadHeader != NULL, "STF Error: NULL pointer passed!\n" );

	int iAddressLength;
	unsigned char *pBuffer;

	switch( pReadHeader->m_Instruction )
	{
	case INSTRUCTION_BIGENDIAN:
		{
			// Check the size
			SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize == 0, "STF Error: Unexpected data received!\n" );
		
			STFSLOT_SEND_INITBUFFER(pReadHeader->m_Instruction);
				unsigned char uBigEndian = (unsigned char)CORE_BIGENDIAN; 
				pBuffer = Server::PushBuffer(pStart,&uBigEndian);
			STFSLOT_SEND_CLOSEBUFFER;
		}
		// Start the identification
		SendInstruction(INSTRUCTION_ID);
		return true;
	case INSTRUCTION_ID:
		// Check the size
		SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize > 0, "STF Error: Unexpected data received!\n" );

		// Expect an int argument
		Server::PopBuffer(pReadHeader->m_pMemory,&m_ClientID);

		// Continue the identification
		SendInstruction(INSTRUCTION_IPADDRESS);
		return true;
	case INSTRUCTION_IPADDRESS:
		// Check the size
		SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize > 0, "STF Error: Unexpected data received!\n" );

		// Expect a IP argument
		pBuffer = Server::PopBuffer(pReadHeader->m_pMemory,&iAddressLength);
		Server::PopBuffer(pBuffer,m_aClientAddress,iAddressLength);

		// Continue the identification
		SendInstruction(INSTRUCTION_MACADDRESS);
		return true;
	case INSTRUCTION_MACADDRESS:
		// Check the size
		SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize > 0, "STF Error: Unexpected data received!\n" );

		// Expect a MAC argument
		pBuffer = Server::PopBuffer(pReadHeader->m_pMemory,&iAddressLength);
		Server::PopBuffer(pBuffer,m_aClientMACAddress,iAddressLength);
		return true;
	default:
		break;
	}

	return false;
}

/*
virtual void Slot::OnDisconnect(void)
{
	int iTrace = 0;
	iTrace++;
}

virtual void Slot::OnConnect(void)
{
	int iTrace = 0;
	iTrace++;
}
*/

/* virtual */ void Slot::OnReceive(unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength < ( SOCKET_SLOT_RECEIVINGMEMORY_LENGTH - m_ReceivingMemoryLength ), "STF Error: About to overflow the entire receiving buffer!\n" );

	// Concat the received memory at the bottom of the buffer
	SOCKET_MEMCPY( &m_pReceivingMemory[m_ReceivingMemoryLength], pMemory, iMemoryLength * sizeof(unsigned char) );
	m_ReceivingMemoryLength += iMemoryLength;

	// Check if we got the expected chunk
	int				iHeaderSize = sizeof(Header);
	while( m_ReceivingMemoryLength >= iHeaderSize )
	{
		// Grab the header
		ReadHeader tReadHeader;
		ReceiveInstruction( &tReadHeader, m_pReceivingMemory );

		// Check the size of the entire buffer
		const int iTotalLength =  iHeaderSize + tReadHeader.m_TransactionSize;
		if( m_ReceivingMemoryLength >= iTotalLength )
		{
			// Perform the receiving buffer
			OnReceiveInstruction(&tReadHeader);

			if( m_ReceivingMemoryLength > iTotalLength )	// Bring the rest of the memory to the bottom of the overflow memory
			{
				m_ReceivingMemoryLength -= iTotalLength;	// TODO: Remove the memory copy and get a linear treatment
				SOCKET_MEMCPY( m_pReceivingMemory, &m_pReceivingMemory[iTotalLength], m_ReceivingMemoryLength * sizeof(unsigned char) );
			}
			else											// Or make sure to come back from the top of the buffer
			{
				m_ReceivingMemoryLength = 0;
			}
		}
		else
		{
			return;
		}
	};
}

/* virtual */ void Slot::Send(unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer!\n" );

	m_pSocket->Send(pMemory,iMemoryLength);
}

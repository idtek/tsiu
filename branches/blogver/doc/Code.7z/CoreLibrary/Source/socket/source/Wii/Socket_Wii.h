
#ifndef _SOCKET_SOCKET_WII_H_
#define _SOCKET_SOCKET_WII_H_

#include "Socket/Defines.h"

#if CORE_WII || CORE_TOOLS

#include "Socket/source/Socket.h"

#include <revolution/hio2.h>

namespace Axiom
{
	namespace Socket
	{
		class Socket_Wii : public Socket
		{
		public:

			// Constructor and virtual destructor
			Socket_Wii(SocketManager* socketManager);
			/* virtual */ ~Socket_Wii(void);
	
			// Public virtual methods
			/* virtual */ void			GetLocalAddress(IPV4Address*);
			/* virtual */ void			GetLocalMACAddress(MACAddress_s*);

			/* virtual */ SocketError	Send(unsigned char *pMemory = 0, int iMemoryLength = 0);

		protected:

			// Protected virtual methods
			/* virtual */ SocketError	Open(void);
			/* virtual */ SocketError	Close(void);

			/* virtual */ SocketError	Bind(void);
			/* virtual */ SocketError	Listen(void);
			/* virtual */ SocketError	Accept(void);

			/* virtual */ SocketError	Connect(void);
			/* virtual */ SocketError	Receive(void);

		private:

			// Private member variables
			HIO2Handle		m_Handle;
			bool			m_ConnectionOpened;
			bool			m_HIO2Started;
			bool			m_Closing;
			bool			m_AbortPending;

			void			FlushSendBuffer(void);
			void			AbortConnection(void);
			void			AbortConnectionNextUpdate(void);

			static void OnReceive( HIO2Handle h );
#if CORE_TOOLS
			static BOOL EnumDevices( HIO2DevicePath path, void* param );
			static int OnNotification( HIO2NotifyEvent e, void* param );
			HIO2DevicePath  m_Device;
#else  // !CORE_TOOLS
			static void OnDisconnect( HIO2Handle handle );
			static BOOL EnumDevices( HIO2DeviceType type );
			HIO2DeviceType  m_Device;
#endif // CORE_TOOLS

#if !CORE_TOOLS
			SocketError SendOpenRequest();
#endif
			static void PrintHIO2ErrorDetails();
		};
	} // namespace Socket
}

# endif

#endif
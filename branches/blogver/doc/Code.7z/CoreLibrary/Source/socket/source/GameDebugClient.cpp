#include "Socket/GameDebugClient.h"

// Namespace usage
using namespace Axiom::Socket;

// Constructor and virtual destructor
GameDebugClient::GameDebugClient(void) :
	Client()
{
	// Make sure the ID is correct
	SetID(STFGAMESLOT_DEBUG_ID);
	m_TimeSinceLastActivity = 0;
	m_ConnectionOpened = false;
}

/* virtual */ GameDebugClient::~GameDebugClient(void)
{
}

void GameDebugClient::ResetKeepAliveTimeout()
{
	m_TimeSinceLastActivity = 0;
}

// Callback
void gameclientdebugslot_update(Socket* pThisSocket, void *pData)
{
// 	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );
// 
// 	// Call the virtual connect function
	GameDebugClient *pClient = (GameDebugClient*)pData;
	pClient->UpdateKeepAlive();
}

// Public virtual methods
void GameDebugClient::Init(SocketManager* socketManager, const char *pAddress, int iPort, int iProtocol)
{
	m_ConnectionOpened = false;
	ResetKeepAliveTimeout();

	// Call base class init
	Client::Init(socketManager, pAddress, iPort, iProtocol);

	// Set the update callback
	m_pSocket->SetUpdateCallback((Axiom::Socket::UpdateCallback)&gameclientdebugslot_update,(void*)this);
}

void GameDebugClient::UpdateKeepAlive(void)
{
	if (m_ConnectionOpened)
	{	
		m_TimeSinceLastActivity++;
	}
}


/* virtual */ void GameDebugClient::OnReceive(unsigned char *pMemory, int iMemoryLength)
{
	if (m_pSocket==NULL)
		return; //Probably in the process of connect/shutdown

	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );
//	SOCKET_ASSERTMESSAGE( iMemoryLength < ( STFSYSTEM_SLOT_RECEIVINGMEMORY_LENGTH - m_ReceivingMemoryLength ), "STF Error: About to overflow the entire receiving buffer!\n" );
	ResetKeepAliveTimeout();
	m_ConnectionOpened = true;

	while( iMemoryLength > 0 )
	{
		int iMaxReceivingMemoryLength = SOCKET_SLOT_RECEIVINGMEMORY_LENGTH - m_ReceivingMemoryLength;
		int iReceivingMemoryLength = ( iMemoryLength > iMaxReceivingMemoryLength ? iMaxReceivingMemoryLength : iMemoryLength );

		// Concat the received memory at the bottom of the buffer
		memcpy( &m_pReceivingMemory[m_ReceivingMemoryLength], pMemory, iReceivingMemoryLength * sizeof(unsigned char) );
		m_ReceivingMemoryLength += iReceivingMemoryLength;
		
		// Move on
		iMemoryLength -= iReceivingMemoryLength;
		pMemory += iReceivingMemoryLength;

		// Check if we got the expected chunk
		int		iHeaderSize = sizeof(Header);
		bool	bTransactionComplete = true;
		while( m_ReceivingMemoryLength >= iHeaderSize && bTransactionComplete )
		{
			// Grab the header
			ReadHeader tReadHeader;
			ReceiveInstruction( &tReadHeader );

			// Check the size of the entire buffer
			const int iTotalLength =  iHeaderSize + tReadHeader.m_TransactionSize;
//			SOCKET_ASSERTMESSAGE( iTotalLength < STFSYSTEM_SLOT_RECEIVINGMEMORY_LENGTH, "STF Error: Expected buffer can't fit in our slot!\n" );

			if( m_ReceivingMemoryLength >= iTotalLength )
			{
				// Perform the receiving buffer
				OnReceiveInstruction(&tReadHeader);

				if( m_ReceivingMemoryLength > iTotalLength )	// Bring the rest of the memory to the bottom of the overflow memory
				{
					m_ReceivingMemoryLength -= iTotalLength;
					memcpy( m_pReceivingMemory, &m_pReceivingMemory[iTotalLength], m_ReceivingMemoryLength * sizeof(unsigned char) );
				}
				else											// Or make sure to come back from the top of the buffer
				{
					m_ReceivingMemoryLength = 0;
				}
			}
			else
			{
				bTransactionComplete = false;
			}
		};
	};
}

/*virtual*/ void GameDebugClient::OnDisconnect(void)
{
	Client::OnDisconnect();
}


// Public methods
void GameDebugClient::SendFlow(int iInstruction, unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Game Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Game Error: 0 memory length passed!\n" );

	unsigned char	aBuffer[SOCKET_DEBUGSENDBUFFER_LENGTH], *pSize, *pStart, *pBuffer;
	Instruction_t	tInstruction = static_cast<Instruction_t>(iInstruction);
	Control_t		tControl = (Control_t)0;
	FinalSize_t		tFinalSize = (FinalSize_t)iMemoryLength;
	PageIndex_t		tPageIndex = (PageIndex_t)0;

	// Setup the send buffer
	pBuffer = PushBuffer(aBuffer, &tInstruction);
	pSize = PushBuffer(pBuffer, &tControl);
	pStart = pSize + sizeof(TransactionSize_t) + sizeof(FinalSize_t) + sizeof(PageIndex_t);	// Jump over the sizes

	int		iMaxSendingMemoryLength = SOCKET_DEBUGSENDBUFFER_LENGTH - sizeof(Header);
	bool	bTooBig = iMemoryLength > iMaxSendingMemoryLength;
	if( bTooBig )	// If the memory you're trying to send is too big, use the DebugFlow memory
	{
		SOCKET_ASSERTMESSAGE( GetGameDebugPeer()->m_pDebugFlowMemory == NULL, "STF Game Error: Debug flow is already assigned!\n" );

		GetGameDebugPeer()->InitDebugFlowMemory( iMemoryLength );
		memcpy( GetGameDebugPeer()->m_pDebugFlowMemory, pMemory, iMemoryLength );
	}

	pBuffer = PushBuffer(pStart, pMemory, ( bTooBig ? iMaxSendingMemoryLength : iMemoryLength ) );

	// Update the size
	TransactionSize_t tTransactionSize = static_cast<TransactionSize_t>(pBuffer-pStart);
	pSize = PushBuffer(pSize, &tTransactionSize);	
	pSize = PushBuffer(pSize, &tFinalSize);	
	PushBuffer(pSize, &tPageIndex);

	// Send the buffer
	Send(aBuffer, static_cast<int>(pBuffer-aBuffer));

	// Update the debug flow memory
	if( bTooBig )
	{
		GetGameDebugPeer()->RemoveFromDebugFlowMemory( static_cast<int>(tTransactionSize) );
	}
}

void GameDebugClient::SendFlow(Instruction_t tInstruction)
{
	unsigned char	aBuffer[SOCKET_DEBUGSENDBUFFER_LENGTH], *pSize, *pStart, *pBuffer;
	Control_t		tControl = (Control_t)0;
	FinalSize_t		tFinalSize = (FinalSize_t)GetGameDebugPeer()->m_DebugFlowMemoryLength;
	PageIndex_t		tPageIndex = (PageIndex_t)GetGameDebugPeer()->m_CurrentDebugFlowPage;

	// Setup the send buffer
	pBuffer = PushBuffer(aBuffer, &tInstruction);
	pSize = PushBuffer(pBuffer, &tControl);
	pStart = pSize + sizeof(TransactionSize_t) + sizeof(FinalSize_t) + sizeof(PageIndex_t);	// Jump over the sizes

	int				iMaxSendingMemoryLength = SOCKET_DEBUGSENDBUFFER_LENGTH - sizeof(Header);
	unsigned char	*pMemory = &GetGameDebugPeer()->m_pDebugFlowMemory[GetGameDebugPeer()->m_CurrentDebugFlowMemoryIndex];
	int				iMemoryLength = GetGameDebugPeer()->m_DebugFlowMemoryLength - GetGameDebugPeer()->m_CurrentDebugFlowMemoryIndex;

	pBuffer = PushBuffer(pStart, pMemory, ( iMemoryLength > iMaxSendingMemoryLength ? iMaxSendingMemoryLength : iMemoryLength ) );

	// Update the size
	TransactionSize_t tTransactionSize = static_cast<TransactionSize_t>(pBuffer-pStart);
	pSize = PushBuffer(pSize, &tTransactionSize);	
	pSize = PushBuffer(pSize, &tFinalSize);	
	PushBuffer(pSize, &tPageIndex);

	// Send the buffer
	Send(aBuffer, static_cast<int>(pBuffer-aBuffer));

	// Update the debug flow memory
	GetGameDebugPeer()->RemoveFromDebugFlowMemory( static_cast<int>(tTransactionSize) );
}

#include "Socket/Defines.h"

#if CORE_WII || CORE_TOOLS

#include "Socket/source/Wii/SocketManager_Wii.h"
#include "Socket/source/Wii/Socket_Wii.h"
#include <revolution/hio2.h>

// Namespace usage
using namespace Axiom::Socket;

#if !CORE_TOOLS
// Get the singleton socket manager that is native to the current platform
static SocketManager_Wii* sSocketManager = NULL;
/*static*/ SocketManager* SocketManager::GetNativeSocketManager()
{
	if (sSocketManager==NULL)
	{
		sSocketManager = SOCKET_NEW( SocketManager_Wii(SOCKETMANAGER_NBSOCKETS_MAX) );
	}
	return sSocketManager;
}
#endif

// Creator implementation
/*virtual*/ Socket* SocketManager_Wii::CreateSocket(void)
{
	return SOCKET_NEW( Socket_Wii(this) );
}

// Constructor and virtual destructor
SocketManager_Wii::SocketManager_Wii(const int iMaxNbSockets /*= SOCKETMANAGER_NBSOCKETS_MAX*/) :
	SocketManager(iMaxNbSockets)
{
}

/* virtual */ SocketManager_Wii::~SocketManager_Wii(void)
{
}

#endif

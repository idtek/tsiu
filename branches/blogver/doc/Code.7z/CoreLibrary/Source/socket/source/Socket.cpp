#include "Socket/source/Socket.h"			// Nobody needs to know what's inside a socket! ;]
#include "Socket/SocketManager.h"

// Namespace usage
using namespace Axiom::Socket;

// Static local variables
static Socket::Update_f	s_aUpdateFunctions[] = { &Axiom::Socket::Socket::_Update_SERVER,	// SOCKET_CLASS_SERVER
													 &Axiom::Socket::Socket::_Update_CLIENT,	// SOCKET_CLASS_CLIENT
													 &Axiom::Socket::Socket::_Update_CLIENT };	// SOCKET_CLASS_SLOT

// Protected virtual methods
/* virtual */ SocketError Socket::Open(void)
{
	if( m_pReceivingMemory == NULL )
	{
		// Allocate the buffer 32 byte aligned for Wii
		m_pReceivingMemory = (unsigned char *)SOCKET_ALLOC( SOCKET_SOCKET_RECEIVINGMEMORY_LENGTH );
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket::Close(void)
{
	// Make the socket will get removed next update
	SetState(SOCKET_STATE_REMOVE);

	// Reset the properties
	m_Class = static_cast<unsigned int>(SocketLASS_INVALID);
	m_Family = static_cast<unsigned int>(SOCKET_FAMILY_INVALID);
	m_Type = static_cast<unsigned int>(SOCKET_TYPE_INVALID);
	m_Protocol = static_cast<unsigned int>(SOCKET_PROTOCOL_INVALID);

	// Freeing reception memory
	if( m_pReceivingMemory != NULL )
	{
		SOCKET_FREE(m_pReceivingMemory);
		m_pReceivingMemory = NULL;
	}

	return SOCKET_ERROR_OK;
}

// Constructor and virtual destructor
Socket::Socket(SocketManager* socketManager) :	
	m_Class(static_cast<unsigned int>(SocketLASS_INVALID)),
	m_AddressIsURL(false),
	m_Protocol(static_cast<unsigned int>(SOCKET_PROTOCOL_INVALID)),
	m_Type(static_cast<unsigned int>(SOCKET_TYPE_INVALID)),
	m_Family(static_cast<unsigned int>(SOCKET_FAMILY_INVALID)),
	m_State(static_cast<unsigned int>(SOCKET_STATE_INVALID)),
	m_Port(0),
	m_pReceivingMemory(NULL),
	m_ReceivingMemoryLength(0),
	m_MaxNbConnections(0),		// Will set m_Connected to false
	m_pSocketManager(socketManager),
	m_pfUpdate(&Axiom::Socket::Socket::_Update_DEFAULT)
{

	// Empty the address
	m_aAddress[0] = '\0';	

	// Callbacks
	m_DisconnectCallback.m_pfCallback = NULL;
	m_DisconnectCallback.m_pData = NULL;
	m_ReceiveCallback.m_pfCallback = NULL;
	m_ReceiveCallback.m_pData = NULL;
	m_AcceptCallback.m_pfCallback = NULL;
	m_AcceptCallback.m_pData = NULL;
	m_UpdateCallback.m_pfCallback = NULL;
	m_UpdateCallback.m_pData = NULL;
}

/* virtual */ Socket::~Socket(void)
{
}

// Public functions
void Socket::SetProperties(SOCKET_CLASS_e eClass, SOCKET_FAMILY_e eFamily, SOCKET_TYPE_e eType, SOCKET_PROTOCOL_e eProtocol)
{
	SetClass( eClass );
	SetFamily( eFamily );

	// TODO: Is that right? I think so! 
	if( eProtocol == SOCKET_PROTOCOL_UDP )
	{
		eType = SOCKET_TYPE_DATAGRAM;
	}

	SetType( eType );
	SetProtocol( eProtocol );
}

void Socket::SetProperties(Socket *pSocket)
{
	SOCKET_ASSERTMESSAGE( pSocket != NULL, "STF Error: NULL pointer passed!\n" );

	SetClass( pSocket->GetClass() );
	SetFamily( pSocket->GetFamily() );
	SetType( pSocket->GetType() );
	SetProtocol( pSocket->GetProtocol() );
}

void Socket::SetClass(SOCKET_CLASS_e eClass)
{
	// Set the class and its virtual function up
	m_Class = eClass;
	m_pfUpdate = s_aUpdateFunctions[m_Class];
	// Set the socket to an idle state
	SetState( SOCKET_STATE_IDLE );
}

void Socket::SetAddressPort(const char *pAddress, int iPort)
{
	SOCKET_ASSERTMESSAGE( pAddress != NULL, "STF Error: NULL pointer passed!\n" );

	SOCKET_STRINGCOPY( m_aAddress, pAddress, SOCKET_IPV4_URL_LENGTH );
	m_AddressIsURL = ( SocketManager::GetAddressIsURL( m_aAddress ) ? 1 : 0 );
	m_Port = iPort;
}

void Socket::_Update_DEFAULT(void)
{
	// Leave it empty!
}

void Socket::_Update_SERVER(void)
{
	switch( GetState() )
	{
	case SOCKET_STATE_SERVER_OPEN:
		// Open the socket
		if( Open() == SOCKET_ERROR_OK )
		{
			// Go to the next state
			SetState( SOCKET_STATE_SERVER_LISTEN );
		}
		break;
	case SOCKET_STATE_SERVER_LISTEN:
		// Bind on the address and port
		if( Bind() == SOCKET_ERROR_OK )
		{
			// Start listening
			if( Listen() == SOCKET_ERROR_OK )
			{
				// Go to the next state
				SetState( SOCKET_STATE_SERVER_ACCEPT );
			}
		}
		break;
	case SOCKET_STATE_SERVER_ACCEPT:
		// Accept a connection
		if( Accept() == SOCKET_ERROR_OK )
		{
			// No next state, keep accepting connections
		}
		break;
	case SOCKET_STATE_SERVER_CLOSE:
		// Close the socket
		if( Close() == SOCKET_ERROR_OK )
		{
			// Go to the next state
//			SetState( SOCKET_STATE_REMOVE );	// NB: This is performed by the close method
		}
		break;
	default:
		break;
	}
	
	// Call this every time
	CallUpdateCallback();
}

void Socket::_Update_CLIENT(void)
{
	switch( GetState() )
	{
	case SOCKET_STATE_CLIENT_OPEN:
		// Open the socket
		if( Open() == SOCKET_ERROR_OK )
		{
			// Go to the next state
			SetState( SOCKET_STATE_CLIENT_CONNECT );
		}
		break;
	case SOCKET_STATE_CLIENT_CONNECT:
		// Connect the socket
		if( Connect() == SOCKET_ERROR_OK )
		{
			// Go to the next state
			SetState( SOCKET_STATE_CLIENT_RECEIVE );
		}
		break;
	case SOCKET_STATE_CLIENT_RECEIVE:
		// Read from the socket
		if( Receive() == SOCKET_ERROR_OK )
		{
			// No next state, keep reading incoming information
		}
		break;
	case SOCKET_STATE_CLIENT_CLOSE:
		// Close the socket
		if( Close() == SOCKET_ERROR_OK )
		{
			// Go to the next state
//			SetState( SOCKET_STATE_REMOVE );	// NB: This is performed by the close method
		}
		break;
	default:
		break;
	}

	// Call this every time
	CallUpdateCallback();
}

#include "Socket/Client.h"
#include "Socket/SocketManager.h"
#include "Socket/Slot.h"
#include "Socket/Instructions.h"
#include "Socket/source/Socket.h"
#include "Socket/source/ClientMacros.h"

// Namespace usage
using namespace Axiom::Socket;

// Callbacks to stuff the sockets with! ;]
void client_disconnect(Socket* /*pThisSocket*/, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual disconnect function
	Client *pClient = (Client*)pData;
	pClient->OnDisconnect();
}

void Clientonnect(Socket* /*pThisSocket*/, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual connect function
	Client *pClient = (Client*)pData;
	pClient->OnConnect();
}

void client_receive(Socket* /*pThisSocket*/, void *pData, unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	// Call the virtual receive function
	Client *pClient = (Client*)pData;
	pClient->OnReceive(pMemory,iMemoryLength);
}

// Protected methods
void Client::SendInstruction(int iInstruction)
{
	// Push type by type to handle the potential endian conversion
	STFCLIENT_SEND_INITBUFFER(iInstruction);
	pBuffer = pStart;
	STFCLIENT_SEND_CLOSEBUFFER;
}

void Client::ReceiveInstruction(ReadHeader *pReadHeader)
{
	// Pop type by type to handle the potential endian conversion
	unsigned char *pMemory = PopBuffer(m_pReceivingMemory,&( pReadHeader->m_Instruction ));
	pMemory = PopBuffer(pMemory,&( pReadHeader->m_Control ));
	pMemory = PopBuffer(pMemory,&( pReadHeader->m_TransactionSize ));
	pMemory = PopBuffer(pMemory,&( pReadHeader->m_FinalSize ));
	pReadHeader->m_pMemory = PopBuffer(pMemory,&( pReadHeader->m_PageIndex ));

	// Special case for (the first) endian instruction 
	if( pReadHeader->m_Instruction == (Instruction_t)INSTRUCTION_BIGENDIAN && pReadHeader->m_TransactionSize > 1 )
	{
		// We're assuming the endian is different, so let's correct the size!
		pReadHeader->m_TransactionSize = (TransactionSize_t)1;
		pReadHeader->m_FinalSize = (FinalSize_t)1;
		pReadHeader->m_PageIndex = (PageIndex_t)0;
	}
}

// Constructor and virtual destructor
Client::Client(void) :
m_pSocket(NULL),
m_ReceivingMemoryLength(0),
m_ServerIsDifferentEndian(false),
m_ID(0xbaddc0de)
{
	// Allocate the buffer 32 byte aligned for Wii
	m_pReceivingMemory = (unsigned char *)SOCKET_ALLOC( SOCKET_CLIENT_RECEIVINGMEMORY_LENGTH );
}

/* virtual */ Client::~Client(void)
{
	// Free the buffer
	if( m_pReceivingMemory != NULL )
	{
		SOCKET_FREE(m_pReceivingMemory);
		m_pReceivingMemory = NULL;
	}

	SOCKET_ASSERTMESSAGE(m_pSocket==NULL, "Client::Release() was never called");
}

// Public methods

// Helpers for data socket
void Client::GetLocalAddress(IPV4Address *pIPAddress)
{
	SOCKET_ASSERTMESSAGE( pIPAddress != NULL, "STF Error: NULL pointer passed!\n" );

	m_pSocket->GetLocalAddress(pIPAddress);
}

const char* Client::GetAddress(void)
{
	return m_pSocket->GetAddress();
}

const bool Client::IsAddressURL(void)
{
	return m_pSocket->IsAddressURL();
}

const int Client::GetPort(void)
{
	return m_pSocket->GetPort();
}

const bool Client::IsConnected(void)
{
	return m_pSocket->IsConnected();
}

// Data transfer functions
/* virtual */void Client::Init(SocketManager* socketManager, const char *pAddress, int iPort, int iProtocol)
{
	SOCKET_ASSERTMESSAGE( pAddress != NULL, "STF Error: NULL pointer passed!\n");
	SOCKET_ASSERTMESSAGE( iPort > 0, "STF Error: Port has to be greater than 0!\n");

	// Create the socket
	m_pSocket = socketManager->AddSocket();
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "" );

	// Set the property
	m_pSocket->SetProperties(Socket::SOCKET_CLASS_CLIENT, Socket::SOCKET_FAMILY_IPV4, Socket::SOCKET_TYPE_STREAM, (Socket::SOCKET_PROTOCOL_e)iProtocol);

	// Set the callbacks
	void *dataptr = (void*)this;
	m_pSocket->SetDisconnectCallback((Axiom::Socket::DisconnectCallback)&client_disconnect,dataptr);
	m_pSocket->SetConnectCallback((Axiom::Socket::ConnectCallback)&Clientonnect,dataptr);
	m_pSocket->SetReceiveCallback((Axiom::Socket::ReceiveCallback)&client_receive,dataptr);

	// Set the address and port
	m_pSocket->SetAddressPort(pAddress,iPort);	

	// Set the state
	m_pSocket->SetState(Socket::SOCKET_STATE_CLIENT_OPEN);
}

/* virtual */void Client::Release(void)
{
	// Make sure to remvoe the socket (system will close it)
	if( m_pSocket != NULL )
	{
		Socket* socket = m_pSocket;
		m_pSocket = NULL;
		socket->Close(); //This will cause OnDisconnect which will try to release the client again, thus setting m_pSocket to NULL first
	}
}

/* virtual */ bool Client::OnReceiveInstruction(ReadHeader *pReadHeader)
{
	SOCKET_ASSERTMESSAGE( pReadHeader != NULL, "STF Error: NULL pointer passed!\n" );

	switch( pReadHeader->m_Instruction )
	{
	case INSTRUCTION_BIGENDIAN:
		{
			// Check the size
			SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize == sizeof(char), "STF Error: Unexpected sized buffer received!\n" );

			// Expect a char argument
			unsigned char uBigEndian = (unsigned char)CORE_BIGENDIAN; // Init with the client's endian
			PopBuffer(pReadHeader->m_pMemory,&uBigEndian);

			// Assign the info
			m_ServerIsDifferentEndian = ( uBigEndian != (unsigned char)CORE_BIGENDIAN );
		}
		return true;
	case INSTRUCTION_ID:
		{
			// Check the size
			SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize == 0, "STF Error: Unexpected data received!\n" );

			STFCLIENT_SEND_INITBUFFER(pReadHeader->m_Instruction);
			pBuffer = PushBuffer(pStart,&m_ID);
			STFCLIENT_SEND_CLOSEBUFFER;
		}
		return true;
	case INSTRUCTION_IPADDRESS:
		{
			// Make sure the size is 0
			SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize == 0, "STF Error: Unexpected data received!\n" );

			STFCLIENT_SEND_INITBUFFER(pReadHeader->m_Instruction);
			IPV4Address tIPAddress;
			m_pSocket->GetLocalAddress(&tIPAddress);
			char aAddress[SOCKET_IPV4_IPADDRESS_LENGTH];
			SOCKET_STRINGFORMAT4(aAddress, SOCKET_IPV4_IPADDRESS_LENGTH, "%i.%i.%i.%i",tIPAddress.m_aBytes[0],tIPAddress.m_aBytes[1],tIPAddress.m_aBytes[2],tIPAddress.m_aBytes[3]);
			int iAddressLength = (int)SOCKET_STRINGLENGTH(aAddress)+1;			// Don't forget to include the '\0' at the end!
			pBuffer = PushBuffer(pStart,&iAddressLength);
			pBuffer = PushBuffer(pBuffer,aAddress,iAddressLength);
			STFCLIENT_SEND_CLOSEBUFFER;
		}
		return true;
	case INSTRUCTION_MACADDRESS:
		{
			// Make sure the size is 0
			SOCKET_ASSERTMESSAGE( pReadHeader->m_TransactionSize == 0, "STF Error: Unexpected data received!\n" );

			STFCLIENT_SEND_INITBUFFER(pReadHeader->m_Instruction);
			MACAddress_s tMACAddress;
			m_pSocket->GetLocalMACAddress(&tMACAddress);
			char aMACAddress[SOCKET_IPV4_MACADDRESS_LENGTH];
			SOCKET_STRINGFORMAT6(aMACAddress, SOCKET_IPV4_MACADDRESS_LENGTH, "%2x:%2x:%2x:%2x:%2x:%2x",tMACAddress.m_aBytes[0],tMACAddress.m_aBytes[1],tMACAddress.m_aBytes[2],tMACAddress.m_aBytes[3],tMACAddress.m_aBytes[4],tMACAddress.m_aBytes[5]);
			int iMACAddressLength = (int)SOCKET_STRINGLENGTH(aMACAddress)+1;		// Don't forget to include the '\0' at the end!
			pBuffer = PushBuffer(pStart,&iMACAddressLength);
			pBuffer = PushBuffer(pBuffer,aMACAddress,iMACAddressLength);
			STFCLIENT_SEND_CLOSEBUFFER;
		}
		return true;
	default:
		break;
	}

	return false;
}

/* virtual */ void Client::OnDisconnect(void)
{
	// Make sure that the reference of the socket is nulled,
	// the socket will be removed and destroyed by the system itself.
	m_pSocket = NULL;
}

/* virtual */ void Client::OnConnect(void)
{
	// Ask the server to send the big endian
	SendInstruction(INSTRUCTION_BIGENDIAN);	
}

/* virtual */ void Client::OnReceive(unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer!\n" );
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength < ( SOCKET_CLIENT_RECEIVINGMEMORY_LENGTH - m_ReceivingMemoryLength ), "STF Error: About to overflow the entire receiving buffer!\n" );

	// Concat the received memory at the bottom of the buffer
	SOCKET_MEMCPY( &m_pReceivingMemory[m_ReceivingMemoryLength], pMemory, iMemoryLength * sizeof(unsigned char) );
	m_ReceivingMemoryLength += iMemoryLength;

	// Check if we got the expected chunk
	int	iHeaderSize = sizeof(Header);
	while( m_ReceivingMemoryLength >= iHeaderSize )
	{
		// Grab the header
		ReadHeader tReadHeader;
		ReceiveInstruction(&tReadHeader);

		// Check the size of the entire buffer
		const int iTotalLength = iHeaderSize + tReadHeader.m_TransactionSize;
		if( m_ReceivingMemoryLength >= iTotalLength )
		{
			// Perform the receiving buffer
			OnReceiveInstruction(&tReadHeader);

			if( m_ReceivingMemoryLength > iTotalLength )	// Bring the rest of the memory to the bottom of the overflow memory
			{
				m_ReceivingMemoryLength -= iTotalLength;
				SOCKET_MEMCPY( m_pReceivingMemory, &m_pReceivingMemory[iTotalLength], m_ReceivingMemoryLength * sizeof(unsigned char) );
			}
			else											// Or make sure to come back from the top of the buffer
			{
				m_ReceivingMemoryLength = 0;
			}
		}
		else
		{
			return;
		}
	};
}

/* virtual */ void Client::Send(unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer!\n" );

	m_pSocket->Send(pMemory,iMemoryLength);
}



#include "Socket/Defines.h"

#if CORE_PS3

#include "Socket/source/PS3/SocketManager_PS3.h"
#include "Socket/source/PS3/Socket_PS3.h"

// Namespace usage
using namespace Axiom::Socket;

// Static private member variables
bool SocketManager_PS3::m_sNetworkStarted = false;

#if !CORE_TOOLS
// Get the singleton socket manager that is native to the current platform
static SocketManager_PS3* sSocketManager = NULL;
/*static*/ SocketManager* SocketManager::GetNativeSocketManager()
{
	if (sSocketManager==NULL)
	{
		sSocketManager = SOCKET_NEW( SocketManager_PS3(SOCKETMANAGER_NBSOCKETS_MAX) );
	}
	return sSocketManager;
}
#endif

/*virtual*/ Socket* SocketManager_PS3::CreateSocket(void)
{
	return SOCKET_NEW( Socket_PS3(this) );
}

// Constructor and virtual destructor
SocketManager_PS3::SocketManager_PS3(const int iMaxNbSockets /*= SOCKETMANAGER_NBSOCKETS_MAX*/) :
	SocketManager(iMaxNbSockets)
{
	if( !m_sNetworkStarted )
	{
		m_sNetworkStarted = true;
	}
}

/* virtual */ SocketManager_PS3::~SocketManager_PS3(void)
{
	if( m_sNetworkStarted )
	{
		m_sNetworkStarted = false;
	}
}

#endif

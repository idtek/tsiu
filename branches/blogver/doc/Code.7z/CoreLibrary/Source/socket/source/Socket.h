#ifndef _SOCKET_SOCKET_H_
#define _SOCKET_SOCKET_H_

#include "Socket/Defines.h"

// Prototypes in context
namespace Axiom
{
	namespace Socket
	{
		class Socket;
		class SocketManager;

		static const int MACADDRESS_LENGTH = 6;
		typedef struct MACAddress_s
		{
			unsigned char m_aBytes[MACADDRESS_LENGTH];

		} MACAddress_s;

		static const int IPV4ADDRESS_LENGTH = 4;
		typedef union IPV4Address
		{
			unsigned long m_aUnsignedLong;
			unsigned char m_aBytes[IPV4ADDRESS_LENGTH];

		} IPV4Address;

		// Function pointer types
		typedef void (*DisconnectCallback)(Socket*,void*);
		typedef void (*ReceiveCallback)(Socket*,void*,unsigned char*,int);
		typedef void (*AcceptCallback)(Socket*,void*,Socket*);
		typedef void (*ConnectCallback)(Socket*,void*);
		typedef void (*UpdateCallback)(Socket*,void*);

		// Prototype
		class Socket 
		{
		public:

			// Public enumerations
			enum SOCKET_CLASS_e
			{
				SOCKET_CLASS_SERVER,
				SOCKET_CLASS_CLIENT,
				SOCKET_CLASS_SLOT,

				SOCKET_NBCLASSES,
				SocketLASS_INVALID = SOCKET_NBCLASSES,
			};

			enum SOCKET_FAMILY_e
			{
				SOCKET_FAMILY_UNKNOWN,
				SOCKET_FAMILY_IPV4,
				SOCKET_FAMILY_IPV6,			// Unsupported on Xbox360
				SOCKET_FAMILY_IRDA,			// Unsupported on Xbox360

				SOCKET_NBFAMILIES,
				SOCKET_FAMILY_INVALID = SOCKET_NBFAMILIES,
			};

			enum SOCKET_TYPE_e
			{
				SOCKET_TYPE_STREAM,
				SOCKET_TYPE_DATAGRAM,
				SOCKET_TYPE_RAW,			// Unsupported on Xbox360

				SOCKET_NBTYPES,
				SOCKET_TYPE_INVALID = SOCKET_NBTYPES,
			};

			enum SOCKET_PROTOCOL_e
			{
				SOCKET_PROTOCOL_TCP,
				SOCKET_PROTOCOL_UDP,

				SOCKET_NBPROTOCOLS,
				SOCKET_PROTOCOL_INVALID = SOCKET_NBPROTOCOLS,
			};

			enum SOCKET_STATE_e
			{
				SOCKET_STATE_IDLE,
				SOCKET_STATE_REMOVE,

				SOCKET_STATE_SERVER_OPEN,
				SOCKET_STATE_SERVER_LISTEN,
				SOCKET_STATE_SERVER_ACCEPT,
				SOCKET_STATE_SERVER_CLOSE,

				SOCKET_STATE_CLIENT_OPEN,
				SOCKET_STATE_CLIENT_CONNECT,
				SOCKET_STATE_CLIENT_RECEIVE,
				SOCKET_STATE_CLIENT_CLOSE,

				SOCKET_NBSTATES,
				SOCKET_STATE_INVALID = SOCKET_NBSTATES,
			};

			// Constructor and virtual destructor
			Socket(SocketManager* socketManager);
			virtual ~Socket(void);

			// Public methods
			void							Release(void);

			// Properties
			void							SetProperties(SOCKET_CLASS_e,SOCKET_FAMILY_e,SOCKET_TYPE_e,SOCKET_PROTOCOL_e);
			void							SetProperties(Socket*);
			void							SetClass(SOCKET_CLASS_e);
			inline const SOCKET_CLASS_e		GetClass(void);
			inline void						SetFamily(SOCKET_FAMILY_e);
			inline const SOCKET_FAMILY_e	GetFamily(void);
			inline void						SetType(SOCKET_TYPE_e);
			inline const SOCKET_TYPE_e		GetType(void);
			inline void						SetProtocol(SOCKET_PROTOCOL_e);
			inline const SOCKET_PROTOCOL_e	GetProtocol(void);

			// Connections
			inline void						SetMaxNbConnections(const int);		// For server sockets
			inline const int				GetMaxNbConnections(void);
			inline void						SetConnected(const bool);			// For client sockets
			inline const bool				IsConnected(void);

			// State
			inline void						SetState(SOCKET_STATE_e);
			inline const SOCKET_STATE_e		GetState(void);

			// Address and port
			void							SetAddressPort(const char*,int);
			inline void						SetPort(int);
			inline const char*				GetAddress(void);
			inline const bool				IsAddressURL(void);
			inline const int				GetPort(void);

			// Setting up the callbacks
			inline void						SetDisconnectCallback(DisconnectCallback,void*);
			inline void						SetReceiveCallback(ReceiveCallback,void*);
			inline void						SetAcceptCallback(AcceptCallback,void*);
			inline void						SetConnectCallback(ConnectCallback,void*);
			inline void						SetUpdateCallback(UpdateCallback,void*);

			// Main update function
			inline void						Update(void);

			// Function pointer type
			typedef void (Socket::*Update_f)(void);

			// "Virtual" update functions
			void							_Update_DEFAULT(void);
			void							_Update_SERVER(void);
			void							_Update_CLIENT(void);

			// Public virtual methods
			virtual void					GetLocalAddress(IPV4Address*) = 0;
			virtual void					GetLocalMACAddress(MACAddress_s*) = 0;

			virtual SocketError				Send(unsigned char*,int) = 0;

			virtual SocketError				Close(void);
			inline void						CallUpdateCallback(void);

		protected:

			inline SocketManager*			GetSocketManager() { return m_pSocketManager; }

			// Protected methods
			inline void						CallDisconnectCallback(void);
			inline void						CallReceiveCallback(void);
			inline void						CallAcceptCallback(Socket*);
			inline void						CallConnectCallback(void);

			// Protected virtual methods
			virtual SocketError				Open(void);
//			virtual SocketError				Close(void);

			virtual SocketError				Bind(void) = 0;
			virtual SocketError				Listen(void) = 0;
			virtual SocketError				Accept(void) = 0;

			virtual SocketError				Connect(void) = 0;
			virtual SocketError				Receive(void) = 0;

			// Protected member variables

			// Properties of the socket
			unsigned int					m_Class:3;
			unsigned int					m_AddressIsURL:1;
			unsigned int					m_Protocol:4;
			unsigned int					m_Type:8;
			unsigned int					m_Family:8;
			unsigned int					m_State:8;

			// Address & Port
			char							m_aAddress[SOCKET_IPV4_URL_LENGTH];
			unsigned int					m_Port;

			// Sending and reception memory
			unsigned char					*m_pReceivingMemory;		// For client sockets
			int								m_ReceivingMemoryLength;	// For client sockets

			// Connections
			union
			{
				int							m_MaxNbConnections;			// For server sockets
				bool						m_Connected;				// For client sockets
			};

		private:

			// Private structures
			struct DisconnectCallbackHandle
			{
				DisconnectCallback	m_pfCallback;	
				void					*m_pData;

			};
			struct ReceiveCallbackHandle
			{
				ReceiveCallback		m_pfCallback;	
				void					*m_pData;

			};
			struct AcceptCallbackHandle
			{
				AcceptCallback		m_pfCallback;
				void					*m_pData;

			};
			struct ConnectCallbackHandle
			{
				ConnectCallback		m_pfCallback;
				void					*m_pData;

			};
			struct UpdateCallbackHandle
			{
				UpdateCallback		m_pfCallback;
				void					*m_pData;

			};

			// Private member variables
			SocketManager* m_pSocketManager;

			// The update function table and pointer
			Update_f					m_pfUpdate;

			// The callbacks to hanle disconnection, send and receive data
			DisconnectCallbackHandle		m_DisconnectCallback;
			ReceiveCallbackHandle			m_ReceiveCallback;		
			union
			{
				AcceptCallbackHandle		m_AcceptCallback;		// For server sockets
				ConnectCallbackHandle		m_ConnectCallback;		// For client sockets
			};
			UpdateCallbackHandle			m_UpdateCallback;		

		};

		// Protected inline implementation
		inline void Socket::CallDisconnectCallback(void)
		{
			if( m_DisconnectCallback.m_pfCallback != 0 )
			{
				(*m_DisconnectCallback.m_pfCallback)(this,m_DisconnectCallback.m_pData);
			}
		};

		inline void Socket::CallReceiveCallback(void)
		{
			if( m_ReceiveCallback.m_pfCallback != 0 )
			{
				(*m_ReceiveCallback.m_pfCallback)(this,m_ReceiveCallback.m_pData,m_pReceivingMemory, m_ReceivingMemoryLength);
			}
		};

		inline void Socket::CallAcceptCallback(Socket *pSocket)
		{
			if( m_AcceptCallback.m_pfCallback != 0 )
			{
				(*m_AcceptCallback.m_pfCallback)(this,m_AcceptCallback.m_pData,pSocket);
			}
		};

		inline void Socket::CallConnectCallback(void)
		{
			if( m_ConnectCallback.m_pfCallback != 0 )
			{
				(*m_ConnectCallback.m_pfCallback)(this,m_ConnectCallback.m_pData);
			}
		};

		inline void Socket::CallUpdateCallback(void)
		{
			if( m_UpdateCallback.m_pfCallback != 0 )
			{
				(*m_UpdateCallback.m_pfCallback)(this,m_UpdateCallback.m_pData);
			}
		};

		// Public inline implementation
		inline const Socket::SOCKET_CLASS_e Socket::GetClass(void)
		{
			return static_cast<SOCKET_CLASS_e>(m_Class);
		};

		inline void Socket::SetFamily(SOCKET_FAMILY_e eFamily)
		{
			SOCKET_ASSERTMESSAGE( eFamily == SOCKET_FAMILY_UNKNOWN || eFamily == SOCKET_FAMILY_IPV4, "STF Error: IPv4 is the only transport family supported!\n" );

			m_Family = static_cast<unsigned int>(eFamily);
		};

		inline const Socket::SOCKET_FAMILY_e Socket::GetFamily(void)
		{
			return static_cast<SOCKET_FAMILY_e>(m_Family);
		};

		inline void Socket::SetType(SOCKET_TYPE_e eType)
		{
			SOCKET_ASSERTMESSAGE( eType == SOCKET_TYPE_STREAM || eType == SOCKET_TYPE_DATAGRAM, "STF Error: IPv4 is the only transport family supported!\n" );

			m_Type = static_cast<unsigned int>(eType);
		};

		inline const Socket::SOCKET_TYPE_e Socket::GetType(void)
		{
			return static_cast<SOCKET_TYPE_e>(m_Type);
		};

		inline void Socket::SetProtocol(SOCKET_PROTOCOL_e eProtocol)
		{
			m_Protocol = static_cast<unsigned int>(eProtocol);
		};

		inline const Socket::SOCKET_PROTOCOL_e Socket::GetProtocol(void)
		{
			return static_cast<SOCKET_PROTOCOL_e>(m_Protocol);
		};

		inline void Socket::SetState(SOCKET_STATE_e eState)
		{
			m_State = static_cast<unsigned int>(eState);
		};

		inline const Socket::SOCKET_STATE_e Socket::GetState(void)
		{
			return static_cast<SOCKET_STATE_e>(m_State);
		};

		inline void Socket::SetMaxNbConnections(const int iMaxNbConnections)	// For server sockets
		{
			if( m_Class == SOCKET_CLASS_SERVER )
			{
				m_MaxNbConnections = iMaxNbConnections;
			}
		};

		inline const int Socket::GetMaxNbConnections(void)
		{
			return ( m_Class == SOCKET_CLASS_SERVER ? m_MaxNbConnections : 0 );
		};

		inline void Socket::SetConnected(const bool bConnected)				// For client sockets
		{
			if( m_Class == SOCKET_CLASS_CLIENT )
			{
				m_Connected = bConnected;
			}
		};

		inline const bool Socket::IsConnected(void)
		{
			return m_Class == SOCKET_CLASS_CLIENT ? m_Connected : false;
		};

		inline const char* Socket::GetAddress(void)
		{
			return m_aAddress;
		};

		inline const bool Socket::IsAddressURL(void)
		{
			return m_AddressIsURL;
		};

		inline void Socket::SetPort(int iPort)
		{
			m_Port = iPort;
		};

		inline const int Socket::GetPort(void)
		{
			return m_Port;
		};

		inline void Socket::SetDisconnectCallback(DisconnectCallback pfCallback, void *pData)
		{
			m_DisconnectCallback.m_pfCallback = pfCallback;
			m_DisconnectCallback.m_pData = pData;
		};

		inline void Socket::SetReceiveCallback(ReceiveCallback pfCallback, void *pData)
		{
			m_ReceiveCallback.m_pfCallback = pfCallback;
			m_ReceiveCallback.m_pData = pData;
		};

		inline void Socket::SetAcceptCallback(AcceptCallback pfCallback, void *pData)
		{
			if( m_Class == SOCKET_CLASS_SERVER )
			{
				m_AcceptCallback.m_pfCallback = pfCallback;
				m_AcceptCallback.m_pData = pData;
			}
		};

		inline void Socket::SetConnectCallback(ConnectCallback pfCallback, void *pData)
		{
			if( m_Class == SOCKET_CLASS_CLIENT )
			{
				m_ConnectCallback.m_pfCallback = pfCallback;
				m_ConnectCallback.m_pData = pData;
			}
		};

		inline void Socket::SetUpdateCallback(UpdateCallback pfCallback, void *pData)
		{
			m_UpdateCallback.m_pfCallback = pfCallback;
			m_UpdateCallback.m_pData = pData;
		};

		inline void Socket::Update(void)
		{
			(this->*m_pfUpdate)();
		};
	}
}

#endif


#include "Socket/Defines.h"

#if CORE_PS3

#include "Socket/source/PS3/Socket_PS3.h"
#include "Socket/SocketManager.h"

#include <netex/errno.h>
#include <netex/net.h>
#include <netex/libnetctl.h>
#include <netdb.h>

// Namespace usage
using namespace Axiom::Socket;

// Static local variables
static int s_aSocketFamilyLookUpTable[Socket::SOCKET_NBFAMILIES] = { AF_UNSPEC,   // SOCKET_FAMILY_UNKNOWN
																	   AF_INET,		// SOCKET_FAMILY_IPV4
																	   AF_INET6 };	// SOCKET_FAMILY_IPV6
//																	   AF_IRDA		// SOCKET_FAMILY_IRDA - Unsupported

static int s_aSocketTypeLookUpTable[Socket::SOCKET_NBTYPES] = { SOCK_STREAM,		// SOCKET_TYPE_STREAM
																  SOCK_DGRAM,		// SOCKET_TYPE_DATAGRAM
																  SOCK_RAW };		// SOCKET_TYPE_RAW

static int s_aSocketProtocolLookUpTable[Socket::SOCKET_NBPROTOCOLS] = { IPPROTO_TCP,		// SOCKET_PROTOCOL_TCP 
																		  IPPROTO_UDP };	// SOCKET_PROTOCOL_UDP

// Private methods
SocketError Socket_PS3::GetSockAddressFromAddress(sockaddr_in *pSockAddress, char *pAddress /*= 0*/, int iPort /*= 0*/)
{
	SOCKET_ASSERTMESSAGE( pSockAddress != NULL, "STF Error: NULL pointer passed!\n" );

	// Put the port (Class' if 0) in a character string
	if( iPort == 0 )
	{
		SOCKET_ASSERTMESSAGE( m_Port != 0, "STF Error: 0 is an unsupported port!\n" );

		iPort = m_Port;
	}

	// Put the address (Class' if 0)
	if( pAddress == 0 /*&& m_aAddress[0] != '\0'*/ )
	{
		pAddress = m_aAddress;
	}

	// Fill up the structure 
	SOCKET_MEMSET(pSockAddress,0,sizeof(sockaddr_in));
	pSockAddress->sin_len = sizeof(sockaddr_in);
	pSockAddress->sin_family = s_aSocketFamilyLookUpTable[m_Family];
	pSockAddress->sin_port = htons(iPort);
	pSockAddress->sin_addr.s_addr = SocketManager::GetLongFromAddress(pAddress);

	return SOCKET_ERROR_OK;
}

SocketError Socket_PS3::GetSockAddressFromURL(sockaddr_in *pSockAddress, char *pURL /*= 0*/, int iPort /*= 0*/)
{
	SOCKET_ASSERTMESSAGE( pSockAddress != NULL, "STF Error: NULL pointer passed!\n" );

	// Put the port (Class' if 0) in a character string
	if( iPort == 0 )
	{
		SOCKET_ASSERTMESSAGE( m_Port != 0, "STF Error: 0 is an unsupported port!\n" );

		iPort = m_Port;
	}
	char aPort[6];
	SOCKET_STRINGFORMAT1(aPort, array_count(aPort), "%i",iPort);

	// Put the address (Class' if 0)
	if( pURL == 0 /*&& m_aAddress[0] != '\0' && m_AddressIsURL*/ )
	{
		pURL = m_aAddress;
	}

	// Resolve the name
	hostent *pHostEntity = gethostbyname(pURL);
	if( pHostEntity == NULL )
	{
/*
		// Get the error
		int iError = WSAGetLastError();
		if( iError == )
		{
		}
*/
		return SOCKET_ERROR_CANTRESOLVEURL;
	}

	// Fill up the address
	in_addr tAddress;
	SOCKET_MEMCPY(&tAddress,pHostEntity->h_addr_list[0],sizeof(unsigned char)*4);

	// Fill up the structure 
	SOCKET_MEMSET(pSockAddress,0,sizeof(sockaddr_in));
	pSockAddress->sin_len = sizeof(sockaddr_in);
	pSockAddress->sin_family = s_aSocketFamilyLookUpTable[m_Family];
	pSockAddress->sin_port = htons(iPort);
	pSockAddress->sin_addr = tAddress;

	return SOCKET_ERROR_OK;
}

// Protected virtual functions
/* virtual */ SocketError Socket_PS3::Open(void)
{
	// Call the base method
	Socket::Open();

	if( m_Handle < 0 )
	{
		int state;
		if (cellNetCtlGetState(&state)<0)
			return SOCKET_ERROR_CANTOPENSOCKET;
		if (state!=CELL_NET_CTL_STATE_IPObtained)
			return SOCKET_ERROR_CANTOPENSOCKET;
		CellNetCtlInfo info;
		if (cellNetCtlGetInfo(CELL_NET_CTL_INFO_IP_ADDRESS, &info)<0)
			return SOCKET_ERROR_CANTOPENSOCKET;
		Axiom::Log("SOCKET", "Opening PS3 NET socket with local IP Address = %s", info.ip_address);

		// Make sure to convert the arguments accordingly to the platform
		int family = s_aSocketFamilyLookUpTable[m_Family];
		int type = s_aSocketTypeLookUpTable[m_Type];
		int protocol = s_aSocketProtocolLookUpTable[m_Protocol];
		m_Handle = socket(family,type,protocol);
		if( m_Handle < 0 )
		{
			// Get the error
			int iError = sys_net_errno;
			Axiom::Log("SOCKET", "Socket::Open error: socket returned %d", iError);

			return SOCKET_ERROR_CANTOPENSOCKET;
		}

		// Set this socket to non-blocking
		int iMode = 1;
		setsockopt(m_Handle, SOL_SOCKET, SO_NBIO, &iMode, sizeof(int));

		// Allow broadcast for UDP
		if( m_Type == SOCKET_TYPE_DATAGRAM )
		{
			unsigned long uMode = 1;
			setsockopt(m_Handle, SOL_SOCKET, SO_BROADCAST, (char*)&uMode, sizeof(uMode));
		}
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Close(void)
{
	if( m_Handle >= 0 )
	{
		if( m_Class == SOCKET_CLASS_CLIENT || m_Class == SOCKET_CLASS_SLOT )
		{
			SetConnected(false);
		}

		// Perform callback
		CallDisconnectCallback();

		// Close winsock socket
		shutdown( m_Handle, SHUT_RDWR );
		socketclose(m_Handle);
		m_Handle = -1;

		// Call the base method
		return Socket::Close();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Bind(void)
{
	if( m_Handle >= 0 )
	{
		// Bind on local address
		sockaddr_in tSockAddress;
		GetSockAddressFromAddress(&tSockAddress);

		// Start binding 
		int iResult = bind(m_Handle,(sockaddr*)&tSockAddress,sizeof(tSockAddress));
		if( iResult < 0 )
		{
/*
			// Get the error
			int iError = sys_net_errno;
			if( iError == )
			{
			}
*/
			Close();
			return SOCKET_ERROR_CANTBINDSOCKET;
		}

		// Call the base method
//		return Socket::Bind();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Listen(void)
{
	if( m_MaxNbConnections > 0 && m_Handle >= 0 )
	{
		int iResult = listen( m_Handle, m_MaxNbConnections );
		if( iResult < 0 )
		{
/*
			// Get the error
			int iError = sys_net_errno;
			if( iError == )
			{
			}
*/
			Close();
			return SOCKET_ERROR_CANTBINDSOCKET;
		}

		// Call the base method
//		return Socket::Listen();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Accept(void)
{
	if( m_Handle >= 0 )
	{
		// Get the client socket handle from the server socket
		int iSocket = accept( m_Handle, NULL, NULL );
		if( iSocket < 0 )
		{
			// Check if no connection is getting through
			int iError = sys_net_errno;
			if( iError == SYS_NET_EWOULDBLOCK )
			{
				return SOCKET_ERROR_PASSED;
			}

			Close();
			return SOCKET_ERROR_CANTLISTENSOCKET;
		}

		// Set this socket to non-blocking
		int iMode = 1;
		setsockopt( iSocket, SOL_SOCKET, SO_NBIO, &iMode, sizeof(int) );

		// Allow broadcast for UDP
		if( m_Type == SOCKET_TYPE_DATAGRAM )
		{
			unsigned long uMode = 1;
			setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, (char*)&uMode, sizeof(uMode));
		}

		// Add one of our socket to the process
		Socket_PS3 *pSocket = (Socket_PS3*)GetSocketManager()->AddSocket();
		pSocket->SetHandle( iSocket );

		// Make sure it's a client one
		pSocket->SetProperties( SOCKET_CLASS_SLOT, (SOCKET_FAMILY_e)m_Family, (SOCKET_TYPE_e)m_Type, (SOCKET_PROTOCOL_e)m_Protocol );

		// Call the base class open method
		pSocket->Socket::Open();

		// Set the client socket up on the right state
		pSocket->SetState(SOCKET_STATE_CLIENT_RECEIVE);

		// Perform callback
		CallAcceptCallback(pSocket);
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Connect(void)
{
	if( m_Handle >= 0 )
	{
		// Connect on given address
		sockaddr_in tSockAddress;
		if( m_AddressIsURL )
		{
			GetSockAddressFromURL(&tSockAddress,m_aAddress);
		}
		else
		{
			GetSockAddressFromAddress(&tSockAddress,m_aAddress);
		}

		// Start the connection
		int iResult = connect(m_Handle,(sockaddr*)&tSockAddress,sizeof(tSockAddress));
		if( iResult < 0 )
		{
			// Get the error
			int iError = sys_net_errno;
			if( iError == SYS_NET_ERROR_EWOULDBLOCK /* Non-blocking */ || iError == SYS_NET_ERROR_EALREADY /* In progress */ || iError == SYS_NET_ERROR_EINVAL /* Invalid, can happen on non-blocking */ )
			{
				return SOCKET_ERROR_PASSED;
			}
			if( iError == SYS_NET_ERROR_EISCONN /* Socket is already connected */ )
			{
				SetConnected(true);

				// Perform callback
				CallConnectCallback();

				// Call the base method
//				return Socket::Connect();
				return SOCKET_ERROR_OK;
			}

			Close();
			return SOCKET_ERROR_CANTCONNECTSOCKET;
		}

		// NOTE: Because the socket is non-blocking, it should never get to this point.
		SetConnected(true);

		// Perform callback
		CallConnectCallback();

		// Call the base method
//		return Socket::Connect();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_PS3::Receive(void)
{
	if( m_Handle >= 0 )
	{
		int iResult = recv(m_Handle,(char*)m_pReceivingMemory,SOCKET_SOCKET_RECEIVINGMEMORY_LENGTH,0);
		if( iResult < 0 )
		{
			// Get the error
			int iError = sys_net_errno;
			if( iResult == SYS_NET_ERROR_EWOULDBLOCK  || iError == SYS_NET_ERROR_EWOULDBLOCK)
			{
				return SOCKET_ERROR_PASSED;
			}

			Close();
			return SOCKET_ERROR_CANTRECEIVESOCKET;
		}
		if( iResult == 0 )
		{
			Close();
			return SOCKET_ERROR_DISCONNECTEDSOCKET;
		}

		// Assign memory length
		m_ReceivingMemoryLength = iResult;

		// Perform callback	
		CallReceiveCallback();

		// Call the base method
//		return Socket::Receive();
	}

	return SOCKET_ERROR_OK;
}

// Constructor and virtual destructor
Socket_PS3::Socket_PS3(SocketManager* socketManager) :
	Socket(socketManager),
	m_Handle(-1)
{
}

/* virtual */ Socket_PS3::~Socket_PS3(void)
{
}

// Public methods
void Socket_PS3::SetHandle(int uHandle)
{
	m_Handle = uHandle;
}

// Public virtual functions
/* virtual */ void Socket_PS3::GetLocalAddress(IPV4Address *pIPAddress)
{
	// The info of an empty host
	sockaddr_in tSockAddress;
	GetSockAddressFromURL(&tSockAddress,"");

	SOCKET_MEMCPY(pIPAddress, &( tSockAddress.sin_addr ), 4);
}

/* virtual */ void Socket_PS3::GetLocalMACAddress(MACAddress_s *pMACAddress)
{
	// Clear up the address
	SOCKET_MEMSET(pMACAddress, 0, sizeof(MACAddress_s));

	CellNetCtlInfo tInfo;
	if( cellNetCtlGetInfo( CELL_NET_CTL_INFO_ETHER_ADDR, &tInfo ) != 0 )
	{
		SOCKET_ASSERTMESSAGE( false, "STF Error: Can't get MAC address!\n" );
	}

	SOCKET_MEMCPY(pMACAddress, &tInfo.ether_addr, sizeof(MACAddress_s));
}

/* virtual */ SocketError Socket_PS3::Send(unsigned char *pMemory /*= 0*/, int iMemoryLength /*=0*/)
{
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );

	if( m_Handle >= 0 )
	{
		int iResult = send(m_Handle,(char*)pMemory,iMemoryLength,0);
		if( iResult < 0 )
		{
			// Get the error
			int iError = sys_net_errno;
			if( iResult == SYS_NET_ERROR_EWOULDBLOCK && iError == SYS_NET_ERROR_EWOULDBLOCK )
			{
				return SOCKET_ERROR_PASSED;
			}

			Close();
			return SOCKET_ERROR_CANTSENDSOCKET;
		}

		// Call the base method
//		return Socket::Send(pMemory,iMemoryLength);
	}

	return SOCKET_ERROR_OK;
}

#endif

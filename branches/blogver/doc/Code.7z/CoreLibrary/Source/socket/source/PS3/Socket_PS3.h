
#ifndef _SOCKET_SOCKET_PS3_H_
#define _SOCKET_SOCKET_PS3_H_

#include "Socket/Defines.h"

# if CORE_PS3

#include "Socket/source/Socket.h"
#include <sys/socket.h>
#include <netinet/in.h>

namespace Axiom
{
	namespace Socket
	{
		class Socket_PS3 : public Socket
		{
		public:

			// Constructor and virtual destructor
			Socket_PS3(SocketManager* socketManager);
			/* virtual */ ~Socket_PS3(void);

			// Public methods
			void								SetHandle(int);
	
			// Public virtual methods
			/* virtual */ void					GetLocalAddress(IPV4Address*);
			/* virtual */ void					GetLocalMACAddress(MACAddress_s*);

			/* virtual */ SocketError			Send(unsigned char *pMemory = 0, int iMemoryLength = 0);

		protected:

			// Protected virtual methods
			/* virtual */ SocketError	Open(void);
			/* virtual */ SocketError	Close(void);

			/* virtual */ SocketError	Bind(void);
			/* virtual */ SocketError	Listen(void);
			/* virtual */ SocketError	Accept(void);

			/* virtual */ SocketError	Connect(void);
			/* virtual */ SocketError	Receive(void);

		private:

			// Private member variables

			// WinSock handle of the socket
			int				m_Handle;

			// Private methods

			// DNS functions
			SocketError		GetSockAddressFromAddress(sockaddr_in *pSockAddress, char *pAddress = 0, int iPort = 0);
			SocketError		GetSockAddressFromURL(sockaddr_in *pSockAddress, char *pURL = 0, int iPort = 0);

		};
	}
}

# endif

#endif

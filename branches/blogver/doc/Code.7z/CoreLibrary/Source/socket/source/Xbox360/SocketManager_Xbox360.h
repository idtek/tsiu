
#ifndef _SOCKET_SOCKETMANAGER_XBOX360_H_
#define _SOCKET_SOCKETMANAGER_XBOX360_H_

#include "Socket/Defines.h"

#if CORE_XBOX360

#  ifndef  _SOCKET_SOCKETMANAGER_H_
#include "Socket/SocketManager.h"
#  endif

namespace Axiom
{
	namespace Socket
	{
		class SocketManager_Xbox360 : public SocketManager
		{
		public:

			// Constructor and virtual destructor
			SocketManager_Xbox360(const int iMaxNbSockets = SOCKETMANAGER_NBSOCKETS_MAX);	
			/* virtual */ ~SocketManager_Xbox360(void);
		
		protected:
			virtual Socket*					CreateSocket(void);									//!< Create a platform-specific socket

		private:

			// Static private member variables
			static bool		m_sWinSockStarted;
			static int		m_sWinSockVersion;

		};
	}
}

# endif

#endif

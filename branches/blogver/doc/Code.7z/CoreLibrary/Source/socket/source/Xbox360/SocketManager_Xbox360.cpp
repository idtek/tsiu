#include "Socket/Defines.h"

#if CORE_XBOX360

#include "Socket/source/Xbox360/SocketManager_Xbox360.h"
#include "Socket/source/Xbox360/Socket_Xbox360.h"

#include <winsockx.h>

// Namespace usage
using namespace Axiom::Socket;

// Static private member variables
bool	SocketManager_Xbox360::m_sWinSockStarted = false;
int		SocketManager_Xbox360::m_sWinSockVersion = 0;

#if !CORE_TOOLS
// Get the singleton socket manager that is native to the current platform
static SocketManager_Xbox360* sSocketManager = NULL;
/*static*/ SocketManager* SocketManager::GetNativeSocketManager()
{
	if (sSocketManager==NULL)
	{
		sSocketManager = SOCKET_NEW( SocketManager_Xbox360(SOCKETMANAGER_NBSOCKETS_MAX) );
	}
	return sSocketManager;
}
#endif

// Creator implementation
/*virtual*/ Socket* SocketManager_Xbox360::CreateSocket(void)
{
	return SOCKET_NEW( Socket_Xbox360(this) );
}

// Constructor and virtual destructor
SocketManager_Xbox360::SocketManager_Xbox360(const int iMaxNbSockets /*= SOCKETMANAGER_NBSOCKETS_MAX*/) :
	SocketManager(iMaxNbSockets)
{
	if( !m_sWinSockStarted )
	{
		// Prepare arguments
		XNetStartupParams xnsParams;
		SOCKET_MEMSET( &xnsParams, 0, sizeof( XNetStartupParams ) );
		xnsParams.cfgSizeOfStruct = sizeof( XNetStartupParams );
		xnsParams.cfgFlags = XNET_STARTUP_BYPASS_SECURITY;

		// XNet startup	
		int iResult = XNetStartup( &xnsParams );

		SOCKET_ASSERTMESSAGE( iResult == 0, "STF Error: XNet can't startup!\n" );

		// Get the winsock system going
		WSADATA wsaData;
		SOCKET_MEMSET( &wsaData, 0, sizeof(wsaData) );

		// Try to startup winsock up to the 2.2 version
		iResult = WSAStartup( MAKEWORD(2,2) ,&wsaData );
		if( iResult != 0 )
		{
			return;
		}

		// Store the version number
		m_sWinSockVersion = (LOBYTE(wsaData.wVersion)<<8)|HIBYTE(wsaData.wVersion);
							
		// Keep log of the creation of winsock	
		m_sWinSockStarted = true;
	}
}

/* virtual */ SocketManager_Xbox360::~SocketManager_Xbox360(void)
{
	if( m_sWinSockStarted )
	{
		// Destroy the winsock system
		WSACleanup();
		m_sWinSockVersion = 0;

	    // XNet cleanup
	    XNetCleanup();

		m_sWinSockStarted = false;
	}
}

#endif

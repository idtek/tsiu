
#ifndef _SOCKET_SOCKET_XBOX360_H_
#define _SOCKET_SOCKET_XBOX360_H_

#include "Socket/Defines.h"

#if CORE_XBOX360

#include "Socket/source/Socket.h"

namespace Axiom
{
	namespace Socket
	{
		class Socket_Xbox360 : public Socket
		{
		public:

			// Constructor and virtual destructor
			Socket_Xbox360(SocketManager* socketManager);
			/* virtual */ ~Socket_Xbox360(void);

			// Public methods
			void						SetHandle(SOCKET);

			// Public virtual methods
			/* virtual */ void			GetLocalAddress(IPV4Address*);
			/* virtual */ void			GetLocalMACAddress(MACAddress_s*);

			/* virtual */ SocketError	Send(unsigned char *pMemory = 0, int iMemoryLength = 0);

		protected:

			// Protected virtual methods
			/* virtual */ SocketError	Open(void);
			/* virtual */ SocketError	Close(void);

			/* virtual */ SocketError	Bind(void);
			/* virtual */ SocketError	Listen(void);
			/* virtual */ SocketError	Accept(void);

			/* virtual */ SocketError	Connect(void);
			/* virtual */ SocketError	Receive(void);

		private:

			// Private member variables

			// WinSock handle of the socket
			SOCKET			m_Handle;

			// DNS functions
			SocketError			GetSockAddressFromAddress(sockaddr_in*,char *pAddress = 0,int iPort = 0);
			SocketError			GetSockAddressFromURL(sockaddr_in*,char *pURL = 0,int iPort = 0);

		};
	}
}

# endif

#endif
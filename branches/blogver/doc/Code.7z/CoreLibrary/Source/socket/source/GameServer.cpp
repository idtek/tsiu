#include "Socket/GameServer.h"
#include "Socket/GameDebugSlot.h"
#include "Socket/Instructions.h"
#include "Socket/GameDebugInstructions.h"
#include "Socket/Game.h"
#include "Socket/SocketManager.h"
#include "Socket/source/Socket.h"

// Namespace usage
using namespace Axiom::Socket;

// Game Pending Slot

// Constructor and virtual destructor
GamePendingSlot::GamePendingSlot(Socket *pSocket) :
	Slot(pSocket)
{
}

/* virtual */ GamePendingSlot::~GamePendingSlot(void)
{
}

// Public virtual methods
/* virtual */ bool GamePendingSlot::OnReceiveInstruction(ReadHeader *pReadHeader)
{
	// Call the base class
	bool bResult = Slot::OnReceiveInstruction(pReadHeader);

	switch(pReadHeader->m_Instruction)
	{
	// Handle some feedback from default instructions
	case INSTRUCTION_ID:
		{
			Game *pGame = Game::GetInstance();

			// Use the client's ID to create the right slot
			Slot *pSlot = NULL;
			switch( GetClientID() )
			{
			case STFGAMESLOT_DEBUG_ID:
				pSlot = SOCKET_NEW( GameDebugSlot(this) );
				break;
			default:
				break;
			}

			SOCKET_ASSERTMESSAGE( pSlot != NULL, "STF Game Error: Client ID not recognized!\n" );
			
			//Check all existing GameDebugSlots and kill them if they are no longer alive
			pGame->KillInactiveGameDebugSlots();

			// Add the new slot to the server
			Server *pServer = pGame->GetServer();
			pServer->AddSlot( pSlot );
			pSlot->Init();
			
			pServer->RemoveSlot( this );
		}
		return true;
		
	default:
		break;
	}

	return bResult;
}

// Game Server

// Constructor and virtual destructor
GameServer::GameServer(void) :
	Server(STFGAMESERVER_NBCONNECTIONS_MAX)
{
}

/* virtual */ GameServer::~GameServer(void)
{
}

// Public virtual methods
/* virtual */ void GameServer::OnAccept(Axiom::Socket::Socket* /*pSocket*/,Axiom::Socket::Socket *pConnectedSocket)
{
	SOCKET_ASSERTMESSAGE( pConnectedSocket != NULL, "STF Game Error: NULL pointer passed!\n" );

	// Note: We're not calling the base class' method but we're keeping the same logic.

	// Creating a pending slot
	const unsigned int allocSize = Axiom::Math::Max( sizeof( GamePendingSlot ), sizeof( GameDebugSlot ) );
	void* alloc = SOCKET_ALLOC( allocSize );
	Slot* pSlot = SOCKET_PLACEMENT_NEW( alloc ) GamePendingSlot( pConnectedSocket );

	AddSlot( pSlot );
	pSlot->Init();
}


void GameServer::BroadcastLogMessage(const char* message)
{
	SlotNode_s	*pNode;
	for( pNode = m_pSlotHeadNode ; pNode != NULL ; pNode = pNode->m_pNextNode )
	{
		Slot *pSlot = pNode->m_pSlot;
		if( pSlot != NULL && pSlot->GetClientID() == STFGAMESLOT_DEBUG_ID )
		{
			reinterpret_cast<GameDebugSlot*>(pSlot)->QueueLogMessage(message);
		}
	}
}

#include "Socket/Defines.h"

#if CORE_WIN32

#include "Socket/source/Win32/SocketManager_Win32.h"
#include "Socket/source/Win32/Socket_Win32.h"

#include <winsock2.h>

// Namespace usage
using namespace Axiom::Socket;

// Static private member variables
bool	SocketManager_Win32::m_sWinSockStarted = false;
int		SocketManager_Win32::m_sWinSockVersion = 0;

#if !CORE_TOOLS
// Get the singleton socket manager that is native to the current platform
static SocketManager_Win32* sSocketManager = NULL;
/*static*/ SocketManager* SocketManager::GetNativeSocketManager()
{
	if (sSocketManager==NULL)
	{
		sSocketManager = SOCKET_NEW( SocketManager_Win32(SOCKETMANAGER_NBSOCKETS_MAX) );
	}
	return sSocketManager;
}
#endif

// Creator implementation
/*virtual*/ Socket* SocketManager_Win32::CreateSocket(void)
{
	return SOCKET_NEW( Socket_Win32(this) );
}

// Constructor and virtual destructor
SocketManager_Win32::SocketManager_Win32(const int iMaxNbSockets /*= SOCKETMANAGER_NBSOCKETS_MAX*/) :
	SocketManager(iMaxNbSockets)
{
	if( !m_sWinSockStarted )
	{
		// Get the winsock system going
		WSADATA wsaData;
		SOCKET_MEMSET( &wsaData, 0, sizeof(wsaData) );

		// Try to startup winsock up to the 2.2 version
		int iResult = WSAStartup( MAKEWORD(2,2) ,&wsaData );
		if( iResult != 0 )
		{
			return;
		}

		// Store the version number
		m_sWinSockVersion = (LOBYTE(wsaData.wVersion)<<8)|HIBYTE(wsaData.wVersion);
							
		// Keep log of the creation of winsock	
		m_sWinSockStarted = true;
	}
}

/* virtual */ SocketManager_Win32::~SocketManager_Win32(void)
{
	if( m_sWinSockStarted )
	{
		// Destroy the winsock system
		WSACleanup();
		m_sWinSockVersion = 0;

		m_sWinSockStarted = false;
	}
}

#endif


#include "Socket/GameDebugSlot.h"
#include "Socket/Server.h"
#include "Socket/GameDebugInstructions.h"
#include "Socket/source/Socket.h"
#include "Socket/Game.h"
#include "reflection/textserializer.h"
#include "eventsystem/eventman.h"
#include "core/time.h"
 
// Namespace usage
using namespace Axiom::Socket;
using namespace AP::Reflection;

static const float	MAX_NOP_TIMEOUT = 3000.0f;
static const float	MAX_KILL_TIMEOUT = 15000.0f;

// Callback
void gamedebugslot_update(Socket* pThisSocket, void *pData)
{
	SOCKET_ASSERTMESSAGE( pData != NULL, "STF Error: NULL pointer passed!\n" );

	GameDebugSlot *pSlot = (GameDebugSlot*)pData;		
	pSlot->UpdateKeepAlive();		
	pSlot->UpdateEvents();
}

// Constructor and virtual destructor
GameDebugSlot::GameDebugSlot(Slot *pSlot) 
	: Slot(pSlot)
	, GameDebugPeer()
	, m_EventMessageBoxHandle()
	, m_bCheckAlive(false)
	, m_KillElapsed(0.0f)
	, m_NopElapsed(0.0f)
	, m_UpdateTimer(NULL)
	, mLogMessageBufferLength(0)
{
	mLogMessageBuffer[0] = 0;

	if (Game::GetInstance()->GetEventMan()!=NULL)
	{
		m_EventMessageBoxHandle = Game::GetInstance()->GetEventMan()->RegisterAndCreateEventMsgBox("GameDebugSlot", Axiom::Memory::RESERVED_DEBUG_HEAP, 128, 16, 11);
	}
	else
	{
		Axiom::Log("SOCKET", "WARNING: Game::SetEventMan was never called.  GameDebugSlot cannot forward events to remote client.");
	}
}

/* virtual */ GameDebugSlot::~GameDebugSlot(void)
{
	if (m_EventMessageBoxHandle.IsValid())
		Game::GetInstance()->GetEventMan()->UnRegisterEventMsgBox(m_EventMessageBoxHandle);
	m_EventMessageBoxHandle = NULL;
	m_pSocket->SetUpdateCallback(NULL,NULL);	
	if (m_UpdateTimer!=NULL)
		SOCKET_DELETE(m_UpdateTimer);
	m_UpdateTimer = NULL;
}

// Public virtual methods
void GameDebugSlot::Init(void)
{
	ResetKeepAliveTimeout();

	// Set the update callback
	m_pSocket->SetUpdateCallback((Axiom::Socket::UpdateCallback)&gamedebugslot_update,(void*)this);

	// Call base class init
	Slot::Init();
}

/* virtual */ bool GameDebugSlot::OnReceiveInstruction(ReadHeader *pReadHeader)
{
	// Call the base class
	bool bResult = Slot::OnReceiveInstruction(pReadHeader);

	// Manage the pages
	unsigned char *pMemory = NULL;
	if( pReadHeader->m_TransactionSize == pReadHeader->m_FinalSize )
	{
		pMemory = pReadHeader->m_pMemory;
	}
	else
	{
		// Set the memory and its size
		if( pReadHeader->m_PageIndex == 0 )
		{
			InitDebugFlowMemory( pReadHeader->m_FinalSize );
		}
		
		// Add to the debug flow memory
		if( AddToDebugFlowMemory( pReadHeader ) )
		{
			pMemory = m_pDebugFlowMemory;
		}

		// Send the acknowledgment
		SendFlow( GAMEDEBUGINSTRUCTION_ACKNOWLEDGE, &( pReadHeader->m_Instruction ), sizeof(Instruction_t) );
	}
    
	// Succesfully received a big buffer
	if( pMemory != NULL )
	{
		switch(pReadHeader->m_Instruction)
		{
		case GAMEDEBUGINSTRUCTION_REQUEST_LOG_MESSAGES:
			{
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
				Axiom::Log("GameSocket", "sending log messages" );
#endif
				SendFlow( GAMEDEBUGINSTRUCTION_LOG_MESSAGES, reinterpret_cast<unsigned char*>(mLogMessageBuffer), mLogMessageBufferLength+1 );
				mLogMessageBuffer[0] = 0; //Clear the log message buffer
				mLogMessageBufferLength = 0; 
				bResult = true;
			}
			break;

		case GAMEDEBUGINSTRUCTION_SCRIPT:
			{	
				// Execute a script
				Script::Result tResult;
				const char *pScript = reinterpret_cast<char*>(pMemory);
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
				Axiom::Log("GameSocket", "script: %s", pScript );
#endif

				Script::AllocationsUseDebugHeap(true);
				tResult = Script::Execute( pScript );		// The transmitted buffer has to be '\0' terminated
																	// Make sure to release the script memory at this point
				if (tResult.IsBinary())
				{	// Binary result, Review(danc): do we need this any more?
					Script::Binary& binary = tResult.GetBinary();
					SendFlow( GAMEDEBUGINSTRUCTION_SCRIPTRESULT, static_cast<unsigned char*>(binary.Data()), binary.Size() );
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
					Axiom::Log("GameSocket", "binary result sent" );
#endif
				}
				else
				{	// Return the result as string to the client
					const char *pResult = tResult.ToString();
					SendFlow( GAMEDEBUGINSTRUCTION_SCRIPTRESULT, reinterpret_cast<unsigned char*>(const_cast<char*>(pResult)), SOCKET_STRINGLENGTH(pResult)+1 );
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
					Axiom::Log("GameSocket", "string result sent: %s", pResult );
#endif
				}
				Script::AllocationsUseDebugHeap(false);
			}
			bResult = true;
			break;
		case GAMEDEBUGINSTRUCTION_SCRIPTRESULT:
			// Use a default printf
			Axiom::Log("STF-scriptresult", "%s", pMemory );				// The transmitted buffer has to be '\0' terminated
			bResult = true;
			break;
		case GAMEDEBUGINSTRUCTION_ACKNOWLEDGE:
			// Continue to send the buffer
			if( m_DebugFlowMemoryLength > m_CurrentDebugFlowMemoryIndex )
			{
				SendFlow( (Instruction_t)*pMemory );						
			}
			bResult = true;
			break;
		case GAMEDEBUGINSTRUCTION_NOP:
			// Send a NOPRESULT back
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
			Axiom::Log("GameSocket", "sending NOPRESULT" );
#endif
			SendInstruction(GAMEDEBUGINSTRUCTION_NOPRESULT);
			bResult = true;
			break;
		case GAMEDEBUGINSTRUCTION_NOPRESULT:
			bResult = true;
			break;

		case GAMEDEBUGINSTRUCTION_EVENTMSG_REGISTER:
			{
				SOCKET_ASSERTMESSAGE(m_EventMessageBoxHandle.IsValid(), "Remote client asked to register an event but Game::SetEventMan was never called");

				// Register an event message handler from the tool
				const char *pEventMessageName = reinterpret_cast<char*>(pMemory);
				const Type* type = Type::TypeOf(pEventMessageName);
				if (type==NULL)
					break;

				//Create an instance of this object (must be derived from Axiom::EventMsg)
				//and retrieve its Guid property
				Instance instance = type->CreateInstance();
				Instance guidInstance = instance.GetField("Guid");
				unsigned int guid = guidInstance.As<unsigned int>();
				
				//Register to recieve this event in our inbox
				m_EventMessageBoxHandle->RegisterListenBroadcastEvent(guid);
			}
			bResult = true;
			break;
			
		case GAMEDEBUGINSTRUCTION_EVENTMSG_UNREGISTER:
			{	
				SOCKET_ASSERTMESSAGE(m_EventMessageBoxHandle.IsValid(), "Remote client asked to unregister an event but Game::SetEventMan was never called");
				
				// Unregister an event message handler from the tool
				const char *pEventMessageName = reinterpret_cast<char*>(pMemory);
				const Type* type = Type::TypeOf(pEventMessageName);
				if (type==NULL)
					break;

				//Create an instance of this object (must be derived from Axiom::EventMsg)
				//and retrieve its Guid property
				Instance instance = type->CreateInstance();
				Instance guidInstance = instance.GetField("Guid");
				unsigned int guid = guidInstance.As<unsigned int>();
				
				//Register to recieve this event in our inbox
				m_EventMessageBoxHandle->UnRegisterListenBroadcastEvent(guid);
			}
			bResult = true;
			break;
		default:
			break;
		}

	   	if( m_pDebugFlowMemory != NULL && m_DebugFlowMemoryLength == m_CurrentDebugFlowMemoryIndex )
		{
			ReleaseDebugFlowMemory();
		}
	}

	return bResult;
}

/* virtual */ void GameDebugSlot::OnReceive(unsigned char *pMemory, int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( m_pSocket != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Error: 0 memory length passed!\n" );

	// Make sure to reset the keep alive timeout
	ResetKeepAliveTimeout();

	while( iMemoryLength > 0 )
	{
		int iMaxReceivingMemoryLength = SOCKET_SLOT_RECEIVINGMEMORY_LENGTH - m_ReceivingMemoryLength;
		int iReceivingMemoryLength = ( iMemoryLength > iMaxReceivingMemoryLength ? iMaxReceivingMemoryLength : iMemoryLength );

		// Concat the received memory at the bottom of the buffer
		SOCKET_MEMCPY( &m_pReceivingMemory[m_ReceivingMemoryLength], pMemory, iReceivingMemoryLength * sizeof(unsigned char) );
		m_ReceivingMemoryLength += iReceivingMemoryLength;

		// Move on
		iMemoryLength -= iReceivingMemoryLength;
		pMemory += iReceivingMemoryLength;

		// Check if we got the expected chunk
		int		iHeaderSize = sizeof(Header);
		bool	bTransactionComplete = true;
		while( m_ReceivingMemoryLength >= iHeaderSize && bTransactionComplete )
		{
			// Grab the header
			ReadHeader tReadHeader;
			ReceiveInstruction( &tReadHeader, m_pReceivingMemory );

			// Check the size of the entire buffer
			const int iTotalLength =  iHeaderSize + tReadHeader.m_TransactionSize;
//			SOCKET_ASSERTMESSAGE( iTotalLength < STFSYSTEM_SLOT_RECEIVINGMEMORY_LENGTH, "STF Error: Expected buffer can't fit in our slot!\n" );

			if( m_ReceivingMemoryLength >= iTotalLength )
			{
				// Perform the receiving buffer
				OnReceiveInstruction(&tReadHeader);

				if( m_ReceivingMemoryLength > iTotalLength )	// Bring the rest of the memory to the bottom of the overflow memory
				{
					m_ReceivingMemoryLength -= iTotalLength;
					Axiom::OverlappingMemoryCopy( m_pReceivingMemory, &m_pReceivingMemory[iTotalLength], m_ReceivingMemoryLength * sizeof(unsigned char) );
				}
				else											// Or make sure to come back from the top of the buffer
				{
					m_ReceivingMemoryLength = 0;
				}
			}
			else
			{
				bTransactionComplete = false;
			}
		};
	};
}

// Public methods
void GameDebugSlot::SendFlow(int iInstruction,unsigned char *pMemory,int iMemoryLength)
{
	SOCKET_ASSERTMESSAGE( pMemory != NULL, "STF Game Error: NULL pointer passed!\n" );
	SOCKET_ASSERTMESSAGE( iMemoryLength > 0, "STF Game Error: 0 memory length passed!\n" );

	unsigned char	aBuffer[SOCKET_DEBUGSENDBUFFER_LENGTH], *pSize, *pStart, *pBuffer;
	Instruction_t	tInstruction = static_cast<Instruction_t>(iInstruction);
	Control_t		tControl = (Control_t)0;
	FinalSize_t		tFinalSize = (FinalSize_t)iMemoryLength;
	PageIndex_t		tPageIndex = (PageIndex_t)0;

	// Setup the send buffer
	pBuffer = Server::PushBuffer(aBuffer, &tInstruction);
	pSize = Server::PushBuffer(pBuffer, &tControl);
	pStart = pSize + sizeof(TransactionSize_t) + sizeof(FinalSize_t) + sizeof(PageIndex_t);	// Jump over the sizes

	int		iMaxSendingMemoryLength = SOCKET_DEBUGSENDBUFFER_LENGTH - sizeof(Header);
	bool	bTooBig = iMemoryLength > iMaxSendingMemoryLength;
	if( bTooBig )
	{
		SOCKET_ASSERTMESSAGE( m_pDebugFlowMemory == NULL, "STF Game Error: Debug flow is not assigned!\n" );

		InitDebugFlowMemory( iMemoryLength );
		SOCKET_MEMCPY( m_pDebugFlowMemory, pMemory, iMemoryLength );
	}

	pBuffer = Server::PushBuffer(pStart, pMemory, ( bTooBig ? iMaxSendingMemoryLength : iMemoryLength ) );

	// Update the size
	TransactionSize_t tTransactionSize = static_cast<TransactionSize_t>(pBuffer-pStart);
	pSize = Server::PushBuffer(pSize, &tTransactionSize);	
	pSize = Server::PushBuffer(pSize, &tFinalSize);	
	Server::PushBuffer(pSize, &tPageIndex);

	// Send the buffer
	Send(aBuffer, (int)(pBuffer-aBuffer));

	// Update the debug flow memory
	if( bTooBig )
	{
		RemoveFromDebugFlowMemory( (int)tTransactionSize );
	}
}

void GameDebugSlot::SendFlow(Instruction_t tInstruction)
{
	unsigned char	aBuffer[SOCKET_DEBUGSENDBUFFER_LENGTH], *pSize, *pStart, *pBuffer;
	Control_t		tControl = (Control_t)0;
	FinalSize_t		tFinalSize = (FinalSize_t)m_DebugFlowMemoryLength;
	PageIndex_t		tPageIndex = (PageIndex_t)m_CurrentDebugFlowPage;


	// Setup the send buffer
	pBuffer = Server::PushBuffer(aBuffer, &tInstruction);
	pSize = Server::PushBuffer(pBuffer, &tControl);
	pStart = pSize + sizeof(TransactionSize_t) + sizeof(FinalSize_t) + sizeof(PageIndex_t);	// Jump over the sizes

	int				iMaxSendingMemoryLength = SOCKET_DEBUGSENDBUFFER_LENGTH - sizeof(Header);
	unsigned char	*pMemory = &m_pDebugFlowMemory[m_CurrentDebugFlowMemoryIndex];
	int				iMemoryLength = m_DebugFlowMemoryLength - m_CurrentDebugFlowMemoryIndex;

	pBuffer = Server::PushBuffer(pStart, pMemory, ( iMemoryLength > iMaxSendingMemoryLength ? iMaxSendingMemoryLength : iMemoryLength ) );

	// Update the size
	TransactionSize_t tTransactionSize = static_cast<TransactionSize_t>(pBuffer-pStart);
	pSize = Server::PushBuffer(pSize, &tTransactionSize);	
	pSize = Server::PushBuffer(pSize, &tFinalSize);	
	Server::PushBuffer(pSize, &tPageIndex);

	// Send the buffer
	Send(aBuffer, (int)(pBuffer-aBuffer));

	// Update the debug flow memory
	RemoveFromDebugFlowMemory( (int)tTransactionSize );
}

// Private methods
void GameDebugSlot::ResetKeepAliveTimeout(void)
{
	m_KillElapsed = 0.0f;
	m_bCheckAlive = false;
}

void GameDebugSlot::UpdateKeepAlive(void)
{
	float elapsed = 0.0f;
	if (m_UpdateTimer==NULL)
	{
		m_UpdateTimer = SOCKET_NEW(Axiom::Timer());
		m_UpdateTimer->Start();
	}
	else
	{
		m_UpdateTimer->End();
		elapsed = m_UpdateTimer->GetTime().AsFloatInMilliseconds();
		m_UpdateTimer->Start();
	}

	m_NopElapsed += elapsed;
	if (m_NopElapsed > MAX_NOP_TIMEOUT)
	{
		m_NopElapsed = 0.0f;
				
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
		Axiom::Log("GameSocket", "sending NOP");
#endif
		SendInstruction(GAMEDEBUGINSTRUCTION_NOP);
		return;
	}

	if (m_bCheckAlive)
	{
		m_KillElapsed += elapsed;
		if (m_KillElapsed > MAX_KILL_TIMEOUT)
		{
			m_bCheckAlive = false;
			Game::GetInstance()->GetServer()->RemoveSlot( this );
		}
	}
}

void GameDebugSlot::KillIfNotAlive(void)
{
	m_bCheckAlive = true;
}

void GameDebugSlot::UpdateEvents(void)
{
	if (!m_EventMessageBoxHandle.IsValid())
		return;

	int numMsg = m_EventMessageBoxHandle->GetNumEvents();

	// Ensure you register these event with the mEventMsgBoxHandle in InitAIManager() call..  else you will not get any broadcast events!!
	for(int i =0;i<numMsg;i++)
	{
		const Axiom::EventMsg* pEvent = m_EventMessageBoxHandle->GetEvent(i);

		//Format a string as "typename:value" where value is the serialized EventMsg-derived object
		char tempString[1024];
		sprintf(tempString, "%s:", pEvent->GetType().Name());
		int len = SOCKET_STRINGLENGTH(tempString);
		AP::Reflection::TextSerializer::Serialize(*pEvent, tempString+len, 1024-len);
#if SOCKET_GAMEINSTRUCTIONS_DEBUGMODE
		Axiom::Log("GameSocket", "sending event: %s", pEvent->GetType().Name() );
#endif
		SendFlow(Axiom::Socket::GAMEDEBUGINSTRUCTION_EVENTMSG_MARSHAL, reinterpret_cast<unsigned char *>(tempString), SOCKET_STRINGLENGTH(tempString)+1);
	}

	m_EventMessageBoxHandle->ClearOutbox();
	m_EventMessageBoxHandle->ClearInbox();
}

void GameDebugSlot::QueueLogMessage(const char* message)
{
	int len = SOCKET_STRINGLENGTH(message);
	if (mLogMessageBufferLength+len+1 >= LOG_MESSAGE_BUFFER_SIZE-2)
	{
		//Message buffer overflow is indicated with a trailing message 
		if (mLogMessageBuffer[mLogMessageBufferLength-1] != '*')
		{
			mLogMessageBuffer[mLogMessageBufferLength] = '*';
			mLogMessageBufferLength++;
			mLogMessageBuffer[mLogMessageBufferLength] = '*';
			mLogMessageBufferLength++;
			mLogMessageBuffer[mLogMessageBufferLength] = 0;
		}
	}
	else
	{
		if (mLogMessageBufferLength>0)
		{
			//Insert special delimiter character '? between each message
			mLogMessageBuffer[mLogMessageBufferLength] = '*';
			mLogMessageBufferLength++;
			mLogMessageBuffer[mLogMessageBufferLength] = 0;
		}
		SOCKET_STRINGCOPY( mLogMessageBuffer+mLogMessageBufferLength, message, len+1 );
		mLogMessageBufferLength += len;
	}
}
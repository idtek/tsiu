
#ifndef _SOCKET_SOCKET_WIN32_H_
#define _SOCKET_SOCKET_WIN32_H_

#include "Socket/Defines.h"

#if CORE_WIN32

#include "Socket/source/Socket.h"

#include <winsock2.h>
#include <ws2tcpip.h>

namespace Axiom
{
	namespace Socket
	{
		class Socket_Win32 : public Socket
		{
		public:

			// Constructor and virtual destructor
			Socket_Win32(SocketManager* socketManager);
			/* virtual */ ~Socket_Win32(void);

			// Public methods
			void								SetHandle(SOCKET);
	
			// Public virtual methods
			/* virtual */ void					GetLocalAddress(IPV4Address*);
			/* virtual */ void					GetLocalMACAddress(MACAddress_s*);

			/* virtual */ SocketError			Send(unsigned char *pMemory = 0, int iMemoryLength = 0);

		protected:

			// Protected virtual methods
			/* virtual */ SocketError	Open(void);
			/* virtual */ SocketError	Close(void);

			/* virtual */ SocketError	Bind(void);
			/* virtual */ SocketError	Listen(void);
			/* virtual */ SocketError	Accept(void);

			/* virtual */ SocketError	Connect(void);
			/* virtual */ SocketError	Receive(void);

		private:

			// Private member variables

			// WinSock handle of the socket
			SOCKET			m_Handle;

			// Private methods

			// DNS functions
			SocketError		GetAddressInfoFromAddress(addrinfo**,char *pAddress = 0,int iPort = 0);
			SocketError		GetAddressInfoFromURL(addrinfo**,char *pURL = 0,int iPort = 0);

		};
	}
}

# endif

#endif
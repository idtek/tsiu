
#include "Socket/Defines.h"

#if CORE_WII || CORE_TOOLS

#include <socket/Source/Wii/Socket_Wii.h>
#include <socket/SocketManager.h>

#if !CORE_TOOLS
#	include <socket/game.h>
#	include <thread/mutex.h>
#endif

// Defines
#define SOCKET_NBADAPTERS_MAX	10

// USB shared memory addresses for sending data
#define SHAREDMEMORY_PC2NDEV_ADDR	0x0000
#define	SHAREDMEMORY_NDEV2PC_ADDR	0x1000
#define SHAREDMEMORY_SIZE			0x1000

#if CORE_TOOLS
#	define READSTATUS_LOCAL HIO2_STATUS_RX
#	define READSTATUS_REMOTE HIO2_STATUS_TX
#	define SHAREDMEMORY_SEND_ADDR SHAREDMEMORY_PC2NDEV_ADDR
#	define SHAREDMEMORY_RECEIVE_ADDR SHAREDMEMORY_NDEV2PC_ADDR
#else
#	define READSTATUS_LOCAL HIO2_STATUS_TX
#	define READSTATUS_REMOTE HIO2_STATUS_RX
#	define SHAREDMEMORY_SEND_ADDR SHAREDMEMORY_NDEV2PC_ADDR
#	define SHAREDMEMORY_RECEIVE_ADDR SHAREDMEMORY_PC2NDEV_ADDR
#endif

#if CORE_TOOLS
static HANDLE sSocketMutex = 0;
static void InitSocketMutex()
{
	if (sSocketMutex==0)
		sSocketMutex = ::CreateMutex(NULL, false, NULL);
}

static void LockSocketMutex()
{
	while (false)
	{
		DWORD result = ::WaitForSingleObject(sSocketMutex, 10000);
		if (result==WAIT_OBJECT_0)
			break;
		SOCKET_THREAD_SLEEP(100);
	}
}
static void UnlockSocketMutex()
{
	::ReleaseMutex(sSocketMutex);
}
#else
static Axiom::Thread::Mutex* sSocketMutex = NULL;
static void InitSocketMutex()
{
	if (sSocketMutex==NULL)
		sSocketMutex = SOCKET_NEW(Axiom::Thread::Mutex());
}

static void LockSocketMutex()
{
	sSocketMutex->Lock();
}
static void UnlockSocketMutex()
{
	sSocketMutex->Unlock();
}
#endif


// Mailbox command IDs
//   Note: IDs start at 500 to make them totally non-ambiguous!
enum
{
	SOCKET_WII_COMMAND_OPEN = 500,			// NDEV	-> PC   sent repeatedly to request a connection to be opened
	SOCKET_WII_COMMAND_OPEN_ACCEPTED,		// PC -> NDEV	send once to accept a connection, in response to SOCKET_WII_COMMAND_OPEN
	SOCKET_WII_COMMAND_DATA_ACCEPTED,		// NDEV <-> PC	receiver notification that data was recieved
	
	//Data command ID is not a fixed ID.  It is set to 1000 + block size.
	//This allows us to send a data ready notification with the block size implicit in the command ID, using a single mailbox item.
	SOCKET_WII_COMMAND_DATA = 1000,			// NDEV <-> PC	sender notification that data has been delivered
};

// Namespace usage
using namespace Axiom::Socket;


#if SOCKET_WII_DEBUGMODE
static const int MAIL_HISTORY_MAX = 32;
static u32 sMailHistory[MAIL_HISTORY_MAX];
static int sMailHistoryPos_write = -1; //circular write position in sSendData
static int sMailHistoryPos_read = -1; //circular read position in sSendData
static void LogMailHistory(u32 mail)
{
	int writePos = sMailHistoryPos_write+1;
	if (writePos==MAIL_HISTORY_MAX)
		writePos = 0;
	sMailHistory[writePos] = mail;
	sMailHistoryPos_write = writePos;
}
static void FlushMailHistory()
{
	char s[256];
	while (sMailHistoryPos_read!=sMailHistoryPos_write)
	{
		int readPos = sMailHistoryPos_read+1;
		if (readPos==MAIL_HISTORY_MAX)
			readPos = 0;
		u32 mail = sMailHistory[readPos];

		sprintf(s, "Socket_Wii::FlushMailHistory: Received mail: %d", mail);
		SOCKET_PRINT(s);

		sMailHistoryPos_read = readPos;
	}
}
#endif

// Struct for data received in HIO2 callback
struct ReceivedData
{
	u32 command;
	u32 dataSize;
	u32 alignedDataSize;
	char *data;
};

struct SendData
{
	char *data; //Gets advanced by FlushSendBuffer as pieces of the data are sent (this is the remaining data)
	u32 dataSize; //Gets advanced by FlushSendBuffer as pieces of the data are sent (this is the remaining size)
	u32 originalAlignedDataSize; //Does not get modified by FlushSendBuffer
};

#if CORE_TOOLS
	static const int RECEIVED_DATA_MAX = 128;
	static const int RECEIVED_DATA_BUFFER_SIZE = 1024*1024;
	static const int SEND_DATA_MAX = 128;
	static const int SEND_DATA_BUFFER_SIZE = 1024*1024;
#else
	static const int RECEIVED_DATA_MAX = 32;
	static const int RECEIVED_DATA_BUFFER_SIZE = 32*1024;
	static const int SEND_DATA_MAX = 256;
	static const int SEND_DATA_BUFFER_SIZE = 256*1024;
#endif

static char *sReceivedDataBuffer = NULL;
static ReceivedData *sReceivedData = NULL;
static int sReceivedDataBufferPos_write = 0; //circular write position in sReceivedDataBuffer
static int sReceivedDataBufferPos_read = 0; //circular read position in sReceivedDataBuffer
static int sReceivedDataCommandPos_write = -1; //circular write position in sReceivedData
static int sReceivedDataCommandPos_read = -1; //circular read position in sReceivedData

static char *sSendDataBuffer = NULL;
static SendData *sSendData = NULL;
static int sSendDataBufferPos_write = 0; //circular write position in sSendDataBuffer
static int sSendDataBufferPos_read = 0; //circular read position in sSendDataBuffer
static int sSendDataCommandPos_write = -1; //circular write position in sSendData
static int sSendDataCommandPos_read = -1; //circular read position in sSendData
static bool sSentDataAccepted = true;
static bool sPendingSendDataAccepted = false;

static bool ReceiveSimpleCommand(u32 command)
{
	bool result = false;
	if (sReceivedDataCommandPos_read!=sReceivedDataCommandPos_write)
	{
		while (sReceivedDataCommandPos_read!=sReceivedDataCommandPos_write)
		{
			int readPos = sReceivedDataCommandPos_read+1;
			if (readPos==RECEIVED_DATA_MAX)
				readPos = 0;
			ReceivedData* data = &sReceivedData[readPos];
			if (data->command==command)
			{
				result = true;
			}
			else
			{
#if SOCKET_WII_DEBUGMODE
				char s[256];
				sprintf(s, "Socket_Wii::ReceiveSimpleCommand: Ignored unexpected command %d while waiting for %d", data->command, command);
				SOCKET_PRINT(s);
#endif
			}
			sReceivedDataBufferPos_read += data->alignedDataSize;
			sReceivedDataCommandPos_read = readPos; //The HIO2 thread/interupt reads this so we set it LAST

			if (result==true)
				break; //Don't process commands after the one expected!
		}
	}
	return result;
}

static u32 Align32(u32 value)
{
	u32 mod = value % 32;
	if (mod != 0)
	{
		value += (32-mod);
	}
	return value;
}

//This is the callback function called by HIO2 when data has arrived.
//On the tool-side this is called from a separate HIO2 thread.
//On the game-side this is called from a hardware interrupt (I think)...
//For synchronization we depend on the use of circular buffers.  This recieve callback
//writes to the circular buffers and the main thread's update call to Receive() or ReceiveSimpleCommand()
//read from the circular buffers.  We cannot use a mutex because it does not work from the hardware interrupt
//on the game-side.
void Socket_Wii::OnReceive( HIO2Handle h )
{
	u32 mail;
#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
	LockSocketMutex();
#endif
	BOOL ok = HIO2ReadMailbox(h, &mail);
#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
	UnlockSocketMutex();
#endif
	if (!ok)
	{
		SOCKET_ASSERTMESSAGE(false, "HIO2ReadMailbox failed");
		return;
	}

#if SOCKET_WII_DEBUGMODE
	LogMailHistory(mail);
#endif

	//Special case: handle SOCKET_WII_COMMAND_DATA_ACCEPTED by setting the sSentDataAccepted and then just return.
	if (mail==SOCKET_WII_COMMAND_DATA_ACCEPTED)
	{
		SOCKET_ASSERTMESSAGE(!sSentDataAccepted, "Recieved SOCKET_WII_COMMAND_DATA_ACCEPTED when no data was sent!");
		sSentDataAccepted = true;
		return;
	}

	//General case: buffer incoming commands for the main update to process
	if (mail >= SOCKET_WII_COMMAND_OPEN)
	{
		//Use the receive command circular array
		int writePos = sReceivedDataCommandPos_write+1;
		if (writePos==RECEIVED_DATA_MAX)
			writePos = 0;
		SOCKET_ASSERTMESSAGE(writePos!=sReceivedDataCommandPos_read, "HIO2 receive command overflow.  Increase RECEIVED_DATA_MAX?");

		ReceivedData *data = &sReceivedData[writePos];
		data->command = mail;
		data->data = NULL;
		data->dataSize = 0;
		data->alignedDataSize = 0;

		//This command comes with data?
		if (mail >= SOCKET_WII_COMMAND_DATA)
		{
			//The block size is computed using the command ID:
			data->dataSize = data->command - SOCKET_WII_COMMAND_DATA;
			SOCKET_ASSERTMESSAGE(data->dataSize>0 && data->dataSize<=SHAREDMEMORY_SIZE, "Bad data block size");
			data->alignedDataSize = Align32(data->dataSize);

			//Use the receive data circular buffer
			if (sReceivedDataBufferPos_write + data->alignedDataSize > RECEIVED_DATA_BUFFER_SIZE)
				sReceivedDataBufferPos_write = 0;
			if (sReceivedDataBufferPos_write < sReceivedDataBufferPos_read)
			{
				SOCKET_ASSERTMESSAGE((sReceivedDataBufferPos_write+data->alignedDataSize) <= sReceivedDataBufferPos_read, "HIO2 receive buffer overflow. Increase RECEIVED_DATA_BUFFER_SIZE?");
			}
			data->data = sReceivedDataBuffer + sReceivedDataBufferPos_write;
			sReceivedDataBufferPos_write += data->alignedDataSize;

#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
			LockSocketMutex();
#endif
			ok = HIO2Read(h, SHAREDMEMORY_RECEIVE_ADDR, data->data, data->alignedDataSize);	
#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
			UnlockSocketMutex();
#endif
			//Read the data from HIO2 shared memory
			if (!ok)
			{
				//PrintHIO2ErrorDetails();
				SOCKET_ASSERTMESSAGE(false, "HIO2Read failed.");
				return;
			}
#if !CORE_TOOLS
			DCInvalidateRange(data->data, data->alignedDataSize);
#endif
			SOCKET_ASSERTMESSAGE(!sPendingSendDataAccepted, "sPendingSendDataAccepted already true");
			sPendingSendDataAccepted = true;
		}
		sReceivedDataCommandPos_write = writePos; //Do this LAST because it will be accessed from main thread and we can't use a mutex!
	}
}

void Socket_Wii::FlushSendBuffer()
{
	if (!m_ConnectionOpened)
		return;

	if (m_AbortPending)
	{
		m_AbortPending = false;
		AbortConnection();
		return;
	}

	if (sPendingSendDataAccepted)
	{
		LockSocketMutex();
		u32 status;
		// Get HIO2 status
		BOOL ok = HIO2ReadStatus(m_Handle, &status);
		UnlockSocketMutex();	

		if (!ok)
		{	
#if SOCKET_WII_DEBUGMODE
			SOCKET_PRINT("Socket_Wii::FlushSendBuffer call to HIO2ReadStatus returned failure.  Will retry next update.");
#endif
			return;
		}

		//Check the remote read status to make sure the remote mailbox is empty before stuffing it with more.
		if ( status & READSTATUS_REMOTE )
		{	
#if SOCKET_WII_DEBUGMODE
			SOCKET_PRINT("Socket_Wii::FlushSendBuffer can't send yet because remote mailbox is full.  Will retry next update.");
#endif
			return;
		}

		//Clear the pending flag that was originally set by OnReceive
		sPendingSendDataAccepted = false;
		
#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
		LockSocketMutex();
#endif
		ok = HIO2WriteMailbox(m_Handle, SOCKET_WII_COMMAND_DATA_ACCEPTED);
#if CORE_TOOLS //On the game side, this callback is called from a hardware interrupt.  No mutex locking allowed!
		UnlockSocketMutex();
#endif
		//Send back a message saying we've accepted the data (which permits them to write more)
		if (!ok)
		{
			PrintHIO2ErrorDetails();
			SOCKET_ASSERTMESSAGE(false, "HIO2WriteMailbox failed.");
		}
		
		return; //Any buffered data will be sent NEXT update to give the remote client time to read its mailbox.
	}		

	if (sSendDataCommandPos_read != sSendDataCommandPos_write)
	{
		while (sSendDataCommandPos_read != sSendDataCommandPos_write)
		{
			int readPos = sSendDataCommandPos_read+1;
			if (readPos==SEND_DATA_MAX)
				readPos = 0;
			SendData* data = &sSendData[readPos];

			//Break the send up into chunks no larger than SHAREDMEMORY_SIZE
			while (data->dataSize>0)
			{
				LockSocketMutex();
				u32 status;
				// Get HIO2 status
				BOOL ok = HIO2ReadStatus(m_Handle, &status);
				UnlockSocketMutex();	

				if (!ok)
				{	
		#if SOCKET_WII_DEBUGMODE
					SOCKET_PRINT("Socket_Wii::FlushSendBuffer call to HIO2ReadStatus returned failure.  Will retry next update.");
		#endif
					return;
				}

				//Check the remote read status to make sure the remote mailbox is empty before stuffing it with more.
				//Also check sSentDataAccepted flag which is set to false when we send and cleared when SOCKET_WII_COMMAND_DATA_ACCEPTED comes back.
				if ( status & READSTATUS_REMOTE  || !sSentDataAccepted)
				{	
		#if SOCKET_WII_DEBUGMODE
					SOCKET_PRINT("Socket_Wii::FlushSendBuffer can't send yet because remote mailbox is full.  Will retry next update.");
		#endif
					return;
				}

				//Send the next chunk of data
				unsigned char *dataToSend = reinterpret_cast<unsigned char *>(data->data);
				int lengthOfDataToSend = data->dataSize;

				if (lengthOfDataToSend > SHAREDMEMORY_SIZE)
				{
					lengthOfDataToSend = SHAREDMEMORY_SIZE;
				}
				u32 alignedLengthOfDataToSend = Align32((u32)lengthOfDataToSend);
	#if !CORE_TOOLS
				DCFlushRange(dataToSend, alignedLengthOfDataToSend);
	#endif

				LockSocketMutex();
				ok = HIO2Write(m_Handle, SHAREDMEMORY_SEND_ADDR, dataToSend, alignedLengthOfDataToSend);
				UnlockSocketMutex();
				if (!ok)
				{
	#if SOCKET_WII_DEBUGMODE
					SOCKET_PRINT("Socket_Wii::FlushSendBuffer call to HIO2Write returned failure.  Will retry next update.");
	#endif
					return;
				}				

				//Send a message saying the data is ready to read.
				//The command ID encodes the size of the data sent:
				u32 commandID = SOCKET_WII_COMMAND_DATA + lengthOfDataToSend;

				LockSocketMutex();	
				//Clear the data accepted flag.  This will be set again in OnReceive when SOCKET_WII_COMMAND_DATA_ACCEPTED comes back.
				sSentDataAccepted = false;	
				ok = HIO2WriteMailbox(m_Handle, commandID);
				UnlockSocketMutex();
				if ( !ok )
				{
	#if SOCKET_WII_DEBUGMODE
					SOCKET_PRINT("Socket_Wii::FlushSendBuffer call to HIO2WriteMailbox returned failure.  Will retry next update.");
	#endif
					return;
				}

				
	#if SOCKET_WII_DEBUGMODE
				char s[256];
				sprintf(s, "Socket_Wii::FlushSendBuffer: Sent data with command = %d", commandID);
				SOCKET_PRINT(s);
	#endif
				
				data->data += lengthOfDataToSend;
				data->dataSize -= lengthOfDataToSend;
			}

			sSendDataBufferPos_read += data->originalAlignedDataSize;
			sSendDataCommandPos_read = readPos; //The main thread reads this so we set it LAST
		}
	}
}

#if CORE_TOOLS
BOOL Socket_Wii::EnumDevices( HIO2DevicePath path, void* param )
{
	Socket_Wii* obj = reinterpret_cast<Socket_Wii*>(param);
	obj->m_Device = path;
	return false; //Always accept the first enumerated device.  Returning false terminates enumeration.
}

int Socket_Wii::OnNotification( HIO2NotifyEvent e, void* param )
{
	(void)e; (void)param;
	//This is called when another process is trying to steal our HIO2 connection with the NDEV.
	return 0;
}

#else  // !CORE_TOOLS

void Socket_Wii::OnDisconnect( HIO2Handle handle )
{
/*
TODO: implement this with workaround for static method
	if (Close() != SOCKET_ERROR_OK)
	{
		SOCKET_ASSERTMESSAGE(false, "Failed to close socket");
	}
*/
	AP_ASSERTFAIL("Not implemented");
}

static HIO2DeviceType preferredDevice = HIO2_DEVICE_INVALID;
BOOL Socket_Wii::EnumDevices( HIO2DeviceType type )
{
	//Accept the first device enumerated as the one we'll use
	if (preferredDevice==HIO2_DEVICE_INVALID)
		preferredDevice = type;
	return false; //Always accept the first enumerated device.  Returning false terminates enumeration.
}
#endif // CORE_TOOLS

// Protected virtual functions
/* virtual */ SocketError Socket_Wii::Open(void)
{
	// Call the base method
	Socket::Open();

	//Set the data accepted flag.  We don't care about any previous data sent being accepted, from an old aborted connection.
	sSentDataAccepted = true;

	if (sReceivedDataBuffer==NULL)
	{
		//Init data buffers only ONCE
		sReceivedDataBuffer = reinterpret_cast<char*>(SOCKET_ALIGNED_ALLOC(RECEIVED_DATA_BUFFER_SIZE, 32));
		sReceivedData = reinterpret_cast<ReceivedData*>(SOCKET_ALLOC(RECEIVED_DATA_MAX*sizeof(ReceivedData)));
		sSendDataBuffer = reinterpret_cast<char*>(SOCKET_ALIGNED_ALLOC(SEND_DATA_BUFFER_SIZE, 32));
		sSendData = reinterpret_cast<SendData*>(SOCKET_ALLOC(SEND_DATA_MAX*sizeof(SendData)));
	}

	InitSocketMutex();
	
	if( !m_HIO2Started )
	{
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Open is calling HIO2Init()");
#endif
		LockSocketMutex();
		m_HIO2Started = (HIO2Init()!=0);
		UnlockSocketMutex();
		SOCKET_ASSERTMESSAGE(m_HIO2Started, "HIO2Init() failed.");
	}

	if( m_Handle == HIO2_INVALID_HANDLE_VALUE )
	{
		// check if we have devices
#if CORE_TOOLS
		m_Device = NULL;
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Open is calling HIO2EnumDevices()");
#endif
		LockSocketMutex();
		int deviceCount = HIO2EnumDevices( Socket_Wii::EnumDevices, this );
		UnlockSocketMutex();
		const bool success = (deviceCount>0);
		if (!success || m_Device==NULL)
			return SOCKET_ERROR_CANTOPENSOCKET;
		
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Open is calling HIO2Open()");
#endif
		LockSocketMutex();
		m_Handle = HIO2Open(m_Device, Socket_Wii::OnReceive, Socket_Wii::OnNotification, this);
		UnlockSocketMutex();
		if( m_Handle == HIO2_INVALID_HANDLE_VALUE )
		{
			PrintHIO2ErrorDetails();
			Close(); //We're hosed... Abort the connection
			return SOCKET_ERROR_CANTOPENSOCKET;
		}
#else 
		preferredDevice = HIO2_DEVICE_INVALID;
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Open is calling HIO2EnumDevices()");
#endif
		if (!HIO2EnumDevices( Socket_Wii::EnumDevices ) || preferredDevice==HIO2_DEVICE_INVALID)
		{
			PrintHIO2ErrorDetails();
			Close(); //We're hosed... Abort the connection
			return SOCKET_ERROR_CANTOPENSOCKET;
		}
			
		m_Device = preferredDevice;
		
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Open is calling HIO2Open()");
#endif
		m_Handle = HIO2Open(m_Device, Socket_Wii::OnReceive, NULL);
		if( m_Handle == HIO2_INVALID_HANDLE_VALUE )
		{
			PrintHIO2ErrorDetails();
			Close(); //We're hosed... Abort the connection
			return SOCKET_ERROR_CANTOPENSOCKET;
		}
#endif 
 
		//Clear the local mailbox by reading any stray messages
		LockSocketMutex();
		while (true)
		{
			u32 status;
			
			// Get HIO2 status
			if ( HIO2ReadStatus(m_Handle, &status) )
			{
				if ( status & READSTATUS_LOCAL )
				{
					u32 mail;
					if ( HIO2ReadMailbox(m_Handle, &mail) )
					{
					#if SOCKET_WII_DEBUGMODE
						char s[256];
						sprintf(s, "Socket_Wii::Open is discarding a stray message: %d", mail);
						SOCKET_PRINT(s);
					#endif
					}
					else
					{
						SOCKET_PRINT("Socket_Wii::Open: Call to HIO2ReadMailbox failed.  YOU MAY NEED TO POWER OFF YOUR NDEV.");
						break;
					}
				}
				else
				{
					break; //No more stray mail
				}
			}
			else
			{
				SOCKET_PRINT("Socket_Wii::Open: Call to HIO2ReadStatus failed.  Cannot check for stray mail.");
				break;
			}
		}
		UnlockSocketMutex();
	}

	return SOCKET_ERROR_OK;
}

/* virtual */ SocketError Socket_Wii::Close(void)
{
	if (m_Closing)
		return SOCKET_ERROR_OK; //Prevent re-entrancy

	m_Closing = true;
	
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Close is closing the HIO2 connection.");
#endif

	SocketError result = SOCKET_ERROR_OK;
	if( m_Handle != HIO2_INVALID_HANDLE_VALUE )
	{
		LockSocketMutex();
		if (HIO2Close( m_Handle )!=0)
		{
			result = SOCKET_ERROR_CANTCLOSESOCKET;
		}
		UnlockSocketMutex();
		m_Handle = HIO2_INVALID_HANDLE_VALUE;
	}
	/*
	if( m_HIO2Started )
	{
		LockSocketMutex();
		HIO2Exit();		
		UnlockSocketMutex();
		m_HIO2Started = false;
	}*/
	
	if (m_ConnectionOpened)
	{
		m_ConnectionOpened = false;

		// Perform callback
		CallDisconnectCallback();
	}
	
#if CORE_TOOLS
	Socket::Close();
#else
	//Don't actually close the socket on the game side or it gets removed...
	//Just go back to listening for a new connection		
	SetClass(SOCKET_CLASS_SERVER);
	SetState(SOCKET_STATE_SERVER_OPEN);
#endif

	m_Closing = false;

	return result;
}

/* virtual */ SocketError Socket_Wii::Bind(void)
{
	// This does not apply for Wii USB connection
#if CORE_TOOLS
	return SOCKET_ERROR_CANTLISTENSOCKET;
#else
	return SOCKET_ERROR_OK;
#endif
}

/* virtual */ SocketError Socket_Wii::Listen(void)
{
	// This does not apply for Wii USB connection
#if CORE_TOOLS
	return SOCKET_ERROR_CANTLISTENSOCKET;
#else
	return SOCKET_ERROR_OK;
#endif
}

#if !CORE_TOOLS
//This is called intermittently to "ping" the remote tool with an open request.  
//Even when a connection is already open, this ensures that if the tool reset the connect it can connect again.
SocketError Socket_Wii::SendOpenRequest()
{		
	//if (sSendDataCommandPos_read != sSendDataCommandPos_write)
	//	return SOCKET_ERROR_OK; //Don't send open request while the send buffer has other data to be sent!
		
	//The remote server has not accepted our connection yet.
	//Here, we send a request every 60 updates to open the connection.
	static int sendRequestCountdown = 0;
	static bool remoteMailBoxIsFull = false;
	sendRequestCountdown--;
	if (sendRequestCountdown<=0)
	{
		sendRequestCountdown = 60;
		u32 status;
		// Get HIO2 status
		if ( !HIO2ReadStatus(m_Handle, &status) )
		{
			return SOCKET_ERROR_CANTSENDSOCKET;
		}
		if ( !(status & READSTATUS_REMOTE) )
		{
			if (remoteMailBoxIsFull)
			{
				//The remote mailbox is no longer full, so clear the flag but count down again before sending the open request.
				//This gives the remote tool time to initialize and properly recieve the open request.
				remoteMailBoxIsFull = false;
	#if SOCKET_WII_DEBUGMODE
				SOCKET_PRINT("Socket_Wii::SendOpenRequest: Remote mailbox is no longer full.  Will send request on next countdown.");
	#endif
			}
			else
			{
				//Send a request to open a connection.  When the other side recieves this, it will reply with SOCKET_WII_COMMAND_OPEN_ACCEPTED
				if ( !HIO2WriteMailbox(m_Handle, SOCKET_WII_COMMAND_OPEN) )
				{
					return SOCKET_ERROR_CANTSENDSOCKET;
				}
				else
				{
	#if SOCKET_WII_DEBUGMODE
					SOCKET_PRINT("Socket_Wii::SendOpenRequest: Sent the message SOCKET_WII_COMMAND_OPEN.");
	#endif
				}
			}
		}
		else
		{
			remoteMailBoxIsFull = true;
		}
	}
	return SOCKET_ERROR_OK;
}
#endif

/* virtual */ SocketError Socket_Wii::Accept(void)
{
#if CORE_TOOLS
	return SOCKET_ERROR_CANTLISTENSOCKET;
#else

#if SOCKET_WII_DEBUGMODE
	FlushMailHistory();
#endif

	SocketError result = SOCKET_ERROR_OK;
	
	if (ReceiveSimpleCommand(SOCKET_WII_COMMAND_OPEN_ACCEPTED))
	{
		m_ConnectionOpened = true;
		
		SOCKET_PRINT("Socket_Wii::Accept has accepted an HIO2 connection.");

		//Turn this socket's class from a SERVER into a SLOT so that it can start recieving data
		SetClass(SOCKET_CLASS_SLOT);

		// Enter the recieve state
		SetState(SOCKET_STATE_CLIENT_RECEIVE);
	
		// Perform callback
		CallAcceptCallback(this);
	}
	else if (ReceiveSimpleCommand(SOCKET_WII_COMMAND_OPEN))
	{
		SOCKET_PRINT("ERROR: You are using an OLD version of Streaker whose RemoteConsoleWii project is out of date.");
		SOCKET_ASSERTMESSAGE(false, "You are using an OLD version of Streaker whose RemoteConsoleWii project is out of date.");
		result = SOCKET_ERROR_CANTSENDSOCKET;
	}
	else
	{
		result = SendOpenRequest();
	}

	FlushSendBuffer();
	return result;
#endif
}

/* virtual */ SocketError Socket_Wii::Connect(void)
{
#if !CORE_TOOLS
	return SOCKET_ERROR_CANTLISTENSOCKET;
#else
#if SOCKET_WII_DEBUGMODE
	FlushMailHistory();
#endif

	SocketError result = SOCKET_ERROR_PASSED;

	if (ReceiveSimpleCommand(SOCKET_WII_COMMAND_OPEN))
	{
		m_ConnectionOpened = true;
		
		SOCKET_PRINT("Socket_Wii::Connect has established an HIO2 connection.");
		
		LockSocketMutex();
		//Send the NDEV a message saying we've accepted the connection
		if ( !HIO2WriteMailbox(m_Handle, SOCKET_WII_COMMAND_OPEN_ACCEPTED) )
		{
			UnlockSocketMutex();
			PrintHIO2ErrorDetails();
			Close(); //We're hosed... Abort the connection
			return SOCKET_ERROR_CANTSENDSOCKET;
		}
		UnlockSocketMutex();
		
#if SOCKET_WII_DEBUGMODE
		SOCKET_PRINT("Socket_Wii::Connect sent the message SOCKET_WII_COMMAND_OPEN_ACCEPTED");
#endif

		//SOCKET_THREAD_SLEEP(1000); //Give some time before we start blasting the game with reams of data

		//Turn this socket's class into a CLIENT so that it can start recieving data
		SetClass(SOCKET_CLASS_CLIENT);
		
		// Perform callback
		CallConnectCallback();

		result = SOCKET_ERROR_OK;
	}

	FlushSendBuffer();
	return result;
#endif
}

/* virtual */ SocketError Socket_Wii::Receive(void)
{   
#if SOCKET_WII_DEBUGMODE
	FlushMailHistory();
#endif
	if (sReceivedDataCommandPos_read!=sReceivedDataCommandPos_write)
	{
		while (sReceivedDataCommandPos_read!=sReceivedDataCommandPos_write)
		{
			int readPos = sReceivedDataCommandPos_read+1;
			if (readPos==RECEIVED_DATA_MAX)
				readPos = 0;
			ReceivedData* data = &sReceivedData[readPos];

#if SOCKET_WII_DEBUGMODE
				char s[256];
				sprintf(s, "Socket_Wii::Receive: Received data with command = %d", data->command);
				SOCKET_PRINT(s);
#endif

#if !CORE_TOOLS
			//The old client could have died... are we getting a new open request?
			if (data->command==SOCKET_WII_COMMAND_OPEN_ACCEPTED)
			{
				//Close current connection
				AbortConnection();

				//Accept the new connection next update
				return SOCKET_ERROR_OK;
			}
#endif

			if (data->command>=SOCKET_WII_COMMAND_DATA)
			{
				SOCKET_MEMCPY(m_pReceivingMemory, data->data, data->dataSize);
				m_ReceivingMemoryLength = data->dataSize;
				sReceivedDataBufferPos_read += data->alignedDataSize;
				sReceivedDataCommandPos_read = readPos; //The HIO2 thread/interupt reads this so we set it LAST

				// Perform callback	
				CallReceiveCallback();
			}
			else
			{
				sReceivedDataCommandPos_read = readPos; //The HIO2 thread/interupt reads this so we set it LAST
			}
		}
	}


	SocketError result = SOCKET_ERROR_OK;
#if !CORE_TOOLS
	result = SendOpenRequest();
#endif
	
	FlushSendBuffer();
	return result;
}

void Socket_Wii::AbortConnectionNextUpdate()
{
	m_AbortPending = true;
}

void Socket_Wii::AbortConnection()
{
	if (m_ConnectionOpened)
	{
		//Don't actuallyc call Close(), just get the server to delete the GameDebugSlot by calling its DisconnectCallback
		m_ConnectionOpened = false;

	   	//Don't allow the server to close the socket.
		m_Closing = true;
		CallDisconnectCallback();
		m_Closing = false;	
	}
	
	//Reset the send buffer
	sSendDataCommandPos_write = -1;
	sSendDataCommandPos_read = -1;
	sSendDataBufferPos_write = 0;
	sSendDataBufferPos_read = 0;
	sSentDataAccepted = true;
	
	SetClass(SOCKET_CLASS_SERVER);
	SetState(SOCKET_STATE_SERVER_ACCEPT);
}

/* virtual */ SocketError Socket_Wii::Send(unsigned char *pMemory /*= 0*/, int iMemoryLength /*=0*/)
{
	if (!m_ConnectionOpened)
	{
		SOCKET_PRINT("Socket_Wii::Send cannot send because connection is currently not open, data will not be sent.");
		return SOCKET_ERROR_CANTSENDSOCKET;
	}

	//Use the send buffer circular array
	int writePos = sSendDataCommandPos_write+1;
	if (writePos==SEND_DATA_MAX)
		writePos = 0;
	if (writePos==sSendDataCommandPos_read)
	{
		SOCKET_PRINT("***** Send command buffer overflow. Resetting socket connection. *****");
		AbortConnectionNextUpdate();
		return SOCKET_ERROR_CANTSENDSOCKET;
	}

	SendData *data = &sSendData[writePos];
	data->data = NULL;
	data->dataSize = 0;
	data->originalAlignedDataSize = 0;

	data->dataSize = iMemoryLength;
	SOCKET_ASSERTMESSAGE(data->dataSize>0, "Bad data block size");
	data->originalAlignedDataSize = Align32(data->dataSize);

	//Use the send data circular buffer
	if (sSendDataBufferPos_write + data->originalAlignedDataSize > SEND_DATA_BUFFER_SIZE)
		sSendDataBufferPos_write = 0;
	if (sSendDataBufferPos_write < sSendDataBufferPos_read)
	{
		if ((sSendDataBufferPos_write+data->originalAlignedDataSize) > sSendDataBufferPos_read)
		{
			SOCKET_PRINT("***** Send data buffer overflow. Resetting socket connection. *****");
			AbortConnectionNextUpdate();
			return SOCKET_ERROR_CANTSENDSOCKET;
		}
	}
	data->data = sSendDataBuffer + sSendDataBufferPos_write;
	sSendDataBufferPos_write += data->originalAlignedDataSize;

	SOCKET_MEMCPY(data->data, pMemory, iMemoryLength);
		
#if SOCKET_WII_DEBUGMODE
	SOCKET_PRINT("Socket_Wii::Send buffered a new chunk of data for sending.");
#endif

	sSendDataCommandPos_write = writePos; //Do this LAST because it will be accessed from main thread and we can't use a mutex!

	return SOCKET_ERROR_OK;
}

void Socket_Wii::PrintHIO2ErrorDetails()
{
	LockSocketMutex();
	HIO2Error error = HIO2GetLastError();
	UnlockSocketMutex();
	switch (error)
	{
		case HIO2_ERROR_NONE:				SOCKET_PRINT("HIO2 ERROR: no error"); break;
		case HIO2_ERROR_UNINITIALIZED:		SOCKET_PRINT("HIO2 ERROR: HIO2 is not initialized"); break;
		case HIO2_ERROR_INVALID_HANDLE:		SOCKET_PRINT("HIO2 ERROR: invalid HIO2 handle"); break;
		case HIO2_ERROR_INVALID_PARAMETER:	SOCKET_PRINT("HIO2 ERROR: invalid function parameter"); break;
		case HIO2_ERROR_CHANNEL_BUSY:		SOCKET_PRINT("HIO2 ERROR: channel already used"); break;
		case HIO2_ERROR_CHANNEL_FULL:		SOCKET_PRINT("HIO2 ERROR: all channels are used"); break;
		case HIO2_ERROR_CANNOT_USE:			SOCKET_PRINT("HIO2 ERROR: this console cannot use HIO2"); break;
		case HIO2_ERROR_NOT_FIND:			SOCKET_PRINT("HIO2 ERROR: EXI-USB not find"); break;
		case HIO2_ERROR_INTERNAL:			SOCKET_PRINT("HIO2 ERROR: internal error (EXI error)"); break;
	}
}


// Constructor and virtual destructor
Socket_Wii::Socket_Wii(SocketManager* socketManager) :
	Socket(socketManager),
	m_Handle(HIO2_INVALID_HANDLE_VALUE),
	m_ConnectionOpened(false),
	m_HIO2Started(false),
	m_Closing(false),
	m_AbortPending(false)
{
}

/* virtual */ Socket_Wii::~Socket_Wii(void)
{
}

// Public virtual functions
/* virtual */ void Socket_Wii::GetLocalAddress(IPV4Address *pIPAddress)
{
	SOCKET_MEMSET(pIPAddress->m_aBytes, 0, IPV4ADDRESS_LENGTH);
}

/* virtual */ void Socket_Wii::GetLocalMACAddress(MACAddress_s *pMACAddress)
{
	SOCKET_MEMSET(pMACAddress->m_aBytes, 0, MACADDRESS_LENGTH);
}
#endif

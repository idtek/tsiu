
#ifndef _SOCKET_INSTRUCTIONS_H_
#define _SOCKET_INSTRUCTIONS_H_

namespace Axiom
{
	namespace Socket
	{
		enum INSTRUCTION_e
		{
			INSTRUCTION_INVALID = -1,			//!< Invalid instruction

			INSTRUCTION_BIGENDIAN,				//!< Use Big Endian instruction.  Mandatory that this value is 0!  
			INSTRUCTION_ID,						//!< Instruction Id packet type
			INSTRUCTION_IPADDRESS,				//!< IP Address packet type
			INSTRUCTION_MACADDRESS,				//!< MAC Address packet type

			INSTRUCTION_BASE					//!< Base Instruction, can be used to append new instructions 
		};
	}
}

#endif

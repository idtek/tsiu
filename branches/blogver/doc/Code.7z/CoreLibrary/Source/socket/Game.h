
#ifndef _SOCKET_GAME_H_
#define _SOCKET_GAME_H_

#include <core/singleton.h>
#include "Socket/GameDefines.h"
#include <collections/list.h>

namespace Axiom
{
	class EventMan;

	namespace Socket
	{
		// Axiom::Socket prototypes
		class SocketManager;
		class Server;
		class GameServer;

		// Game class prototype
		class Game : public Axiom::Singleton<Game>
		{
		public:
			// Constructor & destructor
			Game(void);
			virtual ~Game(void);

			//This sets up the EventMan that will be used to receive events
			//that will be forwarded to the remote client.  It is crucial that
			//this is set up properly or event listening from the RemoteConsole
			//will not work correctly.
			void SetEventMan(Axiom::EventMan* eventMan) { m_EventMan = eventMan; }

			//Get the EventMan that was previously set
			Axiom::EventMan* GetEventMan()				{ return m_EventMan; }

			//Update callbacks
			typedef	void (*UpdateCallback)();
			void AddUpdateCallback(UpdateCallback callback) { m_UpdateCallbacks.Add(callback); }
			void RemoveUpdateCallback(UpdateCallback callback) { m_UpdateCallbacks.Remove(callback); }

			Server*						GetServer(void);
			bool						IsDebugClientConnected(void);
			void						KillInactiveGameDebugSlots(void);
			void					    Update(void);

			void						EnablePrintBroadcasting(bool enable) { m_EnablePrintBroadcasting = enable; }
			bool						PrintBroadcastingEnabled() { return m_EnablePrintBroadcasting; }

		private:
			// Private member variable
			SocketManager				*m_pSocketManager;
			GameServer					*m_pServer;
			Axiom::EventMan				*m_EventMan;
			Axiom::Collections::StaticList<UpdateCallback, 10> m_UpdateCallbacks;
			bool 						m_EnablePrintBroadcasting;
		};
	}
}

#endif

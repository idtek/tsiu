//------------------------------------------------------------------------------
//
//!  @file STFSlot.h
//!	 @brief	API to create a slot/session between client and server
//--------------------------------------------------------------------------

#ifndef _SOCKET_SLOT_H_
#define _SOCKET_SLOT_H_

#include "Socket/Defines.h"

namespace Axiom
{
	namespace Socket
	{

			class Socket;

		// Header of transaction memory
		typedef unsigned char	Instruction_t;
		typedef unsigned char	Control_t;
		typedef unsigned short	TransactionSize_t;
		typedef unsigned int	FinalSize_t;
		typedef unsigned int	PageIndex_t;

		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		Header
		//!	@brief		Struct for the packet header to pass instructions
		//! @ingroup	Online
		//!
		//! This structure is the packet header, which has instructions for the receiver to execute.
		//---------------------------------------------------------------------------------------------------------------------------------	
		typedef struct Header
		{
			Instruction_t		m_Instruction;				//!< Current instruction of a packet
			Control_t			m_Control;					//!< Not used yet
			TransactionSize_t	m_TransactionSize;			//!< Memory size of the transaction
			FinalSize_t			m_FinalSize;				//!< Memory size of the final data
			PageIndex_t			m_PageIndex;				//!< Page index of the memory stream

		} Header;

		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		ReadHeader
		//!	@brief		Struct for package header to read
		//! @ingroup	Online
		//!
		//! This structure is the package header used for reading in the package from the receiver side and contains the memory pool pointer
		//---------------------------------------------------------------------------------------------------------------------------------	
		typedef struct ReadHeader : Header
		{
			unsigned char		*m_pMemory;									//!< Memory pool to contain the packet data to read

		} ReadHeader;


		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		Slot
		//!	@brief		API for creating a slot for client and server to communicate
		//! @ingroup	Online
		//!
		//! Slot is a session that is set up to allow the client and server to communicate back and forth through a socket.
		//---------------------------------------------------------------------------------------------------------------------------------	
		class Slot
		{
		public:

			//---------------------------------------------------------------------------------------------------------------------------------
			//!	@enum		SLOT_INSTRUCTION_e
			//!	@brief		Enum list of instruction type in a packet
			//! @ingroup	Online
			//!
			//---------------------------------------------------------------------------------------------------------------------------------

			// Constructor and virtual destructor
			Slot(Socket*);
			Slot(Slot*);
			virtual ~Slot(void);

			// Public methods
			const bool						IsClientConnected(void);				//!< Is client connected to slot	
			inline const unsigned int	GetClientID(void);						//!< Get client ID
			inline const char*			GetClientAddress(void);					//!< Get client IP Address
			inline const char*			GetClientMACAddress(void);				//!< Get client MAC Address
//			inline const bool				GetSubstitued(void);

			// Public virtual methods
			virtual void				Init(void);
			virtual void				Release(void);
//			virtual void				OnDisconnect(void);		
//			virtual void				OnConnect(void);		
			virtual void				OnReceive(unsigned char*,int);			//!< On receive of normal data packet
			virtual bool				OnReceiveInstruction(ReadHeader*);	//!< On receive of a new instruction packet
			virtual void				Send(unsigned char*,int);				//!< Send data through the slot

			// Helpers for server
			inline Socket*			GetSocket(void);						//!< Get the socket owned by the slot

		protected:

			// Protected variable members
			Socket		*m_pSocket;											//!< The data socket
			
			unsigned char	*m_pReceivingMemory;								//! The receiving memory of the data from the socket
			int				m_ReceivingMemoryLength;							//! Receive Memory length

			// Protected methods
			void			SendInstruction(int);								//!< Send an instruction through the socket
			void			ReceiveInstruction(ReadHeader*,unsigned char*);	//!< Receive an instruction from the socket

		private:

			// Private variable members
			unsigned int	m_ClientID;											//!< Client id
			char			m_aClientAddress[SOCKET_IPV4_IPADDRESS_LENGTH];		//!< Client IP address
			char			m_aClientMACAddress[SOCKET_IPV4_MACADDRESS_LENGTH];	//!< Client MAX address
			bool			m_Substitued;										//!< If slot is substituted, then do not destroy the socket

		};

		// Inline implementation of public methods
		inline Socket* Slot::GetSocket(void)
		{
			SOCKET_ASSERTMESSAGE( m_pSocket != 0, "STF Error: NULL pointer!\n" );
	
			return m_pSocket;
		};

		inline const unsigned int Slot::GetClientID(void)
		{
			return m_ClientID;
		};

		inline const char* Slot::GetClientAddress(void)
		{
			return m_aClientAddress;
		};

		inline const char* Slot::GetClientMACAddress(void)
		{
			return m_aClientMACAddress;
		};
/*
		inline const bool Slot::GetSubstitued(void)
		{
			return m_Substitued;
		};
*/
	}
}

#endif


#ifndef _SOCKET_GAMEDEFINES_H_
#define _SOCKET_GAMEDEFINES_H_

// Including the original defines
#include "Socket/Defines.h"

// Component support
//#define STFGAME_ASACOMPONENT				

// Defines
#define STFGAME_NBSOCKETS_MAX					32

#define STFGAMESERVER_NBCONNECTIONS_MAX		16
#define STFGAMESERVER_TCPPORT					3505

// Slots
#define STFGAMESLOT_DEBUG_ID					0x01

// Marshaller
#define STFGAMEMARSHALLER_NBEVENTS_MAX			64
#define STFGAMEMARSHALLER_NBCACHEDEVENTS_MAX	25

// Clients
#define SOCKET_HTTPSENDBUFFER_LENGTH				4096
#define SOCKET_DEBUGSENDBUFFER_LENGTH				16384	// Recommendation: This number should be the same as SOCKET_XXX_RECEIVINGMEMORY_LENGTH
#define SOCKET_HTTPCLIENT_NBREQUESTS_MAX			8

// Events
#define STFGAME_TRANSLATEBUFFER_LENGTH			4096

// Package data
#define STFGAMEPACKAGEDATA_USERHEADER_LENGTH	32

#endif

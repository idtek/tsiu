//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		file\STFServer.h
//! @brief		Online Server API
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------

#ifndef _SOCKET_SERVER_H_
#define _SOCKET_SERVER_H_

#include "Socket/Defines.h"

namespace Axiom
{
	namespace Socket
	{
		class Slot;
		class Socket;
		class SocketManager;
		union IPV4Address;

		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		Server
		//!	@brief		Online Server API for sending and recieve packets
		//! @ingroup	Online
		//! 
		//---------------------------------------------------------------------------------------------------------------------------------	
		class Server
		{
		public:

			// Constructor and virtual destructor
			Server(const int iMaxNbSlots = SOCKET_SERVER_NBSLOTS_MAX);
			virtual ~Server(void);

			// Public methods

			// Helpers from the listening socket
			void				GetLocalAddress(IPV4Address*);								//!< Get local address
			const int			GetPort(void);													//!< Get the port

			// Data transfer functions
			virtual void		Init(SocketManager*,int,int);													//!< Initialize the server
			virtual void		Release(void);													//!< Release the server
			virtual void		OnDisconnect(Socket*);										//!< Disconnect the socket
			virtual void		OnAccept(Socket*,Socket*);									//!< Accept a connection through the sockets
			virtual void		OnReceive(Socket*,unsigned char*,int);						//!< Recieve data via the socket

			// Slots
			void				RemoveSlot(Socket*);											//!< Destroy a slot
			void				AddSlot(Slot*);												//!< Add a slot to the server
			void				RemoveSlot(Slot*);											//!< Destroy a slot
			Slot*				FindSlot(Socket*);											//!< Find the slot from a socket
			Slot*				FindSlot(unsigned int);											//!< Find the slot from a socket
			Slot*				FindNextSlot(Slot*, unsigned int);										//!< Find a slot from an slot index
			inline const int	GetNbSlots(void);												//!< Get Number of slots

			// Static public template methods
			template <typename T> inline static unsigned char*	PushBuffer(unsigned char*,const T*,int iSize = 1);		//<! Push data onto the buffer
			template <typename T> inline static unsigned char*	PopBuffer(unsigned char*,T*,int iSize = 1);				//! Pop data off the buffer


		protected:

			// Protected structures
			//---------------------------------------------------------------------------------------------------------------------------------
			//!	@struct		SlotNode_s
			//!	@brief		Contains a slot and the next slot node
			//! @ingroup	Online
			//! 
			//---------------------------------------------------------------------------------------------------------------------------------	
			struct SlotNode_s
			{
				Slot		*m_pSlot;															//!< A slot pointer
				SlotNode_s	*m_pNextNode;														//!< Next slot node

			};

			// Protected member variables

			// Connection list
			SlotNode_s		*m_pSlotNodes;														//!< List of slot nodes
			SlotNode_s		*m_pSlotHeadNode;													//!< Head of the slot node list
			SlotNode_s		*m_pSlotFreeNode;													//!< Free slot node list
			int				m_NbSlots;															//!< Number of slots
			int				m_MaxNbSlots;														//!< Max number of slots

		private:
	
			// Private member variables

			// The main socket
			Socket		*m_pListenSocket;													//!< Socket handling connections

			// Private methods
			void			ResetSlotList(void);												//!< Reset the slot list
			void			DestroySlotList(void);												//!< Destroy the slot list

		};

		// Public inline implementation
		inline const int Server::GetNbSlots(void)
		{
			return m_NbSlots;
		};

		// Static public template inline implementation
		// No endian conversion on server side, that's the rule!

		template <typename T> inline /* static */ unsigned char* Server::PushBuffer(unsigned char *pBuffer, const T *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			iSize *= sizeof(T);
			SOCKET_MEMCPY( pBuffer, pData, iSize );
			pBuffer += iSize;
			return pBuffer;
		}

		template <typename T> inline /* static */ unsigned char* Server::PopBuffer(unsigned char *pBuffer, T *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			iSize *= sizeof(T);
			if( pData != 0 )
			{
				SOCKET_MEMCPY( pData, pBuffer, iSize );
			}
			pBuffer += iSize;
			return pBuffer;
		}

	}
}

#endif

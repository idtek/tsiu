//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		file\STFClient.h
//! @brief		Online Client API
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------

#ifndef _SocketLIENT_H_
#define _SocketLIENT_H_

#include "Socket/Defines.h"

namespace Axiom
{
	namespace Socket
	{
		class Socket;
		class SocketManager;
		union IPV4Address;
		struct Header;
		struct ReadHeader;

		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		Client
		//!	@brief		Online Client API for sending and receiving packet
		//! @ingroup	Online
		//! 
		//---------------------------------------------------------------------------------------------------------------------------------	
		class Client
		{
		public:

			// Constructor and virtual destructor
			Client(void);
			virtual ~Client(void);

			// Public methods

			// Helpers for the client
			inline const bool			IsServerDifferentEndian(void);										//!< Check if server difference in endianess
			inline const unsigned int	GetID(void);														//!< Get Client Id

			// Helpers for the data socket
			void						GetLocalAddress(IPV4Address*);									//!< Get Local IP Address
			const char*					GetAddress(void);													//!< Get Local IP Address by string
			const bool					IsAddressURL(void);													//!< Is address set a URL
			const int					GetPort(void);														//!< Get the current listening port
			const bool					IsConnected(void);													//!< Is Online connected
			const bool					IsInitialized(void) { return m_pSocket!=NULL; }

			// Public virtual methods

			// Data transfer functions
			virtual void				Init(SocketManager*, const char*,int,int);											//!< Initialize the client
			virtual void				Release(void);														//!< Destroy the client
			virtual void				OnConnect(void);													//!< Called when connection detected
			virtual void				OnDisconnect(void);													//!< Called when disconnect detected
			virtual void				OnReceive(unsigned char*,int);										//!< Called when a new packet is received
			virtual bool				OnReceiveInstruction(ReadHeader*);								//!< Called when an instruction packet is recieved
			virtual void				Send(unsigned char*,int);											//!< Send the package through the socket to the other client


			// Public template methods
			template <typename T> inline unsigned char*	PushBuffer(unsigned char*,const T*,int iSize = 1);	//!< Push data onto the buffer
			template <typename T> inline unsigned char*	PopBuffer(unsigned char*,T*,int iSize = 1);			//!< Pop data off the buffer
			void			SendInstruction(int);															//!< Send an instruction packet thru socket

		protected:

			// Protected variable members

			// The data socket
			Socket		*m_pSocket;																		//!< Current socket of communication

			// The receiving memory
			unsigned char	*m_pReceivingMemory;															//!< Memory pool where data is received
			int				m_ReceivingMemoryLength;														//!< Size of the memory pool  to receive data
			
			//Keep alive
			bool			m_KeepAliveEnabled;

			// Protected methods
			inline void		SetID(unsigned int);															//!< Set the id of client
			void			ReceiveInstruction(ReadHeader*);												//!< Receive an instruction packet
	
		private:

			// Private member variables
			bool			m_ServerIsDifferentEndian;														//!< Flag to determine endianess

			// The ID
			unsigned int	m_ID;																			//!< Id of current client

			
		};

		// Protected inline implementation
		inline void	Client::SetID(unsigned int uID)
		{
			m_ID = uID;
		};

		// Public inline implementation
		inline const bool Client::IsServerDifferentEndian(void)
		{
			return m_ServerIsDifferentEndian;
		};

		inline const unsigned int Client::GetID(void)
		{
			return m_ID;
		};

		// Public template inline implementation
		
		// Endian conversion happens on the client side, that's the rule!
		template <> inline unsigned char* Client::PushBuffer<float>(unsigned char *pBuffer, const float *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			if( m_ServerIsDifferentEndian )
			{
				const unsigned char	*pUCData = reinterpret_cast<const unsigned char*>(pData);
				int				i;
				for( i = 0 ; i < iSize ; i += sizeof(float) )
				{
					*pBuffer++ = pUCData[i+3];
					*pBuffer++ = pUCData[i+2];
					*pBuffer++ = pUCData[i+1];
					*pBuffer++ = pUCData[i];
				}
				return pBuffer;
			}

			float	*pFBuffer = reinterpret_cast<float*>(pBuffer);
			int		i;
			for( i = 0 ; i < iSize ; ++i )
			{
				*pFBuffer++ = pData[i];
			}
			return reinterpret_cast<unsigned char*>(pFBuffer);
		};

		template <> inline unsigned char* Client::PushBuffer<unsigned int>(unsigned char *pBuffer, const unsigned int *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			if( m_ServerIsDifferentEndian )
			{
				const unsigned char	*pUCData = reinterpret_cast<const unsigned char*>(pData);
				int				i;
				for( i = 0 ; i < iSize ; i += sizeof(unsigned int) )
				{
					*pBuffer++ = pUCData[i+3];
					*pBuffer++ = pUCData[i+2];
					*pBuffer++ = pUCData[i+1];
					*pBuffer++ = pUCData[i];
				}
				return pBuffer;
			}

			unsigned int	*pUIBuffer = reinterpret_cast<unsigned int*>(pBuffer);
			int				i;
			for( i = 0 ; i < iSize ; ++i )
			{
				*pUIBuffer++ = pData[i];
			}
			return reinterpret_cast<unsigned char*>(pUIBuffer);
		};

		template <> inline unsigned char* Client::PushBuffer<int>(unsigned char *pBuffer, const int *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			if( m_ServerIsDifferentEndian )
			{
				const unsigned char	*pUCData = reinterpret_cast<const unsigned char*>(pData);
				int				i;
				for( i = 0 ; i < iSize ; i += sizeof(int) )
				{
					*pBuffer++ = pUCData[i+3];
					*pBuffer++ = pUCData[i+2];
					*pBuffer++ = pUCData[i+1];
					*pBuffer++ = pUCData[i];
				}
				return pBuffer;
			}

			int *pIBuffer = reinterpret_cast<int*>(pBuffer);
			int i;
			for( i = 0 ; i < iSize ; ++i )
			{
				*pIBuffer++ = pData[i];
			}
			return reinterpret_cast<unsigned char*>(pIBuffer);
		};

		template <> inline unsigned char* Client::PushBuffer<unsigned short>(unsigned char *pBuffer, const unsigned short *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			if( m_ServerIsDifferentEndian )
			{
				const unsigned char	*pUCData = reinterpret_cast<const unsigned char*>(pData);
				int				i;
				for( i = 0 ; i < iSize ; i += sizeof(unsigned short) )
				{
					*pBuffer++ = pUCData[i+1];
					*pBuffer++ = pUCData[i];
				}
				return pBuffer;
			}

			unsigned short	*pUSBuffer = reinterpret_cast<unsigned short*>(pBuffer);
			int				i;
			for( i = 0 ; i < iSize ; ++i )
			{
				*pUSBuffer++ = pData[i];
			}
			return (unsigned char*)pUSBuffer;
		};

		template <> inline unsigned char* Client::PushBuffer<unsigned char>(unsigned char *pBuffer, const unsigned char *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			SOCKET_MEMCPY( pBuffer, pData, iSize );
			pBuffer += iSize;
			return pBuffer;
		};

		template <> inline unsigned char* Client::PushBuffer<char>(unsigned char *pBuffer, const char *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 
			SOCKET_ASSERTMESSAGE( pData != 0, "STF Error: NULL pointer passed!\n" ); 

			SOCKET_MEMCPY( pBuffer, pData, iSize );
			pBuffer += iSize;
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<float>(unsigned char *pBuffer, float *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				if( m_ServerIsDifferentEndian )
				{
					unsigned char	*pUCData = reinterpret_cast<unsigned char*>(pData);
					int				i;
					for( i = 0 ; i < iSize ; i += sizeof(float) )
					{
						pUCData[i+3] = *pBuffer++;
						pUCData[i+2] = *pBuffer++;
						pUCData[i+1] = *pBuffer++;
						pUCData[i] = *pBuffer++;
					}
					return pBuffer;
				}

				float	*pFBuffer = reinterpret_cast<float*>(pBuffer);
				int		i;
				for( i = 0 ; i < iSize ; ++i )
				{
					pData[i] = *pFBuffer++;
				}
				return reinterpret_cast<unsigned char*>(pFBuffer);
			}
			pBuffer += iSize * sizeof(float);
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<unsigned int>(unsigned char *pBuffer, unsigned int *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				if( m_ServerIsDifferentEndian )
				{
					unsigned char	*pUCData = reinterpret_cast<unsigned char*>(pData);
					int				i;
					for( i = 0 ; i < iSize ; i += sizeof(unsigned int) )
					{
						pUCData[i+3] = *pBuffer++;
						pUCData[i+2] = *pBuffer++;
						pUCData[i+1] = *pBuffer++;
						pUCData[i] = *pBuffer++;
					}
					return pBuffer;
				}

				unsigned int	*pUIBuffer = reinterpret_cast<unsigned int*>(pBuffer);
				int				i;
				for( i = 0 ; i < iSize ; ++i )
				{
					pData[i] = *pUIBuffer++;
				}
				return (unsigned char*)pUIBuffer;
			}
			pBuffer += iSize * sizeof(unsigned int);
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<int>(unsigned char *pBuffer, int *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				if( m_ServerIsDifferentEndian )
				{
					unsigned char	*pUCData = (unsigned char*)pData;
					int				i;
					for( i = 0 ; i < iSize ; i += sizeof(int) )
					{
						pUCData[i+3] = *pBuffer++;
						pUCData[i+2] = *pBuffer++;
						pUCData[i+1] = *pBuffer++;
						pUCData[i] = *pBuffer++;
					}
					return pBuffer;
				}

				int	*pIBuffer = (int*)pBuffer;
				int i;
				for( i = 0 ; i < iSize ; ++i )
				{
					pData[i] = *pIBuffer++;
				}
				return (unsigned char*)pIBuffer;
			}
			pBuffer += iSize * sizeof(int);
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<unsigned short>(unsigned char *pBuffer, unsigned short *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				if( m_ServerIsDifferentEndian )
				{
					unsigned char	*pUCData = (unsigned char*)pData;
					int				i;
					for( i = 0 ; i < iSize ; i += sizeof(unsigned short) )
					{
						pUCData[i+1] = *pBuffer++;
						pUCData[i] = *pBuffer++;
					}
					return pBuffer;
				}

				unsigned short	*pUSBuffer = (unsigned short*)pBuffer;
				int				i;
				for( i = 0 ; i < iSize ; ++i )
				{
					pData[i] = *pUSBuffer++;
				}
				return (unsigned char*)pUSBuffer;
			}
			pBuffer += iSize * sizeof(unsigned short);
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<unsigned char>(unsigned char *pBuffer, unsigned char *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				SOCKET_MEMCPY( pData, pBuffer, iSize );
			}
			pBuffer += iSize;
			return pBuffer;
		};

		template <> inline unsigned char* Client::PopBuffer<char>(unsigned char *pBuffer, char *pData, int iSize /*= 1*/)
		{
			SOCKET_ASSERTMESSAGE( pBuffer != 0, "STF Error: NULL pointer passed!\n" ); 

			if( pData != 0 )
			{
				SOCKET_MEMCPY( pData, pBuffer, iSize );
			}
			pBuffer += iSize;
			return pBuffer;
		};
	}
}

#endif

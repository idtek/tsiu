
#ifndef _SOCKET_GAMEDEBUGCLIENT_H_
#define _SOCKET_GAMEDEBUGCLIENT_H_

#include "Socket/GameDefines.h"
#include "Socket/Client.h"
#include "Socket/Slot.h"
#include "Socket/source/Socket.h"
#include "Socket/GameDebugPeer.h"
#include "Socket/GameDebugInstructions.h"

namespace Axiom
{
	namespace Socket
	{
		struct ReadHeader;

		class GameDebugClient : public Client
		{
		public:

			// Constructor and virtual destructor
			GameDebugClient(void);
			virtual ~GameDebugClient(void);

			// Public methods
			void				SendFlow(int,unsigned char*,int);
			void				SendFlow(Instruction_t);

			// Public virtual methods
			virtual void	Init(SocketManager*,const char*,int,int);
			virtual void	OnReceive(unsigned char*,int);
			virtual void	OnDisconnect(void);

			void ResetKeepAliveTimeout(void);
			void UpdateKeepAlive(void);
			int GetTimeSinceLastActivity(void) { return m_TimeSinceLastActivity; }

			GameDebugPeer* GetGameDebugPeer() { return &m_GameDebugPeer; }

		private:
			GameDebugPeer		m_GameDebugPeer;
			int					m_TimeSinceLastActivity;
			bool				m_ConnectionOpened;
		};
	}
}

#endif

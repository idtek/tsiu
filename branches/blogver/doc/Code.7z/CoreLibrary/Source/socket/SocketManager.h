//------------------------------------------------------------------------------
//
//!  @file STFSocketManager.h
//!	 @brief	API for creating/destroying network sockets for communications
//--------------------------------------------------------------------------

#ifndef _SOCKET_SOCKETMANAGER_H_
#define _SOCKET_SOCKETMANAGER_H_

#include "Socket/Defines.h"

namespace Axiom
{
	namespace Socket
	{
		class Socket;

		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		SocketManager
		//!	@brief		An API to allow creation of sockets 
		//! @ingroup	Online
		//!
		//! The SocketManager is a module that manages creation and destruction of network sockets for the entire online networking layer.
		//---------------------------------------------------------------------------------------------------------------------------------	
		class SocketManager
		{
		public:

			// Constructor and virtual destructor
			SocketManager(const int iMaxNbSockets = SOCKETMANAGER_NBSOCKETS_MAX);
			virtual ~SocketManager(void);
			
#if !CORE_TOOLS
			// Get the singleton socket manager that is native to the current platform
			static SocketManager*			GetNativeSocketManager();
#endif
			void							Update(void);										//!< Update pump

			Socket*							AddSocket(void);									//!< Add a new socket for communication
			void							RemoveSocket(Socket*);							//!< Remove an existing socket
			inline const int				GetNbSockets(void);									//!< Get the Nth existing socket

		protected:
			virtual Socket*					CreateSocket(void) = 0;									//!< Create a platform-specific socket

		private:

			// Friendship declaration
			friend class Socket;
# if CORE_WIN32
			friend class Socket_Win32;
# elif CORE_XBOX360
			friend class Socket_Xbox360;
# elif CORE_PS3
			friend class Socket_PS3;
# endif

			// Private structures
			struct SocketNode_s
			{
				Socket					*m_pSocket;														//!< The socket pointer
				SocketNode_s			*m_pNextNode;													//!< Next socket node
			};

			// Socket list
			SocketNode_s				*m_pSocketNodes;												//!< List of socket nodes
			SocketNode_s				*m_pSocketHeadNode;												//!< The head socket node.
			SocketNode_s				*m_pSocketFreeNode;												//!< Free socket list
			int							m_NbSockets;													//!< Number of sockets
			int							m_MaxNbSockets;													//!< Max number of sockets

			// Private static methods
			static const unsigned long	GetLongFromAddress(char*);										//!< Convert address from string to int
			static const bool			GetAddressIsURL(char*);											//!< Check if string is a URL

			// Private methods
			void						ResetSocketList(void);											//!< Reset the socket list
			void						DestroySocketList(void);										//!< Destroy the list of sockets
			SocketNode_s*				AddInSocketList(Socket*);										//!< Add a new socket into the list
			SocketNode_s*				RemoveFromSocketList(Socket*);									//!< Destroy a socket

		};

		// Public inline implementation
		inline const int SocketManager::GetNbSockets(void)
		{
			return m_NbSockets;
		};

	}
}

#endif

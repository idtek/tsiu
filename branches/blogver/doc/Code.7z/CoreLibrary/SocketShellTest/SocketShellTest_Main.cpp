// ComonentLibraryUnitTest.cpp : Defines the entry point for the application.
//
// Desc: 
//
// This test initializes CoreLibrary subsystems and then creates a single component that
// accepts an STF (RemoteConsole) connection.  It is used for testing Core tools RemoteConsole
// and Reflection functionality.
//-------------------------------------------------------------------------------------
#include "debug/assert.h"
#include "core/time.h"
#include "reflection/script.h"
#include "reflection/serialize.h"
#include "reflection/typeregistry.h"
#include "reflection/textserializer.h"
#include "reflection/source/remote_reflection_tests.h"
#include "Socket/Game.h"
#include "files/filemanager.h"
#include "eventsystem/eventman.h"
#if CORE_WIN32
	#include <conio.h>
#endif

const char *gExecutableName = NULL;

#if CORE_PS3
#include <cell/sysmodule.h>
#include <netex/libnetctl.h>
#include <netex/net.h>
#include <np.h>
#endif

using namespace Axiom;
using namespace AP::Reflection;

#if CORE_PS3
void InitModules()
{
	if(cellSysmoduleLoadModule(CELL_SYSMODULE_FS) != CELL_OK)
	{
		Log("System","FAIL TO LOAD FILE SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD FILE SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_AVCONF_EXT) != CELL_OK)
	{
		Log("System","FAIL TO LOAD AUX VIDEO SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD AUX VIDEO SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_SYSUTIL_NP) != CELL_OK)
	{
		Log("System","FAIL TO LOAD NP SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD NP SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_RTC) != CELL_OK)
	{
		Log("System","FAIL TO LOAD RTC SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD RTC SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_NET) != CELL_OK)
	{
		Log("System","FAIL TO LOAD NET SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD NET SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_L10N) != CELL_OK)
	{
		Log("System","FAIL TO LOAD L10N SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD L10N SYS MODULE");
	}
}

void InitNetwork()
{
	const int NP_POOL_SIZE = (128*1024);
	static uint8_t g_np_sample_pool[NP_POOL_SIZE];

	if (cellNetCtlInit()<0)
	{
		Log("System", "FAIL TO INITIALIZE NETCTL");
		AP_ASSERTFAIL("FAIL TO INITIALIZE NETCTL");
	}

	if (sceNpInit (NP_POOL_SIZE, g_np_sample_pool)<0)
	{
		Log("System", "FAIL TO INITIALIZE NP");
		AP_ASSERTFAIL("FAIL TO INITIALIZE NP");
	}	

	if (sys_net_initialize_network()<0)
	{
		Log("System", "FAIL TO INITIALIZE NET");
		AP_ASSERTFAIL("FAIL TO INITIALIZE NET");
	}
}
#endif

static Axiom::EventMan sEventMan;

void InitCoreSystems()
{
	// Todo: Probably not necessary to create so many heaps.
	Axiom::Memory::Init(IN_MB(40));
	Axiom::Memory::RESERVED_CORE_HEAP		= Axiom::Memory::CreateHeap("RESERVED_CORE_HEAP",		IN_MB(14) );
	Axiom::Memory::RESERVED_SYSTEMS_HEAP	= Axiom::Memory::CreateHeap("RESERVED_SYSTEMS_HEAP",	IN_MB(1) );
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(15) );
	Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_KB(512) );
	Axiom::Memory::PHYSICS_HEAP				= Axiom::Memory::CreateHeap("PHYSICS_HEAP",				IN_KB(512) );
	Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_KB(512) );
	Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_KB(512) );
	Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_KB(512) );
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_KB(512) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_KB(512) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(2) );
	Axiom::Memory::OVERFLOW_HEAP = Axiom::Memory::DEFAULT_HEAP;
	Axiom::Memory::RESERVED_DEBUG_HEAP = Axiom::Memory::DEFAULT_HEAP;

	// Initialise logging sytem
	Axiom::InitLogging(Axiom::Memory::DEFAULT_HEAP, NULL);
#if CORE_WIN_BASED_OS
	//Direct log output to console window, not debug output window
	Axiom::LogToDebugOutput(false);
#endif

	Axiom::Socket::Game::Init(Axiom::Memory::DEFAULT_HEAP);
	Axiom::Socket::Game::GetInstance()->SetEventMan(&sEventMan);
	
#if CORE_PS3
	InitModules();
	InitNetwork();
#endif

	Axiom::FileManager::FileManager * fileManager = 0;
	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	fileManager = Axiom::FileManager::FileManager::GetInstance();
	fileManager->AddPathAlias("home:",				"file:");
	
#if CORE_XBOX360
	fileManager->SetDiskAliasPath("game:");
#elif CORE_WIN32	
	static char szBuffer[MAX_PATH] = {0};
	GetCurrentDirectory( MAX_PATH, szBuffer );
	fileManager->SetDiskAliasPath(szBuffer);
#endif
	
#if CORE_XBOX360 || CORE_WIN32
	//Get the command line string and chop off the arguments, keeping only the executable filename
	LPSTR commandLine = GetCommandLine();
	char executableFilename[256];
	int len = SOCKET_STRINGLENGTH(commandLine);
	const char* spaceChar = Axiom::StringFindChar(commandLine, ' ');
	if (spaceChar!=NULL)
		len = spaceChar - commandLine;
	SOCKET_STRINGCOPY(executableFilename, commandLine, len);
	executableFilename[len] = 0;
	if (executableFilename[0]=='\"') //Chop start quote character
	{
		SOCKET_STRINGCOPY(executableFilename, executableFilename+1, len-1);
		len--;
		executableFilename[len] = 0;
	}
	if (executableFilename[len-1]=='\"') //Chop end quote character
	{
		len--;
		executableFilename[len] = 0;
	}
#elif CORE_PS3
	const char* executableFilename = gExecutableName;
	const char* forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
	while (forwardSlashChar!=NULL)
	{
		executableFilename = forwardSlashChar+1;
		forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
	}
#elif CORE_WII
//TODO
	const char* executableFilename = "Unknown";
#endif
	fileManager->InitExecutableFilename(executableFilename);

	Script::Init();
	RuntimeTypeRegistry::Init(Axiom::Memory::DEFAULT_HEAP);

#if CORE_XBOX360
	RuntimeTypeRegistry::GetInstance()->GenerateTypeXML();
	Axiom::Log("Reflection", "Generated type XML to file: types.xml");
#endif

}

void ServeRemoteConnection(volatile bool& forever)
{
	Axiom::Log("REMOTESHELLTEST", "Waiting for connection...");
	//static bool forever = true;
	//int updatecount = 0;
	while (forever)
	{
		Axiom::Socket::Game::GetInstance()->Update();
		Axiom::Thread::Sleep(10);
		
		//Axiom::Log("socketshelltest", "update: %d", updatecount);
		//updatecount++;
	}
}

int main(int argc, char** argv)
{
#if CORE_WII
	OSInit();
#endif 
#if CORE_PS3
	gExecutableName = argv[0];
#else
	UNUSED_PARAM(argc);
	UNUSED_PARAM(argv);
#endif

	InitCoreSystems();
	sEventMan.Init();

	Script::Result tResult;
	const char* script;

	script = "TypeRegistry.InitRemoteReflectionTests();";
	tResult = Script::Execute(script);
	Axiom::Log("socketshelltest", "script: %s\n%s", script, tResult.ToString());

	script = "return Serialize.ToString(ReflectionTest, true)";
	tResult = Script::Execute(script);
	Axiom::Log("socketshelltest", "script: %s\n%s", script, tResult.ToString());

#if REFLECTION_DIAGNOSTICS
	AP::Reflection::RuntimeTypeRegistry::GetInstance()->PrintReflectionDiagnostics();
#endif

	bool forever = true;
	ServeRemoteConnection(forever);
	
#if CORE_WII
	OSRebootSystem();

	return 0;
#else
	return 0;
#endif 
}



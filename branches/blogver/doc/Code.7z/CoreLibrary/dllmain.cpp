#ifdef APDLL_EXPORTS

#include "stdafx.h"

BOOL APIENTRY DllMain( HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		{
			Axiom::Memory::Init(IN_MB(64)); // PLATFORM_MAXALLOC);				// Enough ?
			Axiom::Memory::RESERVED_CORE_HEAP		= Axiom::Memory::CreateHeap("RESERVED_CORE_HEAP",		IN_MB(32) );
			Axiom::Memory::RESERVED_DEBUG_HEAP		= Axiom::Memory::CreateHeap("RESERVED_DEBUG_HEAP",		IN_MB(1) );
			Axiom::Memory::RESERVED_SYSTEMS_HEAP	= Axiom::Memory::CreateHeap("RESERVED_SYSTEMS_HEAP",	IN_MB(1) );
			Axiom::Memory::DEFAULT_HEAP			= Axiom::Memory::CreateHeap("DEFAULT_HEAP",			IN_MB(32) );
			Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_MB(1) );
			Axiom::Memory::PHYSICS_HEAP			= Axiom::Memory::CreateHeap("PHYSICS_HEAP",			IN_MB(1) );
			Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_MB(1) );
			Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_MB(1) );
			Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_MB(1) );
			Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_MB(1) );
			Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_MB(1) );
			Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(1) );
			break;
		}
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;

		case DLL_PROCESS_DETACH:
			Axiom::Memory::Destroy();
			break;
	}
	return TRUE;
}

#endif
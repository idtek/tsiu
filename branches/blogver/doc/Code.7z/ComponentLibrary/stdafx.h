// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef __COMPONENT_LIBRARY_STDAFX_H_
#define __COMPONENT_LIBRARY_STDAFX_H_

//This _LIBNAME define is required in order to use the AP_PROXY macro for reflecting classes that require a proxy.
#ifdef _LIBNAME
#	error "_LIBNAME is already defined and must only be defined once per library/executable"
#else
#	define _LIBNAME "ComponentLibrary"
#endif

// TODO: reference additional headers your program requires here
#include <core/core.h>

#endif // __COMPONENT_LIBRARY_STDAFX_H_

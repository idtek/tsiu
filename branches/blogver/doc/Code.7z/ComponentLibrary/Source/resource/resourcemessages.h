#if !defined( RESOURCE_MESSAGES_H ) 
#define RESOURCE_MESSAGES_H

#include <eventsystem/eventmsg.h>
#include "collections/list.h"

#include "resource/rescommon.h"

namespace Axiom
{
	namespace FileManager
	{
		class FileInfo;
	}

	namespace Resource
	{
		/**
			@namespace Events
			A namespace that holds the events that are sent to and from the resource component.

			With events that have collections in them, the convention is to try and keep it so that
			only the resourcecomponent knows the underlying collection type.

			@see ResourcesAllocatedForGroupEvent
			@see AllocateResourcesForGroupEvent

			For examples
		*/

		namespace Events
		{
			//The joy of static lists being larger on the ps3.  Due to the way alignment is handled, I believe.
			//We can get rid of this with support for larger data events

#if CORE_PS3==CORE_YES || CORE_WII==CORE_YES
			static const UInt MaxNumAllocationsPerEvent = 9;
#else
			static const UInt MaxNumAllocationsPerEvent = 10;
#endif
			//Events sent TO resource component

			/**
				@class CreateResourceGroupEvent
				Event that tells resource component to create a new resource group
				The name is so that if a component fires off 5 of these, it can differentiate between them
				If loadImmediate is set to true, the resource component will begin to load files as they are added to the group.
				If it is set to false, it will wait until the group is closed
			*/

			class CreateResourceGroupEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( CreateResourceGroupEvent );

				/**
					Constructor
					@param name the name you wish to give the new resource group
					@param componentId the component requesting the group
				*/

				CreateResourceGroupEvent( const Axiom::Char* name, Axiom::UInt componentId, Int priority = -1  ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mName( name ),
					mComponentId( componentId ),
					mPriority( priority )
				{
				}

				/**
					@return the name
				*/

				const Axiom::ShortString& GetGroupName() const {return mName;}

				/**
					@return the component id
				*/

				UInt	GetComponentId() const {return mComponentId;}

				/**
					@return the groups priority
				*/

				Int		GetPriority() const {return mPriority;}

			private:

				Axiom::ShortString		mName;
				Axiom::UInt				mComponentId;	//The id of the component requesting this 
				Axiom::Int				mPriority;

			};	//class CreateResourceGroupEvent

			/**
				@class AddFilesToResourceGroupEvent
				Event that tells resource component to add some files
				To a resource group

				This event shouild be modified if we ever get better support for large data
				messages
			*/

			class AddFilesToResourceGroupEvent : public Axiom::EventMsg
			{
			public:

				//	The Filename and the unique id for the file
				typedef Collections::DynamicList< Pair< Resource::Filename, UInt > > FilesList;

				EVENT_MSG_GUID( AddFilesToResourceGroupEvent );

				/**
					Constructor
					@param id the id of the group to add files to
				*/

				AddFilesToResourceGroupEvent( GroupId id ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id )
				{
				}

				/**
					Constructor
					@param id the id of the group to add files to
					@param file the file
					@param uniqueId the unique id
				*/

				AddFilesToResourceGroupEvent( GroupId id, const Char* file, UInt uniqueId ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id )
				{
					mFilesList = AP_NEW( Axiom::Memory::DEFAULT_HEAP, FilesList );
					mFilesList->Resize( Axiom::Memory::DEFAULT_HEAP, 1 );
					mFilesList->Add( Pair< Resource::Filename, UInt >( file, uniqueId ) );
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}
							 

				/**
					Adds a list of files to the event
					@param filesList the list of files
					@note this list is not copied, and must be a valid pointer by the time it gets to the resource
					component
				*/

				void SetFilesList( FilesList* filesList ) {mFilesList = filesList;}

				/**
					@return the filesList
				*/

				const FilesList* GetFilesList() const {return mFilesList;}

			private:

				GroupId					mId;
				UInt					mUniqueId;
				FilesList*				mFilesList;
			};	//class AddFilesToResourceGroupEvent

			/**
				@class ResourcesAllocatedForGroupEvent
				A class that tells the resource component that the resources in question has been allocated
			*/

			class ResourcesAllocatedForGroupEvent : public EventMsg
			{
			public:
	
				typedef Axiom::Pair< void*, Int > AllocationInfo;

				EVENT_MSG_GUID( ResourcesAllocatedForGroupEvent );

				ResourcesAllocatedForGroupEvent( GroupId id ) :
					Axiom::EventMsg( EVENT_GUID ),
					mId( id )
				{
				}

				/**
					@return the groupId
				*/

				GroupId				GetGroupId() const {return mId;}

				/**
					@return the number of allocations
				*/

				UInt				GetNumberOfAllocations() const { return mAllocations.Count(); }

				/**
					@return the allocation info at the passed index
					@param index the index
				*/

				const AllocationInfo& GetAllocationInfo( UInt index ) const { return mAllocations[ index ]; }

				/**
					Adds an allocation
					@param buffer the buffer
					@param fileId the fileId
				*/

				void AddAllocation( void* buffer, Int fileId ) { mAllocations.Add( AllocationInfo( buffer, fileId ) ); }

			private:
				GroupId					mId;
			
				Axiom::Collections::StaticList< AllocationInfo, MaxNumAllocationsPerEvent > mAllocations;

			};	//class ResourcesAllocatedForGroupEvent

			/**
				@class RemoveFileFromResourceGroupEvent
				Event that tells resource component to remove a file
				From a resource group
			*/

			class RemoveFileFromResourceGroupEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( RemoveFileFromResourceGroupEvent );

				/**
					Constructor
					@param id the id of the group to add files to
				*/

				RemoveFileFromResourceGroupEvent( GroupId id, const Axiom::Char* file ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id ),
					mFile( file )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}
							 

				/**
					@return the file
				*/

				const Filename& GetFileName() const {return mFile;}

			private:

				GroupId				mId;
				Filename			mFile;
			};	//class RemoveFileFromResourceGroupEvent

			/**
				@class CloseResourceGroupEvent
				Event that tells resource component to close a resource group
				Once a resource group is closed, files can no longer be added
			*/

			class CloseResourceGroupEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( CloseResourceGroupEvent );

				/**
					@param id the group to close
				*/

				CloseResourceGroupEvent( GroupId id ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}

			private:
				GroupId	mId;
			};	//class CloseResourceGroupEvent

			/**
				@class MarkResourceGroupForRecycleEvent
				Event that tells ResourceComponent it may mark the data associated with this group for recycle
				If the forceRecylcle flag is set, the resource group will be immediately recycled (ie, no longer tracked)
			*/

			class MarkResourceGroupForRecycleEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( MarkResourceGroupForRecycleEvent );

				/**
					@param id the group to close
				*/

				MarkResourceGroupForRecycleEvent( GroupId id, Axiom::Bool forceRecyle = false ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id ),
					mForce( forceRecyle )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}

				/**
					@return force recycle
				*/

				Axiom::Bool IsForceRecycle() const { return mForce; }

			private:
				GroupId	mId;
				Axiom::Bool mForce;
			};	//class MarkResourceGroupForRecycleEvent

			/**
				Event that tells the resource component to recycle any resources flagged as recycled
			*/

			class RecycleResourcesEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( RecycleResourcesEvent );

				RecycleResourcesEvent() :
					Axiom::EventMsg( EVENT_GUID )
				{
				}

			};	//class RecycleResourcesEvent

			class HoldResourceAllocationsEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( HoldResourceAllocationsEvent );

				HoldResourceAllocationsEvent() :
					Axiom::EventMsg( EVENT_GUID )
				{
				}

			};	//class HoldResourceAllocationsEvent

			//Events sent FROM resource component

			/**
				@class ResourceGroupCreatedEvent
				Event that tells other components that the resource component has
				created this resource group
			*/

			class ResourceGroupCreatedEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( ResourceGroupCreatedEvent );

				ResourceGroupCreatedEvent( const Axiom::Char* name, GroupId id, Axiom::UInt componentId ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mName( name ),
					mId( id ),
					mComponentId( componentId )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}

				/**
					@return the group name
				*/

				const Axiom::ShortString& GetGroupName() const {return mName;}

				/**
					@return the component id
				*/

				Axiom::UInt GetComponentId() const {return mComponentId;}

			private:

				Axiom::ShortString	mName;
				GroupId				mId;
				Axiom::UInt			mComponentId;

			};	//class ResourceGroupCreatedEvent

			class AllocateResourcesForGroupEvent : public Axiom::EventMsg
			{
			public:
				
				typedef Axiom::Pair< UInt, Int > ResInfo;

				EVENT_MSG_GUID( AllocateResourcesForGroupEvent );

				AllocateResourcesForGroupEvent( Axiom::UInt componentId, GroupId group ) :
					Axiom::EventMsg( EVENT_GUID ),
					mGroupId( group ),
					mComponentId( componentId )
				{
				}	

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mGroupId;}

				/**
					@return the component id
				*/

				UInt GetComponentId() const {return mComponentId;}

				/**
					@return the number of resources
				*/
					
				UInt GetNumberOfResources() const {return mResourceInfo.Count();}

				/**
					@return is the event full
				*/

				Bool IsFull() const { return mResourceInfo.IsFull(); }

				/**
					@return the unique id of the resource at index
					@param index the index
				*/

				UInt GetUniqueId( UInt index ) const { return mResourceInfo[ index ].first; }

				/**
					@return the file id of the resource at index
					@param index the index
				*/

				Int GetFileId( UInt index ) const { return mResourceInfo[ index ].second; }

				/**
					Adds a resource
					@param resource to add
				*/

				void	AddResource( const ResInfo& resource ) { mResourceInfo.Add( resource ); }

			private:
				GroupId					mGroupId;
				UInt					mComponentId;
	
				Axiom::Collections::StaticList< ResInfo, MaxNumAllocationsPerEvent > mResourceInfo;

			};	//class AllocateResourcesForGroupEvent

			/**
				@class ResourceGroupLoadedEvent
				Tells a component that the a resource group has finished loading.
				This is not sent until
				A) every file in that group is loaded and
				B) the group is closed
			*/

			class ResourceGroupLoadedEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( ResourceGroupLoadedEvent );

				/**
					@param id the group id
				*/

				ResourceGroupLoadedEvent( GroupId id, Axiom::UInt componentId ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id ),
					mComponentId( componentId )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}

				/**
					@return the component id
				*/

				Axiom::UInt GetComponentId() const {return mComponentId;}
				
			private:
				GroupId		mId;
				Axiom::UInt	mComponentId;
			};	//class ResourceGroupLoadedEvent

			/**
				@class DeallocateResourceEvent
				Tells the components that the resource identified by the group
				and the filename in the message should be deallocated
				This message also contains the buffer where the resource was allocated to
			*/

			class DeallocateResourceEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( DeallocateResourceEvent );

				DeallocateResourceEvent( GroupId id, void* buffer, Axiom::UInt compId, Axiom::UInt uniqueId ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mId( id ),
					mBuffer( buffer ),
					mComponentId( compId ),
					mUniqueId( uniqueId )
				{
				}

				/**
					@return the groupId
				*/

				GroupId GetGroupId() const {return mId;}

				/**
					@return the buffer
				*/

				void* GetBuffer() const {return mBuffer;}
				
				/**
					@return the component id
				*/

				Axiom::UInt GetComponentId() const {return mComponentId;}

				/**
					@return the unique id
				*/

				Axiom::UInt GetUniqueId() const {return mUniqueId;}
				
			private:
				GroupId				mId;
				void*				mBuffer;
				Axiom::UInt			mComponentId;
				Axiom::UInt			mUniqueId;
			};	//class DeallocateResourceEvent

			class RecycleResourcesDoneEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( RecycleResourcesDoneEvent );

				RecycleResourcesDoneEvent() :
					Axiom::EventMsg( EVENT_GUID )
				{
				}
			};	//class RecycleResourcesDoneEvent


		}	//namespace Events

	}	//namespace Resource

}	//namespace Axiom

#endif //RESOURCE_COMMON_H

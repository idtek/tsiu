#if !defined( RESOURCE_INFO_TABLE_H ) 
#define RESOURCE_INFO_TABLE_H

#include "resource/rescommon.h"
#include "collections/booklet.h"
#include "core/singleton.h"
#include "files/fileinfo.h"

namespace Axiom
{
	namespace FileManager
	{
		class FileManager;
	}

	namespace Resource
	{
		/**
			@class InfoTable
			A class that seperates the information needed by project specific code to load a file (size) from the
			componenent levels and the file manager.

			IE, most project specific code should call InfoTable::GetFileSize to determine how much memory to allocate.
			NOT FileManager::GetInstance()->GetFileInfo
		*/

		class InfoTable : public Axiom::Singleton< InfoTable >
		{
		public:

			/**
				Creates an info table
			*/

			InfoTable();

			/**
				Pre Inits the info table.
				@param fileManager the file manager to use
			*/

			void PreInit( Axiom::FileManager::FileManager* fileManager );

			/**
				@return the size of the passed file
				@param name the file name
			*/

			Axiom::UInt	GetFileSize( const Filename& name );

		
			/**
				@return the size of the passed file
				@param fileId the id of the file
			*/

			Axiom::UInt	GetFileSize( Int fileId );

			/**
				@return the info associated with the passed file
				@param name the file name
			*/

			const Axiom::FileManager::FileInfo* GetFileInfo( const Filename& name );

			/**
				@return the info associated with the passed file
				@param fileId the id of the file
			*/

			const Axiom::FileManager::FileInfo* GetFileInfo( Int fileId );

			/**
				Clears the cache
			*/

			void	Clear() { mTable.Clear();}

		private:

			Axiom::FileManager::FileManager*	mFileManager;
			Axiom::Thread::Mutex				mMutex;

			//DAY 6/24/2008 10:52:13 AM
			//Sadly, the PC file names are long enough that we can't use Filename here

#if CORE_WIN32 == CORE_YES
			Axiom::Collections::DynamicBooklet< Axiom::FileManager::FileNameString, Axiom::FileManager::FileInfo, void > mTable;
#else
			Axiom::Collections::DynamicBooklet< Filename, Axiom::FileManager::FileInfo, void > mTable;
#endif
		};	//class InfoTable
	}	//namespace Resource
}	//namespace Axiom

#endif //RESOURCE_INFO_TABLE_H

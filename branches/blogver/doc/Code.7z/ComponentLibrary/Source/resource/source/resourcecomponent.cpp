#include "resource/resourcecomponent.h"
#include "resource/resourceinfotable.h"

#include "files/filemanager.h"
#include "asyncloader/asyncloadermessages.h"

namespace Axiom
{
	namespace Resource
	{		
		ResElement* ResGroup::Find( Int fileId )
		{
			for( Axiom::UInt i = 0; i < mResources.Count(); ++i )
			{
				if( mResources[i]->mFileId == fileId )
				{
					return mResources[i];
				}
			}

			return 0;
		}	

		void ResGroup::AddElement( ResElement* el )
		{
			if( mResources.IsFull() )
			{
				mResources.IncreaseAndCopy( Axiom::Memory::DEFAULT_HEAP, mResources.Count() + 4 );
			}

			mResources.Add( el );
		}

		Bool ResGroup::IsLoaded() const
		{
			for( Axiom::UInt i = 0; i < mResources.Count(); ++i )
			{
				if( !mResources[i]->mLoaded )
				{
					return false;
				}
			}

			return true;
		}

		ResourceComponent::ResourceComponent( ConstStr name, AP::Kernel* kernel ) :
			AP::Component( name, kernel  ),
			mNextId( InvalidResourceGroup ),
            m_ComponentMsgBox( NULL ),
			mFileManager( 0 ),
			mSizeCurrentlyLoading( 0 ),
			mMaxSizeAtOnce( 0 ),
			mLoadsPending( 0 ),
			mHoldAllocMark( 0 ),
			mHoldAllocations( false ),
			mIncrementalLoads( false )
		{
		}

		void ResourceComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("ResourceComponent", Axiom::Memory::DEFAULT_HEAP, 400, 500, 10);		
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::CreateResourceGroupEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::AddFilesToResourceGroupEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::ResourcesAllocatedForGroupEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::CloseResourceGroupEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::MarkResourceGroupForRecycleEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::RecycleResourcesEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::HoldResourceAllocationsEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::RemoveFileFromResourceGroupEvent::GetEventId() );
			
			m_ComponentMsgBox->RegisterListenBroadcastEvent( ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent::GetEventId() );
		}

		void ResourceComponent::PreInit( Axiom::FileManager::FileManager* fileManager, Axiom::UInt maxLoadSizeAtOnce, Axiom::UInt maxNumElements, Axiom::UInt maxNumGroups )
		{
			mFileManager = fileManager;
			mMaxSizeAtOnce = maxLoadSizeAtOnce;

			AP_ASSERT( mFileManager != 0 && mMaxSizeAtOnce > 0 );

			mResourceSets.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumGroups );
			mElements.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumElements );
			mClosedList.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumGroups );

			mLoadQueue.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumElements );
			mEventQueue.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumElements );
		}

		void ResourceComponent::OnUpdate()
		{
			AP_ASSERT( mFileManager != 0 );
			
			HandleEvents();

			//Note that here, we do keep track of the SIZE of how much is loading.  We do not keep track of the NUMBER of elements loading.
			//Size is our business, number of files is for the async loader to worry about

			while( !mLoadQueue.IsEmpty() )
			{
				const Int fileId = mLoadQueue[ 0 ]->mFileId;
				const Axiom::UInt size = InfoTable::GetInstance()->GetFileSize( fileId );
				
				if( mSizeCurrentlyLoading + size < mMaxSizeAtOnce )
				{
					mSizeCurrentlyLoading += size;
					TriggerLoadElement( *mLoadQueue[ 0 ] );
					mLoadQueue.RemoveAt( 0 );
				}
				else
				{
					break;
				}
			}	

			CheckClosedGroups();

			HandleQueuedAllocations();

			m_ComponentMsgBox->ClearOutbox();
		}

		void ResourceComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox( m_ComponentMsgBox );
			
			//Don't shut me down if I'm tracking files.  It's uncool at best
			AP_ASSERT( mSizeCurrentlyLoading == 0 );
		}

		void ResourceComponent::HandleEvents()
		{
			const Axiom::UInt numEvents = m_ComponentMsgBox->GetNumEvents();

			for( Axiom::UInt i = 0; i < numEvents; ++i )
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent( i );

				if( pMsg->GetGuidID() == Events::CreateResourceGroupEvent::EVENT_GUID )
				{
					OnCreateGroup( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::ResourcesAllocatedForGroupEvent::EVENT_GUID )
				{
					OnResourceAllocated( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::AddFilesToResourceGroupEvent::EVENT_GUID )
				{
					OnAddFilesToGroup( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::CloseResourceGroupEvent::EVENT_GUID )
				{
					OnCloseGroup( pMsg );
				}	
				else if( pMsg->GetGuidID() == Events::MarkResourceGroupForRecycleEvent::EVENT_GUID )
				{
					OnRecycleGroup( pMsg );
				}
				else if( pMsg->GetGuidID() == ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent::EVENT_GUID )
				{
					OnLoadComplete( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::RecycleResourcesEvent::EVENT_GUID )
				{
					OnRecycleResources( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::HoldResourceAllocationsEvent::EVENT_GUID )
				{
					OnHoldResourceAllocations( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::RemoveFileFromResourceGroupEvent::EVENT_GUID )
				{
					OnRemoveFileFromGroup( pMsg );
				}
			}

			m_ComponentMsgBox->ClearInbox();
		}

		void ResourceComponent::OnCreateGroup( const Axiom::EventMsg* pMsg )
		{
			const Events::CreateResourceGroupEvent* theEvent = pMsg->GetClass< Events::CreateResourceGroupEvent >();

			ResGroup newGroup( ++mNextId, theEvent->GetComponentId(), theEvent->GetPriority() );
			AP_DATAVALIDATION_SUPPORT( newGroup.mName = theEvent->GetGroupName().AsChar() );

			mResourceSets.Add( newGroup.mId, newGroup );

			Events::ResourceGroupCreatedEvent createdEvent( theEvent->GetGroupName().AsChar(), newGroup.mId, newGroup.mComponentId );
			m_ComponentMsgBox->SendEvent( &createdEvent );
		}

		void ResourceComponent::OnAddFilesToGroup( const Axiom::EventMsg* pMsg )
		{
			const Events::AddFilesToResourceGroupEvent* theEvent = pMsg->GetClass< Events::AddFilesToResourceGroupEvent >();

			ResGroup* group = GetGroup( theEvent->GetGroupId() );
			AP_ASSERT( group && !group->mClosed);

			const Events::AddFilesToResourceGroupEvent::FilesList* list = theEvent->GetFilesList();
			Events::AllocateResourcesForGroupEvent* allocateEvent = AP_NEW( Axiom::Memory::DEFAULT_HEAP, Events::AllocateResourcesForGroupEvent( group->mComponentId, group->mId ) );

			for( UInt i = 0; i < list->Count(); ++i )
			{
				const Axiom::FileManager::FileInfo* info = InfoTable::GetInstance()->GetFileInfo( list->Item( i ).first );

				ResElement* el = FindElement( info->GetId() );			

				if( el && group->Find( info->GetId() ) )
				{
					continue;
				}

				if( el == 0 )
				{
					AP_ASSERT( info->IsValid() );
					AP_ASSERT( static_cast< Axiom::UInt>( info->GetSize() ) < mMaxSizeAtOnce );

					el = AP_NEW( Axiom::Memory::DEFAULT_HEAP, ResElement( info->GetId(), list->Item( i ).second ) );
					mElements.Add( el );

					allocateEvent->AddResource( Events::AllocateResourcesForGroupEvent::ResInfo( list->Item( i ).second, info->GetId()  ) );

					if( IsIncrementalLoading() || allocateEvent->IsFull() )
					{
						mEventQueue.Add( allocateEvent );
						allocateEvent = AP_NEW( Axiom::Memory::DEFAULT_HEAP, Events::AllocateResourcesForGroupEvent( group->mComponentId, group->mId ) );
					}
				}
				else
				{
					Log( "Resource", "just ref count inc for %s", info->m_FileNameString.AsChar() );
				}

				el->mPriority = Axiom::Max( group->mPriority, el->mPriority );
				el->mRefCount++;
				group->AddElement( el );
			}

			if( allocateEvent->GetNumberOfResources() != 0 )
			{
				mEventQueue.Add( allocateEvent );
			}
			else
			{
				AP_DELETE( allocateEvent );
			}

			AP_DELETE( list );
		}

		void ResourceComponent::OnResourceAllocated( const Axiom::EventMsg* pMsg )
		{
			const Events::ResourcesAllocatedForGroupEvent* theEvent = pMsg->GetClass< Events::ResourcesAllocatedForGroupEvent >();

			for( UInt i = 0; i < theEvent->GetNumberOfAllocations(); ++i )
			{
				const Events::ResourcesAllocatedForGroupEvent::AllocationInfo& allocInfo = theEvent->GetAllocationInfo( i );

				const Axiom::FileManager::FileInfo* info = GetFileInfo( allocInfo.second );

				ResElement* el = FindElement( info->GetId() );
				AP_ASSERT( el && !el->mData );
				el->mData = allocInfo.first;

				AP_ASSERT( el->mData );

				if( !el->mLoadTriggered && !el->mLoaded )
				{
					AP_LOGGING_SUPPORT( PrintFileName( el->mFileId ) );
					el->mLoadTriggered = true;
					mLoadQueue.Add( el );
				}
			}
		}

		void ResourceComponent::OnCloseGroup( const Axiom::EventMsg* pMsg )
		{
			const Events::CloseResourceGroupEvent* theEvent = pMsg->GetClass< Events::CloseResourceGroupEvent >();

			ResGroup* group = GetGroup( theEvent->GetGroupId() );
			AP_ASSERT( group );

			group->mClosed = true;

			mClosedList.Add( group->mId );
		}

		void ResourceComponent::OnLoadComplete( const Axiom::EventMsg* pMsg )
		{
			const ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent* theEvent = pMsg->GetClass< ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent >();

			bool found = false;

			for( Axiom::UInt i = 0; i < mElements.Count(); ++i )
			{
				if( theEvent->m_FileInfo->GetId() == mElements[ i ]->mFileId &&
					mElements[ i ]->mLoadTriggered )
				{
					mElements[i]->mLoaded = true;
					mElements[i]->mLoadTriggered = false;

					found = true;
					break;
				}
			}

			if( found )
			{
				mSizeCurrentlyLoading -= theEvent->m_FileInfo->GetSize();
				mLoadsPending--;
			}
		}

		void ResourceComponent::OnRecycleGroup( const EventMsg* pMsg )
		{
			const Events::MarkResourceGroupForRecycleEvent* theEvent = pMsg->GetClass< Events::MarkResourceGroupForRecycleEvent >();

			ResGroup* group = GetGroup( theEvent->GetGroupId() );
			AP_ASSERT( group );
			AP_ASSERT( group->mResources.Count() == 0 || group->mClosed && group->IsLoaded() );

			if( theEvent->IsForceRecycle() )
			{
				RecycleGroup( group );
				mResourceSets.RemoveKey( group->mId );
			}
			else
			{
				group->mMarkedForRecycle = true;
			}
		}

		void ResourceComponent::OnRecycleResources( const Axiom::EventMsg* pMsg )
		{
			for( Axiom::UInt i = mResourceSets.Count(); i > 0; --i )
			{					
				ResGroup* group = &mResourceSets.GetItemByIndex( i - 1 );

				if( group->mMarkedForRecycle )
				{
					RecycleGroup( group );
					mResourceSets.RemoveAt( i - 1 );
				}
			}

			//Set hold allocs to false now that we have
			//recycled, and handle any queued allocations we had.
			//We do this now instead of waiting for the one in on update
			//because a client may have queued up some more loads and followed
			//them with another hold allocation message

			mHoldAllocations = false;
			mHoldAllocMark = 0;

			HandleQueuedAllocations();	
		
			Events::RecycleResourcesDoneEvent myEvt;
			m_ComponentMsgBox->SendEvent( &myEvt );
		}

		void ResourceComponent::OnHoldResourceAllocations( const EventMsg* pMsg )
		{
			mHoldAllocations = true;

			if( IsIncrementalLoading() )
			{
				if( mEventQueue.IsEmpty() )
				{
					mHoldAllocMark = 0;
				}
				else
				{
					//allow the group queued to finish.  Just that group though.
					mHoldAllocMark = 1;
					const GroupId first = mEventQueue[ 0 ]->GetGroupId();

					for( unsigned int i = 0; i < mEventQueue.Count(); ++i )
					{
						if( mEventQueue[ i ]->GetGroupId() != first )
						{
							mHoldAllocMark = i;
							break;
						}
					}
				}				
			}
		}

		Bool ResourceComponent::IsHoldingAllocations() const
		{ 
			if( mHoldAllocations )
			{
				if( mHoldAllocMark > 0 )
				{
					return false;
				}

				return true;
			}

			return false;
		}

		void ResourceComponent::CheckClosedGroups()
		{
			for( Axiom::UInt i = 0; i < mClosedList.Count(); ++i )
			{
				ResGroup* group = GetGroup( mClosedList[ i] );

				if( group->IsLoaded() )
				{
					Events::ResourceGroupLoadedEvent myEvt( group->mId, group->mComponentId );
					m_ComponentMsgBox->SendEvent( &myEvt );

					mClosedList.RemoveAt( i );
					--i;
				}
			}
		}

		void ResourceComponent::HandleQueuedAllocations()
		{
			//DAY 6/26/2008 2:56:07 PM
			//When allocating resources, we need to give the components time to dealloc current ones in use before
			//we try and allocate new ones.  The core pres component sends an event to set this mHoldAllocations flag before it assigns
			//all the new game elements to its groups.  This gives it time to respond to the de allocs before trying the allocs


			//Non incremental is yes or no
			if( !IsIncrementalLoading() )
			{
				if( !IsHoldingAllocations() )
				{
					for( Axiom::UInt i = 0; i < mEventQueue.Count(); ++i )
					{
						m_ComponentMsgBox->SendEvent( mEventQueue[ i ] );
						AP_DELETE( mEventQueue[ i ] );
						mLoadsPending++;
					}

					mEventQueue.Clear();
				}
			}
			else
			{
				//Hold alloc mark is the number of events we had to handle in the queue BEFORE we got the request to hold allocations.
				//We can't squelch these during incremental loading the same way we can non incremental

				if( !IsHoldingAllocations() )
				{
					if( mLoadsPending == 0 && !mEventQueue.IsEmpty() )
					{
						Events::AllocateResourcesForGroupEvent* myEvt = mEventQueue[ 0 ];
						m_ComponentMsgBox->SendEvent( myEvt );

						//This is not a quick remove because we want to preserve order.  Better collection choice?
						mEventQueue.RemoveAt( 0 );
						AP_DELETE( myEvt );

						mLoadsPending++;

						if( mHoldAllocMark > 0 )
						{
							mHoldAllocMark--;
						}
					}
				}
			}
		}

		void ResourceComponent::RecycleGroup( ResGroup* group )
		{
			for( Axiom::UInt i = 0; i < group->mResources.Count(); ++i )
			{			
				ResElement* el = group->mResources[ i ];

				AP_ASSERT( el->mLoaded && el->mData && el->mRefCount > 0 );

				el->mRefCount--;

				if( el->mRefCount == 0 )
				{
					FreeElement( el, group );
				}
			}

			group->mResources.Clear();
		}

		void ResourceComponent::OnRemoveFileFromGroup( const EventMsg* pMsg )
		{
			const Events::RemoveFileFromResourceGroupEvent* theEvent = pMsg->GetClass< Events::RemoveFileFromResourceGroupEvent >();

			ResGroup* group = GetGroup( theEvent->GetGroupId() );
			AP_ASSERT( group );

			if( group->mResources.Count() == 1 )
			{
				RecycleGroup( group );
				mResourceSets.RemoveKey( group->mId );
			}
			else
			{
				const Axiom::FileManager::FileInfo* info = InfoTable::GetInstance()->GetFileInfo( theEvent->GetFileName().AsChar() );

				for( Axiom::UInt i = 0; i < group->mResources.Count(); ++i )
				{
					ResElement* el = group->mResources[ i ];

					if( el->mFileId == info->GetId() )
					{
						el->mRefCount--;

						if( el->mRefCount == 0 )
						{
							group->mResources.QuickRemove( el );
							FreeElement( el, group );
						}
					}
				}
			}
		}

		ResElement* ResourceComponent::FindElement( Int fileId )
		{
			for( Axiom::UInt i = 0; i < mElements.Count(); ++i )
			{
				if( mElements[ i ]->mFileId == fileId )
				{
					return mElements[ i ];
				}
			}

			return 0;
		}

		void ResourceComponent::FreeElement( ResElement* el, const ResGroup* group )
		{
			//DAY 5/26/2008 10:37:47 AM  We can't use file names here because people ask for files like media://Superstar.lua
			//And the file info contains Superstar.lua, or C:\Work\SoccerSuperstar\WorkingDirectory\Media\Superstar.lua.
			//So to get the name they asked for from what we have, we'd have to do some fancy alias work, or store it.
			//I think between the buffer they allocated and the id of the file, they should be able to identify it

			Events::DeallocateResourceEvent myEvt( group->mId, el->mData, group->mComponentId, el->mUniqueId );
			m_ComponentMsgBox->SendEvent( &myEvt );				
							
			mElements.QuickRemove( el );
			AP_DELETE( el );
		}

		const Axiom::FileManager::FileInfo* ResourceComponent::GetFileInfo( Int fileId ) const
		{
			return InfoTable::GetInstance()->GetFileInfo( fileId );
		}

		ResGroup*	ResourceComponent::GetGroup( GroupId id )
		{
			return mResourceSets.Item( id );
		}

		void ResourceComponent::TriggerLoadElement( ResElement& el  )
		{
			AP_ASSERT( !el.mLoaded && el.mData );

			ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestEvent myEvt;
			myEvt.m_FileInfo = GetFileInfo( el.mFileId );
			myEvt.m_pBuffer = el.mData;
			myEvt.m_Priority = el.mPriority;

			m_ComponentMsgBox->SendEvent( &myEvt );
		}

#if CORE_LOGGING 
		void ResourceComponent::DebugPrintElements() const 
		{
			for( Axiom::UInt i = 0; i < mElements.Count(); ++i )
			{
				const ResElement* el = mElements[ i ];
				const Axiom::FileManager::FileInfo* info = GetFileInfo( el->mFileId );
				Log( "Resource", "element at %d is %s with ref count %d", i, info->m_FileNameString.AsChar(), el->mRefCount );;
			}
		}

		void ResourceComponent::PrintFileName( int fileID ) const
		{
			const Axiom::FileManager::FileInfo* info = GetFileInfo( fileID );
			Log( "Resource", "filename is %s", info->m_FileNameString.AsChar() );
		}
#endif

	}	//namespace Resource
}	//namespace Axiom


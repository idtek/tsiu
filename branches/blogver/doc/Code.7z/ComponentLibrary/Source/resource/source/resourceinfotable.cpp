#include "resource/resourceinfotable.h"

#include "files/filemanager.h"

namespace Axiom
{
	namespace Resource
	{
		InfoTable::InfoTable( ) :
			mFileManager( 0 )
		{
			mTable.Resize( Axiom::Memory::OVERFLOW_HEAP, 800 );
		}

		void InfoTable::PreInit( Axiom::FileManager::FileManager* fileManager )
		{
			mFileManager = fileManager;
			AP_ASSERT( mFileManager != 0 );
		}

		Axiom::UInt	InfoTable::GetFileSize( const Filename& name )
		{
			const Axiom::FileManager::FileInfo* info = GetFileInfo( name );
			AP_ASSERT( info && info->IsValid() );

			return ( info ? info->GetSize() : 0 );
		}

		Axiom::UInt	InfoTable::GetFileSize( Int fileId )
		{
			const Axiom::FileManager::FileInfo* info = GetFileInfo( fileId );
			AP_ASSERT( info && info->IsValid() );

			return ( info ? info->GetSize() : 0 );
		}

		const Axiom::FileManager::FileInfo* InfoTable::GetFileInfo( const Filename& name )
		{
			AP_ASSERTMESSAGE(name.Length() > 0, "InfoTable::GetFileInfo: Invalid file name.");

			const FileManager::VirtualFilePathString virtualName( mFileManager->ResolveFilePath( name.AsChar() ) );

			if( !mTable.ContainsKey( virtualName.AsChar() ) )
			{
				mMutex.Lock();
				const FileManager::FileInfo info = mFileManager->GetFileInfo( name.AsChar() );
				mTable.Add( virtualName.AsChar(), info );
				mMutex.Unlock();
			}
			
			return mTable.ConstItem( virtualName.AsChar() );
		}

		const Axiom::FileManager::FileInfo* InfoTable::GetFileInfo( Int fileId )
		{
			for( Axiom::UInt i = 0; i < mTable.Count(); ++i )
			{
				if( mTable[ i ].GetId() == fileId )
				{
					return &mTable[ i ];
				}
			}

			return  0;
		}

	}	//namespace Resource
}	//namespace Axiom


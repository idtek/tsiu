#if !defined( RESOURCE_COMMON_H ) 
#define RESOURCE_COMMON_H

#include "core/Core.h"

namespace Axiom
{
	namespace Resource
	{
		typedef Axiom::StaticString< 100 > Filename;

		//I'm calling this a group and not a set to avoid confusion with existing code
		typedef Int16 GroupId;
		static const GroupId InvalidResourceGroup = -1;

	}	//namespace Resource
}	//namespace Axiom

#endif //RESOURCE_COMMON_H

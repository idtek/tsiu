#if !defined( RESOURCE_COMPONENT_H ) 
#define RESOURCE_COMPONENT_H

#include <kernel/component.h>

#include "resource/rescommon.h"
#include "resource/resourcemessages.h"

#include "collections/booklet.h"
#include "collections/list.h"

namespace Axiom
{
	namespace FileManager
	{
		class FileManager;
		class FileInfo;
	}

	/**
		@namespace Resource
		A namespace for the resource related components and classes
	*/
		
	namespace Resource
	{
		class ResElement
		{
		public:

			ResElement( Int fileId = -1, UInt uniqueId = 0, void* data = 0 ) :
				mFileId( fileId ),
				mLoadTriggered( false ),
				mLoaded( false ),
				mRefCount( 0 ),
				mUniqueId( uniqueId ),
				mPriority( -1 ),
				mData( data )
			{
			}

			Bool operator==( const ResElement& el ) const { return ( el.mFileId == mFileId); }

			//File management
			Int								mFileId;
			Bool							mLoadTriggered;
			Bool							mLoaded;
			UInt							mRefCount;
			UInt							mUniqueId;
			Int								mPriority;

			//DATA!
			void*							mData;
		};

		class ResGroup
		{
		public:
			ResGroup( GroupId id, Axiom::UInt componentId, Int priority = -1  ) :
				mId( id ),
				mClosed( false ),
				mMarkedForRecycle( false ),
				mComponentId( componentId ),
				mPriority( priority )
			{
			}

			ResElement* Find( Int fileId );

			void AddElement( ResElement* el );
			
			Bool IsLoaded() const;

			GroupId			mId;
			Bool			mClosed;
			Bool			mMarkedForRecycle;
			UInt			mComponentId;
			Int				mPriority;

			Collections::DynamicList< ResElement* > mResources;

			AP_DATAVALIDATION_SUPPORT( Axiom::ShortString mName; )
		};

		//I know.  Resource::ResourceComponent.  Will change when we move to the new resource system

		/**
			@class ResourceComponent.
			A class that manages resources and resource groups.
			Passes load requests off to async loading component
		*/

		class ResourceComponent : public AP::Component
		{
		public:

			/**
				Constructs a resource component
				@param name the name of the component
				@param kernel the kernel to run on
				@param maxSizeAtOnce the max size at once that this component will allow to load
			*/

			ResourceComponent( ConstStr name, AP::Kernel* kernel );

			void	OnInit();
			void	OnUpdate();
			void	OnShutdown();

			/**
				Pre init the component
				@param fileManager the file manager for this component to use
				@param maxLoadSizeAtOnce the max amount of data to load at once ( in BYTES )
			*/

			void	PreInit( Axiom::FileManager::FileManager* fileManager, Axiom::UInt maxLoadSizeAtOnce, Axiom::UInt maxNumElements, Axiom::UInt maxNumGroups );

			/**
				@return the number of groups being tracked by the resource manager
			*/

			UInt	GroupCount() const { return mResourceSets.Count(); }

			/**
				Set the incremental loads flag
				Incremental load mode is where the resource component loads elements one at a time.  It also waits until an element is loaded before
				firing off another allocation event.  This is for hardware like the ps3 that have multiple memory systems, and our rendering system uses a re alloc
				on those machines once memory is copied into different memory.  This re alloc will cause MASSIVE fragmentation if we alloc more than one file before we load
				@param incrementalLoads to use Incremental Loads or not
			*/

			void	SetIncrementalLoads( Bool incrementalLoads ) { mIncrementalLoads = incrementalLoads; }

		private:

			//Event related functions

			void	HandleEvents();

			void	OnCreateGroup( const EventMsg* pMsg );
			void	OnResourceAllocated( const EventMsg* pMsg );
			void	OnAddFilesToGroup( const EventMsg* pMsg );
			void	OnCloseGroup( const EventMsg* pMsg );
			void	OnLoadComplete( const EventMsg* pMsg );
			void	OnRecycleGroup( const EventMsg* pMsg );
			void	OnRecycleResources( const EventMsg* pMsg );
			void	OnRemoveFileFromGroup( const EventMsg* pMsg );
			void	OnHoldResourceAllocations( const EventMsg* pMsg );

			//State

			Bool	IsIncrementalLoading() const { return mIncrementalLoads; }
			Bool	IsHoldingAllocations() const;

			void	CheckClosedGroups();
			void	HandleQueuedAllocations();

			void	TriggerLoadElement( ResElement& el );

			//data access events

			ResGroup*	GetGroup( GroupId id );
			ResElement* FindElement( Int fileId ); 
			void		FreeElement( ResElement* el, const ResGroup* group );

			void		RecycleGroup( ResGroup* group );

			const FileManager::FileInfo*	GetFileInfo( Int fileId ) const;

			AP_LOGGING_SUPPORT( void		DebugPrintElements() const ;)
			AP_LOGGING_SUPPORT( void		PrintFileName( int fileID ) const; )

		private:			

			Collections::DynamicBooklet< GroupId, ResGroup, GroupId >	mResourceSets;

			GroupId								mNextId;
            EventMsgBoxHandle					m_ComponentMsgBox;
			FileManager::FileManager*			mFileManager;

			UInt								mSizeCurrentlyLoading;
			UInt								mMaxSizeAtOnce;
			UInt								mLoadsPending;
			UInt								mHoldAllocMark;
			Bool								mHoldAllocations;
			Bool								mIncrementalLoads;

			Collections::DynamicList< ResElement* > mElements;
		
			Collections::DynamicList< ResElement* > mLoadQueue;	
			Collections::DynamicList< GroupId  > mClosedList;

			Collections::DynamicList< Events::AllocateResourcesForGroupEvent* > mEventQueue;

		};	//class ResourceComponent

	}	//namespace Resource
}	//namespace Axiom

#endif //RESOURCE_COMPONENT_H

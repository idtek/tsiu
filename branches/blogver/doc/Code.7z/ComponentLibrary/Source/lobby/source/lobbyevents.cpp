
#include "lobby/lobbyevents.h"

using namespace Lobby::Events;

AP_TYPE(LobbyInitialize)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Type", m_nLobbyType, "Type of lobby to create.")
AP_TYPE_END()

AP_TYPE(LobbyAuthenticationEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Status", m_bStatus, "Login status.")
AP_TYPE_END()

AP_TYPE(LobbyInitializationEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Status", m_bStatus, "Login status.")
AP_TYPE_END()

AP_TYPE(LobbyShutdown)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyEnumerationEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyStartMatchmaking)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Params", m_Params, "Matchmaking Parameters")
AP_TYPE_END()

AP_TYPE(LobbyStopMatchmaking)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyJoinSession)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyLeaveSession)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyEnterSessionEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbySessionExitEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyEntityStatsUpdateEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyOperationStatusEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyEndMatch)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyPlayerInfoEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyEndMatchEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyStatsQueryEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyLeaderboardQueryComplete)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyPrivateMatchConnected)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyFriendsQueryComplete)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()


AP_TYPE(LobbyFriendsQueryEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyInviteFriendToMatch)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LobbyRemotePlayerRecieved)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()


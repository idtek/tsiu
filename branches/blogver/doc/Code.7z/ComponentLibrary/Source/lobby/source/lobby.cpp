
#include "lobby/lobby.h"

using namespace Lobby;

LobbyObj::~LobbyObj()
{
	m_eventQueue.Clear();
}


AP_TYPE(MatchmakingParameters)
	AP_DEFAULT_CREATE()
	AP_FIELD("NoOfSearchAttributes",			m_nNoOfSearchAttributes,	"Number of search attribuetes being used")
	AP_FIELD("IsRanked",						m_bIsRanked,				"if the online game is ranked or not")
	AP_FIELD("Private",						m_bPrivate,					"Private match or not")
	AP_FIELD("AutoJoin",						m_bAutoJoin,				"If its auto join or not")
	AP_FIELD("SearchAttributes",				m_aSearchAttributeValues,	"search attributes")
	AP_FIELD("Visible",						m_bVisible,					"is visible")
AP_TYPE_END()


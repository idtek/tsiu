
#include "core/core.h"

#include "lobby/lobbycomponent.h"
#include "lobby/lobbyevents.h"
#include "lobby/lobbymanager.h"
#include "lobby/lobbyinterfaces.h"

#include "network/networksessionevents.h"

#include <eventsystem/eventman.h>

using namespace Lobby;

// C-tor
LobbyComponent::LobbyComponent (Axiom::ConstStr name, AP::Kernel* kernel) : 
	AP::Component(name, kernel),
    m_ComponentMsgBox( NULL ),
	mRefCounter( 0 )
{	
	m_Random.Seed(866);
}


// D-tor
LobbyComponent::~LobbyComponent()
{
	// Do nothing
}


// Component methods:
void LobbyComponent::OnInit()
{
	m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Lobby");
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyInitialize::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyShutdown::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyStartMatchmaking::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyStopMatchmaking::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyJoinSession::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyLeaveSession::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyEndMatch::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyPlayerInfoEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyStatsQueryEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyFriendsQueryEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyInviteFriendToMatch::EVENT_GUID);
	
	
	// Network session events
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionPeerConnectionEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionPeerDisconnectionEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionStartGameRound::EVENT_GUID);
}


// Polls component events from local event queue and handles them.
void LobbyComponent::HandleEvents()
{

    const Axiom::UInt numEvents = m_ComponentMsgBox->GetNumEvents();

	for( Axiom::UInt i = 0; i < numEvents; ++i)
	{
		const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);		
		const Axiom::EventMsgId msgId = pMsg->GetGuidID();			
		Axiom::Bool opStatus = false;

		if (msgId == Events::LobbyInitialize::EVENT_GUID)
		{
			// Initialization:
			Initialize();
		}
		else if (msgId == Lobby::Events::LobbyStartMatchmaking::EVENT_GUID)
		{
			// Matchmaking:
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			const Lobby::Events::LobbyStartMatchmaking* pMatchmakingRequest = pMsg->GetClass<Lobby::Events::LobbyStartMatchmaking>();
			Axiom::Log("lobby", "Received request to start matchmaking.");
			if (pLobby != 0)
			{	
				opStatus = pLobby->StartMatchmaking( pMatchmakingRequest->m_Params );
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Lobby::Events::LobbyStopMatchmaking::EVENT_GUID)
		{
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			Axiom::Log("lobby", "Received request to stop matchmaking.");
			if (pLobby != 0)
			{
				opStatus = pLobby->StopMatchmaking();
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Lobby::Events::LobbyJoinSession::EVENT_GUID)
		{
			// Join Session:
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			const Lobby::Events::LobbyJoinSession* pJoinRequest = pMsg->GetClass<Lobby::Events::LobbyJoinSession>();
			Axiom::Log("lobby", "Handling request to join session, name= <UNICODE STR>.");

			if (pLobby != 0 && pJoinRequest != 0)
			{
				opStatus = pLobby->JoinSession(pJoinRequest->m_strSessionToJoin);
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Network::Events::SessionPeerConnectionEvent::EVENT_GUID)
		{
			const Network::Events::SessionPeerConnectionEvent* pConnectionEvent = pMsg->GetClass<Network::Events::SessionPeerConnectionEvent>();
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();

			Axiom::Log("lobby", "Received connection event for %s connection to %s peer.", 
				(pConnectionEvent->m_bStatus ? "successful" : "failed"), (pConnectionEvent->m_bIsLocal ? "local" : "remote")); 

			if (pLobby != 0)
			{
				if (pConnectionEvent->m_bIsLocal == false) 
				{
					if (pConnectionEvent->m_bStatus == true)
					{
						opStatus = pLobby->PlayerAccepted();
					}
					else
					{
						opStatus = pLobby->LeaveSession();
					}
				}
				else 
				{
					// Do nothing
				}
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Network::Events::SessionPeerDisconnectionEvent::EVENT_GUID)
		{
			const Network::Events::SessionPeerDisconnectionEvent* pDisconnectionEvent = pMsg->GetClass<Network::Events::SessionPeerDisconnectionEvent>();
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();

			Axiom::Log("lobby", "Received disconnection event for %s peer.", (pDisconnectionEvent->m_bIsLocal ? "local" : "remote"));
			if (pLobby != 0 && pDisconnectionEvent->m_bStatus == true)
			{
				opStatus = pLobby->LeaveSession();
			}
		}
		else if (msgId == Lobby::Events::LobbyEndMatch::EVENT_GUID)
		{
			LobbyObj* pLobby = LobbyObjManager::Instance()->CurrentLobby();

			if( pLobby )
			{
				opStatus = pLobby->EndMatch( LobbyObjManager::Instance()->GetMatchStats() );
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Lobby::Events::LobbyLeaveSession::EVENT_GUID)
		{
			// Leave Session:
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			Axiom::Log("lobby", "Handling request to leave current session.");
			if (pLobby != 0 )
			{
				opStatus = pLobby->LeaveSession();
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Lobby::Events::LobbyShutdown::EVENT_GUID)
		{
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			
			Axiom::Log("lobby", "Handling request to shutdown current lobby.");

			mRefCounter--;

			if( pLobby && mRefCounter == 0)
			{
				pLobby->Shutdown();
				// Even if shutdown fails we cannot do anything with result anyway.
				opStatus = true;
			}
			else
			{
				// There is no active lobby in a system - just send completion event.
				Lobby::Events::LobbyInitializationEvent evt;

				evt.m_bStatus = false;
				m_ComponentMsgBox->SendEvent(&evt);
			}
		}
		else if (msgId == Network::Events::SessionStartGameRound::EVENT_GUID)
		{
			// StartMatch:
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			Axiom::Log("lobby", "Handling request to start game round.");
			if (pLobby != 0)
			{
				opStatus = pLobby->StartMatch();
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Lobby::Events::LobbyPlayerInfoEvent::EVENT_GUID)
		{
			// Player info from remote host.
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			const Lobby::Events::LobbyPlayerInfoEvent* pPlayerInfo = pMsg->GetClass<Lobby::Events::LobbyPlayerInfoEvent>();
			if (pLobby != 0 && pPlayerInfo != 0)
			{
				pLobby->SetRemotePlayerInfo(pPlayerInfo->m_acRawData, pPlayerInfo->m_nRawDataSize);
			}
			else
			{
				AP_ASSERT(0);
			}
		}
		else if( msgId == Events::LobbyStatsQueryEvent::EVENT_GUID )
		{
			const Lobby::Events::LobbyStatsQueryEvent* eventInfo = pMsg->GetClass<Lobby::Events::LobbyStatsQueryEvent>();

			if( LobbyObjManager::Instance()->CurrentLobby() )
			{
				if( LobbyObjManager::Instance()->QueryStats( eventInfo->mData ) )
				{
					Events::LobbyLeaderboardQueryComplete completeEvent;
					m_ComponentMsgBox->SendEvent( &completeEvent );
				}
			}

			opStatus = true;
		}
		else if( msgId == Events::LobbyFriendsQueryEvent::EVENT_GUID )
		{
			const Events::LobbyFriendsQueryEvent* eventInfo = pMsg->GetClass<Lobby::Events::LobbyFriendsQueryEvent>();

			if( LobbyObj* lobby = Lobby::LobbyObjManager::Instance()->CurrentLobby() )
			{
				lobby->GetFriendList( eventInfo->mStartValue, eventInfo->mNumberToReturn );
			}
		}
		else if( msgId == Events::LobbyInviteFriendToMatch::EVENT_GUID )
		{
			const Events::LobbyInviteFriendToMatch* friendEvent = pMsg->GetClass<Lobby::Events::LobbyInviteFriendToMatch>();

			if( LobbyObj* lobby = Lobby::LobbyObjManager::Instance()->CurrentLobby() )
			{
				lobby->InviteToGame( friendEvent->mName );
			}
		}
		else
		{
			// Since we register for events explicitly there is no reason to be registered for events we don't need
			AP_ASSERT(0);
		}

		// Send back status of lobby operation.
		Lobby::Events::LobbyOperationStatusEvent lobbySyatusEvent(msgId, opStatus);
		m_ComponentMsgBox->SendEvent(&lobbySyatusEvent);
	}

	m_ComponentMsgBox->ClearInbox();
}


// Called by Component manager within regular intervals
void LobbyComponent::OnUpdate()
{
	// Give some CPU time to lobby

    if( LobbyObjManager::Instance()->Update() )
	{
		//If this returns true, then the lobby manager has told us
		//we need to initialize a lobby
		Initialize();
	}

	HandleEvents();

	Lobby::LobbyObj* pLobby = 0;

	// Process internal lobby events. We check if lobby still available with every iteration, 
	// because one of event handler function(s) can pull it from underneath. i.e. look at OnLobbyInitializationEvent().
	while((pLobby = LobbyObjManager::Instance()->CurrentLobby()) != 0)
	{	
		Axiom::SmartPtr<InternalEvent> ptrEvent = pLobby->GetEvent();
		if (ptrEvent.IsValid())
		{
			InternalEvent::EvtType lobbyEvtType = ptrEvent->TypeOf();
			switch(lobbyEvtType)
			{
			case InternalEvent::LE_INITIALIZATIONEVENT:
				OnLobbyInitializationEvent(ptrEvent);
				break;
			case InternalEvent::LE_AUTHENTICATIONEVENT:
				OnAuthenticationLobbyEvent(ptrEvent);
				break;				
			case InternalEvent::LE_ENUMERATIONEVENT:
				OnLobbyEnumerationEvent(ptrEvent);  
				break;
			case InternalEvent::LE_ENTERSESSIONEVENT:
				OnEnterSessionEvent(ptrEvent);
				break;
			case InternalEvent::LE_SESSIONEXITEVENT:
				OnSessionExitEvent(ptrEvent);
				break;
			case InternalEvent::LE_LOCALPLAYERINFOEVENT:
				OnLocalPlayerInfoEvent(ptrEvent);
				break;
			case InternalEvent::LE_ENDMATCHEVENT:
				OnEndMatchEvent(ptrEvent);
				break;
			case InternalEvent::LE_ENTITYSTATSUPDATE:
				OnLobbyEntityStatsUpdate(ptrEvent);
				break;
			case InternalEvent::LE_LEADERBOARDSTATSUPDATE:
				OnLobbyLeaderboardStatsUpdate( ptrEvent );
				break;
			case InternalEvent::LE_PRIVATEMATCHREADY:
				OnLobbyPrivateMatchReady( ptrEvent );
				break;
			case InternalEvent::LE_FRIENDQUERYCOMPLETE:
				OnFriendQueryComplete( ptrEvent );
				break;
			default:
				break;
			}
		}
		else 
		{
			break;
		}
	}

	// - Deliver all message from Outgoing message box to recipients.
	m_ComponentMsgBox->ClearOutbox();
}


// 
void LobbyComponent::OnLobbyEntityStatsUpdate( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{	
	const Lobby::LobbyEntityStatsUpdate* pStatsUpdate = static_cast< const Lobby::LobbyEntityStatsUpdate*>(ptrEvent.pVal());
	if (pStatsUpdate != 0)
	{			
		Lobby::LobbyObjManager::Instance()->SetEntityStats( pStatsUpdate->mData );

		if( pStatsUpdate->mRemote )
		{
			Events::LobbyRemotePlayerRecieved rcvdEvent;
			m_ComponentMsgBox->SendEvent( &rcvdEvent );
		}
	}
	else
	{
		AP_ASSERT(0);
	}
}


//
void LobbyComponent::OnEndMatchEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyEndMatchEvent* pEndMatchEvent = static_cast< const Lobby::LobbyEndMatchEvent*>(ptrEvent.pVal());
	if (pEndMatchEvent != 0)
	{
		Lobby::Events::LobbyEndMatchEvent evt(pEndMatchEvent->m_bStatus);
		m_ComponentMsgBox->SendEvent(&evt);	
	}
	else
	{
		AP_ASSERT(0);
	}
}


// 
void LobbyComponent::OnLocalPlayerInfoEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyLocalPlayerInfo* pPlayerInfoEvent = static_cast< const Lobby::LobbyLocalPlayerInfo*>(ptrEvent.pVal());
	AP_ASSERT( pPlayerInfoEvent );
	
	Lobby::Events::LobbyPlayerInfoEvent evt(&pPlayerInfoEvent->m_acRawPlayerData[0], pPlayerInfoEvent->m_nDataLen);
	m_ComponentMsgBox->SendEvent(&evt);
}


// 
void LobbyComponent::OnLobbyInitializationEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyInitializationEvent* pInitEvent = static_cast< const Lobby::LobbyInitializationEvent*>(ptrEvent.pVal());
	
	if (pInitEvent != 0)
	{
		// If lobby object was uninitialized - destroy it!
		if( !pInitEvent->m_bStatus )		
		{
			Lobby::LobbyObjManager::Instance()->ResetAll();
		}

		Events::LobbyInitializationEvent evt;
		evt.m_bStatus = pInitEvent->m_bStatus;
		m_ComponentMsgBox->SendEvent(&evt);
	}		
}


// 
void LobbyComponent::OnAuthenticationLobbyEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyAuthenticationEvent* pAuthEvent = static_cast< const Lobby::LobbyAuthenticationEvent*>(ptrEvent.pVal());
	if (pAuthEvent != 0) 
	{
		if( !pAuthEvent->m_bAuthenticationStatus )
		{
			TriggerShutdown();
		}

		//DAY 5/6/2008 9:32:43 AM  I'm not sure anyone actually listens for this
		Events::LobbyAuthenticationEvent evt;
		evt.m_bStatus = pAuthEvent->m_bAuthenticationStatus;
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


// Handles internal lobby enumeration event. This event usually notifies components when new sessions
// are found on on-line or LAN lobby and contains list of names that can be used to join advertised session.
void LobbyComponent::OnLobbyEnumerationEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyEnumerationEvent* pEnumEvent = static_cast< const Lobby::LobbyEnumerationEvent*>(ptrEvent.pVal());
	if (pEnumEvent != 0) 
	{
		if (!pEnumEvent->m_bAutoJoin)
		{
			Lobby::LobbyObjManager::Instance()->SetSessionList(pEnumEvent->m_sessionsFound);
			Lobby::Events::LobbyEnumerationEvent evt;
			m_ComponentMsgBox->SendEvent(&evt);
		}
		else
		{
			Lobby::LobbyObj* pLobby = Lobby::LobbyObjManager::Instance()->CurrentLobby();
			if (pEnumEvent->m_sessionsFound.Count() > 0 && pLobby != 0 && (m_Random.RandInt(0, 1) == 1))
			{
				// Join first session from the list.
				pLobby->JoinSession( pEnumEvent->m_sessionsFound[0].GetPlayerName() );
			}
		}
	}	
}


// Handles internal lobby connection event. 
void LobbyComponent::OnEnterSessionEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyEnterSessionEvent* pEnterEvent = static_cast< const Lobby::LobbyEnterSessionEvent*>(ptrEvent.pVal());
	if (pEnterEvent != 0) 
	{		
		Lobby::Events::LobbyEnterSessionEvent evt;
		evt.m_SessionHostAddress = pEnterEvent->m_address;
		evt.m_bStatus = pEnterEvent->m_bStatus;
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


// Handles internal lobby connection event. 
void LobbyComponent::OnSessionExitEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbySessionExitEvent* pEnterEvent = static_cast< const Lobby::LobbySessionExitEvent*>(ptrEvent.pVal());
	if (pEnterEvent != 0) 
	{
		Lobby::Events::LobbySessionExitEvent evt;
		evt.m_bStatus = pEnterEvent->m_bStatus;
		evt.m_bLocal = pEnterEvent->m_bLocal;
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


// Called by component manager when component is about to be destroyed.
void LobbyComponent::OnShutdown()
{
	AP_ASSERT( mRefCounter == 1 );
	Lobby::LobbyObjManager::Instance()->ResetAll();
	mRefCounter = 0;
}

void LobbyComponent::OnLobbyLeaderboardStatsUpdate( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyLeaderboardStatsUpdate* updateEvt = static_cast< const Lobby::LobbyLeaderboardStatsUpdate*>( ptrEvent.pVal() );
	
	if( updateEvt != 0 )
	{
		Lobby::LobbyObjManager::Instance()->AddStats( updateEvt->mList );

		Events::LobbyLeaderboardQueryComplete completeEvent;
		m_ComponentMsgBox->SendEvent( &completeEvent );
	}
}

void LobbyComponent::OnLobbyPrivateMatchReady( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyPrivateMatchReadyEvent* readyEvt = static_cast< const Lobby::LobbyPrivateMatchReadyEvent*>( ptrEvent.pVal() );

	if( readyEvt )
	{
		Events::LobbyPrivateMatchConnected conEvent;
		m_ComponentMsgBox->SendEvent( &conEvent );
	}
}

void LobbyComponent::OnFriendQueryComplete( const Axiom::SmartPtr<InternalEvent>& ptrEvent )
{
	const Lobby::LobbyFriendQueryCompleteEvent* friendsEvt = static_cast< const Lobby::LobbyFriendQueryCompleteEvent*>( ptrEvent.pVal() );

	if( friendsEvt )
	{
		Lobby::LobbyObjManager::Instance()->SetFriendsList( friendsEvt->mFriends );

		Events::LobbyFriendsQueryComplete completeEvent;
		m_ComponentMsgBox->SendEvent( &completeEvent );
	}
}

void LobbyComponent::Initialize()
{
	Axiom::Log("lobby", "Lobby initialization requested.");
	mRefCounter++;

	if( Lobby::LobbyObjManager::Instance()->CurrentLobby() == 0 )
	{
		Lobby::LobbyObjManager::Instance()->CreateLobby( Lobby::LobbyObj::PLATFORM_LAN_LOBBY );
	}
	else
	{
		Events::LobbyInitializationEvent evt;
		evt.m_bStatus = true;
		m_ComponentMsgBox->SendEvent( &evt );
	}
}

void LobbyComponent::TriggerShutdown()
{
	if( LobbyObj* lobby = LobbyObjManager::Instance()->CurrentLobby() )
	{
		lobby->Shutdown();
		mRefCounter = 0;
	}
}

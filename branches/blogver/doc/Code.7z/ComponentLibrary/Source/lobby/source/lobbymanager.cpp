
#include "lobby/lobbymanager.h"
#include "lobby/lobbyinterfaces.h"
#include "lobby/lobby.h"

namespace Lobby
{
	//LobbyObjManager

	LobbyObjManager* LobbyObjManager::m_pSingletonInstance = 0;

	// C-tor
	LobbyObjManager::LobbyObjManager( ) :
		m_pCurrentLobbyObj( 0 ),
		mDatabase( 0 ),
		mExpiryCounter( 0 )
	{
	}

	// Returns instance of singleton object. This function uses Double-Checked Locking Optimization pattern.
	LobbyObjManager* LobbyObjManager::Instance()
	{
		if (LobbyObjManager::m_pSingletonInstance == 0)
		{
			// We only acquire lock per singleton instantiation.
			static Axiom::Thread::Mutex singletonMutex;
			if (!singletonMutex.TryLock())
				return 0;

			if (LobbyObjManager::m_pSingletonInstance == 0)
			{
				LobbyObjManager::m_pSingletonInstance = AP_NEW(Axiom::Memory::ONLINE_HEAP, LobbyObjManager);
			}
		}

		return LobbyObjManager::m_pSingletonInstance;
	};


	//! 
	bool LobbyObjManager::Initialize()
	{
		return true;
	}


	// Creates new lobby of type <stype> and start accepting incoming connections.
	bool LobbyObjManager::CreateLobby(Lobby::LobbyObj::LobbyType lobbyType)
	{
		if (m_pCurrentLobbyObj == 0)
		{
			Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
			m_pCurrentLobbyObj = LobbyObj::Create(lobbyType);

			mDatabase = m_pCurrentLobbyObj->CreateDatabase();
		}
		else
		{
			// Lobby object already exists.
		}
		
		AP_ASSERT(m_pCurrentLobbyObj != 0);
		return (m_pCurrentLobbyObj != 0);
	}

	// 
	bool LobbyObjManager::Update()
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		
		if( m_pCurrentLobbyObj )
		{
			m_pCurrentLobbyObj->Update();
			const Axiom::UInt timeVal( 60 * 60 );	//1 minute in seconds if we update at 60FPS

			if( ++mExpiryCounter > timeVal )	
			{
				mExpiryCounter = 0;
				mDatabase->Expire( Axiom::TimeRelative::CreateFromSeconds( 60 ) );
			}
		}
		else
		{
			if( mUpdateDelegate )
			{
				return mUpdateDelegate();
			}
		}

		return false;
	}


	//! Destroys all active sessions.
	void LobbyObjManager::ResetAll()
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);

		AP_DELETE(m_pCurrentLobbyObj);
		m_pCurrentLobbyObj = 0;

		AP_DELETE( mDatabase );
		mDatabase = 0;
	};

	//
	void LobbyObjManager::SetSessionList(const SessionEnumList& sessionList)
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		m_SessionEnumList = sessionList;
	}

	//
	int LobbyObjManager::GetSessionList( SessionEnumList& sessionList) const
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		sessionList = m_SessionEnumList;		
		return sessionList.Count();
	}

	void LobbyObjManager::SetFriendsList( const FriendList& list )
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		mFriendList = list;
	}

	bool LobbyObjManager::GetFriendsList( FriendList& list ) const
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		list = mFriendList;
		return true;
	}

	//! 
	void LobbyObjManager::SetMatchStats(const BlobData& data)
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);

		mMatchStats.mType = data.mType;
		Axiom::MemoryCopy( mMatchStats.mData, data.mData, sizeof( mMatchStats.mData ) );
	}

	//
	void LobbyObjManager::SetEntityStats( const StatBlobData& data )
	{
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		mDatabase->UpdateStat( data );
	}

	const StatsList& LobbyObjManager::GetSearchList() const 
	{
		return mDatabase->GetSearchList();
	}

	bool LobbyObjManager::QueryStats( const BlobData& data )
	{
		if( mDatabase->Search( data ) )
		{
			return true;
		}
		else
		{
			m_pCurrentLobbyObj->GetStats( data );
		}

		return false;
	}

	bool LobbyObjManager::AddStats( const Axiom::Collections::StaticList< StatBlobData, MAX_STATS_RECORDS >& list )
	{
		const Axiom::UInt last = list.Count() - 1;
		for( Axiom::UInt i = 0; i < list.Count(); ++i )
		{
			mDatabase->UpdateStat( list[i], ( i == last ) );
		}

		return true;
	}


} // namespace Network

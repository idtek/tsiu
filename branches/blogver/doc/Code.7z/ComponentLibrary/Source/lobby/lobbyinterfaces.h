#if !defined( LOBBY_INTERFACES_H )
#define LOBBY_INTERFACES_H

#include "string/string.h"
#include "lobby/configuration.h"

namespace Lobby
{
	/**
		@class IStatDatabase
		A class that offers a transparent layer between the front end and the source of the stats
		So the source of the stats can be xbox360 leaderboards, demonware leaderboards, etc
	*/

	class IStatDatabase
	{
	public:
		virtual ~IStatDatabase(){}

		/**
			Adds some stats to the db
			@param data the data to add
			@param last is this the last stat in a series of stats
		*/
		
		virtual void UpdateStat( const StatBlobData& data, Axiom::Bool last = true ) = 0;

		/**
			Triggers a search based on the passed search criteria
			@param data the passed search criteria
			@return if the search was successful
		*/

		virtual Axiom::Bool Search( const BlobData& data ) = 0;

		/**
			Fills the passed data in with the local player
			@param data the data to fill in
			@return if there was a local player
		*/

		virtual Axiom::Bool GetLocalPlayer( Lobby::StatBlobData& data ) const = 0;

		/**
			Fills the passed data in with the remote player
			@param data the data to fill in
			@return if there was a remote player
		*/

		virtual Axiom::Bool GetRemotePlayer( Lobby::StatBlobData& data ) const = 0;
		
		/**
			Gets the search list.  This list is filled in when calls to 
			Search are finished
			@return the search list
		*/

		virtual const StatsList& GetSearchList() const = 0;

		/**
			Makes all stats stored in the db that are older than now - timeDiff expire
			@param timeDiff the difference
		*/

		virtual void Expire( const Axiom::TimeRelative& timeDiff ) = 0;

		/**
			@return is the db empty
		*/

		virtual Axiom::Bool Empty() const = 0;
	};
}

#endif //LOBBY_INTERFACES_H


#ifndef _LOBBY_MANAGER_H_
#define _LOBBY_MANAGER_H_

#include "lobby/lobby.h"
#include "core/functor.h"

namespace Lobby
{

//types
typedef Axiom::Delegate<Axiom::Bool(void)>	LobbyUpdateDelegate;

class IStatDatabase;

//!
class LobbyObjManager
{
public:

	// D-tor
	~LobbyObjManager()
	{
		// Make sure all sessions have been properly shut down before Session Manager destroyed.
		AP_ASSERT(m_pCurrentLobbyObj == 0);
	}

	// Returns instance of singleton object. This function uses Double-Checked Locking Optimization pattern.
	static LobbyObjManager* Instance();

	//! 
	bool Initialize();

	// Returns pointer to current session, NULL if session does not exists.
	Lobby::LobbyObj* CurrentLobby(void)
	{
		return m_pCurrentLobbyObj;
	}

	// Creates new lobby of type <lobbyType> and start accepting incoming connections.
	bool CreateLobby(Lobby::LobbyObj::LobbyType lobbyType);

	//! Destroys all active sessions.
	void ResetAll();

	// Give Session Manage r slice of CPU time.
	bool Update();

	//
	void SetSessionList(const SessionEnumList& sessionList);
	//
	int GetSessionList( SessionEnumList& sessionList) const;

	const StatsList& GetSearchList() const;

	//! 
	template< class T >
	bool GetLocalPlayerStats( T& stats ) const
	{	
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		
		if( !mDatabase )
		{
			return false;
		}

		StatBlobData data;
		if( mDatabase->GetLocalPlayer( data ) )
		{
			stats = T::ReadFrom( data );
			return true;
		}

		return false;
	}

	template< class T >
	bool GetRemotePlayerStats( T& stats ) const
	{	
		Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
		
		if( !mDatabase )
		{
			return false;
		}

		StatBlobData data;
		if( mDatabase->GetRemotePlayer( data ) )
		{
			stats = T::ReadFrom( data );
			return true;
		}

		return false;
	}

	//!
	void SetFriendsList( const FriendList& list );
	bool GetFriendsList( FriendList& list ) const;

	//! 
	void SetMatchStats(const BlobData& stats);
	const BlobData& GetMatchStats() const {return mMatchStats;}

	//! 
	void SetEntityStats( const StatBlobData& data );

	bool QueryStats( const BlobData& data );
	bool AddStats( const Axiom::Collections::StaticList< StatBlobData, MAX_STATS_RECORDS >& list );

	//The update delegate is a function that gets called when there is no lobby object.
	//It can be used to check for things like sign ins and outs that the lobby cannot detect
	//This is a delegate since handling this is a project specific task
	void SetUpdateDelegate( const LobbyUpdateDelegate& del ) {mUpdateDelegate = del;}

protected:

	// Default c-tor.
	LobbyObjManager();

	// Static singleton instance
	static LobbyObjManager*		m_pSingletonInstance;

	// Guards session(s)
	mutable Axiom::Thread::Mutex m_pSessionMutex;

	// We can have more than one session object in future, but right now we only support one.
	LobbyObj*				m_pCurrentLobbyObj;

	// List of sessions in lobby.
	SessionEnumList			m_SessionEnumList;

	//List of current users friends
	FriendList				mFriendList;
	BlobData				mMatchStats;
	IStatDatabase*			mDatabase;
	Axiom::UInt				mExpiryCounter;
	LobbyUpdateDelegate		mUpdateDelegate;
};


} // namespace Lobby

#endif // _LOBBY_MANAGER_H_

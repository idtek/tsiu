
#ifndef _LOBBY_H_
#define _LOBBY_H_

#include <eventsystem/eventman.h>

#include "core/referenced.h"

#include "collections/queue.h"

#include "lobby/configuration.h"
#include "lobby/lobbyinterfaces.h"
#include "string/string.h"

#include "network/networksession.h"

namespace Lobby
{
	// This structure contains parameters that control Matchmaking process
	class MatchmakingParameters
	{
		public:

			MatchmakingParameters() : 
				m_nNoOfSearchAttributes(1),	
				m_bIsRanked(false),
				m_bPrivate(false),
				m_bAutoJoin(false),
				m_bVisible( false ),
				m_fAutoRefreshIntervalSec(3.0)
			{
				for (int param = 0; param < MAX_SEARCH_ATTRIBUTES; param++)
				{
					m_aSearchAttributeValues.Add(0);
				}
			}

			// No of search attributes used.
			int		m_nNoOfSearchAttributes;
			// Array of parameters used in session search query
			Axiom::Collections::StaticList<int, MAX_SEARCH_ATTRIBUTES> m_aSearchAttributeValues;
			// Is this game ranked?
			bool	m_bIsRanked;
			// Is this a private session?
			bool	m_bPrivate;
			// Should session automatically joined?
			bool	m_bAutoJoin;
			// Should this session be visible?
			bool	m_bVisible;
			// Session list refresh interval in secconds.
			float	m_fAutoRefreshIntervalSec;

			AP_DECLARE_TYPE();
	};

	class SessionInfo
	{
	public:

		SessionInfo()
		{
			for( Axiom::UInt i = 0; i < mAttributes.Size(); ++i )
			{
				mAttributes[i] = 0;
			}
		}

		PlayerName			GetPlayerName() const {return mName;}
		void				SetPlayerName( const PlayerName& name ) {mName = name;}

		Axiom::Int64	GetAttribute( Axiom::UInt index ) const {return mAttributes[index];}
		void			SetAttribute( Axiom::UInt index, Axiom::Int64 value ) { mAttributes[index] = value;}

	private:

		PlayerName			mName;
		Axiom::Collections::StaticArray< Axiom::Int64, MAX_NUM_SESSION_ATTRIBUTES > mAttributes;
	};

	//typedefs
	typedef Axiom::Collections::StaticList< SessionInfo, LOBBY_MAX_ENUM_ENTRIES> SessionEnumList;




//Todo.  Cleanup this struct once it is implemented for both 360 and PS3

#if CORE_XBOX360
typedef XUID FriendUserId;
#else
typedef Axiom::UInt FriendUserId;
#endif

class FriendInfo
{
public:

	PlayerName		mName;
	FriendUserId	mId;
};

typedef Axiom::Collections::StaticList< FriendInfo, MAX_NUM_FRIENDS > FriendList;


// Internal events used by Lobby.
class InternalEvent : public Axiom::Referenced
{
public:
	//! 
	enum EvtType
	{
		LE_INVALID					= 0x0,
		LE_INITIALIZATIONEVENT		= 0x1,
		LE_AUTHENTICATIONEVENT		= 0x2,
		LE_ENUMERATIONEVENT			= 0x3,
		LE_CONNECTIONEVENT			= 0x4,
		LE_DISCONNECTIONEVENT		= 0x5,
		LE_ENTERSESSIONEVENT		= 0x6,
		LE_SESSIONEXITEVENT			= 0x7,
		LE_LOCALPLAYERINFOEVENT		= 0x8,
		LE_ENDMATCHEVENT			= 0x9,
		LE_ENTITYSTATSUPDATE		= 0xA,
		LE_LEADERBOARDSTATSUPDATE	= 0xB,
		LE_PRIVATEMATCHREADY		= 0xC,
		LE_FRIENDQUERYCOMPLETE		= 0xD,

	};
	// C-tor
	InternalEvent(EvtType evttype) : m_type(evttype) { };
	// D-tor
	virtual ~InternalEvent() { };

	EvtType TypeOf() const
	{
		return m_type;
	}

private:
	// 
	EvtType	m_type;
};

//! 
class LobbyObj
{
public:

	//! 
	enum LobbyType
	{
		INVALID_LOBBY_TYPE		= 0x0,
		PLATFORM_LAN_LOBBY		= 0x1,
		PLATFORM_ONLINE_LOBBY	= 0x2,
	};	

	//~ C-tor
	LobbyObj()
	{
	}


	// D-tor
	virtual ~LobbyObj();

	//! Authenticate user with On-line/LAN lobby. Returns <true> if authentication process started successfully. LE_AUTHENTICATIONEVENT
	//! will be generated when authentication task completes.
	virtual bool Authenticate(const Axiom::ShortStringW& wstrAccountName, const Axiom::StaticString<32, char>& strPassword) = 0;

	//! 
	virtual bool StartMatchmaking(const MatchmakingParameters& params) = 0;

	// Instructs matchmaking process to stop.
	virtual bool StopMatchmaking() = 0;

	//! Find session with <wstrSessionName> name in a list of sessions discovered using current matchmaking
	//! mechanism and if session is found - try to join it.
	virtual bool JoinSession(const Lobby::PlayerName& wstrSessionName) = 0;

	//! Called when new player is accepted into a session.
	virtual bool PlayerAccepted() = 0;

	//! 
	virtual bool SetRemotePlayerInfo(const char* data, int dataLen) = 0;

	//! Start online match.
	virtual bool StartMatch() = 0;

	//! Notifies lobby that match has been finished. 
	virtual bool EndMatch(const BlobData& stats) = 0;

	//! Leave current session. <wstrSessionName> is optional, if session name is not specified 
	//! request will be applied to current session, otherwise it will first search for active
	//! session with specified name. If session with given name not found LeaveSession() returns false
	//! and nothing will happen.
	virtual bool LeaveSession() = 0;

	//! Shutdown the lobby.
	virtual void Shutdown(void) = 0;

	virtual void GetStats( const BlobData& data ) = 0;

	virtual void GetFriendList( Axiom::UInt startingAt, Axiom::UInt numberOfFriends ) = 0;

	virtual void InviteToGame( const PlayerName& playerName ) = 0;

	virtual Lobby::IStatDatabase* CreateDatabase() const = 0;

	//!	Returns next SessionEvent.
	Axiom::SmartPtr< InternalEvent >  GetEvent()
	{
		return m_eventQueue.IsEmpty() ? Axiom::SmartPtr< InternalEvent >() : m_eventQueue.PopFront();
	};

	//! Virtual c-tor, returns instance of specific class
	static LobbyObj* Create(LobbyType lobbyType);
	// Users should provide implementation for this static member function elsewhere like for example:
	// Lobby::LobbyObj* Lobby::LobbyObj::CreateLobbyObj(Lobby::LobbyObj::LobbyType lobbyType) {	return new Agora_Lobby(); }

	// Give session slice of CPU time
	void Update()
	{
		Process();
	}

protected:

	//! Places SessionEvent into internal event queue
	void PostEvent( InternalEvent* message )
	{
		m_eventQueue.PushBack( message );
	}

private:

	// Give session slice of CPU time
	virtual void Process() = 0;

	// Internal event queue.
	Axiom::Collections::Queue< InternalEvent*, LOBBY_INTERNAL_QUEUE_SIZE> m_eventQueue;
};


//! Sent when lobby initialization/shutdown is completed.
class LobbyInitializationEvent : public InternalEvent
{
public:
	// C-tor
	LobbyInitializationEvent(bool bStatus)
		: InternalEvent(LE_INITIALIZATIONEVENT),
		m_bStatus(bStatus)
	{
		// Do nothing
	}

	// Lobby initialization status.
	bool	m_bStatus;
};


// Sent when user authentication status changes.
class LobbyAuthenticationEvent : public InternalEvent
{
public:
	// C-tor
	LobbyAuthenticationEvent(bool bStatus) 
		: InternalEvent(LE_AUTHENTICATIONEVENT),
		m_bAuthenticationStatus(bStatus)
	{
		// Do nothing.
	};

	// Authentication status, true if user is authenticated, or false otherwise.
	bool	m_bAuthenticationStatus;
};


// Enumeration event generated when new session is discovered.
class LobbyEnumerationEvent : public InternalEvent
{
public:
	
	// C-tor
	LobbyEnumerationEvent() : 
	  InternalEvent(LE_ENUMERATIONEVENT),
	  m_bAutoJoin( false )
	{
	}

	// Add an entry to the list of enumerated sessions.
	void AddEntry( const SessionInfo& entry )
	{
		m_sessionsFound.Add( entry );
	}
 
	// List of Sessions produced by session enumeration.
	SessionEnumList m_sessionsFound;
	// If this flag is true session returned in a list will be joined by Lobby component automatically.
	bool			m_bAutoJoin;
};


// 
class LobbyLocalPlayerInfo : public InternalEvent
{
public:
	// C-tor
	LobbyLocalPlayerInfo(const char* data, size_t dataLen)
		: InternalEvent(LE_LOCALPLAYERINFOEVENT)
	{
		m_nDataLen = dataLen;
		Axiom::MemoryCopy(&m_acRawPlayerData[0], data, dataLen);
	}

	// 
	char	m_acRawPlayerData[120];
	//
	int		m_nDataLen;
};


// Informs that we entered into a session.
class LobbyEnterSessionEvent : public InternalEvent
{
public:

	// C-tor
	LobbyEnterSessionEvent(bool bStatus, const Network::Address& address = Network::Null_Address)
		: InternalEvent(LE_ENTERSESSIONEVENT),
		m_bStatus(bStatus),
		m_address(address)
	{
		// 
	}

	// 
	bool				m_bStatus;
	// 
	Network::Address	m_address;
};


// Informs that we entered into a session.
class LobbySessionExitEvent : public InternalEvent
{
public:

	// C-tor
	LobbySessionExitEvent(bool bStatus, bool bLocal)
		: InternalEvent(LE_SESSIONEXITEVENT),
		m_bStatus(bStatus),
		m_bLocal(bLocal)
	{
		// 
	}

	// Status, expected to be <true>
	bool				m_bStatus;
	//
	bool				m_bLocal;
};


// Informs lobby when match has ended.
class LobbyEndMatchEvent : public InternalEvent
{
public:
	// C-tor
	LobbyEndMatchEvent(bool bStatus) 
		: InternalEvent(LE_ENDMATCHEVENT), 
		m_bStatus(bStatus)
	{
		// 
	}

	// Status, expected to be <true>
	bool	m_bStatus;
};


//
class LobbyEntityStatsUpdate : public InternalEvent
{
public:

	// C-tor
	LobbyEntityStatsUpdate( Axiom::Bool remote = false)
		: InternalEvent(LE_ENTITYSTATSUPDATE),
		mRemote( remote )
	{
	}

	StatBlobData mData;
	Axiom::Bool mRemote;
};

class LobbyLeaderboardStatsUpdate : public InternalEvent
{
public:
	LobbyLeaderboardStatsUpdate()
		: InternalEvent( LE_LEADERBOARDSTATSUPDATE )
	{
	}

	Axiom::Collections::StaticList< StatBlobData, MAX_STATS_RECORDS > mList;
};

class LobbyPrivateMatchReadyEvent : public InternalEvent
{
public:
	LobbyPrivateMatchReadyEvent()
		: InternalEvent( LE_PRIVATEMATCHREADY )
	{
	}
};

class LobbyFriendQueryCompleteEvent : public InternalEvent
{
public:
	LobbyFriendQueryCompleteEvent()
		: InternalEvent( LE_FRIENDQUERYCOMPLETE )
	{
	}

	FriendList	mFriends;
};


} // namespace Lobby

#endif


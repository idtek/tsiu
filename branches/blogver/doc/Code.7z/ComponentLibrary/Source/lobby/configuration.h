#if !defined( LOBBY_CONFIG_H )
#define LOBBY_CONFIG_H

#include "collections/list.h"

#define LOBBY_INTERNAL_QUEUE_SIZE 100

//Maximum number of stat records in any one given list
#define MAX_STATS_RECORDS 128
//Maximum number of friends returned in one search
#define MAX_NUM_FRIENDS 100
// Maximum number of sessions expected from single session search query
#define LOBBY_MAX_ENUM_ENTRIES 50
// Maximum number of search attributes
#define MAX_SEARCH_ATTRIBUTES 6
// Maximum number of session attributes
#define MAX_NUM_SESSION_ATTRIBUTES 20

namespace Lobby
{
	//Typedefs
	typedef Axiom::Collections::StaticList< void*, MAX_STATS_RECORDS > StatsList;
	/// We need this typedef since our event system can't handle an Axiom::MediumStringW
	typedef Axiom::StaticString< 32, wchar_t > PlayerName;

	//Interfaces needed by our lobby that must be implemented by each game

	class IStatDatabase;

	template< Axiom::UInt size >
	class BlobDataBase
	{
		enum
		{
			DATA_SIZE = size,
		};


	public:
		Axiom::Char	mData[ DATA_SIZE ];
		Axiom::UInt mType;
	};

	typedef BlobDataBase< 60 > BlobData;
	typedef BlobDataBase< 500 > StatBlobData;	//For player names, we use Axiom::MediumStringW's, which are 128 * 2 bytes
}	

#endif //LOBBY_CONFIG_H

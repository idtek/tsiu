
#ifndef ONLINELOBBYCOMPONENT_H__
#define ONLINELOBBYCOMPONENT_H__

#include "core/random.h"

#include <kernel/component.h>
#include "lobby/configuration.h"
#include "lobby/lobby.h"

namespace Lobby
{

//! This class implements Lobby Session Component. This component implements 
//! fully connected Peer-to-peer networked session used in multi-player mode.
class LobbyComponent : public AP::Component
{
public:
	
	//! C-tor
	LobbyComponent (Axiom::ConstStr name, AP::Kernel* kernel);		

	//! D-tor
	virtual	~LobbyComponent();

	// Component methods:
	virtual void	OnInit();	
	virtual void	OnUpdate();
	virtual void	OnShutdown();

private:
	// 
	void HandleEvents(void);

	// Specific event handlers:
	void OnAuthenticationLobbyEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	// 
	void OnLobbyInitializationEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	// Handles internal lobby enumeration event.
	void OnLobbyEnumerationEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnLobbyConnectionEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnLobbyDisConnectionEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	// 
	void OnEnterSessionEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnSessionExitEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnLocalPlayerInfoEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnEndMatchEvent( const Axiom::SmartPtr<InternalEvent>& ptrEvent );
	//
	void OnLobbyEntityStatsUpdate( const Axiom::SmartPtr<InternalEvent>& ptrEvent );

	void OnLobbyLeaderboardStatsUpdate( const Axiom::SmartPtr<InternalEvent>& ptrEvent );

	void OnLobbyPrivateMatchReady( const Axiom::SmartPtr<InternalEvent>& ptrEvent ); 

	void OnFriendQueryComplete( const Axiom::SmartPtr<InternalEvent>& ptrEvent ); 

	void TriggerShutdown();
	void Initialize();

private:

	// 
	Axiom::EventMsgBoxHandle m_ComponentMsgBox;

	// Random number used to randomize quickmatch selection of sessions to join.
	Axiom::Random m_Random;

	Axiom::UInt mRefCounter;
};

} // end of namespace Lobby

#endif // ONLINELOBBYCOMPONENT_H__

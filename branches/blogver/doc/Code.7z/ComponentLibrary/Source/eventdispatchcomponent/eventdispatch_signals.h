#ifndef __EVENTDISPATCH_SIGNAL_LIST_H__
#define __EVENTDISPATCH_SIGNAL_LIST_H__

#include "kernel/coreglobalsignallist.h"

#define EVENT_DISPATCH_SIGNAL_LIST()\
	SIGNAL_LIST_ITEM( SigEventDispatchChannel		,SIGNAL_TYPE_GENERICEVENT, AP::SIGNALFLAG_DEFAULT )	\

namespace AP
{
	namespace EventDispatch
	{

		class EventDispatchSignalList
		{
			public:
// 				#ifndef SIGNAL_LIST_ITEM
// 				#define SIGNAL_LIST_ITEM(sig, sigType, flag) DECLARE_SIGNAL(sig, sigType)
// 							EVENT_DISPATCH_SIGNAL_LIST()
// 				#endif
// 				#undef SIGNAL_LIST_ITEM
		};

	} //namespace EventDispatch
} //namespace AP

#endif

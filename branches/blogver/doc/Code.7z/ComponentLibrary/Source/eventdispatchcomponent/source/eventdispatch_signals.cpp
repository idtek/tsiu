// class header
#include "eventdispatchcomponent/eventdispatch_signals.h"

// other includes

namespace AP
{
	namespace EventDispatch
	{

// 		#define STREAKER_SIGNAL_CREATE_STATIC(sig, flag) AP::EventDispatch::EventDispatchSignalList::sig(flag);
// 		#ifndef SIGNAL_LIST_ITEM
// 		#define SIGNAL_LIST_ITEM(sig, sigType,flag) sigType STREAKER_SIGNAL_CREATE_STATIC(sig, flag)
// 				EVENT_DISPATCH_SIGNAL_LIST()
// 		#endif
// 		#undef SIGNAL_LIST_ITEM

	} //namespace InputRecording
} //namespace AP

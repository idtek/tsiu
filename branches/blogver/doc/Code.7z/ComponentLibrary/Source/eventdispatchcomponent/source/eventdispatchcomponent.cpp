#include "eventdispatchcomponent/eventdispatchcomponent.h"
#include "socket/game.h"

namespace AP
{
	namespace EventDispatch
	{
		
		EventDispatchComponent::EventDispatchComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name, kernel)
		{
			//Set up the socket server to use our EventMan for forwarding events to the remote client
			Axiom::Socket::Game::GetInstance()->SetEventMan(&GetEventMan());
		}

		EventDispatchComponent::~EventDispatchComponent()
		{
			Axiom::Socket::Game::GetInstance()->SetEventMan(NULL);
		}

		void EventDispatchComponent::OnInit( )
		{
		}

		void EventDispatchComponent::OnUpdate( )
		{
		}

		void EventDispatchComponent::OnShutdown( )
		{
		}

	} //namespace EventDispatch
}  // namespace  AP

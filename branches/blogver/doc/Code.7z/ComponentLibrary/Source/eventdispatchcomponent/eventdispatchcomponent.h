// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	eventdispatchcomponent.h
//!	@brief	Component that will take any event registered to it and send it to STF for use by external applications/tools
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#ifndef __EVENTDISPATCH_COMPONENT_H__
#define __EVENTDISPATCH_COMPONENT_H__
#include "kernel/component.h"

namespace AP
{
	namespace EventDispatch
	{ 

		class EventDispatchComponent: public AP::Component
		{
			public:
				EventDispatchComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~EventDispatchComponent();

			public:  // component methods:
				virtual void		OnInit( );
				virtual void		OnUpdate( );
				virtual void		OnShutdown( );
		};

	} //namespace EventDispatch
}  // namespace  AP

#endif

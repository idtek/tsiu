#include "kernel/kernel.h"
#include "visualassert.h"
#include "thread/thread.h"
#include "thread/atomic.h"
#include <stdio.h> 

namespace AP
{
	static RenderIsInFrame							RENDER_ISINFRAME_FUNC = NULL;
	static RenderBeginFunc							RENDER_BEGIN_FUNC = NULL;
	static RenderEndFunc							RENDER_END_FUNC = NULL;
	static RenderTextFunc							RENDER_TEXT_FUNC = NULL;
	static ThreadIdFunc								GETTHREADID = NULL;
	static ThreadNameFunc							GETHREADNAME = NULL;
	static Axiom::Thread::ThreadId					RENDER_THREAD_ID = Axiom::Thread::AP_INVALID_THREADID;
	static volatile bool							sVisualAssertDisplayed = false;

	#define ISRENDERTHREAD()						((GETTHREADID != NULL) && (RENDER_THREAD_ID == GETTHREADID()))

	// Set function callbacks for visual assist!!
	void SetThreadNameCallback( ThreadNameFunc pFunc )			{ GETHREADNAME = pFunc; }
	void SetThreadIdFunc( ThreadIdFunc pFunc )					{ GETTHREADID = pFunc; }
	void SetRenderIsInFrameCallBack( RenderIsInFrame pFunc )	{ RENDER_ISINFRAME_FUNC = pFunc; }
	void SetRenderThreadId( Axiom::Thread::ThreadId threadid )	{ RENDER_THREAD_ID = threadid; }
	void SetRenderBeginCallBack( RenderBeginFunc pFunc )		{ RENDER_BEGIN_FUNC = pFunc; }
	void SetRenderEndCallBack( RenderEndFunc pFunc )			{ RENDER_END_FUNC = pFunc; }
	void SetRenderTextCallBack( RenderTextFunc pFunc )			{ RENDER_TEXT_FUNC = pFunc; }

	// Main visual asset function!!
	void VisualAssertDisplay(const char *expr, const char *msg, const char* filename, int line)
	{
		if(	!GETHREADNAME 
			|| !RENDER_ISINFRAME_FUNC 
			|| !RENDER_BEGIN_FUNC 
			|| !RENDER_END_FUNC 
			|| !RENDER_TEXT_FUNC 
			|| !GETTHREADID 
			|| (RENDER_THREAD_ID == Axiom::Thread::AP_INVALID_THREADID)
			)
		{
			AP_DEBUGBREAK();
		}

		static const int MAX_DEBUG_STRING = 1024;
		static const int MAX_DEBUG_THREAD_STRING = 256;

		static char szTemp[MAX_DEBUG_STRING];
		static char szThreadName[MAX_DEBUG_THREAD_STRING];
			
		Axiom::Thread::ThreadId nRenderThreadId = RENDER_THREAD_ID;
		Axiom::Thread::ThreadId nThreadId = GETTHREADID();

		// This should be snprintf..  stdio libs not including into component project, so use sprintf for now
		Axiom::StringFormat(szThreadName, MAX_DEBUG_THREAD_STRING, "%s ASSERT!!!", GETHREADNAME(GETTHREADID()));
		Axiom::StringFormat(szTemp, MAX_DEBUG_STRING, "%s\nAssert:%s \nMsg:%s\nfile:%s\nline:%d", szThreadName, expr, msg, filename, line);

		if(nRenderThreadId == nThreadId)
		{
			if(!RENDER_ISINFRAME_FUNC())
			{
				RENDER_BEGIN_FUNC(0xFF000000);
			}

			RENDER_TEXT_FUNC(50, 40,0xFFFFFFFF,  szTemp, false);

			RENDER_END_FUNC();

			Axiom::Log( "System", "%s\n", szTemp );

			AP_DEBUGBREAK();
		}
		else
		{
			RENDER_TEXT_FUNC(50, 40,0xFFFFFFFF, szTemp, true);
		
			while (!sVisualAssertDisplayed) // spinning volatile bool. Wait to be notified by the render thread (through the presentation manager)
			{
				Axiom::Thread::Sleep(10);
			}

			Axiom::Log( "System", "%s\n", szTemp );

			AP_DEBUGBREAK();

			while(1)
			{
				Axiom::Thread::Sleep(10);
			}
		}
	}

	void VisualAssertHasBeenDisplayed()
	{
		sVisualAssertDisplayed = true;
	}
}

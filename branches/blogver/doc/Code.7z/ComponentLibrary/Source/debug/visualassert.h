#ifndef _VISUALASSERT_H__
#define _VISUALASSERT_H__
#include "thread/thread.h"
#include "kernel/coreglobalsignallist.h"

namespace AP
{
	// Call backs for render functions
	typedef Axiom::Thread::ThreadId (*ThreadIdFunc)();
	typedef const char*			(*ThreadNameFunc)(Axiom::Thread::ThreadId);
	typedef bool				(*RenderIsInFrame)();
	typedef void				(*RenderBeginFunc)(int bgColor);
	typedef void				(*RenderEndFunc)();
	typedef void				(*RenderTextFunc)(float x, float y, int color, char *szString, bool defer);

	// Display visual assert
	extern void VisualAssertDisplay(const char *expr, const char *msg, const char* filename, int line);
	extern void VisualAssertHasBeenDisplayed();

	// Set callbacks for rendering
	extern void SetThreadNameCallback(ThreadNameFunc pFunc);
	extern void SetRenderIsInFrameCallBack(RenderIsInFrame pFunc);
	extern void SetRenderBeginCallBack( RenderBeginFunc pFunc);
	extern void SetRenderEndCallBack( RenderEndFunc pFunc);
	extern void SetRenderTextCallBack( RenderTextFunc pFunc);
	extern void SetThreadIdFunc(ThreadIdFunc pFunc);
	extern void SetRenderThreadId(Axiom::Thread::ThreadId threadid);


}
#endif

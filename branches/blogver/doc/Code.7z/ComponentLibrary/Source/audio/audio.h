#ifndef _AUDIO_H
#define _AUDIO_H

# ifndef _APMATH_H
#  include "math/apmath.h"
# endif

#include <core/singleton.h>
#include <core/core.h>
#include <kernel/signal.h>
#include "fmod_event.hpp"
#include "audio/audiodefines.h"
#include <collections/list.h>
#include <collections/circularbuffer.h>
#include "audio/audioparams.h"
#include "audio/SignaledAudio.h"
#include "audio/NSyncMusicTransitionalGroup.h"

#if CORE_PS3 == CORE_YES
#include "fmodps3.h"
#endif
 
namespace AP
{
	// forward declares
	class		AudioTriggers; 
	class		AudioMixes;
	//--------------------------------------------------------

	namespace Audio
	{		
		enum
		{
			MaxNumEvents = 370, 
			MaxNumGroups = 35, 
			MaxNumSignalBacks = 10, 
			MaxNumMusicTransitions = 6,
			MaxMusicTransitionsSequenceLength = 12,
			MaxNumFinishedStreamsToDelete = 8,
			MaxNumLoadedStreamsToStart = 8,
			MaxNumAudioMixes = 25, 
			MaxNumDelayedEvents = 10
		};		

		// typedefs
		typedef		Axiom::Collections::StaticList <Axiom::UInt8, MaxNumEvents>							AudioVolumeType;
		typedef		Axiom::Collections::StaticList <AudioEventData,MaxNumEvents>						AudioEventListType;
		typedef		Axiom::Collections::StaticList <AudioEventGroupData,MaxNumGroups>					AudioEventGroupListType;
		typedef		Axiom::Collections::StaticList <AudioMixArrangementData,MaxNumAudioMixes>			AudioMixOverlayType;
		typedef		Axiom::Collections::StaticList <SignaledAudio, MaxNumSignalBacks>					AudioSignalListType;
		typedef		Axiom::Collections::StaticList <NSyncMusicTransitionalGroup, MaxNumMusicTransitions>NSyncMusicTransitionListType;
		typedef		Axiom::Collections::DynamicCircularBuffer <Axiom::Int32>							AudioStreamsWaitingToLoadType;
			
		//-----------------------------------------------------------------------------------
		class AudioSystem : public Axiom::Singleton<AudioSystem> 
		{
			AP_NON_COPYABLE(AudioSystem);		
		public:
			//------------- begin interface ---------------------
			 AudioSystem();

			 void					Initialize						();
			 NSyncMusicTransitionalGroup*
									CreateMusicTransitionGroup		(int* EventIndices, int NumIndices);
			 void					DeleteMusicTransitionGroup		(NSyncMusicTransitionalGroup* group);
			 bool					IsReady							() {return mIsReady;}		 
			 void					SetCurrentIntensity				(int intensity) {mCurrentIntensity = intensity;}	
			 
			 void					Update							(float X, float Y, float Z, float LookAtX, float LookAtY, float LookAtZ, float upX, float upY, float upZ);
			 void					UpdateTime						(int TimePassedInMilliseconds);
			 void					PlayEvent_Reflection			(int EventId);
			 void					PlayEvent						(int EventId, Axiom::UInt8 priority, float X, float Y, float Z, bool PlayIn3D);
			 void					PlayEvent						(int EventId, Axiom::UInt8 priority, Axiom::UInt8 ValueFrom0to100);
			 void					PlayEventWithSignalBack			(int EventId, int ReplyId, PlayBankParams& PlayParams,  bool SignalOnAudioEnd);
			 void					StopEvent						(int EventId);

			 void					PreloadEvent					(int EventId);
			 void					UnloadEvent						(int EventId);

			 void					SetVolume						(int mastervol);

			 void					SetCurrentMix					(int which);
			 void					SetCurrentMix_Reflection		(const char* name);

			 void					SetRolloff						(float Rolloff);
			 void					SetDistanceScaling				(float DistanceScaling);
			 Axiom::UInt32			GetMemoryWatermark				() const;		 
			 Axiom::UInt32			GetMaxMemoryAvailable			() const;
			 void					AddAudioFile					(const char* AudioFileName, const char* RawAudioData);

			 //--------------- end interface ---------------------
			 // the interface used by the component system is continued below.		 

			AudioEventListType					AudioEventPool;
			AudioEventGroupListType				AudioEventGroupPool;
			AudioMixOverlayType					AudioMixOverlayPool;
			AudioMixCurrentValue				CurrentMix;

			AudioSignalListType					AudioSignalListPool;
			NSyncMusicTransitionListType		MusicTransitionPool;
			AudioVolumeType						VolumeSetByGame;		
			Axiom::UInt8*						mMemBuffer;
			
			float								DistanceScalingFactor;
			float								RolloffValue;
	static	double								DefaultMaxVolume;
	static	bool								mIsRequestedFileAStream;

			//---------------------------------------------------------

		private:
			bool								mIsReady;	
			bool								mIsResetting;
			bool								mStreamsArePaused;
			bool								mStreamsAreEnabled;
			bool								mNSyncStreamsAreEnabled;
			FMOD::EventSystem*					FmodEventSystem;
			FMOD::EventCategory*				FmodEventCategories;
			FMOD::EventGroup*					FmodEventGroups;
			FMOD_VECTOR							mFmodCameraPositionVector;

			int									mMasterVolume;
			int									mMemoryWaterMark;
			int									mMaxNumberOfStreams;
			float								mCategoryVolumes [AP::Events::EAudioBroadCategory::NumberOfItems];
			
			Axiom::Collections::
				DynamicList<ComplexAudioBankData>mDelayedEventQueue;  //delayed event queue

			Axiom::Collections::
				DynamicList<SignalledAudioWhenReady*>	mSignaler;
			Axiom::Collections::
				DynamicList<SignalledAudioWhenCompleted*>	mSignaledCompleted;
			int									mNumAudioEvents;  
			int									mNumAudioMixes;  
			int									currentAudioMixIndex;  
			AudioTriggers*						mAudioEvents;
			AudioMixes*							mAudioMixes;
			unsigned int						FModVersion;
			unsigned int						HeapSize;
	static	AudioThatSignalsBackWhenDone*		ArrayOfFinishedAudioItemsNeedingDelete [MaxNumFinishedStreamsToDelete];
	static	int									FinishedAudioIndex;
			AudioStreamsWaitingToLoadType		AudioStreamsLoading;

			bool								mOverRideIntensityFlag;
			int									mIntensityOverrideValue;
			int									mCurrentIntensity;

			void								SetupFileSystem ();

			//--------------------- hidden here ------------------
			// this interface is used by the component system only

		public:
			// returns the number of valid IDs
			int					GetInternalIDsFromEvent (int EventID, int* ArrayOfInternalIDs, int ArraySize);

			//---------------------------------------------------	
			// used for the reflection system
			AudioEventData*			GetEvent		(const char* name);
			AudioEventGroupData*	GetEventGroup	(const char* name);
			AudioMixArrangementData*GetMix			(const char* name);
			int						GetMixID		(const char* name);
			int						GetGroupVolume	(int Id);
			AudioEventData&			GetEventData	(int EventId);

			int						GetNumGroups	();
			AudioEventGroupData&	GetGroupDataByName	(const char* name);
			AudioEventGroupData&	GetGroupDataByGroupId	(int GroupId);
			AudioEventGroupData&	GetGroupDataByAudioEventName	(const char* name);	// this name will be parsed
			AudioEventGroupData&	GetGroupDataByFmodEventName	(const char* name);	// this name will be parsed

			int						GetGroupIdByName	(const char* name);	
			AudioEventGroupData&	GetGroupData	(int GroupId);	
			int						GetGroupMixVolumeLevel	(const char* name);	
			int						GetGroupMixVolumeLevel (int GroupId);

			void					SetEventVolume	(int EventId, float Volume);
			void					SetEventPitch	(int EventId, float Pitch);
			void					SetGroupVolume	(int Id, int Volume);
			void					SetCategoryVolume (int category, int volume);

			void					PauseAllStreams (bool PauseApply = true);
			void					SetOverrideIntensity (bool OverrideTrue = true) {mOverRideIntensityFlag = OverrideTrue;}
			void					SetOverrideIntensityValue (int value) {mIntensityOverrideValue = value;}
			void					PrepareFMODPointer (SimpleBankData* BankData, bool forcePrepForPlay = false);
			

			void					ERRCHECK(FMOD_RESULT);
			//FMOD::Event*			GetFMODEvent	(int FmodEventId);
			FMOD::Event*			GetFMODEvent	(SimpleBankData* BankData);

			void					PlayEventInternal				(int EventId, Axiom::UInt8 priority, float X, float Y, float Z, 
																		bool PlayIn3D, bool IsGameRequestToPlay, Axiom::UInt8 SpecialSetting);
			// not used by the game, only by the tool
			void					PlayBank						(int BankId, int Volume);
			void					StopBank						(int BankId);
			void					PlayBank						(const char* FModBankName, int Volume);
			void					StopBank						(const char* FModBankName);

			//---------------------------------------------------		 

			// these calls are internal registration calls by other components.
			void					RegisterForEventFinishedCallbacks (SignalledAudioWhenReady* Signaller) {mSignaler.Add (Signaller);}
			void					RegisterForEventFinishedCallbacks (SignalledAudioWhenCompleted* Signaller) {mSignaledCompleted.Add (Signaller);}
			void					SetAudioEvents (AudioTriggers* ptr);
			void					SetNumAudioMixes (int evtSize) {mNumAudioMixes = evtSize;}	
			void					SetAudioMixes	(AudioMixes* ptr)  {mAudioMixes = ptr;}

			//---------------------------------------------------	
			void					OnUpdateQueue();
			void					AddQueueItem	(SimpleBankData*, int AdditionalDelay, Axiom::UInt8 priority, float X, float Y, float Z, bool PlayIn3D);
			void					PlaySound	(AudioEventData* EventData, 
													AudioEventGroupData* GroupData, 
													SimpleBankData* audioParameters, 
													Axiom::UInt8 priority, float X, float Y, float Z, bool PlayIn3D, Axiom::UInt8 SpecialSetting);
			void					StopSound (SimpleBankData* BankData);

			void					Setup3DSoundForPlay (AudioEventData* EventData, AudioEventGroupData* GroupData, FMOD::Event* pEvent, float X, float Y, float Z);
			void					SetupStreamForPlay (AudioEventData* EventData, SimpleBankData* BankData, Axiom::UInt8 priority );

			void					PlaySound (AudioEventData* EventData, 
												AudioEventGroupData* GroupData, 
												SimpleBankData* audioParameters);

			void					MuteAll ();
			void					UnmuteAll ();
			void					MuteGroup (int GroupId);
			void					UnmuteGroup (int GroupId);
			void					MuteEvent (int EventId);
			void					UnmuteEvent (int EventId);

			void					AudioSetVolume (int EventId, int Volume);
			void					AudioSetGameVolume (int EventId, int Volume);
			int						GetNumberOfCurretlyPlayingStreams ();
			bool					KillLowestPriorityStreamPlayingWithPriorityLowerThan (int priority);

			float					CalculateVolume (AudioEventData* EventData, SimpleBankData* BankData);
			float					CalculateVolume (AudioEventData* EventData);
			float					CalculatePitch (AudioEventData* EventData, SimpleBankData* BankData);

			void					Shutdown ();
			void					ClearMemBuffer ();
			void					FMODInit ();
			void					FMODLoad ();
			void					FMODDestroy ();
			void   					FMODLoadBackup ();// in case there is a problem with the project file
			void					LoadAudioLuaFile ();
			void					LoadAudioMixLuaFile ();
			void					InitializeGroupNames ();
			void					FixUpEventsIDsAndGroupIDsByName ();

			void					InitAudioEventList ();
			void					InitAudioEventGroupList ();
			void					InitAudioMixList ();
			void					InitVolumeSetByGame ();
			void					InitEventWithSignalBack ();

			void					UpdateAudioWithCallbacks ();
			void					UpdateFinishedAudio ();
			void					UpdateLoadingAudio ();
			void					UpdateFileStreams ();
			void					UpdateAudioMixes (int TimePassedInMilliseconds);
	static	void					AddToFinishedAudioItemsNeedingDeleteList (AudioThatSignalsBackWhenDone* ff);
	static	void					AddToLoadedAudioItemsNeedingToStartList (AudioThatSignalsBackWhenReadyToPlay* ff);

			void					InitNSyncMusicTransitionGroup ();
			void					UpdateNSyncMusicTransitionGroup ();
			bool					PlayNSyncMusicTransitionGroup (int EventId);
			bool					StopNSyncMusicTransitionGroup (int EventId);
			bool					SetNSyncMusicTransitionGroup_Volume (int EventId);
			bool					SetNSyncMusicTransitionGroup_Pitch (int EventId);
			int						FindValidEventIDsFromListOfEventIDs (int* ResultEventIDs, int* FMODEventIDs, int* SourceGameEventIDs, int num);// returns number found
			bool					DoesNSyncMusicTransitionGroupAlreadyExist (int* ArrayOfEventIds);
			int						SetupNewTransitionGroup (int* ValidEventIds , int NumIndices);

			void					ClearFModEventsIDs ();	
			void					ResetTransitionGroups ();	
			
			bool					IsResetting ();
			void					VolumeWasChanged (int EventId) ;
			void					AudioMixUpdated () ;
			bool					CanPlay (SimpleBankData* BankData, bool IsGameRequest);

			static FMOD::Event*		InvalidFMODEventPointer ()
			{
				return reinterpret_cast<FMOD::Event*>(0xFFFFFFFF);
			}

			//--------------------- PS3 only  ------------------
		public:	
		#if CORE_PS3 == CORE_YES
			FMOD_PS3_EXTRADRIVERDATA  ps3DriverData;
		#endif
		public:
			AP_DECLARE_TYPE();	
		};
	}// namespace Audio
} //namespace AP

	//---------------------------------------------
	//---------------------------------------------

namespace AP
{
	class AudioTriggers
	{
	public:
		//------------------------------

		const char*	GetEventName(int eventId);
		// this is intended to be created in the game, not in the Component library
		int		GetEventCount(); 
		//------------------------------

		bool	GetNYsyncMusicGroup (int which, Audio::AudioSystem* audio);
	public:
		static void Init();	
		AP_DECLARE_TYPE();
		// this is intended to be created in the game, not in the Component library
	protected:
		protected:
		static AudioTriggers* mInstance;
	};

	//---------------------------------------------

	class AudioMixes
	{
	public:
		//------------------------------

		const char*	GetMixName(int mixId);
		// this is intended to be created in the game, not in the Component library
		int		GetMixCount(); 
		//------------------------------
	public:
		static void Init();
		static char* mMixList[];	
		AP_DECLARE_TYPE();
		// this is intended to be created in the game, not in the Component library
	protected:
		static AudioMixes* mInstance;
	};
}
#endif	//_AUDIO_H




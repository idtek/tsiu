// NSyncMusicTransitionalGroup.h
#ifndef __NSYNC_MUSIC_TRANSITION_GROUP_H__
#define __NSYNC_MUSIC_TRANSITION_GROUP_H__
//-----------------------------------------------------------

namespace AP
{
	namespace Audio
	{
		class AudioSystem;
		struct SimpleBankData;

		class NSyncMusicTransitionalGroup
		{
			enum {MaxNumberOfBanks = 10};
		public:
			NSyncMusicTransitionalGroup ();
			void				Clear ();
			void				Init (FMOD::EventGroup*group, int* indices, SimpleBankData* BankData, int NumBanks);
			void				PlayStream (const char* FModEventName);
			void				StopStream (const char* FModEventName);
			void				StopAll ();
			void				PauseAll (bool PauseApply);
			void				Update ();

			bool				IsPrepedForTransitionToAnotherStream  () {return AwaitingTransitionFlag;}
			bool				IsPrepedForEndingAllAudio  () {return IsSetupToStopAllAudioFlag;}
			void				SyncPointWasHit ();
			void				AudioWasEnded ();

			// --------------------------------------------

			void				SetVolume (const char* FModEventName, float VolumeLevel);
			void				SetPitch (const char* FModEventName, float PitchLevel);
			void				SetAudioSystem (AudioSystem* Audio) {MainAudio = Audio;}

			void				SetToBeDeleted (bool setDeleteFlag = true) {IsSetupToBeDeleted = setDeleteFlag;}
			bool				IsReadyToBeDeleted ();

		private:

			void				Setup ();
			FMOD::Event*		SetupForPlay (int index);

			// here we are managing state and creating threading protections
			bool				IsTransitioningFlag;
			bool				AwaitingTransitionFlag;
			bool				IsSyncPointSignalledFlag;
			bool				IsSetupToStopAllAudioFlag;
			bool				IsSetupToBeDeleted;

			int					TransitionToIndex;
			FMOD::Event*		CurrentlyPlayingEvent;
			FMOD::Event*		TransitionToEvent;
			AudioSystem*		MainAudio;
		public:
			FMOD::Event*		GetFMODEvent (int index);

			FMOD::EventGroup*	eventgroup;
			int					EventIds[MaxNumberOfBanks];
			SimpleBankData*		AudioBanks;
			int					NumBanks;
			int					CurrentlyPlayingIndex;
		};
	}// namespace Audio
}
//-----------------------------------------------------------
#endif // __NSYNC_MUSIC_TRANSITION_GROUP_H__

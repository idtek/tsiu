#ifndef _AUDIO_DEFINES_H
#define _AUDIO_DEFINES_H

#include "core/classedenum.h"

namespace AP
{
	namespace Events
	{
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS AP_DECLARE_TYPE();

CLASSEDENUM (	EAudioTestType, \
				CLASSEDENUM_ITEMSTART(AudioClearUnitTest) \
				CLASSEDENUM_ITEM(PeriodicSoundPlay), \
				PeriodicSoundPlay \
				)

CLASSEDENUM (	EReplyToAudioEvent, \
				CLASSEDENUM_ITEMSTART(ReplyWhenAudioStarts) \
				CLASSEDENUM_ITEM(ReplyWhenAudioEnds), \
				ReplyWhenAudioEnds \
				)
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS

	}
}

#endif

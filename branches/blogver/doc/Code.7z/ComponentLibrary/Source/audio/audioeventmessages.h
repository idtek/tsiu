#ifndef _AUDIOMESSAGES_H
#define _AUDIOMESSAGES_H
#include <eventsystem/eventman.h>
#include <kernel/messages.h>
#include <math/vector3.h>
#include "Collections/list.h"
#include "audio/audiodefines.h"
#include "core/classedenum.h"

namespace AP
{
	namespace Events
	{
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS AP_DECLARE_TYPE();

CLASSEDENUM (	EAudioBroadCategory,
				CLASSEDENUM_ITEMSTART(SoundFX)\
				CLASSEDENUM_ITEM(FrontEnd) \
				CLASSEDENUM_ITEM(InGameMusic) \
				CLASSEDENUM_ITEM(BackgroundMusic), \
				SoundFX \
				)
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS

		//---------------------------------------------------------------------
		class AudioPlaySoundEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioPlaySoundEvent);
			enum {SettingOff = 255};
				
			AudioPlaySoundEvent(): Axiom::EventMsg(EVENT_GUID),
									m_AudioEventId (0),
									m_X (0),
									m_Y (0),
									m_Z (0),
									m_Is3D (false),
									m_Priority (50),// 0 - 100 range
									m_Setting (SettingOff)// 0 - 100
				{}
			AudioPlaySoundEvent(int id, float Velocity, float X, float Y, float Z)
				: Axiom::EventMsg(EVENT_GUID),
				m_AudioEventId(id),
				m_X(X),
				m_Y(Y),
				m_Z(Z),
				m_Is3D (false),
				m_Priority (50),
				m_Setting (0)
				{ UNUSED_PARAM(Velocity); }
				

			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_AudioEventId;
			float						m_X,m_Y,m_Z;
			bool						m_Is3D;
			Axiom::UInt8				m_Priority;
			Axiom::UInt8				m_Setting;
		};

		//---------------------------------------------------------------------
		class AudioStopSoundEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioStopSoundEvent);
				
				AudioStopSoundEvent(): Axiom::EventMsg(EVENT_GUID){}
				AudioStopSoundEvent(int id)
					: Axiom::EventMsg(EVENT_GUID),
					m_AudioEventId(id)
				{}

			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_AudioEventId;
		};
		//---------------------------------------------------------------------
		class AudioSetVolumeForCategory : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetVolumeForCategory);
			
			AudioSetVolumeForCategory(): Axiom::EventMsg(EVENT_GUID),
				m_Category (EAudioBroadCategory::SoundFX), 
										 m_Volume (0)
			{}
			AudioSetVolumeForCategory(EAudioBroadCategory cat, int vol): 
										 Axiom::EventMsg(EVENT_GUID),
										 m_Category(cat),
										 m_Volume (vol)
			{
				if (m_Volume < 0) m_Volume = 0;
				if (m_Volume > 100) m_Volume = 100;
			}
			
			AP_DECLARE_POLYMORPHIC_TYPE();

			EAudioBroadCategory		m_Category;
			int								m_Volume; // range 0-100 (off - full)
		};
		//---------------------------------------------------------------------
		class AudioPlaySoundBank : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioPlaySoundBank);
				
				AudioPlaySoundBank(): Axiom::EventMsg(EVENT_GUID){}
				AudioPlaySoundBank(int id)
					: Axiom::EventMsg(EVENT_GUID),
					m_AudioBankId(id),
					m_Volume (255)
				{}

			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_AudioBankId;
			int							m_Volume;
			Axiom::ShortString			m_FModEventName;
		};

		//---------------------------------------------------------------------
		class AudioStopSoundBank : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioStopSoundBank);//,MSG_Audio_System_Stopsound )
				
				AudioStopSoundBank(): Axiom::EventMsg(EVENT_GUID){}
				AudioStopSoundBank(int id)
					: Axiom::EventMsg(EVENT_GUID),
					m_AudioBankId(id)
				{}

			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_AudioBankId;
			Axiom::ShortString			m_FModEventName;
		};
		//---------------------------------------------------------------------
		class AudioSetEventVolume : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetEventVolume);

			AudioSetEventVolume(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetEventVolume(int EventId, int Volume)
				: Axiom::EventMsg(EVENT_GUID),
				mEventId(EventId),
				mVolume(Volume)
			{
				mIsFromGame = false;
			}
			AP_DECLARE_POLYMORPHIC_TYPE();
			int							mEventId;
			int							mVolume;
			bool						mIsFromGame;// the game may want to temporarily adjust the volume should not modify
													// the overarching volume settings
		};

		//---------------------------------------------------------------------
		class AudioResetAllEventVolume : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioResetAllEventVolume);

			AudioResetAllEventVolume(): Axiom::EventMsg(EVENT_GUID){}

			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//---------------------------------------------------------------------
		class AudioSetEventPitch : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetEventPitch);

			AudioSetEventPitch(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetEventPitch(int EventId, float Pitch)
				: Axiom::EventMsg(EVENT_GUID),
				mEventId(EventId),
				mPitch(Pitch)
			{}
			AP_DECLARE_POLYMORPHIC_TYPE();
			int							mEventId;
			float						mPitch;
		};

		//---------------------------------------------------------------------
		class AudioSetMixEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetMixEvent);

			AudioSetMixEvent(): Axiom::EventMsg(EVENT_GUID),
				mMixType(0)
			{}
			AudioSetMixEvent(int mix_id): Axiom::EventMsg(EVENT_GUID),
				mMixType(mix_id)
			{}

			AP_DECLARE_POLYMORPHIC_TYPE();
			int					mMixType;
		};

		//---------------------------------------------------------------------
		class AudioSetMasterVolume : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetMasterVolume);

			AudioSetMasterVolume(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetMasterVolume(int val)
				: Axiom::EventMsg(EVENT_GUID),
				m_mastVolume(val)
			{}
			AP_DECLARE_POLYMORPHIC_TYPE();
			int							m_mastVolume;
		};
		//---------------------------------------------------------------------
		class AudioSetRolloff : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetRolloff);

			AudioSetRolloff(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetRolloff(float val)
				: Axiom::EventMsg(EVENT_GUID),
				m_Rolloff(val)
			{}
			AP_DECLARE_POLYMORPHIC_TYPE();
			float							m_Rolloff;
		};
		//---------------------------------------------------------------------
		class AudioSetDistanceScaling : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetDistanceScaling);

			AudioSetDistanceScaling(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetDistanceScaling(float val)
				: Axiom::EventMsg(EVENT_GUID),
				m_DistanceScale(val)
			{}
			AP_DECLARE_POLYMORPHIC_TYPE();
			float							m_DistanceScale;
		};
		//---------------------------------------------------------------------
		class AudioStartGameEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioStartGameEvent);

			AudioStartGameEvent(): Axiom::EventMsg(EVENT_GUID)
			{
			}

			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		//---------------------------------------------------------------------
		class AudioEndGameEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioEndGameEvent);

			AudioEndGameEvent(): Axiom::EventMsg(EVENT_GUID)
			{
			}

			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		//---------------------------------------------------------------------
		class AudioUnitTestEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioUnitTestEvent);

			AudioUnitTestEvent(): Axiom::EventMsg(EVENT_GUID){}
			AudioUnitTestEvent(int EventId, int DelayBetweenRepeats, EAudioTestType tt)
				: Axiom::EventMsg(EVENT_GUID),
				m_EventId(EventId),
				m_DelayBetweenRepeats (DelayBetweenRepeats),
				m_TestType(tt)
			{}

			AP_DECLARE_POLYMORPHIC_TYPE();
			int				m_EventId;
			int				m_DelayBetweenRepeats;
			EAudioTestType		m_TestType;
		};

		//---------------------------------------------------------------------
		class AudioPlaySoundExpectingReply : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioPlaySoundExpectingReply);

			AudioPlaySoundExpectingReply(): Axiom::EventMsg(EVENT_GUID){}
			AudioPlaySoundExpectingReply(int sfxID, float Velocity, float X, float Y, float Z, int ReplyID, EReplyToAudioEvent type, int Delay)
				: Axiom::EventMsg(EVENT_GUID),
				m_sfxID (sfxID),
				m_ReplyId (ReplyID),
				m_DelayInFrames (Delay),
				m_Velocity (Velocity),
				m_X (X),
				m_Y (Y),
				m_Z (Z),
				m_Type (type)
			{}
			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_sfxID;
			int							m_ReplyId;
			int							m_DelayInFrames;
			float						m_Velocity;
			float						m_X,m_Y,m_Z;
			EReplyToAudioEvent			m_Type;
		};

		//---------------------------------------------------------------------
		class AudioReplyToPlaySound: public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioReplyToPlaySound);

			AudioReplyToPlaySound(): Axiom::EventMsg(EVENT_GUID){}
			AudioReplyToPlaySound(int sfxID, int ReplyID, EReplyToAudioEvent type)
				: Axiom::EventMsg(EVENT_GUID),
				m_sfxID (sfxID),
				m_ReplyId (ReplyID),
				m_Type (type)
			{}

			AP_DECLARE_POLYMORPHIC_TYPE();

			int							m_sfxID;
			int							m_ReplyId;
			EReplyToAudioEvent			m_Type;
		};
		//---------------------------------------------------------------------
		class AudioUpdateCameraBody : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioUpdateCameraBody);

			AudioUpdateCameraBody(): Axiom::EventMsg(EVENT_GUID){}
			AudioUpdateCameraBody(Axiom::Math::Vector3 vPos, Axiom::Math::Vector3 vFront, Axiom::Math::Vector3 vUp, Axiom::Math::Vector3 vRight)
				: Axiom::EventMsg(EVENT_GUID),
				m_Position(vPos),
				m_Front(vFront),
				m_Up(vUp),
				m_Right(vRight)
			{}
			
			Axiom::Math::Vector3	m_Position;
			Axiom::Math::Vector3	m_Front;
			Axiom::Math::Vector3	m_Up;
			Axiom::Math::Vector3	m_Right;
		};

		//---------------------------------------------------------------------
		class AudioExecuteCommands : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioExecuteCommands);
			enum	{Kill, Reboot};
			
			AudioExecuteCommands(): Axiom::EventMsg(EVENT_GUID){}
			AudioExecuteCommands(int evtcommand): 
				Axiom::EventMsg(EVENT_GUID),
				m_eventID(evtcommand)
			{}
			
			AP_DECLARE_POLYMORPHIC_TYPE();

			int			m_eventID;
		};

		//---------------------------------------------------------------------
		class AudioStop : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioStop);//,MSG_Audio_System_Stop )

			AudioStop(): Axiom::EventMsg(EVENT_GUID){}
			AudioStop(int eventID): 
				Axiom::EventMsg(EVENT_GUID),
				m_eventID(eventID)
			{}

			int		m_eventID;
		};
		//---------------------------------------------------------------------
		class AudioPaused : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioPaused);

			AudioPaused(): Axiom::EventMsg(EVENT_GUID){}
			AudioPaused(bool Paused): 
				Axiom::EventMsg(EVENT_GUID),
				m_Paused(Paused)
			{}

			bool		m_Paused;
		};
		//---------------------------------------------------------------------
		class AudioPlayVenueAmbiance : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioPlayVenueAmbiance);
			enum PlayStop {Play, Stop};	

			AudioPlayVenueAmbiance(): Axiom::EventMsg(EVENT_GUID), mPlayStop (Stop), mMiniGameEnabled (false), mBallPositionOnlyFlag(false)
				{}
			AudioPlayVenueAmbiance(int ps): Axiom::EventMsg(EVENT_GUID), mPlayStop (ps), mMiniGameEnabled (false), mBallPositionOnlyFlag (false)
				{}
			AP_DECLARE_POLYMORPHIC_TYPE();
			int		mPlayStop;
			bool	mMiniGameEnabled;
			bool	mBallPositionOnlyFlag;
		};


		//---------------------------------------------------------------------	
		class EbbRuleStart : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(EbbRuleStart);
				
			EbbRuleStart(): Axiom::EventMsg(EVENT_GUID)
				{}			

			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		//---------------------------------------------------------------------	
		class EbbRuleStop : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(EbbRuleStop);
				
			EbbRuleStop(): Axiom::EventMsg(EVENT_GUID)
				{}			

			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		//---------------------------------------------------------------------	
		class EbbRuleUpdateEvent : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(EbbRuleUpdateEvent);
				
			EbbRuleUpdateEvent(): Axiom::EventMsg(EVENT_GUID)
				{}			

			AP_DECLARE_POLYMORPHIC_TYPE();
			int					mCurrentValue;
			Axiom::StringCRC	mConfigurationName;
		};
		//---------------------------------------------------------------------
		class AudioSetupEventFilter : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioSetupEventFilter);

			AudioSetupEventFilter(): Axiom::EventMsg(EVENT_GUID){}
			AudioSetupEventFilter(int e, int time, bool removeFilter = false)
				: Axiom::EventMsg(EVENT_GUID),
				EventId(e),
				TimeInMSBetweenFirings(time),
				RemoveFlag (removeFilter)
			{}

			void Set (int e, int time, bool removeFilter = false)
			{
				EventId = e;
				TimeInMSBetweenFirings = time;
				RemoveFlag = removeFilter;
			}
			
			AP_DECLARE_POLYMORPHIC_TYPE();
			int EventId;
			int TimeInMSBetweenFirings;
			bool RemoveFlag;
		};
		//---------------------------------------------------------------------
		class AudioClearTimeFilters : public Axiom::EventMsg
		{
		public:	
			EVENT_MSG_GUID(AudioClearTimeFilters);

			AudioClearTimeFilters(): Axiom::EventMsg(EVENT_GUID){}
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		//---------------------------------------------------------------------

	}
	static const int componentID = 69;
}

#endif


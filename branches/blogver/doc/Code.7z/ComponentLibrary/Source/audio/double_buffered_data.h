//------------------------------------------------------------------------------
//
//!  @DoubleBufferedData.h
//!
//! This class is meant to represent a buffer from which to read data and fill with data.
//! The assumption is that you will read this data from a file. 
//! It works with a variety of sizes for read and write.
//! The reads should always be less than or equal to the writes.
//!
//!	 Copyright (c) 2007 by Action Pants Inc
//
//------------------------------------------------------------------------------

namespace Axiom
{
template <int BufferSize = 8*1024>// default total buffer size is 8K
class	DoubleBufferedData
{
public:	
	DoubleBufferedData ();
	~DoubleBufferedData ();
	
	int		GetBufferSize () {return BufferSize;}
	bool	IsInUse () {return mIsInUse;}
	void	SetInUse (bool inUse = true);
	void	Clear ();

	//--------------------------------------------

	bool	DoesBufferNeedRefilling ();
	int		HowMuchDataIsNeededToRefill ();
	void	AddDataToBuffer (void*, int NumBytes);
	int		ReadDataFromBuffer (void*, int SizeRequested);

	//--------------------------------------------

protected:
	int		mCurrentReadBufferIndex;
	int		mBufferReadOffset[2];
	char*	mBuffer;
	char*	mPointerToBuffer [2];
	int		mBufferWriteOffset [2];
	int		mNumStoredBytesInBuffer[2];

	bool	mIsBufferUsedUp[2];// only changes to true when the buffer is completely used up
	bool	mIsInUse;
};

}

//---------------------------------------------------------------------
//---------------------------------------------------------------------

#	include "audio/source/double_buffered_data.inl"

//---------------------------------------------------------------------
//---------------------------------------------------------------------



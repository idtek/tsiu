#include <kernel/kernel.h>
#include "audio/audio.h"
#include "fmod.hpp"
#include "math/vector3.h"
#include <string/stringutils.h>
//#include <core/time.h>
#include "files/filemanager.h"
#include "encode/base64.h"


#if !CORE_WII
#define AUDIO_ENABLED
#endif
#define ALWAYS_GRAB_NEW_NON_STREAM_FMOD_POINTER

namespace AP
{
	AP_TYPE(AudioTriggers)
		AP_DEFAULT_CREATE()
		AP_COMMAND(GetEventName,"Return Trigger List")
		AP_COMMAND(GetEventCount,"Return Event Count")
	AP_TYPE_END()

	
	AP_TYPE(AudioMixes)
		AP_DEFAULT_CREATE()
		AP_COMMAND(GetMixName,"Return Mix List")
		AP_COMMAND(GetMixCount,"Return Mix Count")
	AP_TYPE_END()

	AudioTriggers*  AudioTriggers::mInstance =		NULL;
	AudioMixes*		AudioMixes::mInstance =			NULL;

	namespace Audio
	{
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	AP_TYPE(AudioSystem)
		AP_FIELD("AudioEventPool",AudioEventPool,"The Audio Event System")
		AP_FIELD("AudioMixPool",AudioMixOverlayPool,"The mix settings used in the game")
		AP_FIELD("AudioEventGroupPool",AudioEventGroupPool,"The Audio Event Groups")
		AP_FIELD("MasterVolume",mMasterVolume,"Audio Master Volume")
		AP_FIELD("DistanceScale",DistanceScalingFactor,"Audio distance scaling")
		AP_FIELD("Rolloff", RolloffValue,"Audio distance rolloff envelope")
		AP_FIELD("Reset",mIsReady,"reset_Flag")
		AP_FIELD("AudioMixCount", mNumAudioMixes, "The number of audio mixes")
		AP_FIELD("AudioMixes", mAudioMixes, "A list of available audio mixes")
		AP_FIELD("FMODVersion", FModVersion, "the current version of the FDesigner libs")
		AP_FIELD("MaxStreams", mMaxNumberOfStreams, "the current version of the FDesigner libs")
		AP_FIELD("EnableStreams", mStreamsAreEnabled, "Turn on streams")
		AP_FIELD("EnableSynchronizedStreams", mNSyncStreamsAreEnabled, "Mostly FE streams")
		AP_COMMAND(SetVolume,"set the Master Volume")
		AP_COMMAND(GetEvent,"Return an event by name")
		AP_COMMAND(GetGroupData,"Return an group by ID")
		AP_COMMAND(GetNumGroups, "How many groups are valid")
		AP_COMMAND(GetGroupDataByName,"get a group by name")
		AP_COMMAND(GetGroupDataByGroupId, "get a group by its id")
		AP_COMMAND(SetGroupVolume, "Set the volume for a group")
		AP_COMMAND(GetGroupVolume, "Set the volume for a group")
		AP_COMMAND(GetMix,"Return an mix by name")
		AP_COMMAND(IsReady, "Is the audio system ready to accept new audio events and data")
		AP_COMMAND(IsResetting, "Is the audio system ready to accept new audio events and data")
		AP_COMMAND(GetMemoryWatermark, "What is the highest level of memory used")
		AP_COMMAND(GetMaxMemoryAvailable, "How much is available")
		AP_COMMAND(AudioMixUpdated, "reload volumes and such")
		AP_COMMAND(SetOverrideIntensity, "")
		AP_COMMAND(SetOverrideIntensityValue, "")
		AP_COMMAND(MuteAll, "")
		AP_COMMAND(UnmuteAll, "")
		AP_COMMAND(MuteGroup, "")
		AP_COMMAND(UnmuteGroup, "")
		AP_COMMAND(MuteEvent, "")
		AP_COMMAND(UnmuteEvent, "")
		AP_COMMAND(ResetTransitionGroups, "")
		AP_COMMAND(AddAudioFile, "way to dump raw audio data into the game")
		AP_NAMED_COMMAND("SetMix",SetCurrentMix_Reflection,"Return an mix by name")
		AP_NAMED_COMMAND("PlayEvent", PlayEvent_Reflection, "play a sound")
		AP_NAMED_COMMAND("UnloadBankIds", ClearFModEventsIDs, "Just reset audio")
		AP_NAMED_COMMAND("RelinkEventsAndGroups", FixUpEventsIDsAndGroupIDsByName, "Just reset audio")
	AP_TYPE_END()

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	// Static member data
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	
	double			AudioSystem::DefaultMaxVolume = 196.0;
	bool			AudioSystem::mIsRequestedFileAStream = false;

	AudioThatSignalsBackWhenDone*	AudioSystem::ArrayOfFinishedAudioItemsNeedingDelete [MaxNumFinishedStreamsToDelete];
	int								AudioSystem::FinishedAudioIndex = 0;

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	static const char* MAIN_CATEGORY	= "master";
	static const char* MAIN_GROUP		= "AudioProject/untitled";
	static const char* MAIN_EVENT_FILE  = "AudioProject.fev";

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	// utility functions
	float CalculateVolumeUtil (Axiom::UInt32 Event, 
							Axiom::UInt32 Bank, 
							Axiom::UInt32 GameVolumeSetting = -1, 
							Axiom::UInt32 AudioMixVolume = -1)
	{
		// normalize the result
		// we want to normalize to 196 being the max volume
		const double reciprical = 1.0/ AudioSystem::DefaultMaxVolume;
		double EventValue = double (Event) * reciprical;
		double BankValue = double (Bank) * reciprical;
		double GameValue = double (GameVolumeSetting) * reciprical;
		if (GameVolumeSetting == static_cast<unsigned int>(-1))
			GameValue = 1.0;
		double MixValue = double (AudioMixVolume) * reciprical;
		if (AudioMixVolume == static_cast<unsigned int>(-1))
			MixValue = 1.0;

		//Aggregate the values
		double product = EventValue * BankValue * GameValue * MixValue; 	
		if (product >1.0)
			product = 1.0;
		if (product < 0) 
			product = 0;

		return (float) product;
	}

	float CalculateVolumeUtil (Axiom::UInt32 Volume)
	{
		double product = double (Volume); 

		// normalize the result
		product /= AudioSystem::DefaultMaxVolume;
		if (product >1.0)
			product = 1.0;
		if (product < 0) 
			product = 0;
		return (float) product;
	}

	float CalculatePitchUtil (float Setting1, float Setting2)
	{
		// for ranges from -0.69 to 0.69 for 0.5 to 2.0 pitch
		return Axiom::Math::Exp ((Setting1 + Setting2) / 200.0F) - 1.0F;
		// I decided to divide by two since minor pitch setting had such a huge effect on the pitch
	}

	float CalculateAttenuation (float Dist)// starting at a distance of 3
	{
		float ReturnValue = 1.0;
		if (Dist>=3)
			ReturnValue = 1.0F -(log((Dist-3)*10)/7);
		if (ReturnValue >1.0F)
			ReturnValue = 1.0F;
		return ReturnValue;
		//return 1.0;
	}

	float CalculateDistance (FMOD_VECTOR vec1, FMOD_VECTOR vec2)
	{
		float Distance =  Axiom::Math::Vector3(vec1.x-vec2.x, vec1.y-vec2.y, vec1.z-vec2.z).Magnitude();
		return Distance;
	}

	// Game coordinates.
	// X = Forwardeasx
	// Y = LeftRight
	// Z = Up
	// FMOD coordinates.
	// Z = Forwardeasx
	// X = LeftRight
	// Y = Up

	void	SetVector (FMOD_VECTOR& vec, float x, float y, float z, float ScaleValue)
	{
		vec.x = -y * ScaleValue;
		vec.y = z * ScaleValue;
		vec.z = x * ScaleValue;
	}
	void	SetVector (FMOD_VECTOR& vec, float x, float y, float z)
	{
		vec.x = -y;
		vec.y = z;
		vec.z = x;
	}
	void	SetOffsetVector (FMOD_VECTOR& vec, float x, float y, float z, FMOD_VECTOR& offset, float ScaleValue)
	{
		vec.x = -y* ScaleValue - offset.x;
		vec.y = z* ScaleValue - offset.y;
		vec.z = x* ScaleValue - offset.z;
	}
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------

	// Default constructor required by Singleton. Should probably initialize the members variables.
	AudioSystem::AudioSystem():mMemBuffer (NULL),
								mNumAudioMixes (MaxNumAudioMixes),
								mNumAudioEvents (0),
								currentAudioMixIndex (0),
								mIsResetting (false),
								mIsReady (false),
								RolloffValue (0.0F),
								DistanceScalingFactor (40),// while a magic number, during testing, this does give decent results.
								HeapSize (0),
								mMaxNumberOfStreams (5),
								mStreamsArePaused (false),
								mStreamsAreEnabled (true),
								mNSyncStreamsAreEnabled (true),
								mCurrentIntensity (0),
								mOverRideIntensityFlag (false),
								mIntensityOverrideValue (0)
	{
		mSignaler.Resize (Axiom::Memory::AUDIO_HEAP, MaxNumSignalBacks);
		mSignaledCompleted.Resize (Axiom::Memory::AUDIO_HEAP, MaxNumSignalBacks);
		mDelayedEventQueue.Resize(Axiom::Memory::AUDIO_HEAP, MaxNumDelayedEvents);

		for (int i=0; i<MaxNumFinishedStreamsToDelete; i++)
		{
			ArrayOfFinishedAudioItemsNeedingDelete [i] = NULL;
		}
		
		AudioStreamsLoading.Resize (Axiom::Memory::AUDIO_HEAP, MaxNumLoadedStreamsToStart);
		for (int i=0; i<MaxNumLoadedStreamsToStart; i++)
		{
			AudioStreamsLoading.Add (-1);
		}
		
#if CORE_PS3 == CORE_YES
		mStreamsAreEnabled = true;
#else
		mStreamsAreEnabled = true;
#endif
		FinishedAudioIndex = (0);

		for (int i=0; i<AP::Events::EAudioBroadCategory::NumberOfItems; i++)
		{
			mCategoryVolumes[i] = 1.0F;
		}
	}

	//---------------------------------------------------------------------

	void		AudioSystem::FMODDestroy ()
	{
		mIsResetting = true;
		mIsReady = false;

		FMOD_RESULT					result;
	
		int NumItems = MusicTransitionPool.Count ();
		for (int i= 0; i< NumItems; i++)
		{
			NSyncMusicTransitionalGroup& Group = MusicTransitionPool[i];
			Group.Clear ();
		}

		
		FMOD::EventCategory *		pCategory;
		result = FmodEventSystem->getCategory (MAIN_CATEGORY, &pCategory);
		AP_ASSERTMESSAGE(result == FMOD_OK, "grabbing the category for FDesigner went badly");

		result = pCategory->stopAllEvents ();
		Axiom::Thread::Sleep(250);

		result = FmodEventSystem->unload();// this frees all memory associated with events.
		AP_ASSERTMESSAGE(result == FMOD_OK, "Stopping the playing audio in FDesigner went badly");
		Axiom::Thread::Sleep(500);

		result = FmodEventSystem->release();
		FmodEventSystem = NULL;

		//ClearFModEventsIDs ();
		//Axiom::Thread::Sleep(500);

		//ClearMemBuffer ();

		mIsResetting = false;
	}
	
	//---------------------------------------------------------------------

	void		AudioSystem::InitializeGroupNames ()
	{
		// now that we have the names of 
		int NumEvents = mAudioEvents->GetEventCount ();
		char Buffer [64];
		char LastName[64]; LastName[0] = 0;
		int GroupIndex = 0;
		for (int i=0; i<NumEvents; i++)
		{
			const char* Name = mAudioEvents->GetEventName (i);
			char* PointerToUnderscore = Axiom::StringFindChar (Name, '_');

			int LengthToUnderscore = PointerToUnderscore - Name;
			
			Axiom::StringCopy	(Buffer, Name, LengthToUnderscore);
			Buffer [LengthToUnderscore] = 0;// ending null char

			if (Axiom::StringCompare (LastName, Buffer, LengthToUnderscore) != 0)
			{
				AudioEventGroupPool[GroupIndex].m_Name = Buffer;
				AudioEventGroupData&	Group = GetGroupData (GroupIndex);
				Group.m_Name.Set (Buffer);
				Group.m_Id = static_cast <Axiom::Int8> (GroupIndex);
				Axiom::StringCopy (LastName, Buffer, LengthToUnderscore);
				LastName [LengthToUnderscore] = 0;// ending null char
				GroupIndex ++;
			}
		}

		for (;GroupIndex< MaxNumGroups; GroupIndex++)
		{
			AudioEventGroupPool[GroupIndex].m_Name.Clear ();
			AudioEventGroupPool[GroupIndex].m_Id = -1;
		}
	}

	// ---------------------------------------------

	void	AudioSystem::InitEventWithSignalBack ()
	{
		if (AudioSignalListPool.Count () == 0)
		{
			for (int i= 0; i< MaxNumSignalBacks; i++)
			{
				SignaledAudio Group;
				AudioSignalListPool.Add (Group);
			}
		}
	}
	//---------------------------------------------
	void	AudioSystem::InitAudioEventList ()
	{
		AudioEventPool.Clear ();
		for (int x = 0; x < MaxNumEvents;x++)
		{
			AudioEventData GenericEvent;
			GenericEvent.m_Id = x;
			GenericEvent.m_GroupId = 0;
			GenericEvent.m_NumBanks = 0;
			GenericEvent.m_AudioSettings.m_Volume = (Axiom::UInt8) DefaultMaxVolume;			
			AudioEventPool.Add (GenericEvent);

			AudioEventPool[x].m_BankSetup.Clear ();

			for (int i = 0; i < AudioEventData::MaxBankCount;i++)
			{
				SimpleBankData GenericBank;
				//GenericBank.m_Id = i;
				GenericBank.m_FModEventId = -1;
				GenericBank.m_AudioSettings.m_Volume = (Axiom::UInt8) DefaultMaxVolume;
				GenericBank.m_AudioSettings.m_IsStream = false;
				AudioEventPool[x].m_BankSetup.Add (GenericBank);
			}
		}
	}
	//---------------------------------------------
	void	AudioSystem::InitAudioEventGroupList ()
	{
		AudioEventGroupPool.Clear ();
		for (int i= 0; i< MaxNumGroups; i++)
		{
			AudioEventGroupData GenericData;
			GenericData.m_Id = static_cast <Axiom::Int8> (i);
			GenericData.m_Volume = (Axiom::UInt8) DefaultMaxVolume;
			AudioEventGroupPool.Add (GenericData);
		}
	}
	//---------------------------------------------------------------------
	void	AudioSystem::InitAudioMixList ()
	{
		AudioMixOverlayPool.Clear ();
		for (int i= 0; i< MaxNumAudioMixes; i++)
		{
			AudioMixArrangementData GenericData;
			for (int j=0; j<AudioMixArrangementData::MaxNumGroups; j++)
			{
				GenericData.MixPerGroup.Add ((Axiom::UInt8) DefaultMaxVolume);// set all mix values to max
				GenericData.RampTimePerGroup.Add ((Axiom::Float) 1.0);// set all ramp times to a default
			}
			AudioMixOverlayPool.Add (GenericData);
		}
		CurrentMix.Setup (AudioMixOverlayPool[0].MixPerGroup);
	}
	//---------------------------------------------------------------------
	void	AudioSystem::InitVolumeSetByGame ()
	{
		VolumeSetByGame.Clear ();
		if (VolumeSetByGame.Count () == MaxNumEvents)
			return;

		Axiom::UInt8* ptr = mMemBuffer;
		for (int i=0; i<MaxNumEvents; i++)
		{
			if (mMemBuffer != ptr)
			{
				i = i;
			}
			VolumeSetByGame.Add ((Axiom::UInt8) DefaultMaxVolume);
		}
	}
	//---------------------------------------------------------------------
	void	AudioSystem::InitNSyncMusicTransitionGroup ()
	{
		if (mStreamsAreEnabled == false)
		{
			return;
		}

		if (MusicTransitionPool.Count () == 0)
		{
			for (int i= 0; i< MaxNumMusicTransitions; i++)// fill the list with blank events
			{
				NSyncMusicTransitionalGroup Group;
				MusicTransitionPool.Add (Group);
			}
		}
		else// we already have a list full of items, but we need to clear the data in there.
		{
			for (int i= 0; i< MaxNumMusicTransitions; i++)
			{
				NSyncMusicTransitionalGroup& Group = MusicTransitionPool[i];
				Group.Clear ();
			}
			// this is performed in the CommonMain, normally. We redo it here in the rare
			// case that the data has been replaced.
			mAudioEvents->Init ();
		}		
	}
		//---------------------------------------------------------------------
	//---------------------------------------------------------------------
#if CORE_WIN32 == CORE_YES
#define MICKEY_DEMO_HACK
#endif

	void		AudioSystem::FMODInit()
	{
		// let's not interrupt
		mIsReady = false;
		mIsResetting = true;
		mIsRequestedFileAStream = false;
		FMOD_RESULT           result;

#ifndef MICKEY_DEMO_HACK
		result = FMOD::Memory_Initialize(mMemBuffer, HeapSize, 0, 0, 0);
		AP_ASSERTMESSAGE(result == FMOD_OK, "Setting memory up is a problem in Audio");
#endif

		result = FMOD::EventSystem_Create(&FmodEventSystem);
		AP_ASSERTMESSAGE(result == FMOD_OK,"Create Sound Failed!!");

		FMOD::System * SystemObject;
		result = FmodEventSystem->getSystemObject (&SystemObject);
		ERRCHECK(result);

		result = SystemObject->getVersion(&FModVersion);
		ERRCHECK(result);

		int TimeInMS = 200;
		int FileBufferSize_Type = FMOD_TIMEUNIT_MS;
		result = SystemObject->setStreamBufferSize (TimeInMS , FileBufferSize_Type);
		ERRCHECK(result);
	}
	//---------------------------------------------------------------------
	void		AudioSystem::UpdateAudioWithCallbacks ()
	{
		if (mIsReady == false)
			return;

		int NumItems = AudioSignalListPool.Count ();
		for (int i=0; i<NumItems; i++)
		{
			SignaledAudio& sa = AudioSignalListPool[i];
			
			if (sa.IsAvailable () == false)
			{
				// always call update before checking flags.
				sa.Update ();

				if (sa.HasSignaled ())
				{
					AudioEventData&			EventData = GetEventData (sa.GetEventID ());
					AudioEventData::AudioBankDataType&		
											BankSetup = EventData.m_BankSetup;
					SimpleBankData*	BankData = &(BankSetup[0]);

					bool WasPlaying = BankData->m_AudioSettings.m_IsPlaying;
					BankData->m_AudioSettings.m_IsPlaying = false;
					if (BankData->m_AudioSettings.m_IsStream && WasPlaying)
					{
						PrepareFMODPointer (BankData);
						if (BankData->mStreamPointer != InvalidFMODEventPointer ())
						{
							BankData->mStreamPointer->stop ();

							if (BankData->m_AudioSettings.m_IsSelfDeleting == false)
							{
								FmodEventGroups->freeEventData (BankData->mStreamPointer);// assuming that this is a stream.
								BankData->m_AudioSettings.m_IsLoaded = false;
							}
							BankData->mStreamPointer = InvalidFMODEventPointer ();
						}
					}
					sa.SetAvailable ();
				}
			}
		}
	}

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	
	// we have potential threading issues here. Some threading protection mechanism is required
	void			AudioSystem::UpdateFinishedAudio ()
	{
		while (FinishedAudioIndex >0)
		{
			--FinishedAudioIndex;

			AudioThatSignalsBackWhenDone * Suicidal = ArrayOfFinishedAudioItemsNeedingDelete [FinishedAudioIndex];
			if (Suicidal->GetParams ()->m_IsStream && 
				Suicidal->GetParams ()->m_IsPlaying)
				{
					Suicidal->GetParams ()->m_IsPlaying = false;// let's put this first to avoid threading issues	
				}
			Suicidal->GetParams ()->m_IsSelfDeleting = false;
			Suicidal->GetParams ()->m_IsLoaded = false;
			FMOD::EventGroup* group = Suicidal->m_EventGroup;
			group->freeEventData (Suicidal->m_FModEvent);	
			AP_DELETE (Suicidal);
		}
		FinishedAudioIndex = 0;/// just to be sure
	}
	//---------------------------------------------------------------------
	void			AudioSystem::UpdateLoadingAudio ()
	{
		for (int i=0; i<MaxNumLoadedStreamsToStart; i++)
		{
			int EventId = AudioStreamsLoading[i];
			if (EventId == -1)
				continue;

			bool IsFinishedLoading = false;
			FMOD::Event*			pEvent = InvalidFMODEventPointer ();
			//int FModEventId = -1;
			const char* FModEventName = NULL;
			SimpleBankData*	BankData = NULL;

			AudioEventData&						EventData = GetEventData (EventId);
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;
			int									NumItems = EventData.m_NumBanks;
			for (int bankId=0; bankId<NumItems; bankId++)
			{
				BankData = &(BankSetup[bankId]);
				PrepareFMODPointer (BankData);
				if (BankData->mStreamPointer != InvalidFMODEventPointer ())// we won't look unless we need to.
				{
					pEvent = BankData->mStreamPointer;//GetFMODEvent (BankData);
					FMOD_EVENT_STATE		eventState;
					pEvent->getState (&eventState);
					if (eventState == FMOD_EVENT_STATE_READY)
					{
						IsFinishedLoading = true;
						FModEventName = BankData->m_FModEventName.AsChar ();
						break;
					}
				}
			}

			if (IsFinishedLoading == true)
			{
				BankData->m_AudioSettings.m_IsLoaded = true;
				mIsRequestedFileAStream = true;
				AudioThatSignalsBackWhenDone* Suicidal = AP_NEW (Axiom::Memory::AUDIO_HEAP, 
						AudioThatSignalsBackWhenDone (FmodEventGroups, 
														pEvent, FModEventName, &(BankData->m_AudioSettings)));
				Suicidal = Suicidal;// Avoiding compiler warnings
				AudioStreamsLoading[i] = -1;// clear the index
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::Update( float X, float Y, float Z, float LookAtX, float LookAtY, float LookAtZ, float upX, float upY, float upZ)
	{	
		FMOD_RESULT           result;
		if(mIsReady)
		{
			// Camera position
			SetVector (mFmodCameraPositionVector, X, Y, Z);//, 1.0);//DistanceScalingFactor);
			int ListenerId = 0;

			
		/*	LookAtX = -LookAtX;
			LookAtY = -LookAtY;
			LookAtZ = -LookAtZ;*/

			FMOD_VECTOR			OrientationVector; 
			
			FMOD_VECTOR			UpVector;
			FMOD_VECTOR			VelocityVector = {0, 0, 0};
			FMOD_VECTOR			HackVector = mFmodCameraPositionVector;//{0, 0, 0};

			// invert the looking direction because we receive the looking direction from the Ball to the camera
			SetVector (OrientationVector, -LookAtX, -LookAtY, -LookAtZ);
			SetVector (UpVector, upX, upY, upZ);

			// camera orientation
			result = FmodEventSystem->set3DListenerAttributes (ListenerId,
																&HackVector,
																&VelocityVector,
																&OrientationVector,
																&UpVector);

			UpdateAudioWithCallbacks ();
			UpdateNSyncMusicTransitionGroup ();
			OnUpdateQueue();
			UpdateFinishedAudio ();
			UpdateLoadingAudio ();
			UpdateFileStreams ();
			
			FmodEventSystem->update();	
		}
	}

	//---------------------------------------------------------------------

	void					AudioSystem::UpdateTime						(int TimePassedInMilliseconds)
	{
		UpdateAudioMixes (TimePassedInMilliseconds);
	}

	//---------------------------------------------------------------------

	void			AudioSystem::UpdateAudioMixes				(int TimePassedInMilliseconds)
	{
		if (CurrentMix.Update (TimePassedInMilliseconds) == true)
		{
			AudioMixUpdated ();
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::UpdateNSyncMusicTransitionGroup ()
	{
		if	(mIsReady == false)
		{
			return;
		}
		if (MusicTransitionPool.Count() > 0)// fixes a possible race condition
		{
			for (int i= 0; i< MaxNumMusicTransitions; i++)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[i];
				if (TransitionGroup.CurrentlyPlayingIndex != -1)
				{
					TransitionGroup.Update ();
				}
			}

			for (int i= 0; i< MaxNumMusicTransitions; i++)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[i];
				if (TransitionGroup.IsReadyToBeDeleted () == true)
				{
					int NumBanks = TransitionGroup.NumBanks;
					for (int i=0; i<NumBanks; i++)
					{
						int EventId = TransitionGroup.EventIds [i];
						//int EventId = TransitionGroup.AudioBanks->EventId;
						AudioEventData&		EventData = GetEventData (EventId);// clearing references to the audio
						EventData.m_NSyncMusicTransitionalGroupId = -1;
					}
					TransitionGroup.Clear ();
				}
			}
		}
	}
	
	//---------------------------------------------------------------------
	void	AudioSystem::PlayEventInternal				(int EventId, Axiom::UInt8 priority, float X, float Y, float Z, 
															bool PlayIn3D, bool IsGameRequestToPlay, Axiom::UInt8 SpecialSetting)
	{
		//Get the Event which points to an array of sound id's to play
		if(mIsReady && EventId>=0)// this event ID thing just became an issue, -1 is not an acceptable index.
		{
			AudioEventData&						EventData = GetEventData (EventId);
			const char*							EventName = mAudioEvents->GetEventName (EventData.m_Id);
			AudioEventGroupData&				GroupData = GetGroupDataByAudioEventName (EventName);
			//AudioEventGroupData&				GroupData = GetGroupData (EventData.m_GroupId);
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;			
			
			if (PlayNSyncMusicTransitionGroup (EventId) == true)
			{
				return;
			}
			int NumItems = EventData.m_NumBanks;
			int EventDelay = EventData.m_AudioSettings.m_Delay;
			for (int x = 0; x < NumItems;x++)
			{	
				SimpleBankData* BankData = &(BankSetup[x]);
				if (CanPlay (BankData, IsGameRequestToPlay) == false)
				{
					continue;
				}
				int TotalDelay = EventDelay + BankData->m_AudioSettings.m_Delay;
				if (TotalDelay > 0)
				{
					AddQueueItem(BankData, EventData.m_AudioSettings.m_Delay, priority, X, Y, Z, PlayIn3D);
				}
				else if (BankData->m_AudioSettings.m_IsStopEvent)
				{
					StopEvent (EventId);
				}
				else
				{
					PlaySound (&EventData, &GroupData, BankData, priority, X, Y, Z, PlayIn3D, SpecialSetting);
				}
			}
		}
	}
	//---------------------------------------------------------------------
	void	AudioSystem::PlayEvent_Reflection (int EventId)
	{
		if (mIsReady == false)
			return;
		PlayEventInternal (EventId, 50, 0, 0, 0, false, false, 255);
	}
	//---------------------------------------------------------------------
	void	AudioSystem::PlayEvent(int EventId,Axiom::UInt8 priority, float X, float Y, float Z, bool PlayIn3D)
	{
		PlayEventInternal (EventId, priority, X, Y, Z, PlayIn3D, true, 255);
	}
	//---------------------------------------------------------------------
	void	AudioSystem::PlayEvent(int EventId, Axiom::UInt8 priority, Axiom::UInt8 ValueFrom0to100)
	{
		PlayEventInternal (EventId, priority, 0, 0, 0, false, true, ValueFrom0to100);
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::CanPlay (SimpleBankData* BankData, bool IsGameRequest)// not a request from the tool
	{
		if (BankData->m_FModEventName.Length () == 0)
			return false;

		if (IsGameRequest == false)// always play tool-events
			return true;

		int TestValue = mCurrentIntensity;
		if (mOverRideIntensityFlag == true)
		{
			TestValue = mIntensityOverrideValue;
		}
		
		// make sure that the audio is in the range of intensity
		if (TestValue >= BankData->m_AudioSettings.m_PlayRange.m_Low && 
			TestValue <= BankData->m_AudioSettings.m_PlayRange.m_High)
			return true;

		return false;
	}
	//---------------------------------------------------------------------
	// event stopping is assumed to be called only from scripts. This means that 
	// we need to unload the audio data when a user calls stop.
	void	AudioSystem::StopEvent (int EventId)
	{
		//Get the Event which points to an array of sound id's to play
		if(mIsReady)
		{
			if (StopNSyncMusicTransitionGroup (EventId) == true)
			{
				return;
			}

			AudioEventData&						EventData = GetEventData (EventId);		
			int									NumItems = EventData.m_NumBanks;
			AudioEventData::AudioBankDataType &	BankSetup = EventData.m_BankSetup;
			//int									FmodIDLogging = 0;

			for (int x = 0; x < NumItems;x++)
			{	
				SimpleBankData* BankData = &(BankSetup[x]);
				StopSound (BankData);			
			}		
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::PreloadEvent					(int EventId)
	{
		if(mIsReady && EventId>=0)// this event ID thing just became an issue, -1 is not an acceptable index.
		{
			AudioEventData&						EventData = GetEventData (EventId);
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;				

			int NumItems = EventData.m_NumBanks;
			for (int x = 0; x < NumItems;x++)
			{	
				SimpleBankData* BankData = &(BankSetup[x]);
				if (BankData->m_AudioSettings.m_IsStream == true &&
					BankData->m_AudioSettings.m_IsLoaded == false)
				{
					GetFMODEvent (BankData);
					BankData->m_AudioSettings.m_IsLoaded = true;
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::UnloadEvent						(int EventId)
	{
		if(mIsReady && EventId>=0)
		{
			StopEvent (EventId);
			AudioEventData&						EventData = GetEventData (EventId);
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;				

			int NumItems = EventData.m_NumBanks;
			for (int x = 0; x < NumItems;x++)
			{	
				SimpleBankData* BankData = &(BankSetup[x]);
				if (BankData->m_AudioSettings.m_IsStream == true &&
					BankData->m_AudioSettings.m_IsLoaded == true)
				{
					if (BankData->mStreamPointer != InvalidFMODEventPointer ())
					{
						FmodEventGroups->freeEventData (BankData->mStreamPointer);
						BankData->mStreamPointer = InvalidFMODEventPointer ();
					}
					BankData->m_AudioSettings.m_IsLoaded = false;
				}
			}
		}
	}
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	
	float	AudioSystem::CalculateVolume (AudioEventData* EventData, SimpleBankData* BankData)
	{		
		if (EventData->m_AudioSettings.m_MuteOn == true)
		{
			return 0.0;
		}
		const char* EventName = mAudioEvents->GetEventName (EventData->m_Id);
		AudioEventGroupData&	GroupData =GetGroupDataByAudioEventName	(EventName);	
		return CalculateVolumeUtil (EventData->m_AudioSettings.m_Volume,
								BankData->m_AudioSettings.m_Volume,
								GetGroupMixVolumeLevel (EventName),
								VolumeSetByGame[EventData->m_Id]) * mCategoryVolumes[GroupData.m_Category];
	}
	float	AudioSystem::CalculateVolume (AudioEventData* EventData)
	{
		if (EventData->m_AudioSettings.m_MuteOn == true)
		{
			return 0.0;
		}
		const char* EventName = mAudioEvents->GetEventName (EventData->m_Id);
		AudioEventGroupData&	GroupData = GetGroupDataByAudioEventName (EventName);
		return CalculateVolumeUtil (EventData->m_AudioSettings.m_Volume,
								(Axiom::UInt32) DefaultMaxVolume,
								GetGroupMixVolumeLevel (EventData->m_GroupId),
								VolumeSetByGame[EventData->m_Id]) * mCategoryVolumes[GroupData.m_Category];
	}
	float	AudioSystem::CalculatePitch (AudioEventData* EventData, SimpleBankData* BankData)
	{
		return CalculatePitchUtil (BankData->m_AudioSettings.m_Pitch, (float) EventData->m_AudioSettings.m_Pitch);
	}
	
	//---------------------------------------------------------------------
	void	AudioSystem::PlayEventWithSignalBack			(int EventId, int ReplyId, PlayBankParams& PlayParams, bool SignalOnAudioEndFlag)
	{
		if (mIsReady == false)
			return;

		int NumItems = AudioSignalListPool.Count ();
		for (int i=0; i<NumItems; i++)
		{
			SignaledAudio& sa = AudioSignalListPool[i];
			if (sa.IsAvailable () == true)
			{
				SignaledAudio::SignalType SignalType = SignaledAudio::SignalBackAtEnd;
				if (SignalOnAudioEndFlag == false)
					SignalType = SignaledAudio::SignalBackAtStart;

				AudioEventData&			EventData = GetEventData (EventId);	
				AudioEventData::AudioBankDataType&		
										BankSetup = EventData.m_BankSetup;
				SimpleBankData*	BankData = &(BankSetup[0]);// we'll just use the first bank in an event (usually just one anyway)

				// note the order here, we check the ID first and then the pointer. 
				// No sense grabbing a pointer to an invalid ID.
				if (BankData->m_FModEventName.Length () != 0)
				{
					PrepareFMODPointer (BankData, true);
					float Volume = CalculateVolume (&EventData, BankData);
					float Pitch = CalculatePitch (&EventData, BankData);

					PlayParams.m_volume = Volume;
					PlayParams.m_pitch = Pitch;
					if (EventData.m_AudioSettings.m_MuteOn == true)
					{
						Volume = 0;
					}

					if (mStreamsAreEnabled == true ||
						BankData->m_AudioSettings.m_IsStream != true)
					{
						if (BankData->m_AudioSettings.m_IsStream == true)
						{
							BankData->m_AudioSettings.m_IsPlaying = true;
						}
						sa.PlaySound (SignalType, FmodEventGroups, BankData->mStreamPointer, EventId, ReplyId, &mSignaler, PlayParams);
					}
				}
				break;// once we find an available spot to put the signal back
			}
		}
	}
	

	//---------------------------------------------------------------------
	
	// we have potential threading issues here. Some threading protection mechanism is required
	void			AudioSystem::AddToFinishedAudioItemsNeedingDeleteList (AudioThatSignalsBackWhenDone* ff)
	{
		AP_ASSERT (FinishedAudioIndex < MaxNumFinishedStreamsToDelete);
		for (int i=0; i<FinishedAudioIndex; i++)
		{
			if (ArrayOfFinishedAudioItemsNeedingDelete[i] == ff)// avoid duplicates.
				return;
		}
		ArrayOfFinishedAudioItemsNeedingDelete [FinishedAudioIndex++] = ff;
	}

	

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	
	void			AudioSystem::PlayBank (int BankId, int Volume)
	{
		FMOD_RESULT result;
		if(mIsReady)
		{
			// this may be confusing, but remember that our event corresponds to an FDesigner 
			// event which we treat as a bank
			// note the order here, we check the ID first and then the pointer. 
			// No sense grabbing a pointer to an invalid ID.
			if (BankId != -1)
			{
				FMOD::Event* pEvent = InvalidFMODEventPointer ();
				result = FmodEventGroups->getEventByIndex (BankId, 0, &pEvent);
				if (result == FMOD_OK)
				{
					result = pEvent->setVolume(CalculateVolumeUtil (Volume));
					result = pEvent->start ();
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::StopBank (int BankId)
	{
		FMOD_RESULT result;
		if(mIsReady)
		{
			// this may be confusing, but remember that our event corresponds to an FDesigner 
			// event which we treat as a bank
			// note the order here, we check the ID first and then the pointer. 
			// No sense grabbing a pointer to an invalid ID.
			if (BankId != -1)
			{
				FMOD::Event* pEvent = InvalidFMODEventPointer ();
				result = FmodEventGroups->getEventByIndex (BankId, 0, &pEvent);
				if (result == FMOD_OK)
				{
					result = pEvent->stop ();
					FmodEventGroups->freeEventData (pEvent);// assuming that this is a stream.
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::PlayBank	(const char* FModBankName, int Volume)
	{
		if(mIsReady)
		{
			if (FModBankName != NULL)
			{
				FMOD::Event* pBank = InvalidFMODEventPointer ();
				FMOD_EVENT_MODE NonBlockingCall = FMOD_EVENT_NONBLOCKING;
				FMOD_RESULT result = FmodEventGroups->getEvent (FModBankName, NonBlockingCall, &pBank);
				if (result == FMOD_OK)
				{
					result = pBank->setVolume(CalculateVolumeUtil (Volume));
					result = pBank->start ();
				}
			}
		}
	}
	
	//---------------------------------------------------------------------

	void			AudioSystem::StopBank	(const char* FModBankName)
	{
		if(mIsReady)
		{
			if (FModBankName != NULL)
			{
				FMOD::Event* pBank = InvalidFMODEventPointer ();
				FMOD_EVENT_MODE NonBlockingCall = FMOD_EVENT_NONBLOCKING;
				FMOD_RESULT result = FmodEventGroups->getEvent (FModBankName, NonBlockingCall, &pBank);
				if (result == FMOD_OK)
				{
					result = pBank->stop ();
					FmodEventGroups->freeEventData (pBank);// assuming that this is a stream.
				}
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	//Play SFX is the core one-shot playback function, it ultimately controls all composite
	//sound events designed with streaker
	//////////////////////////////////////////////////////////////////////////////////////////////

	void			AudioSystem::SetEventVolume (int EventId, float Volume)
	{
		if (EventId == -1)
			return;

		if (SetNSyncMusicTransitionGroup_Volume (EventId))
		{
			return;
		}
		AudioEventData&						EventData = GetEventData (EventId);
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;
		int									NumItems = EventData.m_NumBanks;
		for (int i=0; i<NumItems; i++)
		{
			SimpleBankData*	BankData = &(BankSetup[i]);

			PrepareFMODPointer (BankData);
			FMOD::Event*			pEvent= BankData->mStreamPointer;//GetFMODEvent (BankData);
			if (pEvent != InvalidFMODEventPointer ())
			{
				pEvent->setVolume (Volume);
			}

		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::SetEventPitch (int EventId, float Pitch)
	{
		if (EventId == -1)
			return;

		if (SetNSyncMusicTransitionGroup_Pitch (EventId))
		{
			return;
		}
		AudioEventData&						EventData = GetEventData (EventId);
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;
		int									NumItems = EventData.m_NumBanks;
		for (int i=0; i<NumItems; i++)
		{
			SimpleBankData*	BankData = &(BankSetup[i]);
			PrepareFMODPointer (BankData);
			FMOD::Event*			pEvent = BankData->mStreamPointer;//mGetFMODEvent (BankData);
			if (pEvent != InvalidFMODEventPointer ())
			{
				pEvent->setPitch (Pitch, FMOD_EVENT_PITCHUNITS_RAW);
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::SetAudioEvents (AudioTriggers* ptr) 
	{
		mAudioEvents = ptr;
		
		int Index = 0;
		while (mAudioEvents->GetNYsyncMusicGroup (Index++, this))
		{
		}

		// this must happen after the initialization of the events
		//InitializeGroupNames ();

		// this is the only place where this works during init. It will be called repeatedly during a tools session
		//FixUpEventsIDsAndGroupIDsByName ();
	}

	//---------------------------------------------------------------------

	void			AudioSystem::PlaySound (AudioEventData* EventData, 
									AudioEventGroupData* GroupData, 
									SimpleBankData* BankData, 
									Axiom::UInt8 priority, float X, float Y, float Z, 
									bool PlayIn3D, Axiom::UInt8 SpecialSetting)
	{
		FMOD_RESULT         result = FMOD_OK;
		PrepareFMODPointer (BankData, true);
		FMOD::Event*		pEvent = BankData->mStreamPointer;
		if (pEvent == InvalidFMODEventPointer ())
			return;
		if (BankData->m_AudioSettings.m_IsPlaying)// only affects streams
			return;

		// volume -- 
		float Volume = CalculateVolume (EventData, BankData);
		if (EventData->m_AudioSettings.m_MuteOn == true)
		{
			Volume = 0;
		}
		result = pEvent->setVolume (Volume);

		// pitch -- 
		float Pitch = CalculatePitch (EventData, BankData);
		if (SpecialSetting != Events::AudioPlaySoundEvent :: SettingOff)
		{
			float PitchOverride = ((float) (SpecialSetting - 50)) * 0.25F;
			Pitch = CalculatePitchUtil (Pitch, PitchOverride);
		}
		result = pEvent->setPitch (Pitch, FMOD_EVENT_PITCHUNITS_RAW);

		// setup for playing
		if (PlayIn3D)
		{			
			Setup3DSoundForPlay (EventData, GroupData, pEvent, X, Y, Z);
		}
		else
		{
			FMOD_VECTOR			PositionVector;
			PositionVector.x = 0; PositionVector.y = 0; PositionVector.z = 0;
			result = pEvent->set3DAttributes(&PositionVector,0,0);
		}
		
		if (BankData->m_AudioSettings.m_IsStream)
		{
		    //AP_ASSERTMESSAGE(result == FMOD_OK, "Playing audio went badly");
		    SetupStreamForPlay (EventData, BankData, priority);
		}
		else
		{
			result = pEvent->start();
		}
		AP_ASSERTMESSAGE(result == FMOD_OK, "Playing audio went badly");
	}
	//---------------------------------------------------------------------

	void	AudioSystem::SetupStreamForPlay (AudioEventData* EventData, 
									SimpleBankData* BankData, Axiom::UInt8 priority)
	{
		if (mStreamsArePaused == false && 
				mStreamsAreEnabled == true)
			{
				bool DidKillOne = true;
				if (GetNumberOfCurretlyPlayingStreams () >= mMaxNumberOfStreams)
				{
					DidKillOne = KillLowestPriorityStreamPlayingWithPriorityLowerThan (priority);
				}

				if (DidKillOne)// don't start a stream unless we can
				{
					BankData->m_Priority = priority;
					for (int i=0; i<MaxNumLoadedStreamsToStart; i++)
					{
						int EId = AudioStreamsLoading[i];
						if (EId == -1)
						{
							AudioStreamsLoading[i] = EventData->m_Id;
							break;
						}
					}
				}	
			}
	}
	//---------------------------------------------------------------------

	void	AudioSystem::Setup3DSoundForPlay (AudioEventData* EventData, AudioEventGroupData* GroupData, FMOD::Event* pEvent, float X, float Y, float Z)
	{
		/*float ScaleValue = //DistanceScalingFactor * 
			GroupData->m_DistanceScaling;*/
		if (GroupData->m_HighVolumeDisc > 0.0F)// just move those objects farther away
		{
			float MinDist = GroupData->m_HighVolumeDisc;// * DistanceScalingFactor;// multiplying by the reciprical.
			pEvent->setPropertyByIndex (FMOD_EVENTPROPERTY_3D_MINDISTANCE, &MinDist, false);
		}
		float MaxDist = 60.0;// hard-coded scalar
		pEvent->setPropertyByIndex (FMOD_EVENTPROPERTY_3D_MAXDISTANCE, &MaxDist, false);
		
		FMOD_VECTOR			PositionVector;
		//SetOffsetVector (PositionVector, X, Y, Z, mFmodCameraPositionVector, ScaleValue);
		SetVector (PositionVector, X, Y, Z);//, ScaleValue);

		pEvent->set3DAttributes(&PositionVector,0,0);
	}

	//---------------------------------------------------------------------

	void	AudioSystem::StopSound (SimpleBankData* BankData)
	{
		if (BankData->m_AudioSettings.m_IsStream && 
			BankData->m_AudioSettings.m_IsPlaying == false)
			return;

		PrepareFMODPointer (BankData);
		FMOD::Event*		pEvent = BankData->mStreamPointer;//GetFMODEvent (BankData);
		if (pEvent != InvalidFMODEventPointer ())
		{
			FMOD_RESULT			result = pEvent->stop();
			if (result != FMOD_OK)
			{
				BankData->mStreamPointer = InvalidFMODEventPointer ();
			}

			if (BankData->m_AudioSettings.m_IsStream == true && 
				BankData->m_AudioSettings.m_IsSelfDeleting == false)
			{
				result = FmodEventGroups->freeEventData (pEvent);
				if (result != FMOD_OK)
				{
					BankData->mStreamPointer = InvalidFMODEventPointer ();
				}
				//ERRCHECK(result);
				BankData->m_AudioSettings.m_IsLoaded = false;
			}				
		}
	}

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------

	void	AudioSystem::MuteAll ()
	{
		if (mIsReady == false)
			return;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			MuteEvent (EventId);
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::UnmuteAll ()
	{
		if (mIsReady == false)
			return;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			UnmuteEvent (EventId);
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::MuteGroup (int GroupId)
	{
		if (mIsReady == false)
			return;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			AudioEventData&		EventData = GetEventData (EventId);
			if (EventData.m_GroupId == GroupId)
			{
				MuteEvent (EventId);
			}
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::UnmuteGroup (int GroupId)
	{
		if (mIsReady == false)
			return;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			AudioEventData&		EventData = GetEventData (EventId);
			if (EventData.m_GroupId == GroupId)
			{
				UnmuteEvent (EventId);
			}
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::MuteEvent (int EventId)
	{
		if (mIsReady == false)
			return;
		AudioEventData&						EventData = GetEventData (EventId);
		EventData.m_AudioSettings.m_MuteOn = true;
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;
		float MuteVolume = 0;
		if (EventData.m_NumBanks >0)
		{
			int NumItems = EventData.m_NumBanks;
			for (int i=0; i<NumItems; i++)
			{
				SimpleBankData*	BankData = &(BankSetup[i]); 				

				if (BankData->m_AudioSettings.m_IsStream == true)// these nested ifs should be performed this way
				{
					if	(BankData->m_AudioSettings.m_IsPlaying == true)
					{
						PrepareFMODPointer (BankData);
						FMOD::Event*		pEvent = BankData->mStreamPointer; //GetFMODEvent (BankData);
						if (pEvent != InvalidFMODEventPointer ())
						{
							pEvent->setVolume (MuteVolume);
						}
					}
				}
				else if (BankData->mStreamPointer != InvalidFMODEventPointer ())
				{
					BankData->mStreamPointer->setVolume (MuteVolume);// this can be an invalid or expired pointer, but we don't care
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void	AudioSystem::UnmuteEvent (int EventId)
	{
		if (mIsReady == false)
			return;
		AudioEventData&						EventData = GetEventData (EventId);
		EventData.m_AudioSettings.m_MuteOn = false;
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;
		if (EventData.m_NumBanks >0)
		{
			int NumItems = EventData.m_NumBanks;
			for (int i=0; i<NumItems; i++)
			{
				SimpleBankData*	BankData = &(BankSetup[i]);

				if (BankData->m_AudioSettings.m_IsStream == true)// these nested ifs should be performed this way
				{
					if	(BankData->m_AudioSettings.m_IsPlaying == true)
					{
						PrepareFMODPointer (BankData);
						FMOD::Event*		pEvent = BankData->mStreamPointer;// GetFMODEvent (BankData);
						if (pEvent != InvalidFMODEventPointer ())
						{
							float Volume = CalculateVolume (&EventData, BankData);
							pEvent->setVolume (Volume);
						}
					}
				}
				else if (BankData->mStreamPointer != InvalidFMODEventPointer ())
				{
					float Volume = CalculateVolume (&EventData, BankData);
					BankData->mStreamPointer->setVolume (Volume);// this can be an invalid or expired pointer, but we don't care
				}
			}
		}
	}

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------

	void			AudioSystem::AudioSetVolume (int EventId, int Volume) 
	{
		AudioEventData&						EventData = GetEventData (EventId);
		EventData.m_AudioSettings.m_Volume = (Axiom::UInt8)Volume;

		VolumeWasChanged (EventId);
	}

	//---------------------------------------------------------------------

	void			AudioSystem::AudioSetGameVolume (int EventId, int Volume) 
	{
		if (VolumeSetByGame.Count () < MaxNumEvents)
			return;

		VolumeSetByGame[EventId] = (Axiom::UInt8) Volume;
		VolumeWasChanged (EventId);
	}

	//---------------------------------------------------------------------

	int				AudioSystem::GetNumberOfCurretlyPlayingStreams ()
	{
		int NumOfCurrentlyPlayingStreams = 0;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			AudioEventData&						EventData = GetEventData (EventId);
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
			if (EventData.m_NumBanks >0)
			{
				int NumItems = EventData.m_NumBanks;
				for (int i=0; i<NumItems; i++)
				{
					SimpleBankData*	BankData = &(BankSetup[i]);
					if (BankData->m_AudioSettings.m_IsStream == true)
					{
						if (BankData->m_AudioSettings.m_IsPlaying == true)
							NumOfCurrentlyPlayingStreams++;
					}
				}
			}
		}
		return NumOfCurrentlyPlayingStreams;
	}

	//---------------------------------------------------------------------
	bool		AudioSystem::KillLowestPriorityStreamPlayingWithPriorityLowerThan (int priority)
	{
		int LowestIndex = -1;
		int LowestBankIndex = -1;
		int LowestFoundPriority = priority;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			AudioEventData&						EventData = GetEventData (EventId);			
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
			if (EventData.m_NumBanks >0)
			{
				int NumItems = EventData.m_NumBanks;
				for (int i=0; i<NumItems; i++)
				{
					SimpleBankData*	BankData = &(BankSetup[i]);
					if (BankData->m_AudioSettings.m_IsStream == true)
					{
						if (BankData->m_AudioSettings.m_IsPlaying == true)
						{
							if (BankData->m_Priority < LowestFoundPriority)
							{
								LowestIndex = EventId;
								LowestBankIndex = i;
								LowestFoundPriority = BankData->m_Priority;
							}
						}
					}
				}
			}
		}

		if (LowestIndex != -1)
		{
			AudioEventData&						EventData = GetEventData (LowestIndex);			
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
			if (EventData.m_NumBanks >0)
			{
				SimpleBankData*	BankData = &(BankSetup[LowestBankIndex]);
				if (BankData->m_AudioSettings.m_IsStream == true)
				{
					if (BankData->m_AudioSettings.m_IsPlaying == true)
					{
						PrepareFMODPointer (BankData);
						FMOD::Event* pEvent = BankData->mStreamPointer;// GetFMODEvent (BankData);
						if (pEvent != InvalidFMODEventPointer ())
						{
							pEvent->stop ();
							if (BankData->m_AudioSettings.m_IsSelfDeleting == false)
							{
								FmodEventGroups->freeEventData (pEvent);
								BankData->m_AudioSettings.m_IsLoaded = false;
							}
							BankData->mStreamPointer = InvalidFMODEventPointer ();
						}
					}
				}
			}
			return true;
		}
		return false;
	}
	//---------------------------------------------------------------------

	void			AudioSystem :: VolumeWasChanged (int EventId) 
	{
		AudioEventData&						EventData = GetEventData (EventId);
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
		if (EventData.m_NumBanks >0)
		{
			//AudioEventGroupData&				GroupData = GetGroupData (EventData.m_GroupId);
			int NumItems = EventData.m_NumBanks;
			for (int i=0; i<NumItems; i++)
			{
				SimpleBankData*	BankData = &(BankSetup[i]);
				if (BankData->m_AudioSettings.m_IsStream == true && 
					BankData->m_AudioSettings.m_IsPlaying == true)
				{
					PrepareFMODPointer (BankData);

					FMOD::Event*			pEvent = BankData->mStreamPointer;// GetFMODEvent (BankData);
					if (pEvent != InvalidFMODEventPointer ())
					{
						float Volume = CalculateVolume (&EventData, BankData);
						FMOD_RESULT result = pEvent->setVolume (Volume);
						if (result != FMOD_OK)
						{
							BankData->mStreamPointer = InvalidFMODEventPointer ();
						}
					}
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::AudioMixUpdated () 
	{
		if (mIsReady == false)
			return;

		//Axiom::Thread::Sleep (500);
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			if (SetNSyncMusicTransitionGroup_Volume (EventId))
			{
				SetNSyncMusicTransitionGroup_Pitch (EventId);
				continue;
			}

			AudioEventData&						EventData = GetEventData (EventId);			
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
			int NumItems = EventData.m_NumBanks;
			for (int bankId=0; bankId<NumItems; bankId++)
			{
				SimpleBankData*	BankData = &(BankSetup[bankId]);					

				if (BankData->m_AudioSettings.m_IsStream == true && 
					BankData->m_AudioSettings.m_IsPlaying == true) 
					//&& BankData->mStreamPointer != InvalidFMODEventPointer ())
				{
					PrepareFMODPointer (BankData);
					FMOD::Event*		pEvent = BankData->mStreamPointer;
					float Volume = CalculateVolume (&EventData, BankData);
					FMOD_RESULT result = pEvent->setVolume (Volume);
					if (result != FMOD_OK)
					{
						BankData->mStreamPointer = InvalidFMODEventPointer ();
					}
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void			AudioSystem::Shutdown()
	{
		AP::Reflection::Script::Unregister("AudioSystem");
		FmodEventSystem->release();
		FmodEventSystem = NULL;
		if (mMemBuffer != NULL)
		{
			AP_DELETE(mMemBuffer);
			mMemBuffer = NULL;
		}
	}

	//---------------------------------------------------------------------

	Axiom::UInt32			AudioSystem::GetMaxMemoryAvailable			() const
	{
		return HeapSize;
	}

	//---------------------------------------------------------------------

	// I have no way to test the following code. Sorry if it doesn't work. - Mickey
	void					AudioSystem::AddAudioFile					(const char* AudioFileName, const char* RawEncodedAudioData)
	{
		Axiom::Base64Decoder decoder;

		int RawAudioDataLength = Axiom::StringLength (RawEncodedAudioData);
		int	NewDecodedLength = RawAudioDataLength;
		char* NewAudioBuffer = AP_NEW (Axiom::Memory::AUDIO_HEAP, char[NewDecodedLength]);
		decoder.Decode (RawEncodedAudioData, RawAudioDataLength, NewAudioBuffer, NewDecodedLength);

		// you now have the data you need to add a new chunk of audio
		// something like this (this code is completely untested, but does compile):
		// 
		// FMOD::System * SystemObject;
		// FMOD::Sound * ResultingSound;
		// FMOD_CREATESOUNDEXINFO SoundDefinitionPointer;
		// FmodEventSystem->getSystemObject (&SystemObject);
		// int FModMode = FMOD_3D | FMOD_HARDWARE | FMOD_OPENMEMORY; // FMOD_OPENRAW (inca== case the data is uncompressed)
		// FMOD_RESULT result = SystemObject->createSound (NewAudioBuffer, FModMode, &SoundDefinitionPointer, &ResultingSound);

		AP_DELETE (NewAudioBuffer);
	}

	//---------------------------------------------------------------------

	void			AudioSystem::SetVolume						(int Volume)
	{
		if (mIsReady == false)
			return;
		mMasterVolume = Volume;
		FmodEventCategories->setVolume(CalculateVolumeUtil (Volume));
	}

	//---------------------------------------------------------------------

	void			AudioSystem::SetCurrentMix					(int which)
	{
		currentAudioMixIndex = which;
		if (currentAudioMixIndex >= mNumAudioMixes)
		{
			currentAudioMixIndex = 0;
		}
		CurrentMix.Setup (AudioMixOverlayPool[currentAudioMixIndex].MixPerGroup, AudioMixOverlayPool[currentAudioMixIndex].RampTimePerGroup);
	}

	//---------------------------------------------------------------------

	void			AudioSystem::SetCurrentMix_Reflection		(const char* name)
	{
		if (mIsReady == false)
			return;
		int  WhichArrangement = GetMixID (name);
		if (WhichArrangement != -1)
		{	
			// set it immediately, don't wait.
			CurrentMix.Setup (AudioMixOverlayPool[WhichArrangement].MixPerGroup);
			//SetCurrentMix	(WhichArrangement);
		}
	}

	//---------------------------------------------------------------------
/*	void					AudioSystem::SetRolloff						(float Rolloff)
	{
		FMOD::System * SystemObject;
		FMOD_RESULT result = FmodEventSystem->getSystemObject (&SystemObject);
		ERRCHECK(result);

		float dopplerscale = 0, distancefactor = 0, rolloffscale = 0;
		result = SystemObject->get3DSettings (&dopplerscale, &distancefactor, &rolloffscale);
		ERRCHECK(result);

		rolloffscale = Rolloff; 
		result = SystemObject->set3DSettings (dopplerscale, distancefactor, rolloffscale);
		ERRCHECK(result);
	}*/
	//---------------------------------------------------------------------

	void			AudioSystem::SetDistanceScaling				(float DistanceScaling)
	{
		DistanceScalingFactor = DistanceScaling;
	}

	//---------------------------------------------------------------------

	int				AudioSystem::GetGroupMixVolumeLevel (int GroupId)
	{
		int MixValue = CurrentMix.GetCurrentValue (GroupId);
		return MixValue;
	}

	//---------------------------------------------------------------------

	int				AudioSystem::GetGroupMixVolumeLevel	(const char* EventName)
	{
		int	GroupId = GetGroupDataByAudioEventName	(EventName).m_Id;	
		int MixValue = GetGroupMixVolumeLevel (GroupId);
		return MixValue;
	}
	//---------------------------------------------------------------------

	bool			AudioSystem::IsResetting ()
	{
		return mIsResetting;
	}

	//---------------------------------------------------------------------

	int 			AudioSystem::GetInternalIDsFromEvent (int EventId, int* ArrayOfInternalIDs, int ArraySize)
	{
		int ReturnCount = 0;
		AudioEventData&						EventData = GetEventData (EventId);			
		AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
		if (EventData.m_NumBanks >0)
		{
			int NumItems = EventData.m_NumBanks;
			for (int i=0; i<NumItems; i++)
			{
				SimpleBankData*	BankData = &(BankSetup[i]);
				ArrayOfInternalIDs [ReturnCount++] = BankData->m_FModEventId;
				if (ReturnCount > ArraySize)
					return ReturnCount;
			}
		}
		ArrayOfInternalIDs [ReturnCount] = 0;
		return ReturnCount;
	}

	//---------------------------------------------------------------------

	AudioEventData*		AudioSystem::GetEvent	(const char* name)
	{
		/*if (mIsReady == false)
			return NULL;*/

		int LengthOfPassedInString = Axiom::StringLength (name);
		int num = mAudioEvents->GetEventCount ();
		
		for (int i=0; i<num; i++)
		{
			const char* EventName = mAudioEvents->GetEventName(i);
			int LenLocal = Axiom::StringLength (EventName);
			
			// these strings cannot be the same unless their lengths are the same (ignoring any extra spaces on the ends)
			if (LenLocal == LengthOfPassedInString &&
				Axiom::StringCompare (EventName, name, LenLocal) == 0)
			{
				AudioEventData*ReturnPointer = &(AudioEventPool[i]);
			
				return ReturnPointer;
			}
		}
		return &(AudioEventPool[AudioEventPool.Capacity ()-1]);
	}
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	AudioMixArrangementData* AudioSystem::GetMix	(const char* name)
	{
		int num = mAudioMixes->GetMixCount ();
		int LengthOfPassedInString = Axiom::StringLength (name);
		for (int i=0; i<num; i++)
		{
			int LenLocal = Axiom::StringLength (mAudioMixes->GetMixName(i));

			if (LenLocal == LengthOfPassedInString &&
				Axiom::StringCompare (mAudioMixes->GetMixName(i), name, LenLocal) == 0)
			{
				AudioMixArrangementData*ReturnPointer = &(AudioMixOverlayPool[i]);
				return ReturnPointer;
			}
		}
		return &(AudioMixOverlayPool[AudioMixOverlayPool.Capacity () -1]);
	}
	//---------------------------------------------------------------------
	int			AudioSystem::GetMixID	(const char* name)
	{
		int num = mAudioMixes->GetMixCount ();
		int LengthOfPassedInString = Axiom::StringLength (name);
		for (int i=0; i<num; i++)
		{
			int LenLocal = Axiom::StringLength (mAudioMixes->GetMixName(i));
			
			if (LenLocal == LengthOfPassedInString &&
				Axiom::StringCompare (mAudioMixes->GetMixName(i), name, LenLocal) == 0)
			{
				return i;
			}
		}
		return -1;
	}



	//---------------------------------------------------------------------
	void		AudioSystem::FMODLoad()
	{
#if defined (AUDIO_ENABLED)
		FMOD_RESULT           result;
		mFmodCameraPositionVector.x = 0;
		mFmodCameraPositionVector.y = 0;
		mFmodCameraPositionVector.z = 0;

#if CORE_PS3 == CORE_NO
		result = FmodEventSystem->init (MaxNumEvents, FMOD_INIT_NORMAL, 0, FMOD_EVENT_INIT_NORMAL);
#else
		result = FmodEventSystem->init (MaxNumEvents, FMOD_INIT_NORMAL, (void *)&ps3DriverData);
#endif
		AP_ASSERTMESSAGE(result == FMOD_OK, "Fmod init went badly");

		result = FmodEventSystem->set3DListenerAttributes (0,&mFmodCameraPositionVector,0,0,0);
		AP_ASSERTMESSAGE(result == FMOD_OK, "Setting the camera for FDesigner went badly");

		Axiom::FileManager::VirtualFilePathString eventPath = "platform_audio:";
		Axiom::FileManager::PlatformFilePathString platformPath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( eventPath );

		const char*				PlatformSpecificPath = platformPath.AsChar();//eventPath.GetPlatformSpecific().CStr();
		result = FmodEventSystem->setMediaPath (PlatformSpecificPath);  
		AP_ASSERTMESSAGE(result == FMOD_OK, "Setting the path in FDesigner went badly");

		FMOD::EventProject *  FmodProject;
		result = FmodEventSystem->load (MAIN_EVENT_FILE, 0, &FmodProject);
		if (result == FMOD_ERR_FILE_NOTFOUND)
		{	
			FMODLoadBackup ();
		}
		else 
		{
			result = FmodEventSystem->getGroup (MAIN_GROUP, FMOD_EVENT_DEFAULT, &FmodEventGroups);
			if (result == FMOD_OK)
			{
				Axiom::Thread::Sleep (1000);
#if	CORE_LINKEDTORELEASE // performance of release builds necessitates this extra time to allow for the file copy to complete.
		Axiom::Thread::Sleep (1200);
#endif
				// This tells us what is cached in memory and what is not. Right now, we are only caching Banks, not Streams.
#if CORE_WII == CORE_YES
				result = FmodEventGroups->loadEventData (FMOD_EVENT_RESOURCE_SAMPLES, FMOD_EVENT_DEFAULT); // Wii non-blocking results in no audio
#else
				result = FmodEventGroups->loadEventData (FMOD_EVENT_RESOURCE_SAMPLES, FMOD_EVENT_NONBLOCKING);
#endif
				// If we want to load everything into RAM, use this
				//(FMOD_EVENT_RESOURCE_STREAMS_AND_SAMPLES, FMOD_EVENT_DEFAULT);
					
				if (result == FMOD_OK)
				{
					result = FmodEventSystem->getCategory (MAIN_CATEGORY, &FmodEventCategories);
					AP_ASSERTMESSAGE(result == FMOD_OK, "grabbing the category for FDesigner went badly");

					InitializeGroupNames ();
					FixUpEventsIDsAndGroupIDsByName ();// loading can sometimes leave the ids out of whack
					// another concern is that the names need to be setup before runnuing the lua files

					LoadAudioLuaFile ();
					LoadAudioMixLuaFile ();
					// this must be called after the load lua call or at least after the 
					// FDesigner project loads
					InitEventWithSignalBack ();

					FmodEventCategories->setVolume (CalculateVolumeUtil (mMasterVolume));// max volume
				}
				else
				{
					FmodEventSystem->unload ();
					FMODLoadBackup ();
				}
			}
			else
			{
				FmodEventSystem->unload ();
				FMODLoadBackup ();
			}
		}
		mIsReady = true;
		mIsResetting = false;
		InitNSyncMusicTransitionGroup ();

		SetCurrentMix(currentAudioMixIndex);// after loading the mix file, we need to set our values.
		AudioMixUpdated ();
		
#endif //AUDIO_ENABLED
	}
	
	

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------

	void		AudioSystem::FMODLoadBackup ()
	{
		// note: we don't load the LUA file.

		FMOD_RESULT result = FmodEventSystem->load("DefaultProject.fev", 0, 0);
		if (result != FMOD_ERR_FILE_NOTFOUND)
		{
			result = FmodEventSystem->getGroup("DefaultProject/untitled", true, &FmodEventGroups);
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD get group went badly");

			result = FmodEventGroups->loadEventData(FMOD_EVENT_RESOURCE_STREAMS_AND_SAMPLES, 0);
			AP_ASSERTMESSAGE(result == FMOD_OK, "loading the event file in FDesigner went badly");

			if (result == FMOD_OK)
			{
				result = FmodEventSystem->getCategory("master", &FmodEventCategories);
				AP_ASSERTMESSAGE(result == FMOD_OK, "getting the category for FDesigner went badly");
			}
		}
		mIsReady = true;
	}
	//---------------------------------------------------------------------

	void		AudioSystem::LoadAudioLuaFile()
	{
		AP::Reflection::Script::Result result;
		Axiom::FileManager::FileManager & fs = *Axiom::FileManager::FileManager::GetInstance();
		const Axiom::FileManager::FileInfo fileInfo = fs.GetFileInfo("platform_audio:Audio.lua");

		if (fileInfo.GetSize() >0)
		{
			result = AP::Reflection::Script::ExecuteFile ("platform_audio:Audio.lua") ;
			if (result.Error () != AP::Reflection::Script::SUCCESS)
			{
				const char* ptr = result.ToString();
				Axiom::Log ("Audio", "Lua Script error: %s", ptr);
				AP_ASSERTFAIL ("Hey programmer dude, what is the problem with the Audio.lua file");
			}
		}
	}

	//---------------------------------------------------------------------
	void		AudioSystem::LoadAudioMixLuaFile()
	{
		AP::Reflection::Script::Result result;
		Axiom::FileManager::FileManager & fs = *Axiom::FileManager::FileManager::GetInstance();
		const Axiom::FileManager::FileInfo fileInfo = fs.GetFileInfo("platform_audio:AudioMix.lua");

		if (fileInfo.GetSize() >0)
		{
			result = AP::Reflection::Script::ExecuteFile ("platform_audio:AudioMix.lua") ;
			if (result.Error () != AP::Reflection::Script::SUCCESS)
			{
				const char* ptr = result.ToString();
				Axiom::Log ("AudioMix", "Lua Script error: %s", ptr);
				AP_ASSERTFAIL ("Hey programmer dude, what is the problem with the AudioMix.lua file");
			}
		}
	}

	//---------------------------------------------------------------------

	void		AudioSystem::FixUpEventsIDsAndGroupIDsByName ()
	{
		int num = mAudioEvents->GetEventCount ();
		
		for (int i=0; i<num; i++)
		{
			const char* EventName = mAudioEvents->GetEventName(i);
			AudioEventGroupData&	Group = GetGroupDataByAudioEventName	(EventName);
			AudioEventData& EventData = GetEventData (i);
			EventData.m_GroupId = Group.m_Id;
		}
	}

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	AudioEventGroupData&	AudioSystem::GetGroupData (int GroupId)
	{
		AP_ASSERT(GroupId < MaxNumGroups);
		return AudioEventGroupPool[GroupId];
	}

	//---------------------------------------------------------------------
	AudioEventGroupData&	AudioSystem::GetGroupDataByAudioEventName	(const char* name)	// this name will be parsed
	{
		// first sort out just the first part of the string
		char Buffer [64];
		char* PointerToUnderscore = Axiom::StringFindChar (name, '_');

		int LengthToUnderscore = PointerToUnderscore - name;
			
		// it often happens that the first part of the name is "Event"
		/*if (Axiom::StringCompare (name, "Event", 5) == 0)
		{
			name += 5;
			LengthToUnderscore -= 5;
		}*/
		AP_ASSERT (LengthToUnderscore > 1);

		Axiom::StringCopy	(Buffer, name, LengthToUnderscore);
		Buffer [LengthToUnderscore] = 0;// ending null char
		

		return GetGroupDataByName	(Buffer);
	}
	
	//---------------------------------------------------------------------
	AudioEventGroupData&	AudioSystem::GetGroupDataByFmodEventName (const char* name)
	{
		// first sort out just the first part of the string
		char Buffer [64];
		char* PointerToUnderscore = Axiom::StringFindChar (name, '_');

		int LengthToUnderscore = PointerToUnderscore - name;
			
		// it often happens that the first part of the name is "Event"
		if (Axiom::StringCompare (name, "Event", 5) == 0)
		{
			name += 5;
			LengthToUnderscore -= 5;
		}
		AP_ASSERT (LengthToUnderscore > 1);

		Axiom::StringCopy	(Buffer, name, LengthToUnderscore);
		Buffer [LengthToUnderscore] = 0;// ending null char
		

		return GetGroupDataByName	(Buffer);
	}

	//---------------------------------------------------------------------
	int						AudioSystem::GetNumGroups	()
	{
		int Count = 0;
		for (int i=0; i<MaxNumGroups; i++)
		{
			if (AudioEventGroupPool[i].m_Name.Length () >0)
			{
				Count ++;
			}
		}
		return Count;
	}

	//---------------------------------------------------------------------
	AudioEventGroupData&	AudioSystem::GetGroupDataByName	(const char* name)
	{
		for (int i=0; i<MaxNumGroups; i++)
		{
			if (AudioEventGroupPool[i].m_Name == name)
			{
				return AudioEventGroupPool[i];
			}
		}
		return AudioEventGroupPool[MaxNumGroups-1];
	}
	
	//---------------------------------------------------------------------
	AudioEventGroupData&	AudioSystem::GetGroupDataByGroupId	(int GroupId)
	{
		for (int i=0; i<MaxNumGroups; i++)
		{
			if (AudioEventGroupPool[i].m_Id == GroupId)
			{
				return AudioEventGroupPool[i];
			}
		}
		return AudioEventGroupPool[MaxNumGroups-1];
	}
	//---------------------------------------------------------------------
	int						AudioSystem::GetGroupIdByName	(const char* name)
	{
		for (int i=0; i<MaxNumGroups; i++)
		{
			if (AudioEventGroupPool[i].m_Name == name)
			{
				return AudioEventGroupPool[i].m_Id;
			}
		}
		return -1;
	}
	//---------------------------------------------------------------------
	void	AudioSystem::SetGroupVolume (int GroupId, int Volume)
	{
		AP_ASSERT(GroupId < MaxNumGroups);
		AudioEventGroupPool[GroupId].m_Volume = (Axiom::UInt8) Volume;
	}
	//---------------------------------------------------------------------
	void	AudioSystem::SetCategoryVolume (int category, int volume)
	{
		if (category <0 || category >AP::Events::EAudioBroadCategory::NumberOfItems)
			return;

		if (volume <0)
			volume = 0;
		if (volume > 100)
			volume = 100;

		float FinalValue = (float) volume / 100;

		mCategoryVolumes[category] = FinalValue;

		AudioMixUpdated ();// update all playing streams and volume
	}

	//---------------------------------------------------------------------
	void	AudioSystem:: PauseAllStreams (bool PauseApply)
	{
		//return;
		//PauseApply = false;
		for (int EventId=0; EventId<MaxNumEvents; EventId ++)
		{
			AudioEventData&						EventData = GetEventData (EventId);			
			AudioEventData::AudioBankDataType&	BankSetup = EventData.m_BankSetup;	
			if (EventData.m_NumBanks >0)
			{
				int NumItems = EventData.m_NumBanks;
				for (int i=0; i<NumItems; i++)
				{
					SimpleBankData*	BankData = &(BankSetup[i]);
					if (BankData->m_AudioSettings.m_IsStream == true &&
						//BankData->m_AudioSettings.m_IsPlaying == true &&
						BankData->mStreamPointer != InvalidFMODEventPointer ())
					{
						PrepareFMODPointer (BankData);
						FMOD::Event*		pEvent = BankData->mStreamPointer;//GetFMODEvent (BankData);// while this may not make sense, pointers become depricated over time
						pEvent->setPaused (PauseApply);
						//ERRCHECK(result);
					}
				}
			}
		}
		for (int i= 0; i< MaxNumMusicTransitions; i++)
		{
			NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[i];
			if (TransitionGroup.CurrentlyPlayingIndex != -1)
			{
				TransitionGroup.PauseAll (PauseApply);
			}
		}
		mStreamsArePaused = PauseApply;
	}
	//---------------------------------------------------------------------
	int		AudioSystem::GetGroupVolume (int GroupId)
	{
		AP_ASSERT(GroupId < MaxNumGroups);
		return AudioEventGroupPool[GroupId].m_Volume;
	}

	//---------------------------------------------------------------------

	AudioEventData&	AudioSystem::GetEventData (int EventId)
	{
		AP_ASSERT(EventId < MaxNumEvents);
		return AudioEventPool[EventId];
	}

	//---------------------------------------------------------------------

	FMOD::Event*	AudioSystem::GetFMODEvent (SimpleBankData* BankData)
	{
		//AP_ASSERT (BankData->m_FModEventName.Length () != 0);// this index will be invalid anyway
		if (BankData->m_FModEventName.Length () == 0)
			return InvalidFMODEventPointer ();

		// set a global value for the extra file system management.
		if (BankData->m_AudioSettings.m_IsStream == true)
			mIsRequestedFileAStream = true;
		else
			mIsRequestedFileAStream = false;

		float TestPitch;// we are only using this value to test the validity of the pointer.
		if (BankData->m_AudioSettings.m_IsStream &&// for a stream only.
			BankData->mStreamPointer != InvalidFMODEventPointer () &&
			BankData->mStreamPointer->getPitch (&TestPitch) == FMOD_OK)
		{
			return BankData->mStreamPointer;
		}

		FMOD::Event* pBank = InvalidFMODEventPointer ();

		if (mStreamsAreEnabled == true || // we will return an invalid pointer in the case where streams are disabled 
			BankData->m_AudioSettings.m_IsStream == false) //and the requested type is a stream
		{
			FMOD_EVENT_MODE NonBlockingCall = FMOD_EVENT_NONBLOCKING;
			AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, FmodEventGroups->getEvent (BankData->m_FModEventName.AsChar (), NonBlockingCall, &pBank));
			AP_ASSERT (result == FMOD_OK);
		}
	
		BankData->mStreamPointer = pBank;
		return pBank;
	}
	
	//---------------------------------------------------------------------

	void	AudioSystem::PrepareFMODPointer (SimpleBankData* BankData, bool forcePrepForPlay)
	{
		if (BankData->mStreamPointer == InvalidFMODEventPointer ())// we won't look unless we need to.
		{
			GetFMODEvent (BankData);
		}
		else
		{
#ifdef ALWAYS_GRAB_NEW_NON_STREAM_FMOD_POINTER
			if (BankData->m_AudioSettings.m_IsStream == false)// only do this for non-streams, basically, always get a new pointer
			{
				FMOD::Event* pBank = InvalidFMODEventPointer ();
				FMOD_EVENT_MODE NonBlockingCall = FMOD_EVENT_NONBLOCKING;
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, FmodEventGroups->getEvent (BankData->m_FModEventName.AsChar (), NonBlockingCall, &pBank));
				BankData->mStreamPointer = pBank;
				AP_ASSERT (result == FMOD_OK);
			}
			else
#endif
			if(//if we have a stream, make sure that it's playing
				(BankData->m_AudioSettings.m_IsPlaying == true) ||
				forcePrepForPlay == true)// or if we must test the pointer
			{
				float TestPitch = 0.0;// we are testing the pointer
				FMOD_RESULT result = BankData->mStreamPointer->getPitch (&TestPitch);
				if (result != FMOD_OK)
				{
					BankData->mStreamPointer = InvalidFMODEventPointer ();
					GetFMODEvent (BankData);	
				}
				else
				{
					/*Axiom::StaticString<128, char> errorString;
					errorString = "AudioSystem: PrepareFMODPointer - '";
					errorString += FMOD_ErrorString(result);
					errorString += "\'\n";*/
					//Axiom::Log(LOGGING_CHANNEL, "AudioSystem: PrepareFMODPointer - \n'%s\'\n", FMOD_ErrorString(result));
				}
			}
		}
	}

	//---------------------------------------------------------------------

	void AudioSystem::ERRCHECK(FMOD_RESULT result)
	{
		AP_ASSERTMESSAGE(result == FMOD_OK, "Bad FDesigner result");
	}

	//---------------------------------------------------------------------
	void AudioSystem::OnUpdateQueue()
	{
		Axiom::UInt index = 0;
		//const Axiom::UInt NumItemsInQueue = mDelayedEventQueue.Count();

		while(index < mDelayedEventQueue.Count())
		{
			mDelayedEventQueue[index].m_BasicAudioInfo.m_AudioSettings.m_Delay -= 1;
			if (mDelayedEventQueue[index].m_BasicAudioInfo.m_AudioSettings.m_Delay == 0)
			{
				int EventId = mDelayedEventQueue[index].m_BasicAudioInfo.m_AudioEventId;
				
				AudioEventData&			EventData = GetEventData (EventId);
				const char* EventName = mAudioEvents->GetEventName (EventData.m_Id);
				AudioEventGroupData&	GroupData = GetGroupDataByAudioEventName (EventName);
				//AudioEventGroupData&	GroupData = GetGroupData (EventData.m_GroupId);

				PlaySound (& EventData,
							&GroupData, 
							&mDelayedEventQueue[index].m_BasicAudioInfo, 
								mDelayedEventQueue[index].m_BasicAudioInfo.m_Priority,
								mDelayedEventQueue[index].X,
								mDelayedEventQueue[index].Y,
								mDelayedEventQueue[index].Z, 
								mDelayedEventQueue[index].PlayIn3D, 255);
				mDelayedEventQueue.RemoveAt(index);
			}
			else
			{
				index++;
			}
		}
	}

	//---------------------------------------------------------------------
	void AudioSystem::AddQueueItem(SimpleBankData* dStrruct, int AdditionalDelay, Axiom::UInt8 priority, float X, float Y, float Z, bool PlayIn3D)
	{
		AP_ASSERTMESSAGE(mDelayedEventQueue.Count()<mDelayedEventQueue.Capacity(),"too many delayed events, increase queue\n");

		ComplexAudioBankData NewAudioStruct;
		NewAudioStruct.m_BasicAudioInfo = *dStrruct;
		Axiom::Int16 CurrentDelay = NewAudioStruct.m_BasicAudioInfo.m_AudioSettings.m_Delay;
		NewAudioStruct.m_BasicAudioInfo.m_AudioSettings.m_Delay = (Axiom::Int16) (CurrentDelay + AdditionalDelay);
		NewAudioStruct.m_BasicAudioInfo.m_Priority = priority;
		NewAudioStruct.X = X;
		NewAudioStruct.Y = Y;
		NewAudioStruct.Z = Z;
		NewAudioStruct.PlayIn3D = PlayIn3D;
		mDelayedEventQueue.Add(NewAudioStruct);
	}

	
	//---------------------------------------------------------------------
	NSyncMusicTransitionalGroup*
			AudioSystem::CreateMusicTransitionGroup		(int* GameEventIndices, int NumIndices)
	{
		if	(mIsReady == false)
		{
			return NULL;
		}

		if (mStreamsAreEnabled == false)
		{
			return NULL;
		}

		int ArrayOfFMODEventIds[MaxMusicTransitionsSequenceLength];
		int ValidEventIds [MaxMusicTransitionsSequenceLength];
		for (int i=0; i<MaxNumMusicTransitions; i++)
			ArrayOfFMODEventIds[i] = -1;

		bool Success = false;

		// look up the equivalences
		int NumerOfValidIDs = FindValidEventIDsFromListOfEventIDs (ValidEventIds, ArrayOfFMODEventIds, GameEventIndices, NumIndices);
		if (NumerOfValidIDs > 1)// we have to have at least 2 items to successfully setup a transition group.
			Success = true;

		if (MusicTransitionPool.Count() < 1)
		{
			Success = false;
		}
		if (Success)
		{
			// look for this group already existing.
			bool AlreadyEnabledFlag = DoesNSyncMusicTransitionGroupAlreadyExist (ValidEventIds);//ArrayOfFMODEventIds);

			if (AlreadyEnabledFlag == false && MusicTransitionPool.Count() > 0)// fixes a possible race condition
			{
				int Which = SetupNewTransitionGroup (ValidEventIds, NumerOfValidIDs);
				return &(MusicTransitionPool[Which]);
			}
		}
		// not necessarily an error
		//AP_ASSERTMESSAGE(result == FMOD_OK, "could not create a new transition group");
		return &(MusicTransitionPool[MusicTransitionPool.Count () -1]);
	}
	//---------------------------------------------------------------------
	void	AudioSystem::DeleteMusicTransitionGroup		(NSyncMusicTransitionalGroup* group)
	{
		if (MusicTransitionPool.Count() > 0)
		{
			for (int i= 0; i< MaxNumMusicTransitions; i++)
			{
				NSyncMusicTransitionalGroup* TestGroup = &(MusicTransitionPool[i]);
				if (TestGroup == group)
				{
					TestGroup->SetToBeDeleted ();
					break;
				}
			}				
		}
	}

	//---------------------------------------------------------------------
	int		AudioSystem::FindValidEventIDsFromListOfEventIDs (int* ValidEventIds, int* FMODEventIDs, int* SourceGameEventIDs, int NumIndices)// returns number found
	{
		int NumberFound = 0;
		for (int i=0; i<NumIndices; i++)
		{
			// in the case of music transitions, we'll only have one piece of audio per event.
			int EventId = SourceGameEventIDs[i];

			AudioEventData::AudioBankDataType& BankSetup = GetEventData (EventId).m_BankSetup;
			const char* FModEventName = BankSetup[0].m_FModEventName.AsChar ();

			if (FModEventName != NULL)
			{
				ValidEventIds[NumberFound] = EventId;
				NumberFound++;
			}
		}
		return NumberFound;
	}
	//---------------------------------------------------------------------
	int		AudioSystem::SetupNewTransitionGroup (int* ValidGameIds, int NumIndices)
	{
		int Which = 0;
		for (int i= 0; i< MaxNumMusicTransitions; i++)
		{
			if (MusicTransitionPool[i].NumBanks == 0)// this is an available Transition
			{
				SimpleBankData ArrayOfAudioEvents[MaxMusicTransitionsSequenceLength];
				for (int j=0; j<NumIndices; j++)
				{
					int				Index = ValidGameIds[j];
					AudioEventData& EventData = GetEventData (Index);
					ArrayOfAudioEvents[j] = EventData.m_BankSetup[0];
					EventData.m_NSyncMusicTransitionalGroupId = i;
				}
				MusicTransitionPool[i].Init (FmodEventGroups, ValidGameIds, ArrayOfAudioEvents, NumIndices);
				MusicTransitionPool[i].SetAudioSystem (this);
				Which = i;
				break;
			}			
		}
		return Which;
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::DoesNSyncMusicTransitionGroupAlreadyExist (int* ArrayOfEventIds)
	{
		bool AlreadyEnabledFlag = false;
		if (MusicTransitionPool.Count() > 0)
		{
			for (int i= 0; i< MaxNumMusicTransitions; i++)
			{
				// this pool item already contains values
				if (MusicTransitionPool[i].NumBanks != 0)
				{
					for (int j=0; j<MusicTransitionPool[i].NumBanks; j++)
					{
						if (MusicTransitionPool[i].EventIds[j] == ArrayOfEventIds[0])
						{
							AlreadyEnabledFlag = true;
							break;
						}
					}
				}
				if (AlreadyEnabledFlag == true)
					return true;
			}				
		}
		return false;
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::PlayNSyncMusicTransitionGroup (int EventId)
	{
		if	(mIsReady == false)
		{
			return false;
		}

		if (mStreamsAreEnabled == false)
		{
			return false;
		}

		if (MusicTransitionPool.Count() > 0)
		{
			AudioEventData&		EventData = GetEventData (EventId);
			int Index = EventData.m_NSyncMusicTransitionalGroupId;
			if (Index != -1)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[Index];
				AudioEventData::AudioBankDataType& BankSetup = GetEventData (EventId).m_BankSetup;
				const char* FModEventName = BankSetup[0].m_FModEventName.AsChar ();
				TransitionGroup.PlayStream (FModEventName);

				AudioEventData&			EventData = GetEventData (EventId);	
				float Volume = CalculateVolume (&EventData, &(BankSetup[0]));
				float Pitch = CalculatePitchUtil ((float) 0.0, (float) EventData.m_AudioSettings.m_Pitch);

				if (EventData.m_AudioSettings.m_MuteOn == true)
				{
					Volume = 0;
				}
				TransitionGroup.SetVolume (FModEventName, Volume);
				TransitionGroup.SetPitch (FModEventName, Pitch);
				return true;
			}
		}
		return false;
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::SetNSyncMusicTransitionGroup_Volume (int EventId)
	{
		if	(mIsReady == false)
		{
			return false;
		}

		if (mStreamsAreEnabled == false)
		{
			return false;
		}

		if (MusicTransitionPool.Count() > 0)
		{
			AudioEventData&		EventData = GetEventData (EventId);
			int Index = EventData.m_NSyncMusicTransitionalGroupId;
			if (Index != -1)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[Index];
				AudioEventData::AudioBankDataType& BankSetup = GetEventData (EventId).m_BankSetup;
				const char* FModEventName = BankSetup[0].m_FModEventName.AsChar ();

				float Volume = CalculateVolume (&EventData, &(BankSetup[0]));
				if (EventData.m_AudioSettings.m_MuteOn == true)
				{
					Volume = 0;
				}
				TransitionGroup.SetVolume (FModEventName, Volume);
				return true;
			}
		}
		return false;
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::SetNSyncMusicTransitionGroup_Pitch (int EventId)
	{
		if	(mIsReady == false)
		{
			return false;
		}

		if (mStreamsAreEnabled == false)
		{
			return false;
		}

		if (MusicTransitionPool.Count() > 0)
		{
			AudioEventData&		EventData = GetEventData (EventId);
			int Index = EventData.m_NSyncMusicTransitionalGroupId;
			if (Index != -1)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[Index];	
				AudioEventData::AudioBankDataType &BankSetup = GetEventData (EventId).m_BankSetup;
				const char* FModEventName = BankSetup[0].m_FModEventName.AsChar ();

				float Pitch = CalculatePitchUtil ((float) 0.0, (float) EventData.m_AudioSettings.m_Pitch);
				TransitionGroup.SetPitch (FModEventName, Pitch);
				return true;
			}
		}

		return false;
	}
	//---------------------------------------------------------------------
	bool	AudioSystem::StopNSyncMusicTransitionGroup (int EventId)
	{
		if	(mIsReady == false)
		{
			return false;
		}

		if (mStreamsAreEnabled == false)
		{
			return false;
		}

		if (MusicTransitionPool.Count() > 0)
		{
			AudioEventData EventData = GetEventData (EventId);
			int Index = EventData.m_NSyncMusicTransitionalGroupId;
			if (Index != -1)
			{
				NSyncMusicTransitionalGroup& TransitionGroup = MusicTransitionPool[Index];
				AudioEventData::AudioBankDataType &BankSetup = EventData.m_BankSetup;
				TransitionGroup.StopStream (BankSetup[0].m_FModEventName.AsChar ());
				return true;
			}
		}
		return false;
	}

	//---------------------------------------------------------------------
	void	AudioSystem::ClearFModEventsIDs ()
	{
		if (mIsReady == false)
			return;
		for (int EventId= 0; EventId< MaxNumEvents; EventId++)
		{
			AudioEventData& EventData = GetEventData (EventId);
			AudioEventData::AudioBankDataType &BankSetup = EventData.m_BankSetup;

			for (int i = 0; i<AudioEventData::MaxBankCount; i++)
			{	
				SimpleBankData* BankData = &(BankSetup[i]);
				BankData->m_FModEventId = -1;
				BankData->m_FModEventName.Clear ();
				BankData->mStreamPointer = InvalidFMODEventPointer ();
			}
			// remove all of the bank listings as well
			EventData.m_NumBanks = 0; 
		}
	}

	//---------------------------------------------------------------------
	void	AudioSystem::ResetTransitionGroups ()
	{
		if (mAudioEvents != NULL)
		{
			mAudioEvents->Init ();
		}
		if (mAudioMixes != NULL)
		{
			mAudioMixes->Init ();
		}
	}
	//---------------------------------------------------------------------

	AudioThatSignalsBackWhenDone :: AudioThatSignalsBackWhenDone (FMOD::EventGroup* group, FMOD::Event* event, const char* EventName, BankParams*	AudioParams) :
																		m_EventGroup (group),
																		m_FModEvent (event),
																		m_FModEventName (EventName),
																		m_BankParams (AudioParams)
	{
		FMOD_RESULT result = event->setCallback (FmodEndAudioCallback, this);
		result = event->start ();
		m_BankParams->m_IsPlaying = true;
		m_BankParams->m_IsSelfDeleting = true;
	}

	FMOD_RESULT F_CALLBACK	AudioThatSignalsBackWhenDone :: FmodEndAudioCallback (FMOD_EVENT *event, FMOD_EVENT_CALLBACKTYPE type, void *param1, void *param2, void *userdata)
	{
		if (//type == FMOD_EVENT_CALLBACKTYPE_SOUNDDEF_END || 
			type == FMOD_EVENT_CALLBACKTYPE_EVENTFINISHED)
		{
			AudioThatSignalsBackWhenDone* Suicidal = (AudioThatSignalsBackWhenDone*) userdata;
			
			AudioSystem::AddToFinishedAudioItemsNeedingDeleteList (Suicidal);
		}
		return FMOD_OK;
	}

	//---------------------------------------------------------------------
	//---------------------------------------------------------------------

	}// namespace Audio
} //namespace AP

#include <kernel/kernel.h>

#include "audio/audio.h"
#include "reflection/script.h"
#include "fmodwii.h"
#include "math/vector3.h"


namespace AP
{
	namespace Audio
	{
		void	AudioSystem::SetupFileSystem ()
		{
			// no impl for Wii
		} 
		  
		void	AudioSystem::UpdateFileStreams ()
		{
			// no impl for Wii
		}
		
		//---------------------------------------------------------------------
		//---------------------------------------------------------------------
	/*	void* F_CALLBACK AudioAlloc(const size_t size, FMOD_MEMORY_TYPE type)
		{

			int heapId = Axiom::Memory::AUDIO_HEAP;

			void* pMem = Axiom::Memory::Alloc(heapId, size, "Default new", 0);
			if(!pMem)
			{
				Axiom::Memory::MemDump();
			}
			AP_FORCEASSERT(NULL != pMem, "[MEM] Out of memory.");
			return pMem;
		}
		//--------------------------------------------------------------------------
		void* F_CALLBACK AudioRealloc(void* ptrToMem, const size_t size, FMOD_MEMORY_TYPE type)
		{
			int heapId = Axiom::Memory::AUDIO_HEAP;
			return AP_REALLOC(heapId, ptrToMem, size);
		}
		//--------------------------------------------------------------------------
		void F_CALLBACK AudioFree(void*ptr, FMOD_MEMORY_TYPE type)
		{
			Axiom::Memory::Free(ptr);
		}*/
		//--------------------------------------------------------------------------
		//---------------------------------------------------------------------

		void AudioSystem::Initialize()
		{
			mIsReady = false;

			// useful for processor assignment on the XBox360
		/*	FMOD_THREAD_PROCESSOR_ASSIGNMENTS m_FMODThreadAssign;
			m_FMODThreadAssign.file = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.mixer = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.nonblocking = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.stream = FMOD_THREAD_CORE2THREAD0;*/

			HeapSize = IN_MB(3) + IN_MB(1)/2;
			// Create a 40 meg memory space for fmod at this point I'm not certain how much memory fmod needs
			int WhichHeap = //Axiom::Memory::RENDER_HEAP;
					Axiom::Memory::AUDIO_HEAP;
			mMemBuffer = AP_NEW(WhichHeap, Axiom::UInt8[HeapSize]);
			ClearMemBuffer ();

			/*FMOD_RESULT           result;
			result = FMOD::Memory_Initialize(mMemBuffer, HeapSize, 0, 0, 0);
			AP_ASSERTMESSAGE(result == FMOD_OK,"FDesigner memory init failed!!");*/

			InitAudioEventList ();
			InitAudioEventGroupList ();
			InitAudioMixList ();
			InitVolumeSetByGame ();
			ClearFModEventsIDs ();	
			
			FMODInit();
			AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(this), "Audio Editor");
			FMODLoad();
		}

		void	AudioSystem::ClearMemBuffer ()
		{
			memset (mMemBuffer, 0, HeapSize);
		}

		Axiom::UInt32			AudioSystem::GetMemoryWatermark () const
		{
			int x = HeapSize / sizeof (Axiom::UInt64);
			Axiom::UInt64* ptr = (Axiom::UInt64*) mMemBuffer;
			for (int i=x-1; i>0; i--)
			{
				if (ptr [i] != 0)
				{
					return i * sizeof (Axiom::UInt64);
				}
			}
			return 0;
		}
		//---------------------------------------------------------------------
		//---------------------------------------------------------------------
	}// namespace Audio
} //namespace AP

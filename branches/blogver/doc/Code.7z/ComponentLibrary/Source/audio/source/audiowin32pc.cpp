
#include "kernel/kernel.h"
#include "reflection/script.h"
#include "audio/audio.h"
#include "core/core.h"
#include <fmod.hpp>
#include <fmod_errors.h>
//#include <direct.h>

#include "math/vector2.h"
#include "math/vector3.h"


namespace AP
{
	namespace Audio
	{
#if CORE_WIN32 == CORE_YES
#define MICKEY_DEMO_HACK
#endif
	void	AudioSystem::SetupFileSystem ()
	{
		// no impl for windows
	}
	void	AudioSystem::UpdateFileStreams ()
	{
	}

	//------------------------------------------------------------------------------------------
	void AudioSystem::Initialize()
	{
		mIsReady				= false;

		/* Create a 40 meg memory space for fmod
		at this point I'm not certain how much memory fmod needs */

		HeapSize = IN_MB(1);
		mMemBuffer = AP_NEW(Axiom::Memory::AUDIO_HEAP, Axiom::UInt8[HeapSize]);
		ClearMemBuffer ();
#ifndef MICKEY_DEMO_HACK
		//FMOD::Memory_Initialize(mMemBuffer, HeapSize, NULL, NULL, NULL); //NULLs are callback hooks not needed right now
#endif

		InitAudioEventList ();
		InitAudioEventGroupList ();
		InitAudioMixList ();
		InitVolumeSetByGame ();
		ClearFModEventsIDs ();	

		AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(this), "Audio Editor");
		FMODInit();
		FMODLoad();
	}
	void	AudioSystem::ClearMemBuffer ()
	{
		Axiom::MemorySet (mMemBuffer, 0, HeapSize);
	}

	Axiom::UInt32			AudioSystem::GetMemoryWatermark () const
	{
		int x = HeapSize / sizeof (Axiom::UInt64);
		Axiom::UInt64* ptr = (Axiom::UInt64*) mMemBuffer;
		for (int i=x-1; i>0; i--)
		{
			if (ptr [i] != 0)
			{
				return i * sizeof (Axiom::UInt64);
			}
		}
		return 0;
	}
	//------------------------------------------------------------------------------------------
	}// namespace Audio
} //namespace AP

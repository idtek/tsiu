
#include <core/singleton.h>
#include <core/core.h>
#include <kernel/signal.h>
#include "fmod.hpp"
#include "fmod_event.hpp"
#include "..\audioparams.h"

using namespace AP;
using namespace AP::Audio;

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

AP_TYPE(PlayRange)
	AP_DEFAULT_CREATE()
	AP_FIELD("Low",m_Low,"the minimum value to play")
	AP_FIELD("High",m_High,"the maximum level to play")
AP_TYPE_END()

AP_TYPE(BankParams)
	AP_DEFAULT_CREATE()
	AP_FIELD("Range",m_PlayRange, "the valid excitement range for playing this piece of audio")
	AP_FIELD("Audio_Sample",m_Id,"Which Sample to Play")
	AP_FIELD("Sample_Volume",m_Volume,"Sample Volume")
	AP_FIELD("Delay",m_Delay,"delay")
	AP_FIELD("Pitch",m_Pitch,"Pitch")
	AP_FIELD("BPM",m_BPM,"Beats per minute")
	AP_FIELD("IsPlaying", m_IsPlaying, "is playing")
	AP_FIELD("IsStream",m_IsStream,"is this a stream")
	AP_FIELD("IsStopEvent",m_IsStopEvent,"punch or kick of the ball")
	AP_FIELD("Muted",m_MuteOn,"checking to see if the mute is enabled")
AP_TYPE_END()
 
AP_TYPE(SimpleBankData)		
	AP_FIELD("ID",m_AudioSettings.m_Id,"my ID")
	AP_FIELD("FModBankID",m_FModEventId,"EventID")
	AP_FIELD("FModBankName",m_FModEventName,"Event Name")
	AP_FIELD("AudioEventID",m_AudioEventId,"AudioEventID")
	AP_FIELD("Parameters",m_AudioSettings,"Setup")
	AP_FIELD("Priority",m_Priority,"how high should it be")
AP_TYPE_END()

AP_TYPE(AudioEventData)		
	AP_FIELD("ID",m_Id,"my EventID")	
	AP_FIELD("GroupId",m_GroupId,"Which group ID do we belong to?")
	AP_FIELD("AudioBankList",m_BankSetup,"Parms for each Event Sound")
	AP_FIELD("Count",m_NumBanks,"How Many Sounds in the Event")
	AP_FIELD("Parameters",m_AudioSettings,"Setup")
	AP_FIELD("NSyncMusicTransitionalGroupId", m_NSyncMusicTransitionalGroupId, "Transition group")
AP_TYPE_END()

AP_TYPE(AudioEventGroupData)	
	AP_FIELD("ID",m_Id,"my GroupID")
	AP_FIELD("Distance", m_DistanceScaling, "Change the relative distance of the group (0-1 shorter, 1-inf longer)")
	AP_FIELD("Name",m_Name,"the name identifier for this group")
	AP_FIELD("Volume",m_Volume,"volume")
	AP_FIELD("HighVolumeDisc", m_HighVolumeDisc, "non-attenuating area")
	AP_FIELD("AudioCategory", m_Category, "category for player settings")
AP_TYPE_END()

AP_TYPE(AudioMixArrangementData)
	AP_DEFAULT_CREATE()
	AP_FIELD("Volume",MixPerGroup,"Volume level per group ID")
	AP_FIELD("RampTime",RampTimePerGroup,"How long to transition to the new level")
	AP_COMMAND(GetNumMixes, "Return the number of available mixes")
AP_TYPE_END()

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

PlayRange :: PlayRange (): 
								m_Low (0), 
								m_High (100)
{
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

BankParams::BankParams ():
	m_Id (BadValue),
	m_Delay (0),
	m_Pitch (CenterPitch),						
	m_Volume (MaxVolume),	
	m_BPM (0),
	m_IsPlaying (false),
	m_IsStream (false),
	m_IsStopEvent (false),
	m_IsSelfDeleting (false),
	m_IsLoaded (false),
	m_MuteOn (false)
{}

const bool BankParams :: operator ==(const BankParams& rhs) const
{ 
	return	m_Id == rhs.m_Id &&
			m_Delay == rhs.m_Delay &&
			m_Pitch == rhs.m_Pitch &&
			m_Volume == rhs.m_Volume &&
			m_BPM == rhs.m_BPM &&	
			m_IsStream == rhs.m_IsStream &&
			m_IsStopEvent == rhs.m_IsStopEvent &&
			m_IsSelfDeleting == rhs.m_IsSelfDeleting;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

PlayBankParams :: PlayBankParams():
	m_id(-1),
	m_volume(0),
	m_positionX(0),
	m_positionY(0),
	m_positionZ(0),
	m_distance(0),
	m_pitch(0),
	m_impactvelocity(0),
	m_delay(0)
{ }

//-----------------------------------
const bool PlayBankParams :: operator ==(const PlayBankParams& rhs) const
{ 
	return	m_id == rhs.m_id &&
			m_volume == rhs.m_volume &&
			m_positionX == rhs.m_positionX &&
			m_positionY == rhs.m_positionY &&
			m_positionZ == rhs.m_positionZ &&
			m_distance == rhs.m_distance &&
			m_pitch == rhs.m_pitch &&
			m_impactvelocity == rhs.m_impactvelocity &&
			m_delay == rhs.m_delay;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

SimpleBankData :: SimpleBankData () :
	m_AudioSettings (),
	m_FModEventId (-1),
	m_AudioEventId (0),
	mStreamPointer ((FMOD::Event*)0xFFFFFFFF),
	m_Priority (0)
{ }

//-----------------------------------
const bool SimpleBankData :: operator ==(const SimpleBankData& rhs) const
{
	return  m_FModEventId == m_FModEventId &&
			m_AudioEventId == rhs.m_AudioEventId &&
			m_AudioSettings == rhs.m_AudioSettings;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

AudioEventData :: AudioEventData():
					m_BankSetup (),// technically, these will be attached to FMOD events.
					m_AudioSettings (),
					m_Id (-1),
					m_GroupId (-1), 
					m_NumBanks (0),							
					m_NSyncMusicTransitionalGroupId (-1)
{		
	m_BankSetup.Clear ();
}
					
//-----------------------------------

int		AudioEventData :: Count () 
{
	return m_BankSetup.Count ();
}		

//-----------------------------------

const bool AudioEventData :: operator ==(const AudioEventData& rhs) const
{
	return  m_Id == rhs.m_Id &&
			m_GroupId == rhs.m_GroupId && 
			m_AudioSettings == m_AudioSettings &&
			m_NumBanks == rhs.m_NumBanks &&					
			m_BankSetup == rhs.m_BankSetup &&
			m_NSyncMusicTransitionalGroupId == rhs.m_NSyncMusicTransitionalGroupId;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

AudioEventGroupData :: AudioEventGroupData ():
						m_Category (AP::Events::EAudioBroadCategory::SoundFX),
						m_DistanceScaling (1.0F),
						m_HighVolumeDisc (0.0F),
						m_Id (-1),
						m_Volume (0)
{
}

//-----------------------------------

const bool AudioEventGroupData :: operator ==(const AudioEventGroupData& rhs) const
{
	return  m_Id == rhs.m_Id &&
			m_Name == m_Name;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

AudioMixCurrentValue :: AudioMixCurrentValue () : IsRamping (false)
{
	CurrentMixValue.Clear ();
	DestinationValue.Clear ();
	RampValuePerMillisecond.Clear ();
	for (int i=0; i<AudioMixArrangementData::MaxNumGroups; i++)
	{
		CurrentMixValue.Add (0);
		DestinationValue.Add (0);
		RampValuePerMillisecond.Add (1);
	}
}

//-----------------------------------

void	AudioMixCurrentValue :: Setup (Axiom::Collections::StaticList<Axiom::UInt8,AudioMixArrangementData::MaxNumGroups>& Mix)
{
	IsRamping = false;
	CurrentMixValue.Clear ();
	for (int i=0; i<AudioMixArrangementData::MaxNumGroups; i++)
	{
		CurrentMixValue.Add (Mix[i]);
	}
}

//-----------------------------------

void	AudioMixCurrentValue :: Setup (Axiom::Collections::StaticList<Axiom::UInt8,AudioMixArrangementData::MaxNumGroups>& MixChange,
				Axiom::Collections::StaticList<Axiom::Float,AudioMixArrangementData::MaxNumGroups>& RampTimes)
{
	IsRamping = true;
	DestinationValue.Clear ();
	RampValuePerMillisecond.Clear ();
	for (int i=0; i<AudioMixArrangementData::MaxNumGroups; i++)
	{
		DestinationValue.Add (MixChange[i]);
	}
	for (int i=0; i<AudioMixArrangementData::MaxNumGroups; i++)
	{
		float Distance = DestinationValue[i] - CurrentMixValue[i];
		float Time = RampTimes[i];
		if (Time == 0.0)// error correction
		{
			Time = 1.0;// this will ramp almost instantly
		}
		float DistanceOverTime = Distance/Time;
		RampValuePerMillisecond.Add (DistanceOverTime);
	}
}

//-----------------------------------

Axiom::UInt8 AudioMixCurrentValue :: GetCurrentValue (int index)
{
	int CurrentValue = 196;
	for (int i=0; i<AudioMixArrangementData::MaxNumGroups; i++)
	{
		int Value = static_cast <Axiom::UInt8> (CurrentMixValue[i]);
		if (i == index)
		{
			CurrentValue = Value;
		}
		
	}
	
	return static_cast <Axiom::UInt8> (CurrentValue);
	//return 190;
}

//-----------------------------------

bool	AudioMixCurrentValue :: Update (int TimePassedInMilliseconds)
{
	if (IsRamping)
	{
		int NumItems = static_cast <int> (CurrentMixValue.Count ());
		if (DestinationValue.Count () == 0)
		{
			IsRamping = false;
			return IsRamping;
		}
		int NumItemsAlreadyAtTargetValue = 0;
		for (int i=0; i<NumItems; i++)
		{
			// assuming that the ramp value is less than 1.
			float Mixvalue = CurrentMixValue[i];
			float Destvalue = DestinationValue[i];
			float Rampvalue = RampValuePerMillisecond[i] * TimePassedInMilliseconds;
			if (Rampvalue == 0.0F)
			{
				if (Mixvalue + Rampvalue == Destvalue)
				{
					Reset (i, Destvalue);
					Rampvalue = 0.0;
					NumItemsAlreadyAtTargetValue ++;
				}
			}
			else if (Rampvalue < 0)
			{
				if (Mixvalue + Rampvalue < Destvalue)
				{
					Reset (i, Destvalue);
					Rampvalue = 0.0;
					NumItemsAlreadyAtTargetValue ++;
				}
			}
			else
			{
				if (Mixvalue + Rampvalue > Destvalue)
				{
					Reset (i, Destvalue);
					Rampvalue = 0.0;
					NumItemsAlreadyAtTargetValue ++;
				}
			}
			CurrentMixValue[i] += Rampvalue;
		}
		if (NumItemsAlreadyAtTargetValue == NumItems)
		{
			IsRamping = false;
		}
	}
	return IsRamping;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



#include "audio/audio.h"
#include "..\SignaledAudio.h"

namespace AP
{
	namespace Audio
	{
//----------------------------------------------------
FMOD_RESULT F_CALLBACK FmodEndAudioPlayCallback(FMOD_EVENT *event, FMOD_EVENT_CALLBACKTYPE type, void *param1, void *param2, void *userdata)
{
	SignaledAudio* AudioEvent = (SignaledAudio*) userdata;
	if (AudioEvent == NULL)
		return FMOD_OK;

	if (AudioEvent->GetType() == SignaledAudio::SignalBackAtEnd &&
			type == FMOD_EVENT_CALLBACKTYPE_SOUNDDEF_END)
	{
		//printf("FMOD Event finished \n");
		AudioEvent->SetSignal ();
	}

	if (AudioEvent->GetType() == SignaledAudio::SignalBackAtStart &&
		type == FMOD_EVENT_CALLBACKTYPE_SOUNDDEF_START)
	{
		printf("FMOD Event begun \n");
		AudioEvent->SetSignal ();
	}

    return FMOD_OK;
}

//----------------------------------------------------

SignaledAudio :: SignaledAudio () : 
					Type (SignalBackAtEnd),
					IsEnabledFlag (false), 
					HasSignaledFlag (false), 
					IsAwaitingCallbackFlag (false),
					SignalId (0), 
					EventId (0)
{
}

SignaledAudio :: ~SignaledAudio ()
{
	AP_ASSERT (IsEnabledFlag == false);
}
//----------------------------------------------------

void	SignaledAudio :: Clear ()
{
	Type = SignalBackAtEnd,
	IsEnabledFlag = false, 
	HasSignaledFlag = false, 
	IsAwaitingCallbackFlag = false,
	SignalId = 0, 
	EventId = 0, 
	Signaller = NULL;
}

//----------------------------------------------------

void	SignaledAudio :: PlaySound (SignalType type, 
						FMOD::EventGroup*eventgroup, FMOD::Event* AudioEvent, int eventId, int signalId, 
								Axiom::Collections::DynamicList <Audio::SignalledAudioWhenReady*>* signaller, 
								const Audio::PlayBankParams& Params)
{
	AP_ASSERT (IsEnabledFlag == false);

	IsEnabledFlag = true;
	HasSignaledFlag = false;
	IsAwaitingCallbackFlag = false;
	//FModEventId = fmod_eventId;
	EventId = eventId;
	FmodAudioEvent = AudioEvent;
	SignalId = signalId;
	PlayParams = Params;
	EventGroup = eventgroup;

	Type = type;
	Signaller = signaller;

	if (FmodAudioEvent== AudioSystem::InvalidFMODEventPointer ())
	{
		SetSignal ();
		return;
	}
	float TestPitch = 0.0;// we are testing the pointer
	FMOD_RESULT result = FmodAudioEvent->getPitch (&TestPitch);
	if (result != FMOD_OK)
	{
		SetSignal ();
		return;
	}

	result = FmodAudioEvent->setVolume (Params.m_volume);

	FMOD_VECTOR			tempvec;
	tempvec.x = Params.m_positionX;
	tempvec.y = Params.m_positionX;
	tempvec.z = Params.m_positionX;
	result = FmodAudioEvent->set3DAttributes(&tempvec,0,0);	
	//ERRCHECK(result);
}

//----------------------------------------------------

void	SignaledAudio :: Update ()
{
	if (IsEnabledFlag)
	{
		if (PlayParams.m_delay > 0)
		{
			PlayParams.m_delay--;
			return;
		}

		if (Type == SignaledAudio::SignalBackAtStart)
		{
			IsAwaitingCallbackFlag = true;
			FMOD_EVENT_STATE		eventState;
			FmodAudioEvent->getState (&eventState);
			if (eventState == FMOD_EVENT_STATE_READY)
			{
				SetSignal ();
				IsAwaitingCallbackFlag = false;

				FmodAudioEvent->start ();
				//ERRCHECK(result);
			}
		}
		else if (IsAwaitingCallbackFlag == false)// signaled back at end
		{
			IsAwaitingCallbackFlag = true;

			FMOD_RESULT result = FmodAudioEvent->setCallback (FmodEndAudioPlayCallback, this);

			result = FmodAudioEvent->start ();
		}
	}
	/*if (IsEnabledFlag && IsAwaitingCallbackFlag == false)
	{
		if (PlayParams.m_delay > 0)
		{
			PlayParams.m_delay--;
			return;
		}
	
		IsAwaitingCallbackFlag = true;

		FMOD::Event* FmodAudioEvent;
		FMOD_RESULT result = EventGroup->getEventByIndex(FModEventId, 0, &FmodAudioEvent);
		if (result != FMOD_OK)
		{
			SetSignal ();
		}
		result = FmodAudioEvent->setCallback (FmodEndAudioPlayCallback, this);

		result = FmodAudioEvent->start ();
		//ERRCHECK(result);
	}*/

	if (HasSignaledFlag == true)
	{
		if (Signaller != NULL)
		{
			int NumItems = Signaller->Count ();
			for (int i=0; i<NumItems; i++)
			{
				Audio::SignalledAudioWhenReady* Signal = Signaller->Item (i);
				if (Type == SignalBackAtStart)
					Signal->AudioStarted (EventId, SignalId);
				else
					Signal->AudioEnded (EventId, SignalId);
			}

			// no more signalling
			Signaller = NULL;
		}
	}
}

void	SignaledAudio :: Mute (int eventId)
{
	if (eventId == EventId)
	{
	}
}

void	SignaledAudio :: Unmute (int eventId)
{
	if (eventId == EventId)
	{
	}
}
//----------------------------------------------------

bool	SignaledAudio :: IsAvailable ()
{
	if (IsEnabledFlag)
		return false;
	return true;
}

void	SignaledAudio :: SetAvailable ()
{
	IsEnabledFlag = false;
}

//----------------------------------------------------

//----------------------------------------------------

void	SignaledAudio :: SetSignal ()
{
	HasSignaledFlag = true;
}

//----------------------------------------------------
}// namespace Audio
}// namespace AP


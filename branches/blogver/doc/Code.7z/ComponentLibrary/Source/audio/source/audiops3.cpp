#include <kernel/kernel.h>
#include "audio/audio.h"
#include "jobmanager/jobmanager.h"
#include "reflection/script.h"
#include <math/apmath.h>
#include "fmod.hpp"
#include "math/vector3.h"
#include "..\Graphics\Graphics\ps3\spumanager.h"
#include <cell/cell_fs.h>

#define SPU_PROGRAM         "/app_home/fmodex_spu.self"
#define SPU_PROGRAM_MPEG    "/app_home/fmodex_spu_mpeg.self"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern unsigned long _binary_fmodex_spurs_elf_start[];
extern unsigned long _binary_fmodex_spurs_mpeg_elf_start[];

#ifdef __cplusplus
}
#endif /* __cplusplus */

using namespace Axiom;

namespace AP
{
	namespace Audio
	{
	//--------------------------------------------------------------
	struct FileMap
	{
		enum {BufferSize = IN_KB(128) };
		Axiom::ShortString	Filename;
		int					TotalFileSize;
		void*				FileHandle;
		int					NumBytesValidInBuffer;
		int					CurrentBufferReadPosition;
		int					CurrentFileReadPosition;
		char*				Buffer;
		bool				IsInUse;

		FileMap () : TotalFileSize (0), 
						FileHandle (0), 
						NumBytesValidInBuffer (0),
						CurrentBufferReadPosition (0),
						CurrentFileReadPosition (0),
						Buffer (NULL),
						IsInUse (false)
		{
			Buffer = AP_NEW(Axiom::Memory::AUDIO_HEAP, Axiom::Int8[BufferSize]);// 20K
		}
		~FileMap ()
		{
			delete [] Buffer;
		}
	};

	//-------------------------------------------------
	//-------------------------------------------------

	const int NumFileMapItems= 12;
	Axiom::Collections::StaticList <FileMap*, NumFileMapItems> ListOfOpenFiles;
	int		NumOpened = 0, NumClosed = 0;

	//-------------------------------------------------
	//-------------------------------------------------

	FileMap* NewFile ()
	{
		int NumItems = ListOfOpenFiles.Count ();
		for (int i=0; i<NumItems; i++)
		{
			FileMap* ptr = ListOfOpenFiles[i];
			if (ptr->IsInUse == false)
			{
				ptr->IsInUse = true;
				ptr->NumBytesValidInBuffer = 0;
				ptr->CurrentBufferReadPosition = 0;
				ptr->TotalFileSize = 0;
				return ptr;
			}
		}
		return NULL;
	}
	FileMap* FindFile (void* filehandle)
	{
		FileMap* ReturnMap = NULL;
		int NumItems = ListOfOpenFiles.Count ();
		for (int i=0; i<NumItems; i++)
		{
			FileMap* ptr = ListOfOpenFiles[i];
			if (ptr->FileHandle == filehandle)
			{
				ReturnMap = ptr;
				break;
			}
		}
		return ReturnMap;
	}

	void	DeleteFile (FileMap* Map)
	{
		if (Map == NULL)
			return;
		Map->IsInUse = false;
	}

	//----------------------------------------------------------------------
	//----------------------------------------------------------------------

	FMOD_RESULT F_CALLBACK FMOD_FileOpenCallback(const char *filename, int unicode, unsigned int *filesize, void **filehandle, void **userdata)
	{
		int fileDescriptor = 0;
		CellFsErrno error = ::cellFsOpen(filename, CELL_FS_O_RDONLY, &fileDescriptor, 0, 0);
		NumOpened++;

		AP_ASSERT(error == CELL_FS_SUCCEEDED);
		CellFsStat fsStat;
		Axiom::MemorySet(&fsStat, 0, sizeof(CellFsStat));
		error = cellFsFstat(fileDescriptor, &fsStat);

		// save off new data
		*filesize = static_cast<int>(fsStat.st_size);
		AP_ASSERT (*filesize > 0);
		*filehandle = reinterpret_cast<void*>(fileDescriptor);

		if (AudioSystem::mIsRequestedFileAStream)
		{
			FileMap* Mapping = NewFile ();
			AP_ASSERT (Mapping != NULL);

			Mapping->TotalFileSize = *filesize;
			Mapping->FileHandle = *filehandle;
			Mapping->Filename = filename;

			// make sure that we have this tracking data available
			*userdata = Mapping;
			// immediately clear this flag.
			AudioSystem::mIsRequestedFileAStream = false;
		}
		else
		{
			*userdata = NULL;
		}
		
		return FMOD_OK;
	}

	//----------------------------------------------------------------------
	FMOD_RESULT F_CALLBACK FMOD_FileCloseCallback(void *filehandle, void *userdata)
	{
		CellFsErrno error = ::cellFsClose(reinterpret_cast<int>(filehandle));
		AP_ASSERT(error == CELL_FS_SUCCEEDED);

		NumClosed ++;
		if (userdata != NULL)
		{
			FileMap* Mapping = FindFile (filehandle);			
			DeleteFile (Mapping);
		}
		
		return FMOD_OK;
	}
	//----------------------------------------------------------------------
	FMOD_RESULT F_CALLBACK FMOD_FileReadCallback     (void *filehandle, void *buffer, unsigned int sizebytes, unsigned int *bytesread, void *userdata)
	{
		uint64_t bytesRead = 0;
		uint64_t bytesRequested = FileMap::BufferSize;
		if (userdata != NULL)
		{
			FileMap* Mapping = FindFile (filehandle);

			if (Mapping != NULL)
			{
				if (Mapping->CurrentBufferReadPosition == 0)// we are assuming that the user will always request something smaller than our buffersize.
				{
					Log( "Audio", "reading %d from %s", sizebytes, Mapping->Filename.AsChar() );
					
					CellFsErrno error = ::cellFsRead(reinterpret_cast<int>(Mapping->FileHandle), Mapping->Buffer, bytesRequested, &bytesRead);
					if (error != CELL_FS_SUCCEEDED)
					{
						AP_ASSERTMESSAGE(error == CELL_FS_SUCCEEDED, "File failed to read %s\n", Mapping->Filename.AsChar() );
					}

					Mapping->NumBytesValidInBuffer = bytesRead;

					Log( "Audio", "done reading %d from %s", sizebytes, Mapping->Filename.AsChar() );

					//Mapping->NumBytesValidInBuffer = (int) fread (Mapping->Buffer, 1, FileMap::BufferSize, (FILE*)Mapping->FileHandle);
				}
				if (Mapping->NumBytesValidInBuffer == 0)// no more data left in bank
				{
					return FMOD_ERR_FILE_EOF;
				}
				int SizeToReturn = Mapping->NumBytesValidInBuffer;
				if (SizeToReturn > (int) sizebytes)
					SizeToReturn = sizebytes;

				Axiom::MemoryCopy (buffer, &(Mapping->Buffer[Mapping->CurrentBufferReadPosition]), SizeToReturn);
				Mapping->CurrentBufferReadPosition += SizeToReturn;	
				Mapping->CurrentFileReadPosition += SizeToReturn;
				Mapping->NumBytesValidInBuffer -= SizeToReturn;
				if (Mapping->NumBytesValidInBuffer <=0)
				{
					Mapping->CurrentBufferReadPosition = 0;
				}
				*bytesread = SizeToReturn;
			}
		}
		else
		{
			bytesRequested = sizebytes;
			CellFsErrno error = ::cellFsRead(reinterpret_cast<int>(filehandle), buffer, bytesRequested, &bytesRead);
			if (error != CELL_FS_SUCCEEDED)
			{
				AP_ASSERTMESSAGE(error == CELL_FS_SUCCEEDED, "File failed to read\n");
			}

			*bytesread = bytesRead;
			if (bytesRead == 0)
			{
				return FMOD_ERR_FILE_EOF;
			}
		}

		return FMOD_OK;
	}
	//----------------------------------------------------------------------
	FMOD_RESULT F_CALLBACK FMOD_FileSeekCallback     (void *filehandle, unsigned int offset, void *userdata)
	{
		uint64_t position = 0;
		CellFsErrno error = ::cellFsLseek(reinterpret_cast<int>(filehandle), offset, CELL_FS_SEEK_SET, &position);
		AP_ASSERT(error == CELL_FS_SUCCEEDED);

		if (userdata != NULL)
		{
			FileMap* Mapping = (FileMap* ) userdata;
			Mapping->CurrentBufferReadPosition = 0;
			Mapping->NumBytesValidInBuffer = 0;
			Mapping->CurrentFileReadPosition = position;
		}

		return FMOD_OK;
	}
	//----------------------------------------------------------------------

	void AudioSystem::SetupFileSystem ()
	{
		int FMOD_Blockalign = -1;// use the default setting here
		FMOD::System * System;
		FmodEventSystem->getSystemObject (&System);

		for (int i=0; i<NumFileMapItems; i++)
		{
			FileMap* ptr = AP_NEW (Axiom::Memory::AUDIO_HEAP, FileMap ());
			ListOfOpenFiles.Add  (ptr);
		}
		
		(System)->setFileSystem (FMOD_FileOpenCallback, FMOD_FileCloseCallback, FMOD_FileReadCallback, FMOD_FileSeekCallback, FMOD_Blockalign);
	}

	//----------------------------------------------------------------------
	void	AudioSystem::UpdateFileStreams ()
	{
	}

	//----------------------------------------------------------------------
	void AudioSystem::Initialize()
	{
		mIsReady						= false; 

		Axiom::MemorySet(&ps3DriverData, 0, sizeof(FMOD_PS3_EXTRADRIVERDATA));
		CellSpurs* Spurs = Graphics::SPUManager::GetSpurs ();
		//----------------------------------
		Axiom::MemorySet(&ps3DriverData, 0, sizeof(FMOD_PS3_EXTRADRIVERDATA));

		ps3DriverData.spurs                               = Spurs;                                
		ps3DriverData.spu_mixer_elfname_or_spursdata      = _binary_fmodex_spurs_elf_start;      
		ps3DriverData.spu_streamer_elfname_or_spursdata   = _binary_fmodex_spurs_mpeg_elf_start;  
		ps3DriverData.spu_priority_mixer                  = 0;  
		ps3DriverData.spu_priority_streamer               = 0;
		ps3DriverData.spu_priority_at3                    = 500;                                 

		ps3DriverData.force5point1                        = 0; 
		ps3DriverData.attenuateDDLFE                      = 0; 

		HeapSize = IN_MB(32);
		mMemBuffer = AP_NEW(Axiom::Memory::AUDIO_HEAP, Axiom::UInt8[HeapSize]);
		ClearMemBuffer ();

		// ps3 is completely disabled in audio until we resolve the file system issues.
#if 1
		/*FMOD_RESULT           result;
		result = FMOD::Memory_Initialize(mMemBuffer, HeapSize, 0, 0, 0);
		AP_ASSERTMESSAGE(result == FMOD_OK,"FDesigner memory init failed!!");*/

		InitAudioEventList ();
		InitAudioEventGroupList ();
		InitAudioMixList ();
		InitVolumeSetByGame ();
		ClearFModEventsIDs ();	

		FMODInit();

		AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(this), "Audio Editor");
		SetupFileSystem ();
		FMODLoad();
#endif
		//SetupFileSystem ();
	}

	void	AudioSystem::ClearMemBuffer ()
	{
		Axiom::MemorySet (mMemBuffer, 0, HeapSize);
	}

	Axiom::UInt32			AudioSystem::GetMemoryWatermark () const
	{
		int x = HeapSize / sizeof (Axiom::UInt64);
		Axiom::UInt64* ptr = (Axiom::UInt64*) mMemBuffer;
		for (int i=x-1; i>0; i--)
		{
			if (ptr [i] != 0)
			{
				return i * sizeof (Axiom::UInt64);
			}
		}
		return 0;
	}
	//---------------------------------------------------------------------

	//---------------------------------------------------------------------
	}// namespace Audio
} //namspace AP

#include <core/core.h>
#include <kernel/signal.h>
#include "fmod_event.hpp"
//#include <audio/audioparams.h>
#include "..\NSyncMusicTransitionalGroup.h"
#include <audio/audio.h>

static const char* LOGGING_CHANNEL	= "AudioPlaying";
using namespace AP;
using namespace AP::Audio;

//----------------------------------------------------
FMOD_RESULT F_CALLBACK FmodSyncPointCallback(FMOD_EVENT *event, FMOD_EVENT_CALLBACKTYPE type, void *param1, void *param2, void *userdata)
{
	NSyncMusicTransitionalGroup*	AudioGroup = reinterpret_cast<NSyncMusicTransitionalGroup*>(userdata);
    if (type == FMOD_EVENT_CALLBACKTYPE_SYNCPOINT)
	{
		//Axiom::Log(LOGGING_CHANNEL, "NSync: Sync point hit");	
		if (AudioGroup->IsPrepedForTransitionToAnotherStream ())
		{
			AudioGroup->SyncPointWasHit ();
			//Axiom::Log(LOGGING_CHANNEL, "NSync: Sync point hit waiting for transition");	
		}
	}
	if (type == FMOD_EVENT_CALLBACKTYPE_SOUNDDEF_END || type == FMOD_EVENT_CALLBACKTYPE_EVENTFINISHED)
	{
		//Axiom::Log(LOGGING_CHANNEL, "NSync: end of audio");	
		if (AudioGroup->IsPrepedForEndingAllAudio ())
		{
			AudioGroup->AudioWasEnded ();
			//Axiom::Log(LOGGING_CHANNEL, "NSync: end of audio while preped for it");
		}

	}

    return FMOD_OK;
}

//--------------------------------------------------------------

NSyncMusicTransitionalGroup :: NSyncMusicTransitionalGroup () : 
						eventgroup (NULL), 
						AwaitingTransitionFlag (false),
						IsTransitioningFlag (false),
						IsSyncPointSignalledFlag (false),
						CurrentlyPlayingIndex (-1), 
						TransitionToIndex(-1),
						IsSetupToStopAllAudioFlag (false),
						IsSetupToBeDeleted (false),
						MainAudio (NULL),
						AudioBanks (NULL)
{
	CurrentlyPlayingEvent = AudioSystem::InvalidFMODEventPointer ();
	TransitionToEvent = AudioSystem::InvalidFMODEventPointer ();
	Clear ();
}
						
//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: Clear ()
{
	NumBanks = 0;
	/*for (int i=0; i<NumBanks; i++)
	{
		EventIds[i] = -1;
	}*/
	if (CurrentlyPlayingEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, CurrentlyPlayingEvent->stop());
		eventgroup->freeEventData (CurrentlyPlayingEvent);
		AP_ASSERT(result == FMOD_OK);	
	}
	if (TransitionToEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, TransitionToEvent->stop());
		eventgroup->freeEventData (TransitionToEvent);
		AP_ASSERT(result == FMOD_OK);	
	}
	CurrentlyPlayingEvent = AudioSystem::InvalidFMODEventPointer ();
	TransitionToEvent = AudioSystem::InvalidFMODEventPointer ();

	if (AudioBanks != NULL)
	{
		AP_DELETEARRAY (AudioBanks);
		AudioBanks = NULL;
	}
	IsSetupToBeDeleted = false;
}

//--------------------------------------------------------------
//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: Init (FMOD::EventGroup*group, int* indices, SimpleBankData* BankData, int NumIndices)
{
	eventgroup  = group, 
	NumBanks = NumIndices, 
	AwaitingTransitionFlag = false,
	IsTransitioningFlag = false,
	IsSyncPointSignalledFlag = false,
	CurrentlyPlayingIndex = -1, 
	TransitionToIndex = -1;

	for (int i=0; i<NumIndices; i++)
	{
		int Index = indices[i];
		EventIds[i] = Index;	
	}

	if (AudioBanks != NULL)
	{
		AP_DELETEARRAY (AudioBanks);
	}
	AudioBanks = AP_NEW (Axiom::Memory::AUDIO_HEAP, SimpleBankData[NumBanks]);
	for (int i=0; i<NumBanks; i++)
	{
		AudioBanks[i] = BankData[i];	
	}
}

//--------------------------------------------------------------

FMOD::Event*	NSyncMusicTransitionalGroup :: SetupForPlay (int index)
{
	FMOD::Event* pEvent = GetFMODEvent (index);

	if (pEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, pEvent->setCallback (FmodSyncPointCallback, this));
		AP_ASSERT(result == FMOD_OK);
	}

	return pEvent;
}

//--------------------------------------------------------------

FMOD::Event*	NSyncMusicTransitionalGroup :: GetFMODEvent (int index)
{
	FMOD::Event* pEvent = AudioSystem::InvalidFMODEventPointer ();

	if (MainAudio != NULL)
	{
		if (NumBanks != 0 && AudioBanks != NULL)
		{
			bool ForcePreparation = true;
			MainAudio->PrepareFMODPointer(&AudioBanks[index], ForcePreparation);
			pEvent = AudioBanks[index].mStreamPointer;
		}
	}
	else
	{	
		AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, eventgroup->getEvent (AudioBanks[index].m_FModEventName.AsChar (), 0, &pEvent));
		AP_ASSERT(result == FMOD_OK);
	}
	return pEvent;
}


//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: PlayStream (const char* FModEventName)
{
	int WhichEventIndex = -1;
	for (int i=0; i<NumBanks; i++)
	{
		//if (Which == EventIds[i])
		if (Axiom::StringCompareNoCase (FModEventName, AudioBanks[i].m_FModEventName.AsChar (), 32) == 0)
		{
			WhichEventIndex = i;
			break;
		}
	}
	if (WhichEventIndex == -1)
		return;
	if (AwaitingTransitionFlag == true)// finish one transition before beginning the next
		return;
	if (CurrentlyPlayingIndex == WhichEventIndex)
		return;

	//Axiom::Log(LOGGING_CHANNEL, "NSync: PlayStream");	

	FMOD_RESULT result = FMOD_OK;
	FMOD::Event* pEvent = SetupForPlay (WhichEventIndex);
	// this put here fixes a fundamental flaw. if the user setup a transition group in code but does not hook up the audio
	// in the FDesigner tool, then we may not be able to find the audio.
	if (pEvent == AudioSystem::InvalidFMODEventPointer ())
		return;

	if (CurrentlyPlayingIndex != -1)
	{
		IsTransitioningFlag = true;
		TransitionToEvent = pEvent;

		AwaitingTransitionFlag = true;
		TransitionToIndex = WhichEventIndex;
		IsTransitioningFlag = false;
	}
	else
	{
		CurrentlyPlayingIndex = WhichEventIndex;

		Axiom::Log(LOGGING_CHANNEL, "NSync: starting fresh stream");	
		result = pEvent->start ();
		AP_ASSERT(result == FMOD_OK);
		CurrentlyPlayingEvent = pEvent;
	}
}

void	NSyncMusicTransitionalGroup :: SetVolume (const char* FModEventName, float VolumeLevel)
			
//void	NSyncMusicTransitionalGroup :: SetVolume (int EventId, float VolumeLevel)
{
	int WhichEventIndex = -1;
	for (int i=0; i<NumBanks; i++)
	{
		if (Axiom::StringCompareNoCase (FModEventName, AudioBanks[i].m_FModEventName.AsChar (), 32) == 0)
		{
			WhichEventIndex = i;
			break;
		}
	}
	if (CurrentlyPlayingIndex == WhichEventIndex && 
		CurrentlyPlayingEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		CurrentlyPlayingEvent->setVolume (VolumeLevel);
	}
	if (TransitionToIndex == WhichEventIndex && 
		TransitionToEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		TransitionToEvent->setVolume (VolumeLevel);
	}
}

void	NSyncMusicTransitionalGroup :: SetPitch (const char* FModEventName, float PitchLevel)
{
	int WhichEventIndex = -1;
	for (int i=0; i<NumBanks; i++)
	{
		if (Axiom::StringCompareNoCase (FModEventName, AudioBanks[i].m_FModEventName.AsChar (), 32) == 0)
		{
			WhichEventIndex = i;
			break;
		}
	}
	if (CurrentlyPlayingEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		CurrentlyPlayingEvent->setPitch (PitchLevel, FMOD_EVENT_PITCHUNITS_RAW);
	}
	if (TransitionToEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		TransitionToEvent->setPitch (PitchLevel, FMOD_EVENT_PITCHUNITS_RAW);
	}
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: StopStream (const char* FModEventName)//(int Which)
{
	int WhichEventIndex = -1;
	for (int i=0; i<NumBanks; i++)
	{
		//if (Which == EventIds[i])
		if (Axiom::StringCompareNoCase (FModEventName, AudioBanks[i].m_FModEventName.AsChar (), 32) == 0)
		{
			WhichEventIndex = i;
			break;
		}
	}
	if (WhichEventIndex == -1)
		return;
	if (CurrentlyPlayingIndex != WhichEventIndex)
		return;
	if (IsTransitioningFlag == true)
		return;

	FMOD_RESULT		result;	
	FMOD::Event*	pEvent = GetFMODEvent (WhichEventIndex);
	if (pEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		result = pEvent->stop ();
		eventgroup->freeEventData (pEvent);
		AP_ASSERT(result == FMOD_OK);	
	}

	CurrentlyPlayingIndex = -1;
	CurrentlyPlayingEvent = AudioSystem::InvalidFMODEventPointer ();
	TransitionToEvent = AudioSystem::InvalidFMODEventPointer ();

	IsTransitioningFlag = false;
	AwaitingTransitionFlag = false;
	TransitionToIndex = -1;
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: SyncPointWasHit ()
{
	if (IsTransitioningFlag == true)
		return;

	IsSyncPointSignalledFlag = true;
	Axiom::Log(LOGGING_CHANNEL, "NSync: SyncPointWasHit");
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: AudioWasEnded ()
{
	IsSyncPointSignalledFlag = true;
	Axiom::Log(LOGGING_CHANNEL, "NSync: AudioWasEnded");
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: StopAll ()
{
	for (int i=0; i<NumBanks; i++)
	{
		FMOD::Event* pEvent = GetFMODEvent (i);
		if (pEvent != AudioSystem::InvalidFMODEventPointer ())
		{
			AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, pEvent->stop ());
			eventgroup->freeEventData (pEvent);
			AP_ASSERT(result == FMOD_OK);	
		}
	}
	CurrentlyPlayingIndex = -1;
	IsTransitioningFlag = false;
	AwaitingTransitionFlag = false;
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: PauseAll (bool PauseApply)
{
	if (CurrentlyPlayingEvent != AudioSystem::InvalidFMODEventPointer ())
	{
		CurrentlyPlayingEvent->setPaused (PauseApply);
	}

	/*for (int i=0; i<NumBanks; i++)
	{
		FMOD::Event* pEvent = GetFMODEvent (i);
		if (pEvent != AudioSystem::InvalidFMODEventPointer ())
		{
			FMOD_RESULT result = pEvent->stop ();
			eventgroup->freeEventData (pEvent);
			AP_ASSERT(result == FMOD_OK);	
		}
	}*/
}

//--------------------------------------------------------------

void	NSyncMusicTransitionalGroup :: Update ()
{
	FMOD_RESULT  result = FMOD_OK;

	if (IsSyncPointSignalledFlag == true &&
		AwaitingTransitionFlag == true)
	{
		FMOD_EVENT_STATE		eventState;
		TransitionToEvent->getState (&eventState);
		if ((eventState | FMOD_EVENT_STATE_READY) != FMOD_EVENT_STATE_READY)//FMOD_EVENT_STATE_PLAYING != FMOD_EVENT_STATE_PLAYING)//FMOD_EVENT_STATE_READY)
		{
			return;
		}
		TransitionToEvent->start ();
		//TransitionToEvent->setPaused (true);

		Axiom::Log(LOGGING_CHANNEL, "NSync: update transitioning");
		IsSyncPointSignalledFlag = false;
		AwaitingTransitionFlag = false;
		
		Axiom::Log(LOGGING_CHANNEL, "NSync: stopping old stream");
		// stop the old one now that we have begun the new.
		result = CurrentlyPlayingEvent->stop ();
		eventgroup->freeEventData (CurrentlyPlayingEvent);// free that memory
		AP_ASSERT(result == FMOD_OK);

		Axiom::Log(LOGGING_CHANNEL, "NSync: starting new stream");
		// this pointer cannot become invalid in the short 2-4 second span that is the transition.
		//result = TransitionToEvent->setPaused (false);
		//result = TransitionToEvent->start ();
		//result = TransitionToEvent->setPaused (false);
		AP_ASSERT(result == FMOD_OK);	

		// fix up the pointers.
		CurrentlyPlayingEvent = TransitionToEvent;
		CurrentlyPlayingIndex = TransitionToIndex;

		TransitionToEvent = AudioSystem::InvalidFMODEventPointer ();
		TransitionToIndex = -1;

		// special case where the transition group is about to end.
		if (CurrentlyPlayingIndex == NumBanks-1)
		{
			IsSetupToStopAllAudioFlag = true;
		}
		else
			IsSetupToStopAllAudioFlag = false;
	}
	if (IsSetupToStopAllAudioFlag == true && 
		IsSyncPointSignalledFlag == true)
	{
		//Axiom::Log(LOGGING_CHANNEL, "NSync: transitioning to fadeout");	

		IsSetupToStopAllAudioFlag = false;
		result = CurrentlyPlayingEvent->stop ();
		eventgroup->freeEventData (CurrentlyPlayingEvent);// free that memory
		//AP_ASSERT(result == FMOD_OK);	

		CurrentlyPlayingEvent = AudioSystem::InvalidFMODEventPointer ();
		CurrentlyPlayingIndex = -1;
		TransitionToIndex = -1;
		AwaitingTransitionFlag = false;
	}
}

//--------------------------------------------------------------

bool	NSyncMusicTransitionalGroup :: IsReadyToBeDeleted ()
{
	if (IsSetupToBeDeleted == true &&
		CurrentlyPlayingEvent == AudioSystem::InvalidFMODEventPointer () &&
		CurrentlyPlayingIndex == -1 && 
		TransitionToIndex == -1)
		return true;

	return false;
}

//--------------------------------------------------------------
//--------------------------------------------------------------

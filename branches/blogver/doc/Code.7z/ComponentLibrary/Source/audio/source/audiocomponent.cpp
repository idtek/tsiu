#include "audio/audioeventmessages.h"
#include "audio/audio.h"
#include "audio/audiocomponent.h"
#include "kernel/component.h"
#include "core/allocator.h"
#include "collections/list.h"

namespace AP
{
	static Axiom::Timer			sTimer;
	static Axiom::Int32			sLastTimeInMS;
	static bool					sIsTimerStarted = false;

#ifdef EVENT_TIMING_ON
	static const char* LOGGING_CHANNEL = "AudioPlaying";
#endif

	Audio::AudioComponent::AudioComponent(Axiom::ConstStr name, AP::Kernel* kernel) : 
																Component(name,kernel),
                                                                m_pAudioSystem(NULL), 
																m_bPause(false), 
																m_CameraX(0.0f), 
																m_CameraY(0.0f), 
																m_CameraZ(0.0f),
																m_UnitTestType (Events::EAudioTestType::AudioClearUnitTest),
																m_UnitTestEventId (-1),
																m_UnitTestCurrentCountBetweeenRepeats (0),
																m_UnitTestDelayBetweenRepeats (0),
																m_ComponentMsgBox( NULL )
																{}

	Audio::AudioComponent::~AudioComponent() {}

	void		Audio::AudioComponent::OnInit()
	{
		m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Audio");
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioPlaySoundEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioStopSoundEvent::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioPlaySoundBank::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioStopSoundBank::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioPlaySoundExpectingReply::EVENT_GUID);

		//m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioReplyToPlaySound::EVENT_GUID);// This is sender of the event, not a receiver.

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioUpdateCameraBody::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioExecuteCommands::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioStop::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetMasterVolume::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetRolloff::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetDistanceScaling::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetEventVolume::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetEventPitch::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetMixEvent::EVENT_GUID);
		//m_ComponentMsgBox->RegisterListenBroadcastEvent(Soccer::Events::ChangedActivityStatus::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioUnitTestEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioResetAllEventVolume::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetVolumeForCategory::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioPaused::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::EbbRuleStop::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::EbbRuleUpdateEvent::EVENT_GUID);

		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioSetupEventFilter::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioClearTimeFilters::EVENT_GUID);

		// Start up audio system
		AudioSystem::Init(Axiom::Memory::AUDIO_HEAP);
		m_pAudioSystem = AudioSystem::GetInstance();
		AP_ASSERT(m_pAudioSystem!=NULL);
		m_pAudioSystem->Initialize();
		m_pAudioSystem->RegisterForEventFinishedCallbacks (this);

		EventFilters.Resize(Axiom::Memory::AUDIO_HEAP, MaxNumFilters);
	}

	//----------------------------------------------------------
	void		Audio::AudioComponent::AudioStarted (int EventId, int ReplyId)
	{
		Events::AudioReplyToPlaySound Reply;
		Reply.m_ReplyId = ReplyId;
		Reply.m_sfxID = EventId;
		Reply.m_Type = Events::EReplyToAudioEvent::ReplyWhenAudioStarts;

		m_ComponentMsgBox->SendEvent (&Reply);
	}
	//----------------------------------------------------------
	void		Audio::AudioComponent::AudioEnded (int EventId, int ReplyId)
	{
		// this functionality is too heavyweight
		Events::AudioReplyToPlaySound Reply;
		Reply.m_ReplyId = ReplyId;
		Reply.m_sfxID = EventId;
		Reply.m_Type = Events::EReplyToAudioEvent::ReplyWhenAudioEnds;
		
		m_ComponentMsgBox->SendEvent (&Reply);
	}
	//----------------------------------------------------------
	void		Audio::AudioComponent::AddFilter (int EventId, int MinimumTimeBetweenFirings)
	{
		int Index = FindFilter (EventId);
		if (Index != -1)
		{
			EventFilters[Index].MinimumTimeInMS = MinimumTimeBetweenFirings;
		}
		else
		{
			EventFilterWithTimeLimits NewFilter (EventId, MinimumTimeBetweenFirings, 0);
			EventFilters.Add (NewFilter);
		}
	}
	//----------------------------------------------------------
	void		Audio::AudioComponent::RemoveFilter (int EventId)
	{
		int Index = FindFilter (EventId);
		if (Index != -1)
		{
			EventFilters.RemoveAt(Index);
		}
	}
	//----------------------------------------------------------
	int		Audio::AudioComponent::FindFilter (int EventId)
	{
		int NumFilters = EventFilters.Count ();
		for (int i=0; i<NumFilters; i++)
		{
			if (EventFilters[i].Event == EventId)
				return i;
		}
		return -1;
	}
	//----------------------------------------------------------
	void		Audio::AudioComponent::OnUpdate()
	{
		if (!sIsTimerStarted)
		{
			sTimer.Start();
			sIsTimerStarted = true;
		}
		
		HandleEvents();
		AP_ASSERTMESSAGE(m_pAudioSystem!=NULL, "Audio not created yet");	

		if (m_pAudioSystem->IsReady ())
		{
			m_pAudioSystem->Update(m_CameraX, m_CameraY, m_CameraZ, m_LookAtX, m_LookAtY, m_LookAtZ, m_upX, m_upY, m_upZ);
			
		}
		
		if (m_UnitTestType != Events::EAudioTestType::AudioClearUnitTest)
		{
			m_UnitTestCurrentCountBetweeenRepeats++;
			if (m_UnitTestCurrentCountBetweeenRepeats > m_UnitTestDelayBetweenRepeats)
			{
				m_UnitTestCurrentCountBetweeenRepeats = 0;
				m_pAudioSystem->PlayEvent (m_UnitTestEventId, 
										1, 
										0, 0, 0, true);
			}
		}
		UpdateTime ();
		
		m_ComponentMsgBox->ClearOutbox();// send on these messages
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::OnShutdown()
	{
		mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);

		AP_ASSERTMESSAGE(m_pAudioSystem!=NULL, "Audio not created yet");
		
		m_pAudioSystem->Shutdown();
		m_pAudioSystem->Destroy();
	}
	//----------------------------------------------------------

	void		Audio::AudioComponent::OnSetVolume(int fVolume)
	{
		m_pAudioSystem->SetVolume(fVolume);
	}

	//----------------------------------------------------------

	void	Audio::AudioComponent::UpdateTime ()
	{
		int  currTime = sTimer.GetTime().AsIntInMilliseconds ();
		int  diffTime = currTime - sLastTimeInMS;
		//float frameTime =  static_cast<float>(Axiom::Math::Max(diff.AsInt64InMicroseconds(), static_cast<Axiom::Int64>(1)))  / 1000000.0f;
		//float fps = 1.0f / Axiom::Math::Max(frameTime, 1.0f/60.0f);

		if (m_pAudioSystem->IsReady() )
		{
			m_pAudioSystem->UpdateTime (diffTime);
		}
		sLastTimeInMS = currTime;	
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::HandleEvents()
	{
		int numEvents = m_ComponentMsgBox->GetNumEvents();
#ifdef EVENT_TIMING_ON
		//int nowtime = Axiom::TimeAbsolute::GetSystemTime().AsIntInMilliseconds ();
#endif

		for (int i = 0; i < numEvents; ++i)
		{
			const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			

			if(pMsg->GetGuidID() == Events::AudioUpdateCameraBody::EVENT_GUID)
			{
				UpdateCameraBody(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::AudioPlaySoundEvent::EVENT_GUID)
			{ 
#ifdef EVENT_TIMING_ON
				// testing only, be sure to delete this test
				int SentTime = pMsg->GetTimeSent ();
				int RecievedTime = pMsg->GetTimeReceived ();
				const Events::AudioPlaySoundEvent* Event = pMsg->GetClass<Events::AudioPlaySoundEvent>();

				Axiom::Log(LOGGING_CHANNEL, "Audio event play:Id:%d, time(sent:%dms; recd:%dms; diff:%dms)", 
					Event->m_AudioEventId, 
					SentTime, 
					RecievedTime, 
					RecievedTime-SentTime);
#endif
				PlaySoundEvent(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::AudioStopSoundEvent::EVENT_GUID)
			{ 
				StopSoundEvent(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::AudioPlaySoundBank::EVENT_GUID)
			{ 
				PlaySoundBank(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioPlaySoundExpectingReply::EVENT_GUID)
			{
				PlaySoundBankExpectingReply(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::AudioStopSoundBank::EVENT_GUID)
			{ 
				StopSoundBank(pMsg);
			}		
			else if(pMsg->GetGuidID() == Events::AudioExecuteCommands::EVENT_GUID)
			{	
				const Events::AudioExecuteCommands *pAudcommand = pMsg->GetClass<Events::AudioExecuteCommands>();
				switch(pAudcommand->m_eventID)
				{
				case Events::AudioExecuteCommands::Kill:
					if (m_pAudioSystem->IsReady ())
						{
							m_pAudioSystem->FMODDestroy();
						}
						break;
				case Events::AudioExecuteCommands::Reboot:
						m_pAudioSystem->FMODInit();
						m_pAudioSystem->FMODLoad();
						m_pAudioSystem->ResetTransitionGroups ();
						///m_pAudioSystem->FixUpEventsIDsAndGroupIDsByName();// unnecessary
					break;	
				
				default:
					break;
				}
			}
			else if(pMsg->GetGuidID() == Events::AudioSetMasterVolume::EVENT_GUID)
			{			
				SetMasterVolume(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioSetRolloff::EVENT_GUID)
			{
				SetRolloff(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioSetDistanceScaling::EVENT_GUID)
			{
				SetDistanceScaling(pMsg);
			}
			/*else if(pMsg->GetGuidID() == Events::AudioSetStreamVolume::EVENT_GUID)
			{			
				SetStreamVolume(pMsg);
			}*/
			else if(pMsg->GetGuidID() == Events::AudioSetEventVolume::EVENT_GUID)
			{ 
				SetEventVolume(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::AudioSetEventPitch::EVENT_GUID)
			{
				SetEventPitch(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioSetMixEvent::EVENT_GUID)
			{
				SetCurrentMix(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioResetAllEventVolume::EVENT_GUID)
			{
				ResetAllAudioVolumes(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioSetVolumeForCategory::EVENT_GUID)
			{
				SetVolumeForCategory (pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioUnitTestEvent::EVENT_GUID)
			{
				StartUnitTest (pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioPaused::EVENT_GUID)
			{
				PauseAudio(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::EbbRuleUpdateEvent::EVENT_GUID)
			{
				NewIntensityValue (pMsg);
			}
			else if (pMsg->GetGuidID() == Events::EbbRuleStop::EVENT_GUID)
			{
				StopTrackingIntensity ();
			}
			else if (pMsg->GetGuidID() == Events::AudioSetupEventFilter::EVENT_GUID)
			{
				SetupFilter (pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioClearTimeFilters::EVENT_GUID)
			{
				ClearFilterTimes ();
			}
		}
		m_ComponentMsgBox->ClearInbox();
	}

	//----------------------------------------------------------

	void Audio::AudioComponent::UpdateCameraBody(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioUpdateCameraBody *audioCameraEvent = pMsg->GetClass<Events::AudioUpdateCameraBody>();
			m_CameraX = audioCameraEvent->m_Position.X ();
			m_CameraY = audioCameraEvent->m_Position.Y ();
			m_CameraZ = audioCameraEvent->m_Position.Z ();
			m_LookAtX = audioCameraEvent->m_Front.X ();
			m_LookAtY = audioCameraEvent->m_Front.Y (); 
			m_LookAtZ = audioCameraEvent->m_Front.Z ();
			m_upX	  = audioCameraEvent->m_Up.X ();
			m_upY	  = audioCameraEvent->m_Up.Y ();
			m_upZ	  = audioCameraEvent->m_Up.Z ();
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::PlaySoundEvent(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady () && CanPlayAudioEvent (*pMsg))
		{
			const Events::AudioPlaySoundEvent* Event = pMsg->GetClass<Events::AudioPlaySoundEvent>();
			if (Event->m_Setting != Events::AudioPlaySoundEvent :: SettingOff)
			{
				m_pAudioSystem->PlayEvent (Event->m_AudioEventId, 
										Event->m_Priority, 
										Event->m_Setting);
			}
			else if (Event->m_Is3D)
			{
				m_pAudioSystem->PlayEvent (Event->m_AudioEventId, 
										Event->m_Priority, 
										Event->m_X, Event->m_Y, Event->m_Z, true);
			}
			else
			{
				m_pAudioSystem->PlayEvent_Reflection (Event->m_AudioEventId);
			}
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::StopSoundEvent(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioStopSoundEvent* Event = pMsg->GetClass<Events::AudioStopSoundEvent>();
			m_pAudioSystem->StopEvent(Event->m_AudioEventId);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::PlaySoundBankExpectingReply(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioPlaySoundExpectingReply* Event = pMsg->GetClass<Events::AudioPlaySoundExpectingReply>();

			PlayBankParams PlayParams;

			bool ReplyOnAudioEndFlag = true;
			if (Event->m_Type == Events::EReplyToAudioEvent::ReplyWhenAudioStarts)
				ReplyOnAudioEndFlag = false;

			PlayParams.m_delay = CastToFloat(Event->m_DelayInFrames);
			PlayParams.m_impactvelocity = Event->m_Velocity;
			PlayParams.m_positionX = Event->m_X;
			PlayParams.m_positionY = Event->m_Y;
			PlayParams.m_positionZ = Event->m_Z;

			m_pAudioSystem->PlayEventWithSignalBack (Event->m_sfxID, Event->m_ReplyId, PlayParams, ReplyOnAudioEndFlag);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::PlaySoundBank(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioPlaySoundBank* Event = pMsg->GetClass<Events::AudioPlaySoundBank>();
			if (Event->m_AudioBankId == -1)
			{
				m_pAudioSystem->PlayBank(Event->m_FModEventName.AsChar (), Event->m_Volume);
			}
			else
			{
				m_pAudioSystem->PlayBank(Event->m_AudioBankId, Event->m_Volume);
			}
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::StopSoundBank(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioStopSoundBank* Event = pMsg->GetClass<Events::AudioStopSoundBank>();
			if (Event->m_AudioBankId == -1)
			{
				m_pAudioSystem->StopBank(Event->m_FModEventName.AsChar ());
			}
			else
			{
				m_pAudioSystem->StopBank(Event->m_AudioBankId);
			}
		}
	}
	//----------------------------------------------------------
	
	void		Audio::AudioComponent::SetMasterVolume(const Axiom::EventMsg* pMsg)  
	{		
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetMasterVolume* Event = pMsg->GetClass<Events::AudioSetMasterVolume>();
			m_pAudioSystem->SetVolume(Event->m_mastVolume);
		}
	}

	//----------------------------------------------------------
	
	void		Audio::AudioComponent::SetRolloff(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			//const Events::AudioSetRolloff* Event = pMsg->GetClass<Events::AudioSetRolloff>();
			//m_pAudioSystem->SetRolloff(Event->m_Rolloff);
		}
	}

	//----------------------------------------------------------
	
	void		Audio::AudioComponent::SetDistanceScaling(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetDistanceScaling* Event = pMsg->GetClass<Events::AudioSetDistanceScaling>();
			m_pAudioSystem->SetDistanceScaling(Event->m_DistanceScale);
		}
	}
 
	//----------------------------------------------------------

	/*void		Audio::AudioComponent::SetStreamVolume(const Axiom::EventMsg* pMsg)
	{			
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetStreamVolume* Event = pMsg->GetClass<Events::AudioSetStreamVolume>();
			m_pAudioSystem->SetStreamVolume(Event->m_streamID, Event->m_strmVolume);
		}
	}*/

	//----------------------------------------------------------
	
	void		Audio::AudioComponent::SetEventVolume(const Axiom::EventMsg* pMsg)
	{			
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetEventVolume* Event = pMsg->GetClass<Events::AudioSetEventVolume>();
			if (Event->mIsFromGame == false)
				m_pAudioSystem->AudioSetVolume(Event->mEventId, Event->mVolume);
			else
				m_pAudioSystem->AudioSetGameVolume(Event->mEventId, Event->mVolume);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::SetEventPitch(const Axiom::EventMsg* pMsg)
	{			
		if (m_pAudioSystem->IsReady ())
		{
			//const Events::AudioSetStreamVolume* Event = pMsg->GetClass<Events::AudioSetStreamVolume>();
			//m_pAudioSystem->AudioSetStreamVolume(Event->m_streamID, Event->m_strmVolume);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::SetCurrentMix(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetMixEvent* Event = pMsg->GetClass<Events::AudioSetMixEvent>();
			m_pAudioSystem->SetCurrentMix(Event->mMixType);
			m_pAudioSystem->AudioMixUpdated ();
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::ResetAllAudioVolumes(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			//const Events::AudioResetAllEventVolume* Event = pMsg->GetClass<Events::AudioResetAllEventVolume>();
			m_pAudioSystem->AudioMixUpdated ();
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::SetVolumeForCategory (const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioSetVolumeForCategory* Event = pMsg->GetClass<Events::AudioSetVolumeForCategory>();
			m_pAudioSystem->SetCategoryVolume (Event->m_Category, Event->m_Volume);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::StartUnitTest (const Axiom::EventMsg * msg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioUnitTestEvent* Event = msg->GetClass<Events::AudioUnitTestEvent>();
			m_UnitTestType = Event->m_TestType;
			m_UnitTestEventId = Event->m_EventId;
			m_UnitTestCurrentCountBetweeenRepeats = 0;
			m_UnitTestDelayBetweenRepeats = Event->m_DelayBetweenRepeats;
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::PauseAudio(const Axiom::EventMsg * pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::AudioPaused* Event = pMsg->GetClass<Events::AudioPaused>();
			m_pAudioSystem->PauseAllStreams (Event->m_Paused);
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::NewIntensityValue(const Axiom::EventMsg * pMsg)
	{
		if (m_pAudioSystem->IsReady ())
		{
			const Events::EbbRuleUpdateEvent* Event = pMsg->GetClass<Events::EbbRuleUpdateEvent>();
			int NewIntensity = Event->mCurrentValue;
			Axiom::StringCRC ComparisonValue ("AudioIntensity");
			if (StringCompare (ComparisonValue, Event->mConfigurationName, ComparisonValue.kStringLength) == 0)
			{
				m_pAudioSystem->SetCurrentIntensity (NewIntensity);
			}
		}
	}

	//----------------------------------------------------------

	void		Audio::AudioComponent::StopTrackingIntensity ()
	{
		if (m_pAudioSystem->IsReady ())
		{
			m_pAudioSystem->SetCurrentIntensity (0);
		}
	}
	
	//----------------------------------------------------------

	void	Audio::AudioComponent::SetupFilter (const Axiom::EventMsg* pMsg)
	{
		const Events::AudioSetupEventFilter* Filter = pMsg->GetClass<Events::AudioSetupEventFilter>();
		if (Filter->RemoveFlag == false)
			AddFilter (Filter->EventId, Filter->TimeInMSBetweenFirings);
		else
			RemoveFilter (Filter->EventId);
	}
	//--------------------------------------------------------------------------------------------------------------------

	bool	Audio::AudioComponent::CanPlayAudioEvent (const Axiom::EventMsg& msg)
	{
		if (msg.GetGuidID() == AP::Events::AudioPlaySoundEvent::EVENT_GUID)
		{
			int  CurrentTimeInMS = sTimer.GetTime().AsIntInMilliseconds ();

			AP::Events::AudioPlaySoundEvent* AudioEvent = (AP::Events::AudioPlaySoundEvent*) &msg;
			int itemId = AudioEvent->m_AudioEventId;
			int NumFilters = EventFilters.Count ();
			// if there are no filters, it fires normally
			for (int i=0; i<NumFilters; i++)
			{
				if (itemId == EventFilters [i].Event)
				{
					// too soon to play again
					if (CurrentTimeInMS - EventFilters [i].LastTimeFiredInMS < 
						EventFilters [i].MinimumTimeInMS)
					{
						return false;
					}
					// reset the timer
					EventFilters [i].LastTimeFiredInMS = CurrentTimeInMS;
					break;
				}
			}
			return true;
		}
		else
		{
			return true;
		}
	}

	//--------------------------------------------------------------------------------------------------------------------

	void	Audio::AudioComponent::ClearFilterTimes ()
	{
		int NumFilters = EventFilters.Count ();
		for (int i=0; i<NumFilters; i++)
		{
			EventFilters [i].LastTimeFiredInMS = 0;
		}
	}
}// namespace AP
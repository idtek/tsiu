#include <kernel/kernel.h>

#include "audio/audio.h"
#include "reflection/script.h"
#include <xtl.h>
#include <xaudio.h>
#include <tchar.h>
#include "fmodxbox360.h"
#include "math/vector3.h"
#include <audio/double_buffered_data.h>


namespace AP
{
	namespace Audio
	{
#if 1
		//--------------------------------------------------------------
		struct FileMap
		{
			enum {BufferSize = 128*1024};
			Axiom::StaticString<64>			Filename;
			int					TotalFileSize;
			void*				FileHandle;
			int					CurrentFileReadPosition;
			Axiom::DoubleBufferedData <BufferSize> Buffer;
			bool				mIsInUse;

			FileMap () : TotalFileSize (0), 
							FileHandle (0), 
							CurrentFileReadPosition (0),
							mIsInUse (false)
			{
			}
			~FileMap ()
			{
			}
			void	SetInUse (bool used) {mIsInUse = used;}
			bool	IsInUse () {return mIsInUse;}
		};

		//-------------------------------------------------
		//-------------------------------------------------

		const int NumFileMapItems= 14;
		Axiom::Collections::StaticList <FileMap*, NumFileMapItems> ListOfOpenFiles;
		int		NumOpened = 0, NumClosed = 0;
		int		IndexOfLastUpdatedStream = 0;
		char ReadingBuffer [FileMap::BufferSize];

		//-------------------------------------------------
		//-------------------------------------------------

		FileMap* NewFile ()
		{
			int NumItems = ListOfOpenFiles.Count ();
			for (int i=0; i<NumItems; i++)
			{
				FileMap* ptr = ListOfOpenFiles[i];
				if (ptr->IsInUse () == false)
				{
					ptr->SetInUse (true);
					ptr->Buffer.Clear ();
					ptr->TotalFileSize = 0;
					return ptr;
				}
			}
			AP_ASSERTMESSAGE (0,"cannot open file stream because memory is not available\n");
			return NULL;
		}
		FileMap* FindFile (void* filehandle)
		{
			FileMap* ReturnMap = NULL;
			int NumItems = ListOfOpenFiles.Count ();
			for (int i=0; i<NumItems; i++)
			{
				FileMap* ptr = ListOfOpenFiles[i];
				if (ptr->FileHandle == filehandle)
				{
					ReturnMap = ptr;
					break;
				}
			}
			return ReturnMap;
		}

		void	DeleteFile (FileMap* Map)
		{
			if (Map == NULL)
				return;
			Map->SetInUse(false);
		}

		//----------------------------------------------------------------------
		//----------------------------------------------------------------------

		FMOD_RESULT F_CALLBACK FMOD_FileOpenCallback(const char *filename, int unicode, unsigned int *filesize, void **filehandle, void **userdata)
		{
			HANDLE hFile = ::CreateFile(filename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			NumOpened++;

			AP_ASSERT(hFile != 0);
			if (hFile == (HANDLE)0xffffffff)
			{
				return FMOD_ERR_FILE_NOTFOUND;
			}
			WIN32_FILE_ATTRIBUTE_DATA fileData;
			if( GetFileAttributesEx( filename, GetFileExInfoStandard, &fileData ) )
			{
				AP_ASSERT(fileData.nFileSizeHigh == 0);
			}

			// save off new data
			*filesize = static_cast<int>(fileData.nFileSizeLow);
			if (fileData.nFileSizeLow < 1)
			{
				CloseHandle (hFile);
				return FMOD_ERR_FILE_NOTFOUND;
			}
			AP_ASSERT (*filesize > 0);
			*filehandle = reinterpret_cast<void*>(hFile);

			if (AudioSystem::mIsRequestedFileAStream)
			{
				FileMap* Mapping = NewFile ();
				AP_ASSERT (Mapping != NULL);

				Mapping->TotalFileSize = *filesize;
				Mapping->FileHandle = hFile;
				Mapping->Filename = filename;

				// make sure that we have this tracking data available
				*userdata = Mapping;
				// immediately clear this flag.
				AudioSystem::mIsRequestedFileAStream = false;
			}
			else
			{
				*userdata = NULL;
			}
			
			return FMOD_OK;
		}

		//----------------------------------------------------------------------
		FMOD_RESULT F_CALLBACK FMOD_FileCloseCallback(void *filehandle, void *userdata)
		{
			AP_ASSERT_SUPPORTASSIGN(BOOL result, CloseHandle ( reinterpret_cast<HANDLE> (filehandle) ));
			AP_ASSERT(result == 1);
			NumClosed ++;
			if (userdata != NULL)
			{
				FileMap* Mapping = FindFile (filehandle);
				DeleteFile (Mapping);
			}
			
			return FMOD_OK;
		}
		//----------------------------------------------------------------------
		FMOD_RESULT F_CALLBACK FMOD_FileReadCallback     (void *filehandle, void *buffer, unsigned int sizebytes, unsigned int *bytesread, void *userdata)
		{
			DWORD bytesRead = 0;
			DWORD bytesRequested = FileMap::BufferSize;
			if (userdata != NULL)
			{
				FileMap* Mapping = FindFile (filehandle);
				if (Mapping != NULL)
				{
					if (Mapping->Buffer.DoesBufferNeedRefilling ())
					{
						DWORD FullBufferSize = Mapping->Buffer.HowMuchDataIsNeededToRefill ();
						if (bytesRequested > FullBufferSize)
							bytesRequested = FullBufferSize;

						while (bytesRead == 0)
						{
							AP_ASSERT_SUPPORTASSIGN(BOOL readResult,::ReadFile(reinterpret_cast<HANDLE> (filehandle), ReadingBuffer, bytesRequested, &bytesRead, NULL));
							AP_ASSERTMESSAGE(readResult != 0,"File failed to read %s\n", Mapping->Filename);

							if (bytesRead == 0)
							{
								AP_ASSERT_SUPPORTASSIGN(DWORD result,::SetFilePointer(reinterpret_cast<HANDLE> (filehandle), 0, 0, FILE_BEGIN));
								AP_ASSERT(result != INVALID_SET_FILE_POINTER);
							}
							else
							{
								Mapping->Buffer.AddDataToBuffer (ReadingBuffer, bytesRead);
							}
						}
					}
					else
					{
						bytesRead = sizebytes;
					}
					
					int SizeToReturn = bytesRead;
					if (SizeToReturn > (int) sizebytes)
						SizeToReturn = sizebytes;

					bytesRead = Mapping->Buffer.ReadDataFromBuffer (buffer, SizeToReturn);
					if (bytesRead == 0)// no more data left in bank
					{
						Mapping->Buffer.Clear ();
						return FMOD_ERR_FILE_EOF;
					}

					*bytesread = SizeToReturn;
				}
			}
			else
			{
				bytesRequested = sizebytes;
				AP_ASSERT_SUPPORTASSIGN(BOOL readResult, ::ReadFile(reinterpret_cast<HANDLE> (filehandle), buffer, bytesRequested, &bytesRead, NULL));
				AP_ASSERTMESSAGE(readResult != 0,"File failed to read\n");

				*bytesread = bytesRead;
				if (bytesRead == 0)
				{
					return FMOD_ERR_FILE_EOF;
				}
			}

			return FMOD_OK;
		}
		//----------------------------------------------------------------------
		FMOD_RESULT F_CALLBACK FMOD_FileSeekCallback     (void *filehandle, unsigned int offset, void *userdata)
		{
			AP_ASSERT_SUPPORTASSIGN(DWORD result, ::SetFilePointer(reinterpret_cast<HANDLE> (filehandle), offset, 0, FILE_BEGIN));
			AP_ASSERT(result != INVALID_SET_FILE_POINTER);

			if (userdata != NULL)
			{
				FileMap* Mapping = (FileMap* ) userdata;
				Mapping->Buffer.Clear ();
				Mapping->CurrentFileReadPosition = offset;
			}

			return FMOD_OK;
		}
		//----------------------------------------------------------------------

		void	AudioSystem::SetupFileSystem ()
		{
			int FMOD_Blockalign = -1;// use the default setting here
			FMOD::System * System;
			//FMOD_RESULT Result = 
				FmodEventSystem->getSystemObject (&System);

			for (int i=0; i<NumFileMapItems; i++)
			{
				FileMap* ptr = AP_NEW (Axiom::Memory::AUDIO_HEAP, FileMap ());
				ListOfOpenFiles.Add  (ptr);
			}
			//AP_NEW(Axiom::Memory::AUDIO_HEAP, FileMap (filename))
			(System)->setFileSystem (FMOD_FileOpenCallback, FMOD_FileCloseCallback, FMOD_FileReadCallback, FMOD_FileSeekCallback, FMOD_Blockalign);
		}
		
		void	AudioSystem::UpdateFileStreams ()
		{
			/*int NumItems = ListOfOpenFiles.Count ();
			if (IndexOfLastUpdatedStream >= NumItems)// basic range checking
				IndexOfLastUpdatedStream = 0;

			FileMap* Mapping = ListOfOpenFiles [IndexOfLastUpdatedStream];
			if (if (Mapping->IsInUse () == true && 
				Mapping->Buffer.DoesBufferNeedRefilling ())
			{
				DWORD FullBufferSize = Mapping->Buffer.HowMuchDataIsNeededToRefill ();
				if (bytesRequested > FullBufferSize)
					bytesRequested = FullBufferSize;

				while (bytesRead == 0)
				{
					BOOL readResult = ::ReadFile(reinterpret_cast<HANDLE> (filehandle), ReadingBuffer, bytesRequested, &bytesRead, NULL);
					AP_ASSERTMESSAGE(readResult != 0,"File failed to read %s\n", Mapping->Filename);

					if (bytesRead == 0)
					{
						DWORD result = ::SetFilePointer(reinterpret_cast<HANDLE> (filehandle), 0, 0, FILE_BEGIN);
						AP_ASSERT(result != INVALID_SET_FILE_POINTER);
					}
					else
					{
						Mapping->Buffer.AddDataToBuffer (ReadingBuffer, bytesRead);
					}
				}
			}*/
		}
#else
	void	AudioSystem::SetupFileSystem ()
	{
	}
	void	AudioSystem::UpdateFileStreams ()
	{
	}
#endif
		//--------------------------------------------------------------------------
		//---------------------------------------------------------------------

		void AudioSystem::Initialize()
		{
			mIsReady = false;

			// useful for processor assignment on the XBox360
		/*	FMOD_THREAD_PROCESSOR_ASSIGNMENTS m_FMODThreadAssign;
			m_FMODThreadAssign.file = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.mixer = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.nonblocking = FMOD_THREAD_CORE2THREAD0;
			m_FMODThreadAssign.stream = FMOD_THREAD_CORE2THREAD0;*/

			HeapSize = IN_MB(33);
			// Create a 40 meg memory space for fmod at this point I'm not certain how much memory fmod needs
			int WhichHeap = Axiom::Memory::AUDIO_HEAP;
			mMemBuffer = AP_NEW(WhichHeap, Axiom::UInt8[HeapSize]);
			ClearMemBuffer ();

			/*FMOD_RESULT           result;
			result = FMOD::Memory_Initialize(mMemBuffer, HeapSize, 0, 0, 0);
			AP_ASSERTMESSAGE(result == FMOD_OK,"FDesigner memory init failed!!");*/

			InitAudioEventList ();
			InitAudioEventGroupList ();
			InitAudioMixList ();
			InitVolumeSetByGame ();
			ClearFModEventsIDs ();	
			
			FMODInit();
			AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(this), "Audio Editor");

			SetupFileSystem ();
			FMODLoad();
		}

		void	AudioSystem::ClearMemBuffer ()
		{
			Axiom::MemorySet (mMemBuffer, 0, HeapSize);
		}

		Axiom::UInt32			AudioSystem::GetMemoryWatermark () const
		{
			int x = HeapSize / sizeof (Axiom::UInt64);
			Axiom::UInt64* ptr = (Axiom::UInt64*) mMemBuffer;
			for (int i=x-1; i>=0; i--)
			{
				if (ptr [i] != 0)
				{
					return i * sizeof (Axiom::UInt64);
				}
			}
			return 0;
		}
		//---------------------------------------------------------------------
		//---------------------------------------------------------------------
	}
} //namespace AP

#ifndef CORE_AUDIO_COMPONENT_H__
#define CORE_AUDIO_COMPONENT_H__

#include "kernel/component.h"
#include "audio/audio.h"
#include "core/time.h"

namespace AP
{
	namespace Audio
	{
		struct EventFilterWithTimeLimits
		{
			EventFilterWithTimeLimits (int e, int m, int l)
			{
				Event = e; MinimumTimeInMS = m; LastTimeFiredInMS = l;
			}
			int Event;
			int MinimumTimeInMS;
			int LastTimeFiredInMS;
		};

		class AudioComponent: public Component, public SignalledAudioWhenReady
		{
		public:
			enum {MaxNumFilters = 40};
		public:

			AudioComponent(Axiom::ConstStr name, AP::Kernel* kernel);
			~AudioComponent();
 
			virtual void					OnInit();
			virtual void					OnUpdate();
			virtual void					OnShutdown();

			//void							RegisterEventListLength(int evtLength);
			void							OnSetVolume(int fVolume);
			
			void							AudioStarted (int EventID, int SignalId);
			void							AudioEnded (int EventID, int SignalId);

			void							AddFilter (int EventId, int MinimumTimeBetweenFirings);
			void							RemoveFilter (int EventId);

		protected:
		private:
			AudioSystem*					m_pAudioSystem;
			bool							m_bPause;
			float							m_CameraX, m_CameraY, m_CameraZ;
			float							m_LookAtX, m_LookAtY, m_LookAtZ;
			float							m_upX, m_upY, m_upZ;

			int								m_UnitTestType;
			int								m_UnitTestEventId;
			int								m_UnitTestCurrentCountBetweeenRepeats;
			int								m_UnitTestDelayBetweenRepeats;
			Axiom::Collections::DynamicList <EventFilterWithTimeLimits> EventFilters;

			void							HandleEvents();

			void 							UpdateCameraBody(const Axiom::EventMsg* pMsg);
			void 							VehicleEvent(const Axiom::EventMsg* pMsg);
			void 							CreateVehicle(const Axiom::EventMsg* pMsg);
			void 							VehicleUpdate(const Axiom::EventMsg* pMsg);
			void 							PlaySoundEvent(const Axiom::EventMsg* pMsg);
			void 							StopSoundEvent(const Axiom::EventMsg* pMsg);
			void 							PlaySoundBank(const Axiom::EventMsg* pMsg);
			void							PlaySoundBankExpectingReply(const Axiom::EventMsg* pMsg);
			void 							StopSoundBank(const Axiom::EventMsg* pMsg);
			void							SetMixEvent(const Axiom::EventMsg* pMsg);
			void							SetMasterVolume(const Axiom::EventMsg* pMsg);
			void							SetRolloff(const Axiom::EventMsg* pMsg);
			void							SetDistanceScaling(const Axiom::EventMsg* pMsg);
			void							SetStreamVolume(const Axiom::EventMsg* pMsg);
			void							SetEventVolume(const Axiom::EventMsg* pMsg);
			void							SetEventPitch(const Axiom::EventMsg* pMsg);
			void							SetCurrentMix(const Axiom::EventMsg* pMsg);
			void							ResetAllAudioVolumes(const Axiom::EventMsg* pMsg);
			void							SetVolumeForCategory (const Axiom::EventMsg* pMsg);
			void							PauseAudio(const Axiom::EventMsg* pMsg);
			void							NewIntensityValue(const Axiom::EventMsg* pMsg);
			void							StopTrackingIntensity ();
			void							SetupFilter (const Axiom::EventMsg* pMsg);
			void							ClearFilterTimes ();

			void							StartUnitTest (const Axiom::EventMsg * msg);
			void							UpdateTime ();

			int								FindFilter (int EventId);
			bool							CanPlayAudioEvent (const Axiom::EventMsg& msg);

			Axiom::EventMsgBoxHandle		m_ComponentMsgBox;
		};
	}
}

#endif


#ifndef _SIGNALED_AUDIO_H_
#define _SIGNALED_AUDIO_H_

#include "audio\audioparams.h"
#include "fmod_event.hpp"

//-------------------------------------------------
namespace AP
{
	namespace Audio
	{
		class SignaledAudio
		{
		public:
			enum	SignalType {SignalBackAtStart, SignalBackAtEnd};

			//--------------------------------------

			SignaledAudio ();
			~SignaledAudio ();
			void	Clear ();// be very careful calling this

			// used for maintenance
			bool	IsAvailable ();
			void	SetAvailable ();

			//--------------------------------------

			void	PlaySound (SignalType type, 
				FMOD::EventGroup*group, FMOD::Event* FmodAudioEvent, int EventId, int SignalId, 
								Axiom::Collections::DynamicList <Audio::SignalledAudioWhenReady*>* Signaller, 
								const Audio::PlayBankParams& Params);
			void	Update ();

			int		GetSignalID () {return SignalId;}
			int		GetEventID () {return EventId;}

			//--------------------------------------
			
			bool		HasSignaled () {return HasSignaledFlag;}
			SignalType	GetType () {return Type;}

			//--------------------------------------

			void	Mute (int EventId);
			void	Unmute (int EventId);

		private:
			Audio::PlayBankParams	PlayParams;
			SignalType				Type;
			bool					IsEnabledFlag;
			bool					HasSignaledFlag;
			bool					IsAwaitingCallbackFlag;
			int						SignalId;
			int						EventId;
			Axiom::Collections::DynamicList <Audio::SignalledAudioWhenReady*>*Signaller;
			FMOD::EventGroup*		EventGroup;
			FMOD::Event*			FmodAudioEvent;
		public:
			void	SetSignal ();// invoked by the FMOD callback
		};
	}// namespace Audio

//-------------------------------------------------
}

#endif // _SIGNALED_AUDIO_H_

#ifndef _AudioParams_H
#define _AudioParams_H

#include <Collections/list.h>
#include <string/string.h>
#include "audio/audioeventmessages.h"

namespace AP
{
	namespace Audio
	{
		struct PlayRange
		{
			public:
			PlayRange ();
			Axiom::UInt8  m_Low, m_High;

			AP_DECLARE_TYPE();
		};
		//--------------------------------------------------------
		//--------------------------------------------------------
		struct BankParams 
		{
		public:
			enum {BadValue = 0xffff, MaxVolume = 196, CenterPitch = 0};

			//----------------------------------------------------
			BankParams ();
			const bool operator ==(const BankParams& rhs) const;
		public:
			//----------------------------------------------------
			PlayRange		m_PlayRange;// this will eventually expand into an array of items
			Axiom::UInt16	m_Id;
			short			m_Delay;
			short			m_Pitch;
			Axiom::UInt8	m_Volume;			
			Axiom::UInt8	m_BPM;	
			Axiom::Bool		m_IsPlaying;
			Axiom::Bool		m_IsStream;
			Axiom::Bool		m_IsStopEvent;
			Axiom::Bool		m_IsSelfDeleting;// meaning that it will be deleted when it finishes
			Axiom::Bool		m_IsLoaded;
			Axiom::Bool		m_MuteOn;

			AP_DECLARE_TYPE();
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		// this structure is too fat for basic purposes
		struct PlayBankParams 
		{
		public:
			PlayBankParams();
			const bool operator ==(const PlayBankParams& rhs) const;
		public:
			//----------------------------------------------------
			int   m_id;
			float m_volume;
			float m_positionX;
			float m_positionY;
			float m_positionZ;
			float m_distance;
			float m_pitch;
			float m_impactvelocity;
			float m_delay;
			
			AP_DECLARE_TYPE();

		};  //The basic components of each sound effect

		//--------------------------------------------------------
		//--------------------------------------------------------
		struct SimpleBankData
		{
		public:
			SimpleBankData () ;
			const bool operator ==(const SimpleBankData& rhs) const;

		public:
			//----------------------------------------------------

			BankParams				m_AudioSettings;
			int						m_FModEventId;// ID of the FMOD Event
			Axiom::ShortString		m_FModEventName;
			int						m_AudioEventId;// ID of the AudioEventData container		
			FMOD::Event*			mStreamPointer;
			Axiom::UInt8			m_Priority;

			AP_DECLARE_TYPE();
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		class AudioThatSignalsBackWhenDone 
		{
		public:
			AudioThatSignalsBackWhenDone (FMOD::EventGroup*, FMOD::Event*, const char* EventName, BankParams* Params);
			BankParams* GetParams () {return m_BankParams;}
			static FMOD_RESULT F_CALLBACK FmodEndAudioCallback (FMOD_EVENT *event, FMOD_EVENT_CALLBACKTYPE type, void *param1, void *param2, void *userdata);

		public:
			//----------------------------------------------------

			FMOD::EventGroup*		m_EventGroup;
			FMOD::Event*			m_FModEvent;
			const char*				m_FModEventName;
			BankParams*				m_BankParams;
		};
		//--------------------------------------------------------
		//--------------------------------------------------------
		class AudioThatSignalsBackWhenReadyToPlay 
		{
		public:
			AudioThatSignalsBackWhenReadyToPlay (FMOD::EventGroup*, FMOD::Event*, int EventId, BankParams* Params);
			BankParams* GetParams () {return m_BankParams;}
			static FMOD_RESULT F_CALLBACK FmodAudioLoadedCallback (FMOD_EVENT *event, FMOD_EVENT_CALLBACKTYPE type, void *param1, void *param2, void *userdata);

		public:
			//----------------------------------------------------
			FMOD::EventGroup*		m_EventGroup;
			FMOD::Event*			m_FmodEvent;
			int						m_FModEventId;
			BankParams*				m_BankParams;
			bool					m_IsReady;
		};
		//--------------------------------------------------------
		//--------------------------------------------------------
		struct ComplexAudioBankData
		{
		public:
			SimpleBankData			m_BasicAudioInfo;
			float					X, Y, Z;
			bool					PlayIn3D;
		};	
		//--------------------------------------------------------
		//--------------------------------------------------------
		class SignalledAudioWhenReady 
		{
		public:
			SignalledAudioWhenReady() {};
			virtual ~SignalledAudioWhenReady() {};

			virtual void AudioStarted (int EventID, int SignalId) { UNUSED_PARAM(EventID); UNUSED_PARAM(SignalId); }
			virtual void AudioEnded (int EventID, int SignalId) { UNUSED_PARAM(EventID); UNUSED_PARAM(SignalId); }
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		class SignalledAudioWhenCompleted
		{
		public:
			SignalledAudioWhenCompleted() {};
			virtual ~SignalledAudioWhenCompleted() {};

			virtual void AudioStarted (int EventID, int SignalId) { UNUSED_PARAM(EventID); UNUSED_PARAM(SignalId); }
			virtual void AudioEnded (int EventID, int SignalId) { UNUSED_PARAM(EventID); UNUSED_PARAM(SignalId); }
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		// The Event data is internal to ActionPants. This is a layer above the 
		struct AudioEventData
		{
		public:
			enum {MaxBankCount = 8};	
			typedef Axiom::Collections::StaticList<SimpleBankData, MaxBankCount>
				AudioBankDataType;

			//-----------------------------------
			AudioEventData();
			int		Count ();

			const bool operator ==(const AudioEventData& rhs) const;

		public:
			//-----------------------------------
			AudioBankDataType				m_BankSetup;
			BankParams						m_AudioSettings;
			int								m_Id;
			int								m_GroupId;	
			
			int								m_NumBanks;	
			int								m_NSyncMusicTransitionalGroupId;
			AP_DECLARE_TYPE();
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		struct AudioEventGroupData
		{
		public:
			AudioEventGroupData ();
			const bool operator ==(const AudioEventGroupData& rhs) const;

		public:
			//-----------------------------------
			Axiom::ShortString				m_Name;
			AP::Events::EAudioBroadCategory	m_Category;
			float							m_DistanceScaling;
			float							m_HighVolumeDisc;// distance
			int								m_Id;	
			int								m_Volume;	
				
			AP_DECLARE_TYPE();
		};

		//--------------------------------------------------------
		//--------------------------------------------------------
		class AudioMixArrangementData
		{
		public:
			enum	{MaxNumGroups = 25};
			Axiom::Collections::StaticList<Axiom::UInt8,MaxNumGroups>			MixPerGroup;
			Axiom::Collections::StaticList<Axiom::Float,MaxNumGroups>			RampTimePerGroup;

			AudioMixArrangementData () {}
			const bool operator ==(const AudioMixArrangementData& rhs) const
			{
				bool IsEqual = true;
				for (int i=0; i<MaxNumGroups; i++)
				{
					if (MixPerGroup[i] == rhs.MixPerGroup[i])
						continue;
					IsEqual = false;
					break;
				}
				return IsEqual;
			}
			int GetNumMixes () {return MaxNumGroups;}
			AP_DECLARE_TYPE();
		};
		//--------------------------------------------------------
		//--------------------------------------------------------
		class AudioMixCurrentValue
		{
		public:
			AudioMixCurrentValue ();
			void	Setup (Axiom::Collections::StaticList<Axiom::UInt8,AudioMixArrangementData::MaxNumGroups>& Mix);

			void	Setup (Axiom::Collections::StaticList<Axiom::UInt8,AudioMixArrangementData::MaxNumGroups>& MixChange,
							Axiom::Collections::StaticList<Axiom::Float,AudioMixArrangementData::MaxNumGroups>& RampTimes);
			Axiom::UInt8 GetCurrentValue (int index);
			bool	Update (int TimePassedInMilliseconds);

		protected:
			void	Reset (int index, float Destvalue)
			{
				CurrentMixValue[index] = Destvalue;
				RampValuePerMillisecond[index] = 0.0;
			}
			
			bool	IsRamping;
			Axiom::Collections::StaticList<Axiom::Float,AudioMixArrangementData::MaxNumGroups>			CurrentMixValue;
			Axiom::Collections::StaticList<Axiom::UInt8,AudioMixArrangementData::MaxNumGroups>			DestinationValue;
			Axiom::Collections::StaticList<Axiom::Float,AudioMixArrangementData::MaxNumGroups>			RampValuePerMillisecond;
		};
		//--------------------------------------------------------
		//--------------------------------------------------------
	}
}

#endif // _AudioParams_H_

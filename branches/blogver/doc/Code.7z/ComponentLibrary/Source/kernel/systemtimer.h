#ifndef __TIMER_H
#define __TIMER_H

#include <core/time.h>

#define CORE_DEFAULT_FRAME_RATE 1.f/60.f

namespace AP
{
	namespace System
	{
		class Timer
		{
		public:
			Timer ();
			~Timer ();

			void				Start();
			float				GetElapseTime();
			Axiom::TimeAbsolute	GetTime();
			void				Set(float secs);

		private:

#if CORE_WIN32 || CORE_XBOX360
			LARGE_INTEGER	mFreq;
			LARGE_INTEGER	mStartTick;
#elif CORE_PS3
			uint64_t		mFreq;
			uint64_t		mStartTick;
#elif CORE_WII
			OSTick			mFreq;
			OSTick			mStartTick;
#else
#error "Not implemented"
#endif
		};

	}
}

#endif


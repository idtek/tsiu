#if CORE_WIN32
	#include <windows.h>
	#include <winbase.h>
#elif CORE_PS3
	#include <sys/time_util.h>
	#include <sys/sys_time.h>
	#include <sys/process.h>
	#include <sys/timer.h>
	#include <sys/sys_time.h>
	#include <sys/time_util.h>
#elif CORE_WII
	#include <revolution/os.h>
#endif

#include "kernel/systemtimer.h"

namespace AP
{
	namespace System
	{
		Timer::Timer ()
		{
#if CORE_WIN_BASED_OS
			QueryPerformanceFrequency(&mFreq);
#elif CORE_PS3
			mFreq = sys_time_get_timebase_frequency();
#elif CORE_WII
			mFreq = OS_TIMER_CLOCK;
#endif
		}

		Timer::~Timer ()
		{	
		}

		void Timer::Start()
		{
#if CORE_WIN_BASED_OS
			QueryPerformanceCounter(&mStartTick);
#elif CORE_PS3
			SYS_TIMEBASE_GET(mStartTick);
#elif CORE_WII
			mStartTick = OSGetTick();
#endif
		}

		float Timer::GetElapseTime()
		{
#if CORE_WIN_BASED_OS
			LARGE_INTEGER tick;
			QueryPerformanceCounter(&tick);
			return static_cast<float>(tick.QuadPart-mStartTick.QuadPart)/static_cast<float>(mFreq.QuadPart);
#elif CORE_PS3
			const uint64_t U_SEC (1000 * 1000);
			register uint64_t curTime;
			SYS_TIMEBASE_GET(curTime);

			return ((static_cast<float>(curTime-mStartTick)/static_cast<float>(mFreq / U_SEC)))/1000000.f;		
#elif CORE_WII
			OSTick time = OSGetTick();
			OSTick diff = time - mStartTick;
			return OSTicksToMicroseconds(diff)/1000000.f;
#endif
		}

		Axiom::TimeAbsolute Timer::GetTime()
		{
#if CORE_WIN_BASED_OS
			LARGE_INTEGER tick;
			QueryPerformanceCounter(&tick);
			return Axiom::TimeAbsolute::CreateFromSeconds(static_cast<float>(tick.QuadPart-mStartTick.QuadPart)/static_cast<float>(mFreq.QuadPart));
#elif CORE_PS3
			register uint64_t curTime;
			SYS_TIMEBASE_GET(curTime);

			return Axiom::TimeAbsolute::CreateFromSeconds(static_cast<float>(curTime-mStartTick)/static_cast<float>(mFreq));
#elif CORE_WII
			OSTick time = OSGetTick();
			OSTick diff = time - mStartTick;
			return Axiom::TimeAbsolute::CreateFromSeconds(static_cast<float>(OSTicksToSeconds(diff)));
#endif
		}
	}
}

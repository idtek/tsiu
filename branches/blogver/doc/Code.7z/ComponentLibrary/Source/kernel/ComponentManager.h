//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		Kernel/componentmanager.h
//! @brief		Component Manager API
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------
#ifndef _COMPONENT_MANAGER_H
#define _COMPONENT_MANAGER_H

#include <core/singleton.h>
#include "kernel/kernel.h"
#include <collections/circularbuffer.h>

namespace Axiom
{
	class Event; 
	class EventContainer;
	class EventMsg;
}

//--------------------------------------------------------------------------
namespace AP
{
	typedef int EventListenerId;
	class KernelManager;
	class Component;

	using Axiom::Log;

	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@enum		ConnectType
	//!	@brief		Type of connection
	//! @ingroup	ComponentArchitecture
	//!
	//! Type of connection from one component to the next
	//---------------------------------------------------------------------------------------------------------------------------------
	enum ConnectType
	{
		CT_BI_DIRECTION = 0,				//!< Bi-directional connection
		CT_SINGLE_DIRECTION = 1				//!< direcitonal connection
	};

	enum ESpecialComponentIDs
	{
		EInvalidComponentID = -1,
		EFirstComponentID
	};


	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		KernelConfig
	//!	@brief		API to configure a kernel
	//! @ingroup	ComponentArchitecture
	//!
	//! Specify the kernel hardware processor/thread id, memory heap, and kernel id/name.  This is needed to ensure the component manager will run correctly
	//---------------------------------------------------------------------------------------------------------------------------------
	class KernelConfig
	{
	public:
		//---------------------------------------------------------------------------------------------------------------------------------
		//!	@class		Config
		//!	@brief		Structure for storing configurations
		//! @ingroup	ComponentArchitecture
		//!
		//! Specify the kernel hardware processor/thread id, memory heap, and kernel id/name.  This is needed to ensure the component manager will run correctly
		//---------------------------------------------------------------------------------------------------------------------------------
		struct Config
		{
			KernelIdType kernelId;						//!< Assign a kernel Id
			Axiom::ConstStr name;						//!< Name of the kernel
			int processId;								//!< Hardware Processor ID.  XBOX360[0..5]  PC[0]  PS3[0]
			Axiom::Thread::ThreadPriority priority;		//!< Priority
   			Axiom::Memory::HeapId mainHeapId;			//!< Asigned memory heap
		};

		KernelConfig():mNumKernelConfigs(0){}
		~KernelConfig(){}

		void AddKernel(KernelIdType kernelId, Axiom::ConstStr name, int processId, Axiom::Thread::ThreadPriority priority, const Axiom::Memory::HeapId mainHeapId)		
		{
			AP_ASSERT(mNumKernelConfigs < MAX_KERNEL_CONFIG);
			mKernelConfigList[mNumKernelConfigs].kernelId = kernelId;
			mKernelConfigList[mNumKernelConfigs].name = name;
			mKernelConfigList[mNumKernelConfigs].processId = processId;
			mKernelConfigList[mNumKernelConfigs].priority = priority;
			mKernelConfigList[mNumKernelConfigs].mainHeapId = mainHeapId;

			mNumKernelConfigs++;
		}																																		//!< Adding a kernel to the config

		int GetNumKernelConfigs() { return mNumKernelConfigs;}																					//!< Get number of configurations

		Config & operator[](const int index)																									//!< Random accessor of kernel config entry
		{
			AP_ASSERT(index < MAX_KERNEL_CONFIG);
			return mKernelConfigList[index];
		}

	private:

		static const int MAX_KERNEL_CONFIG = 32;																								//!< Number of kernel configuration
		Config			mKernelConfigList[MAX_KERNEL_CONFIG];																					//!< List of kernel configuration
		int				mNumKernelConfigs;																										//!< List of kernel
	};

	struct KernelInfo
	{
		Axiom::Thread::ThreadId			m_threadId;													//!< hwThread Id
		Axiom::Thread::ThreadPriority	m_threadPriority;											//!< Thread Priority
		Kernel*							m_pKernel;													//!< Pointer to a kernel
		const char*						m_pStaticName;												//!< Name of the kernel
	};

	class OverflowedMessage
	{
	public:
		OverflowedMessage( int fromComponent, int toComponent, const Axiom::EventMsg *msg)
		: m_FromComponent (fromComponent )
		, m_ToComponent( toComponent )
		, m_Event( Axiom::EventData(msg))
		{
		}
		int m_FromComponent;
		int m_ToComponent;
		Axiom::EventData m_Event;
	};

	template <int size>
	class OverflowedMessageBuffer
	{
	public:
		OverflowedMessageBuffer();
		void				AddMessage( const Axiom::EventMsg *msg, int fromComponent, int toComponent );
		Axiom::EventData*	GetMessage( int fromComponent, int toComponent );
		void				PopMessage( int fromComponent, int toComponent );
	private:
		unsigned int													m_HighWaterMark;
		Axiom::Thread::Mutex											m_Mutex;
		Axiom::Collections::StaticLinkedListArray<OverflowedMessage, size>	m_OverflowBuffer;
	};

	class ConnectionBuffer
	{
	public:
		bool															m_RequiresMutex;
		Axiom::Thread::Mutex											m_Mutex;
		Axiom::Collections::DynamicCircularList<Axiom::EventData>		m_MessageRingBuffer;

		int	m_NumEventsIn;
		int m_HighWaterMark;
		int m_Size;
		int m_FromComponent;
		int m_ToComponent;

        static const unsigned int NumberOfOverflowedMessages = 512;
		static OverflowedMessageBuffer<NumberOfOverflowedMessages>*	m_OverflowedMessages;

		ConnectionBuffer(int fromCompoent, int toComponent, bool requiresMutex = false, int bufferSize = 256 );
		bool AddNewEvent( const Axiom::EventMsg *msg );
		Axiom::EventData* GetOldestEvent();	// Get the oldest event available
		void PopOldestEvent();			// You can only release it after processing
	};

	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		ComponentManager
	//!	@brief		API to create multi-thread environment with a component topology
	//! @ingroup	ComponentArchitecture
	//!
	//! The component manager is now data driven to configure hardware environment (threads and processor), creating components, synchronization startup, update, and shutdown.
	//! This will allow users to not worry about any of the threading and synchronization during startup, update, and shutdown.
	//---------------------------------------------------------------------------------------------------------------------------------
	class ComponentManager : public Axiom::Singleton <ComponentManager>
	{
								AP_NON_COPYABLE(ComponentManager);

	public:

		// ---------------------------------- Constructor/Destructor calls -------------------------------------------------------------
								ComponentManager();
								~ComponentManager();

		void					InitComponentManager(Axiom::Memory::HeapId heapId, unsigned int MaxKernels, unsigned int MaxComponents);

		// ---------------------------------- Members calls -------------------------------------------------------------
		void					InitKernels(KernelConfig &config);																								//!< Init kernel configuration

		void 					SetKernelHeap(unsigned int kernelId, const Axiom::Memory::HeapId mainHeapId);
		
		void					Connect(Component* pComponent1, Component* pComponent2,const ConnectType connectType = CT_SINGLE_DIRECTION, int fromAToB = 16, int fromBToA = 16);
																																								//!< Connect a component to another component
		template<typename T> T* CreateComponent( Axiom::ConstStr name, KernelIdType kernelId, bool overRideMsgBoxSizes = false, unsigned int inMsgSize = 256, unsigned int outMsgSize = 256, unsigned int filterSize = 50);																	//!< Create a new component

		void					InitializeAllComponents();																										//!< Start the kernel and wait until all components are initialized
		void					StartAllComponents();																											//!< Resume the kernel and start all component updating

		bool					IsAllComponentActive();																											//!< Is the component manager still active

		void					RequestShutdown();																												//!< Request component manager to shutdown all components
		void					SendMessage(const Axiom::EventMsg& newMsg);																						//!< Send a message from the current active component

		Component*				ActiveComponent();																												//!< Get the current active component within the running kernel
		const Component*		ActiveComponent() const;																										//!< Get the current active component within the running kernel

		AP_DECLARE_TYPE();

		Component*				FindComponent(Axiom::ConstStr name);

		KernelInfo*				GetKernelInfo(KernelIdType kernelId);
		const char*				GetKernelName(Axiom::Thread::ThreadId threadid);			//!< Get Kernel name
		Axiom::Thread::ThreadId GetCurrentThreadId() const;
		Axiom::Thread::ThreadId	GetThreadId(KernelIdType kerId);							//!< Get Thread Id
		KernelIdType			GetKernelId();												//!< Get kernel id
		Kernel*					GetCurrentKernel();											//!< Get the current active kernel
		const Kernel*			GetCurrentKernel() const;									//!< Get the current active kernel
		void					EnterExclusiveMode();										//!< Set exclusive kernel run mode 
		void					LeaveExclusiveMode();										//!< Leave exclusive kernel run mode
		// Message passing between components, might be better (completely or partly) in EventManager
		void					PushEventsToListeners( Component* fromComponent, Axiom::EventMsgBoxHandle externalMsgBoxHandle, bool sendEvents );
		void					PushEventToListeners( Component* fromComponent, const Axiom::EventMsg* baseMsg, bool sendEvents );
		void					ListenToEvents( Component* whatComponent );

	protected:
		Kernel*					FindKernel(KernelIdType kernelId);																								//!< Find a kernel object given the kernel id

		void					CreateKernel(	unsigned int kernelId, 
												Axiom::ConstStr name,
												int processorId,
												Axiom::Thread::ThreadPriority priority, 
												const Axiom::Memory::HeapId mainHeapId);			//!< Create a kernel given the hardware properties. processorId:{XBOX360[0..5] Win32[0] PS3[0]}  and priority [0 to 100]

		// Message passing between components, might be better (completely or partly) in EventManager
		void					PushEventsAcrossThreadBoundaries( int fromComponentID, int toComponentID, Axiom::EventMsgBoxHandle externalMsgBoxHandle );
		void					PushEventsToSameThread( int fromComponentID, int toComponentID, Axiom::EventMsgBoxHandle externalMsgBoxHandle );

		void					PushEventAcrossThreadBoundaries( int fromComponentID, int toComponentID, const Axiom::EventMsg* baseMsg );
		void					PushEventToSameThread( int fromComponentID, int toComponentID, const Axiom::EventMsg* baseMsg );

		void					GetEventsAcrossThreadBoundaries( int fromComponentID, int toComponentID );
		void					GetEventsFromSameThread(int fromComponentID, int toComponentID);
		void					DumpConnectionBufferInfo();
	private:
		Axiom::Collections::DynamicList<KernelInfo>		m_KernelList;																									//!< List of kernels registered
		Axiom::Collections::DynamicList<Component*>		m_ComponentList;
		int												m_NextComponentID;

		int												m_MaxComponents;
		ConnectionBuffer**								m_pComponentConnectionBuffers;

		Axiom::Thread::Mutex							m_ExclusiveModeMutex;										//!< Mutex for doing exclusive mode
	};

	
	template<typename T> inline
	T* ComponentManager::CreateComponent( Axiom::ConstStr name, KernelIdType kernelId, bool overrideMsgBoxSizes, unsigned int inMsgSize, unsigned int outMsgSize, unsigned int filterSize)
	{
		Kernel* kernel = FindKernel(kernelId);
		AP_ASSERT(kernel!=NULL);

		T* comp = reinterpret_cast<T*>(AP_NEW(kernel->GetHeapId(),T(name,kernel)));
		comp->SetComponentID( ++m_NextComponentID );
		m_ComponentList.Add( comp );

		if ( overrideMsgBoxSizes)
		{
			comp->SetMsgBoxOverride(inMsgSize, outMsgSize, filterSize);
		}

		Log("ComponentManager","COM[%s] \t 0x%x", name,comp->GetClassHashId());
		AP_ASSERTMESSAGE(kernel!=NULL,"Can't add component, kernel not found!");
		kernel->AttachComponent(comp);
		return comp;
	}
//--------------------------------------------------------------------------
} // namespace AP

#endif // _COMPONENT_MANAGER_H_

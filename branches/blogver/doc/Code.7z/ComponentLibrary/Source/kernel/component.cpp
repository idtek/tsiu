/*!
 * Implementation of component
 * 
 * Copyright (c) 2005 by Action Pants
 */
 
// class header
#include "kernel/component.h"
 
// other includes
#include "kernel/kernel.h"
#include "kernel/messages.h"
#include <kernel/componentmanager.h>
#include <eventsystem/eventman.h>

namespace AP
{
//#define	__COMPONENT_VERBOSE__MODE__

	AP_TYPE(Component)
		AP_PROXY("ComponentLibrary")
	AP_TYPE_END()
	//------------------------------------------------------------------------------------------------------------------------
	// Constructor
	//------------------------------------------------------------------------------------------------------------------------

	Component::Component (Axiom::ConstStr _name, Kernel* kernel, bool autoSendEventToListener )
		:
	      mExternalMsgBoxHandle(NULL)
	    , m_kernel(kernel)
	    , mName( _name )
		, mOverrideMessageBoxDefaults(0)
		, mAutoSendEventToListener(autoSendEventToListener)
		, mListenAllEvents(false)
		, mHashNameId( Axiom::CRC( _name ) )
	{
	}

	Component::~Component ()
	{
	
	}

	void Component::Init()
	{
		// Initialize the new event system
		mEventMan.Init();
		AP_ASSERT(mExternalMsgBoxHandle == NULL);
		if ( mOverrideMessageBoxDefaults)
		{
			mExternalMsgBoxHandle = mEventMan.RegisterAndCreateEventMsgBox( mName.AsChar(), Axiom::Memory::DEFAULT_HEAP, mInMsgBoxSize, mOutMsgBoxSize, mFilterSize );
		}
		else
		{
			mExternalMsgBoxHandle = mEventMan.RegisterAndCreateEventMsgBox( mName.AsChar() );
		}
		mExternalMsgBoxHandle->OverrideFilterAndListenAllEvents(true);
		
		OnInit();
	}
	
	void Component::Shutdown()
	{		
		OnShutdown();

		//Unregister and shutdown the event manager
		mEventMan.UnRegisterEventMsgBox(mExternalMsgBoxHandle);
	
		AP_ASSERT(mExternalMsgBoxHandle == NULL);
		mEventMan.Destroy();
	}

	void Component::RegisterListenEvent(Axiom::EventMsgId id)
	{
		AP_ASSERT( !mListenEvents.Contains( id ) );
		mListenEvents.Add(id);
	}

	bool Component::IsEventAccepted(const Axiom::EventMsg *baseMsg) const
	{
		return mListenAllEvents ? true : mListenEvents.Contains( baseMsg->GetGuidID() );
	}

	void Component::PushEventToListeners(const Axiom::EventMsg *baseMsg, bool sendEventToListener)
	{
		AP::ComponentManager::GetInstance()->PushEventToListeners( this, baseMsg, sendEventToListener );
	}

	void Component::Execute()
	{
		AP_ASSERT(mExternalMsgBoxHandle!=NULL);

		//DAY 10/17/2008 3:34:34 PM  
		//We listen to events before update so that we may process any events sent to us by other components this frame.

		AP::ComponentManager::GetInstance()->ListenToEvents( this );

		mExternalMsgBoxHandle->ClearOutbox();
		
		OnUpdate();

		// Handle the intercomponent messagepump
		AP::ComponentManager::GetInstance()->PushEventsToListeners( this, mExternalMsgBoxHandle, mAutoSendEventToListener );

		mExternalMsgBoxHandle->ClearInbox();
	}

	float Component::GetFPS() const
	{
		return m_kernel->GetFPS();
	}

	void Component::OnGenericEvent(Axiom::EventData& gameEvent)
	{
		const Axiom::EventMsg* pMsg = gameEvent.GetEventMsg();
#ifdef __COMPONENT_VERBOSE__MODE__
		printf("                                                                                  COM[%s]                      INCOMING(%s-0x%x)\n",Name(), pMsg->GetName(),pMsg->GetSenderComponentId());
#endif
		mExternalMsgBoxHandle->ResendEvent(pMsg);
	}
}


//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		Kernel/component.h
//! @brief		Component API
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------

#ifndef __COMPONENT_H
#define __COMPONENT_H

#include <string/string.h>
#include <core/hashfunctions.h>
#include <eventsystem/eventman.h>
#include "kernel/signal.h"

namespace AP
{
    class ComponentClass;    
	class IEventListner;
	class Kernel;
	
	/*!
	 * \brief
	 * Implements the Component concept
	 * 
	 * A component has various characteristics:
	 *
	 *		- It knows what processor its on.
	 *		- It can send messages to other components (used primarily by the kernel components to send event data), even if they're
	 *		  live on different processors.
	 *		- It has the ability to bind to Lua, through functions, events and properties.
	 *		- It has a place in the NOH (Named Object Hierarchy) so has a concept of children.
	 *		- Has the ability to serialise itself to a stream.
	 *		- Has the ability to register event handlers to its local kernel.
	 *		- Knows where its local kernel is.
	 * 
	 * \remarks
	 * Write remarks for Component here.
	 * 
	 * \see
	 * Separate items with the '|' character.
	 */
		
	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		Component
	//!	@brief		API to a base component
	//! @ingroup	ComponentArchitecture
	//!
	//! A component is a shareable piece of code that has an init, update, shutdown, and event handler. 
	//! Each component can be specialized to implement a functionality, such as input, audio, logging, etc..
	//! A component can be run on any kernel in a thread safe manner.
	//---------------------------------------------------------------------------------------------------------------------------------
	class Component
	{
	public:
		static const int INVALID_COMPONENT_ID = Axiom::INVALID_SENDER_COMPONENT_ID;
		typedef Axiom::UInt32 ComponentHashID;																						//!< Component hash id

		// --------------- interface --------------------
		Component (Axiom::ConstStr name, AP::Kernel* kernel, bool autoSendEventToListener = true);		
		virtual ~Component ();
		
		// ---------------------------------- Must override calls -------------------------------------------------------------
		virtual void						OnInit() = 0;																		//!< Ensure that the specialized component does proper initialization
		virtual void						OnUpdate() = 0;																		//!< Ensure that the specialized component handles update calls
		virtual void						OnShutdown() = 0;																	//!< Ensure that the specialized component handles shutdown calls
	
		// ---------------------------------- Optional management functions -------------------------------------------------------------
		void								RegisterListenEvent(Axiom::EventMsgId id);											//!< Register for events this component is interested in listening to
		void								ListenAllEvents(bool b) { mListenAllEvents = b; }									//!< Listen to all events, no registration of individual events required
		void								AutoEventSentToListener(bool b){mAutoSendEventToListener = b;}						//!< Automatically send local events to listening components.  If false, the specialized component must explicitly manage the sending of events to listening components
		ComponentHashID						GetClassHashId() const { return mHashNameId; }				//!< Get Component hash id
		Kernel*								GetKernel() const { return m_kernel; }												//!< Get the current kernel the component is running on
		Axiom::EventMan&					GetEventMan(){return mEventMan;}													//!< Get the event manager

		int									GetComponentID() const { return mComponentID; }
		void								SetComponentID( int componentID ) { mComponentID = componentID; }

		void								SetMsgBoxOverride( int in, int out, int filter)	{ mOverrideMessageBoxDefaults = 1; mInMsgBoxSize = in; mOutMsgBoxSize = out; mFilterSize = filter; }
	protected:
		// ---------------------------------- Protected members -------------------------------------------------------------
		Axiom::ConstStr						Name() const {return mName.AsChar();}														//!< Get the component name
		void								OnGenericEvent(Axiom::EventData& gameEvent);										//!< Internal signal call for getting external events
		void								Init();																				//!< Initialize the component and then call the specialized component's OnInit
		void								Execute();																			//!< Execute the update component and then call the specialized component's OnUpdate
		void								Shutdown();																			//!< Shutdown the component and then call the specialized component's OnShutdown

		float								GetFPS() const;																			//!< Get FPS of current component

		bool								IsEventAccepted(const Axiom::EventMsg *baseMsg) const;									//!< Is the event accepted by this component?

		void								PushEventToListeners(const Axiom::EventMsg *baseMsg, bool sendEventToListener);	//!< Push current event to listener components
		
		friend class Kernel;
		friend class ComponentManager;
	protected:
		int												mComponentID;		

		Axiom::EventMan									mEventMan;
		Axiom::EventMsgBoxHandle						mExternalMsgBoxHandle;		// This is where events to/from other components go.
		
	private:

		static const int								MAX_NUM_LISTEN_EVENT = 68;
		typedef Axiom::Collections::StaticList< Axiom::EventMsgId, MAX_NUM_LISTEN_EVENT > ListenEventArray;

		Kernel*											m_kernel;															//!< Current kernel component is running on
		Axiom::ShortString								mName;																//!< Name of component

		// Don't really want to grow the components, so 1 int should hold these...
		unsigned int									mOverrideMessageBoxDefaults:1;
		unsigned int									mInMsgBoxSize:10;
		unsigned int									mOutMsgBoxSize:10;
		unsigned int									mFilterSize:7;

		bool											mAutoSendEventToListener;											//!< Auto send of events to listener
		bool											mListenAllEvents;													//!< Automatically listen to all events, not only the ones in mListenEvents
		ComponentHashID									mHashNameId;														//!< Hash Id of component name
		ListenEventArray								mListenEvents;														//!< List of events to listen to
		
	public:
		AP_DECLARE_POLYMORPHIC_TYPE();
	};
}

#endif // __COMPONENT_H

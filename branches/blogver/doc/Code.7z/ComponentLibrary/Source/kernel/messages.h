#ifndef __MESSAGES_H
#define __MESSAGES_H

/* This enum holds all of the message ID's for components.
	Include this file in your component header */
#include <eventsystem/eventman.h>
#include <kernel/componentmanager.h>

namespace AP
{
// Send event macro
#define SEND_EVENT(theEvent)										\
{																	\
    AP::ComponentManager::GetInstance()->SendMessage(theEvent);		\
}

//	printf("                    COM[%s]  SendEvent(%s)\n", AP::ComponentManager::GetInstance()->ActiveComponent()->Name(),theEvent.GetName());

#define LOCAL_EVENT_MAN() AP::ComponentManager::GetInstance()->ActiveComponent()->GetEventMan()

} // namespace AP


#endif // __MESSAGES_H

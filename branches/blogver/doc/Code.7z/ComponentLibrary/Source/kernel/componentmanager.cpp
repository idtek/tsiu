// --------------------------------------------------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
// Copyright (c) 2007 by Action Pants Inc
//
// --------------------------------------------------------------------------------------------------------------------

#include <eventsystem/eventman.h>
#include "kernel/componentmanager.h"
#include <reflection/script.h>
using namespace Axiom;

namespace AP
{

	// ----------------------------------------------------------------------------------------------------------------
	AP_TYPE(ComponentManager)
		AP_COMMAND(SendMessage, "Send a message.");
		AP_COMMAND(FindComponent, "Finds the given component.");
	AP_TYPE_END()

	OverflowedMessageBuffer<ConnectionBuffer::NumberOfOverflowedMessages>* ConnectionBuffer::m_OverflowedMessages = NULL;

		
	// ----------------------------------------------------------------------------------------------------------------
	ComponentManager::ComponentManager()
		: m_NextComponentID(EInvalidComponentID)
		, m_MaxComponents(0)
		, m_pComponentConnectionBuffers(0)
	{
		Reflection::Script::Register("ComponentManager", Reflection::Instance(this), "Interface to the component manager!");
	}

	// ----------------------------------------------------------------------------------------------------------------
	ComponentManager::~ComponentManager()
	{
		Reflection::Script::Unregister("ComponentManager");
	}

	void ComponentManager::InitComponentManager(Axiom::Memory::HeapId heapId, unsigned int MaxKernels, unsigned int MaxComponents)
	{
		m_KernelList.Resize(heapId, MaxKernels);
		m_ComponentList.Resize(heapId, MaxComponents);
		m_MaxComponents = MaxComponents;
		m_pComponentConnectionBuffers = AP_NEW(Axiom::Memory::DEFAULT_HEAP, ConnectionBuffer*[MaxComponents*MaxComponents]);
		for (unsigned int i = 0; i < MaxComponents; ++i)
		{
			for (unsigned int j = 0; j < MaxComponents; ++j)
			{
				m_pComponentConnectionBuffers[i * MaxComponents + j] = 0;
			}
		}
	}

	void ComponentManager::InitKernels(KernelConfig &config)
	{
		int numKernels = config.GetNumKernelConfigs();
		for(int i=0;i< numKernels; ++i)
		{
			KernelConfig::Config info = config[i];
			CreateKernel(info.kernelId, info.name, info.processId, info.priority, info.mainHeapId);
		}
	}

	void ComponentManager::Connect(Component* pComponent1, Component* pComponent2,const ConnectType connectType, int fromAToB, int fromBToA)
	{
		// Check the Kernel ID's of the components
		bool areOnDifferentKernels  = ( pComponent1->GetKernel() != pComponent2->GetKernel());
		m_pComponentConnectionBuffers[pComponent1->GetComponentID() * m_MaxComponents + pComponent2->GetComponentID()] = AP_NEW(Axiom::Memory::DEFAULT_HEAP, ConnectionBuffer(pComponent1->GetComponentID(), pComponent2->GetComponentID(), areOnDifferentKernels, fromAToB));

		// If it's bi directional then create another signal..
		if(connectType == CT_BI_DIRECTION)
		{
			m_pComponentConnectionBuffers[pComponent2->GetComponentID() * m_MaxComponents + pComponent1->GetComponentID()] = AP_NEW(Axiom::Memory::DEFAULT_HEAP, ConnectionBuffer(pComponent1->GetComponentID(), pComponent2->GetComponentID(), areOnDifferentKernels, fromBToA));
		}
	}
	
	ConnectionBuffer::ConnectionBuffer( int fromComponent, int toComponent, bool requiresMutex /*= false*/, int bufferSize /*= 256 */ ) : m_RequiresMutex(requiresMutex)
		, m_NumEventsIn(0)
		, m_HighWaterMark(0)
	{
		m_Size = bufferSize;
		m_MessageRingBuffer.Resize( Axiom::Memory::DEFAULT_HEAP, bufferSize );
		m_FromComponent = fromComponent;
		m_ToComponent = toComponent;
		if (m_OverflowedMessages==NULL)
			m_OverflowedMessages = AP_NEW(Axiom::Memory::DEFAULT_HEAP, OverflowedMessageBuffer<NumberOfOverflowedMessages> );
	}

	bool ConnectionBuffer::AddNewEvent( const Axiom::EventMsg *msg )
	{
		m_NumEventsIn++;
		if ( m_NumEventsIn > m_HighWaterMark )
		{
			m_HighWaterMark = m_NumEventsIn;
		}
		if (m_NumEventsIn > m_Size)
		{
			// This is pretty bad, it goes to the overflow buffer
			return false;
		}
		AP_ASSERTMESSAGE( !m_MessageRingBuffer.IsFull(), "Connection Ringbuffer overflow");
		m_MessageRingBuffer.Push( msg );

		return true;
	}
	
	Axiom::EventData* ConnectionBuffer::GetOldestEvent()
	{
		AP_ASSERTMESSAGE(m_NumEventsIn > 0, "Connection buffer underflow");
		if (m_MessageRingBuffer.Count() <= 0)
		{
			return 0;
		}
		return &m_MessageRingBuffer[0];
	}

	void ConnectionBuffer::PopOldestEvent()
	{
		AP_ASSERTMESSAGE(m_NumEventsIn > 0, "Connection buffer underflow");
		AP_ASSERTMESSAGE(m_MessageRingBuffer.Count() > 0, "Connection Ringbuffer underflow");
		
		m_MessageRingBuffer.Pop();
		m_NumEventsIn--;
		if (m_NumEventsIn==0)
		{
			AP_ASSERTMESSAGE(m_MessageRingBuffer.Count() == 0, "Connection Ringbuffer out of sync");
		}
	}

	void ComponentManager::DumpConnectionBufferInfo()
	{
		EnterExclusiveMode();
		Axiom::Log("ComponentManager","--------------- Intercomponent communications -----------------------------\n");
		for (unsigned int i=0;i<m_ComponentList.Count();i++)
		{
			
			Axiom::Log("ComponentManager","%3d : %s (%d)\n",i,m_ComponentList[i]->Name(), m_ComponentList[i]->GetComponentID());
		}
		Axiom::Log("ComponentManager","\n");
		Axiom::Log("ComponentManager","      ");
		for (unsigned int i=0;i<m_ComponentList.Count();i++)
			Axiom::Log("ComponentManager","%9d ",i);
		Axiom::Log("ComponentManager","\n");
		for (Axiom::UInt i=0;i<m_ComponentList.Count();i++)
		{
			Axiom::Log("ComponentManager","%5d ",i);
			for (Axiom::UInt j=0;j<m_ComponentList.Count();j++)
			{
				if (m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ] != 0)
				{
					if (m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ]->m_RequiresMutex)
						Axiom::Log("ComponentManager","%4d/%4d*",m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ]->m_HighWaterMark, m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ]->m_Size);
					else
						Axiom::Log("ComponentManager","%4d/%4d ",m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ]->m_HighWaterMark, m_pComponentConnectionBuffers[ i * m_MaxComponents +  j ]->m_Size);
				}
				else
				{
					Axiom::Log("ComponentManager","    -     ");
				}
			}
			Axiom::Log("ComponentManager","\n");
		}
		Axiom::Log("ComponentManager","--------------------------------------------\n");
		LeaveExclusiveMode();
	}


	void ComponentManager::PushEventsAcrossThreadBoundaries( int fromComponentID, int toComponentID, Axiom::EventMsgBoxHandle externalMsgBoxHandle )
	{
		Component* toComponent = m_ComponentList[ toComponentID ];
		Component* fromComponent = m_ComponentList[ fromComponentID ];
		// For now, always use the mutex
		// ...figure a TryLock would be nicer to detect problems and more importantly, signal them
		{
			// Push all our messages to the buffer
			// but only if that component is actually interested in said message (could do it in the read but takes more bufferspace then)
			if (externalMsgBoxHandle->GetNumEvents() != 0)
			{
				for (Axiom::UInt i=0;i<externalMsgBoxHandle->GetNumEvents();++i)
				{
					const Axiom::EventMsg *pMsg = externalMsgBoxHandle->GetEvent(i);
					const_cast<Axiom::EventMsg*>(pMsg)->SetSenderComponentId(fromComponent->GetClassHashId());

					if (toComponent->IsEventAccepted(pMsg))
					{
						m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Lock();
						if (!m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->AddNewEvent( pMsg ))
						{
							// Move the message to the overflow buffer
							ConnectionBuffer::m_OverflowedMessages->AddMessage( pMsg, fromComponentID, toComponentID );
						}
						m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Unlock();
					}
				}		
			}
		}
	}

	void ComponentManager::PushEventsToSameThread( int fromComponentID, int toComponentID, Axiom::EventMsgBoxHandle externalMsgBoxHandle )
	{
		// Since this message is not going across thread boundaries there can never be consuming and producing going 
		// on at the same time, so no mutexing is needed
		Component* toComponent = m_ComponentList[ toComponentID ];
		Component* fromComponent = m_ComponentList[ fromComponentID ];

		// Push all our messages to the buffer
		// but only if that component is actually interested in said message (could do it in the read but takes more bufferspace then)
		if (externalMsgBoxHandle->GetNumEvents() != 0)
		{
			for (Axiom::UInt i=0;i<externalMsgBoxHandle->GetNumEvents();++i)
			{
				const Axiom::EventMsg *pMsg = externalMsgBoxHandle->GetEvent(i);
				const_cast<Axiom::EventMsg*>(pMsg)->SetSenderComponentId(fromComponent->GetClassHashId());
				if (toComponent->IsEventAccepted(pMsg))
				{
					if (!m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->AddNewEvent( pMsg ))
					{
						// Move the message to the overflow buffer
						ConnectionBuffer::m_OverflowedMessages->AddMessage( pMsg, fromComponentID, toComponentID );
					}
				}
			}			
		}
	}

	void ComponentManager::PushEventAcrossThreadBoundaries( int fromComponentID, int toComponentID, const Axiom::EventMsg* baseMsg )
	{
		Component* toComponent = m_ComponentList[ toComponentID ];
		Component* fromComponent = m_ComponentList[ fromComponentID ];
		// For now, always use the mutex
		// ...figure a TryLock would be nicer to detect problems and more importantly, signal them
		{
			// Push all our messages to the buffer
			// but only if that component is actually interested in said message (could do it in the read but takes more bufferspace then)
			{
				{
					const Axiom::EventMsg *pMsg = baseMsg;
					const_cast<Axiom::EventMsg*>(pMsg)->SetSenderComponentId(fromComponent->GetClassHashId());

					if (toComponent->IsEventAccepted(pMsg))
					{
						m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Lock();
						if (!m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->AddNewEvent( pMsg ))
						{
							// Move the message to the overflow buffer
							ConnectionBuffer::m_OverflowedMessages->AddMessage( pMsg, fromComponentID, toComponentID );
						}
						m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Unlock();
					}
				}		
			}
		}
	}

	void ComponentManager::PushEventToSameThread( int fromComponentID, int toComponentID, const Axiom::EventMsg* baseMsg )
	{
		// Since this message is not going across thread boundaries there can never be consuming and producing going 
		// on at the same time, so no mutexing is needed
		Component* toComponent = m_ComponentList[ toComponentID ];
		Component* fromComponent = m_ComponentList[ fromComponentID ];

		// Push all our messages to the buffer
		// but only if that component is actually interested in said message (could do it in the read but takes more bufferspace then)
		{
			{
				const Axiom::EventMsg *pMsg = baseMsg;
				const_cast<Axiom::EventMsg*>(pMsg)->SetSenderComponentId(fromComponent->GetClassHashId());
				if (toComponent->IsEventAccepted(pMsg))
				{
					if (!m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->AddNewEvent( pMsg ))
					{
						// Move the message to the overflow buffer
						ConnectionBuffer::m_OverflowedMessages->AddMessage( pMsg, fromComponentID, toComponentID );
					}
				}
			}			
		}
	}


	void ComponentManager::GetEventsAcrossThreadBoundaries( int fromComponentID, int toComponentID )
	{
		// For now, always use the mutex
		// ....figure a TryLock would be nicer to detect problems and more importantly, signal them
		m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Lock();
		{
			// gobble up all the messages that are there
			Component* toComponent = m_ComponentList[toComponentID];

#if !CORE_FINAL
			// Give a message if the connection buffer needs to be resized
			if (m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn >
				m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Size )
			{
				Axiom::Log("ComponentManager","*****************************************************************************************************************\n");
				Axiom::Log("ComponentManager","ComponentConnections : Please increase the connection from %d (%s) to %d (%s) to at least %d (currently %d)\n",
					fromComponentID, m_ComponentList[fromComponentID]->Name(),
					toComponentID, m_ComponentList[toComponentID]->Name(),
					m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn, 
					m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Size );
				Axiom::Log("ComponentManager","*****************************************************************************************************************\n");
			}
#endif
			while (m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn > 0)
			{
				Axiom::EventData* workMessage;
				workMessage = m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->GetOldestEvent();
				if (workMessage)
				{
					toComponent->OnGenericEvent( *workMessage );
					m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->PopOldestEvent();
				}
				else
				{
					workMessage = ConnectionBuffer::m_OverflowedMessages->GetMessage( fromComponentID, toComponentID );
					toComponent->OnGenericEvent( *workMessage );
					ConnectionBuffer::m_OverflowedMessages->PopMessage( fromComponentID, toComponentID );
					m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn--;
				}
			}
		}
		m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Mutex.Unlock();
	}

	void ComponentManager::GetEventsFromSameThread(int fromComponentID, int toComponentID)
	{
		// Since this message is not going across thread boundaries there can never be consuming and producing going 
		// on at the same time, so no mutexing is needed
		Component* toComponent = m_ComponentList[toComponentID];
		// Give a message if the connection buffer needs to be resized
#if !CORE_FINAL
		if (m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn >
			m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Size )
		{
			Axiom::Log("ComponentManager","*****************************************************************************************************************\n");
			Axiom::Log("ComponentManager","ComponentConnections : Please increase the connection from %d (%s) to %d (%s) to at least %d (currently %d)\n",
								fromComponentID, m_ComponentList[fromComponentID]->Name(),
								toComponentID, m_ComponentList[toComponentID]->Name(),
								m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn, 
								m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_Size );
			Axiom::Log("ComponentManager","*****************************************************************************************************************\n");
		}
#endif
		while (m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn > 0)
		{
			Axiom::EventData* workMessage;
			workMessage = m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->GetOldestEvent();
			if (workMessage)
			{
				toComponent->OnGenericEvent( *workMessage );
				m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->PopOldestEvent();
			}
			else
			{
				workMessage = ConnectionBuffer::m_OverflowedMessages->GetMessage( fromComponentID, toComponentID );
				toComponent->OnGenericEvent( *workMessage );
				ConnectionBuffer::m_OverflowedMessages->PopMessage( fromComponentID, toComponentID );
				m_pComponentConnectionBuffers[ fromComponentID * m_MaxComponents +  toComponentID ]->m_NumEventsIn--;
			}
		}
	}

	void ComponentManager::ListenToEvents( Component* whatComponent )
	{
#if !CORE_FINAL & 0
		static int a = 0;
		a++;
		
		//if (dumpReport)
		if (a==100000)
		{
			a = 0;
			DumpConnectionBufferInfo();
		}
#endif
		// for each component check if I want to be notified of its messages
		int myID = whatComponent->GetComponentID();
		for (int i=0;i<m_MaxComponents;i++)
		{
			if (m_pComponentConnectionBuffers[ i * m_MaxComponents + myID ] != 0)
			{
				// stack this message in it's cross component buffer
				if (m_pComponentConnectionBuffers[ i * m_MaxComponents + myID ]->m_RequiresMutex)
				{
					// It's cross kernel so might want to use a mutex
					GetEventsAcrossThreadBoundaries( i, myID );
				}
 				else
 				{
 					GetEventsFromSameThread( i, myID );
 				}
			}
		}
	}

	void ComponentManager::PushEventToListeners( Component* fromComponent, const Axiom::EventMsg* baseMsg, bool sendEvents )
	{
		if (sendEvents)
		{
			// for each component see if it wants to be notified of our messages
			int myID = fromComponent->GetComponentID();
			for (int i=0;i<m_MaxComponents;i++)
			{
				if (m_pComponentConnectionBuffers[ myID * m_MaxComponents + i ] != 0)
				{
					// stack this message in it's cross component buffer
					if (m_pComponentConnectionBuffers[ myID * m_MaxComponents + i ]->m_RequiresMutex)
					{
						// It's cross kernel so might want to use a mutex
						PushEventAcrossThreadBoundaries( myID, i, baseMsg );
					}
					else
					{
						PushEventToSameThread( myID, i, baseMsg );
					}
				}
			}
		}
	}


	void ComponentManager::PushEventsToListeners( Component* fromComponent, Axiom::EventMsgBoxHandle externalMsgBoxHandle, bool sendEvents )
	{
		if (sendEvents)
		{
			// for each component see if it wants to be notified of our messages
			int myID = fromComponent->GetComponentID();
			for (int i=0;i<m_MaxComponents;i++)
			{
				if (m_pComponentConnectionBuffers[ myID * m_MaxComponents + i ] != 0)
				{
					// stack this message in it's cross component buffer
					if (m_pComponentConnectionBuffers[ myID * m_MaxComponents + i ]->m_RequiresMutex)
					{
						// It's cross kernel so might want to use a mutex
						PushEventsAcrossThreadBoundaries( myID, i, externalMsgBoxHandle );
					}
 					else
 					{
 						PushEventsToSameThread( myID, i, externalMsgBoxHandle );
 					}
				}
			}
#if 0
			// This really shouldn't be necessary since Outbox is cleared right after this and noone can touch it
			for (Axiom::UInt i=0;i<externalMsgBoxHandle->GetNumEvents();++i)
			{
				const Axiom::EventMsg *pMsg = externalMsgBoxHandle->GetEvent(i);
				const_cast<Axiom::EventMsg*>(pMsg)->SetSenderComponentId(fromComponent->GetClassHashId());
			}		
#endif
		}
	}

	Component* ComponentManager::FindComponent(Axiom::ConstStr name)
	{
		Component* pComponent = NULL;
		Component::ComponentHashID hashId = Axiom::CRC(name);

		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			pComponent = m_KernelList[i].m_pKernel->FindComponent(Component::ComponentHashID(hashId));

			if(pComponent)
			{
				break;
			}
		}
		return pComponent;
	}

	Kernel* ComponentManager::FindKernel(KernelIdType kernelId)
	{
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if(m_KernelList[i].m_pKernel->GetKernelId() == kernelId)
			{
				return m_KernelList[i].m_pKernel;
			}
		}
		return NULL;
	}

	// ----------------------------------------------------------------------------------------------------------------
	void ComponentManager::SendMessage(const Axiom::EventMsg& newMsg)
	{		
		ActiveComponent()->GetEventMan().DistributeEvent( &newMsg );
	}

	// ----------------------------------------------------------------------------------------------------------------
	Component* ComponentManager::ActiveComponent()
	{
		AP_ASSERTMESSAGE(GetCurrentKernel() != NULL, "KERNEL MUST BE GOOD!!");
		return GetCurrentKernel()->GetActiveComponent();
	}

	// ----------------------------------------------------------------------------------------------------------------
	const Component* ComponentManager::ActiveComponent() const
	{
		AP_ASSERTMESSAGE(GetCurrentKernel() != NULL, "KERNEL MUST BE GOOD!!");
		return GetCurrentKernel()->GetActiveComponent();
	}

	void  ComponentManager::InitializeAllComponents()
	{
#if CORE_WIN32
	MSG uMsg;
	Axiom::MemorySet(&uMsg, 0, sizeof(uMsg));
#endif
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			m_KernelList[i].m_pKernel->StartInitAndSuspend();

			// Wait until done intiailizing
			while(!m_KernelList[i].m_pKernel->IsInitDone())
			{

#if CORE_WIN32
				// We need to process window messages that might be posted from another thread during initialization
				if(PeekMessage( &uMsg, NULL, 0, 0, PM_REMOVE ))
				{ 
					TranslateMessage( &uMsg );
					DispatchMessage( &uMsg );
				}
#endif


				Axiom::Thread::Sleep(10);
			}
		}
	}
	
	void  ComponentManager::StartAllComponents()
	{
		// Each kernel is ready to resume! For each kernel, resume it..
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			m_KernelList[i].m_pKernel->Resume();
		}
	}


	void ComponentManager::RequestShutdown()
	{
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			m_KernelList[i].m_pKernel->Shutdown();
		}
	}


	bool ComponentManager::IsAllComponentActive()
	{
		bool bActive = false;
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if(!m_KernelList[i].m_pKernel->IsShutdownDone())
			{
				bActive = true;
				break;
			}
		}

		return bActive;
	}

	void ComponentManager::CreateKernel(unsigned int kernelId, Axiom::ConstStr name, int processorIndex, Axiom::Thread::ThreadPriority priority, const Axiom::Memory::HeapId mainHeapId)
	{
		
		Kernel* pKernel = AP_NEW(mainHeapId, Kernel(kernelId, name, mainHeapId));
		AP_FORCEASSERT(pKernel != 0, "Invalid Kernel");
		Axiom::Thread::ThreadId  threadId = Axiom::Thread::CreateThread(AP::Kernel::Main,
																		(Axiom::Thread::ThreadParam)(pKernel), 
																		priority,
																		processorIndex,
																		const_cast<char*>(name));
		
		pKernel->m_threadId = threadId;

		m_KernelList.AddDefault();
		KernelInfo& kernelInfo = m_KernelList.LastItem();

		// Kernel is setting the thread that is associated to the heap it is using so no other thread can use it..
		Axiom::Memory::SetThreadAllowed(pKernel->m_threadId, mainHeapId);

		kernelInfo.m_pKernel = pKernel;
		kernelInfo.m_pStaticName = name;
		kernelInfo.m_threadId = pKernel->GetThreadId();
		kernelInfo.m_threadPriority = priority;
	}

	void ComponentManager::SetKernelHeap(unsigned int kernelId, const Axiom::Memory::HeapId mainHeapId)
	{
		m_KernelList[kernelId].m_pKernel->SetHeapId(mainHeapId);
	}

	KernelInfo* ComponentManager::GetKernelInfo(KernelIdType kernelId)
	{
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if ( m_KernelList[i].m_pKernel && m_KernelList[i].m_pKernel->GetKernelId() == kernelId)
			{
				return &m_KernelList[i];
			}
		}

		return NULL;
	}
	
	const char* ComponentManager::GetKernelName(Axiom::Thread::ThreadId threadid)
	{
		for(unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if(m_KernelList[i].m_threadId == threadid)
			{
				return m_KernelList[i].m_pStaticName;
			}
		}

		return "NO_NAME";
	}
	
	Axiom::Thread::ThreadId ComponentManager::GetThreadId(KernelIdType kerId)
	{
		KernelInfo* pInfo = GetKernelInfo(kerId);
		AP_ASSERTMESSAGE(pInfo != NULL, "Kernel Must be added before call");
		return (pInfo != NULL) ? pInfo->m_threadId : Axiom::Thread::AP_INVALID_THREADID;
	}
	

	Axiom::Thread::ThreadId ComponentManager::GetCurrentThreadId() const
	{
		return Axiom::Thread::GetThreadId();
	}

	KernelIdType ComponentManager::GetKernelId ()
	{
		Axiom::Thread::ThreadId thread = GetCurrentThreadId();
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if (m_KernelList[i].m_threadId == thread)
			{
				return i;
			}
		}

		return -1;
	}

	Kernel* ComponentManager::GetCurrentKernel()
	{
		Axiom::Thread::ThreadId thread = GetCurrentThreadId();
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if (m_KernelList[i].m_threadId == thread)
			{
			return m_KernelList[i].m_pKernel;
			}
		}

		return NULL;
	}

	const Kernel* ComponentManager::GetCurrentKernel() const
	{
		const Axiom::Thread::ThreadId thread = GetCurrentThreadId();
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if (m_KernelList[i].m_threadId == thread)
			{
			return m_KernelList[i].m_pKernel;
			}
		}

		return NULL;
	}

	void ComponentManager::EnterExclusiveMode()
	{
		m_ExclusiveModeMutex.Lock();
		KernelIdType kernel = GetKernelId();
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if (m_KernelList[i].m_pKernel)
			{
				if (static_cast<int>(i) != kernel)
				{
					m_KernelList[i].m_pKernel->Suspend();
				}
			}
		}
		m_ExclusiveModeMutex.Unlock();
	}

	void ComponentManager::LeaveExclusiveMode()
	{
		m_ExclusiveModeMutex.Lock();
		KernelIdType kernel = GetKernelId();
		for (unsigned int i = 0; i < m_KernelList.Count(); ++i)
		{
			if (m_KernelList[i].m_pKernel)
			{
				if (static_cast<int>(i) != kernel)
				{
					m_KernelList[i].m_pKernel->Resume();
				}
			}
		}
		m_ExclusiveModeMutex.Unlock();
	}

	// ----------------------------------------------------------------------------------------------------------------

	template <int size>
	OverflowedMessageBuffer<size>::OverflowedMessageBuffer() 
	: m_HighWaterMark( 0 )
	{

	}

	template <int size>
	void OverflowedMessageBuffer<size>::AddMessage( const Axiom::EventMsg *msg, int fromComponent, int toComponent )
	{
		m_Mutex.Lock();
		m_OverflowBuffer.Add( OverflowedMessage( fromComponent, toComponent, msg ) );
#if !CORE_FINAL
		if (m_OverflowBuffer.Count() > m_HighWaterMark)	
		{
			Axiom::Log("ComponentManager","*************** ComponentConnections ********* OverFlowBuffer buffer touched (%d) - from %d to %d - %s\n", 
								m_OverflowBuffer.Count(),
								fromComponent,
								toComponent, 
								msg->GetName() );
			m_HighWaterMark = m_OverflowBuffer.Count();
		}
#endif
		m_Mutex.Unlock();
	}

	template <int size>
	Axiom::EventData* OverflowedMessageBuffer<size>::GetMessage( int fromComponent, int toComponent )
	{
		m_Mutex.Lock();
		Axiom::EventData* workMessage;
		bool found = false;
		int index = 0;
		for (unsigned int i=0;i<m_OverflowBuffer.Count();i++)
		{
			if (m_OverflowBuffer[i].m_ToComponent == toComponent)
			{
				found = true;
				index = i;
				break;
			}
		}
		AP_ASSERTMESSAGE( found, "Critical Error in overflow buffer GetMessage!");
		workMessage = &m_OverflowBuffer[index].m_Event;
		m_Mutex.Unlock();
		return workMessage;
	}

	template <int size>
	void OverflowedMessageBuffer<size>::PopMessage( int fromComponent, int toComponent )
	{
		// Since items are always added to the tail, it's always the first found - noone else can 
		// have removed it - for this sender/receiver pairing that is
		m_Mutex.Lock();
		bool found = false;
		for (unsigned int i=0;i<m_OverflowBuffer.Count();i++)
		{
			if (m_OverflowBuffer[i].m_ToComponent == toComponent)
			{
				found = true;
				m_OverflowBuffer.Remove(i);
				break;
			}
		}
		AP_ASSERTMESSAGE( found, "Critical Error in overflow buffer PopMessage!");
		m_Mutex.Unlock();
	}
} // namespace AP

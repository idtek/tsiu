//---------------------------------------------------------------------------------------------------------------------------------
//!	@file		Kernel/kernel.h
//! @brief		Kernel API
//
// Copyright (C) 2007 Action Pants Inc.
//---------------------------------------------------------------------------------------------------------------------------------
#ifndef __KERNEL_H
#define __KERNEL_H

#include <core/allocator.h>
#include <collections/array.h>
#include <collections/queue.h>
#include "kernel/coreglobalsignallist.h"
#include "kernel/component.h"
#include "kernel/systemtimer.h"

namespace AP
{
	typedef int			KernelIdType;
	const int			AP_DEFAULT_DEFERRED_CALL_BUFFFERSIZE = 128;

    class EventFilter;
	class Timer;

	//---------------------------------------------------------------------------------------------------------------------------------
	//!	@class		Kernel
	//!	@brief		API to create a run-able thread on a processor/hwThread
	//! @ingroup	ComponentArchitecture
	//!
	//! The kernel is an interface to create a run-able thread on a processor's hwThread.  The kernel 
	//! can hold a list of components.  Each kernel will be responsible in init, update, and shutdown of the components in the list.
	//---------------------------------------------------------------------------------------------------------------------------------
	class Kernel
	{
	public:
		//--------------------------------------------------- Public Members ---------------------------------------------
		static void						Sleep			(int microsecs);										//!< Tell the kernel to sleep
		Axiom::Memory::HeapId			GetHeapId		() const { return m_mainMemHeapId;}						//!< Get the kernel local memory heap
		void							SetHeapId		(Axiom::Memory::HeapId heapId) { m_mainMemHeapId = heapId;}

	protected:
		//-------------------------------------------- Constructor/Destructor -------------------------------------------
		Kernel(){}
		Kernel (unsigned int kernelId, Axiom::ConstStr name, const Axiom::Memory::HeapId mainHeapId);
		~Kernel ();

		//--------------------------------------------------- Members ---------------------------------------------------
		void							Suspend ();																//!< Suspend current kernel
		void							Resume ();																//!< Resume current kernel

		void							Shutdown(){m_quit = true;}												//!< Shutdown current kernel
		bool							IsShutdownDone();														//!< Is Shutdown done
		void							ShutdownDone();															//!< Performing a shutdown
		static void						Main(Axiom::Thread::ThreadParam);										//!< Main thread entry point

		bool							HasQuit() const		{ return m_quit; }									//!< Has kernel quit

		float							GetFPS() const {return m_Fps;}											//!< Get current frame rate from kernel
		KernelIdType					GetKernelId() const {return m_kernelId;}								//!< Get the kernel Id

		void							AttachComponent	(Component *pComponent);								//!< Attach a component to a kernel
		Component*						FindComponent(Component::ComponentHashID hashId);						//!< Find a component by hash id

		// Kernel Thread Startup!!
		void							StartInitAndSuspend();													//!< Start init and then wait for resume
		bool							IsInitDone();															//!< Check if all components are done initialization stage

		Axiom::Thread::ThreadId			GetThreadId() {return m_threadId;}										//!< Get current thread Id of kernel
		Component*						GetActiveComponent() const {return mActiveComponent;}					//!< Get Active component

		const char*						GetKernelName () const { return m_kernelName.AsChar(); };
	
		friend class KernelManager;
		friend class ComponentManager;
		friend class Component;

	private:

		void							SetInitDone();															//!< Notify that init is done
		Axiom::UInt32					SupsendCount();

		void							SetDebuggerThreadName ();
		
		typedef Axiom::Collections::Array<Component*,Axiom::Allocator</*Axiom::Memory::RESERVED_CORE_HEAP*/0/*##NA*/> > ComponentArray;

		int								m_kernelId;																//!< Kernel Id
		Axiom::Thread::ThreadId			m_threadId;																//!< Current hwThread Id

		Axiom::Thread::Mutex			m_runableLock;															//!< Runable mutex lock
		volatile bool					m_runable;																//!< Is thread inited

		Axiom::Thread::Mutex			m_readyLock;															//!< Runable mutex lock
		volatile bool					m_ready;																//!< Is thread ready

		volatile bool					m_shutdown;
		ComponentArray					m_componentlist;														//!< List of components
		Axiom::Memory::HeapId			m_mainMemHeapId;														//!< Main Heap Id

		volatile bool					m_quit;																	//!< Quit flag
		
		Axiom::UInt32					m_suspendFlag;															//!< Set >0 if the kernel update loop is disabled

		AP::System::Timer				m_Timer;																//!< local Timer
		float							m_RateLock;																//!< Lock frame rate
		float							m_Fps;																	//!< Frame per second

		Component*														mActiveComponent;						//!< Current active component on this kernel

		Axiom::StaticString<32>				m_kernelName;
	};
}

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

#endif // __KERNEL_H

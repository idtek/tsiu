/*!
 * Kernel implementation
 * 
 * Copyright (c) 2005 by Action Pants
 */
 
// class header
#include "kernel/kernel.h"
#include "kernel/componentmanager.h"

// other includes
#include "core/system.h"

//#include "kernel/timer.h"
#include <thread/mutex.h>
#include <thread/atomic.h>

const unsigned int MAX_KERNEL_COMPONENTS = 15;

const unsigned int MAX_SUS_PEND_COUNT = 1000;
#if CORE_FINAL
	#define OUTPUT_THREAD_DEBUG 0
#else
	#define OUTPUT_THREAD_DEBUG 0
#endif

using namespace Axiom::Thread;
namespace AP
{

	void Kernel::Sleep (int microsecs)
	{
		Axiom::Thread::Sleep(microsecs);
	}

	Axiom::UInt32 Kernel::SupsendCount()
	{
		return AtomicRead(&m_suspendFlag);
	}

	void Kernel::Suspend ()
	{
		AP_ASSERT(SupsendCount()>=0 && SupsendCount() <= MAX_SUS_PEND_COUNT);
		AtomicIncrement(&m_suspendFlag);		
	}

	void Kernel::Resume ()
	{
		AtomicDecrement(&m_suspendFlag);
		AP_ASSERT(SupsendCount()>=0 && SupsendCount() <= MAX_SUS_PEND_COUNT);
	}

	bool Kernel::IsShutdownDone()
	{
		return m_shutdown;
	}
	//------------------------------------------------------------------------------------------------------------------------
	// Kernel methods
	//------------------------------------------------------------------------------------------------------------------------

	Kernel::Kernel (unsigned int kernelId, Axiom::ConstStr name, const Axiom::Memory::HeapId mainHeapId)
		: m_kernelId(kernelId)
		, m_threadId(Axiom::Thread::AP_INVALID_THREADID)
		, m_runable(false)
		, m_ready( false)
		, m_shutdown(false)
		, m_mainMemHeapId(mainHeapId)
		, m_quit(false)
		, m_suspendFlag(false)
		, m_RateLock(CORE_DEFAULT_FRAME_RATE)
		, m_kernelName(name)
	{
		m_componentlist.Reserve(MAX_KERNEL_COMPONENTS);
		Suspend();
	}

	Kernel::~Kernel ()
	{
	}

	//------------------------------------------------------------------------------------------------------------------------
	// Component Management
	//------------------------------------------------------------------------------------------------------------------------

	void Kernel::AttachComponent(Component *pComponent)
	{
		AP_FORCEASSERT(m_componentlist.Size() < MAX_KERNEL_COMPONENTS, "To many components");
		m_componentlist.PushBack(pComponent);
	}

	void Kernel::ShutdownDone()
	{
		m_shutdown = true;
	}

	Component*	Kernel::FindComponent(Component::ComponentHashID hashId)
	{
		for (ComponentArray::Iterator it = m_componentlist.Begin(); it != m_componentlist.End();	it++)
		{
			Component *pComponent = static_cast<Component*>(*it);
			if(pComponent->GetClassHashId() == hashId)
			{
				return pComponent;
			}
		}	
		return NULL;
	}

	void Kernel::SetDebuggerThreadName ()
	{
		// This bit of obscure code triggers an exception that the debugger catches and interprets
		// as a thread naming request.

#if (CORE_WIN32 || CORE_XBOX360) && CORE_DEBUG && !CORE_PS3
#if CORE_VISUALC
#pragma warning(push)
#pragma warning(disable:4311)
#endif
		DWORD buffer[4] = { 0x1000U, (DWORD)GetKernelName(), (DWORD)-1, 0x0000U };
		__try 
		{ 
			RaiseException (0x406D1388, 0, 4, buffer); 
		}
		__except(EXCEPTION_CONTINUE_EXECUTION) 
		{ 
		}
#if CORE_VISUALC
#pragma warning(pop)
#endif
#endif


	}

	//------------------------------------------------------------------------------------------------------------------------
	// Main loop
	//------------------------------------------------------------------------------------------------------------------------
	void Kernel::Main (Axiom::Thread::ThreadParam data)
	{
		Kernel* kernel = (Kernel*)data;

		kernel->m_threadId = Axiom::Thread::GetThreadId();

		kernel->SetDebuggerThreadName();

		// Suspend until we start the kernel!
		while(kernel->SupsendCount() > 0)
		{
			Sleep(10);
		}

		// Initializing the list of components
		for (ComponentArray::Iterator it = kernel->m_componentlist.Begin(); it != kernel->m_componentlist.End();	it++)
		{
			kernel->mActiveComponent = static_cast<Component*>(*it);
			kernel->mActiveComponent->Init();
		}
		
		kernel->mActiveComponent = NULL;

		kernel->SetInitDone();

		// Init and wait!! Suspend until resume!!
		kernel->Suspend();


		while(kernel->SupsendCount() > 0)
		{
			Sleep(5);
		}

		// Go through component updates..
		for(;;)
		{
			if(kernel->m_quit == true)
			{
				break;
			}

			if (kernel->m_suspendFlag > 0)
			{
				Sleep(0);
				continue;
			}

			kernel->m_Timer.Start();
	
			kernel->mActiveComponent = NULL;
			
			//
			// Update all components
			//
			for (ComponentArray::Iterator it = kernel->m_componentlist.Begin(); it != kernel->m_componentlist.End(); ++it)
			{
				kernel->mActiveComponent = (*it);
				kernel->mActiveComponent->Execute();
			}
			kernel->mActiveComponent = NULL;

			// Lock frame rate
			while(kernel->m_Timer.GetElapseTime() < kernel->m_RateLock)
			{
				Sleep(0);
			}

			// Calculate frame rate
			kernel->m_Fps = 1.f / kernel->m_Timer.GetElapseTime();
		}

		for (ComponentArray::Iterator it = kernel->m_componentlist.Begin(); it != kernel->m_componentlist.End(); ++it)
		{
			ComponentManager::GetInstance()->EnterExclusiveMode();
			kernel->mActiveComponent = static_cast<Component*>(*it);
			kernel->mActiveComponent->Shutdown();
			ComponentManager::GetInstance()->LeaveExclusiveMode();
		}
		
		for (ComponentArray::Iterator it = kernel->m_componentlist.Begin(); it != kernel->m_componentlist.End(); ++it)
		{
			kernel->mActiveComponent = static_cast<Component*>(*it);
			AP_DELETE(kernel->mActiveComponent);
		}

		kernel->mActiveComponent = NULL;
		kernel->ShutdownDone();
	}

	void Kernel::StartInitAndSuspend()
	{
		Resume();
	}

	void Kernel::SetInitDone()
	{
		m_readyLock.Lock();
		m_ready= true;
		m_readyLock.Unlock();
	}
	
	bool Kernel::IsInitDone()
	{
		bool temp = m_ready;
		m_readyLock.Lock();
		temp = m_ready;
		m_readyLock.Unlock();
		return temp;
	}

}

#ifndef CORE_AUDIO_COMPONENT_WII_H__
#define CORE_AUDIO_COMPONENT_WII_H__

#include "kernel/component.h"
#include "audiowii/audiosystem.h"
#include "core/time.h"

#define AUDIO_FMODEX

namespace AP
{
	namespace AudioWii
	{
		class AudioComponent: public Component, public AudioCallback
		{
		public:

			AudioComponent(Axiom::ConstStr name, AP::Kernel* kernel);
			~AudioComponent();
 
			virtual void					OnInit();
			virtual void					OnUpdate();
			virtual void					OnShutdown();
			void							OnSetVolume(int fVolume);
			
			// Callbacks from AudioSystem
			void							AudioStarted (int EventID, int SignalId);
			void							AudioEnded (int EventID, int SignalId);
			void							AudioError(const char*);
			void							SendAudioMessage(Axiom::EventMsg* pMsg);

		protected:
		private:
			AP::AudioWii::AudioSystemWii*	m_pAudioSystem;

			void							HandleEvents();

			void 							UpdateCameraBody(const Axiom::EventMsg* pMsg);
			void 							PlaySoundEvent(const Axiom::EventMsg* pMsg);
			void							SetDistanceScaling(const Axiom::EventMsg* pMsg);  
			void							StartUnitTest (const Axiom::EventMsg * msg);
			void							OnResourceLoaded(const Axiom::EventMsg * msg);
			void							UpdateTime ();



			Axiom::EventMsgBoxHandle		m_ComponentMsgBox;
		};
	}
}

#endif // CORE_AUDIO_COMPONENT_WII_H__

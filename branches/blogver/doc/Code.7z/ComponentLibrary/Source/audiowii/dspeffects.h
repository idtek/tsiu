#ifndef _DSPEFFECTS_H
#define _DSPEFFECTS_H

#include <core/classedenum.h>

namespace AP
{
	namespace AudioWii
	{
		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS AP_DECLARE_TYPE();

		// Filters - lowpass, highpass, bandpass
		CLASSEDENUM
		(
			FilterType, \
			CLASSEDENUM_ITEMSTART(Invalid) \
			CLASSEDENUM_ITEM(HighPass) \
			CLASSEDENUM_ITEM(LowPass) \
			CLASSEDENUM_ITEM(BandPass), \
			Invalid
		)

		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS

		// Reverb Properties
		struct ReverbProperties
		{
			ReverbProperties() :  mWetMix(0),
								  mReverbTime(7.0f),
								  mPreDelay(0.0f),
								  mDamping(0.4f),
								  mColoration(0.1f) {}; 

			ReverbProperties(float mix, float time, float predelay, float damping, float coloration) : 
								 mWetMix(mix),
								 mReverbTime(time),
								 mPreDelay(predelay),
								 mDamping(damping),
								 mColoration(coloration) {};
								
			float mWetMix;
			float mReverbTime;
			float mPreDelay;
			float mDamping;
			float mColoration;

			AP_DECLARE_TYPE();
		};
		
	}
}

#endif // _DSPEFFECTS_H
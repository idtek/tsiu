#ifndef _DSPUTILS_H
#define _DSPUTILS_H

#include <collections/list.h>

using namespace Axiom::Collections;

namespace AP
{
	namespace AudioWii
	{
		// convert a dB Value (reference 1.0) to a normalized float (0 -> 1.0 or higher)
		float dBToAmplitude(float dB);

		// convert a normalized float (0 -> 1.0 or higher) to a dB value from 1.0 reference
		float AmplitudeTodB(float amplitude);

		// evaluate a linear control point curve at a certain point
		float InterpLinear(DynamicList<float> controlPoints, float x);

		// evaluate a splined control point curve at a certain point
		float InterpSpline(DynamicList<float> controlPoints, float x);

		// evaluate a polynomial control point curve at a certain point
		float InterpPolynomial(DynamicList<float> controlPoints, float x);
		
	}
}

#endif
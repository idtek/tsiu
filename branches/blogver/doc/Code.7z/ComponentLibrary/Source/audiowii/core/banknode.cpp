#include "audiowii/banknode.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(BankNode)
			AP_DEFAULT_CREATE()
			AP_BASE_TYPE(Bank)
			AP_FIELD("ChildNodes", mChildren, "Child Nodes of this bank")
			AP_EXPLICIT_PROXY("AcademyLibrary", "AudioWii")
		AP_TYPE_END()


		void BankNode::LinkChildren(BankNode* pNode)
		{
			int ChildCount = pNode->mChildren.Count();

			AssetList& assetList = pNode->GetAssets();
			int AssetCount = assetList.Count();

			// link assets of the node this banknode 
			for(int i=0; i < AssetCount; i++)
		    {
			   assetList[i]->SetParentNode(pNode);
			}
			
			// link child nodes
			for(int i=0; i < ChildCount; i++)
			{
				BankNode* pChildNode = pNode->mChildren[i];  	
				pChildNode->mParentNode = pNode;
				LinkChildren(pChildNode);
			}
		}

		
		AudioPathString BankNode::GetPath(const BankNode* pNode)
		{
			const BankNode* pCurrentNode = pNode;

			char NewPath[BankNode::MAX_BANK_PATH_CHARS];
			char Path[BankNode::MAX_BANK_PATH_CHARS];
			
			Path[0] = '\0';
            while (true)
			{
				if (pCurrentNode->mParentNode == NULL)
				{
					break;
				}

				NewPath[0] = '/';
				NewPath[1] = '\0';
				Axiom::StringConcat(NewPath, pCurrentNode->GetName(), BankNode::MAX_BANK_PATH_CHARS);
				Axiom::StringConcat(NewPath, Path, BankNode::MAX_BANK_PATH_CHARS);
				Axiom::StringCopy(Path, NewPath, BankNode::MAX_BANK_PATH_CHARS);
				pCurrentNode = pCurrentNode->mParentNode;    
            }
            return Path;
		} 

		///////////////////////////////////////////////////////////////////////////////
		// Recursive function for finding a node given a full node path
		//
		// Checks the string 'nodePath' against the root node in the path.
		// i.e. looks for a child node in pNode with "node1" in "/node1/node2/node3", and returns
		// node2 if found, NULL otherwise.
		///////////////////////////////////////////////////////////////////////////////
		Playable* BankNode::NodeFromPath(AudioPathString nodePath, BankNode* pNode, bool exactMatch)
		{
			// Get the root part of the path...
			bool terminalNode = false;
			
			// Trim the leading "/" 
			nodePath = nodePath.SubString(1, nodePath.Length() - 1);

			// Look for the next "/"
			int secondDelimiterIndex = nodePath.Find("/");
			Axiom::ShortString rootNodeToFind;

			if (secondDelimiterIndex > 0)
			{
				// trim the remainder of the string
				rootNodeToFind	= nodePath.SubString(0, secondDelimiterIndex);
				nodePath		= nodePath.SubString(rootNodeToFind.Length(), nodePath.Length() - rootNodeToFind.Length());
			}
			else
			{
				// we're at our terminal node
				terminalNode = true;
				rootNodeToFind = nodePath;
			} 

			int childCount = pNode->mChildren.Count();
			int assetCount = pNode->GetAssets().Count();

			// check the assets:
			if (assetCount > 0)
			{
				Bank::AssetList& AssetList = pNode->GetAssets();	
				for(int i = 0; i < assetCount; i++)
				{
					const char* AssetName = AssetList[i]->GetName();

					if (!exactMatch)
					{
						if (Axiom::StringFindString(AssetName, rootNodeToFind.AsChar()) != NULL)
						{
							return pNode->GetAssets()[i];
						}
					}
					else if (rootNodeToFind == AssetName)
					{
						// assets are always terminal nodes, no need to check 'terminalNode'...
						// we found it
						return pNode->GetAssets()[i];
					}
				}
			}

			// check the child nodes:
			for(int i = 0; i < childCount; i++)
			{
				// check the children
				const char* BankName = pNode->mChildren[i]->GetName();
				if (!exactMatch)
				{
					if (Axiom::StringFindString(BankName, rootNodeToFind.AsChar()) != NULL)
					{
						if (terminalNode)
						{
							return pNode->mChildren[i];
						}
						else
						{
							return NodeFromPath(nodePath, pNode->mChildren[i], exactMatch);
						}
					}
				}
				else if (rootNodeToFind == BankName)
				{
					if (terminalNode)
					{
						return pNode->mChildren[i];
					}
					else
					{
						return NodeFromPath(nodePath, pNode->mChildren[i], exactMatch);
					}
				}				
			}
			
			return NULL;
		}

		void BankNode::IterateDown(Playable* pNode, BankNodeIterator iterator, void* pUserData, bool IterateIntoAssets)
		{
			// apply the function to this playable node
			iterator(pNode, pUserData);

			// if this is an asset, just return. no iteration required
			if (pNode->GetType() != AP_TYPEOF(BankNode))
			{
				return;
			}

			// if the flag is set, iterate over the playable assets of this bank/node:
			if (IterateIntoAssets)
			{  	   
				Bank::AssetList& AssetList = (static_cast<BankNode*>(pNode))->GetAssets();	
				int AssetCount = AssetList.Count();	
				for(int i=0; i < AssetCount; i++)
				{
					iterator(AssetList[i], pUserData); 
				} 
			}
			
			// and iterate into children
			BankNode* pBankNode = static_cast<BankNode*>(pNode);
			int ChildCount = pBankNode->mChildren.Count();		
			for(int i=0; i < ChildCount; i++)
			{
				BankNode* pChildNode = pBankNode->mChildren[i];
				IterateDown(pChildNode, iterator, pUserData, IterateIntoAssets);
			}
		}

		void BankNode::IterateUp(Playable* pNode, BankNodeIterator iterator, void* pUserData)
		{
			// apply the function to this playable node
			iterator(pNode, pUserData);

			// and iterate up to parent
			Bank* pParentNode = pNode->GetParentNode();
			if (pParentNode != NULL)
			{
				IterateUp(pNode->GetParentNode(), iterator, pUserData);
			}
		}
	}
}
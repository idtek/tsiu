#include "audiowii/audiocallback.h"

namespace AP
{
	namespace AudioWii
	{
		AudioCallback::AudioCallback()
		{

		}

		AudioCallback::~AudioCallback()
		{

		}
	}
}
#include "audiowii/asbparser.h"

namespace AP
{
	namespace AudioWii
	{
		
		ASBParser::ASBParser()
		{
			mRootPath			= "<not yet parsed>";
			mData				= NULL;
			mTotalSize			= 0;
			mNumSounds			= 0;
			mCurReadOffset		= 0;
			mFirstSoundOffset	= -1;
		}
			
		ASBParser::~ASBParser()
		{
			
		}

		Axiom::Bool ASBParser::ReadNextAtom(ASBAtom& atom)
		{
			char type[5];
			type[4] = '\0';

			Axiom::MemoryCopy(static_cast<void*>(type), &mData[mCurReadOffset], 4); // the four character type
			atom.mType = type;
			mCurReadOffset += 4;

			Axiom::MemoryCopy(static_cast<void*>(&atom.mSize), &mData[mCurReadOffset], 4); // the 32-bit size
			mCurReadOffset += 4;

			// check before reading past the end of the whole sound bank...
			AP_ASSERTMESSAGE(mCurReadOffset + atom.mSize <= mTotalSize, "Corrupt or missing data in AP soundbank '%s'", mRootPath);
			atom.mData = &mData[mCurReadOffset]; // the actual data

			int padding = 0;
			if (atom.mType == "data")
			{
				// the data pointer has to be 8-byte aligned (the tool puts the data into the bank aligned at 8)
				while((unsigned int)atom.mData % 8)
				{
					atom.mData = &mData[mCurReadOffset++];
					padding++;
				}
				padding = padding ? padding - 1 : 0;
			}

			if (padding)
			{
				atom.mSize -= padding;
				mCurReadOffset += atom.mSize - 1;
			}
			else
			{
				mCurReadOffset += atom.mSize;
			}

			return true;
		}


		Axiom::Bool	ASBParser::Init(char* pBankData, int size)
		{
			mRootPath			= "<not yet parsed>";
			mFirstSoundOffset	= -1;
			mTotalSize			= size;
			mData				= pBankData;

			ASBAtom atom;
			ReadNextAtom(atom);
			if(atom.mType != "ftyp")
			{
				// bail
				return false;
			}

			// file count
			ReadNextAtom(atom);
			if (atom.mType != "fcnt")
			{
				return false;
			}
			Axiom::MemoryCopy(&mNumSounds, atom.mData, sizeof(Axiom::Int32));
			AP_ASSERTMESSAGE(mNumSounds > 0 && mNumSounds < 2000, "Invalid number of sounds found in AP soundbank");

			// we should be at the first sound now... just check to make sure though
			mFirstSoundOffset = mCurReadOffset;

			ReadNextAtom(atom);
			if (atom.mType != "snd ")
			{
				AP_ASSERTMESSAGE(false, "Corrupt data found in soundbank '%s'", mRootPath);
				return false;
			}

			SeekToSound(0);

			// success!
			return true;
		}

		Axiom::Bool	ASBParser::GetSoundAt(int index, ASBSound& sound)
		{
			SeekToSound(index);

			ASBAtom atom;

			// read the sound atom- we only care about certain fields here
			ReadNextAtom(atom); // 'snd '
			ReadNextAtom(atom); // 'path'
			sound.mPath.AssignFromSubstring(reinterpret_cast<char*>(atom.mData), atom.mSize);

			ReadNextAtom(atom); // 'stor'
			sound.mStorageMode.AssignFromSubstring(reinterpret_cast<char*>(atom.mData), atom.mSize);
			
			ReadNextAtom(atom); // 'fmt '
			ReadNextAtom(atom); // 'rate'
			ReadNextAtom(atom); // 'chan'
			ReadNextAtom(atom); // 'data'
			sound.mSize = atom.mSize;
			sound.mData = atom.mData;
				
			return true;
		}

		void ASBParser::SeekToSound(int soundIndex)
		{
			if (soundIndex >= mNumSounds)
			{
				AP_ASSERTMESSAGE(false, "Invalid Sound Index requested (%d) in bank '%s'", soundIndex, mRootPath);
				return;
			}

			ASBAtom atom;
			mCurReadOffset = mFirstSoundOffset;
			for(int i = 0; i < soundIndex; i++)
			{
				// read the sound atom
				ReadNextAtom(atom); // 'snd ' - first ID atom
				ReadNextAtom(atom); // 'path' - full bank path of the sound
				ReadNextAtom(atom); // 'stor' - storage mode, "MEMORY" or "STREAMING"
				ReadNextAtom(atom); // 'fmt ' - format - mp3, pcm, gcadpcm, etc.
				ReadNextAtom(atom); // 'rate' - sample rate
				ReadNextAtom(atom); // 'chan' - channels
				ReadNextAtom(atom); // 'data' - actual data
			}		
		}
	}
}
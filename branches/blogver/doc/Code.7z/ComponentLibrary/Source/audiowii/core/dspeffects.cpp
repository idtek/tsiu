#include <audiowii/dspeffects.h>

namespace AP
{
	namespace AudioWii
	{
	    AP_TYPE(FilterType)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(ReverbProperties)
			AP_DEFAULT_CREATE()
			AP_FIELD("WetMix",			mWetMix,		"-100 = Completely Dry, 0 = Completely Wet")
			AP_FIELD("ReverbTime",		mReverbTime,	"Reverb Time, in seconds. Valid Range 0 -> 10.0")
			AP_FIELD("PreDelay",		mPreDelay,		"Pre-delay, in seconds. Valid Rnage 0.0 -> 0.1")
			AP_FIELD("Damping",			mDamping,		"Damping (Modulation Depth). Valid Range 0.0 -> 1.0")
			AP_FIELD("Coloration",		mColoration,	"Coloration (Reflections). Valid Range 0.0 -> 1.0")
			AP_ATTRIBUTE("DefaultValue", "{WetMix=-100.0}, ReverbTime=3.0, PreDelay=0.0, Damping=0.5, Coloration=0.5}")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

	}
}
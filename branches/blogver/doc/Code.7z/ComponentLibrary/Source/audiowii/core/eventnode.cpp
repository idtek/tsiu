#include "audiowii/eventnode.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(EventNode)
			AP_DEFAULT_CREATE()
			AP_BASE_TYPE(Event)
			AP_FIELD("ChildNodes", mChildren, "Child Nodes of this event")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		EventNode::EventNode() : mParentNode(NULL)
		{ 
			mChildren.Resize(Axiom::Memory::AUDIO_HEAP, 20); 
		}

		Axiom::StringCRC EventNode::GetPath(const EventNode* pNode)
		{
			const EventNode* pCurrentNode = pNode;

			char NewPath[EventNode::MAX_EVENT_PATH_CHARS];
			char Path[EventNode::MAX_EVENT_PATH_CHARS];
			
			Path[0] = '\0';
            while (true)
			{
				if (pCurrentNode->mParentNode == NULL)
				{
					// don't add the root node string
					break;
				}

				NewPath[0] = '/';
				NewPath[1] = '\0';
				Axiom::StringConcat(NewPath, pCurrentNode->GetName(), EventNode::MAX_EVENT_PATH_CHARS);
				Axiom::StringConcat(NewPath, Path, EventNode::MAX_EVENT_PATH_CHARS);
				Axiom::StringCopy(Path, NewPath, EventNode::MAX_EVENT_PATH_CHARS);
                pCurrentNode = pCurrentNode->GetParent();    
            }

            return Path;
		}

		///////////////////////////////////////////////////////////////////////////////
		// Recursive function for finding a node given a full node path
		//
		// Checks the string 'nodePath' against the root node in the path.
		// i.e. looks for a child node in pNode with "node1" in "/node1/node2/node3", and returns
		// node2 if found, NULL otherwise.
		///////////////////////////////////////////////////////////////////////////////
		EventNode* EventNode::NodeFromPath(Axiom::MediumString nodePath, EventNode* pNode)
		{
			// Get the root part of the path...
			bool terminalNode = false;
			
			// Trim the leading "/" 
			nodePath = nodePath.SubString(1, nodePath.Length() - 1);

			// Look for the next "/"
			int secondDelimiterIndex = nodePath.Find("/");
			Axiom::ShortString rootNodeToFind;

			if (secondDelimiterIndex > 0)
			{
				// trim the remainder of the string
				rootNodeToFind	= nodePath.SubString(0, secondDelimiterIndex);
				nodePath		= nodePath.SubString(rootNodeToFind.Length(), nodePath.Length() - rootNodeToFind.Length());
			}
			else
			{
				// we're at our terminal node
				terminalNode = true;
				rootNodeToFind = nodePath;
			} 

			int childCount = pNode->mChildren.Count();

			// check the child nodes:
			for(int i = 0; i < childCount; i++)
			{
				// check the children
				const char* BankName = pNode->mChildren[i]->GetName();
				if (rootNodeToFind == BankName)
				{
					if (terminalNode)
					{
						return pNode->mChildren[i];
					}
					else
					{
						return NodeFromPath(nodePath, pNode->mChildren[i]);
					}
				}				
			}
			
			return NULL;
		}

		void EventNode::LinkChildren(EventNode* pNode)
		{
			int ChildCount = pNode->mChildren.Count();
			
			for(int i=0; i < ChildCount; i++)
			{
				EventNode* pChildNode = pNode->mChildren[i];
				pChildNode->mParentNode = pNode;
				LinkChildren(pChildNode);
			}
		}
	}
}
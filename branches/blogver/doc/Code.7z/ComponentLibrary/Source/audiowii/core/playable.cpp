#include "audiowii/playable.h"
#include "audiowii/bank.h"
#include "audiowii/banknode.h"
#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "asyncloader/asyncloadermessages.h"
#include "resource/resourceinfotable.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(Playable)
			AP_DEFAULT_CREATE()
			AP_FIELD("Name", mName, "Asset Name")
			AP_FIELD("SoundProperties", mProperties, "Rendering Properties of the asset (volume, pan, delay, pitch, etc.)")
			AP_PROPERTY("MasterVolumeDB", GetMasterVolumeDB, SetMasterVolumeDB, "Master volume in dB (from reference, i.e. -90.4 to 0.0)")
			AP_COMMAND(LoadFromStream,"LoadFromStream")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		int Playable::mLoadsExpected;
		
		Playable::Playable()
		{
			mIsLoaded				= false;
			mPackage				= NULL;
			mIsPlaying				= false;
			mIsReverbEnabled		= false;
			mPauseCount 			= 0;
			mPausing				= false;
			mName					= "";   
			mVolumeEnvPositionMS	= 0;
			mApplyingRelease		= false;
			mApplyingVolumeEnv		= false; 
			mApplyingPitchEnv		= false;     
			mRefCount				= 0;
			mLoadsExpected			= 0;
			mIsMuted				= false;
			mUnloadWhenStopped		= false;
			mUnloadNextFrameCount	= 0;
			mIsLoading				= false;
			mCancelledLoad 			= false;
			mResumeVolume			= 0;
			mMaxPolyphony			= 4;
			mStartWaitingOnReady	= false;
			mLoadList.Resize(Axiom::Memory::DEFAULT_HEAP, 2);
			mStartNextFrame			= false;
			mDelayedStarts.Resize(Axiom::Memory::AUDIO_HEAP, 5); // shouldn't need more than this
		}

		void Playable::SetMasterVolumeDB(float dBVol)	
		{ 
			// Update the master dB volumes
			mProperties.mMasterVolumeDB = dBVol;

			if (mIsPlaying)
			{
				float SummedVolume = CalculateStartVolumeDB();
				SetVolumeDB(SummedVolume);
			}

		   BankNode::IterateDown(this, BankNodeIterators::ApplySummedVolume, NULL, true);
		}

		AudioPathString	Playable::GetLocalPath() const
		{
			AudioPathString path = BankNode::GetPath(mParentNode);
			path += "/";
			path += GetName();
			return path;
		}

		void Playable::StreamLoadComplete(bool success)
		{	
			if (success)
			{
				mIsLoaded = true;
				if (mStartWaitingOnReady)
				{
					Vector3 vec(0, 0, 0);
					mStartNextFrame = true; // can't call FMOD functions from within FMOD callbacks... so just set a flag
					mStartWaitingOnReady = false;
					AudioSystem_FMOD::GetInstance()->AddPlayingNode(this); // so UpdateTime() gets called, otherwise we won't know when the next frame is ")
					AUDIOWII_LOG("audiowii", "Playable::StreamReady [%s] - Setting mStartNextFrame = true.", GetLocalPath().AsChar(), GetName());
				}
				else if (mIsLoading)
				{
					if (mCancelledLoad)
					{
						AUDIOWII_LOG("audiowii", "Playable::StreamReady [%s] - Cancelled Load flag set, setting mUnloadNextFrame = true.", GetLocalPath().AsChar(), GetName());
						UnloadNextFrame(true); // this node will already be in the Update() list because it's a stream
						mCancelledLoad = false;
					}
				}
			}
			else
			{
				UnloadNextFrame(true);
			}
			
			mIsLoading = false;
		}
		
		void Playable::UpdateTime(int deltaMilliseconds)
		{		  
			InternalVerifyStreams();
			  
			// while muted or paused, ignore this timeupdate - don't skip it if we're pausing w/ a fade out though
			if (mIsMuted || (mPauseCount > 0 && !mPausing))
			{
				return;
			}

			if (mUnloadNextFrameCount)
			{
				mUnloadNextFrameCount--;
				if(mUnloadNextFrameCount == 0)
				{
					Unload();
					return;
				}
			}
			
			if (mStartNextFrame)
			{
				// stream waiting for the disc to be ready, now it is. start it up. forget position info for now, as this only happens with streams
				AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
				mStartNextFrame = false;
				Vector3 vec(0, 0, 0);
				AUDIOWII_LOG("audiowii", "Playable::UpdateTime [%s] - mStartNextFrame == true, calling Play() again.", GetLocalPath().AsChar(),  GetName());
				Play(-1, vec, 50.0f, 0, false);  			
				return;
			}
			 
			deltaMilliseconds = 16; // Force one 60 FPS frame per time update 

			// Handle pitch envelope
			if (mApplyingPitchEnv && mDelayedStarts.Count() == 0)
			{
				mPitchEnvPositionMS += deltaMilliseconds;

				if (mPitchEnvPositionMS > mPitchEnvDurationMS)
				{
					// end of pitch envelope
					mApplyingPitchEnv = false;
					mPitchEnvPositionMS = 0;

					// need this line incase we never faded at all (long frame)
					InternalSetPitch(mTargetFadePitch); 			
				}
				else
				{
					float newPitch = mInitialFadePitch + (static_cast<float>(mPitchEnvPositionMS / mPitchEnvDurationMS))*(mTargetFadePitch - mInitialFadePitch); 			
					InternalSetPitch(newPitch);
				}
			}
				
			// if we are delaying startup, check our counter and see if we're ready to fire it up
			if (mDelayedStarts.Count() > 0)
			{
				for(unsigned int i = 0; i < mDelayedStarts.Count(); i++)
				{
					if (i == mDelayedStarts.Count())
					{
						break;
					}

					mDelayedStarts[i].mDelayTimeRemaining -= deltaMilliseconds;

					if (mDelayedStarts[i].mDelayTimeRemaining <= 0)
					{   					
						if (!InternalPlay(mDelayedStarts[i].mEntityID, mDelayedStarts[i].mPosition, CalculateStartVolumeDB(), CalculateStartPitch()))
						{
							return;
						}
										
						mIsPlaying = true;

						// if the sound has an attack set, set up the volume fade
						if (mDelayedStarts[i].mEventAttack > 0)
						{
							//  need to set mIsPlaying == true
							SetVolumeDB(MIN_DB_VOLUME);
							SetVolumeFade(CalculateStartVolumeDB(), mDelayedStarts[i].mEventAttack);
						}

						mDelayedStarts.RemoveAt(i);
					}
				}
			}
			// Update volume envelope
			else if (mApplyingVolumeEnv)
			{
				mVolumeEnvPositionMS += deltaMilliseconds;
				if (mVolumeEnvPositionMS > mVolumeEnvDurationMS)
				{
					// End of the volume envelope
					mApplyingVolumeEnv = false;
					mVolumeEnvPositionMS = 0;

					// need this line incase we never faded at all (long frame)
					SetVolumeDB(mTargetFadeVolume);
					AUDIOWII_LOG("audiowii", "Playable::UpdateTime [%s] - Fade Envelope completed, forcing volume to %2.2f dB", GetName(), GetLocalPath().AsChar(), mTargetFadeVolume);
					
					// if we are applying a release, kill the sound now
					if (mApplyingRelease)
					{
						// End of the attack portion of the envelope
						AUDIOWII_LOG("audiowii", "Playable::UpdateTime [%s] - Killing sound, mApplyingRelease == true", GetLocalPath().AsChar(), mTargetFadeVolume, GetName());
						mApplyingRelease = false;
						InternalStop(-1); 
						mPauseCount = 0;
						mIsPlaying = false;
						mPausing = false;

						// NOTE: the unloadwhenstopped flag is set, it'll be unloaded automatically when it stops by the fmod callback
					}
					else if (mPausing)
					{
						mPausing 	= false;
						mPauseCount++;
						AUDIOWII_LOG("audiowii", "Playable::UpdateTime [%s] - Pausing (%d), mPausing == true", GetLocalPath().AsChar(), GetName(), mPauseCount);
						InternalPause();
					}
				}
				else
				{
					float newVolumeDB = mInitialFadeVolume + (static_cast<float>(mVolumeEnvPositionMS / mVolumeEnvDurationMS))*(mTargetFadeVolume - mInitialFadeVolume); 		
					SetVolumeDB(newVolumeDB);
				}
			}
		}

		void Playable::SetVolumeFade(float volumeTarget, float durationMilliseconds)
		{
			if (mIsMuted)
			{
				return;
			}

			if (volumeTarget == GetVolumeDB())
			{
				return;
			}

			// no duration? just set the volume
			if (durationMilliseconds == 0)
			{
				SetVolumeDB(volumeTarget);
			}

			// setup a volume fade to volumeTarget over durationMilliseconds - overriding other fade operations
			mApplyingRelease		= false;
			mApplyingVolumeEnv 		= true;
			mInitialFadeVolume  	= GetVolumeDB();
			mTargetFadeVolume		= volumeTarget;
			mVolumeEnvDurationMS 	= durationMilliseconds;
			mVolumeEnvPositionMS	= 0;
		}

		void Playable::SetPitchEnv(float pitchTarget, float durationMilliseconds)
		{
			if (mIsMuted || !mIsPlaying || !mIsLoaded)
			{
				return;
			}

			// no duration? just set the pitch
			if (durationMilliseconds == 0)
			{
				InternalSetPitch(pitchTarget);
			}

			// setup a volume fade to volumeTarget over durationMilliseconds - overriding other fade operations
			mApplyingPitchEnv 		= true;
			mInitialFadePitch		= InternalGetPitch();
			mTargetFadePitch  		= pitchTarget;
			mPitchEnvDurationMS		= durationMilliseconds;
			mPitchEnvPositionMS		= 0;
		}

		void Playable::SetPitchEnvRelative(float pitchTargetRelative, float durationMilliseconds)
		{
			if (mIsMuted || !mIsPlaying || !mIsLoaded)
			{
				return;
			}

			float internalPitch = InternalGetPitch();

			float pitchTargetAbsolute = internalPitch + pitchTargetRelative;

			// no duration? just set the pitch
			if (durationMilliseconds == 0)
			{
				InternalSetPitch(pitchTargetAbsolute);
			}

			// setup a volume fade to volumeTarget over durationMilliseconds - overriding other fade operations
			mApplyingPitchEnv 		= true;

			internalPitch 			= InternalGetPitch();
			mInitialFadePitch		= internalPitch;
			mTargetFadePitch  		= pitchTargetAbsolute;
			mPitchEnvDurationMS		= durationMilliseconds;
			mPitchEnvPositionMS		= 0;
		}

		void Playable::Load(bool bAsync)
		{
			if (mIsLoaded || mIsLoading)
			{
				// reset the sound, clearing the unloadwhenstopped flag (2nd param into stop())
				if (mApplyingRelease || mPausing)
				{
					mApplyingRelease = false;
					mPausing = false;
					Stop(0, false, -1);
				}
				return;
			}

			// queue the loads for MatchCommon streams which are loaded during gameplay. Need to give FMOD time to catch up the playing streams.		
			if (mProperties.mStorageMode == StorageMode::STREAMING && GetLocalPath().Find("/Streams/MatchCommon") != -1)
			{
				if (AudioSystem_FMOD::GetInstance()->StreamLoading())
				{
					if (!AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().Contains(this))
					{
						AUDIOWII_LOG("AudioSystemWii", "Playable::Load [%s] - Another stream is already loading, adding to queue.", GetLocalPath().AsChar(), GetName());
						AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().IncreaseAdd(Axiom::Memory::AUDIO_HEAP, this);
					}
					return;
				}

				AudioSystem_FMOD::GetInstance()->StreamLoading(true);
			}

			AUDIOWII_LOG("AudioSystemWii", "Playable::Load [%s] - Loading.", GetLocalPath().AsChar(), GetName());
			InternalLoad(bAsync);
		}
		
		void Playable::Unload()
		{
			if (!mIsLoaded)
			{
				if (mProperties.mStorageMode == StorageMode::STREAMING && AudioSystem_FMOD::GetInstance()->StreamLoading())
				{
					if (AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().Contains(this))
					{
						AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().Remove(this);
					}
				}

				if (mIsLoading)
				{
					// got Unload while it was in the middle of loading
					AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalUnload [%s] - Async Load in progress, setting mCancelledLoad to true.", GetLocalPath().AsChar(), GetName());
					mCancelledLoad = true; // this'll unload 
				}

				return;
			}
			
			if (mIsPlaying)
			{
				// if we're fading out, wait for the fade to complete
				if (mApplyingRelease || mPausing)
				{
					// just unload it when the release is finished
					mApplyingRelease = true;
					mPausing		 = false;
					mUnloadWhenStopped = true;
					mDelayedStarts.Clear();
					return;  					
				}
				else
				{
					// force stop it if we're in the middle of playing it - fade out if playing, hard stop if paused
					Stop(mPauseCount > 0 ? 0 : 400.0f, true, -1);
				}
			}
			else
			{
				 AUDIOWII_LOG("AudioSystemWii", "Playable::Unload [%s] - Unloading.", GetLocalPath().AsChar(), mName.AsChar());
				 if (InternalUnload() == true)
				 {
					 // unload may have failed due to stream still running, only reset these if it succeeds
					 mUnloadNextFrameCount = 0; 
					 mPauseCount = 0;
					 mDelayedStarts.Clear();
					 mStartWaitingOnReady = false;
				 }
			}
		}
		
		void Playable::Play(int entityID, Vector3& position, float attackMS, float delayMS, bool unloadWhenDone)
		{
			if (!mIsLoaded)
			{
				if (mIsLoading)
				{
					mStartWaitingOnReady = true;
					AUDIOWII_LOG("AudioSystemWii", "Playable::Play [%s] - Sound still loading, setting mStartWaitingOnReady flag.", GetLocalPath().AsChar(), mName.AsChar())
					return;
				}
				
				Axiom::Log("audiosystemwii", "WARNING: Received play command on asset '%s' which isn't loaded!", GetLocalPath());
#if !CORE_FINAL
				AudioWii::Events::AudioRemotingPlayEvent PlayEvent(GetLocalPath().AsChar(), CalculateStartVolumeDB());  			
				PlayEvent.mNotLoaded = true;
				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&PlayEvent);
				}
#endif
				return;
			}

			if (mIsMuted)
			{
				return;
			}

			// Check to see if we have a random missfire - if we do,  randomly ignore the start call
			if (mProperties.mRandomMissfire > 0)
			{
				float rand = mRandomizer.RandFloat(0, 100);
				if (rand < mProperties.mRandomMissfire)
				{
					return;
				}
			}

			// If we're fading to some volume, or applying a release and get a start command, just stop the fade-out
			if (mApplyingVolumeEnv)
			{
				mApplyingVolumeEnv = false;
				mApplyingRelease = false;
			}

			if (mProperties.mDelay > 0 || delayMS > 0)
			{
				// start the timer, don't start playing yet.
				// use the sum of the event delay (passed in) and the bank delay (member variable)
				DelayedStart start;
				start.mEntityID = entityID;
				start.mDelayTimeRemaining = mProperties.mDelay + delayMS;
				start.mEventAttack = attackMS;
				start.mPosition = position;
				mDelayedStarts.IncreaseAdd(Axiom::Memory::AUDIO_HEAP, start);
			}
			else 
			{ 		   		
				if (InternalPlay(entityID, position, CalculateStartVolumeDB(), CalculateStartPitch()) == false)
				{
					return;
				}

				mIsPlaying = true;
				
				if (attackMS > 0)
				{
					//  need to set mIsPlaying == true
					SetVolumeDB(MIN_DB_VOLUME);
					float startVolume = CalculateStartVolumeDB();
					SetVolumeFade(startVolume, attackMS); 
					mResumeVolume = startVolume;
				}
			}

			AudioSystem_FMOD* pAudioSystem = AudioSystem_FMOD::GetInstance();
			pAudioSystem->AddPlayingNode(this);
			mUnloadWhenStopped = unloadWhenDone;
		}

		void Playable::Stop(float releaseMS, bool unloadWhenStopped, int EntityID)
		{  	
			
			// Waiting to startup (got a Start(), but the node has the delay paramter set) 
			// Just cancel the pending startup
			if (mDelayedStarts.Count() > 0)
			{
				AUDIOWII_LOG("audiowii", "Playable::Stop [%s], in the delay of startup phase, ignoring and resetting", GetLocalPath().AsChar(), GetName());
				InternalStop(-1);
				mDelayedStarts.Clear();
				mPauseCount = 0;
				AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
				return;
			}
			
			if (!mIsPlaying || mStartWaitingOnReady)
			{
				//AUDIOWII_LOG("audiowii", "Playable::Stop [%s] ignoring mplay = false", GetLocalPath().AsChar(), GetName());

				if (mStartWaitingOnReady)
				{   	
					InternalStop(-1);
					mPauseCount = 0;
					mStartWaitingOnReady = false;
					AUDIOWII_LOG("audiowii", "Playable::Stop [%s] - Setting mStartWaitingOnReady = false", GetLocalPath().AsChar(), GetName());
					AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
				}
				return;
			}

			// Currently Paused? Just Kill the sound
			if (mPauseCount > 0)
			{
				AUDIOWII_LOG("audiowii", "Playable::Stop [%s] Forcing STOP, PauseCount > 0", GetLocalPath().AsChar(), GetName());
				mUnloadWhenStopped = unloadWhenStopped;
				InternalStop(-1);
				SetPlaying(false);
				mPausing = false;
				mPauseCount = 0;
				mApplyingVolumeEnv = false;

				// NOTE: the unloadwhenstopped flag is set, it'll be unloaded automatically when it stops by the fmod callback
			}
			else if (mPausing)
			{
				// fading out to pause. just set the release flag to true, keeping the prev requested fade time for the pause
				mApplyingRelease = true;
				mUnloadWhenStopped = unloadWhenStopped;
			}
			else if (releaseMS > 0)
			{  	
				// start the fade, set the flag	 
				AUDIOWII_LOG("audiowii", "Playable::Stop [%s]- releaseMS > 0, setting volume fade to %3.1f over %3.0f ms", GetLocalPath().AsChar(), GetName(), MIN_DB_VOLUME, releaseMS); 		
				SetVolumeFade(MIN_DB_VOLUME, releaseMS);
				mApplyingRelease = true;
				mUnloadWhenStopped = unloadWhenStopped;
			}
			else
			{
				// really, stop it.
			    AUDIOWII_LOG("audiowii", "Playable::Stop [%s] Forcing STOP, no release specified", GetLocalPath().AsChar(), GetName());
				mUnloadWhenStopped = unloadWhenStopped;
				InternalStop(EntityID);
				if (GetNumChannelsPlaying() == 0)
				{
					mPausing = false;
					mPauseCount = 0;
					mApplyingVolumeEnv = false;
					mIsPlaying = false;
				}

				// NOTE: the unloadwhenstopped flag is set, it'll be unloaded automatically when it stops by the fmod callback
			}

			mPauseCount = 0;
		}

		void Playable::Pause(float durationMilliseconds)	
		{		
			if (!mIsPlaying)
			{
				if (mDelayedStarts.Count() > 0)
				{
					mPauseCount++;
				}
				return;
			}
			else if (mPausing || mPauseCount > 0)
			{
				// already paused/pausing, add one to the pause count
				mPauseCount++;
				AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d]  - Paused already, incrementing pause count", GetLocalPath().AsChar(), GetName(), mPauseCount);
				InternalPause();
				return;
			}

			// If we have a duration for the pause event, don't kill the sound yet... let it fade out
			if (durationMilliseconds > 0)
			{
				mPausing = true;
				if (!mApplyingVolumeEnv)
				{
					mResumeVolume = GetVolumeDB();
					AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d]  - Getting resume volume from current volume (%2.2f dB - master is %2.2f)", GetLocalPath().AsChar(), GetName(), mPauseCount, GetVolumeDB(), mProperties.mMasterVolumeDB);
				}
				else if (!mPausing || mApplyingRelease)
				{
					// if we get a pause during a fade (fade not due to a pause),
					// just set the resume volume to whatever we were fading towards
					mResumeVolume = mTargetFadeVolume;
					AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d] - Pause received during fade - setting resume volume to target fade (%2.2f dB)", GetLocalPath().AsChar(), GetName(), mPauseCount, durationMilliseconds, mTargetFadeVolume);
				}
				
				AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d] - Pausing over %2.0f ms - setting resume volume to %2.2f dB", GetLocalPath().AsChar(), GetName(), mPauseCount, durationMilliseconds, mResumeVolume);
				SetVolumeFade(MIN_DB_VOLUME, durationMilliseconds);
			}
			else
			{
				mPauseCount++;
				if (!mApplyingVolumeEnv)
				{
					mResumeVolume = GetVolumeDB();
					AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d] - Getting resume volume from current volume (%2.2f dB - master is %2.2f)", GetLocalPath().AsChar(),  GetName(), mPauseCount, GetVolumeDB(), mProperties.mMasterVolumeDB);
				}
				else if (!mPausing || mApplyingRelease)
				{
					// if we get a pause during a fade (fade not due to a pause),
					// just set the resume volume to whatever we were fading towards
					mResumeVolume = mTargetFadeVolume;
					AUDIOWII_LOG("audiowii", "Playable::Pause [%s, %d] - Pausing detected during fade - setting resume volume to target fade (%2.2f dB)", GetLocalPath().AsChar(), GetName(), mPauseCount, mTargetFadeVolume);
				}
			  			   
				InternalPause();
			}
		}

		void Playable::Resume(float durationMilliseconds, float delayMS, bool forceRestart)
		{
			if (mIsMuted)
			{
				AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Muted so ignoring it", GetLocalPath().AsChar(), GetName(), mPauseCount);
				return;
			}

			if (!mIsLoaded)
			{
				AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Not loaded so ignoring it", GetLocalPath().AsChar(), GetName(), mPauseCount);
				return;
			}

			if (!mIsPlaying)
			{
				if (mDelayedStarts.Count() > 0)
				{
					// we were waiting to start the sound when the pause request came in.
					// decrement this, then UpdateTime() will resume the delay sequence
					mPauseCount--;
					return;
				}
				
				if (!forceRestart)
				{
					AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Not playing and not forcing restart.", GetLocalPath().AsChar(), GetName(), mPauseCount);
					return;
				}

				// force start it - ignore the fade in time
				Vector3 vec(0, 0, 0);
				Play(-1, vec, 0, delayMS, mUnloadWhenStopped);
				
				AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Got resume, not playing, forcing start, to %3.1f dB over %3.0f ms", GetLocalPath().AsChar(), GetName(), mPauseCount, mResumeVolume, durationMilliseconds);
			}   
			else
			{   			
				if (mPauseCount > 0 || mPausing)
				{  				
					if (!mPausing)
					{
						// this gets hit if we AREN'T currently pausing w/ a fade out
						mPauseCount--;
					}

					if (mPauseCount == 0 || forceRestart)
					{
						mPauseCount = 0;
						
						AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Resuming to %2.2f dB", GetLocalPath().AsChar(), GetName(), mPauseCount, mResumeVolume);
						
						// no more pauses, restart the sound
						if (durationMilliseconds > 0)
						{   
							SetVolumeFade(mResumeVolume, durationMilliseconds);
						} 					
						else
						{  	   
							SetVolumeDB(mResumeVolume);
						}
						
						InternalResume();
					}

					mPausing = false;
					
				}
				else 
				{
					AUDIOWII_LOG("audiowii", "Playable::Resume [%s, %d] - Not pausing or paused. Doing nothing.", GetLocalPath().AsChar(), GetName(), mPauseCount);
					return;
				}
			}
		}

		float Playable::GetRandomAttenuation()
		{
			if (mProperties.mRandomAttenuation > 0)
			{
				return mRandomizer.RandFloat(0, mProperties.mRandomAttenuation);
			}

			return 0;
		}

		float Playable::GetRandomPitch()
		{
			if (mProperties.mRandomPitch > 0)
			{
				return mRandomizer.RandFloat(-mProperties.mRandomPitch, mProperties.mRandomPitch);
			}

			return 0;
		}
				
		float Playable::CalculateStartVolumeDB()
		{
			// calc the summed dB volume of this object (traverse up the tree summing the dB volumes)
			float SummedVolumeDB = mProperties.mMasterVolumeDB;
			BankNode::IterateUp(mParentNode, BankNodeIterators::GetSummedVolume, &SummedVolumeDB);

			// knock off some amplitude if we have a random attenuation set
			SummedVolumeDB -= GetRandomAttenuation();

			// and apply the user volumes set in the FE (if we should)
			if (mProperties.mApplyUserVolumeSFX)
			{
				SummedVolumeDB += AudioSystem_FMOD::GetInstance()->GetUserVolumeSFX();
			}

			if (mProperties.mApplyUserVolumeMusic)
			{
				SummedVolumeDB += AudioSystem_FMOD::GetInstance()->GetUserVolumeMusic();
			}			
			
			return SummedVolumeDB;
		}

		float Playable::CalculateStartPitch()
		{
			// calc the summed dB volume of this object (traverse up the tree summing the dB volumes)
			float StartPitch = mProperties.mPitch;

			if (mProperties.mRandomPitch > 0)
			{
				// vary it by that amount (in cents)
				StartPitch += GetRandomPitch();
			}
			
			return StartPitch;
		}

		void Playable::Mute()
		{
			mIsMuted = true;
			mResumeVolume = GetVolumeDB();
			SetVolumeDB(-90.4);
		}

		void Playable::UnMute()
		{
			mIsMuted = false;
			SetVolumeDB(mResumeVolume);
		}

		
	}
}

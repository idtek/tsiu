#include "audiowii/event.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(Event)
			AP_DEFAULT_CREATE()
			AP_FIELD("Name", mName, "Event Name")
			AP_FIELD("Actions", mActions, "Event Actions")
			AP_FIELD("Volume", mVolume, "Event Volume (0 -> 1.0)")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		Event::Event()
		{
			mActions.Resize(Axiom::Memory::AUDIO_HEAP, 5);
		}


	}
}

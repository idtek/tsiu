#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "audiowii/audioeventmessages.h"
#include "audiowii/bank.h"
#include "audiowii/banknodeiterators.h"
#include "audiowii/event.h"
#include <math/vector3.h>
#include "math/vector3.h"
#include <string/stringutils.h>
#include "reflection/serialize.h"
#include "asyncloader/asyncloadermessages.h"
#include "resource/resourceinfotable.h"
#include "audiowii/asbparser.h"

using namespace Axiom;
using namespace Axiom::Collections;

#if CORE_FINAL
#define USE_PACKAGES CORE_YES
#elif CORE_SHIP
#define USE_PACKAGES CORE_YES
#elif CORE_DEBUG
#define USE_PACKAGES CORE_YES
#else
#define USE_PACKAGES CORE_NO
#endif

namespace AP
{	
	namespace AudioWii
	{		
		AP_TYPE(AudioSystemWii)
			AP_FIELD("RootEvent",		mRootEvent, 	"Audio Event Root Node")
			AP_FIELD("RootBank",		mRootBank, 		"Audio Asset Root Node")
			AP_FIELD("Enabled",			mEnabled,  		"Enable flag for event-driven audio")
			AP_FIELD("ActorPathMap",    mActorPathMap,  "Map of Actor Names to sub-paths for Actor Banks in the Bank Tree")
			AP_FIELD_USERDEBUG("LogEventPaths",	mLogEventPaths, "Enable flag for logging event paths to TTY") // when !CORE_FINAL
			AP_FIELD_USERDEBUG("LogRemoteMessages", mSendRemotingEvents, "Enable flag for logging via Remoting messages") // when !CORE_FINAL
			AP_FIELD_USERDEBUG("OutOfMemoryFMOD", mOutOfMemoryFMOD, "FMOD is out of Memory") // use the audio remoting event to signal the tool as well
			AP_FIELD_USERDEBUG("OutOfMemoryNative", mOutOfMemoryNative, "Native audio heap is out of memory")
			AP_COMMAND_USERDEBUG(UpdateMemoryStats, "Get the audio engine to send out a memory stat message")
			AP_COMMAND_USERDEBUG(ReloadBanks,		"Reload Banks, optionally reloading ALL banks")
			AP_COMMAND_USERDEBUG(PreviewEvent,	"Play an Event")
			AP_COMMAND_USERDEBUG(StopEvent,		"Stop an Event")
			AP_COMMAND_USERDEBUG(PlayNodePath,	"Play an Asset Node")
			AP_COMMAND_USERDEBUG(StopNodePath,	"Stop an Asset Node")
			AP_COMMAND_USERDEBUG(MuteNodePath,	"Mute an Asset Node")
			AP_COMMAND_USERDEBUG(BuildTree, "setup all of the child nodes in the tree")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(ActorPathEntry)
			AP_DEFAULT_CREATE()
			AP_FIELD("ActorName",  mActorName, 	"Name/Type of the Actor")
			AP_FIELD("SubPath",    mSubPath, 	"SubPath (Folder Name) in the bank tree")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		//----------------------------------------------------------------

		AudioSystemWii* AudioSystemWii::mInstance 			= NULL;
		Axiom::EventMsgBoxHandle AudioSystemWii::sAudioSystemMsgBox = NULL;
		int AudioSystemWii::mLoadsExpected = 0;
		Axiom::Collections::DynamicList< AudioCallback* > AP::AudioWii::AudioSystemWii::sCallbackList;

		// Hard-coded voice asset folders for FE Conversations
		const char* AudioSystemWii::sConversationVoiceFolders[NUM_FE_CONVERSATION_VOICES] = 
		{
			"Male0", 		// 0
			"Male1", 		// 1
			"Male2", 		// 2
			"Male3", 		// 3
			"Male4", 		// 4
			"Male5", 		// 5
			"Male6", 		// 6
			"Male7", 		// 7
			"Male8", 		// 8
			"Pele", 		// 9
			"Shady", 		// 10
			"Female1", 		// 11
			"Female0", 		// 12
			"EvilHead", 	// 13
			"Female2", 		// 14
			"Rabbids", 		// 15
			"Rayman", 		// 16
			"Altair", 		// 17
			"SamFisher", 	// 18
			"Jade", 		// 19
			"Prince", 		// 20
			"Female3",		// 21
			"Female4",		// 22
			"Male9"			// 23
		};
		
		//----------------------------------------------------------------

		AudioSystemWii* AudioSystemWii::GetInstance()
		{
			if (AudioSystemWii::mInstance == NULL)
			{
				AudioSystemWii::mInstance = AP_NEW(Axiom::Memory::AUDIO_HEAP, AudioSystem_FMOD);
				AP::Reflection::Script::Register("AudioSystemWii", AP::Reflection::Instance(AudioSystemWii::mInstance), "Audio Editor");
				AUDIOWII_LOG("audiosystemwii", "OOPS! AlexE accidentally submitted his verbose logging... go get him to turn it off", NULL, "");
			}
			return AudioSystemWii::mInstance;
		}

		//----------------------------------------------------------------

		AudioSystemWii::AudioSystemWii()
		{
			sCallbackList.Resize(Axiom::Memory::AUDIO_HEAP, 5);
			mIsInitialized = false;
			mEnabled = true;
			mStreamLoading = false;
			mLogEventPaths = false;
			mSendRemotingEvents = false;
			mOutOfMemoryFMOD	= false;
			mOutOfMemoryNative	= false;
			mStreamLoadFrameCountdown = 0;

			// Need this so Playable_FMOD doesn't get compiled out
			Playable_FMOD::Dummy();
			mPlayingNodes.Resize(Axiom::Memory::AUDIO_HEAP, 5);
			mNodesToUpdate.Resize(Axiom::Memory::AUDIO_HEAP, 5);
			mLoadList.Resize(Axiom::Memory::DEFAULT_HEAP, 5);

			sAudioSystemMsgBox = LOCAL_EVENT_MAN().RegisterAndCreateEventMsgBox("AudioSystem", Axiom::Memory::DEFAULT_HEAP, 1, 1, 0);
		}

		//----------------------------------------------------------------

		AudioSystemWii::~AudioSystemWii()
		{
			
		}

		//----------------------------------------------------------------
		//----------------------------------------------------------------

		// Recursive function that loads all assets of a bank (node)
		void AudioSystemWii::ReloadBankNodeAssets(BankNode* node)
		{
			// Load all of the assets of this node:
			ReflectedList< Axiom::AutoPointer< Playable > >& bankAssets = node->GetAssets();
			int numPlayableAssets = bankAssets.Count();
			for(int i = 0; i < numPlayableAssets ; i++)
			{
				bankAssets[i]->Unload();

				Axiom::Log("AudioSystemWii", "Loading Asset '%s'", bankAssets[i]->GetName());
				bankAssets[i]->Load(false);
				//LogMemoryStats();		
			}

			// Load the assets of the children of this node (recurse):
			BankNode::BankNodeList& ChildNodes = node->GetChildren();
			int numChildBankNodes = ChildNodes.Count();
			for(int i=0; i < numChildBankNodes; i++)
			{
				ReloadBankNodeAssets(ChildNodes[i]);
			}			
		}

		//----------------------------------------------------------------

		// Clear and reload all assets referenced by the Bank Tree
		void AudioSystemWii::ReloadAllAssets()
		{		
			Axiom::Timer timer;
			timer.Start();
			
			ReloadBankNodeAssets(&mRootBank);

			LogMemoryStats();
			Axiom::Log("audiosystem", "Loading Assets took %d ms", timer.GetTime().AsIntInMilliseconds());		
		}

		//----------------------------------------------------------------

		void AudioSystemWii::Destroy()
		{

		}

		//----------------------------------------------------------------
	
		void AudioSystemWii::ReloadBanks(bool bReloadAll)
		{
			ReloadAllAssets();
		}

		//----------------------------------------------------------------

		void AudioSystemWii::Initialize(int NumChannels)
		{

#if CORE_WII // only audio on Wii for now.
			// populate the event & bank trees
			AP::Reflection::Deserialize::FromFile("platform_audio:AudioBanks.rst", &mRootBank);	  
			AP::Reflection::Deserialize::FromFile("platform_audio:AudioEvents.rst", &mRootEvent);
			AP::Reflection::Deserialize::FromFile("platform_audio:AudioActors.rst", &mActorPathMap); 	  	
#else
			// Load the event tree for debugging
			//AP::Reflection::Deserialize::FromFile("platform_audio:AudioEvents.rst", &mRootEvent);
			mEnabled = false;
#endif
			// don't bother loading all the assets if we're not enabled.
			if (!mEnabled)
			{
				Axiom::Log("AudioSystemWii", "Audio is DISABLED. Assets will not be loaded.");
				return;
			} 		
			
			mRootEvent.SetName("EventRoot");

			// finalize trees (assign ParentNodes to all the children for faster traversal)
			BuildTree ();

			LoadParams params = { NULL, false };
			Playable* pNodeToLoad = NULL;
			
#if USE_PACKAGES
			// check for a sound package containing all the characters' assets (celeb, talent, and vox)
			Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			filePath += "_Packages/Static_FrontEnd.asb";
			Axiom::Resource::InfoTable* infoTable = Axiom::Resource::InfoTable::GetInstance();
			const Axiom::FileManager::FileInfo* info = infoTable->GetFileInfo( filePath.AsChar() );
			if (info->IsValid())
			{
				// Load the FE SFX from the bank
				char* data = static_cast<char*>(AP_ALIGNED_ALLOC( Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32), 32 ));
	
				AP_ASSERTMESSAGE((data != NULL), "Audio out of memory on initial load"); 
				
				Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
				fileManager->LoadFileSynchronous( *info, data );
				LoadAssetsFromASB(data,  info->GetSize(), info->m_FileNameString);
			}
			else
			{
				Axiom::Log("AudioSystem", "Warning, _Packages/Static_Frontend.asb doesn't exist, FE sounds are NOT loaded.");
			}

			filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			filePath += "_Packages/Static_Animations.asb";
			info = infoTable->GetFileInfo( filePath.AsChar() );

			if (info->IsValid())
			{
				// Load the Animation SFX from the bank
				char* data = static_cast<char*>(AP_ALIGNED_ALLOC( Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32), 32 ));
				AP_ASSERTMESSAGE((data != NULL), "Audio out of memory on initial load"); 			
				Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
				fileManager->LoadFileSynchronous( *info, data );
				LoadAssetsFromASB(data,  info->GetSize(), info->m_FileNameString);
			}
			else
			{
				Axiom::Log("AudioSystem", "Warning, _Packages/Static_Animations.asb doesn't exist, Animation sounds are NOT loaded.");
			}
#else
			// Load FE SFX
			pNodeToLoad = BankNode::NodeFromPath("/FE", &mRootBank);
			BankNode::IterateDown(pNodeToLoad, BankNodeIterators::Load, &params, true);

			 // Load Animation SFX
			pNodeToLoad = BankNode::NodeFromPath("/Animations", &mRootBank);
			BankNode::IterateDown(pNodeToLoad, BankNodeIterators::Load, &params, true);
			
#endif // USE_PACKAGES

			// Load FE Streams  
			pNodeToLoad = BankNode::NodeFromPath("/Streams/FE", &mRootBank);
			BankNode::IterateDown(pNodeToLoad, BankNodeIterators::Load, &params, false);
			
			// print out the longest string
			//BankNode::IterateDown(&mRootBank, BankNodeIterators::Unload, NULL, true);
			
			mIsInitialized = true;
			
		}

		void AudioSystemWii::SetUserVolume(AudioWii::Events::EUserVolumeType volumeType, float volume)
		{
			if (volumeType == AudioWii::Events::EUserVolumeType::Music)
			{
				// volume passed in is 0 -> 100. normalize and convert to dB
				mUserVolumeMusic =  AmplitudeTodB(volume/100.0f);

				// update volumes of playing streams right now...
				// just create a change gain action with no effect and fire it off. this will refresh the volumes to reflect
				EventActionChangeGainRestore changeGainAction;
				changeGainAction.mDuration = 0;
				for(unsigned int nodeIndex = 0; nodeIndex < mPlayingNodes.Count(); nodeIndex++)
				{
					changeGainAction.Execute(mPlayingNodes[nodeIndex]);
				}
				
			}
			else if (volumeType == AudioWii::Events::EUserVolumeType::SFX)
			{
				// volume passed in is 0 -> 100. normalize and convert to dB
				mUserVolumeSFX = AmplitudeTodB(volume/100.0f);
			}
		}


		void AudioSystemWii::UpdateEntityLocation(int id, Vector3 position)
		{
			for(unsigned int nodeIndex=0; nodeIndex < mPlayingNodes.Count(); nodeIndex++)
			{
				if (mPlayingNodes[nodeIndex]->GetType() == AP_TYPEOF(Playable_FMOD))
				{
					// only care about 3D sounds
					if (mPlayingNodes[nodeIndex]->GetProperties().mPositioningMode != PositioningMode::THREE_DIMENSIONAL)
					{
						continue;
					}
					
					const Axiom::Collections::DynamicList<Channel>& channels = static_cast<Playable_FMOD*>(mPlayingNodes[nodeIndex])->GetChannels();
					for(unsigned int i = 0; i < channels.Count(); i++)
					{
						if (channels[i].mEntityID == id)
						{
							FMOD_VECTOR pos;
							AudioSystem_FMOD::TranslateVector(position, &pos);
							FMOD_RESULT result = channels[i].mFMODChannel->set3DAttributes(&pos, NULL);
							AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting 3D attributes on sound '%s'", mPlayingNodes[nodeIndex]->GetName());
							break;
						}
					}
				}
			}
		}
		void	AudioSystemWii::BuildTree ()
		{
			BankNode::LinkChildren(&mRootBank);
			EventNode::LinkChildren(&mRootEvent);
		}

		//----------------------------------------------------------------
		
		void AudioSystemWii::RunScript(const char* script)
		{
			AP::Reflection::Script::Result r;
			r = AP::Reflection::Script::ExecuteFile(script);
			if (r.Error() != AP::Reflection::Script::SUCCESS)
			{
				const char* errorString = r.ToString();

				Log("AudioSystem", "Script Error! (%s): \n\t%s", script, errorString);
			}

			AP_ASSERTMESSAGE( r.Error() == AP::Reflection::Script::SUCCESS, "Error running game script");		
		}

		//----------------------------------------------------------------

		// This is called by the tool (private) to preview an event
		void AudioSystemWii::PreviewEvent(const char* EventPath)
		{
			AudioWii::Events::AudioPlaySoundEvent audioEvent;
			audioEvent.m_EventPath = EventPath;
			PlayEvent(&audioEvent);
		}

		bool AudioSystemWii::VerifyBankExists(Playable* pNode, AudioPathString NodePath)
		{
			if (pNode == NULL)
			{
 #if !CORE_FINAL
				if (mLogEventPaths)
				{
					// do a fast, text-only log
					Axiom::Log("audio", "*** Can't find bank/node '%s'", NodePath);

					if (mSendRemotingEvents)
					{
						// fire a remoting event  to let the desinger know
						AudioWii::Events::AudioRemotingBankNotFoundEvent NotFoundEvent(NodePath.AsChar());
						sCallbackList[0]->SendAudioMessage(&NotFoundEvent);
					}
				}  
#endif  
				return false;					
			} 
			else
			{
				return true;
			}

		}

		void AudioSystemWii::LoadFEVoice(const char* type, Axiom::Byte feVoiceID)
		{
			AudioPathString NodeName = "/Streams/Vox/FE/";
			NodeName += type;
			NodeName += "/";
			NodeName += sConversationVoiceFolders[feVoiceID];
			Playable* pNode = BankNode::NodeFromPath(NodeName, &mRootBank);
			
			VerifyBankExists(pNode, NodeName);
				
			if (pNode != NULL)
			{   
				EventActionLoad loadAction;
				loadAction.mAsync = true;    	
				loadAction.Execute(pNode);
			}

			// special case for voiceID == 5, this is sam fisher's voice - load HQ as well
			if (feVoiceID == 5)
			{
				NodeName = "/Streams/Vox/FE/";
				NodeName += type;
				NodeName += "/HQ";
				pNode = BankNode::NodeFromPath(NodeName, &mRootBank);
	
				// HQ only has Expl and RespNormal, don't bother loading the other ones
				if (VerifyBankExists(pNode, NodeName) == true)
				{  	   
					EventActionLoad loadAction;
					loadAction.mAsync = true;    	
					loadAction.Execute(pNode);
				}
			}
		}

		void AudioSystemWii::LoadPackageAsync(const char* packageName)
		{
			Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			filePath += "_Packages/";
			filePath += packageName;
			filePath += ".asb"; 

			Axiom::Resource::InfoTable* infoTable = Axiom::Resource::InfoTable::GetInstance();
			const Axiom::FileManager::FileInfo* info = infoTable->GetFileInfo( filePath.AsChar() );

			if (info->IsValid())
			{
#if !CORE_FINAL
				Axiom::ShortString path = "Package '";
				path += packageName;
				path += "'";
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(path.AsChar(), true, false);

				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&LoadEvent);
				}
#endif // CORE_FINAL
				Axiom::Log("AudioSystem", "Loading package '%s' ( %dK )", packageName, (info->GetSize() >> 10));
				
#if !CORE_FINAL
				if (!Axiom::Memory::CanAlloc(Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32)))
				{
					// try and load them individually.
					Axiom::MediumString listFilename = filePath.AsChar();
					listFilename += ".list";
					LoadAssetsFromASBList(listFilename);
					if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative == false)
					{
						AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative = true;   					
						AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(packageName);
					}
					return;
				}
				else if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative == true)
				{
					AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative = false;   					
					AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(packageName);
				}
#endif // CORE_FINAL
				void* data = AP_ALIGNED_ALLOC( Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32), 32 );
				
				if (data == NULL)
				{
					// try and load them individually.
					Axiom::MediumString listFilename = filePath.AsChar();
					listFilename += ".list";
					LoadAssetsFromASBList(listFilename);
					return;
				}
				
				ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestEvent asyncLoaderRequestEvent;
				asyncLoaderRequestEvent.m_FileInfo = info;
				asyncLoaderRequestEvent.m_pBuffer = data;

				AudioSystem_FMOD::sAudioSystemMsgBox->SendEvent(&asyncLoaderRequestEvent);
				AudioSystem_FMOD::sAudioSystemMsgBox->ClearOutbox();
				mLoadList.IncreaseAdd( Axiom::Memory::AUDIO_HEAP, Axiom::Pair< const Axiom::FileManager::FileInfo*, Axiom::Byte*  >(info, (Axiom::Byte*)data) );
				mLoadsExpected++;
			}
			else
			{
				AP_ASSERTMESSAGE(false, "Can't find audio package '%s'", packageName);
			}
		
		}

		void AudioSystemWii::LoadEntityAssets(const AudioWii::Events::AudioPlaySoundEvent* pLoadEvent)
		{			
			if (pLoadEvent->m_ActorName.Length() != 0)
			{   			
				char* actorName = const_cast<char*>(pLoadEvent->m_ActorName.AsChar());
				LoadParams params = { actorName, true };
     
				Playable* pNode = NULL;

#if USE_PACKAGES
				LoadPackageAsync(actorName);
#else

#if !CORE_FINAL
				Axiom::ShortString path = "All vocal assets for character '";
				path += actorName;
				path += "'";
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(path.AsChar(), true, false);

				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&LoadEvent);
				}
#endif // !CORE_FINAL
				Axiom::Log("AudioSystem", "Loading vocals (async) for actor '%s'", pLoadEvent->m_ActorName.AsChar());

				// create an EventAction to load the char specific vocals
				pNode = BankNode::NodeFromPath("/Vocals", &mRootBank);
				BankNodeIterators::Load(pNode, &params);

				Axiom::Log("AudioSystem", "Loading talent SFX (async) for actor '%s'", pLoadEvent->m_ActorName.AsChar());

				// do the same for the talents
				pNode = BankNode::NodeFromPath("/Talents", &mRootBank);
				BankNodeIterators::Load(pNode, &params);

				Axiom::Log("AudioSystem", "Loading celebration SFX for actor '%s'", pLoadEvent->m_ActorName.AsChar());

				// do the same for the celebrations
				pNode = BankNode::NodeFromPath("/Celebration", &mRootBank);
				BankNodeIterators::Load(pNode, &params);
#endif // USE_PACKAGES

				// load Ubi celebrations (they dont' have specific ones, so use their common character equivalents)
				char* actorNameCommon = NULL;
				if (pLoadEvent->m_ActorName == "Jade")
				{
					// Jade's a deer  	
					actorNameCommon = "Deer";
				}
				else if (pLoadEvent->m_ActorName == "Altair" || 
					pLoadEvent->m_ActorName == "Prince" || 
					pLoadEvent->m_ActorName == "SamFisher" ) 
				{
					// All these guys are cats...    
					actorNameCommon = "Cat";
				}   

				if (actorNameCommon != NULL)
				{
					params.mActorName = actorNameCommon;

					Axiom::Log("AudioSystem", "Loading celebration SFX for actor '%s'", actorNameCommon);    
					pNode = BankNode::NodeFromPath("/Celebration", &mRootBank);
					BankNodeIterators::Load(pNode, &params);
				}

				// load the random rabbids stuff if there are rabbids on the pitch
				if (pLoadEvent->m_ActorName == "Rabbid")
				{
					params.mActorName = NULL;
					pNode = BankNode::NodeFromPath("/Vocals/Rabbid_Randoms", &mRootBank);
					BankNodeIterators::Load(pNode, &params);
				}
			}
			else if (pLoadEvent->m_VoiceID != 255)
			{
				LoadFEVoice("Ques", 		pLoadEvent->m_VoiceID);
				LoadFEVoice("Expl", 		pLoadEvent->m_VoiceID);
				LoadFEVoice("RespHappy", 	pLoadEvent->m_VoiceID);
				LoadFEVoice("RespNorm", 	pLoadEvent->m_VoiceID);
				LoadFEVoice("RespSad", 		pLoadEvent->m_VoiceID);
			}
		}
		
		
		void AudioSystemWii::PlayEvent(const AudioWii::Events::AudioPlaySoundEvent* pPlaySoundEvent)
		{
			// Global enable / disable. Needed to bypass audio for the splash screens at startup. Could be use elsewhere...
			if (pPlaySoundEvent->m_EventPath == "/GlobalDisable")
			{
				mEnabled = false;
			}
			else if (pPlaySoundEvent->m_EventPath == "/GlobalEnable")
			{
				mEnabled = true;
			}
			else if (pPlaySoundEvent->m_EventPath == "/FrontEnd/Transition/Load/EntityAssets")
			{
				LoadEntityAssets(pPlaySoundEvent);
				return;
			}
		   
			if (!mEnabled)
			{   
				return;
			}
			
			AP_ASSERTMESSAGE(Axiom::StringLength(pPlaySoundEvent->m_EventPath.AsChar()) > 0, "Audio Event Received with no event path");
			
			AUDIOWII_LOG("audio", "Received event '%s'", NULL, pPlaySoundEvent->m_EventPath.AsChar());

			const Event* pEvent = EventNode::NodeFromPath(pPlaySoundEvent->m_EventPath.AsChar(), &mRootEvent);

			if (pEvent == NULL)
			{
#if !CORE_FINAL
				if (mLogEventPaths)
				{
					// do a fast, text-only log
					//Axiom::Log("audio", "*** Received unknown event '%s' - taking no Action", pPlaySoundEvent->m_EventPath.AsChar());

					if (mSendRemotingEvents)
					{
						// fire a remoting event for debugging
						AudioWii::Events::AudioRemotingTriggerEvent TriggerEvent(pPlaySoundEvent->m_EventPath, pPlaySoundEvent->m_ActorName.AsChar(), false);
						sCallbackList[0]->SendAudioMessage(&TriggerEvent);
					}
				}
#endif
				return;
			}
			
#if !CORE_FINAL
			if (mLogEventPaths)
			{
					// do a fast, text-only log
					//Axiom::Log("AudioSystemWii", "Firing event '%s'", pPlaySoundEvent->m_EventPath.AsChar());

					if (mSendRemotingEvents)
					{
						// fire a remoting event for debugging
						AudioWii::Events::AudioRemotingTriggerEvent TriggerEvent(pPlaySoundEvent->m_EventPath, pPlaySoundEvent->m_ActorName.AsChar(), true);
						sCallbackList[0]->SendAudioMessage(&TriggerEvent);
					}
			}
#endif

			// Loop through the actions for this event
			const Event::EventActionList& EventActions = pEvent->GetActions();
			int iNumActions = EventActions.Count();
			for(int ActionIndex = 0; ActionIndex < iNumActions; ActionIndex++)
			{
				const EventAction* pAction = EventActions[ActionIndex];

				if (pAction->GetType() == AP_TYPEOF(EventActionSetMasterReverbProperties))
				{
					const EventActionSetMasterReverbProperties* pReverbAction = static_cast<const EventActionSetMasterReverbProperties*>(pAction);
					SetReverbProperties(pReverbAction->mReverbProperties);
					continue;
				}
				else if (pAction->GetType() == AP_TYPEOF(EventActionLoad) && static_cast<const EventActionLoad*>(pAction)->mPackageName != "")
				{
					// package loads have a different member variable for the package name so the bank list is empty
					pAction->Execute(NULL);
					continue;
				}
				
				// Get the bank names for bank nodes attached to this action
				const EventAction::PlayableNodeList& NodeNames = pAction->GetNodeList();
				int iNumBanks = NodeNames.Count();
						
				// Execute Action on all nodes
				for(int i = 0; i < iNumBanks; i++)
				{
					AudioPathString NodeName = *NodeNames[i];

					if (NodeName == "/AllPlayingAssets")
					{
						// special case, apply this action to all playing assets
						for(unsigned int nodeIndex=0; nodeIndex < mPlayingNodes.Count(); nodeIndex++)
						{
							pAction->Execute(mPlayingNodes[nodeIndex]);
						}
						continue;
					}
					else if (NodeName == "/AllLoopingAssets")
					{
						// special case, apply this action to all looping assets, and any randomfiring banks
						for(unsigned int nodeIndex=0; nodeIndex < mPlayingNodes.Count(); nodeIndex++)
						{
							// the action may remove a playing node - check to make sure
							if (nodeIndex >= mPlayingNodes.Count())
							{
								break;
							}
							
							if (mPlayingNodes[nodeIndex]->GetProperties().mLoopingMode == LoopingMode::START_MID_END &&
								mPlayingNodes[nodeIndex]->GetProperties().mStorageMode == StorageMode::MEMORY)
							{
								pAction->Execute(mPlayingNodes[nodeIndex]);
							}

							// the action above may remove a playing node - check to make sure
							if (nodeIndex >= mPlayingNodes.Count())
							{
								break;
							}
							
							if (mPlayingNodes[nodeIndex]->GetType() == AP_TYPEOF(BankNode))
							{
								BankNode* pBankNode = static_cast<BankNode*>(mPlayingNodes[nodeIndex]);
								if (pBankNode->GetPlaybackMode() == PlaybackMode::RANDOMFIRE)
								{
								   pAction->Execute(mPlayingNodes[nodeIndex]);
								} 
							}
						}
						continue;
					}

					Playable* pNode = BankNode::NodeFromPath(NodeName, &mRootBank);

					if (pNode != NULL)
					{
						// Check for actor-specific bank. We need to descend into the proper actor bank if needed
						if (pNode->GetType() == AP_TYPEOF(BankNode))
						{
							BankNode* pBankNode = static_cast<BankNode*>(pNode);
							if (pBankNode->IsActorSpecific() && pAction->GetType() == AP_TYPEOF(EventActionPlay))
							{
								NodeName += "/";

								if (pPlaySoundEvent->m_VoiceID == 255)
								{
									NodeName += pPlaySoundEvent->m_ActorName;
								}
								else if (pPlaySoundEvent->m_VoiceID == 200)
								{
									// HQ (with Sam fisher - special case)
									NodeName += "HQ";
								}
								else
								{
									AP_ASSERTMESSAGE(pPlaySoundEvent->m_VoiceID < NUM_FE_CONVERSATION_VOICES, "AudioSystem: Out of Range VoiceID for FE Conversation");
									NodeName += sConversationVoiceFolders[pPlaySoundEvent->m_VoiceID];
								}
								
								pNode = BankNode::NodeFromPath(NodeName, &mRootBank, false);

								// it may be a .wav/.dsp file, not a folder. 
								// try looking for that instead
								if (pNode == NULL)
								{
									pNode = BankNode::NodeFromPath(NodeName + ".dsp", &mRootBank, false);
								}   
							}
						}
						if (pNode != NULL)
						{
							if (pAction->GetType() == AP_TYPEOF(EventActionPlay))
							{
								EventAction* pUnconstAction 	= const_cast<EventAction*>(pAction);
								EventActionPlay* pPlayAction 	= static_cast<EventActionPlay*>(pUnconstAction);					
								pPlayAction->mPosition 			= Vector3(pPlaySoundEvent->m_X, pPlaySoundEvent->m_Y, pPlaySoundEvent->m_Z); 
								pPlayAction->mEntityID			= pPlaySoundEvent->m_EntityID;
							}
							else if (pAction->GetType() == AP_TYPEOF(EventActionStop))
							{
								EventAction* pUnconstAction 	= const_cast<EventAction*>(pAction);
								EventActionStop* pStopAction 	= static_cast<EventActionStop*>(pUnconstAction);					
								pStopAction->mEntityID			= pPlaySoundEvent->m_EntityID;
							}

							pAction->Execute(pNode);
						}
					}

					VerifyBankExists(pNode, NodeName);				
				}
			} 
		}

		//----------------------------------------------------------------

		void AudioSystemWii::PlayEvent(int EventID, const Axiom::Math::Vector3& Position, int DelayInMS, int Priority)
		{
		   // Not implemented yet - need directional info here first.
		}

		// Stop any playing assets in this event
		void AudioSystemWii::StopEvent(const char* EventPath)
		{	
			const Event* pEvent = EventNode::NodeFromPath(EventPath, &mRootEvent);

			if (pEvent == NULL)
			{
				return;
			}

			AUDIOWII_LOG("AudioSystemWii", "Stopping event '%s'", NULL, EventPath);

			// Loop through the actions for this event
			const Event::EventActionList& EventActions = pEvent->GetActions();
			int iNumActions = EventActions.Count();
			for(int ActionIndex = 0; ActionIndex < iNumActions; ActionIndex++)
			{
				const EventAction* pAction = EventActions[ActionIndex];

				// Get the bank names for banks attached to this action
				const EventAction::PlayableNodeList& NodeNames = pAction->GetNodeList();
				int iNumBanks = NodeNames.Count();
							
				if (pAction->GetType() == AP_TYPEOF(EventActionPlay))
				{

					// Stop playing all banks
					for(int i = 0; i < iNumBanks; i++)
					{
						StopNodePath((*NodeNames[i]).AsChar());
					}
				}

			} // for (each action in the event)
		}

		//----------------------------------------------------------------

		void AudioSystemWii::PlayNode(BankNode* pNode)
		{
			
		}

		//----------------------------------------------------------------

		void AudioSystemWii::StopNode(BankNode* pNode)
		{
			
		}

		//----------------------------------------------------------------

		void AudioSystemWii::PlayNodePath(const char* NodePath)
		{
			Playable* pNode = BankNode::NodeFromPath(NodePath, &mRootBank);
							
			if (pNode != NULL)
			{
				PlayParams params = { 0, 0, 0, 0, 0, 0 };
				BankNode::IterateDown(pNode, BankNodeIterators::Play, &params, false);
			}
		}

		//----------------------------------------------------------------

		void AudioSystemWii::StopNodePath(const char* NodePath)
		{
			Playable* pNode = BankNode::NodeFromPath(NodePath, &mRootBank);
							
			if (pNode != NULL)
			{
				StopParams params = { -1, 0, false };
				BankNode::IterateDown(pNode, BankNodeIterators::Stop, &params, false);
			}
		}


		// ----------------------------------------------------------------
		void AudioSystemWii::MuteNodePath(const char* NodePath, bool mute)
		{
			Playable* pNode = BankNode::NodeFromPath(NodePath, &mRootBank);
							
			if (pNode != NULL)
			{
				
				BankNode::IterateDown(pNode, (mute ? BankNodeIterators::Mute : BankNodeIterators::UnMute), NULL, false);
			}
		}
		//----------------------------------------------------------------

		void AudioSystemWii::AddPlayingNode(Playable* pNode)
		{
			if (mPlayingNodes.IsFull())
			{
				mPlayingNodes.IncreaseAndCopy(Axiom::Memory::AUDIO_HEAP, mPlayingNodes.Capacity()*2);
			}

			if (pNode->GetRefCount() == 0)
			{
				AUDIOWII_LOG("audiowii", "AudioSystemWii::AddPlayingNode [%s], adding node.", pNode->GetLocalPath().AsChar(), pNode->GetName(), pNode->GetRefCount());
				mPlayingNodes.Add(pNode);
			}

			if (pNode->GetProperties().mStorageMode == StorageMode::STREAMING && 
			    pNode->GetRefCount() > 0 && 
				pNode->GetType() == AP_TYPEOF(Playable_FMOD))
			{
				// streams only have one playing instance
				return;
			}
			
			pNode->IncrementRefCount();	
			AUDIOWII_LOG("audiowii", "AudioSystemWii::AddPlayingNode [%s], ref count is %d.", pNode->GetLocalPath().AsChar(), pNode->GetName(), pNode->GetRefCount());

		}

		//----------------------------------------------------------------

		void AudioSystemWii::RemovePlayingNode(Playable* pNode)
		{
			int AssetCount = mPlayingNodes.Count();
			for(int i=0; i < AssetCount; i++)
			{
				if (mPlayingNodes[i] == pNode)
				{
					while(pNode->GetRefCount() > 0)
					{
						pNode->DecrementRefCount();
					}
					
					AUDIOWII_LOG("audiowii", "AudioSystemWii::RemovePlayingNode [%s], ref count is %d.", pNode->GetLocalPath().AsChar(), pNode->GetName(), pNode->GetRefCount());
					
					if (pNode->GetRefCount() == 0)
					{
						mPlayingNodes.RemoveAt(i);
						AUDIOWII_LOG("audiowii", "AudioSystemWii::RemovePlayingNode [%s], removed.", pNode->GetLocalPath().AsChar(), pNode->GetName());
					}
					return;
				}
			}
		}

		void AudioSystemWii::AddNodeToUpdate(Playable* pNode)
		{
			mNodesToUpdate.IncreaseAdd(Axiom::Memory::AUDIO_HEAP, pNode);
		}
		
		void AudioSystemWii::RemoveNodeToUpdate(Playable* pNode)
		{
			for(unsigned int i=0; i < mNodesToUpdate.Count(); i++)
			{
				if (i >= mNodesToUpdate.Count())
				{
					break;
				}
				
				if (mNodesToUpdate[i] == pNode)
				{
					mNodesToUpdate.RemoveAt(i);
					AUDIOWII_LOG("audiowii", "AudioSystemWii::RemoveNodeToUpdate [%s], removed.", pNode->GetLocalPath().AsChar(), pNode->GetName());
				}
			}
		}

		//----------------------------------------------------------------
		
		void AudioSystemWii::PauseAllSounds(float fade)
		{
			for(Axiom::UInt i = 0; i < mPlayingNodes.Count(); i++)
			{
				mPlayingNodes[i]->Pause(fade);
			}
		}

		//----------------------------------------------------------------
		
		void AudioSystemWii::ResumeAllSounds(float fade)
		{
			for(Axiom::UInt i = 0; i < mPlayingNodes.Count(); i++)
			{
				mPlayingNodes[i]->Resume(fade, 0, false);
			}
		}

		//----------------------------------------------------------------

		// Recursive function that loads all assets of a bank (node)
		static void NotifyBankOfLoad(BankNode* node, const Axiom::FileManager::FileInfo* fileInfo)
		{
			// Load all of the assets of this node:
			ReflectedList< Axiom::AutoPointer< Playable > >& bankAssets = node->GetAssets();
			int numPlayableAssets = bankAssets.Count();
			for(int i = 0; i < numPlayableAssets ; i++)
			{
				bankAssets[i]->OnLoadFinished(fileInfo);
			}

			// Load the assets of the children of this node (recurse):
			BankNode::BankNodeList& ChildNodes = node->GetChildren();
			int numChildBankNodes = ChildNodes.Count();
			for(int i=0; i < numChildBankNodes; i++)
			{
				NotifyBankOfLoad(ChildNodes[i], fileInfo);
			}			
		}

		// .asb file parsing, individually loading files from an asb list
		void AudioSystemWii::LoadAssetsFromASBList(Axiom::MediumString filename)
		{
			Axiom::Resource::InfoTable* infoTable = Axiom::Resource::InfoTable::GetInstance();
			const Axiom::FileManager::FileInfo* info = infoTable->GetFileInfo( filename.AsChar() );
			if (info->IsValid())
			{
				// read the list file
				char* data = static_cast<char*>(AP_ALIGNED_ALLOC( Axiom::Memory::DEFAULT_HEAP, AP_ALIGN_TO(info->GetSize(), 32), 32 ));
	
				AP_ASSERTMESSAGE((data != NULL), "Audio out of memory loading an .asb list file"); 
				
				Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
				fileManager->LoadFileSynchronous( *info, data );
				
				LoadParams params;
				params.mActorName = NULL;
				params.mAsync = true;

				unsigned int curIndex = 0;
				AudioPathString NodePath = "";
				while(curIndex < info->GetSize())
				{
					if (data[curIndex] == '\n')
					{
						if (NodePath.Length() > 0)
						{
							NodePath = NodePath.Left(NodePath.Length() - 1);
							
							// load the node
							Playable* pNode = BankNode::NodeFromPath(NodePath, &mRootBank, true);
							if (pNode != NULL )
							{
								BankNode::IterateDown(pNode, BankNodeIterators::Load, &params, false);
							}

							NodePath = "";
						}
					}
					else
					{
						char temp[2] = { data[curIndex], '\0' };
						NodePath += temp;
					}
					
					curIndex++;
				}

				// catch the last line
				if (NodePath.Length() > 0)
				{
					// load the node
					Playable* pNode = BankNode::NodeFromPath(NodePath, &mRootBank, true);
					if (pNode != NULL )
					{
						BankNode::IterateDown(pNode, BankNodeIterators::Load, &params, false);
					}
				}
			}
			else
			{
				Axiom::Log("AudioSystem", "Warning, package list file '%s' doesn't exist, FE sounds are NOT loaded.", filename);
			}				
		}
		

		void AudioSystemWii::LoadAssetsFromASB(char* pPackageData, int size, Axiom::MediumString path)
		{
			ASBParser parser;
			parser.Init(pPackageData, size);
	
			// cache the package info, we'll need it when it's time to cleanup
			SoundPackage* pPackage 		= AP_NEW(Axiom::Memory::DEFAULT_HEAP, SoundPackage );
			pPackage->mName 			= path;
			pPackage->mData 			= pPackageData;
			pPackage->mRefCount 		= 0;
			mLoadedPackages.IncreaseAdd(Axiom::Memory::DEFAULT_HEAP, pPackage);
			
			ASBSound sound;
			Playable* pNode;
			for(int soundIndex = 0; soundIndex < parser.GetNumSounds(); soundIndex++)
			{
				parser.GetSoundAt(soundIndex, sound);
				
				pNode = BankNode::NodeFromPath(sound.mPath.AsChar(), &mRootBank );
	
				if (pNode != NULL)
				{
					if (sound.mStorageMode == "MEMORY")
					{
						pNode->InternalLoadFromPackage(sound.mData, sound.mSize, pPackage);
					}
					else if (sound.mStorageMode == "STREAM")
					{
						pNode->Load(true);
					}
					else
					{
						AP_ASSERTMESSAGE(false, "Invalid Storage Mode found in sound '%s', in soundbank '%s'", pNode->GetName(), pPackage->mName);
					}
				} 
			}
		}
		
		//----------------------------------------------------------------
		void AudioSystemWii::OnLoadFinished(const Axiom::FileManager::FileInfo* fileInfo )
		{
			//Axiom::Timer timer;
			//timer.Start();

			// get the node path from the fileInfo, and trim the platform path from the start (.i.e. /<platform>/Sounds)
			Axiom::FileManager::PlatformFilePathString platformPath;
			platformPath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			AudioPathString nodePath = fileInfo->m_FullFilePathString.Right(fileInfo->m_FullFilePathString.Length() - platformPath.Length() + 1).AsChar();
			nodePath = nodePath.Replace(".fsb", ".dsp");

			if (nodePath.Find(".asb") != -1)
			{
				// .asb file. parse it
				for(Axiom::UInt i = 0; i < mLoadList.Count(); i++)
				{
					if(fileInfo == mLoadList[i].first)
					{
						LoadAssetsFromASB(reinterpret_cast<char*>(mLoadList[i].second), fileInfo->GetSize(), fileInfo->m_FileNameString);
						mLoadList.RemoveAt(i);
						mLoadsExpected--;
					}
				}
			}
			else
			{
				Playable* pNode = BankNode::NodeFromPath(nodePath, &mRootBank);
	
				if (pNode)
				{
					pNode->OnLoadFinished(fileInfo);
				}
			}

			//Axiom::Log("audiosystem", "Notifying banks took %d ms", timer.GetTime().AsIntInMicroseconds());	 
		}

		void AudioSystemWii::IncrementPackageRef(SoundPackage* pPackage)
		{
			for(unsigned int i = 0; i < mLoadedPackages.Count(); i++)
			{
				if (mLoadedPackages[i] == pPackage)
				{
					pPackage->IncrementRefCount();
					break;
				}
			}
		}

		void AudioSystemWii::DecrementPackageRef(SoundPackage* pPackage)
		{
			for(unsigned int i = 0; i < mLoadedPackages.Count(); i++)
			{
				if (mLoadedPackages[i] == pPackage)
				{
					pPackage->DecrementRefCount();
					
					AUDIOWII_LOG("audiowii", "AudioSystemWii::DecrementPackageRef [%s] - Ref Count = %d.", pPackage->mName.AsChar(), pPackage->mName.AsChar(), pPackage->mRefCount);

					if (pPackage->mRefCount == 0)
					{
						Axiom::Log("AudioSystem", "No more references to package '%s', unloading.", pPackage->mName.AsChar());

						AP_DELETE(pPackage); // d'tor will free the sound bank memory slab
						mLoadedPackages.Remove(pPackage);
						
#if !CORE_FINAL
						AudioSystem_FMOD::GetInstance()->UpdateMemoryStats();
#endif
					}
				}
			}
		}
		
#if !CORE_FINAL
		void AudioSystemWii::UpdateMemoryStats()
		{
			AudioWii::Events::AudioRemotingMemoryUpdateEvent MemoryEvent;

			if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
			{
				AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&MemoryEvent);
			}
		}

		void AudioSystemWii::SendMemoryUpdate(AudioPathString assetPath)
		{
			AudioWii::Events::AudioRemotingMemoryUpdateEvent MemoryEvent;
			if (assetPath.Length() >= MemoryEvent.mAssetPath.Capacity())
			{
				MemoryEvent.mAssetPath = "...";
				MemoryEvent.mAssetPath += assetPath.Right(MemoryEvent.mAssetPath.Capacity() - 4);
			}
			else
			{
				MemoryEvent.mAssetPath = assetPath;
			}

			MemoryEvent.mOutOfMemoryFMOD 	= AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD;
			MemoryEvent.mOutOfMemoryNative 	= AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative;
				
			if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
			{
				AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&MemoryEvent);
			}
		}
#endif

		//----------------------------------------------------------------

		void AudioSystemWii::PauseToggle(bool bPaused)
		{

		}

		//----------------------------------------------------------------

		void AudioSystemWii::UpdateTime(int timedeltaMilliseconds)
		{
#ifdef AUDIOWII_LOGNODES
			static unsigned int frameCnt = 0;
			static const int frameUpdate = 60;
			frameCnt++;
#endif

			int NumPlayingNodes = mPlayingNodes.Count();
			for(int i=0; i < NumPlayingNodes; i++)
			{
				// update it each time because the UpdateTime might remove one...
				int updatedCount = mPlayingNodes.Count();
				if (i >= updatedCount)
				{
					break;
				}

				mPlayingNodes[i]->UpdateTime(timedeltaMilliseconds);
				
#ifdef AUDIOWII_LOGNODES
				if (frameCnt % frameUpdate == 0)
				{
					Axiom::Log("audiosystem", "Current Playing Node '%s'", mPlayingNodes[i]->GetLocalPath());
				}
#endif
			}
			
			for(unsigned int i=0; i < mNodesToUpdate.Count(); i++)
			{
				// don't updatetime() twice if the thing is playing
				if (!mPlayingNodes.Contains(mNodesToUpdate[i]))
				{
					mNodesToUpdate[i]->UpdateTime(timedeltaMilliseconds);
				}
			}

			if (mStreamLoadFrameCountdown > 0)
			{
				if (--mStreamLoadFrameCountdown == 0)
				{
					if (AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().Count() > 0)
					{
						Playable* pNode = AudioSystem_FMOD::GetInstance()->GetStreamsToLoad()[0];
						pNode->InternalLoad(true);
						AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().RemoveAt(0);
	
						AUDIOWII_LOG("audiowii", "AudioSystem_FMOD::FMODNonblockCallback - Sent next stream load in queue (%s)", NULL, pNode->GetName());
					}
				}
			}
		}

		//----------------------------------------------------------------

		void AudioSystemWii::UpdateCamera(Vector3 position, Vector3 direction, Axiom::Math::Vector3 top)
		{

		}

		void SoundPackage::DecrementRefCount()
		{
			if (mRefCount == 0) 
			{
				return;
			}
			
			--mRefCount;
		}
	}
}

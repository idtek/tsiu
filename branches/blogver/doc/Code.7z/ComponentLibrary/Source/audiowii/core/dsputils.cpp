#include <math/apmath.h>

namespace AP
{
	namespace AudioWii
	{
		// convert a dB Value (reference 1.0) to a normalized float (0 -> 1.0 or higher)
		float dBToAmplitude(float dB)
		{
			return Axiom::Math::Power(10, (dB/20.0f));
		}

		// convert a normalized float (0 -> 1.0 or higher) to a dB value from 1.0 reference
		float AmplitudeTodB(float amplitude)
		{
			return 20*Axiom::Math::Log(amplitude, 10.0f);
		}
	}
}
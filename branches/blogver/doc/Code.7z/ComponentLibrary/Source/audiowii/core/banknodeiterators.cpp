#include "audiowii/banknodeiterators.h"
#include "audiowii/banknode.h"
#include "audiowii/dsputils.h"
#include "core/pointer.h"

using namespace Axiom::Collections;

namespace AP
{
	namespace AudioWii
	{
		//////////////////////////////////////////////////////////////////////////////////////////
		// Get the summed volume (traverse up the tree summing Master Volumes). pUserData = float*
		//////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::GetSummedVolume(Playable* pPlayableObject, void* pUserData)
		{
			float* pSummedVolume = static_cast<float*>(pUserData);
			*pSummedVolume += pPlayableObject->GetMasterVolumeDB();

			// also apply random attenuation here
			*pSummedVolume -= pPlayableObject->GetRandomAttenuation();
		}


		////////////////////////////////////////////////////////////////////////////////////////
		// Apply / Update a bank's playing volume if a parent has been updated. pUserData is not used.
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::ApplySummedVolume(Playable* pPlayableObject, void* pUserData)
		{
			if (pPlayableObject->IsPlaying() == true)
			{
				pPlayableObject->SetVolumeDB(pPlayableObject->CalculateStartVolumeDB());
			}
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Load the audio data in the node
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Load(Playable* pPlayableObject, void* pUserData)
		{
			LoadParams* params 		= static_cast<LoadParams*>(pUserData);
			bool async 				= params->mAsync;
			const char* actorName 	= params->mActorName;

			if (pPlayableObject->GetType() == AP_TYPEOF(BankNode))
			{
				BankNode* pBank = static_cast<BankNode*>(pPlayableObject);

				if (pBank->IsActorSpecific())
				{
					if (actorName == NULL)
					{
						// load the bank, we're not looking to load a certain character
						pPlayableObject->Load(async);
					}
					
					// iterate through this nodes children and load if it matches the actor name
					for(unsigned int i = 0; i < pBank->GetChildren().Count();  i++)
					{
						if (Axiom::StringFindString(pBank->GetChildren()[i]->GetName(), actorName) != NULL)
						{
						   pBank->GetChildren()[i]->Load(async);

						   // and iterate down into this child, *without an actor name set* so we load everything in this node
						   // regardless of what the name of the child is
						   void *params[] 	= { &async, NULL };
						   BankNode::IterateDown(pBank->GetChildren()[i], BankNodeIterators::Load, params, false);
						}
					}

					// don't forget to look for playable (real assets, not banks) as well
					for(unsigned int i = 0; i < pBank->GetAssets().Count();  i++)
					{
						if (Axiom::StringFindString(pBank->GetAssets()[i]->GetName(), actorName) != NULL)
						{
						   pBank->GetAssets()[i]->Load(async); 
						}
					}
					
					return;
				}
				else
				{
					if (actorName == NULL)
					{
						// load the bank, we're not looking to load a certain character
						pBank->Load(async);
					}
					
				    // iterate through this nodes children
					for(unsigned int i = 0; i < pBank->GetChildren().Count();  i++)
					{
					   Load(pBank->GetChildren()[i], pUserData);
					}
				}   
			}
			else 
			{
				// it's an actual asset. load it.
				pPlayableObject->Load(async);
			}
		}

		 ////////////////////////////////////////////////////////////////////////////////////////
		// Unload the audio data in the node
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Unload(Playable* pPlayableObject, void* pUserData)
		{  
			pPlayableObject->Unload();

			//static int longest = 0;
			//static int count = 0;  		
			//OSReport("Node Name: (%d chars) '%s' \t (count = %d)\n", Axiom::StringLength(pPlayableObject->GetName()), pPlayableObject->GetName(), ++count);
			//if (Axiom::StringLength(pPlayableObject->GetName()) > longest)
		    //{
			//	longest = Axiom::StringLength(pPlayableObject->GetName());
			//	OSReport("\n\n\n*********Longest = %d\n", longest);
			//}
		}
		
		////////////////////////////////////////////////////////////////////////////////////////
		// Play the Bank in the node. 
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Play(Playable* pPlayableObject, void* pUserData)
		{
			PlayParams* params = static_cast<PlayParams*>(pUserData);
			  		
			Axiom::Math::Vector3 vec(params->mX, params->mY, params->mZ);
			pPlayableObject->Play(params->mID, vec, params->mAttack, params->mDelay, false);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Stop the the Bank in the node. pUserData[0] == float* == release time
		//                                pUserData[1] == float* == (1 == unload when done), 0 == don't
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Stop(Playable* pPlayableObject, void* pUserData)
		{
			StopParams* params = static_cast<StopParams*>(pUserData);
			pPlayableObject->Stop(params->mRelease, params->mUnloadWhenStopped, params->mEntityID);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Pause the Bank in the node. pUserData == float*, address of float with duration of
		// the fade in Milliseconds.
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Pause(Playable* pPlayableObject, void* pUserData)
		{
			float duration = *(static_cast<float*>(pUserData));
			pPlayableObject->Pause(duration);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Resume (un-pause) the Bank in the node. pUserData == float*, address of float with duration of
		// the fade back to full volume in Milliseconds.
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Resume(Playable* pPlayableObject, void* pUserData)
		{
			float duration		= (static_cast<float*>(pUserData))[0];
			float delay			= (static_cast<float*>(pUserData))[1];
			bool  forceRestart	= ((static_cast<float*>(pUserData))[2] == 1) ? true : false;
			pPlayableObject->Resume(duration, delay, forceRestart);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Mute
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::Mute(Playable* pPlayableObject, void* pUserData)
		{
			pPlayableObject->Mute();
		}

		 ////////////////////////////////////////////////////////////////////////////////////////
		// UnMute
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::UnMute(Playable* pPlayableObject, void* pUserData)
		{
			pPlayableObject->UnMute();
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Play the Bank in the node. pUserData is not used.
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::UpdateTime(Playable* pPlayableObject, void* pUserData)
		{
			int deltaMilliseconds = *(static_cast<int*>(pUserData));
			pPlayableObject->UpdateTime(deltaMilliseconds);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Change the gain with a delta (relative)
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::ChangeGainRelative(Playable* pPlayableObject, void* pUserData)
		{
			float dBChange = (static_cast<float*>(pUserData))[0];
			float durationMilliseconds = (static_cast<float*>(pUserData))[1];
			float newdBVolume = pPlayableObject->GetVolumeDB() + dBChange;
			pPlayableObject->SetVolumeFade(newdBVolume, durationMilliseconds);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Set the gain to an absolute value 
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::ChangeGainAbsolute(Playable* pPlayableObject, void* pUserData)
		{
			float dBVolume = (static_cast<float*>(pUserData))[0];
			float durationMilliseconds = (static_cast<float*>(pUserData))[1];
			pPlayableObject->SetVolumeFade(dBVolume, durationMilliseconds);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Restore the gain to it's original (master) volume
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::ChangeGainRestore(Playable* pPlayableObject, void* pUserData)
		{
			float durationMilliseconds = (static_cast<float*>(pUserData))[0];

			float newVolume = pPlayableObject->CalculateStartVolumeDB();

			if (!pPlayableObject->IsPaused() && pPlayableObject->IsPlaying() && !pPlayableObject->IsStopping())
			{
				// if it's currently playing, change the volume right away
				pPlayableObject->SetVolumeFade(newVolume, durationMilliseconds);
			}

			// this will catch paused sounds
			pPlayableObject->SetResumeVolume(newVolume);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Change the pitch - over duration milliseconds
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::SetPitch(Playable* pPlayableObject, void* pUserData)
		{
			float pitchChange = (static_cast<float*>(pUserData))[0];
			float durationMilliseconds = (static_cast<float*>(pUserData))[1];
			pPlayableObject->SetPitchEnv(pitchChange, durationMilliseconds);
		}

		////////////////////////////////////////////////////////////////////////////////////////
		// Change the pitch - over duration milliseconds, relative to current value
		////////////////////////////////////////////////////////////////////////////////////////
		void BankNodeIterators::SetPitchRelative(Playable* pPlayableObject, void* pUserData)
		{
			float pitchChange = (static_cast<float*>(pUserData))[0];
			float durationMilliseconds = (static_cast<float*>(pUserData))[1];

			pPlayableObject->SetPitchEnvRelative(pitchChange, durationMilliseconds);
		}
	}
}

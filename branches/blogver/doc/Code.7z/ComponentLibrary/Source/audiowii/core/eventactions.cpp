#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "audiowii/audiosystem.h"
#include "audiowii/audioeventmessages.h"
#include "audiowii/eventactions.h"
#include "audiowii/banknode.h"
#include "audiowii/banknodeiterators.h"
#include "reflection/type.h"


namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("NodeList",   mNodeList, 	"Banks/Nodes that the action is applied to")		
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionLoad)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Asynchronous", mAsync, "Load the file Asyncronously?");
			AP_FIELD("PackageName", mPackageName, "If loading a package, the name of the package. Leave blank for most loads - the bank paths are loaded individually");
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		 AP_TYPE(EventActionUnload)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()
		
		AP_TYPE(EventActionPlay)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
			AP_FIELD("Attack", 		mAttack, "Attack time, in milliseconds");
			AP_FIELD("Delay", 		mDelay,  "Startup Delay, (summed with the bank delay) ");
		AP_TYPE_END()

		AP_TYPE(EventActionStop)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
			AP_FIELD("Release",  	mRelease, "Release time, in milliseconds");
			AP_FIELD("UnloadWhenStopped",  mUnloadWhenStopped, "If true, asset is unloaded when stopped (after the release)")
		AP_TYPE_END()

		AP_TYPE(EventActionPause)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Release",       mRelease,		"Duration of the fade out (in Milliseconds)")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

	    AP_TYPE(EventActionResume)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Attack",         mAttack,		"Duration of the fade in (in Milliseconds)")
			AP_FIELD("Delay",          mDelay,		"Startup delay in (in Milliseconds)")
			AP_FIELD("ForceRestart",   mForceStart,	"If the sound isn't already playing, start it")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionChangeGainRelative)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("VolumeDelta",    mDeltaGainDB,	"Gain Change in dB. Valid Range -90.4 to + 90.4 dB")
			AP_FIELD("Duration",       mDuration,		"Duration of the fade in Milliseconds")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionChangeGainAbsolute)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Volume",         mAbsoluteGainDB,	"Absolute Gain in dB. Valid Range -90.4 to 0 dB")
			AP_FIELD("Duration",       mDuration,		"Duration of the fade in Milliseconds")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionChangeGainRestore)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Duration",       mDuration,		"Duration of the fade in Milliseconds")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		 AP_TYPE(EventActionSetPitch)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Duration",       mDuration,		"Duration of the pitch change, in Milliseconds")
			AP_FIELD("PitchChange",    mCents,	   		"Target Pitch, in Cents")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionSetPitchRelative)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Duration",       mDuration,		"Duration of the pitch change, in Milliseconds")
			AP_FIELD("PitchChange",    mCents,	   		"Target Pitch, in Cents")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionToggleDSPFilter)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("Enable",       mEnable,		"True to enable the filter, false to disable it")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionSetMasterReverbProperties)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("ReverbProperties", mReverbProperties, "Properties of the system master reverb")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(EventActionSetReverbSend)
			AP_BASE_TYPE(EventAction)
			AP_DEFAULT_CREATE()
			AP_FIELD("ReverbSend", mReverbSend, "Send gain to the system master reverb. -90.6 = OFF, ")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()


		void EventAction::Log(Playable* pNode) const
		{
#if !CORE_FINAL
			AudioPathString nodePath = BankNode::GetPath(static_cast<BankNode*>(pNode)).AsChar();
			
			if (this->GetType() == AP_TYPEOF(EventActionPlay))
			{
				float volume;
				
				// rand volume, so we have to get it from the internal playable object
				if (pNode->IsPlaying())
				{
					volume = pNode->GetVolumeDB();
				}
				else
				{
					// we might not be playing yet (if we have a delay on the sound)
					volume = pNode->CalculateStartVolumeDB();
				}
				
				AudioWii::Events::AudioRemotingPlayEvent PlayEvent(nodePath.AsChar(), volume);

				if (pNode->GetType() == AP_TYPEOF(BankNode))
				{
					PlayEvent.mBankNodePath = BankNode::GetPath(static_cast<BankNode*>(pNode));
				}

				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&PlayEvent);
				}
			}
			else if (this->GetType() == AP_TYPEOF(EventActionLoad))
			{
				const EventActionLoad* pLoadEvent = static_cast<const EventActionLoad*>(this);
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(nodePath.AsChar(), pLoadEvent->mAsync, false);

				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&LoadEvent);
				}

				// Send a remoting message to the tool 
				AudioSystem_FMOD::GetInstance()->UpdateMemoryStats();
			}
			 else if (this->GetType() == AP_TYPEOF(EventActionUnload))
			{
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(nodePath.AsChar(), false, true);

				if (AudioSystem_FMOD::GetInstance()->mSendRemotingEvents)
				{
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&LoadEvent);
				}

				// Send a remoting message to the tool 
				AudioSystem_FMOD::GetInstance()->UpdateMemoryStats();
			}

#endif
		}

		void EventActionLoad::Execute(Playable* pNode) const
		{
			if (mPackageName == "")
			{
				LoadParams params = { NULL, mAsync };
				AUDIOWII_LOG("audiosystemwii", "Executing LOAD on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
				BankNode::IterateDown(pNode, BankNodeIterators::Load, &params, false);
				Log(pNode);
			}
			else
			{
				AudioSystem_FMOD::GetInstance()->LoadPackageAsync(mPackageName.AsChar());
			}
		}

		void EventActionUnload::Execute(Playable* pNode) const
		{
			AUDIOWII_LOG("audiosystemwii", "Executing UNLOAD on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::Unload, NULL, false);
			Log(pNode);
		}

		void EventActionPlay::Execute(Playable* pNode) const
		{
			PlayParams params = { mAttack, mDelay, mEntityID, mPosition.X(), mPosition.Y(), mPosition.Z() };
			AUDIOWII_LOG("audiosystemwii", "Executing PLAY on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::Play, &params, false);
			Log(pNode);
		}

		void EventActionStop::Execute(Playable* pNode) const
		{
			StopParams params = { mEntityID, mRelease, mUnloadWhenStopped };
			AUDIOWII_LOG("audiosystemwii", "Executing STOP on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::Stop, &params, false);
			Log(pNode);
		}

		void EventActionPause::Execute(Playable* pNode) const
		{
			float duration = mRelease;
			AUDIOWII_LOG("audiosystemwii", "Executing PAUSE on node %s, fading %2.2f ms", pNode->GetLocalPath().AsChar(), pNode->GetName(), mRelease);
			BankNode::IterateDown(pNode, BankNodeIterators::Pause, &duration, false);
			Log(pNode);
		}

		void EventActionResume::Execute(Playable* pNode) const
		{
			float params[3] = { mAttack, mDelay, static_cast<float>(mForceStart) };
			AUDIOWII_LOG("audiosystemwii", "Executing RESUME on node %s, fading %2.2f ms", pNode->GetLocalPath().AsChar(), pNode->GetName(), mAttack);
			BankNode::IterateDown(pNode, BankNodeIterators::Resume, params, false);
			Log(pNode);
		}

		void EventActionChangeGainRelative::Execute(Playable* pNode) const
		{			
			float Params[2];
			Params[0] = mDeltaGainDB;
			Params[1] = mDuration;
			AUDIOWII_LOG("audiosystemwii", "Executing CHANGEGAINRELATIVE on node %s, %f dB", pNode->GetLocalPath().AsChar(), pNode->GetName(), Params[0]);
			BankNode::IterateDown(pNode, BankNodeIterators::ChangeGainRelative, Params, true);
			Log(pNode);
		}

		void EventActionChangeGainAbsolute::Execute(Playable* pNode) const
		{	
			float Params[2];
			Params[0] = mAbsoluteGainDB;
			Params[1] = mDuration;
			BankNode::IterateDown(pNode, BankNodeIterators::ChangeGainAbsolute, Params, true);
			Log(pNode);
		}

		void EventActionChangeGainRestore::Execute(Playable* pNode) const
		{
			float Params[1];
			Params[0] = mDuration;
			AUDIOWII_LOG("audiosystemwii", "Executing CHANGEGAINRESTORE on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::ChangeGainRestore, Params, true);
			Log(pNode);
		}

		void EventActionSetPitch::Execute(Playable* pNode) const
		{
			float Params[2];
			Params[0] = mCents;
			Params[1] = mDuration;
			AUDIOWII_LOG("audiosystemwii", "Executing SETPITCH on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::SetPitch, Params, true);
			Log(pNode);
		}

		void EventActionSetPitchRelative::Execute(Playable* pNode) const
		{
			float Params[2];
			Params[0] = mCents;
			Params[1] = mDuration;
			AUDIOWII_LOG("audiosystemwii", "Executing SETPITCH on node %s", pNode->GetLocalPath().AsChar(), pNode->GetName());
			BankNode::IterateDown(pNode, BankNodeIterators::SetPitchRelative, Params, true);
			Log(pNode);
		}

		void EventActionToggleDSPFilter::Execute(Playable* pNode) const
		{
		    // simple for now, don't iterate into assets (higher risk...)
			pNode->ToggleDSPFilter(mEnable);
			Log(pNode);
		}
	}
}
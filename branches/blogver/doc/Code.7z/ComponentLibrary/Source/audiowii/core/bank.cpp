#include "audiowii/bank.h"
#include "audiowii/audioeventmessages.h"

#include "audiowii/fmodex/audiosystem_fmodex.h" // for remoting load event helper function

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(PlaybackOrder)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		 AP_TYPE(PlaybackMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(LoadingMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(Bank)	
			AP_BASE_TYPE(Playable)
			AP_DEFAULT_CREATE()
			AP_FIELD("PlayableAssets",	mPlayableAssets,"List of Playable Assets")
			AP_FIELD("PlaybackOrder",	mPlaybackOrder,	"Playback samples in sequence, random, etc.")
			AP_FIELD("PlaybackMode",	mPlaybackMode,	"Normal play or Random Firing mode")
			AP_FIELD("LoadingMode",		mLoadingMode,	"Normal (All), Synchronous (on-demand), Asynchronous (one at a time in the background)")
			AP_FIELD("RandomFireMin",   mRandomFireMin, "Minimum time interval between sounds firing in RandomFire play mode")
			AP_FIELD("RandomFireMax",   mRandomFireMax, "Maximum time interval between sounds firing in RandomFire play mode")
			AP_FIELD("ActorSpecific",	mActorSpecific, "Actor Bank Flag (actor-specific bank node)")
			AP_PROPERTY("PlayAll", GetPlayAll, SetPlayAll, "Set to true if you want ALL of the sounds to be played before cycling through the bank")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		Axiom::Random Bank::mRandomizer;
		Bank::Bank() :
						mPlaybackOrder(PlaybackOrder::PLAY_SEQUENTIAL),
						mPlaybackMode(PlaybackMode::NORMAL),
						mAssetIDIndexRead(0),
						mActorSpecific(false),
						mPlayAll(false),
						mPreloadedAsset(NULL),
						mRandomFireMin(500),
						mRandomFireMax(2000)
		{

		}
		
		void Bank::SetPlayAll(bool playAll)
		{
			mPlayAll = playAll;
			if (mPlayAll)
			{
				// alloc / resize & init our bool array to keep track of what's been played
				mHasBeenPlayed.Resize(Axiom::Memory::AUDIO_HEAP, mPlayableAssets.Count());
				mHasBeenPlayed.Clear();
				for(unsigned int i=0; i < mHasBeenPlayed.Capacity(); i++)
				{
					mHasBeenPlayed.Add(false);
				}
			}
		}


		void Bank::Play(int entityID, Vector3& position, float attackMS, float delayMS, bool unloadWhenStopped)
		{
			// Get the next asset to play (sequential vs. random, etc.)
			Playable* pAsset = GetNextAsset();

			if (pAsset == NULL)
			{
				// empty bank.
				return;
			}

			if (mPlaybackMode == PlaybackMode::RANDOMFIRE && !mIsPlaying)
			{
				// don't do anything yet. pick a random delay and let UpdateTime() start the next sound below
				// start the first sound between 0 and our random MIN so we hear the first one soon
				mRandomFireDelay = static_cast<Axiom::UInt16>(mRandomizer.RandInt(0, mRandomFireMin));
				mRandomFireDelayElapsed = 0;
				mIsPlaying = true;

				// need to add this node to the playing pool, otherwise UpdateTime() won't get called
				AudioSystem_FMOD::GetInstance()->AddPlayingNode(this);
				return;
			}

			if (mLoadingMode == LoadingMode::SYNCHRONOUS)
			{
				AP_ASSERTMESSAGE(false, "LoadingMode::SYNCHRONOUS not yet supported");

				if (CountPlaying() > 0)
				{
					Stop(0.0f, false, -1);
				}
				
				pAsset->Load(false);
#if !CORE_FINAL
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(pAsset->GetLocalPath().AsChar(), false, false, true);
				AudioSystem_FMOD::GetInstance()->SendRemotingLoadEvent(LoadEvent); 	
#endif
				pAsset->Play(entityID, position, attackMS, delayMS, true);
			}
			else if (mLoadingMode == LoadingMode::ASYNCHRONOUS)
			{
				if (CountPlaying() > 0)
				{
					//Stop(0.0f, true, -1);
					AUDIOWII_LOG("AudioSystemWii", "Bank::Play [%s] - Prev asset is still playing, returning.", GetLocalPath().AsChar(), GetName());
					return;
				}
				
				// if we haven't got Load() yet, don't play anything.
				if (mPreloadedAsset != NULL)
				{
					AUDIOWII_LOG("AudioSystemWii", "Bank::UpdateTime [%s] - Playing pre-loaded asset (%s)", GetLocalPath().AsChar(), GetName(), mPreloadedAsset->GetName());
					mPreloadedAsset->Play(entityID, position, 0, 0, true); 		
				}
				else
				{
#if !CORE_FINAL
					AudioWii::Events::AudioRemotingPlayEvent playEvent(pAsset->GetLocalPath().AsChar(), 0.0f);
					playEvent.mNotLoaded = true;
					AudioSystem_FMOD::GetInstance()->sCallbackList[0]->SendAudioMessage(&playEvent);  	
#endif
					AUDIOWII_LOG("AudioSystemWii", "Bank::Play [%s] - Next asset not loaded yet. Playing nothing.", GetLocalPath().AsChar(), GetName());
					return;
				}	

				// and load the next one in the background
				AUDIOWII_LOG("AudioSystemWii", "Bank::Play [%s] - Pre-loading asset (%s)", GetLocalPath().AsChar(), GetName(), pAsset->GetName());
				pAsset->Load(true);
#if !CORE_FINAL
				AudioWii::Events::AudioRemotingBankLoadEvent LoadEvent(pAsset->GetLocalPath().AsChar(), true, false, true);
				AudioSystem_FMOD::GetInstance()->SendRemotingLoadEvent(LoadEvent); 	
#endif
				mPreloadedAsset = pAsset;
			}
			else
			{
				// normal sound bank (in-memory). just play it with the passed in unlodWhenStopped flag.
				if (pAsset != NULL)
				{
					pAsset->Play(entityID, position, attackMS, delayMS, unloadWhenStopped);
				}
			}
		}

		// Stop, Kill, Load, etc. just forward the calls onto the bank's list of playable objects
		void Bank::Stop(float releaseMS, bool unloadWhenStopped, int entityID)
		{
			if (mLoadingMode == LoadingMode::ASYNCHRONOUS)
			{
				// force unloading of the assets if we're in async (one-at-a-time) loading mode
				unloadWhenStopped = true;
			}
			
			for(unsigned int i = 0; i < mPlayableAssets.Count(); i++)
			{
				mPlayableAssets[i]->Stop(releaseMS, unloadWhenStopped, entityID);
			}

			mIsPlaying = false;
			if (mPlaybackMode == PlaybackMode::RANDOMFIRE)
			{
				AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
			}

			mPauseCount = 0;
		}

		void Bank::Load(bool bAsync)
		{
			if (mPlayableAssets.Count() == 0)
			{
				// empty bank. 
				return;
			}

			
			if (mLoadingMode == LoadingMode::ASYNCHRONOUS)
			{
				// if we're in ASYNCHRONOUS, load the first one asynchronously
				mAssetIDIndexRead = 0;
				Playable* pAsset = GetNextAsset();

				AUDIOWII_LOG("AudioSystemWii", "Bank::Load [%s] - Pre-loading asset (%s).", GetLocalPath().AsChar(), GetName(), pAsset->GetName());
				pAsset->Load(bAsync);
				mPreloadedAsset = pAsset;
			}
			else if (mLoadingMode == LoadingMode::SYNCHRONOUS)
			{
				// do nothing. load will happen when Play() is called
			}
			else if (mLoadingMode == LoadingMode::NORMAL)
			{
				// normal memory or streaming mode - load all the assets with the requested sync mocde
				int AssetCount = mPlayableAssets.Count();
				for(int i = 0; i < AssetCount; i++)
				{
					mPlayableAssets[i]->Load(bAsync);
				}
			}
			
		}

		void Bank::Pause(float releaseMS)
		{
			int AssetCount = mPlayableAssets.Count();
			for(int i = 0; i < AssetCount; i++)
			{
				mPlayableAssets[i]->Pause(releaseMS);
			}

			mPauseCount++;
		}

		void Bank::Resume(float attackMS, float delayMS, bool forceStart)
		{
			int AssetCount = mPlayableAssets.Count();
			for(int i = 0; i < AssetCount; i++)
			{
				mPlayableAssets[i]->Resume(attackMS, delayMS, forceStart);
			}

			if (mPauseCount > 0)
			{
				mPauseCount--;
			}
		}

		void Bank::Unload()
		{
			if (mPlaybackMode == PlaybackMode::RANDOMFIRE)
			{
				// gotta kill the randomfiring bank before unloading - otherwise it'll keep trying to play unloaded assets
				Stop(0, false, -1);
			}
			
			int AssetCount = mPlayableAssets.Count();
			for(int i = 0; i < AssetCount; i++)
			{
				mPlayableAssets[i]->Unload();
			}

			mPauseCount = 0;
		}

		void Bank::Mute()
		{
			int AssetCount = mPlayableAssets.Count();
			for(int i = 0; i < AssetCount; i++)
			{
				mPlayableAssets[i]->Mute();
			}

		}

		void Bank::UnMute()
		{
			int AssetCount = mPlayableAssets.Count();
			for(int i = 0; i < AssetCount; i++)
			{
				mPlayableAssets[i]->UnMute();
			}

		}

		void Bank::UpdateTime(int deltaMilliseconds)
		{
			deltaMilliseconds = 16; // Force this to operate on a 60FPS frame, so operates like real-time in debug & release

			if (mPlaybackMode == PlaybackMode::RANDOMFIRE && mIsPlaying && mPauseCount == 0)
			{
				mRandomFireDelayElapsed = mRandomFireDelayElapsed + static_cast<Axiom::UInt16>(deltaMilliseconds);

				// if we're passed our random fire delay time, fire the next sound up & pick a new delay for the next one
				if (mRandomFireDelayElapsed > mRandomFireDelay)
				{
					Vector3 vec(0, 0, 0);
					Play(-1, vec, 0, 0, 0);
					mRandomFireDelay		= static_cast<Axiom::UInt16>(mRandomizer.RandInt(mRandomFireMin, mRandomFireMax));
					mRandomFireDelayElapsed = 0;
				} 	
			}
			else if (mPlaybackMode == PlaybackMode::NORMAL)
			{
				int AssetCount = mPlayableAssets.Count();
				for(int i = 0; i < AssetCount; i++)
				{
					mPlayableAssets[i]->UpdateTime(deltaMilliseconds);
				} 			
			}    			
		}

		Playable* Bank::GetNextAsset()
		{
			int numAssets = mPlayableAssets.Count();
			Playable* pAsset = NULL;

			if (numAssets == 0)
			{
				return NULL;
			}

			if (mPlaybackOrder == PlaybackOrder::PLAY_SEQUENTIAL)
			{
				// POST increment mAssetIDIndexRead. We need to hear the 0th asset first!
				pAsset = mPlayableAssets[mAssetIDIndexRead];
				if (mAssetIDIndexRead + 1 >= numAssets)
				{
					mAssetIDIndexRead = 0;
				}
				else
				{ 
					mAssetIDIndexRead++;
				}
			}
			else if (mPlaybackOrder == PlaybackOrder::PLAY_RANDOM)
			{
				if (numAssets <= 1)
				{
					return mPlayableAssets[0];
				}

				int	randomIndex;
				
				// need to pick a random next sound, but with two conditions
				while(true)
				{ 
					randomIndex = mRandomizer.RandInt(0, numAssets-1);

					// always pick a new sound (not one previously played)
					if (randomIndex == mAssetIDIndexRead)
					{
						continue;
					}

					// if playall is set, pick a new sound
					if (mPlayAll && mHasBeenPlayed[randomIndex])
					{
						continue;
					}

					break; 
				}

				pAsset = mPlayableAssets[randomIndex];
				mAssetIDIndexRead = static_cast<Axiom::UInt16>(randomIndex);

				// keep track of which assets of this bank have been played.
				if (mPlayAll)
				{
					bool allHaveBeenPlayed = true;
					mHasBeenPlayed[randomIndex] = true;
					for(unsigned int i=0; i < mHasBeenPlayed.Count(); i++)
					{
						if (mHasBeenPlayed[i] == false)
						{
							allHaveBeenPlayed = false;
							break;
						}
					}

					// if we've gone through all of them, reset our hadBeenPlayed array
					if (allHaveBeenPlayed)
					{
						for(unsigned int i=0; i < mHasBeenPlayed.Count(); i++)
						{
							mHasBeenPlayed[i] = false;
						}
					}		
				}  			
			}
			else
			{
				AP_ASSERTMESSAGE(false, "Invalid Play Mode set for Sound Bank");
			}

			return pAsset;
		}

		int Bank::CountPlaying() const
		{
			int iNumAssets = mPlayableAssets.Count();
			int iNumPlaying = 0;
			for(int i=0; i < iNumAssets; i++)
			{
				if (mPlayableAssets[i]->IsPlaying() == true)
				{
					iNumPlaying++;
				}
			}

			return iNumPlaying;
		}


	}
}

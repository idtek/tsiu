#include "audiowii/soundproperties.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(LoopingMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(StorageMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(PositioningMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		 AP_TYPE(AttenuationMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		AP_TYPE(InterpolationMode)
			AP_ENUM()
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		// General Audio Properties
		AP_TYPE(SoundProperties)
			AP_DEFAULT_CREATE()
			AP_FIELD("RandomPitch",			mRandomPitch, "Random Pitch, in Cents. If > 0, sound pitch will vary to +/- this value when played back")
			AP_FIELD("RandomAttenuation",	mRandomAttenuation, "Random Attenuation. If > 0, sound will be attenuated by (0 -> this range) when played back")
			AP_FIELD("RandomMissfire",	 	mRandomMissfire, "Random Missfire, in %. If > 0, sound will not be played back % of the time")
			AP_FIELD("Delay",				mDelay,			"Delay")
			AP_FIELD("Pitch",				mPitch,			"Pitch")
			AP_FIELD("Format",				mFormat,		"Audio Data Format")
			AP_FIELD("LoopStart",			mLoopStart, 	"Loop Start, in frames")
			AP_FIELD("LoopEnd",				mLoopEnd,		"Loop End, in frames")
			AP_FIELD("AttenMin",			mDistAttenMin,	"Distance Attenuation minimum - below which sound plays at full volume. Set to 0 to use system default")
			AP_FIELD("AttenMax",			mDistAttenMax,	"Distance Attenuation maximum - above which sound plays at 0 volume. Set to 0 to use system default")
			AP_FIELD("LoopingMode",			mLoopingMode,	"Loop Mode for the asset")
			AP_FIELD("StorageMode",			mStorageMode,	"Where the asset is stored - Memory, Stream from disk, etc.")
			AP_FIELD("PositioningMode",		mPositioningMode, "How the position the asset playback, 2D/3D etc.")
			AP_FIELD("AttenuationMode",		mAttenuationMode, "Distance Attenuation mode, linear (Default), log, etc.")
			AP_FIELD("StreamBufferSize",	mStreamBufferSize, "Stream Buffer Size - use with caution. Default is 0")
			AP_FIELD("ExternalSpeaker", 	mExternalSpeaker, "Play the sound out the external speaker - i.e. Wii remote")
			AP_FIELD("SendReverb", 			mSendReverb, 		"Reverb send level. Valid ranges -90.6 dB (off) to 0 dB (full volume)")
			AP_FIELD("ApplyUserVolumeSFX", 	mApplyUserVolumeSFX, "Is the playback volume of this asset affected by the User SFX Volume?")
			AP_FIELD("ApplyUserVolumeMusic", mApplyUserVolumeMusic, "Is the playback volume of this asset affected by the User Music Volume?")
			AP_ATTRIBUTE("DefaultValue", "{SendReverb=-100.0}")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		// Data Format of the Audio
		AP_TYPE(SoundFormat)
			AP_DEFAULT_CREATE()
			AP_FIELD("Channels",  mChannels,	"Number of Channels")
			AP_FIELD("SampleRate",  mSampleRate,	"Sampling Frequency in Hz")
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()
	}
}

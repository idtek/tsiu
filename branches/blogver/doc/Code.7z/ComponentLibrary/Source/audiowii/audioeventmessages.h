#ifndef _AUDIOMESSAGES_WII_H
#define _AUDIOMESSAGES_WII_H
#include <eventsystem/eventman.h>
#include <kernel/messages.h>
#include <math/vector3.h>
#include "Collections/list.h"
#include "core/classedenum.h"

namespace AP
{
	namespace AudioWii
	{
		namespace Events
		{

#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS AP_DECLARE_TYPE();

CLASSEDENUM (	EUserVolumeType, \
				CLASSEDENUM_ITEMSTART(Invalid) \
				CLASSEDENUM_ITEM(Music) \
				CLASSEDENUM_ITEM(SFX), \
				Invalid \
				)
				
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS

			//---------------------------------------------------------------------
			class AudioPlaySoundEvent : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioPlaySoundEvent);

				static const int MAX_ACTOR_NAME_LENGTH = 16;
					
				AudioPlaySoundEvent(): Axiom::EventMsg(EVENT_GUID),
										m_EntityID (-1),
										m_X (0),
										m_Y (0),
										m_Z (0),
										m_Is3D (false),
										m_VoiceID(255)
					{}
				AudioPlaySoundEvent(int id, float Velocity, float X, float Y, float Z)
					: Axiom::EventMsg(EVENT_GUID)
					,m_EntityID(id)
					,m_X(X)
					,m_Y(Y)
					,m_Z(Z)
					,m_Is3D (false)
					,m_VoiceID(255)
					{ UNUSED_PARAM(Velocity); }
				void SetPosition(const Axiom::Math::Vector3& pos) { m_X = pos.X(); m_Y = pos.Y(); m_Z = pos.Z(); }

				AP_DECLARE_POLYMORPHIC_TYPE();

				int								m_EntityID;
			    float		    				m_X, m_Y, m_Z;
				Axiom::StringCRC				m_EventPath;
				short							m_ExternalSpeakerID; // which external speaker to play the sound out of (-1 == off)
				Axiom::Byte						m_VoiceID;
				bool							m_Is3D;
				Axiom::StaticString<MAX_ACTOR_NAME_LENGTH, char>	m_ActorName;
			};

			
			//---------------------------------------------------------------------
			// sent from the audio system back to the game to tell the game to send the 
			// event below "AudioUpdateEntityLocationEvent", containing locations 
			// of all registered GUIDs
			class AudioTrackEntityPositionEvent : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioTrackEntityPositionEvent);

				AudioTrackEntityPositionEvent() : Axiom::EventMsg(EVENT_GUID){}

				AudioTrackEntityPositionEvent(int id) : 
										Axiom::EventMsg(EVENT_GUID), 
										mEntityID(id), 
										mUnregister(false) {}

				int		mEntityID;
				bool	mUnregister;
			};

			//---------------------------------------------------------------------
			// sent from the game to the audio system, to update the location of 
			// a specific entity
			class AudioUpdateEntityPositionEvent : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioUpdateEntityPositionEvent);
					
				AudioUpdateEntityPositionEvent() : Axiom::EventMsg(EVENT_GUID){}

				AudioUpdateEntityPositionEvent(int guid, Axiom::Math::Vector3 position)	: 
											Axiom::EventMsg(EVENT_GUID), 
											mEntityGUID(guid),
											mPosition(position) {}

				int				mEntityGUID;
				Axiom::Math::Vector3	mPosition;
			};


			 //---------------------------------------------------------------------
			class AudioFEVolumeAdjustEvent : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioFEVolumeAdjustEvent);
					
					AudioFEVolumeAdjustEvent(): Axiom::EventMsg(EVENT_GUID){}
					AudioFEVolumeAdjustEvent(EUserVolumeType type, float volume)
						: Axiom::EventMsg(EVENT_GUID),
						  mVolumeType(type),
						  mVolumeValue(volume)
					{}

				EUserVolumeType mVolumeType;
				float           mVolumeValue;
				
				AP_DECLARE_POLYMORPHIC_TYPE();

			};
		  
			 //---------------------------------------------------------------------
			class AudioExternalSpeakerEvent : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioExternalSpeakerEvent);

				AudioExternalSpeakerEvent(): mSpeakerID(-1), mEnabled(false), Axiom::EventMsg(EVENT_GUID){}
				AudioExternalSpeakerEvent(int speakerID, bool enabled) : 
					 	Axiom::EventMsg(EVENT_GUID),
						mSpeakerID(speakerID),
						mEnabled (enabled)
				{}

				int				mSpeakerID;
				bool			mEnabled;
			};

			//---------------------------------------------------------------------
			class AudioUpdateCameraBody : public Axiom::EventMsg
			{
			public:	
				EVENT_MSG_GUID(AudioUpdateCameraBody);

				AudioUpdateCameraBody(): Axiom::EventMsg(EVENT_GUID){}
				AudioUpdateCameraBody(Axiom::Math::Vector3 vPos, Axiom::Math::Vector3 vFront, Axiom::Math::Vector3 vUp, Axiom::Math::Vector3 vRight)
					: Axiom::EventMsg(EVENT_GUID)
					,m_Position(vPos)
					,m_Front(vFront)
					,m_Up(vUp)
					,m_Right(vRight)
				{}
				
				Axiom::Math::Vector3	m_Position;
				Axiom::Math::Vector3	m_Front;
				Axiom::Math::Vector3	m_Up;
				Axiom::Math::Vector3	m_Right;
			};

#if !CORE_FINAL

			// REMOTING EVENTS - sent only in !CORE_FINAL to the Tool (Streaker) for 
			// debugging / monitoring
			//---------------------------------------------------------------------
			class AudioRemotingGenericEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingGenericEvent);

				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 30> mMessage;
				
				AudioRemotingGenericEvent(const char* message)
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mMessage = message;
				}

				AudioRemotingGenericEvent()
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mMessage = "";
				}
			};

			//---------------------------------------------------------------------
			class AudioRemotingPlayEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingPlayEvent);

				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 40,  char> mBankNodePath;
				
				AudioRemotingPlayEvent(const char* path, float volume)
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = path;
					mVolume = volume;
					mNotLoaded = false;
				}

				AudioRemotingPlayEvent()
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = "";
					mVolume = -999;
				}

				float mVolume;
				bool  mNotLoaded;
				
			};

			//---------------------------------------------------------------------
			class AudioRemotingBankNotFoundEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingBankNotFoundEvent);

				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 30,  char> mBankNodePath;
				
				AudioRemotingBankNotFoundEvent(const char* path)
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = path;
				}

				AudioRemotingBankNotFoundEvent()
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = "";
				}
		
			};

			//---------------------------------------------------------------------
			class AudioRemotingBankLoadEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingBankLoadEvent);

				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 30,  char> mBankNodePath;
				
				AudioRemotingBankLoadEvent(const char* path, bool bAsync, bool bUnload, bool bAutomatic = false)
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = path;
					mAsync = bAsync;
					mUnload = bUnload;
					mAutomatic = bAutomatic;
				}

				AudioRemotingBankLoadEvent()
					: Axiom::EventMsg(EVENT_GUID)
					
				{
					mBankNodePath = "";
					mAsync = false;
					mAutomatic = false;
				}

				bool mAsync;
				bool mUnload;
				bool mAutomatic; // if the load happens automatically (for async banks, etc.)
		
			};

			class AudioRemotingMemoryUpdateEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingMemoryUpdateEvent);

				AudioRemotingMemoryUpdateEvent(); // defined in the .cpp 			

				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 42,  char> mAssetPath;
				unsigned short mNumKBNative;
				unsigned short mNumKBLargestFreeChunkNative;
				unsigned short mNumKBFMOD;
				unsigned short mNumKBFMODMax;
				unsigned short mNumKBFMODCurrent;
				bool		   mOutOfMemoryFMOD;
				bool		   mOutOfMemoryNative;   
			};

			//---------------------------------------------------------------------
			// Sent when an PlaySoundEvent is received (event path determines
			// the action to be taken.
			//
			class AudioRemotingTriggerEvent : public Axiom::EventMsg
			{
			public:	
				AP_DECLARE_POLYMORPHIC_TYPE();
				EVENT_MSG_GUID(AudioRemotingTriggerEvent);
				
				Axiom::StaticString<Axiom::EventData::MAX_EVENT_DATA_SIZE - 40,  char> mEventPath;
				Axiom::StaticString<AudioPlaySoundEvent::MAX_ACTOR_NAME_LENGTH, char> mActorName;
				   			
				AudioRemotingTriggerEvent(const char* path, const char* actor, bool handled)
					: Axiom::EventMsg(EVENT_GUID)
					
				{				
					mEventPath = path;
					mActorName = actor;
					mHandled = handled;
				}

				AudioRemotingTriggerEvent()
					: Axiom::EventMsg(EVENT_GUID)
					
				{ 
					mEventPath = "";
					mActorName = "";
					mHandled 	= false;
				}
			
				bool mHandled; // if the event path is found in the event tree, the event is considered "handled" 		
			};
			
#endif // #if !CORE_FINAL
		}
	}   
}

#endif // AUDIO_MESSAGES_WII_H


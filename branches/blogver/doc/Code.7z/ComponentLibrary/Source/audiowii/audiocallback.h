#ifndef _AUDIO_CALLBACK_H_
#define _AUDIO_CALLBACK_H_

#include <eventsystem/eventman.h>

// Derive from this class if you want audio callbacks from the AudioSystem object.
// -------------------------------------------------------------------------------

namespace AP
{
	namespace AudioWii
	{
		class AudioCallback
		{
		public:

			AudioCallback();
			virtual ~AudioCallback();

			virtual void SendAudioMessage(Axiom::EventMsg* message) { UNUSED_PARAM(message); }
			virtual void LoadComplete(int eventID) { UNUSED_PARAM(eventID); }
			virtual void AudioStart(int eventID)   { UNUSED_PARAM(eventID); }
			virtual void AudioEnd(int eventID)     { UNUSED_PARAM(eventID); }
			virtual void AudioError(const char*) {} 
		};	
	}
		//-------------------------------------------------
}

#endif // _AUDIO_CALLBACK_H_

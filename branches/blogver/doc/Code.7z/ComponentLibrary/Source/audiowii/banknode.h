#ifndef _BANKNODE_H
#define _BANKNODE_H

#include <collections/list.h>
#include <core/autopointer.h>
#include "audiowii/soundproperties.h"
#include "audiowii/banknodeiterators.h"
#include "audiowii/bank.h"
#include <core/pointer.h>

namespace AP
{
	namespace AudioWii
	{
		class BankNode : public Bank
		{
		public:
			typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer< BankNode > > BankNodeList;
			BankNode() {  };							
			~BankNode() {};

			static AudioPathString  GetPath(const BankNode* pNode);
			static void				LinkChildren(BankNode* pNode);
			static Playable*		NodeFromPath(AudioPathString path, BankNode* pNode, bool exactMatch = true);
			static void				IterateDown(Playable* pNode, BankNodeIterator iterator, void* pUserData, bool IterateIntoAssets);
			static void				IterateUp(Playable* pNode, BankNodeIterator iterator, void* pUserData);

			BankNodeList& GetChildren() { return mChildren; }
			static const int MAX_BANK_PATH_CHARS = 128;

		private:
			BankNodeList mChildren;
	 
		public:	
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _BANKNODE_H
#ifndef _PLAYABLESAMPLE_AX_H
#define _PLAYABLESAMPLE_AX_H

#include "audiowii/playable.h"
#include <revolution.h>


//////////////////////////////////////////////////////////////////////
// FMOD Specific Implementation of Playable Object
//
// The ChannelMain and ChannelAlternate are needed to make the playback
// of stereo vs. mono files transparent to the user on Wii. If the channel
// count in mProperties is 2, then this Object looks for 2 files named
// filename_left.dsp and filename_right.dsp, and hard pans them left 
// and right to realize the stereo field of the original stereo file.
//
//////////////////////////////////////////////////////////////////////

#define AXVOICE_PRIO_HIGH 31
#define AXVOICE_PRIO_MED  15
#define AXVOICE_PRIO_LOW  1

#define AXVOICE_STATE_STOPPED        0
#define AXVOICE_STATE_START          1
#define AXVOICE_STATE_STARTED        2
#define AXVOICE_STATE_PLAYING        3
#define AXVOICE_STATE_STOP           4

#define STREAM_BUFFER_SIZE			(32 * 1024)

namespace AP
{
	namespace AudioWii
	{
		class PlayableSample_AX : public Playable
		{
		public:

			PlayableSample_AX();
			virtual ~PlayableSample_AX();

			// Static public function, to avoid this class getting linked out
			static void Dummy(void);

			// Implement Playable functionality
			virtual bool	Play(float volumeDB, float pitch);
			virtual void	Kill();
			virtual void	Load(bool bAsync);		
			virtual void	Unload();	
			virtual void	SetVolume(float volume);
			virtual float	GetVolume() const;

		private:
			void PlayAXSample(AXVPB** ppAXVoice, float pan);
			void PlayAXStream(AXVPB** ppAXVoice);

			// Static private members
			static int		mDummy;
			
			void 		LoadSampleIntoMemory(const char* Path); // AXType i.e. streaming/memory
			AXVPB* 		AquireVoiceADPCM(void *pDSPADPCMData);

			char*   	mAudioDataMain;
			char*   	mAudioDataAlternate;
			
			AXVPB*		mAXVoiceMain;
			AXVPB*		mAXVoiceAlternate;

			AXPBMIX   	mAXMix;				// mixing structure for the voice
			AXPBVE		mAXVolumeEnvelope;	// volume envelope
			
			int			mVolumeDBX10;		// volume in dB X 10 (1 == .1 dB)

			// used for streaming
			int			mStreamPosMain;
			int 		mStreamPosAlternate;  	
			int 		mDataSize;

		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _PLAYABLESAMPLE_AX_H
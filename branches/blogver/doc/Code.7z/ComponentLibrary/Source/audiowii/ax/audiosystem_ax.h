#ifndef _AUDIOSYSTEM_AX_H
#define _AUDIOSYSTEM_AX_H

#include <core/autopointer.h>
#include <memory/apmemory.h>
#include "audiowii/audiosystem.h"
#include "collections/array.h"
#include "audiowii/ax/playablesample_ax.h"
#include "audiowii/ax/playablestream_ax.h"

#include <revolution.h>
#include <revolution/mix.h>
#include <revolution/axfx.h>

// copied utility functions from revolution sample code
#define RoundUp64(x) (((u32)(x) + 64 - 1) & ~(64 - 1))
#define Bytes2Nibbles(n) (n << 1)
#define Nibbles2Bytes(n) (n >> 1)
#define GetDSPADPCMDataAddress(a) ((void*)((u32)a + sizeof(DSPADPCM)))
#define GetDSPADPCMDataSize32B(a) (RoundUp64(((DSPADPCM*)a)->num_adpcm_nibbles) >> 1)
#define GetVoiceCurrentAddr32(v) (*(u32 *)(&((v)->pb.addr.currentAddressHi))) 
#define GetVoiceLoopAddr32(v) (*(u32 *)(&((v)->pb.addr.loopAddressHi))) 
#define GetVoiceEndAddr32(v) (*(u32 *)(&((v)->pb.addr.endAddressHi)))


namespace AP
{
	namespace AudioWii 
	{
		
		struct AXVoiceInfo
		{
			AXVPB*			voice;
			Axiom::UInt32	state;
			PlayableSample_AX*	pPlayable;  
		};
			
		class AudioSystem_AX : public AudioSystemWii
		{
			friend class PlayableSample_AX;
		public:

			enum ReverbSetting {ReverbNone, ReverbType1, ReverbType2, 
								ReverbMetalPipe, ReverbMetalTank, ReverbExpSmallRoom, 
								ReverbMediumRoom, ReverbLargeRoom, ReverbLongRoom, 
								ReverbSmallHall, ReverbLargeHall, ReverbCavernous, 
								ReverbCathedral };
		public:
			AudioSystem_AX();
			virtual ~AudioSystem_AX();
			
			// Init, Destroy
			virtual void Initialize(int NumChannels);
			virtual void LogMemoryStats();
			virtual void UpdateTime(int deltaMilliseconds);

			void Destroy();

			static AudioSystem_AX* GetInstance();

			// AX System Callbacks
			static void AXVoiceCallback(void * voiceIn);
			static void AXAudioFrameCallback(void);

			static bool	AddVoice (AXVoiceInfo*);
			static bool RemoveVoice (AXVoiceInfo*);

			void	SetReverb (ReverbSetting rs);

		private:
			static AudioSystem_AX* mInstance;
			static AXVoiceInfo mAXVoices[AX_MAX_VOICES];
			char* mAXBuffer;
			char* mMIXBuffer;
			
			AXFX_REVERBSTD_EXP      reverb;
		   
		};
	}
}

#endif // _AUDIOSYSTEM_AX_H
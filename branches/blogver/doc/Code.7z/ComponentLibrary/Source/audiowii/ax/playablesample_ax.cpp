#include "audiowii/ax/PlayableSample_AX.h"
#include "audiowii/ax/audiosystem_ax.h"
#include "audiowii/ax/playablestream_ax.h"
#include "files/filemanager.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(PlayableSample_AX)
			AP_DEFAULT_CREATE()
			AP_BASE_TYPE(Playable)
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

		// Static public function to remove compiler optimizations...
		// Otherwise this class won't be available to streaker.
		int PlayableSample_AX::mDummy = 0;
		void PlayableSample_AX::Dummy(void)
		{
			++mDummy;
		}
		
		PlayableSample_AX::PlayableSample_AX() : Playable()
		{
		    mAudioDataMain = NULL;
			mIsLoaded = false;
			mDataSize = 0;

			mVolumeDBX10 = 0;

		    // Init the mix structure
		    Axiom::MemorySet(&mAXMix, 0, sizeof(AXPBMIX));

			// 0x8000 == 32768 == full volume
		    mAXMix.vL 		= 32767; 	// Left Channel Volume
		    mAXMix.vDeltaL	= 0;		// Left Channel Ramp
		    mAXMix.vR 		= 32767; 	// Left Channel Volume
		    mAXMix.vDeltaR	= 0;		// Left Channel Ramp

		    mAXMix.vAuxAL = 0;         		// volume AUX A left
			mAXMix.vDeltaAuxAL = 0;    		// volume ramp AUX A left
			mAXMix.vAuxAR = 0;         		// volume AUX A right
			mAXMix.vDeltaAuxAR = 0;    		// volume ramp AUX A right
			
			mAXMix.vAuxBL = 0;         		// volume AUX B left
			mAXMix.vDeltaAuxBL = 0;    		// volume ramp AUX B left
			mAXMix.vAuxBR= 0;         		// volume AUX B right
			mAXMix.vDeltaAuxBR= 0;    		// volume ramp AUX B right
			
			mAXMix.vAuxCL = 0;         		// volume AUX C left
			mAXMix.vDeltaAuxCL = 0;    		// volume ramp AUX C left
			mAXMix.vAuxCR = 0;         		// volume AUX C right
			mAXMix.vDeltaAuxCR = 0;    		// volume ramp AUX C right

			mAXMix.vS = 0;             		// volume surround
			mAXMix.vDeltaS = 0;        		// volume ramp surround
			mAXMix.vAuxAS = 0;         		// volume AUX A surround
			mAXMix.vDeltaAuxAS = 0;    		// volume ramp AUX A surround
			mAXMix.vAuxBS = 0;         		// volume AUX B surround
			mAXMix.vDeltaAuxBS = 0;    		// volume ramp AUX B surround
			mAXMix.vAuxCS = 0;         		// volume AUX C surround
			mAXMix.vDeltaAuxCS = 0;    		// volume ramp AUX C surround

			mAXVolumeEnvelope.currentVolume = 32767;
			mAXVolumeEnvelope.currentDelta	= 0;
		}

		PlayableSample_AX::~PlayableSample_AX()
		{
			// This will be called by the reflection system when deleting a bank node.
			// Release the AX Sound Memory and free the voice
			if (mIsLoaded)
			{
			   
			}
		}

		void PlayableSample_AX::LoadSampleIntoMemory(const char* Path)
		{
			Axiom::FileManager::FileManager* pFileManager = Axiom::FileManager::FileManager::GetInstance();
			AP_ASSERTMESSAGE(pFileManager != NULL, "Could not get FileManager!");
				
			Axiom::FileManager::FileInfo fileInfo = pFileManager->GetFileInfo(Path);
			const bool isValid = fileInfo.IsValid();
				
			AP_ASSERTMESSAGE(isValid, "Error getting file information!");
			//AP_ASSERTMESSAGE(fileInfo.m_Size >= 0, "Invalid file size!");

			// alloc 32 byte aligned for the audio mem
			mAudioDataMain = AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[fileInfo.m_Size]);
			mDataSize += fileInfo.m_Size;
			
			// load the file ...
			AP_ASSERT_SUPPORTASSIGN(const int bytesRead, pFileManager->LoadFileSynchronous(fileInfo, mAudioDataMain));
			AP_ASSERTMESSAGE(fileInfo.m_Size == bytesRead, "Bytes read not equal to file size!"); 

			// update out internal size count		  	
		}
		
		void PlayableSample_AX::Load(bool bAsync)
		{
			AP_ASSERTMESSAGE(mIsLoaded == false, "Asset '%s' is already loaded", mLocalPath.AsChar());
			AP_ASSERTMESSAGE(Axiom::StringLength(mLocalPath.AsChar()) != 0, "No path set for playable asset - cannot load");

			// resolve local file path & try to load the sound
			Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			filePath += (mLocalPath.AsChar() + 10); // +10 to get rid of the '/BankRoot/' 
			  	 
			// If it's stereo, need to do this for filename_left.dsp and filename_right.dsp
			// because the dsptool.dll encoder only supports encoding of mono data
			if (mProperties.mFormat.mChannels == 2)
			{
				Axiom::StaticString<127, char> FilePathRight, FilePathLeft;
				FilePathLeft = filePath;
				FilePathLeft.Replace(".dsp", "_lef");
				FilePathLeft += "t.dsp";
				FilePathRight = filePath;
				FilePathRight.Replace(".dsp", "_rig");
				FilePathRight += "ht.dsp";
				if (mProperties.mStorageMode == StorageMode::IN_MEMORY)
				{	
					LoadSampleIntoMemory(filePath.AsChar());
				}
				else if (mProperties.mStorageMode == StorageMode::STREAMING)
				{
					// make sure the file exists
					Axiom::FileManager::FileManager* pFileManager = Axiom::FileManager::FileManager::GetInstance();
					AP_ASSERTMESSAGE(pFileManager != NULL, "Could not get FileManager!");
						
					Axiom::FileManager::FileInfo fileInfo = pFileManager->GetFileInfo(FilePathLeft);
					bool isValid = fileInfo.IsValid();					
					AP_ASSERTMESSAGE(isValid, "Error getting file information!");

					fileInfo = pFileManager->GetFileInfo(FilePathRight);
					isValid = fileInfo.IsValid();					
					AP_ASSERTMESSAGE(isValid, "Error getting file information!");			
			
					// just alloc the memory here. We could start filling data, that could be an option, or another function.
					mAudioDataMain 		= AP_NEW(Axiom::Memory::DEFAULT_HEAP, char[STREAM_BUFFER_SIZE*2]);
					mAudioDataAlternate = AP_NEW(Axiom::Memory::DEFAULT_HEAP, char[STREAM_BUFFER_SIZE*2]);
					mIsLoaded = true;
					return;
				}
			}
			else
			{
				//Axiom::Log("AudioSystemWii", "Loading asset '%s'", filePath.AsChar());
				if (mProperties.mStorageMode == StorageMode::IN_MEMORY)
				{
					 LoadSampleIntoMemory(filePath.AsChar());
				}
				else if (mProperties.mStorageMode == StorageMode::STREAMING)
				{
					// just alloc the memory here. We could start filling data, that could be an option, or another function.
					// for now, wait till Play() is called, then start reading
					mAudioDataMain 		= AP_NEW(Axiom::Memory::DEFAULT_HEAP, char[STREAM_BUFFER_SIZE*2]);
					mIsLoaded = true;
					return;
				}
			}

			if (false/* error */)
			{
				mIsLoaded = false;
				int count = AudioSystemWii::sCallbackList.Count();
				for(int i=0; i < count; i++)
				{
					Axiom::StaticString<256, char> errorString;
					errorString = "Load Error on '";
					errorString += mLocalPath.AsChar();
					AudioSystemWii::sCallbackList[i]->AudioError(errorString.AsChar());
				}
			}
			else
			{
				mIsLoaded = true;
			}
		}

		void PlayableSample_AX::Unload()
		{
			if (mIsLoaded == false)
			{
				return;
			}

			//Axiom::Log("AudioSystemWii", "Unloading asset '%s'", pAsset->GetLocalPath());
			//FMOD_RESULT result = mFMODSoundMain->release();
			//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error unloading asset");

			if (true /* right channel file to play */)
			{
				//result = mFMODSoundAlternate->release();
				//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error unloading asset");
			}

			mIsLoaded = false;
		}

		AXVPB* PlayableSample_AX::AquireVoiceADPCM(void *pDSPADPCMData)
		{
			DSPADPCM            *ps = (DSPADPCM*)pDSPADPCMData;
			AXPBADDR            addr;
			AXPBADPCM           adpcm;
			AXPBSRC             src;
			AXPBADPCMLOOP       adpcmLoop;
			AXVPB*              voice;
			u32                 srcBits;
			u32                 mramAddress;
			u32                 pMRAMStart;
		
			// Allocate a voice for use
			voice = AXAcquireVoice(AXVOICE_PRIO_MED, AudioSystem_AX::AXVoiceCallback, 0);
		
			if (voice == NULL)
			{
				OSReport("WARNING! Voice Acquisition failed!\n");
				return NULL;
			}
		
			// Fill AXPBADDR structure
			// All the folowing addresses are in nibbles
		
			addr.loopFlag           = ps->loop_flag;
			addr.format             = ps->format;
		
			pMRAMStart = OSCachedToPhysical(GetDSPADPCMDataAddress(pDSPADPCMData));
		
			// Support for looping
			if (addr.loopFlag)
			{
				adpcmLoop.loop_pred_scale = ps->lps;
				adpcmLoop.loop_yn1        = ps->lyn1;
				adpcmLoop.loop_yn2        = ps->lyn2;
			}
		
			mramAddress             = (ps->sa + Bytes2Nibbles(pMRAMStart));
			addr.loopAddressHi      = (u16)(mramAddress >> 16);              
			addr.loopAddressLo      = (u16)(mramAddress & 0xFFFF);       
		
			mramAddress             = (ps->ea + Bytes2Nibbles(pMRAMStart));
			addr.endAddressHi       = (u16)(mramAddress >> 16);       
			addr.endAddressLo       = (u16)(mramAddress & 0xFFFF);       
		
			mramAddress             = (ps->ca + Bytes2Nibbles(pMRAMStart));
			addr.currentAddressHi   = (u16)(mramAddress >> 16);       
			addr.currentAddressLo   = (u16)(mramAddress & 0xFFFF);
			
			// Fill AXPBADPCM structure
			adpcm.a[0][0]           = ps->coef[0];
			adpcm.a[0][1]           = ps->coef[1];
			adpcm.a[1][0]           = ps->coef[2];
			adpcm.a[1][1]           = ps->coef[3];
			adpcm.a[2][0]           = ps->coef[4];
			adpcm.a[2][1]           = ps->coef[5];
			adpcm.a[3][0]           = ps->coef[6];
			adpcm.a[3][1]           = ps->coef[7];
			adpcm.a[4][0]           = ps->coef[8];
			adpcm.a[4][1]           = ps->coef[9];
			adpcm.a[5][0]           = ps->coef[10];
			adpcm.a[5][1]           = ps->coef[11];
			adpcm.a[6][0]           = ps->coef[12];
			adpcm.a[6][1]           = ps->coef[13];
			adpcm.a[7][0]           = ps->coef[14];
			adpcm.a[7][1]           = ps->coef[15];
			adpcm.gain              = ps->gain; 
			adpcm.pred_scale        = ps->ps;
			adpcm.yn1               = ps->yn1;
			adpcm.yn2               = ps->yn2;
		
			// Fill AXPBSRC structure for proper sample rates
			srcBits = (u32)(0x00010000 * ((f32)ps->sample_rate / AX_IN_SAMPLES_PER_SEC));
			src.ratioHi = (u16)(srcBits >> 16);
			src.ratioLo = (u16)(srcBits & 0xFFFF);
			src.currentAddressFrac = 0;
			src.last_samples[0] = 0;
			src.last_samples[1] = 0;
			src.last_samples[2] = 0;
			src.last_samples[3] = 0;
		
			// Set voice type
			AXSetVoiceType(voice, AX_PB_TYPE_NORMAL);
		
			// Set Address and ADPCM information from header
			AXSetVoiceAddr(voice, &addr);
			AXSetVoiceAdpcm(voice, &adpcm);
			AXSetVoiceAdpcmLoop(voice, &adpcmLoop);
		
			// Set simple volumes
			AXSetVoiceMix(voice, &mAXMix);
			AXSetVoiceVe(voice, &mAXVolumeEnvelope);
		
			// Set sample type
			AXSetVoiceSrcType(voice, AX_SRC_TYPE_LINEAR);
			AXSetVoiceSrc(voice, &src);
		
			return voice;
		}
		
		void PlayableSample_AX::PlayAXSample(AXVPB** ppAXVoice, float pan)
		{
			UNUSED_PARAM(pan);

			if (mAudioDataMain == NULL)
			{
				AP_ASSERTMESSAGE(false, "AudioSystem AX: Sample not loaded!\n");
			}

			bool old = OSDisableInterrupts();
		
			// Aquire Voice and start
			*ppAXVoice = AquireVoiceADPCM(mAudioDataMain);
			if (*ppAXVoice == NULL)
			{
				AP_ASSERTMESSAGE(false, "AudioSystem AX: Sample not loaded!\n");
			}
			int AttenuationOfReverb = -960;
			
			if (mIsReverbEnabled == true)
			{
				AttenuationOfReverb = 0;
			}
			// add it the mixer
			MIXInitChannel(
                   (*ppAXVoice),       			// pointer to voice
                   MIX_MODE_AUXA_PREFADER,      // initial aux A, B, mute modes
                   0,    						// initial input atten/gain
                   AttenuationOfReverb,     	// initial aux A atten/gain
                   -960,     					// initial aux B atten/gain
                   -960,     					// Aux C initial atten/gain
                   0,      						// initial pan
                   0,     						// initial span
                   mVolumeDBX10     			// initial fader atten/gain
                   ); 
				   

			// fire it up
			AudioSystem_AX::mAXVoices[(*ppAXVoice)->index].voice = *ppAXVoice;
			AudioSystem_AX::mAXVoices[(*ppAXVoice)->index].state = AXVOICE_STATE_START;

			OSRestoreInterrupts(old);
				
		}

		void PlayableSample_AX::PlayAXStream(AXVPB** ppAXVoice)
		{
			bool old = OSDisableInterrupts();
			if (mAudioDataMain == NULL)
			{
				AP_ASSERTMESSAGE(false, "AudioSystem AX: Sample not loaded!\n");
			}
			AP_ASSERTMESSAGE(mIsLoaded == false, "Asset '%s' is already loaded", mLocalPath.AsChar());
			AP_ASSERTMESSAGE(Axiom::StringLength(mLocalPath.AsChar()) != 0, "No path set for playable asset - cannot load");
			
		  /*  AudioStream* map = AudioStream::NewFile ();
			
			const char* filename = mLocalPath.AsChar ();
			map->isLooping = true;*/

		/*	// Aquire Voice
			
			if (mProperties.mFormat.mChannels == 2)
			{
				Axiom::StaticString<255, char> FilePathRight, FilePathLeft;
				FilePathLeft = mLocalPath.AsChar();
				FilePathLeft.Replace(".dsp", "_lef");
				FilePathLeft += "t.dsp";
				FilePathRight = mLocalPath.AsChar();
				FilePathRight.Replace(".dsp", "_rig");
				FilePathRight += "ht.dsp";
				
				map->LoadFiles (FilePathLeft.AsChar (), FilePathRight.AsChar ());
			}
			else
			{
				map->LoadFiles (mLocalPath.AsChar(), NULL);
			}*/

			// open the file(s) and fill the first 32K
			
			
		  /*  mAXVoiceMain = AquireVoiceADPCM(mAudioDataMain, AX_PB_TYPE_STREAM);
			
			if (mProperties.mFormat.mChannels == 2)
			{
				mAXVoiceAlternate = AquireVoiceADPCM(mAudioDataMain, AX_PB_TYPE_STREAM);
			}
			
			if (*ppAXVoice == NULL)
			{
				AP_ASSERTMESSAGE(false, "AudioSystem AX: Sample not loaded!\n");
			}

			// add it the mixer
			MIXInitChannel(
                   (*ppAXVoice),       			// pointer to voice
                   MIX_MODE_AUXA_PREFADER,      // initial aux A, B, mute modes
                   0,    						// initial input atten/gain
                   0,     						// initial aux A atten/gain
                   -960,     					// initial aux B atten/gain
                   -960,     					// Aux C initial atten/gain
                   0,      						// initial pan
                   0,     						// initial span
                   mVolumeDBX10     			// initial fader atten/gain
                   );
				   
				*/
			// fire it up
			AudioSystem_AX::mAXVoices[(*ppAXVoice)->index].voice = *ppAXVoice;
			AudioSystem_AX::mAXVoices[(*ppAXVoice)->index].state = AXVOICE_STATE_START;

			OSRestoreInterrupts(old);
				
		}

		
		bool PlayableSample_AX::Play(float volume, float pitch)
		{
			//AP_ASSERTMESSAGE(IsLoaded() == true, "Asset not yet loaded");		

			if (!mIsLoaded)
			{
				return false;
			}
			
			if (false /* dual channel */ )
			{
				// stereo file
				//PlayFMOD(mFMODSoundMain, &mFMODChannelMain, -1.0);
				//PlayFMOD(mFMODSoundAlternate, &mFMODChannelAlternate, 1.0);

				// fire the channels up at the same time to minimize phase difference between L and R
				//mFMODChannelMain->setPaused(false);
				//mFMODChannelAlternate->setPaused(false);
			}
			else
			{				
				PlayAXSample(&mAXVoiceMain, 0.0f);
			}
			return true;
		}

		void PlayableSample_AX::Kill()
		{
			if (mIsPlaying == false)
			{
				// it's not playing... just return
				return;
			}

			//FMOD_RESULT result;
			//(result, mFMODChannelMain->stop());
			//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error stopping asset '%s'", mLocalPath.AsChar() );

			if (true /* dual channel */)
			{
				// AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mFMODChannelAlternate->stop());
				// AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error stopping asset '%s'", mLocalPath.AsChar() );
			}
		}

		void PlayableSample_AX::SetVolume(float volume)
		{
			if (mIsPlaying == false)
			{
				// it's not playing... just set the mix and return
				mVolumeDBX10 = AmplitudeTodB(volume);   		
				return;
			}

			mVolumeDBX10 = AmplitudeTodB(volume)*10; // * 10 because the MIXSetFader takes tenths of dBs 
		    MIXSetFader(mAXVoiceMain, mVolumeDBX10);

			if (mVolumeDBX10 < -960 || mVolumeDBX10 > 0)
			{
			    Axiom::Log("audiowii", "Setting volume to %d!!!", mVolumeDBX10);
			}
				
			if (true/* dual channel */)
			{
				//(FMOD_RESULT result, mFMODChannelAlternate->setVolume(volume));
				//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting volume asset '%s'", mLocalPath.AsChar() );
			}
		}

		float PlayableSample_AX::GetVolume() const
		{
			if (!mIsPlaying)
			{
				// it's not playing... just return
				return 0.0f;
			}

			float volume = 1.0f;
			//AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mFMODChannelMain->getVolume(&volume));
			//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting volume asset '%s'", mLocalPath.AsChar() );

			return volume;
		}
	}
}

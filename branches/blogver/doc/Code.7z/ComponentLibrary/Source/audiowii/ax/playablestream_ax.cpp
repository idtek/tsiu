//#include "StdAfx.h"
#include "PlayableStream_AX.h"
#include <revolution.h>
#include <stdlib.h>
#include <string.h>
#include <revolution.h>
#include <revolution/mix.h>
#include <revolution/mem.h>
#include <demo.h>
#include <assert.h>
#include "audiowii/ax/audiosystem_ax.h"
//#include "audiowii/fmodex/playable_fmodex.h"
//#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "files/filemanager.h"
//#include "fmod_errors.h"
//#include "macros.h"

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(PlayableStream_AX)
			AP_DEFAULT_CREATE()
			AP_BASE_TYPE(Playable)
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()
		
	// macros
//-------------------------------------------------------------------
//-------------------------------------------------------------------

// --------- dummy fucntions so the compiler won't strip this class
int PlayableStream_AX::mDummy = 0;
void PlayableStream_AX::Dummy(void)
{
	++mDummy;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------
		
template <typename type>// assuming an int type
type  AlignDownTo4Bytes (type val)
{
	return val & ~0x3;
}
template <typename type>// assuming an int type
type  AlignDownTo32Bytes (type val)
{
	return val & ~0x1f;
}
template <typename type>// assuming an int type
type  AlignUpTo32Bytes (type val)
{
	return AlignDownTo32Bytes (val+ 31);
}


template <typename Type, typename DestType>
void AssignEndien (Type n, DestType& low, DestType& hi)
{
	hi      = (u16)(n >> 16);
    low     = (u16)(n & 0xFFFF);
}


#define GetDSPADPCMDataAddress(a) ((void*)((u32)a + sizeof(DSPADPCM)))
#define GetDSPADPCMDataSize32B(a) (RoundUp64(((DSPADPCM*)a)->num_adpcm_nibbles) >> 1)

//-------------------------------------------------------------------
//-------------------------------------------------------------------
PlayableStream_AX* FindFile (DVDFileInfo* filehandle);


void 	GetDataLeftSide (PlayableStream_AX* map);
void 	GetDataRightSideCallback (s32 result, DVDFileInfo* fileInfo);
void 	FinalDataObtainedCallback (s32 result, DVDFileInfo* fileInfo);

void 	GetDataLeftSideStereo (PlayableStream_AX* map);
void 	GetDataRightSideSplitCallback (s32 result, DVDFileInfo* fileInfo);
void 	FinalDataObtainedStereoCallback (s32 result, DVDFileInfo* fileInfo);

//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------

static const int PlayableStream_AX::MaxAudioStreams;
PlayableStream_AX* PlayableStream_AX::ListOfOpenFiles [MaxAudioStreams];
int		PlayableStream_AX::NumStreamsInUse = 0;
bool	DvdIsReadingState = false;

//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: UpdateAllStreams ()
{
	for (int i=0; i<MaxAudioStreams; i++)
	{
		PlayableStream_AX* ptr = ListOfOpenFiles[i];
		if (ptr && 
		ptr->IsInUse () == true)
		{
			ptr->Update ();
		}
	}
}
/*
PlayableStream_AX* PlayableStream_AX :: NewFile ()
{
	int NumItems = MaxAudioStreams;
	for (int i=0; i<NumItems; i++)
	{
		PlayableStream_AX* ptr = ListOfOpenFiles[i];
		if (ptr->IsInUse () == false)
		{
			ptr->Clear ();
			ptr->SetInUse (true);
			ptr->TotalFileSize = 0;
			return ptr;
		}
	}
	//AP_ASSERTMESSAGE (0,"cannot open file stream because memory is not available\n");
	return NULL;
}

PlayableStream_AX*  PlayableStream_AX :: GetFile (int index)
{
	if (index <0 || index >= MaxAudioStreams)
		return NULL;

	return ListOfOpenFiles[index];
}
*/
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------

PlayableStream_AX :: PlayableStream_AX ()
{
	AP_ASSERTMESSAGE (NumStreamsInUse < MaxAudioStreams, "Too many streams");

	if (NumStreamsInUse == 0)// just to be sure that this is initialized properly
	{
		for (int i=0; i<MaxAudioStreams; i++)
		{
			ListOfOpenFiles[i] = NULL;
		}
	}
	for (int i=0; i<MaxAudioStreams; i++)
	{
		if (ListOfOpenFiles[i] == NULL)
		{
			ListOfOpenFiles[i] = this;
			break;
		}
	}
	NumStreamsInUse++;
	mStreamBufferLeftPtr = NULL;
	mLoopBeginBufferLeft = NULL;
	mLoopEndBufferLeft = NULL;
	mStreamBufferRightPtr = NULL;
	mLoopBeginBufferRight = NULL;
	mLoopEndBufferRight = NULL;

	Clear ();
}

PlayableStream_AX :: ~PlayableStream_AX ()
{
	AP_ASSERTMESSAGE (NumStreamsInUse >0, "error on delete");

	for (int i=0; i<MaxAudioStreams; i++)
	{
		if (ListOfOpenFiles[i] == this)
		{
			ListOfOpenFiles[i] = NULL;
			break;
		}
	}
	NumStreamsInUse--;

	
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: Clear ()
{
	mPlayState = STREAM_NONE;
	mIsStereo = false;
	
	mFilename[0][0] = 0;
	mFilename[1][0] = 0;
	mStreamLeft = NULL;
	mStreamRight = NULL;

	mLoopingReadBufferOffset = 0;
	mLoopingReadBufferSize = 0;
	mFileLoopBeginAddr = 0, mFileLoopEndAddr = 0;
	mAudioFormat = AX_PB_FORMAT_ADPCM;
	mDone = 0;
	mRemainderToPlay = 0;

	mIsReadingFromDVD = false;

	mIsLoading = false;
	mIsLooping = false;
	mIsWaitingToLoop = false;
	mTotalFileSize = 0;
	mIsInUse = false;
	if (mStreamBufferLeftPtr != NULL)
	{
		memset (mStreamBufferLeftPtr, 0, PlayableStream_AX::BufferSize);
		mPreviousPlaybackHeadPointer = (u32)OSCachedToPhysical(this->mStreamBufferLeftPtr);
	}
	mCurrentPlaybackHeadPointer = 0;

	if (mStreamBufferLeftPtr) memset (mStreamBufferLeftPtr, 0, PlayableStream_AX::GetRegularBufferSize ());// these are different sizes
	if (mLoopBeginBufferLeft) memset (mLoopBeginBufferLeft, 0, PlayableStream_AX::GetEndBufferSize ());
	if (mLoopEndBufferLeft)   memset (mLoopEndBufferLeft, 0, PlayableStream_AX::GetEndBufferSize ());
	if (mStreamBufferRightPtr)memset (mStreamBufferRightPtr, 0, PlayableStream_AX::GetRegularBufferSize ());
	if (mLoopBeginBufferRight)memset (mLoopBeginBufferRight, 0, PlayableStream_AX::GetEndBufferSize ());
	if (mLoopEndBufferRight)  memset (mLoopEndBufferRight, 0, PlayableStream_AX::GetEndBufferSize ());
}

void	PlayableStream_AX :: CleanupOncePlayIsComplete ()
{
	Clear ();
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: SetInUse (bool used) 
{
	mIsInUse = used;
}

bool	PlayableStream_AX :: IsInUse () 
{
	return mIsInUse;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: SetFileLoopPoints (u32 begin, u32 end)
{
	mFileLoopBeginAddr = AlignDownTo4Bytes (begin);
	mFileLoopEndAddr = AlignDownTo4Bytes (end);
	u32 LoopLength = (mFileLoopEndAddr - mFileLoopBeginAddr) % 32;
	if ((LoopLength) != 0)// the total buffer must align on a 32byte boundary
	{
		u32 	Addition = 32 - LoopLength;
		if (Addition > 16)// move to closest 32 byte value, not just make it longer
		Addition = -Addition;
		mFileLoopEndAddr += Addition;
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

u32		PlayableStream_AX :: GetBeginLoopPoint ()
{
	return mFileLoopBeginAddr;
}
u32		PlayableStream_AX :: GetEndLoopPoint ()
{
	return mFileLoopEndAddr;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: OpenLeftFile ()
{
	// Open stream files.
    if (DVDOpen(mFilename[0], &this->mFileHandleLeft) == false)
	{
		OSReport("Cannot open stream files\n");
	}
	
    this->mAudioFormat = AX_PB_FORMAT_ADPCM;
    this->mDone   = false;
	this->mTotalFileSize = DVDGetLength (&this->mFileHandleLeft);
    this->mRemainderToPlay   = (s32)this->mTotalFileSize;
    this->mFileReadPosition = 0;
	this->mPlayState = PlayableStream_AX::STREAM_INITIALIZING;
}

void	PlayableStream_AX :: OpenRightFile ()
{
	this->mPlayState = PlayableStream_AX::STREAM_INITIALIZING;
    
    // Open stream files.
    if (DVDOpen(mFilename[1], &this->mFileHandleRight) == false)
	{
		OSReport("Cannot open stream files\n");
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: FinishLoadOnLeft ()
{
	// Setup left channel. We set it's looping context to be our double buffer.
	//-------------------------
    DSPADPCM*	dspHeader = (DSPADPCM *)this->mStreamBufferLeftPtr;
	this->SetFileLoopPoints (Nibbles2Bytes (dspHeader->sa) + sizeof(DSPADPCM) + dspHeader->ca , 
							Nibbles2Bytes (dspHeader->ea) + sizeof(DSPADPCM));

	if (dspHeader->sa == dspHeader->ea)
	{
		mIsLooping = false;
	}
	else
	{
		SecondaryBufferReadLeft ();
	}

	// setup the buffer pointers
    u32        BufferStartAddress = Bytes2Nibbles(OSCachedToPhysical (GetDSPADPCMDataAddress (this->mStreamBufferLeftPtr)));
    u32        BufferEndAddress = BufferStartAddress + Bytes2Nibbles ((u32) PlayableStream_AX::BufferSize) - 1;
    u32        BufferCurrentAddress = BufferStartAddress + Bytes2Nibbles(sizeof(DSPADPCM)) + dspHeader->ca;
	BufferStartAddress += dspHeader->ca;// we will soon see a crash if this isn't performed. This is the buffer header.

	
    //-------------------------
	// set the addresses
	AXPBADDR   addr;
	AssignEndien (BufferStartAddress, addr.loopAddressLo, addr.loopAddressHi);
	AssignEndien (BufferEndAddress, addr.endAddressLo, addr.endAddressHi);
	AssignEndien (BufferCurrentAddress, addr.currentAddressLo, addr.currentAddressHi);
    addr.loopFlag         	= AXPBADDR_LOOP_ON;
    addr.format      	 	= AX_PB_FORMAT_ADPCM;

	//-------------------------
	AXPBADPCM  adpcm;
    FillOutAdpcmStructure (adpcm, *dspHeader);

	// Acquire voices and prep the stream left
	//-------------------------
    if ((this->mStreamLeft = AXAcquireVoice(15, NULL, 0)) == false)
	{
		OSHalt("Cannot acquire voice\n");
	}
	
	int AttenuationOfReverb = -960;
			
	if (mIsReverbEnabled == true)
	{
		AttenuationOfReverb = 0;
	}
	if (mIsStereo)
	{
		MIXInitChannel(this->mStreamLeft, 0, 0, AttenuationOfReverb, -904, -904, 0, 127, 0);// off to the left
	}
	else
	{
		MIXInitChannel(this->mStreamLeft, 0, 0, AttenuationOfReverb, -904, -904, 64, 127, 0);// center
	}
    //getLoopContext
	//-------------------------
    AXSetVoiceType   (this->mStreamLeft, AX_PB_TYPE_STREAM); // No loop context.
    AXSetVoiceAdpcm  (this->mStreamLeft, &adpcm);
    AXSetVoiceAddr   (this->mStreamLeft, &addr);
    AXSetVoiceSrcType(this->mStreamLeft, AX_SRC_TYPE_NONE);
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: FinishLoadOnRight ()
 {
	if (this->mIsLooping == true)
	{
		SecondaryBufferReadRight ();
	}
	//-------------------------

	DSPADPCM*	dspHeader = (DSPADPCM *)this->mStreamBufferRightPtr;
	u32        BufferStartAddress = Bytes2Nibbles(OSCachedToPhysical (GetDSPADPCMDataAddress (this->mStreamBufferRightPtr)));
    u32        BufferEndAddress = BufferStartAddress + Bytes2Nibbles (GetRegularBufferSize ()) - 1;
    u32        BufferCurrentAddress = BufferStartAddress + Bytes2Nibbles(sizeof(DSPADPCM)) + dspHeader->ca;
	BufferStartAddress += dspHeader->ca;// we will soon see a crash if this isn't performed. This is the buffer header.
	//-------------------------
	// set the addresses
	AXPBADDR   addr;
	AssignEndien (BufferStartAddress, addr.loopAddressLo, addr.loopAddressHi);
	AssignEndien (BufferEndAddress, addr.endAddressLo, addr.endAddressHi);
	AssignEndien (BufferCurrentAddress, addr.currentAddressLo, addr.currentAddressHi);
    addr.loopFlag         	= AXPBADDR_LOOP_ON;
    addr.format      	 	= AX_PB_FORMAT_ADPCM;

	//-------------------------
	AXPBADPCM  adpcm;
    FillOutAdpcmStructure (adpcm, *dspHeader);

	// Acquire voices and prep the stream right
	//-------------------------
    if ((this->mStreamRight = AXAcquireVoice(15, NULL, 0)) == false)
	{
		OSHalt("Cannot acquire voice\n");
	}

	int AttenuationOfReverb = -960;
			
	if (mIsReverbEnabled == true)
	{
		AttenuationOfReverb = 0;
	}
	// must be stereo
	MIXInitChannel (this->mStreamRight, 0, 0, AttenuationOfReverb, -904, -904, 127, 127, 0);// off to the right

	AXSetVoiceType   (this->mStreamRight, AX_PB_TYPE_STREAM); // No loop context.
    AXSetVoiceAdpcm  (this->mStreamRight, &adpcm);
    AXSetVoiceAddr   (this->mStreamRight, &addr);
    AXSetVoiceSrcType(this->mStreamRight, AX_SRC_TYPE_NONE);
    //AXSetVoiceState  (this->StreamRight, AX_PB_STATE_RUN);
 }
 
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: FillOutAdpcmStructure (AXPBADPCM& adpcm, const DSPADPCM& ps)
{
// Fill AXPBADPCM structure
    adpcm.a[0][0]           = ps.coef[0];
    adpcm.a[0][1]           = ps.coef[1];
    adpcm.a[1][0]           = ps.coef[2];
    adpcm.a[1][1]           = ps.coef[3];
    adpcm.a[2][0]           = ps.coef[4];
    adpcm.a[2][1]           = ps.coef[5];
    adpcm.a[3][0]           = ps.coef[6];
    adpcm.a[3][1]           = ps.coef[7];
    adpcm.a[4][0]           = ps.coef[8];
    adpcm.a[4][1]           = ps.coef[9];
    adpcm.a[5][0]           = ps.coef[10];
    adpcm.a[5][1]           = ps.coef[11];
    adpcm.a[6][0]           = ps.coef[12];
    adpcm.a[6][1]           = ps.coef[13];
    adpcm.a[7][0]           = ps.coef[14];
    adpcm.a[7][1]           = ps.coef[15];
    adpcm.gain              = ps.gain; 
    adpcm.pred_scale        = ps.ps;
    adpcm.yn1               = ps.yn1;
    adpcm.yn2               = ps.yn2;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: InitialBufferReadLeft ()
{
    s32		ActualReadLength = PlayableStream_AX::BufferSize;
	AP_ASSERT (ActualReadLength < mTotalFileSize); 
    DVDRead (&this->mFileHandleLeft, this->mStreamBufferLeftPtr, ActualReadLength, 0);
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: InitialBufferNumberCrunchingLeft ()
{
	
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: SecondaryBufferReadLeft ()
{
    DVDRead (&this->mFileHandleLeft, this->mLoopBeginBufferLeft, PlayableStream_AX::GetEndBufferSize (), this->mFileLoopBeginAddr);
	u32 endPosition = this->mFileLoopEndAddr - GetEndBufferSize ();
	DVDRead (&this->mFileHandleLeft, this->mLoopEndBufferLeft, GetEndBufferSize (), endPosition);
	DVDSeek (&(this->mFileHandleLeft), this->mFileReadPosition + PlayableStream_AX::BufferSize);
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: InitialBufferReadRight ()
{
    s32		ActualReadLength = PlayableStream_AX::BufferSize;
	DVDRead(&this->mFileHandleRight, this->mStreamBufferRightPtr, ActualReadLength, 0);
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: InitialBufferNumberCrunchingRight ()
{
	
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: SecondaryBufferReadRight ()
{
	DVDRead (&this->mFileHandleRight, this->mLoopBeginBufferRight, PlayableStream_AX::GetEndBufferSize (), this->mFileLoopBeginAddr);
	u32 endPosition = this->mFileLoopEndAddr - GetEndBufferSize ();
	DVDRead (&this->mFileHandleRight, this->mLoopEndBufferRight, GetEndBufferSize (), endPosition);
	DVDSeek (&(this->mFileHandleRight), this->mFileReadPosition + PlayableStream_AX::BufferSize);
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: LoadFiles (const char* FilenameLeft, const char* FilenameRight)
{
	AP_ASSERTMESSAGE(mIsLoaded == false, "Asset '%s' is already loaded", mLocalPath.AsChar());
	AP_ASSERTMESSAGE(Axiom::StringLength(mLocalPath.AsChar()) != 0, "No path set for playable asset - cannot load");

	this->SetInUse (true);
	this->mIsLoaded = false;
	
	this->mPlayState = PlayableStream_AX::STREAM_INITIALIZING;
	this->mIsStereo = false;
	if (FilenameRight != NULL)
	{
		mIsStereo = true;
	}
	SetupBuffers ();
	this->mIsLoading = true;
	
	strcpy (this->mFilename[0], FilenameLeft);// save the filename
	OpenLeftFile ();
	
	if (mIsStereo == true)
	{
		strcpy (this->mFilename[1], FilenameRight);// save the filename
		OpenRightFile ();
	}

	InitialBufferReadLeft ();
	if (FilenameRight != NULL)
	{
		InitialBufferReadRight ();
	}

	// 1) 
	// is to load the first section of the first file
	FinishLoadOnLeft ();

	// 2) 
	// is to load the first section of the second file
	if (mIsStereo == true)
	{
		FinishLoadOnRight ();
	}

	// 3)
	this->mRemainderToPlay   	-= PlayableStream_AX::BufferSize;
	this->mFileReadPosition 	+= PlayableStream_AX::BufferSize;

	mIsLoading = false;
		
	this->mIsLoaded = true;
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: SetupBuffers ()
{
	//--------------------------------------------------------------------------------------------
	mStreamBufferLeftPtr = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetRegularBufferSize ()]);
	mLoopBeginBufferLeft = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetEndBufferSize ()]);
	mLoopEndBufferLeft = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetEndBufferSize ()]);
	
	memset (mStreamBufferLeftPtr, 0, PlayableStream_AX::GetRegularBufferSize ());
	memset (mLoopBeginBufferLeft, 0, PlayableStream_AX::GetEndBufferSize ());
	memset (mLoopEndBufferLeft, 0, PlayableStream_AX::GetEndBufferSize ());

	if (mIsStereo)
	{
		mStreamBufferRightPtr = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetRegularBufferSize ()]);
		mLoopBeginBufferRight = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetEndBufferSize ()]);
		mLoopEndBufferRight = (u8*) AP_ALIGNED_NEW(Axiom::Memory::AUDIO_HEAP, 32, char[PlayableStream_AX::GetEndBufferSize ()]);
		memset (mStreamBufferRightPtr, 0, PlayableStream_AX::GetRegularBufferSize ());
		memset (mLoopBeginBufferRight, 0, PlayableStream_AX::GetEndBufferSize ());
		memset (mLoopEndBufferRight, 0, PlayableStream_AX::GetEndBufferSize ());
	}

	// Setup pointer.
	mStreamBufferMidPtr = (u32)OSCachedToPhysical(this->mStreamBufferLeftPtr) + PlayableStream_AX::GetEndBufferSize ();;
	mPreviousPlaybackHeadPointer = (u32)OSCachedToPhysical(this->mStreamBufferLeftPtr);
	mStreamBufferEndPtr = (u32) mStreamBufferMidPtr + BufferSize;// for now, this moves
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

bool	PlayableStream_AX :: Play(float volumeDB, float pitch) 
{
	if (this->mPlayState == PlayableStream_AX::STREAM_STARTED ||
		this->mPlayState == PlayableStream_AX::STREAM_STOPPING ||
		this->mPlayState == PlayableStream_AX::STREAM_STOPPED)
	{
		return false;
	}
	if (this->mIsLoaded == false)
	{
		Load(false);
		FinishLoadOnLeft ();
		if (mIsStereo == true)
		{
			FinishLoadOnRight ();
		}
		this->mRemainderToPlay   	-= PlayableStream_AX::BufferSize;
		this->mFileReadPosition 	+= PlayableStream_AX::BufferSize;
	}
	// start the music playing
	AXSetVoiceState  (this->mStreamLeft, AX_PB_STATE_RUN);
	if (mIsStereo == true)
	{
		AXSetVoiceState  (this->mStreamRight, AX_PB_STATE_RUN);
	}
	this->mPlayState = PlayableStream_AX::STREAM_STARTED;

	return true;
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: Kill() 
{
	if (mIsPaused == true)
		mIsPaused = false;
	Unload();
}; 

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: Pause() 
{
	mIsPaused = true;// stop the streaming and turn off the volume
	float volume = AmplitudeTodB(0); // * 10 because the MIXSetFader takes tenths of dBs 
	MIXSetFader(mStreamLeft, volume);
	if (mIsStereo)
	{
		MIXSetFader(mStreamRight, volume);
	}
}; 

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: Resume() 
{
	mIsPaused = false;// restore the volume
	MIXSetFader(mStreamLeft, GetVolumeDB());

	if (mIsStereo)
	{
		MIXSetFader(mStreamRight, GetVolumeDB ());
	}
};
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: Load(bool bAsync)
{
	if (mProperties.mFormat.mChannels == 2)
	{
		Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
		filePath += (mLocalPath.AsChar() + 10); // +10 to get rid of the '/BankRoot/' 
		
		Axiom::StaticString<255, char> FilePathRight, FilePathLeft;
		FilePathLeft = filePath.AsChar();
		FilePathLeft.Replace(".dsp", "_lef");
		FilePathLeft += "t.dsp";
		FilePathRight = filePath.AsChar();
		FilePathRight.Replace(".dsp", "_rig");
		FilePathRight += "ht.dsp";
		
		LoadFiles (FilePathLeft.AsChar (), FilePathRight.AsChar ());
	}
	else
	{
		Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
		filePath += (mLocalPath.AsChar() + 10); // +10 to get rid of the '/BankRoot/' 
		LoadFiles (filePath.AsChar(), NULL);
	}

	 mIsLoading = false;
}

void   PlayableStream_AX :: Unload() 
{
	if (mIsLoaded == false)
	{
		return;
	}
	
	if (this->mPlayState != STREAM_STOPPED)
	{
		this->mPlayState = PlayableStream_AX::STREAM_STOPPING;
	
		while ( this->mPlayState == PlayableStream_AX::STREAM_STOPPING)// infinite loop
		{
		}
	}

	if (mStreamBufferLeftPtr) 	AP_DELETE (mStreamBufferLeftPtr);
	if (mLoopBeginBufferLeft) 	AP_DELETE (mLoopBeginBufferLeft);
	if (mLoopEndBufferLeft)		AP_DELETE (mLoopEndBufferLeft);
	if (mStreamBufferRightPtr)	AP_DELETE (mStreamBufferRightPtr);
	if (mLoopBeginBufferRight)	AP_DELETE (mLoopBeginBufferRight);
	if (mLoopEndBufferRight)	AP_DELETE (mLoopEndBufferRight);
	
	mStreamBufferLeftPtr = NULL;
	mLoopBeginBufferLeft = NULL;
	mLoopEndBufferLeft = NULL;
	mStreamBufferRightPtr = NULL;
	mLoopBeginBufferRight = NULL;
	mLoopEndBufferRight = NULL;
   /* // no idea what to do with this
	if(mProperties.mStorageMode == StorageMode::IN_MEMORY)
	{
		
	}*/
	
	mIsLoaded = false;
}			
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	GetDataLeftSide(PlayableStream_AX* map)
{
	if (map->mIsStereo == true)
	{
		GetDataLeftSideStereo (map);
		return;
	}
	//OSReport("GetDataLeftSide\n");
	DvdIsReadingState = true;
	map->mIsReadingFromDVD = true;

    if (map->mIsWaitingToLoop == false)// this is your normal behaviour.
	{
		s32 	size    = PlayableStream_AX::GetEndBufferSize ();
		u8*		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset;
		
		s32 	ReadRequestLength  = map->mRemainderToPlay; 
		if (ReadRequestLength > size)
		{
			 ReadRequestLength = size;
		}
		s32  	ActualReadLength = AlignDownTo32Bytes (ReadRequestLength);
	
		DVDReadAsync(&(map->mFileHandleLeft), DestBuffer, ActualReadLength, map->mFileReadPosition, FinalDataObtainedCallback);
		if (!(AlignDownTo32Bytes(map->mRemainderToPlay  - ActualReadLength)))
		{
			(map->mDone)++;
			if (ActualReadLength)
			{
				map->mStreamBufferEndPtr = (u32)OSCachedToPhysical(DestBuffer) + ActualReadLength;
			}
		}

		map->mRemainderToPlay 	-= ActualReadLength;
		map->mFileReadPosition 	+= ActualReadLength;
	}
    else
	{
		s32 	ActualReadLength    = map->mLoopingReadBufferSize;
		u8*		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset;

		// just copy from our prefetched buffer and write into our audio buffer.
		memcpy (DestBuffer, map->mLoopEndBufferLeft + PlayableStream_AX::GetEndBufferSize () - ActualReadLength, ActualReadLength);
    	
		map->mRemainderToPlay 	= map->mTotalFileSize - map->mFileLoopBeginAddr;
		map->mFileReadPosition 	= map->mFileLoopBeginAddr;

		ActualReadLength    = map->mLoopingReadBufferRemainderSize;
		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset + map->mLoopingReadBufferOffset;

		// just copy from our prefetched buffer and write into our audio buffer.
		memcpy (DestBuffer, map->mLoopBeginBufferLeft, ActualReadLength);
		DCFlushRange(map->mStreamBufferLeftPtr +  map->mWriteBufferOffset, PlayableStream_AX::GetEndBufferSize ());
		
		map->mFileReadPosition += ActualReadLength;// update our read position
		map->mRemainderToPlay -= ActualReadLength;

		//------------------------------------------------------	
		map->mLoopingReadBufferRemainderSize = 0;// reset our values
		map->mLoopingReadBufferOffset = 0;
		map->mLoopingReadBufferSize = 0;
		DVDSeekAsync (&(map->mFileHandleLeft), map->mFileReadPosition, FinalDataObtainedCallback);
    }
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	FinalDataObtainedCallback (s32 result, DVDFileInfo* fileInfo)
{
#pragma unused(result)

	//OSReport("FinalDataObtained\n");
	PlayableStream_AX* map = PlayableStream_AX::FindFile (fileInfo);
	assert (map != NULL);

    // If we just filled the first half of the buffer we need to set the loop context 
    if (map->mWriteBufferOffset == 0 && map->mPlayState == PlayableStream_AX::STREAM_STARTED)
    {
        AXPBADPCMLOOP   loop;        

        loop.loop_pred_scale    = (u16)(*((u8*)(map->mStreamBufferLeftPtr)));
        loop.loop_yn1           = 0;
        loop.loop_yn2           = 0;

        AXSetVoiceAdpcmLoop(map->mStreamLeft, &loop);
    }

	map->mIsWaitingToLoop = false;
    map->mIsReadingFromDVD = false;
    DvdIsReadingState = false;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------
void 	GetDataLeftSideStereo (PlayableStream_AX* map)
{
	//OSReport("GetDataLeftSideStereo\n");
	DvdIsReadingState = true;
	map->mIsReadingFromDVD = true;

    if (map->mIsWaitingToLoop == false)// this is your normal behaviour.
	{
		u8*		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset;
		s32 	ReadRequestLength  = map->mRemainderToPlay; 
		if (ReadRequestLength > PlayableStream_AX::GetEndBufferSize ())
		{
			 ReadRequestLength = PlayableStream_AX::GetEndBufferSize ();
		}
		s32  	ActualReadLength = AlignDownTo32Bytes (ReadRequestLength);

		DVDReadAsync (&(map->mFileHandleLeft), DestBuffer, ActualReadLength, map->mFileReadPosition, GetDataRightSideCallback);
		if (!(AlignDownTo32Bytes(map->mRemainderToPlay  - ActualReadLength)))
		{
			(map->mDone)++;
			if (ActualReadLength)
			{
				map->mStreamBufferEndPtr = (u32)OSCachedToPhysical(DestBuffer) + ActualReadLength;
			}
		}
	}
    else
	{
		DVDSeekAsync (&(map->mFileHandleLeft), map->mFileReadPosition, GetDataRightSideSplitCallback);
		s32 	ActualReadLength;
		u8*		DestBuffer;
	    // just copy from our prefetched buffer and write into our audio buffer.
		// Left end
		ActualReadLength    = map->mLoopingReadBufferSize;
		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset;
		u32		EndPositionOffset = PlayableStream_AX::GetEndBufferSize () - ActualReadLength;
		memcpy (DestBuffer, map->mLoopEndBufferLeft + EndPositionOffset, ActualReadLength);
		
		// left begin
		DestBuffer  = map->mStreamBufferLeftPtr +  map->mWriteBufferOffset + map->mLoopingReadBufferOffset;
		memcpy (DestBuffer, map->mLoopBeginBufferLeft, map->mLoopingReadBufferRemainderSize);
		DCFlushRange(map->mStreamBufferLeftPtr +  map->mWriteBufferOffset, PlayableStream_AX::GetEndBufferSize ()); // the entire buffer   
    }
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	GetDataRightSideCallback (s32 result, DVDFileInfo* fileInfo)
{
#pragma unused(result)

	//OSReport("GetDataRightSide\n");
	PlayableStream_AX* map = PlayableStream_AX::FindFile (fileInfo);
	assert (map != NULL);
	
	if (map->mIsWaitingToLoop == false)// this is your normal behaviour.
	{
		u8*		DestBuffer  = map->mStreamBufferRightPtr +  map->mWriteBufferOffset;
		s32 	ReadRequestLength  = map->mRemainderToPlay; 
		if (ReadRequestLength > PlayableStream_AX::GetEndBufferSize ())
		{
			 ReadRequestLength = PlayableStream_AX::GetEndBufferSize ();
		}
		s32  	ActualReadLength = AlignDownTo32Bytes (ReadRequestLength);
	
		DVDReadAsync (&(map->mFileHandleRight), DestBuffer, ActualReadLength, map->mFileReadPosition, FinalDataObtainedStereoCallback);
		
		map->mRemainderToPlay 	-= ActualReadLength;
		map->mFileReadPosition 	+= ActualReadLength;
	}
	else
	{
		assert (0);// should never happen
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	GetDataRightSideSplitCallback (s32 result, DVDFileInfo* fileInfo)
{
#pragma unused(result)

	//OSReport("GetDataRightSideSplit\n");
	PlayableStream_AX* map = PlayableStream_AX::FindFile (fileInfo);
	assert (map != NULL);

	DVDSeekAsync (&(map->mFileHandleRight), map->mFileReadPosition, FinalDataObtainedStereoCallback);
	s32 	ActualReadLength;
	u8*		DestBuffer;
	// right end
	ActualReadLength    = map->mLoopingReadBufferSize;
	DestBuffer  = map->mStreamBufferRightPtr +  map->mWriteBufferOffset;
	u32		EndPositionOffset = PlayableStream_AX::GetEndBufferSize () - ActualReadLength;
	memcpy (DestBuffer, map->mLoopEndBufferRight + EndPositionOffset, ActualReadLength);

	// right begin
	DestBuffer  = map->mStreamBufferRightPtr +  map->mWriteBufferOffset + map->mLoopingReadBufferOffset;
	memcpy (DestBuffer, map->mLoopBeginBufferRight, map->mLoopingReadBufferRemainderSize);
	DCFlushRange(map->mStreamBufferRightPtr +  map->mWriteBufferOffset, PlayableStream_AX::GetEndBufferSize ()); // the entire buffer
	
	// adjust the pointers
	map->mRemainderToPlay 	= map->mTotalFileSize - map->mFileLoopBeginAddr - map->mLoopingReadBufferRemainderSize;
	map->mFileReadPosition 	= map->mFileLoopBeginAddr + map->mLoopingReadBufferRemainderSize;
	
	map->mLoopingReadBufferRemainderSize = 0;// reset our values
	map->mLoopingReadBufferOffset = 0;
	map->mLoopingReadBufferSize = 0;
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	FinalDataObtainedStereoCallback (s32 result, DVDFileInfo* fileInfo)
{
#pragma unused(result)

	//OSReport("FinalDataObtainedStereo\n");
	
	PlayableStream_AX* map = PlayableStream_AX::FindFile (fileInfo);
	assert (map != NULL);
    // If we just filled the first half of the buffer we need to set the loop context 
    if (map->mWriteBufferOffset == 0 && map->mPlayState == PlayableStream_AX::STREAM_STARTED )
    {
        AXPBADPCMLOOP   loop;

		loop.loop_pred_scale    = (u16)(*((u8*)(map->mStreamBufferRightPtr)));
		loop.loop_yn1           = 0;
		loop.loop_yn2           = 0;
		AXSetVoiceAdpcmLoop(map->mStreamRight, &loop);
		
        loop.loop_pred_scale    = (u16)(*((u8*)(map->mStreamBufferLeftPtr)));
        loop.loop_yn1           = 0;
        loop.loop_yn2           = 0;
        AXSetVoiceAdpcmLoop(map->mStreamLeft, &loop);
    }

	map->mIsWaitingToLoop = false;// prevent reentrant behavior
    map->mIsReadingFromDVD = false;
    DvdIsReadingState = false;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: FixUpAnyFileLooping ()
{
	int WhereWillTheFilePositionBeWhenWeReadNext = mFileReadPosition + GetEndBufferSize ();
	if (mIsLooping && 
		 WhereWillTheFilePositionBeWhenWeReadNext > mFileLoopEndAddr)
	{
		// setup a value for the proper number of bytes left to read before the loop point.
		
		u32 	numBytesToRead = mFileLoopEndAddr - mFileReadPosition;
		u32		numberOfBytesToRead = AlignUpTo32Bytes (numBytesToRead);
		u32 	deadSpace = PlayableStream_AX::BufferSize / 2 - numberOfBytesToRead;

		mLoopingReadBufferSize = numberOfBytesToRead;
		mLoopingReadBufferOffset = numberOfBytesToRead;
		mLoopingReadBufferRemainderSize = deadSpace;

		mIsWaitingToLoop = true;
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX :: UpdateCurrentPlaybackHead ()
{
	mCurrentPlaybackHeadPointer = (u32)(mStreamLeft->pb.addr.currentAddressHi << 16) | 
									  (mStreamLeft->pb.addr.currentAddressLo);

	if (mAudioFormat == AX_PB_FORMAT_ADPCM)
	{
		mCurrentPlaybackHeadPointer >>= 1;
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void 	PlayableStream_AX :: UpdateState ()
{
	if (IsInUse () == true && mIsLoaded == true)
	{
		switch (this->mPlayState)
		{
			case PlayableStream_AX::STREAM_NONE:   
			case PlayableStream_AX::STREAM_INITIALIZING:
				break;
	
			case PlayableStream_AX::STREAM_STARTED:
			{
				if (mIsPaused == false)
				{
					UpdateCurrentPlaybackHead ();
					
					if (this->mDone)
					{
						if (((this->mCurrentPlaybackHeadPointer < this->mPreviousPlaybackHeadPointer) && 
							((this->mPreviousPlaybackHeadPointer < this->mStreamBufferEndPtr) || (this->mStreamBufferEndPtr <= this->mCurrentPlaybackHeadPointer))) ||
							((this->mPreviousPlaybackHeadPointer < this->mCurrentPlaybackHeadPointer) && 
							((this->mPreviousPlaybackHeadPointer < this->mStreamBufferEndPtr) && (this->mStreamBufferEndPtr <= this->mCurrentPlaybackHeadPointer))))
						{
							this->mPlayState = PlayableStream_AX::STREAM_STOPPING;
							this->mStreamStoppingCount = 2;
						}
					}
					if (this->mCurrentPlaybackHeadPointer < this->mPreviousPlaybackHeadPointer)
					{
						// Fill 2nd half.
						if (DvdIsReadingState == false)
						{
							this->mWriteBufferOffset = PlayableStream_AX::BufferSize / 2;
							this->FixUpAnyFileLooping ();
							GetDataLeftSide(this);
							this->mPreviousPlaybackHeadPointer = this->mCurrentPlaybackHeadPointer;
						}
					}
					else if ((this->mPreviousPlaybackHeadPointer < this->mStreamBufferMidPtr) && 
								(this->mCurrentPlaybackHeadPointer >= this->mStreamBufferMidPtr))
					{
						// Fill 1st half.
						if (DvdIsReadingState == false)
						{
							this->mWriteBufferOffset = 0;
							this->FixUpAnyFileLooping ();
							GetDataLeftSide(this);
							this->mPreviousPlaybackHeadPointer = this->mCurrentPlaybackHeadPointer;
						}
					}
					else
					{
						this->mPreviousPlaybackHeadPointer = this->mCurrentPlaybackHeadPointer;
					}
				}
				break;
			}
			case PlayableStream_AX::STREAM_STOPPING:

				if (this->mStreamStoppingCount-- <0)
				{
					// left channel
					MIXReleaseChannel(this->mStreamLeft);
					AXFreeVoice(this->mStreamLeft);
					this->mStreamLeft = NULL;
		
					// right channel
					if (mIsStereo)
					{
						MIXReleaseChannel(this->mStreamRight);
						AXFreeVoice(this->mStreamRight);
						this->mStreamRight = NULL;
					}
					
					this->mPlayState = PlayableStream_AX::STREAM_STOPPED;
					
				}
				break;
				
			case PlayableStream_AX::STREAM_STOPPED:
	
				if (DvdIsReadingState == false)
				{
					DVDClose(&this->mFileHandleLeft);
					if (mIsStereo)
					{
						DVDClose(&this->mFileHandleRight);
					}
					this->mPlayState = PlayableStream_AX::STREAM_NONE;
					this->SetInUse (false);
					this->CleanupOncePlayIsComplete();
				}
				break;
		}
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

void	PlayableStream_AX::Update ()
{
	if(mIsLoading == false && mIsLoaded == true)
	{
		UpdateState ();
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

PlayableStream_AX* PlayableStream_AX::FindFile (const char* Filename)
{
	PlayableStream_AX* ReturnMap = NULL;
	int NumItems = MaxAudioStreams;
	for (int i=0; i<NumItems; i++)
	{
		PlayableStream_AX* ptr = ListOfOpenFiles[i];
		if (strcmp (ptr->mFilename[0], Filename) == 0 ||
			strcmp (ptr->mFilename[1], Filename) == 0)
		{
			ReturnMap = ptr;
			break;
		}
	}
	return ReturnMap;
}


//-------------------------------------------------------------------
//-------------------------------------------------------------------

PlayableStream_AX* PlayableStream_AX::FindFile (DVDFileInfo* filehandle)
{
	PlayableStream_AX* ReturnMap = NULL;
	int NumItems = MaxAudioStreams;
	for (int i=0; i<NumItems; i++)
	{
		PlayableStream_AX* ptr = ListOfOpenFiles[i];
		if (&(ptr->mFileHandleLeft) == filehandle || 
			&(ptr->mFileHandleRight) == filehandle
			)
		{
			ReturnMap = ptr;
			break;
		}
	}
	return ReturnMap;
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------

	}// namespace AudioWii
}// namespace AP


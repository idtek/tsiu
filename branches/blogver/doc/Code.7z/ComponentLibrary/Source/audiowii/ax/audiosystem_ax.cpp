#include "audiowii/ax/audiosystem_ax.h"
#include "audiowii/ax/playablesample_ax.h"
#include "audiowii/ax/playablestream_ax.h"
#include "files/filemanager.h"

#include <revolution/axfx_presets.h>

namespace AP
{
	namespace AudioWii
	{
		typedef void(*AXAuxCallback)(void *data, void *context);
		static AXAuxCallback callback = (AXAuxCallback)&AXFXReverbStdExpCallback;
		
		AudioSystem_AX* AudioSystem_AX::mInstance = NULL;
		AXVoiceInfo 	AudioSystem_AX::mAXVoices[AX_MAX_VOICES];
		AudioSystem_AX* AudioSystem_AX::GetInstance ()
		{
			if (AudioSystem_AX::mInstance == NULL)
			{
				AudioSystem_AX::mInstance = AP_NEW (Axiom::Memory::AUDIO_HEAP, AudioSystem_AX);
				AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(AudioSystem_AX::mInstance), "Audio Editor");
			}
			return AudioSystem_AX::mInstance;
		}

		AudioSystem_AX::AudioSystem_AX()
		{
			mAXBuffer = NULL;
		}

		AudioSystem_AX::~AudioSystem_AX()
		{
			AXFXReverbStdExpShutdown(&reverb);
            AXRegisterAuxACallback(NULL, NULL);
		}

		//-----------------------------------------------------
		static void* PrivateAlloc(u32 size)
		{
			return static_cast<char*>(AP_ALIGNED_ALLOC(Axiom::Memory::DEFAULT_HEAP, size,  32));
		}
		
		static void PrivateFree(void* addr)
		{
			AP_FREE (addr);
		}
		//-----------------------------------------------------

		void AudioSystem_AX::Initialize(int NumChannels)
		{
			// do ax init
			AIInit(NULL);

			// Create Memory for AX Lib to use
			// *** this mem should be MEM1 as it contains voice structures to modify playing voices ***
			int axMemSize = AXGetMemorySize(AX_MAX_VOICES); 	    
			mAXBuffer = static_cast<char*>(AP_ALIGNED_ALLOC(Axiom::Memory::DEFAULT_HEAP, axMemSize,  32));
			AXInitSpecifyMem(AX_MAX_VOICES, mAXBuffer);

			// init the mixer, this allows us mixing console style manipulation of the voices.
			int mixMemSize = MIXGetMemorySize(AX_MAX_VOICES);
			mMIXBuffer = static_cast<char*>(AP_ALIGNED_ALLOC(Axiom::Memory::DEFAULT_HEAP, mixMemSize,  32)); 
			MIXInitSpecifyMem(mMIXBuffer);
			
			Axiom::Log("AudioSystem", "AX System (Mixer & AX) using %d kB", (axMemSize + mixMemSize)/1024);

			AXRegisterCallback(&AXAudioFrameCallback);
			// call base
			AudioSystemWii::Initialize(NumChannels);

			// turn on reverb 
			AXFXSetHooks((AXFXAlloc)PrivateAlloc, (AXFXFree)PrivateFree);
			AXFX_PRESET_REVERBSTD_EXP_OLD_TYPE1(&reverb);
			AXFXReverbStdExpInit(&reverb);
		}
		
		void AudioSystem_AX::LogMemoryStats()
		{
			int memUsage = 0;

			//BankNode::IterateDown(&mRootBank, BankNodeIterators::GetDataSize (), &memUsage, true);
   
			Axiom::Log("AudioSystemWii", "AX Sample Memory = %d kB", memUsage/1024);
		}

		void AudioSystem_AX::Destroy()
		{
		   
		}

		void AudioSystem_AX::UpdateTime(int deltaMilliseconds)
		{	
			AudioSystemWii::UpdateTime(deltaMilliseconds);
		}

		void AudioSystem_AX::AXVoiceCallback(void* pVoiceIn)
		{
			AXVPB *voice = (AXVPB*)pVoiceIn;

			// Note: Voice is auto-magically stopped by AX layer when dropped
			
			
			// Application clean-up
			mAXVoices[voice->index].voice = NULL;
			mAXVoices[voice->index].state = AXVOICE_STATE_STOPPED;
		}

		void AudioSystem_AX::AXAudioFrameCallback(void)
		{
			u32 i;
			BOOL bStopFlag = FALSE;
		
			// Monitor each voice and process states. This must be done in the
			// callback
			for (i = 0; i < AX_MAX_VOICES; i++)
			{
				AXVoiceInfo* pVoiceInfo = &AudioSystem_AX::mAXVoices[i];
				
				// Skip NULL entries
				if (pVoiceInfo->voice == NULL) continue;
		
				switch (pVoiceInfo->state)
				{
					case AXVOICE_STATE_STOPPED:
						break;
						
					case AXVOICE_STATE_START:
						// Start the voice
						AXSetVoiceState(pVoiceInfo->voice, AX_PB_STATE_RUN);
						pVoiceInfo->state = AXVOICE_STATE_STARTED;
						break;
						
					case AXVOICE_STATE_STARTED:
						// Skip a frame
						pVoiceInfo->state = AXVOICE_STATE_PLAYING;
						break;
						
					case AXVOICE_STATE_PLAYING:
						// Check to see if the voice is finished, if so, stop it
						if (pVoiceInfo->voice->pb.state == AX_PB_STATE_STOP)
						{
							bStopFlag = TRUE;
						}
						
						break;
						
					case AXVOICE_STATE_STOP:
						// Force a voice to stop
						bStopFlag = TRUE;
						break;
				}
		
				// A voice must be stopped
				if (bStopFlag)
				{
					AXSetVoiceState(pVoiceInfo->voice, AX_PB_STATE_STOP);
					AXFreeVoice(pVoiceInfo->voice);
					pVoiceInfo->voice = NULL;
					pVoiceInfo->state = AXVOICE_STATE_STOPPED;
					bStopFlag = FALSE;
				}
			}

			PlayableStream_AX::UpdateAllStreams();
			MIXUpdateSettings();
		}

		void	AudioSystem_AX::SetReverb (ReverbSetting rs)
		{
			switch (rs)
			{
				case ReverbNone:
					AXFXReverbStdExpShutdown(&reverb);
					AXRegisterAuxACallback(NULL, NULL);
					break;
				case 1:
					AXFX_PRESET_REVERBSTD_EXP_OLD_TYPE1(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 2:
					AXFX_PRESET_REVERBSTD_EXP_OLD_TYPE2(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 3:
					AXFX_PRESET_REVERBSTD_EXP_METAL_PIPE(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 4:
					AXFX_PRESET_REVERBSTD_EXP_METAL_TANK(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 5:
					AXFX_PRESET_REVERBSTD_EXP_SMALL_ROOM(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 6:
					AXFX_PRESET_REVERBSTD_EXP_MEDIUM_ROOM(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;

				case 7:
					AXFX_PRESET_REVERBSTD_EXP_LARGE_ROOM(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 8:
					AXFX_PRESET_REVERBSTD_EXP_LONG_ROOM(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 9:
					AXFX_PRESET_REVERBSTD_EXP_SMALL_HALL(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 10:
					AXFX_PRESET_REVERBSTD_EXP_LARGE_HALL(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 11:
					AXFX_PRESET_REVERBSTD_EXP_CAVERNOUS(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
		
				case 12:
					AXFX_PRESET_REVERBSTD_EXP_CATHEDRAL(&reverb);
					AXFXReverbStdExpSettings(&reverb);
					AXRegisterAuxACallback(callback, (void*)&reverb);
					break;
				}
			}
	}
}
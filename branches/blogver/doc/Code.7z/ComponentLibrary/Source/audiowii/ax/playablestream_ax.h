#ifndef _AUDIOSTREAM_WII_H
#define _AUDIOSTREAM_WII_H

#include <revolution.h>
#include <revolution/mix.h>
#include <revolution/mem.h>
#include "audiowii/playable.h"

namespace AP
{
	namespace AudioWii
	{
		class PlayableStream_AX : public Playable
		{
		public:
			
			enum PLAY_STATE {STREAM_NONE, STREAM_INITIALIZING, STREAM_STARTED, STREAM_STOPPING, STREAM_STOPPED};
			static const int MaxAudioStreams= 16;
			
			PlayableStream_AX ();
			~PlayableStream_AX ();

			 // Static public function, to avoid this class getting linked out
			static void Dummy(void);
			
			//-------------------------------------------------
			// Interface - implemented by a platform-specific playable object
			bool	Play(float volumeDB, float pitch); 	// Start playing the sound regardless of any delay
			void	Kill();					// Stop the sound playback regardless of any amplitude envelope
			void	Pause();				// Pause the sound. Maintain current playback position
			void	Resume();				// Resume the sound playing from Paused position
			void	Load(bool bAsync);		// Load
			void	Unload();				// Unload			

			void	StopLooping () 				{mIsLooping = false;}// this will eventually stop playing

		public:// system-wide functions
			//-------------------------------------------------
			static void	UpdateAllStreams ();// must be called every frame  every 3ms
			
		private:

			// Static private member so compiler doesn't strip this class
			static int		mDummy;
			
			enum {BufferSize = 64*1024, HalfBufferSize = BufferSize/2};
			
			void	SetFileLoopPoints (u32 begin, u32 end);
			u32		GetBeginLoopPoint ();
			u32		GetEndLoopPoint ();
			
			void	OpenLeftFile ();
			void	OpenRightFile ();
			void	FinishLoadOnLeft ();
			void	FinishLoadOnRight ();

			void	InitialBufferReadLeft ();
			void	InitialBufferNumberCrunchingLeft ();
			void	SecondaryBufferReadLeft ();

			void	InitialBufferReadRight ();
			void	InitialBufferNumberCrunchingRight ();
			void	SecondaryBufferReadRight ();
			
			void	FillOutAdpcmStructure (AXPBADPCM& adpcm, const DSPADPCM& ps);
			void	FixUpAnyFileLooping ();
			void	UpdateCurrentPlaybackHead ();

			void	CleanupOncePlayIsComplete ();

			void	LoadFiles (const char* FilenameLeft, const char* FilenameRight);
			void	SetupBuffers ();

			//-------------------------------------------------
			
		public:// these are public because of the global callback functions that must modify them
			static int		GetRegularBufferSize () {return BufferSize;}
			static int		GetEndBufferSize () {return HalfBufferSize;}
						
			static PlayableStream_AX* FindFile (DVDFileInfo* filehandle);
			static PlayableStream_AX* FindFile (const char* Filename);
			
			void	Clear ();
			void	SetInUse (bool used);
			bool	IsInUse ();
			//-------------------------------------------------
			void 	UpdateState ();// called from callback
			//-------------------------------------------------
			void	Update ();// called from mainloop, you must call this every frame
			//-------------------------------------------------
			
			PLAY_STATE  	mPlayState;
			char			mFilename[2][64];
			DVDFileInfo 	mFileHandleLeft;
			AXVPB*			mStreamLeft; // must add this to the system
			u8*				mStreamBufferLeftPtr;
			u32         	mStreamBufferMidPtr;
			u32         	mStreamBufferEndPtr;
			
			u8*				mLoopBeginBufferLeft;
			u8*				mLoopEndBufferLeft;
			s32         	mWriteBufferOffset;

			DVDFileInfo 	mFileHandleRight;
			AXVPB*			mStreamRight; // must add this to the system
			u8*				mStreamBufferRightPtr;
			u8*				mLoopBeginBufferRight;
			u8*				mLoopEndBufferRight;

			u32         	mPreviousPlaybackHeadPointer;
			u32				mCurrentPlaybackHeadPointer;
			
			s32				mLoopingReadBufferSize;
			s32				mLoopingReadBufferOffset;
			s32			 	mLoopingReadBufferRemainderSize;

			u32         	mFileReadPosition;
			u32 			mFileLoopBeginAddr, mFileLoopEndAddr;
			
			u16         	mAudioFormat;
			s32         	mDone;
			s32         	mRemainderToPlay;

			int				mTotalFileSize;
			int				mStreamStoppingCount;

			bool			mIsLooping;
			bool			mIsLoading;
			bool			mIsWaitingToLoop;// set when we are ready.
			bool			mIsReadingFromDVD;
			bool			mIsInUse;
			bool			mIsStereo;
			
			static PlayableStream_AX* ListOfOpenFiles [MaxAudioStreams];
			static int		NumStreamsInUse;
			int				mVolumeDBX10;		// volume in dB X 10 (1 == .1 dB)

		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	} // namespace AudioWii
}// namespace AP


#endif // _AUDIOSTREAM_WII_H
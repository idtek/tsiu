#ifndef _BANKNODEITERATORS_H
#define _BANKNODEITERATORS_H

#include <collections/list.h>
#include <core/autopointer.h>
#include "audiowii/soundproperties.h"
#include "audiowii/bank.h"

///////////////////////////////////////////////////////////////////
// Functions to operate on bank nodes in the bank tree structure
///////////////////////////////////////////////////////////////////

#include "audiowii/bank.h"

namespace AP
{
	namespace AudioWii
	{

		struct PlayParams
		{
			float 	mAttack;
			float 	mDelay;
			int		mID;
			float 	mX;
			float 	mY;
			float 	mZ;
		};

		struct StopParams
		{
			int 	mEntityID;
			float 	mRelease;
			bool    mUnloadWhenStopped;
		};

		// typedef for banknode iterator function over the nodes
		typedef void(*BankNodeIterator)(Playable* pPlayableObject, void* pUserData);

		struct LoadParams
		{
			const char* mActorName;
			bool 		mAsync;
		};
			
		class BankNodeIterators
		{
		public:

			// Get the summed volume of nodes (up or down the tree)
			static void GetSummedVolume(Playable* pPlayableObject, void* pUserData);

			// Apply the summed volume (used if a parent node has had it's master volume changed)
			static void ApplySummedVolume(Playable* pPlayableObject, void* pUserData);

			// Play, Stop. pUserData == float* == attack time for play, release time for stop
			static void Play(Playable* pPlayableObject, void* pUserData);
			static void Stop(Playable* pPlayableObject, void* pUserData);
	
			// Load: pUserData = LoadParams*
			static void Load(Playable* pPlayableObject, void* pUserData);

			// Unload: pUserData not used
			static void Unload(Playable* pPlayableObject, void* pUserData);

			// Pause, Mute
			// pUserData == address of fade time (float*)
			static void Pause(Playable* pPlayableObject, void* pUserData);

			// Resume pUserData[0] = float* (attack)
			//        pUserData[1] = float* (delay)
			//        pUserData[2] = bool*  (forceRestart)
			static void Resume(Playable* pPlayableObject, void* pUserData);

			// Mut. pUserData not used
			static void Mute(Playable* pPlayableObject, void* pUserData);
			static void UnMute(Playable* pPlayableObject, void* pUserData);
			   
			// Update the time elapsed for the bank/asset.
			// This is used to apply envelopes (amplitude attack, release, etc.)
			// pUserData = address of an int to call UpdateTime() with
			static void UpdateTime(Playable* pPlayableObject, void* pUserData);

			// Apply a relative volume change to the node
			// pUserData = address of a float with the dB volume change
			static void ChangeGainRelative(Playable* pPlayableObject, void* pUserData);

			// Apply an absolute gain change to the node
			// pUserData = address of a float with the dB absolute value (from -90.4 -> 0 dB)
			static void ChangeGainAbsolute(Playable* pPlayableObject, void* pUserData);

			// Restore Master Volume of the node
			// pUserData NOT used
			static void ChangeGainRestore(Playable* pPlayableObject, void* pUserData);

			// Set the pitch
			// pUserData = float[2]. float[0] = pitch change (cents), float[1] = duration (ms)
			static void SetPitch(Playable* pPlayableObject, void* pUserData);

			// Set the pitch, relative to current value
			// pUserData = float[2]. float[0] = pitch change (cents), float[1] = duration (ms)
			static void SetPitchRelative(Playable* pPlayableObject, void* pUserData);
			
		};
	}
}


#endif  // _BANKNODEITERATORS_H
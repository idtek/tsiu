#ifndef _PLAYABLE_H
#define _PLAYABLE_H
#include "audiowii/soundproperties.h"
#include "audiowii/dsputils.h"
#include <core/classedenum.h>
#include <core/pointer.h>
#include <core/time.h>
#include <core/random.h>
#include "files/filemanager.h"
#include "math/vector3.h"

/////////////////////////////////////////////////////////////////////////////////////
// Playable class
//
// Base class for anything that is "playable" i.e. a bank, sample (pcm, dsp, mp3), a stream
// a midi file, whatever else... will derive from this and use it as an interface
//
/////////////////////////////////////////////////////////////////////////////////////

using namespace Axiom::Math;

namespace AP
{
	namespace AudioWii
	{
		// forward dec
		class BankNode;
		struct SoundPackage;

		struct DelayedStart
		{
			int		mEntityID;
			float	mDelayTimeRemaining;
			float   mEventAttack;
			Vector3 mPosition;
		};

		static const float MIN_DB_VOLUME		= -90.4f;
		
		typedef Axiom::Collections::DynamicList<Axiom::Pair< const Axiom::FileManager::FileInfo*, Axiom::Byte* > > LoadList;
		typedef Axiom::StaticString<85, char> AudioPathString; 
		typedef Axiom::StaticString<32, char> AudioNameString; // longest one is 29 chars in current data (April 6 2009)
		
		class Playable
		{
		public:
			
			Playable();
			virtual ~Playable() {};

			// Playable interface. Contains platform independent code that manages the internal (platform-specific) playable object
			virtual void    Load(bool bAsync);
			virtual void   	Unload();
			virtual void	Play(int entityID, Vector3& position, float attackMS, float delayMS, bool bUnloadWhenStopped); 	// Initiate playback of the sound with attack time (may not start if the sound is delayed)
			virtual void	Stop(float releaseMS, bool bUnloadWhenStopped, int entityID);	// End the sound w/ release time. Optionally unloading when 
			virtual void 	Pause(float releaseMS);							// Pause the sound, keep resources available and current position
			virtual void 	Resume(float attackMS, float delayMS, bool bForceStart);		// Resume (un-pause) the sound, optionally forcing the start
			virtual void	Mute();											// Calls SetVolumeDB() Sets Volume to -90.4
			virtual void    UnMute();										// Restores volume to mRestoreVolume
			virtual void	ToggleDSPFilter(bool mEnable) {};				// Add / Remove a DSP Effect
		      	
			// Internal Playable Interface - implemented by a platform-specific playable object (sound, stream, midi, etc.)
			// this ideally should be pure virtuals, but because the tool creates them we can't (for now...)
			virtual void	InternalLoad(bool bAsync) 	{};		// Load
			virtual void	InternalLoadFromPackage(char* pData, int size, SoundPackage* package) {}; // load from a memory point (i.e. from a parsed .asb file)
			virtual bool	InternalUnload() 			{ return true; };		// Unload	
			virtual bool	InternalPlay(int entityID, Vector3& position, float volumeDB, float pitch) { return true; } // Start playing the sound regardless of any delay, at specified volume (0 -> -96dB)
			virtual void	InternalStop(int entityID) {};					// Stop the sound playback regardless of any amplitude envelope
			virtual void	InternalPause() {};					// Pause the sound. Maintain current playback position
			virtual void	InternalResume() {};				// Resume the sound playing from Paused position
			virtual void 	InternalSetPitch(float pitch) {}; 	// Set the pitch of sound playing, in cents
			virtual float	InternalGetPitch() const { return 0.0f; }	// Get the pitch the sound playing, in cents
			virtual void	InternalVerifyStreams() {};			// check disc access for streams - may need to mute or reload if they are starving
			virtual int		GetNumChannelsPlaying() const { return 0; }
			
			virtual void	SetVolumeDB(float dBVolume)	{ UNUSED_PARAM(dBVolume); }; // Set Volume, in dB below digital max
			virtual float   GetVolumeDB() const { return 0.0f; };
			virtual void	OnLoadFinished(const Axiom::FileManager::FileInfo* fileInfo) {};

			virtual void	LoadFromStream (const char* Base64_encoded_data, const char* Path, int datasize, int decompressed_size) {}// base64 encoded audio

			// Other platform-independent code
			void			SetMasterVolumeDB(float dBVol);		// sets the master volume for this object
			float			GetMasterVolumeDB()				{ return mProperties.mMasterVolumeDB; }
			float			CalculateStartVolumeDB();	// Get the summed volume for this playable object, plus any random attenuation
			float			CalculateStartPitch();		// Get the starting pitch, plus any random pitch variation
			float			GetRandomAttenuation();		// Get a random playback attenuation for this object
			float			GetRandomPitch();			// Get a random pitch variation for this object
			
			void			SetVolumeFade(float volumeTarget, float durationMilliseconds); // start a volume fade
			void			SetPitchEnv(float pitchTarget, float durationMilliseconds);   // star  a pitch fade
			void			SetPitchEnvRelative(float pitchTarget, float durationMilliseconds);   // star  a pitch fade

			const char*				GetName() const					{ return mName.AsChar(); }
			const SoundFormat*		GetSoundFormat() const			{ return &mFormat; }
		    AudioPathString			GetLocalPath() const;
			const SoundProperties& 	GetProperties() const			{ return mProperties; }
			Axiom::Pointer<BankNode> GetParentNode() const			{ return mParentNode; }
			virtual void			SetParentNode(BankNode* pNode) 	{ mParentNode = pNode; }
			virtual bool			IsPlaying()	const				{ return mIsPlaying; }
			virtual bool			IsStopping() const				{ return mApplyingRelease; }
			virtual bool			IsPaused() const				{ return (mPauseCount > 0); }
			virtual bool			IsLoaded() const				{ return mIsLoaded; }
			virtual bool			IsMuted() const					{ return mIsMuted; }
			virtual bool			UnloadWhenStopped() const 		{ return mUnloadWhenStopped; }
			virtual void			UnloadWhenStopped(bool unload)  { mUnloadWhenStopped = unload; }
			virtual void			UnloadNextFrame(bool unload)  	{ mUnloadNextFrameCount = (unload && mProperties.mStorageMode == StorageMode::STREAMING) ?  30 : 1; }
			virtual void			SetLoaded(bool loaded)			{ mIsLoaded = loaded; }
			virtual void			SetLoading(bool loading)		{ mIsLoading = loading; }
			virtual void			SetPlaying(bool playing)		{ mIsPlaying = playing; }  
			virtual void			SetResumeVolume(float volume)   { mResumeVolume = volume; } 
			
			virtual void			UpdateTime(int deltaMilliseconds);
			virtual void			StreamLoadComplete(bool success);

			virtual void			IncrementRefCount()			{ mRefCount++; }
			virtual void			DecrementRefCount()			{ mRefCount--; }
			virtual int				GetRefCount() const			{ return mRefCount; }

			void					EnableReverb (bool enabled=true) {mIsReverbEnabled = enabled;}// the system must also be enabled for this to work

			static int				GetNumLoadsExpected()		{ return mLoadsExpected; }
			

		protected:

			// protected - this is the data required to implement the internal interface (mostly loading stuff needed to be set directly)
			BankNode* 			mParentNode;   		// Parent Node in which this asset lives
			LoadList			mLoadList;			// A list of currently loading files
			bool				mIsLoaded;			// Load state
			SoundPackage*		mPackage;		// Is this loaded via a bank/package?
			static int			mLoadsExpected;		// How many loads are pending.
			SoundProperties		mProperties;		// Rendering Properties (volume, pan, delay, pitch, etc.)
			bool				mIsPlaying;			// Playing state
			bool 				mUnloadWhenStopped; // Flag to unload the sound when it is finished playing
			int					mUnloadNextFrameCount;	// Falg to unload the sound next frame (can't do it based on the above flag, threadlock might happen)
			bool				mIsLoading;			// Flag set by sublcass to indicate a stream is async loading
			bool				mCancelledLoad;		// Flag set if Unload() was received while the sound was loading asynchronously
			bool			 	mStartWaitingOnReady; // Flag to start playback of async loaded streams
			bool			 	mStartNextFrame; 	// Flag to start playback of async loaded streams on the next frame
			int 				mPauseCount;		// Could be paused > 1 time (pause game, let controller die, etc.) so need to keep track of how many pauses we have
													// NOTE: mIsPlaying is still true while paused
			float				mStartupVolume;		// for sounds that are waiting for the disc to play
			int					mMaxPolyphony;		// Maximum Number of these to play at once
			
		private:
			
			AudioNameString	mName;				// Name of the playable asset/node 		
			SoundFormat			mFormat;			// Audio Format - sample rate, channels, encoding, etc.   
			DynamicList<DelayedStart>	mDelayedStarts;	// Delayed starts to queue up	
			
			bool				mIsMuted;			// Mute state - no guarantees on the proper working of this amidst resuming/pausing/fading/etc, as it's only used by the tool.
			bool				mIsReverbEnabled;	// requiring the system-wide reverb to be enabled, when you play this sound next, the attenuation for reverb will be set
			int					mRefCount;			// Keep track of how many instances of this sound are playing
			float				mInitialFadeVolume; // Keep track of the starting volume while fading
			float				mInitialFadePitch;  // Keep track of the starting pitch while applying pitch env
			float				mTargetFadeVolume;	// If we are fading volume, the target volume
			float 				mTargetFadePitch;	// If we are applying a pitch envelope
			float				mVolumeEnvDurationMS;	// Fade duration for volume envelope, in milliseconds
			float				mPitchEnvDurationMS;	// Fade duration for pitch envelope, in milliseconds
			
			int					mVolumeEnvPositionMS;// Position in the Volume Envelope
			int					mPitchEnvPositionMS; // Position in the Pitch Envelope
			
			bool				mApplyingRelease;	// Are we currently applying our release?
			bool				mApplyingVolumeEnv;	// Are we currently applying a volume evn?
			bool				mApplyingPitchEnv;	// Are we currently applying a volume evn?
			bool				mPausing;			// Are we currently applying a pause fade?
			float				mResumeVolume;		// Volume to resume to when un-pausing or un-muting
			

			Axiom::Random		mRandomizer;		// to get a random attenuation / pitch
						
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _PLAYABLE_H

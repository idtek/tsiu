#ifndef _EVENT_H
#define _EVENT_H

#include "audiowii/bank.h"
#include "audiowii/eventactions.h"
#include <Collections/list.h>

namespace AP
{
	namespace AudioWii
	{
		//////////////////////////////////////////////////////////////////////////////////////
		// Event class
		//
		// Contains a list of actions, a name (stringCRC).
		// Events are called by PlayEvent in the AudioSystem class, which takes this string
		// as an identifier
		//////////////////////////////////////////////////////////////////////////////////////
		class Event
		{
			
		public:
			typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer< EventAction > > EventActionList;
			
			Event();
			Event(const char* name) { mName = name; }
			~Event() {};
		
			const char* GetName() const					{ return mName.AsChar(); }
			const EventActionList& GetActions() const	{ return mActions; }

			void SetName(Axiom::StringCRC name) { mName = name; }		

		private:
			
			float				mVolume;	// 0 -> 1.0
			EventActionList		mActions;	// List of Actions which this Event Triggers
			Axiom::ShortString	mName;
			
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _EVENT_H
#ifndef _EVENTACTIONS_H
#define _EVENTACTIONS_H

#include "audiowii/bank.h"
#include "audiowii/dspeffects.h"
#include <Collections/list.h>

namespace AP
{
	namespace AudioWii
	{
		//////////////////////////////////////////////////////////////////////////////////////
		// Action class (base interface)
		//
		// Each Event can have n actions. Actions are an operation (of type EventActions above)
		// on one or more playable nodes (banks).
		// The sound banks are referenced by an array of string identifiers.
		//////////////////////////////////////////////////////////////////////////////////////
		class EventAction
		{
		public:
			typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer< AudioPathString > > PlayableNodeList;

			EventAction() { }
			~EventAction() {};
			void AddBank(Bank* bank);
			const PlayableNodeList& GetNodeList() const		{ return mNodeList; }

			// derived classes must implement this
			virtual void Execute(Playable* pNode) const  {} ;

		protected:
			PlayableNodeList 	mNodeList;		// the playable nodes to apply the action to

			virtual void Log(Playable* pNode) const; // log this event happening - Axiom::Log, maybe create a remoting event and send it 

		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		/////////////////////////////////////////////////////////////////////
		// Load. Bool for loading async or not
		/////////////////////////////////////////////////////////////////////
		class EventActionLoad : public EventAction
		{
		public:
			EventActionLoad() : mAsync(false) { }
			virtual ~EventActionLoad() {};
			virtual void Execute(Playable* pNode) const;

			bool				mAsync;
			Axiom::ShortString	mPackageName;

			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		/////////////////////////////////////////////////////////////////////
		// Unload. No parameters
		/////////////////////////////////////////////////////////////////////
		class EventActionUnload : public EventAction
		{
		public:
			EventActionUnload() { }
			virtual ~EventActionUnload() {};
			virtual void Execute(Playable* pNode) const;

			AP_DECLARE_POLYMORPHIC_TYPE();
		};
		
		
		/////////////////////////////////////////////////////////////////////
		// Play Action. Params for attack time.
		/////////////////////////////////////////////////////////////////////
		class EventActionPlay : public EventAction
		{
		public:
			EventActionPlay() : mAttack(0), mDelay(0), mEntityID(0), mPosition(Axiom::Math::Vector3::Zero()) { }
			virtual ~EventActionPlay() {};
			virtual void Execute(Playable* pNode) const;

			int   mEntityID;
			float mAttack;
			float mDelay;
			Axiom::Math::Vector3 mPosition;
			
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Stop Action. Params for release time & flag to unload when stopped.
		//////////////////////////////////////////////////////////////////////
		class EventActionStop: public EventAction
		{
		public:
			EventActionStop() : mRelease(0), mUnloadWhenStopped(false), mEntityID(-1) { }
			virtual ~EventActionStop() {}
			virtual void Execute(Playable* pNode) const;

			float mRelease;
			bool  mUnloadWhenStopped;
			int	  mEntityID;

			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Pause Action. Parameter for release/fade time.
		//////////////////////////////////////////////////////////////////////
		class EventActionPause: public EventAction
		{
		public:
			EventActionPause() : mRelease(0) { }
			virtual ~EventActionPause() {};
			virtual void Execute(Playable* pNode) const;

			float mRelease;
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Resume Action. No parameters
		//////////////////////////////////////////////////////////////////////
		class EventActionResume: public EventAction
		{
		public:
			EventActionResume() : mForceStart(false), mAttack(0), mDelay(0) {}
			virtual ~EventActionResume() {};
			virtual void Execute(Playable* pNode) const;

			float mAttack;
			float mDelay;
			bool  mForceStart;
			
			AP_DECLARE_POLYMORPHIC_TYPE();
		};


		//////////////////////////////////////////////////////////////////////
		// Relative Gain Change.
		//////////////////////////////////////////////////////////////////////
		class EventActionChangeGainRelative: public EventAction
		{
		public:
			EventActionChangeGainRelative() { 
												mDeltaGainDB = 0.0f;
												mDuration = 0.0f; 
											}

			virtual ~EventActionChangeGainRelative() {};
			virtual void Execute(Playable* pNode) const;

			float mDeltaGainDB;
			float mDuration;
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Absolute Gain Change
		//////////////////////////////////////////////////////////////////////
		class EventActionChangeGainAbsolute: public EventAction
		{
		public:
			EventActionChangeGainAbsolute() { 
												mAbsoluteGainDB = 0.0f;
												mDuration = 0.0f; 
											}

			virtual ~EventActionChangeGainAbsolute() {};
			virtual void Execute(Playable* pNode) const;

			float mAbsoluteGainDB;
			float mDuration;
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Restore Gain
		//////////////////////////////////////////////////////////////////////
		class EventActionChangeGainRestore: public EventAction
		{
		public:
			EventActionChangeGainRestore() {};
			virtual ~EventActionChangeGainRestore() {};
			virtual void Execute(Playable* pNode) const;
			float mDuration;
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Set a pitch envelope - primitive for now, first round
		//////////////////////////////////////////////////////////////////////
		class EventActionSetPitch : public EventAction
		{
		public:
			EventActionSetPitch() :  mDuration(0.0f), mCents(0.0f), EventAction() {};
			virtual ~EventActionSetPitch() {};
			virtual void Execute(Playable* pNode) const;
			float mDuration;
			float mCents;		// pitch change, in cents
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Set Pitch Relative
		//////////////////////////////////////////////////////////////////////
		class EventActionSetPitchRelative : public EventAction
		{
		public:
			EventActionSetPitchRelative() :  mDuration(0.0f), mCents(0.0f), EventAction() {};
			virtual ~EventActionSetPitchRelative() {};
			virtual void Execute(Playable* pNode) const;
			float mDuration;
			float mCents;		// pitch change, in cents
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Enable / Disable a HighPass / Lowpass filter
		//////////////////////////////////////////////////////////////////////
		class EventActionToggleDSPFilter : public EventAction
		{
		public:
			EventActionToggleDSPFilter() : mEnable(false), EventAction() {};
			virtual ~EventActionToggleDSPFilter() {};
			virtual void Execute(Playable* pNode) const;
			bool 			mEnable;
			float			mCutoff;
			FilterType   	mFilterType;
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Set Master Reverb Properties
		//////////////////////////////////////////////////////////////////////
		class EventActionSetMasterReverbProperties : public EventAction
		{
		public:	
				
			EventActionSetMasterReverbProperties() : EventAction(),
													 mReverbProperties(0, 0, 0, 0, 0) {};

			ReverbProperties mReverbProperties;	
			AP_DECLARE_POLYMORPHIC_TYPE();
		};

		//////////////////////////////////////////////////////////////////////
		// Set Reverb Send Amount
		//////////////////////////////////////////////////////////////////////
		class EventActionSetReverbSend : public EventAction
		{
		public:	
				
			EventActionSetReverbSend() : EventAction(),
										 mReverbSend(-90.6f) {};

			float mReverbSend;	
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
}
}

#endif

#ifndef _AUDIOSYSTEM_FMOD_H
#define _AUDIOSYSTEM_FMOD_H

#include <core/autopointer.h>
#include <memory/apmemory.h>
#include "audiowii/audiosystem.h"
#include "collections/array.h"

#include "fmod.hpp"

//#include "fmodwii.h"

namespace AP
{
	namespace AudioWii 
	{
		class AudioSystem_FMOD : public AudioSystemWii
		{
			friend class Playable_FMOD;

		public:
			static const int FMOD_MEMORY_SIZE = IN_MB(2) + IN_KB(690);
			
			AudioSystem_FMOD();
			virtual ~AudioSystem_FMOD();
			
			// Init, Destroy
			virtual void Initialize(int NumChannels);
			virtual void LogMemoryStats();
			virtual void UpdateTime(int deltaMilliseconds);
			virtual void UpdateCamera(Vector3 position, Vector3 direction, Axiom::Math::Vector3 top);
			virtual void SetReverbProperties(const ReverbProperties& properties);
			static void  TranslateVector(Vector3& position, FMOD_VECTOR* vec);

			// For the wiimote muting/unumuting
			void ExternalSpeakerControl(int controllerID, bool enabled);

			void Destroy();
			FMOD::System* GetFMODSystem() { return mFMODSystem; }

			static AudioSystem_FMOD* GetInstance();
			static bool              IsInit();

#if !CORE_FINAL
			void SendRemotingLoadEvent(AudioWii::Events::AudioRemotingBankLoadEvent& event); // helper func to send a memory update message to streaker
#endif

		private:
			static AudioSystem_FMOD* mInstance;
	
			FMOD::System*			mFMODSystem;				// Main FMOD System
			FMOD_CREATESOUNDEXINFO  mFMODSoundInfo;				// used to input a .dls to use with midi files
			Axiom::FileString		mPathDLS;					// the path to the .dls file referenced by above fmodsound info

			static FMOD_RESULT F_CALLBACK FMODCallback(FMOD_CHANNEL *channel, FMOD_CHANNEL_CALLBACKTYPE type, int command, unsigned int commanddata1, unsigned int commanddata2);
			static FMOD_RESULT F_CALLBACK FMODNonblockCallback( FMOD_SOUND* sound, FMOD_RESULT loadResult);
			
		};
	}
}

#endif // _AUDIOSYSTEM_FMOD_H
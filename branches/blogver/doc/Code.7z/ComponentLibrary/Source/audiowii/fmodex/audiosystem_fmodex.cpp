#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "files/filemanager.h"
#include "fmod_errors.h"

#if CORE_WII
#include "fmodwii.h"
#include <revolution/sc.h>
#include <revolution/axfx.h>
#endif

namespace AP
{
	namespace AudioWii
	{
		AudioSystem_FMOD* AudioSystem_FMOD::mInstance = NULL;
		AudioSystem_FMOD* AudioSystem_FMOD::GetInstance ()
		{
			if (AudioSystem_FMOD::mInstance == NULL)
			{
				AudioSystem_FMOD::mInstance = AP_NEW (Axiom::Memory::AUDIO_HEAP, AudioSystem_FMOD);
				AP::Reflection::Script::Register("AudioSystem", AP::Reflection::Instance(AudioSystem_FMOD::mInstance), "Audio Editor");
			}
			return AudioSystem_FMOD::mInstance;
		}

		bool AudioSystem_FMOD::IsInit()
		{
			return AudioSystem_FMOD::mInstance != NULL;
		}

		AudioSystem_FMOD::AudioSystem_FMOD()
		{
			mFMODSystem 	= NULL;
		}

		AudioSystem_FMOD::~AudioSystem_FMOD()
		{
		
		}

#if CORE_WII
		void* AXFXAlloc(unsigned long size)
		{
			return static_cast<void*>(AP_ALIGNED_ALLOC( Axiom::Memory::DEFAULT_HEAP, AP_ALIGN_TO(size, 32), 32 ));
		}

		void AXFXFree(void* mem)
		{
			AP_FREE(mem);
		}
#endif
		void AudioSystem_FMOD::TranslateVector(Vector3& position, FMOD_VECTOR* vec)
		{
			vec->x = -position.Y();
			vec->y = position.Z();
			vec->z = position.X();
		}

		void AudioSystem_FMOD::UpdateCamera(Vector3 position, Vector3 direction, Axiom::Math::Vector3 top)
		{
			// don't worry about z-axis for now, make sure the up vector given to FMOD is perpendicular to the direction vector
			direction.Z(0);
			top.X(0);
			top.Y(0);
			top.Z(1.0f);

			FMOD_VECTOR FMODPosition, FMODVelocity, FMODDirection, FMODUp;
			
			// translate the axes: fmodZ = x, fmodY = z, fmodX = y
			TranslateVector(position, &FMODPosition);
			TranslateVector(direction, &FMODDirection);
			TranslateVector(top, &FMODUp);
			FMODVelocity.x = 0;
			FMODVelocity.y = 0;
			FMODVelocity.z = 0;
		    FMOD_RESULT result = mFMODSystem->set3DListenerAttributes(0, &FMODPosition, &FMODVelocity, &FMODDirection, &FMODUp);
			AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting FMOD camera position/direction");

		}

		void AudioSystem_FMOD::Initialize(int NumChannels)
		{
			FMOD_RESULT result;

			void *mem = AP_NEW(Axiom::Memory::AUDIO_HEAP, char[FMOD_MEMORY_SIZE]);

			result = FMOD::Memory_Initialize(mem, FMOD_MEMORY_SIZE, 0, 0, 0);
			AP_ASSERTMESSAGE(result == FMOD_OK, "Error Initializing FMOD Ex with AP Memory");
			
			result	= FMOD::System_Create(&mFMODSystem);
			AP_ASSERTMESSAGE(result == FMOD_OK, "Error Creating FMOD EX");

#if CORE_WII
			FMOD_WII_INFO info;
			Axiom::MemorySet(&info, 0, sizeof(FMOD_WII_INFO));
			info.dvdreadpriority = 1; 				// default	
			info.muteremotespeakerifnosound = 1;	// keep the controller speakers muted when not playing sound (save battery life) 

			unsigned char soundMode = SCGetSoundMode();
			switch (soundMode)
			{
				case SC_SOUND_MODE_MONO:
					result = mFMODSystem->setSpeakerMode(FMOD_SPEAKERMODE_MONO);
					Axiom::Log("AudioSystemWii", "Setting outptut config: Mono");
					AP_ASSERTMESSAGE(result == FMOD_OK, "Error Setting Speaker Mode to MONO");
					break;

				case SC_SOUND_MODE_STEREO:
					result = mFMODSystem->setSpeakerMode(FMOD_SPEAKERMODE_STEREO);
					Axiom::Log("AudioSystemWii", "Setting outptut config: Stereo");
					AP_ASSERTMESSAGE(result == FMOD_OK, "Error Setting Speaker Mode to STEREO");
					break;

				case SC_SOUND_MODE_SURROUND:
					result = mFMODSystem->setSpeakerMode(FMOD_SPEAKERMODE_PROLOGIC);
					Axiom::Log("AudioSystemWii", "Setting outptut config: Dolby Pro-Logic II");
					AP_ASSERTMESSAGE(result == FMOD_OK, "Error Setting Speaker Mode to PL2");
					break;
			}

			result	= mFMODSystem->init(NumChannels, FMOD_HARDWARE, &info);
#else
			result	= mFMODSystem->init(NumChannels, FMOD_HARDWARE, NULL);
#endif
			AP_ASSERTMESSAGE(result == FMOD_OK, "Error Initiliazing FMOD EX with %d channels", NumChannels);
	
			memset(&mFMODSoundInfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
			mFMODSoundInfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);

			mPathDLS = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			mPathDLS += "GM16.dls";

			Axiom::MemorySet(&mFMODSoundInfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
			mFMODSoundInfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
			mFMODSoundInfo.dlsname = mPathDLS.AsChar(); // this is one from the revolution sdk
			mFMODSoundInfo.maxpolyphony = 32;

			Axiom::Log("AudioSystemWii", "Initialized Audio System with %d Channels", NumChannels);

#if CORE_WII
			// set alloc hooks for using our memory for reverbs/fx
			AXFXSetHooks(AXFXAlloc, AXFXFree);
#endif 
			
			SetReverbProperties(mReverbProperties);

			unsigned int fmodversion;
			mFMODSystem->getVersion(&fmodversion);
			Axiom::Log("AudioSystemWii", "FMOD Ex Version '0x%x'", fmodversion); 
			
			AudioSystemWii::Initialize(NumChannels);
		}

		void AudioSystem_FMOD::SetReverbProperties(const ReverbProperties& properties)
		{
			FMOD_REVERB_PROPERTIES fmodReverbProps;  	
			fmodReverbProps.Instance		= 0;
			mFMODSystem->getReverbProperties(&fmodReverbProps);
			fmodReverbProps.EnvDiffusion	= properties.mColoration; // crosstalk
			fmodReverbProps.Room			= static_cast<int>(properties.mWetMix*100);     // set to full room ideally (100% wet)  	
			fmodReverbProps.ModulationDepth = properties.mDamping;	 // HF damping - 0.9 damps alot, 0.1 damps little
			fmodReverbProps.DecayTime		= properties.mReverbTime;
			fmodReverbProps.ReverbDelay		= properties.mPreDelay;
			fmodReverbProps.Flags			= FMOD_REVERB_FLAGS_HIGHQUALITYREVERB;

#if CORE_WII
			unsigned char soundMode = SCGetSoundMode();
			if (soundMode == SC_SOUND_MODE_SURROUND)
			{
				fmodReverbProps.Flags		= FMOD_REVERB_FLAGS_HIGHQUALITYDPL2REVERB;
			}
#endif

			FMOD_RESULT result = mFMODSystem->setReverbProperties(&fmodReverbProps);
			AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting reverb properties");

			mReverbProperties = properties;
		}
		
		void AudioSystem_FMOD::ExternalSpeakerControl(int controllerID, bool enabled)
		{
#if CORE_WII
			if (enabled)
			{
				FMOD_Wii_Controller_Command(controllerID, FMOD_WII_CONTROLLER_CMD_SPEAKER_ON);
			}
			else
			{
				FMOD_Wii_Controller_Command(controllerID, FMOD_WII_CONTROLLER_CMD_SPEAKER_OFF);
			}
#endif
		}

		void AudioSystem_FMOD::LogMemoryStats()
		{
			int curAlloc, maxAlloc;
			FMOD::Memory_GetStats(&curAlloc, &maxAlloc);
			Axiom::Log("AudioSystemWii", "FMOD Mem: Current %d, Max %d", curAlloc, maxAlloc);
		}

		void AudioSystem_FMOD::Destroy()
		{
			if (mFMODSystem)
			{
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mFMODSystem->close());
				AP_ASSERTMESSAGE(result == FMOD_OK, "Error Destroying FMOD EX");
				AP::Reflection::Script::Unregister("AudioSystem");
			}
		}

		void AudioSystem_FMOD::UpdateTime(int deltaMilliseconds)
		{	
			AudioSystemWii::UpdateTime(deltaMilliseconds);
			mFMODSystem->update();
		}

		FMOD_RESULT F_CALLBACK AudioSystem_FMOD::FMODCallback(FMOD_CHANNEL *channel, FMOD_CHANNEL_CALLBACKTYPE type, int command, unsigned int commanddata1, unsigned int commanddata2)
		{
			if (type == FMOD_CHANNEL_CALLBACKTYPE_END)
			{
				FMOD::Channel* pChannel = (FMOD::Channel*)channel;
	
				Playable_FMOD* pAsset;
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, pChannel->getUserData(reinterpret_cast<void**>(&pAsset)));
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error getting pSound from user data of Channel object");

				pAsset->ChannelStopped(pChannel);

				AudioSystem_FMOD* pAudioSystem = AudioSystem_FMOD::GetInstance();
				// Set the play flag and remove it from the playing list if no more channels are active
				if (pAsset->GetNumChannelsPlaying() == 0)
				{
					pAudioSystem->RemovePlayingNode(pAsset);
					AUDIOWII_LOG("AUDIOSYSTEM", "FMOD Callback stopping %s", pAsset->GetLocalPath().AsChar(), pAsset->GetName());
				}
				
				// Also check to see if all the sibling nodes are stopped.
				// If we are the last sibling node to stop, we need to set the play flag on our parent
				BankNode* pParentNode = pAsset->GetParentNode();
				if (pParentNode != NULL && pParentNode->IsPlaying())
				{
					int NumSiblingsPlaying = pParentNode->CountPlaying();

					// make sure we don't automatically turn off banks in random fire mode
					if (NumSiblingsPlaying == 0 && pParentNode->GetPlaybackMode() != PlaybackMode::RANDOMFIRE)
					{
						// shut 'er down
						pAudioSystem->RemovePlayingNode(pParentNode);
						pParentNode->SetPlaying(false);
					}
				}
			}

			return FMOD_OK;
		}

		FMOD_RESULT F_CALLBACK AudioSystem_FMOD::FMODNonblockCallback( FMOD_SOUND* sound, FMOD_RESULT loadResult)
		{
			FMOD::Sound* pSound = (FMOD::Sound*)sound;
			Playable_FMOD* pAsset;
			AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, pSound->getUserData(reinterpret_cast<void**>(&pAsset)));
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error getting pSound from user data of Channel object");

			if (loadResult == FMOD_OK)
			{
				AUDIOWII_LOG("audiowii", "AudioSystem_FMOD::FMODNonblockCallback - Sound is ready (%s)", NULL, pAsset->GetName()); 
				pAsset->StreamLoadComplete(true);
			}
			else
			{
				AUDIOWII_LOG("audiowii", "AudioSystem_FMOD::FMODNonblockCallback - Sound is NOT ready (%s), failed w/ FMOD Error (%s):", NULL, pAsset->GetName(), FMOD_ErrorString(loadResult));
				pAsset->StreamLoadComplete(false);
			}
			
			// fire off the next stream load if there's any left
			if (AudioSystem_FMOD::GetInstance()->GetStreamsToLoad().Count() > 0)
			{
				AudioSystem_FMOD::GetInstance()->StartStreamLoadTimer(20);
			}
			else
			{
				AUDIOWII_LOG("audiowii", "AudioSystem_FMOD::FMODNonblockCallback - No more streams in queue", NULL, pAsset->GetName()); 
			    AudioSystem_FMOD::GetInstance()->StreamLoading(false);
			}

			return FMOD_OK;
		}


#if !CORE_FINAL
		void AudioSystem_FMOD::SendRemotingLoadEvent(AudioWii::Events::AudioRemotingBankLoadEvent& event)
		{
			if (mSendRemotingEvents)
			{
				sCallbackList[0]->SendAudioMessage(&event);
			}

			// Send a remoting message to the tool so the memory stats will be updated in streaker
			UpdateMemoryStats();
		}
#endif
	}
}
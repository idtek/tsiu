#include "audiowii/fmodex/playable_fmodex.h"
#include "audiowii/fmodex/audiosystem_fmodex.h"
#include "audiowii/audioeventmessages.h"
#include "files/filemanager.h"
#include "fmod_errors.h"
#include "encode/base64.h"
#include "asyncloader/asyncloadermessages.h"
#include "resource/resourceinfotable.h"

#if CORE_WII
#include "fmodwii.h"
#endif

using namespace AP::AudioWii::Events;

namespace AP
{
	namespace AudioWii
	{
		AP_TYPE(Playable_FMOD)
			AP_DEFAULT_CREATE()
			AP_BASE_TYPE(Playable)
			AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
		AP_TYPE_END()

#if CORE_WII
		//uses our filesystem code to load the file, as it's ~5 times faster than FMOD.
		char* Playable_FMOD::LoadFile(const char* filename, bool bAsync)
		{
			Axiom::Resource::InfoTable* infoTable = Axiom::Resource::InfoTable::GetInstance();
			const Axiom::FileManager::FileInfo* info = infoTable->GetFileInfo( filename );

#if !CORE_FINAL
			if (!Axiom::Memory::CanAlloc(Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32)))
			{
				if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative == false)
				{
					AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative = true;
					AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
				}
				return NULL;
			}
			else if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative == true)
			{
				AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative = false;
				AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
			}   	
#endif

			void* data = AP_ALIGNED_ALLOC( Axiom::Memory::AUDIO_HEAP, AP_ALIGN_TO(info->GetSize(), 32), 32 );

			if (!data)
			{
				return NULL;
			}
			if(!bAsync)
			{
				Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
				fileManager->LoadFileSynchronous( *info, data );
			}
			else
			{
				ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestEvent asyncLoaderRequestEvent;
				asyncLoaderRequestEvent.m_FileInfo = info;
				asyncLoaderRequestEvent.m_pBuffer = data;
	
				AudioSystem_FMOD::sAudioSystemMsgBox->SendEvent(&asyncLoaderRequestEvent);
				AudioSystem_FMOD::sAudioSystemMsgBox->ClearOutbox();
				mLoadList.Add( Axiom::Pair< const Axiom::FileManager::FileInfo*, Axiom::Byte*  >(info, (Axiom::Byte*)data) );
				mLoadsExpected++;
			}

			return reinterpret_cast<char*>(data);
		}
#endif
		
		// Static public function to remove compiler optimizations...
		// Otherwise this class won't be available to streaker.
		int Playable_FMOD::mDummy = 0;
		void Playable_FMOD::Dummy(void)
		{
			++mDummy;
		}
		
		Playable_FMOD::Playable_FMOD() : Playable()
		{
			// we will have at most 2 sounds for a stereo file
			mFMODSounds.Resize(Axiom::Memory::AUDIO_HEAP, 2);

			// start at 4 channels
			mChannels.Resize(Axiom::Memory::AUDIO_HEAP, 4);

			mLoadList.Resize(Axiom::Memory::DEFAULT_HEAP, 2);

			mNeedsReload 	= false;
			mPrevStarveState = false;
		}

		Playable_FMOD::~Playable_FMOD()
		{
			// This will be called by the reflection system when deleting a bank node.
			// Release the FMOD Sound
			if (mIsLoaded)
			{
				int soundCount = mFMODSounds.Count(); 
				for(int i=0; i < soundCount; i++)
				{
					AP_ASSERT_SUPPORT(FMOD_RESULT result =) mFMODSounds[i]->release();		
					AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error unloading asset '%s'", GetLocalPath() );
				}
			}
		}

		void Playable_FMOD::InternalVerifyStreams()
		{
			if (!mIsLoaded || mProperties.mStorageMode != StorageMode::STREAMING)
			{
				return;
			}
			
			if (mNeedsReload)
			{
				mFMODSounds[0]->release();
				mFMODSounds.Clear();
				mIsLoaded = false;
				InternalLoad(true);
				mNeedsReload = false;
				return;
			}

			FMOD_OPENSTATE openstate;
			FMOD_RESULT result = mFMODSounds[0]->getOpenState(&openstate, NULL, NULL);

			if (result != FMOD_OK && result != FMOD_ERR_FILE_DISKEJECTED)
			{
				// FMOD returns ERR_MEMORY from this? commenting out for now.
				//AP_ASSERTMESSAGE(false, "FMOD Error getting open state on stream [%s]", GetName());
				return;
			}
			else if (result == FMOD_ERR_FILE_DISKEJECTED)
			{
				mNeedsReload = true;
				return;
			}

			// update starving state
			bool starveState;
			mFMODSounds[0]->getOpenState(0, 0, &starveState);
            if (starveState != mPrevStarveState && mIsPlaying)
            {
                if (starveState)
                {
                    //AUDIOWII_LOG("audiosystem", "\n\n**** Stream '%s' is starving. Muting channel.\n\n", NULL, GetLocalPath().AsChar());
                    //mChannels[0].mFMODChannel->setMute(true);
                }
                else
                {
                    //AUDIOWII_LOG("audiosystem", "\n\n**** Stream '%s' is recovered. Unmuting channel.\n\n", NULL, GetLocalPath().AsChar());
                    //mChannels[0].mFMODChannel->setMute(false);
                }
            }
            mPrevStarveState = starveState;

		}

		void Playable_FMOD::InternalLoadFromPackage(char* pData, int size, SoundPackage* package)
		{
			if (mIsLoaded)
			{
				return;
			}

			// Override MaxPolyphony for FE sounds
			if (GetLocalPath().Find("/FE/") != -1)
			{
				mMaxPolyphony = 10;
			}
			
			FMOD::Sound* pSoundMain = NULL;
			FMOD::System* pFMODSystem = AudioSystem_FMOD::GetInstance()->GetFMODSystem();
			FMOD_CREATESOUNDEXINFO exinfo;
			memset(&exinfo, 0, sizeof(exinfo));
			exinfo.cbsize = sizeof(exinfo);
			exinfo.length = size;

			FMOD_RESULT result;
		    if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
			{
				FMOD_MODE flags = FMODCreateFlags | FMOD_3D;
				if (mProperties.mAttenuationMode == AttenuationMode::LINEAR)
				{
					flags |= FMOD_3D_LINEARROLLOFF;
				}
				
				result = pFMODSystem->createSound(pData, flags, &exinfo, &pSoundMain);
				AP_ASSERTMESSAGE(result == FMOD_OK, "Error creating FMOD sound '%s'", GetName());
				
				pSoundMain->set3DMinMaxDistance(mProperties.mDistAttenMin, mProperties.mDistAttenMax);
				AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting 3D min/max distance on FMOD sound '%s'", GetName());
			}
			else
			{
				if (mProperties.mFormat.mChannels == 2)
				{  
					Axiom::UInt flags = FMOD_2D | FMOD_LOWMEM | FMOD_OPENMEMORY_POINT;
					result = pFMODSystem->createSound(pData, flags, &exinfo, &pSoundMain);
				
					int subs = -1;
					result = pSoundMain->getNumSubSounds(&subs);  
				}
				else
				{	
					result = pFMODSystem->createSound(pData, FMODCreateFlags | FMOD_2D, &exinfo, &pSoundMain);
				}
			}

			if (result != FMOD_OK)
			{
#if !CORE_FINAL
				if (result == FMOD_ERR_MEMORY)
				{
					if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == false)
					{
						AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = true;   					
						AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
					}
				}
#endif

				mIsLoaded = false;
				
				//int count = AudioSystemWii::sCallbackList.Count();
				Axiom::Log("audiosystem", "WARNING - Didn't load asset '%s': %s", GetLocalPath().AsChar(), FMOD_ErrorString(result));   
			}
			else
			{
#if !CORE_FINAL
				// If we were out of FMOD memory, we aren't now, so send an update to the tool
				if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == true)
				{
					AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = false;   
					AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
				}
#endif
				mIsLoaded = true;
			    mPackage = package;
				mPackage->IncrementRefCount();
				mFMODSounds.Add(pSoundMain);
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalLoadFromPackage [%s] - RefCount on package is now %d", GetLocalPath().AsChar(), GetName(), package->mRefCount); 
			}
		}
		

		void Playable_FMOD::InternalLoad(bool bAsync)
		{
			if (mIsLoaded || mLoadList.Count())
			{
				return;
			}
				
			AP_ASSERTMESSAGE(Axiom::StringLength(GetLocalPath().AsChar()) != 0, "No path set for playable asset - cannot load");

			// Override MaxPolyphony for FE sounds
			if (GetLocalPath().Find("/FE/") != -1)
			{
				mMaxPolyphony = 10;
			}

			// FMOD Sound list should be empty
			if (mFMODSounds.Count() == mFMODSounds.Capacity())
			{
				mIsLoaded = true;
				return;
			}

			// resolve local file path & try to load the sound
			Axiom::FileManager::PlatformFilePathString filePath = Axiom::FileManager::FileManager::GetInstance()->ResolveFilePath( "platform_audio:" );
			filePath += GetLocalPath().AsChar() + 1; // +1 to ignore of the '/'

			FMOD::System* pFMODSystem = AudioSystem_FMOD::GetInstance()->GetFMODSystem();
			FMOD::Sound* pSoundMain = NULL;
			FMOD::Sound* pSoundOtherChannel = NULL;
			FMOD_RESULT result = FMOD_OK;
			
			if (filePath.Right(4) == ".mid")
			{
			   // don't load it for now...
			   Axiom::Log("AudioSystemWii", "NOT loading asset '%s', midi files are temporarily disabled", filePath.AsChar());
			   return;
			}
			else 
			{
#if CORE_WII
				// If it's stereo, need to do this for filename_left.dsp and filename_right.dsp
				// because the dsptool.dll encoder only supports encoding of mono data
				if (mProperties.mFormat.mChannels == 2)
				{ 			  
					if (mProperties.mStorageMode == StorageMode::MEMORY)
					{ 				
						if(!bAsync)
						{
							FMOD_CREATESOUNDEXINFO exinfo;
							Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
							const Axiom::FileManager::FileInfo info = fileManager->GetFileInfo( filePath );

							char* data = LoadFile(filePath.Replace(".dsp", ".fsb").AsChar(), bAsync);
							
							if (!data)
							{
								Axiom::Log("audiosystem", "Out of memory trying to load asset '%s'", GetLocalPath().AsChar());
								return;
							}
							
							memset(&exinfo, 0, sizeof(exinfo));
							exinfo.cbsize = sizeof(exinfo);
							exinfo.length = info.GetSize();
							
							result = pFMODSystem->createSound((char*)data, FMODCreateFlags, &exinfo, &pSoundMain);
							pSoundMain->setUserData(data); 
							mIsLoaded = true;
						}
						else
						{
							char* data = LoadFile(filePath.Replace(".dsp", ".fsb").AsChar(), bAsync);
							
							if (!data)
							{
								Axiom::Log("audiosystem", "Out of memory trying to load asset '%s'", GetLocalPath().AsChar());
								return;
							}
					
							result = FMOD_ERR_FILE_UNWANTED;
						}

						//AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error loading asset");
					}
					else if (mProperties.mStorageMode == StorageMode::STREAMING)
					{
						if (mProperties.mStreamBufferSize != 0)
						{
							// temporarily boost the stream buffer size (only for this stream - reset it after creating this one)
							result = pFMODSystem->setStreamBufferSize(mProperties.mStreamBufferSize, FMOD_TIMEUNIT_RAWBYTES);
							Axiom::Log("audiowii", "Overriding default stream buffer size for '%s' (using %d KB)", GetLocalPath().AsChar(), mProperties.mStreamBufferSize/1024);
						}
						else
						{
							// double the default stream buffer size for stereo streams
							result = pFMODSystem->setStreamBufferSize(IN_KB(24), FMOD_TIMEUNIT_RAWBYTES);
							AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting FMOD stream buffer size to 32K");
						}
						
						// Setup user stuff for the sound
						FMOD_CREATESOUNDEXINFO exinfo;
						Axiom::MemorySet(&exinfo, 0, sizeof(exinfo));
						exinfo.cbsize = sizeof(exinfo);
						if (mProperties.mStreamBufferSize > IN_KB(64))
						{
							// potential starving streams - jack up the decode buffer here too.
							exinfo.decodebuffersize = IN_KB(32);
						}
						else
						{
							exinfo.decodebuffersize = IN_KB(12);
						}
						
						exinfo.initialsubsound = 0;
						exinfo.numsubsounds = 1;
						int soundindex = 0;
						exinfo.inclusionlist = &soundindex;
						exinfo.inclusionlistnum = 1;
						exinfo.nonblockcallback = AudioSystem_FMOD::FMODNonblockCallback;
						exinfo.userdata = this;

						Axiom::UInt flags = FMOD_HARDWARE | FMOD_LOWMEM | FMOD_NONBLOCKING;

						result = pFMODSystem->createStream(filePath.Replace(".dsp", ".fsb").AsChar(), flags, &exinfo, &pSoundMain);
						mIsLoading = true; 	  				
					}
				}
				else
				{
					//Axiom::Log("AudioSystemWii", "Loading asset '%s'", filePath.AsChar());
					if (mProperties.mStorageMode == StorageMode::MEMORY)
					{
						if(!bAsync)
						{
							Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();
							FMOD_CREATESOUNDEXINFO exinfo;
							char* data = LoadFile(filePath.AsChar(), bAsync);

							if (data == NULL)
							{
								// try using FMOD memory
								FMOD_MODE fmodFlags = FMOD_LOWMEM | FMOD_HARDWARE;
								if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
								{
									fmodFlags |= FMOD_3D;
									if (mProperties.mAttenuationMode == AttenuationMode::LINEAR)
									{
										fmodFlags |= FMOD_3D_LINEARROLLOFF;
									}
									
									result = pFMODSystem->createSound(filePath.AsChar(), fmodFlags, NULL, &pSoundMain);

									if (result == FMOD_OK)
									{
										pSoundMain->set3DMinMaxDistance(mProperties.mDistAttenMin, mProperties.mDistAttenMax);
										mIsLoaded = true;
									}
	
								}
								else
								{
									result = pFMODSystem->createSound(filePath.AsChar(), fmodFlags | FMOD_2D, NULL, &pSoundMain);
									if (result == FMOD_OK)
									{
										mIsLoaded = true;
									}
								}
							}
							else
							{  							
								const Axiom::FileManager::FileInfo info = fileManager->GetFileInfo( filePath );
	
								memset(&exinfo, 0, sizeof(exinfo));
								exinfo.cbsize = sizeof(exinfo);
								exinfo.length = info.GetSize();
	
								if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
								{
									FMOD_MODE flags = FMODCreateFlags | FMOD_3D;
									if (mProperties.mAttenuationMode == AttenuationMode::LINEAR)
									{
										flags |= FMOD_3D_LINEARROLLOFF;
									}
									
									result = pFMODSystem->createSound((char*)data, flags, &exinfo, &pSoundMain);
	
									pSoundMain->set3DMinMaxDistance(mProperties.mDistAttenMin, mProperties.mDistAttenMax);
									mIsLoaded = true;
	
								}
								else
								{
									result = pFMODSystem->createSound((char*)data, FMODCreateFlags | FMOD_2D, &exinfo, &pSoundMain);
									mIsLoaded = true;
								}
							} 

							pSoundMain->setUserData(data);
						}
						else
						{
							char* data = LoadFile(filePath.AsChar(), bAsync);

							if (data == NULL)
							{
								// try using FMOD memory
								FMOD_MODE fmodFlags = FMOD_LOWMEM | FMOD_HARDWARE | FMOD_NONBLOCKING;
								if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
								{
									fmodFlags |= FMOD_3D;
									if (mProperties.mAttenuationMode == AttenuationMode::LINEAR)
									{
										fmodFlags |= FMOD_3D_LINEARROLLOFF;
									}
									
									result = pFMODSystem->createSound(filePath.AsChar(), fmodFlags, NULL, &pSoundMain);
									
									pSoundMain->set3DMinMaxDistance(mProperties.mDistAttenMin, mProperties.mDistAttenMax);
	
								}
								else
								{
									result = pFMODSystem->createSound(filePath.AsChar(), fmodFlags | FMOD_2D, NULL, &pSoundMain);
								}
								
								mIsLoaded = true;
							}
							else
							{
								result = FMOD_ERR_FILE_UNWANTED;
							}
						}
					}
					else if (mProperties.mStorageMode == StorageMode::STREAMING)
					{
						// 16K (FMOD default) for mono streams
						FMOD_CREATESOUNDEXINFO exinfo;
						Axiom::MemorySet(&exinfo, 0, sizeof(exinfo));
						exinfo.cbsize = sizeof(exinfo);
						exinfo.decodebuffersize = IN_KB(8);
						exinfo.nonblockcallback = AudioSystem_FMOD::FMODNonblockCallback;
						exinfo.userdata			= this;

						if (GetLocalPath().Find("/Streams/Vox/FE") != -1)
						{
							result = pFMODSystem->setStreamBufferSize(IN_KB(12), FMOD_TIMEUNIT_RAWBYTES);
						}
						else
						{
							result = pFMODSystem->setStreamBufferSize(IN_KB(12), FMOD_TIMEUNIT_RAWBYTES);
						}	
						
						AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting FMOD stream buffer size to 16K"); 		
						result = pFMODSystem->createStream(filePath.AsChar(), FMOD_HARDWARE | FMOD_LOWMEM | FMOD_NONBLOCKING, &exinfo, &pSoundMain);
						mIsLoading = true; 	
					}
				}
				
#else
				//Axiom::Log("AudioSystemWii", "Loading asset '%s'", filePath.AsChar());
				if (mProperties.mStorageMode == StorageMode::MEMORY)
				{
					result = pFMODSystem->createSound(filePath.AsChar(), FMOD_HARDWARE, NULL, &pSoundMain);   
				}
				else if (mProperties.mStorageMode == StorageMode::STREAMING)
				{
					result = pFMODSystem->createStream(filePath.AsChar(), FMOD_HARDWARE, NULL, &pSoundMain);
				}	     		
#endif
			}

			//We are asynchronously loading with our file manager.
			if (result == FMOD_ERR_FILE_UNWANTED)
			{
				mIsLoaded = false;
			}
			else if (result != FMOD_OK)
			{
#if !CORE_FINAL
				if (result == FMOD_ERR_MEMORY)
				{
					if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == false)
					{
						AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = true;   					
						AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
					}
				}
#endif

				mIsLoaded = false;
				//int count = AudioSystemWii::sCallbackList.Count();
				Axiom::Log("audiosystem", "WARNING - Didn't load asset '%s': %s", GetLocalPath().AsChar(), FMOD_ErrorString(result));
			   
			}
			else
			{
#if !CORE_FINAL
				// If we were out of FMOD memory, we aren't now, so send an update to the tool
				if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == true)
				{
					AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = false;   
					AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
				}
#endif
				mFMODSounds.Add(pSoundMain);

				if (pSoundOtherChannel)
				{
					mFMODSounds.Add(pSoundOtherChannel);
				}

				if (mProperties.mStorageMode == StorageMode::STREAMING)
				{
					// streams might get pooched if they are loaded then the disc is ejected.
					AudioSystem_FMOD::GetInstance()->AddNodeToUpdate(this);
				}
			}
				

		}

		void Playable_FMOD::OnLoadFinished(const Axiom::FileManager::FileInfo* fileInfo)
		{
			bool createSoundFailed = false;
			for(Axiom::UInt i = 0; i < mLoadList.Count(); i++)
			{
				if(fileInfo == mLoadList[i].first)
				{
					FMOD::System* pFMODSystem = AudioSystem_FMOD::GetInstance()->GetFMODSystem();
					FMOD::Sound* pSoundMain;
					FMOD_CREATESOUNDEXINFO exinfo;
					
					memset(&exinfo, 0, sizeof(exinfo));
					exinfo.cbsize = sizeof(exinfo);
					exinfo.length = fileInfo->GetSize();

					FMOD_RESULT result;
					if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
					{
						FMOD_MODE flags = FMODCreateFlags | FMOD_3D;
						if (mProperties.mAttenuationMode == AttenuationMode::LINEAR)
						{
							flags |= FMOD_3D_LINEARROLLOFF;
						}
						
						result = pFMODSystem->createSound((char*)mLoadList[i].second, flags, &exinfo, &pSoundMain);
						AP_ASSERTMESSAGE(result == FMOD_OK, "Error creating FMOD sound '%s'", GetName());
						
						pSoundMain->set3DMinMaxDistance(mProperties.mDistAttenMin, mProperties.mDistAttenMax);
						AP_ASSERTMESSAGE(result == FMOD_OK, "Error setting 3D min/max distance on FMOD sound '%s'", GetName());
					}
					else
					{
						if (mProperties.mFormat.mChannels == 2)
						{  
							Axiom::UInt flags = FMOD_2D | FMOD_LOWMEM | FMOD_OPENMEMORY_POINT;
							result = pFMODSystem->createSound((char*)mLoadList[i].second, flags, &exinfo, &pSoundMain);
						
							int subs = -1;
							result = pSoundMain->getNumSubSounds(&subs);  
						}
						else
						{	
							result = pFMODSystem->createSound((char*)mLoadList[i].second, FMODCreateFlags | FMOD_2D, &exinfo, &pSoundMain);
						}
					}
                    
					mLoadsExpected--;
					
					if (result == FMOD_OK)
					{
						// store pointer to the audio data in userData. we'll need this to free it when we unload (below)
						pSoundMain->setUserData(mLoadList[i].second);
						mLoadList.RemoveAt(i);
						mFMODSounds.Add(pSoundMain);

						// stereo files will have two loads to complete before we can play it
						// (two mono files)   				
						if (mLoadList.Count() == 0 && !createSoundFailed)
						{
							mIsLoaded = true;
						}
					}
					else
					{
						// Couldn't create an FMOD sound object... free our mem for this sound (we can't use it anyways)
						AP_FREE(mLoadList[i].second);
						mLoadList.RemoveAt(i);
						createSoundFailed = true;
						mIsLoaded = false;
					}
					
#if !CORE_FINAL
					if (result == FMOD_ERR_MEMORY)
					{
						if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == false)
						{
							AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = true;
							AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
						}
					}				
#endif

				}
			}
		}

		bool Playable_FMOD::InternalUnload()
		{
			FMOD_OPENSTATE openstate;  		
			mFMODSounds[0]->getOpenState(&openstate, NULL, NULL);
			if (openstate == FMOD_OPENSTATE_STREAMING)
			{
				mUnloadNextFrameCount = 1;
				return false;
			}

			// Cycle through the sounds and do the proper de-alloc
			int soundCount = mFMODSounds.Count();
			for(int i = 0; i < soundCount; i++)
			{
				// In-memory sounds are loaded by us, loaded using FMOD_OPEN_MEMORYPOINT
				// So we need to free the memory for them (streams / stream buffers are still handled by FMOD)		
				if(mProperties.mStorageMode == StorageMode::MEMORY)
				{
					void* data; 			
					mFMODSounds[i]->getUserData(&data);

					if (mPackage == NULL)
					{
						AP_FREE(data);
					}
					else
					{
						AudioSystem_FMOD::GetInstance()->DecrementPackageRef(mPackage);
						mPackage = NULL;
					}
					
#if !CORE_FINAL
					if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == true)
					{
						AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = false;
						AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
					}
#endif	

				}

				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mFMODSounds[i]->release());
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error unloading asset");	

				// streams will have been added to the update list after loading incase a disc is ejected and they need to be reloaded
				AudioSystem_FMOD::GetInstance()->RemoveNodeToUpdate	(this);  

#if !CORE_FINAL
				if (AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD == true)
				{
					AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD = false;
					AudioSystem_FMOD::GetInstance()->SendMemoryUpdate(GetLocalPath());
				}
#endif	
   
			}

			AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalUnload [%s] - Clearing FMOD Sounds.", GetLocalPath().AsChar(), GetName());
			mFMODSounds.Clear(); 		
			mIsLoaded = false;
			return true;
		}

		bool Playable_FMOD::InternalPlay(int entityID, Vector3& position,  float volumeDB, float pitch)
		{
			if (mProperties.mStorageMode == StorageMode::STREAMING && mIsPlaying)
			{
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalPlay [%s] - Stream is already playing, resetting position to 0.", GetLocalPath().AsChar(), GetName());
				return true;   
			}

			if (GetRefCount() > mMaxPolyphony)
			{
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalPlay [%s] - Max Polyphony reached, ignoring play command.", GetLocalPath().AsChar(), GetName());
				return false;
			}

			int channelsPlaying;
			AudioSystem_FMOD::GetInstance()->GetFMODSystem()->getChannelsPlaying(&channelsPlaying);
			if (channelsPlaying > 23)
			{
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalPlay [%s] - 24 channels reached, ignoring play command.", GetLocalPath().AsChar(), GetName());
				return false; 
			}

			
#if CORE_WII
			if (mProperties.mFormat.mChannels == 2)
			{
				Channel channel;
				FMOD::Sound* pSubSound;
				FMOD_RESULT result = mFMODSounds[0]->getSubSound(0, &pSubSound);

				if (result == FMOD_ERR_NOTREADY)
				{
					// async loaded file not ready to go yet. set a flag, and let the StreamReady() callback start it
					AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalPlay [%s] - Sound not ready to play, setting StartWaitingOnReady flag", GetLocalPath().AsChar(), GetName()); 
					mStartWaitingOnReady = true;
					mStartupVolume = volumeDB;
					return false;
				}
				
				if (!PlayFMOD(position, pSubSound, &channel.mFMODChannel, volumeDB, 0.0f, pitch))
				{
					return false;
				}

				if (mChannels.Count() >= mChannels.Capacity())
				{
					mChannels.Resize(Axiom::Memory::AUDIO_HEAP, mChannels.Capacity()*2);
				}
				mChannels.Add(channel);
				channel.mFMODChannel->setPaused(false);

				int channelcount = mChannels.Count();
				AUDIOWII_LOG("audiowii", "Starting %s, current count = %d", GetLocalPath().AsChar(), GetName(), channelcount);  			   		   
			}
			else
			{	   	 
				Channel channel;
				channel.mEntityID = entityID; 
				if (!PlayFMOD(position, mFMODSounds[0], &channel.mFMODChannel, volumeDB, 0.0f, pitch))
				{
					return false;
				}
				
				if (mChannels.Count() >= mChannels.Capacity())
				{
					mChannels.Resize(Axiom::Memory::AUDIO_HEAP, mChannels.Capacity()*2);
				}
				
				// Register it for getting position updates it's 3D
				if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL && 
					mProperties.mLoopingMode == LoopingMode::START_MID_END)
				{
					AudioTrackEntityPositionEvent posEvent(channel.mEntityID);
					posEvent.mUnregister = false;
					AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&posEvent);
				}

				mChannels.Add(channel);
				channel.mFMODChannel->setPaused(false);
			}
#else		
			Channel  channel;   
			PlayFMOD(position, mFMODSounds[0], &channel.mFMODChannel, volumeDB, 0.0f, 0.0f);
			
			if (mChannels.Count() >= mChannels.Capacity())
			{
				mChannels.Resize(Axiom::Memory::AUDIO_HEAP, mChannels.Capacity()*2);
			}
			
			mChannels.Add(channel);
			channel.mFMODChannel->setPaused(false);
#endif
			return true;
		}
		
		bool Playable_FMOD::PlayFMOD(Vector3& position, FMOD::Sound* pFMODSound, FMOD::Channel** ppFMODChannel, float volumeDB, float pan, float pitch)
		{
			FMOD::System* pFMODSystem = AudioSystem_FMOD::GetInstance()->GetFMODSystem();
			
			// Start the sound in the paused state
			FMOD::Channel* pChannel = NULL;
			FMOD_RESULT result = pFMODSystem->playSound(FMOD_CHANNEL_FREE, pFMODSound, true, &pChannel);

			if (result == FMOD_ERR_NOTREADY)
			{
				// async loaded file not ready to go yet. set a flag, and let Playable::UpdateTime try and re-start it the next frame
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalPlay [%s] - Sound not ready to play, setting StartWaitingOnReady flag", GetLocalPath().AsChar(), GetName()); 
				mStartWaitingOnReady = true;
				mStartupVolume = volumeDB;
				return false;
			}
			
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error starting playback on '%s', FMOD error %d", GetName(), result);

			mStartWaitingOnReady = false;
			
			// Set Looping, volume, user data, for the channel
			if (mProperties.mLoopingMode == LoopingMode::START_MID_END)
			{
				result = pChannel->setMode(FMOD_LOOP_NORMAL);
			}
			else
			{
				result = pChannel->setMode(FMOD_LOOP_OFF);
			}
				
			AUDIOWII_LOG("audiosystemwii", "FMOD Starting sound (%2.2f dB) for %s", GetLocalPath().AsChar(), volumeDB, GetName());
			float vol = dBToAmplitude(volumeDB);
			result = pChannel->setVolume(vol);
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting volume on Channel");

			if (pitch != 0)
			{
				float frequencyRatio = Axiom::Math::Power(2,(pitch/100/12));
				pChannel->setFrequency(32000.0f*frequencyRatio);
			}

#if CORE_WII
			if (mProperties.mFormat.mChannels == 2)
			{
				result = pChannel->setPan(pan);
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting pan on Channel");
			}

			// Set WiiMote output if asked for
			if (mProperties.mExternalSpeaker == true)
			{
				// Set channel to play out of FMOD_WII_CONTROLLER_0 for now... 
				result = FMOD_Channel_SetControllerSpeaker((FMOD_CHANNEL *)pChannel, FMOD_WII_CONTROLLER_0);
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting wii-mote on Channel");
			}
			
#endif

			// Store the this pointer in user data so when we get callback from FMOD about this sound 
			// we have a Playable to reference
			result = pChannel->setUserData(this);
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error storing pSound as user data in Channel object");

			pChannel->setCallback(FMOD_CHANNEL_CALLBACKTYPE_END, AudioSystem_FMOD::FMODCallback, 0);
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting callback");

			if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL)
			{
				FMOD_VECTOR pos;
				AudioSystem_FMOD::TranslateVector(position, &pos);
				result = pChannel->set3DAttributes(&pos, NULL);
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting channel position");
				//Axiom::Log("AudioSystem", "Starting sound '%s' at location (%2.1f, %2.1f, %2.1f)", GetName(), position.X(), position.Y(), position.Z());
			}

			if (mProperties.mSendReverb > -90.0f)
			{
				FMOD_REVERB_CHANNELPROPERTIES properties;
				properties.Flags = FMOD_REVERB_CHANNELFLAGS_INSTANCE0;
				pChannel->getReverbProperties(&properties);
				properties.Room		= static_cast<int>(mProperties.mSendReverb*100);
				properties.Direct	= -10000;
				result = pChannel->setReverbProperties(&properties);
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting channel reverb send");
			}
			else
			{
				FMOD_REVERB_CHANNELPROPERTIES properties;
				properties.Flags = FMOD_REVERB_CHANNELFLAGS_INSTANCE0;
				pChannel->getReverbProperties(&properties);
				properties.Room	  	= -10000;
				properties.Direct 	= -10000; // -100 dB
				result = pChannel->setReverbProperties(&properties);
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting channel reverb send");
			}

			*ppFMODChannel = pChannel;

			return true;
		}

		void Playable_FMOD::InternalPause()
		{   		
			//  pause all playing channels:
			int channelCount = mChannels.Count();
			for(int i = 0; i < channelCount; i++)
			{
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mChannels[i].mFMODChannel->setPaused(true));
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error pausing asset '%s'", GetLocalPath().AsChar() );
			}
		}

		void Playable_FMOD::InternalResume()
		{   	
			//  resume all playing channels:
			int channelCount = mChannels.Count();
			for(int i = 0; i < channelCount; i++)
			{
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result,  mChannels[i].mFMODChannel->setPaused(false));
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error resuming asset '%s'", GetLocalPath().AsChar() );
			}
		}
			
			
		void Playable_FMOD::InternalStop(int entityID)
		{
			if (!mIsPlaying)
			{
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalStop [%s] - not playing, removing %d channels", GetLocalPath().AsChar(), GetName(), mChannels.Count());
				mChannels.Clear();
				return;
			}

			if (entityID != -1)
			{
				for(unsigned int i = 0; i < mChannels.Count(); i++)
				{
					if (mChannels[i].mEntityID == entityID)
					{
						AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalStop [%s] - Stopping entityID %d", GetLocalPath().AsChar(), GetName(), entityID);
						mChannels[i].mFMODChannel->stop();
						break;
					}
				}

				if (mChannels.Count() == 0)
				{
					AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalStop [%s] - All instances have been stopped - removing playing node from system", GetLocalPath().AsChar(), GetName(), entityID);
					AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
				}   			
			}
			else
			{
				//  stop all playing channels:
				AUDIOWII_LOG("audiowii", "Playable_FMOD::InternalStop [%s] - Stopping all instances.", GetLocalPath().AsChar(), GetName());
				while(mChannels.Count() > 0)
				{
					// because the call to stop() will call the FMODCallback, which removes the channel 
					// from the FMODChannels list, we need to just remove the bottom one each iteration  		
					mChannels[0].mFMODChannel->stop();
				}
				
				AudioSystem_FMOD::GetInstance()->RemovePlayingNode(this);
			}
		}

		void Playable_FMOD::SetVolumeDB(float dBVolume)
		{
			int channelCount = mChannels.Count();
			for(int i = 0; i < channelCount; i++)
			{
				AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mChannels[i].mFMODChannel->setVolume(dBToAmplitude(dBVolume)));
				AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error setting volume asset '%s'", GetLocalPath().AsChar() );
			}
		}

		void Playable_FMOD::InternalSetPitch(float pitch)
		{
			float frequencyRatio = Axiom::Math::Power(2,(pitch/100/12));
			for(unsigned int i = 0; i < mChannels.Count(); i++)
			{
				mChannels[i].mFMODChannel->setFrequency(32000.0f*frequencyRatio);
			}
		}

		float Playable_FMOD::InternalGetPitch() const
		{
			float frequencyRatio;

			// get the current clock sample rate for the channel
		    AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mChannels[0].mFMODChannel->getFrequency(&frequencyRatio));
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error getting pitch asset '%s'", GetLocalPath().AsChar() );
			frequencyRatio = frequencyRatio/32000.0f;

			// convert it to cents
			return 1200.0f * (Axiom::Math::Log(frequencyRatio) / Axiom::Math::Log(2));  	
		}

		float Playable_FMOD::GetVolumeDB() const
		{
			float volume;

			if (!mIsPlaying)
			{
				return 0.0f;
			}
			
			AP_ASSERT_SUPPORTASSIGN(FMOD_RESULT result, mChannels[0].mFMODChannel->getVolume(&volume));
			AP_ASSERTMESSAGE(result == FMOD_OK, "FMOD Error getting volume asset '%s'", GetLocalPath().AsChar() );

			return AmplitudeTodB(volume);
		}

		void Playable_FMOD::ToggleDSPFilter(bool enable)
		{
			static const int bandpassIndex = 20;
#if CORE_WII
			// apply it to all channels
			for (unsigned int i = 0; i < mChannels.Count(); i++)
			{   			
				FMOD_BOOL active = enable ? true : false;
												
				FMOD_RESULT result = FMOD_Channel_SetBiquadFilter((FMOD_CHANNEL*)mChannels[i].mFMODChannel, active,
												__biquad_bpf_coefs[bandpassIndex].b0,
												__biquad_bpf_coefs[bandpassIndex].b1,
												__biquad_bpf_coefs[bandpassIndex].b2,
												__biquad_bpf_coefs[bandpassIndex].a1,
												__biquad_bpf_coefs[bandpassIndex].a2); 

				if (result != FMOD_OK)
				{
					return;
				}
			}	
#endif
		}

		void	Playable_FMOD::LoadFromStream (const char* Base64_encoded_data, const char* Path, int datasize, int decompressed_size)
		{
			char* outbuffer = AP_NEW(Axiom::Memory::DEFAULT_HEAP, char[decompressed_size]); //new char [decompressed_size];
		
			int SizeOutputBuffer = 0;
			Axiom::Base64Decoder Decoder;
			Decoder.Decode (Base64_encoded_data, datasize, outbuffer, SizeOutputBuffer);

			FMOD::System* pFMODSystem = AudioSystem_FMOD::GetInstance()->GetFMODSystem();
			FMOD::Sound* pSoundMain = NULL;
			FMOD_RESULT result = FMOD_OK;
			//if (mProperties.mStorageMode == StorageMode::IN_MEMORY)
			{
				FMOD_CREATESOUNDEXINFO exinfo;
				memset(&exinfo, 0, sizeof(exinfo));
				exinfo.cbsize = sizeof(exinfo);
				exinfo.length = SizeOutputBuffer;
				result = pFMODSystem->createSound(outbuffer, FMODCreateFlags, &exinfo, &pSoundMain);
				pSoundMain->setUserData(outbuffer); 
			}
			if (result != FMOD_OK)
			{
				mIsLoaded = false;
				int count = AudioSystemWii::sCallbackList.Count();
				Axiom::Log("audiosystem", "WARNING - Didn't load asset '%s': %s", GetLocalPath().AsChar(), FMOD_ErrorString(result));
				for(int i=0; i < count; i++)
				{
					Axiom::StaticString<256, char> errorString;
					errorString = "Load Error on '";
					errorString += GetLocalPath().AsChar();
					errorString += "'. FMOD : ";
					errorString += FMOD_ErrorString(result);
				}
			}
			else
			{
				mIsLoaded = true;
			}
				
			mFMODSounds.Add(pSoundMain);
		}

		void Playable_FMOD::ChannelStopped(FMOD::Channel* pChannel)
		{
			// remove from the list, set playing to false if no more channels are active
			int channelCount = mChannels.Count();
			for(int i = 0; i < channelCount; i++)
			{
				if (mChannels[i].mFMODChannel == pChannel)
				{
					// Unregister it from getting position updates
					if (mProperties.mPositioningMode == PositioningMode::THREE_DIMENSIONAL && 
						mProperties.mLoopingMode == LoopingMode::START_MID_END)
					{
						AudioTrackEntityPositionEvent posEvent(mChannels[i].mEntityID);
						posEvent.mUnregister = true;
						AudioSystem_FMOD::sCallbackList[0]->SendAudioMessage(&posEvent);
					}

					mChannels.RemoveAt(i);
					break;
				}
			}

			channelCount = mChannels.Count();
			AUDIOWII_LOG("audiowii", "Playable_FMOD::ChannelStopped [%s], %d currently still active.", GetLocalPath().AsChar(), GetName(), channelCount);
			if (mChannels.Count() == 0)
			{
				mIsPlaying = false;
				if (mUnloadWhenStopped == true)
				{
					AUDIOWII_LOG("audiowii", "Playable_FMOD::ChannelStopped [%s], UnloadWhenStopped is set - setting mUnloadNextFrame = true", GetLocalPath().AsChar(), GetName());
					UnloadNextFrame(true);
					mUnloadWhenStopped = false;
					AudioSystem_FMOD::GetInstance()->AddNodeToUpdate(this);
				}
			}
		}
	}
}

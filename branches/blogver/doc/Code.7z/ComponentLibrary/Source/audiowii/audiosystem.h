#ifndef _AUDIOSYSTEM_WII_H
#define _AUDIOSYSTEM_WII_H

#include <core/singleton.h>
#include <core/autopointer.h>
#include <core/pointer.h>
#include <core/classedenum.h>
#include <kernel/component.h>

#include "audiowii/bank.h"
#include "audiowii/event.h"
#include "audiowii/audiocallback.h"
#include "audiowii/audioeventmessages.h"
#include "audiowii/eventnode.h"
#include "audiowii/banknode.h"
#include "audiowii/playable.h"
#include "audiowii/fmodex/playable_fmodex.h"

using namespace Axiom::Math;
using namespace AP::AudioWii;

//#define AUDIOWII_VERBOSE
//#define AUDIOWII_SOUNDPATHFILTER "Rollover"
//#define AUDIOWII_LOGNODES

#if CORE_FINAL || CORE_SHIP 
	#ifdef AUDIOWII_VERBOSE
	#error "Don't log in final mode"
	#endif
#endif

#ifdef AUDIOWII_VERBOSE
	#ifdef CORE_WII
		#define AUDIOWII_LOG(a, b, soundpath, ...) \
			if (soundpath != NULL) \
			{ \
				 if (Axiom::StringFindString(soundpath, AUDIOWII_SOUNDPATHFILTER) != NULL) \
					{ OSReport(b, __VA_ARGS__); OSReport("\n"); } \
			} \
			else \
			{ \
				 { OSReport(b, __VA_ARGS__); OSReport("\n"); } \
			}
	#else 
		 #define AUDIOWII_LOG(a, b, soundpath, ...) \
			if (soundpath != NULL) \
			{ \
				 if (Axiom::StringFindString(soundpath, AUDIOWII_SOUNDPATHFILTER) != NULL) \
					Axiom::Log(a, b, __VA_ARGS__); \
			} \
			else \
			{ \
				Axiom::Log(a, b, __VA_ARGS__); \
			}
	#endif
#else
	#define AUDIOWII_LOG(a, b, ...) 
#endif

namespace AP
{
	namespace AudioWii 
	{
		// Map from an actor name/type to a subpath in the bank tree.
		// Incoming audio events will have an actor name, the
		// audio system will resolve the proper bank path based on 
		// this mapping.
		// (Populated by reflection)
		struct ActorPathEntry
		{
			Axiom::StringCRC mActorName;
			Axiom::StringCRC mSubPath;
			
			const bool operator==(const ActorPathEntry& rhs) const 
			{ 
				return (mActorName == rhs.mActorName && 
					    mSubPath   == rhs.mSubPath); 
			}
			AP_DECLARE_TYPE();
		};

		// an .asb file
		struct SoundPackage
		{
			SoundPackage() : mData(NULL), mRefCount(0) {}
			~SoundPackage()
			{
				if (mData != NULL)
				{
					AP_FREE(mData);
				}
			}

			void IncrementRefCount() { mRefCount++; }
			void DecrementRefCount();
				 
			Axiom::MediumString mName;
			char* 				mData;
			int	  				mRefCount;
		};
		
		// Need to call this so playable_fmod class doesn't get compiled out
		static Playable_FMOD* pDummy;

		class AudioSystemWii 
		{
			friend class AudioComponent;
			static const int   NUM_FE_CONVERSATION_VOICES = 24;
			static const char* sConversationVoiceFolders[NUM_FE_CONVERSATION_VOICES]; // For FE Conversation Voice Mapping
			
		public:
			typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer< ActorPathEntry > > ActorPathMap;
			AudioSystemWii();
			~AudioSystemWii();

			// Static Publics
			static AudioSystemWii*	GetInstance();

			// Init, Destroy, Register Callbacks, etc.
			virtual void			Initialize(int NumChannels);
			virtual void			LogMemoryStats() {};
			void					RegisterCallback(AudioCallback* callback) { sCallbackList.Add(callback); }
			void					SetNumAudioMixes(int evtSize)		{	mNumMixes = evtSize;	}	
			void					Destroy();

			// Remote Commands to setup audio system
			void					FinalizeTrees();
			void					BuildTree ();
			void					ReloadBanks(bool bReloadAll);

			// Sound Playback (exposed methods - event based only, protected bank/sound playback methods below)
			virtual void			PlayEvent(int EventID, const Axiom::Math::Vector3& Position, int DelayInMS, int Priority);
			virtual void			PlayEvent(const AudioWii::Events::AudioPlaySoundEvent* Event);
			
			// Playback Control
			virtual void			PauseToggle(bool Paused);
			virtual void			UpdateTime(int newTimeInMilliseconds);
			virtual void			UpdateCamera(Vector3 position, Vector3 direction, Axiom::Math::Vector3 top);
			virtual void			UpdateEntityLocation(int id, Vector3 position);
			virtual void			SetUserVolume(AudioWii::Events::EUserVolumeType volumeType, float volume);
			virtual void			SetReverbProperties(const ReverbProperties& properties) { }; // implemented by platform audio system
			virtual void			LoadEntityAssets(const AudioWii::Events::AudioPlaySoundEvent* pLoadEvent);
			virtual void			LoadPackageAsync(const char* packageName);
			virtual bool			VerifyBankExists(Playable* pNode, AudioPathString NodePath);
			virtual void			LoadFEVoice(const char* type, Axiom::Byte feVoiceID);
			virtual void			IncrementPackageRef(SoundPackage* pPackage);
			virtual void			DecrementPackageRef(SoundPackage* pPackage);
			virtual int				GetNumLoadsExpected() { return mLoadsExpected; }

			// State Querying
			bool					IsInitialized() { return mIsInitialized; }

			// Member Access
			virtual float			GetDistanceScaling()				{ return mDistanceScaling; }
			virtual void			SetDistanceScaling(float scaling)	{ mDistanceScaling = scaling; }
			virtual float			GetUserVolumeSFX() const			{ return mUserVolumeSFX; }
			virtual float			GetUserVolumeMusic() const			{ return mUserVolumeMusic; }
			virtual float			GetMasterVolume()					{ return 196; /*return m_pMixer->GetMasterVolume();*/ }
			virtual void			SetMasterVolume(float volume)		{ UNUSED_PARAM(volume); return; /*  m_pMixer->SetMasterVolume(volume); */   }

			virtual void			AddPlayingNode(Playable* pNode);
			virtual void			RemovePlayingNode(Playable* pNode);
			virtual void			AddNodeToUpdate(Playable* pNode);
			virtual void			RemoveNodeToUpdate(Playable* pNode);
			virtual Axiom::Collections::DynamicList< Playable* >&	GetStreamsToLoad() { return mStreamsToLoad; }
			virtual bool			StreamLoading() { return mStreamLoading; }
			virtual void			StreamLoading(bool loading) { mStreamLoading = loading; }
			virtual void			StartStreamLoadTimer(int frames) { mStreamLoadFrameCountdown = frames; }
			

			virtual void			PauseAllSounds(float fade);
			virtual void			ResumeAllSounds(float fade);

			void					OnLoadFinished(const Axiom::FileManager::FileInfo* fileInfo );
#if !CORE_FINAL
			void					UpdateMemoryStats(); 							// Sends a memory update to the tool
			void 					SendMemoryUpdate(AudioPathString assetPath);	
#endif
			void					ExternalSpeakerControl(int speakerID, bool enable);

		//----------------------------------------------------------------

			// the callback list is static so any playable/bank/event can access it directly
			static Axiom::Collections::DynamicList< AudioCallback* >	sCallbackList;	// registered callback (start, stop, load, error, etc.)
			static Axiom::EventMsgBoxHandle sAudioSystemMsgBox;
			static int				mLoadsExpected;		// How many loads are pending.
			bool					mStreamLoading;		// if a stream is currently loading
			int						mStreamLoadFrameCountdown; // space between stream loads while music is playing.
			bool 					mSendRemotingEvents; 	// log events via sending remoting messages back to the game
			bool					mOutOfMemoryFMOD;		// flag to set for the tool to report to the designer - FMOD out of memory
			bool					mOutOfMemoryNative;		// flag to set for the tool to report to the designer - Audio System is out of memory
			
		protected:
			LoadList				mLoadList;
			EventNode				mRootEvent;		// all events (maps to banks)
			BankNode				mRootBank;		// all banks  (maps to playable assets)
			ActorPathMap 			mActorPathMap;	// map of actory names (contained in the audio events) to asset/bank subpath
			bool					mEnabled;		// global enable toggle for the whole system
			bool					mLogEventPaths; // log event paths via Axiom::Log when !CORE_FINAL

			float					mUserVolumeSFX; // user-set volume for SFX (set in front end)
			float					mUserVolumeMusic; // user-set volume for Music (set in front end, NOT applied to Ambiences)
			ReverbProperties		mReverbProperties; // reverb properties for the system reverb
			
			Axiom::Collections::DynamicList< Playable* >	mPlayingNodes;		// store pointers to currently playing sounds
			Axiom::Collections::DynamicList< Playable* >	mNodesToUpdate;		// store pointers to other nodes needing updates (streams might get unloaded, etc.)
			Axiom::Collections::DynamicList< Playable* >	mStreamsToLoad;	
			Axiom::Collections::DynamicList< SoundPackage* >	mLoadedPackages;	// list of currently loaded sound packages (.asb files)

			virtual void			ReloadAllAssets();								// Load all sounds referenced by the banks.
			virtual void			ReloadBankNodeAssets(BankNode* node);			// recursive load function
			virtual void			LoadAssetsFromASB(char* data, int size, Axiom::MediumString name);	// .asb file parsing
			virtual void			LoadAssetsFromASBList(Axiom::MediumString filename);	// .asb file parsing, individually loading files from an asb list
			
			// These are called by the tool only
			virtual void			PreviewEvent(const char* EventPath);
			virtual void			StopEvent(const char* NodePath);

			// a char* interface is needed so the tool can call Play/Stop, etc. on a node
			virtual void			PlayNodePath(const char* NodePath); // just calls PlayNode() below, helper function
			virtual void			StopNodePath(const char* NodePath); // just calls StopNode() below, helper function
			virtual void			MuteNodePath(const char* NodePath, bool mute); // called by the tool only
			virtual void    		PlayNode(BankNode* pNode);			
			virtual void    		StopNode(BankNode* pNode);
			  			
			void					RunScript(const char* script);

			bool					mIsInitialized;
			float					mDistanceScaling;		// Distance Scaling, valid range from 0.0 -> ???			

		//----------------------------------------------------------------

		private:
			int						mNumMixes;
			int						mMaxRolloffDistance;

			static AudioSystemWii*	mInstance;	// for Singleton implementation

		//----------------------------------------------------------------

		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _AUDIOSYSTEM_WII_H
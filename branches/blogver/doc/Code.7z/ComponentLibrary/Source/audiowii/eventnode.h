#ifndef _EVENTNODE_H
#define _EVENTNODE_H

#include <collections/list.h>
#include <core/autopointer.h>
#include <core/pointer.h>
#include "audiowii/soundproperties.h"
#include "audiowii/event.h"

namespace AP
{
	namespace AudioWii
	{
		class EventNode : public Event
		{
			typedef Axiom::Collections::ReflectedList< Axiom::AutoPointer< EventNode > > EventNodeList;
		public:
			
			EventNode();		
			EventNode(EventNode* parent) { mParentNode = parent; }
			~EventNode() {};

			static void				LinkChildren(EventNode* pNode);
			static Axiom::StringCRC GetPath(const EventNode* pNode);

			const Axiom::Pointer<EventNode> GetParent() const { return mParentNode; }
			const EventNodeList* GetChildren() const { return &mChildren; }
			static EventNode*	 NodeFromPath(Axiom::MediumString path, EventNode* pNode);

			static const int MAX_EVENT_PATH_CHARS = 128;

		private:
			EventNodeList mChildren;
			Axiom::Pointer<EventNode> mParentNode;

		public:	
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _EVENTNODE_H 
#ifndef _ASBPARSER_H
#define _ASBPARSER_H

#include <core/classedenum.h>
#include "audiowii/soundproperties.h"

namespace AP
{
	namespace AudioWii
	{
		typedef Axiom::StaticString<5, char> AtomString;

		struct ASBAtom
		{
			AtomString				mType;
			Axiom::Int32			mSize;
			char*					mData;
		};

		struct ASBSound
		{
			char*		   			mData;
			Axiom::Int32			mSize;
			SoundFormat				mFormat;
			Axiom::MediumString		mPath;
			Axiom::ShortString		mStorageMode;
		};

		class ASBParser
		{
		public:
			ASBParser();
			~ASBParser();

			Axiom::Bool				Init(char* pBankData, int size);
			Axiom::MediumString		GetRootPath()  { return mRootPath; }
			Axiom::Int32			GetNumSounds() { return mNumSounds; }
			Axiom::Bool				GetSoundAt(int index, ASBSound& sound);

		private:
			char*					mData;				// sound bank raw data
			Axiom::Int32			mTotalSize;			// keep track of where we are reading from
			Axiom::MediumString     mRootPath;			// root path of the sound bank i.e. /Vocals/Dodge/Cat
			Axiom::Int32			mNumSounds;			// number of sounds in this bank
			Axiom::Int32			mCurReadOffset;		// keep track of where we are reading from
			Axiom::Int32			mFirstSoundOffset;  // so we can seek the start of the first sound
			
			bool ReadNextAtom(ASBAtom& atom);
			void SeekToSound(int soundIndex);
		};
		
	}
}

#endif // _ASBPARSER_H
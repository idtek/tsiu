#include "audiowii/audioeventmessages.h"
#include "audiowii/audiosystem.h"
#include "audiowii/audiocomponent.h"
#include "eventsystem/eventmsg.h"
#include "kernel/component.h"
#include "core/allocator.h"
#include "collections/list.h"
#include "asyncloader/asyncloadermessages.h"

//

#ifdef AUDIO_FMODEX
#include "audiowii/fmodex/audiosystem_fmodex.h"
#else
#include "audiowii/ax/audiosystem_ax.h"
#endif


namespace AP
{
namespace AudioWii
{

	static Axiom::Timer			sTimer;
	static Axiom::Int32			sLastTimeInMS;
	static bool					sIsTimerStarted = false;

#ifdef EVENT_TIMING_ON
	static const char* LOGGING_CHANNEL = "AudioPlaying";
#endif

	AudioComponent::AudioComponent(Axiom::ConstStr name, AP::Kernel* kernel)
		: Component(name,kernel)
		, m_pAudioSystem(NULL)
	{
	}

	AudioComponent::~AudioComponent()
	{

	}

	void		AudioComponent::OnInit()
	{
#if CORE_USERDEBUG==CORE_YES
		m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Audio", Axiom::Memory::DEFAULT_HEAP, 400, 80, 31);
#else
		m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Audio", Axiom::Memory::DEFAULT_HEAP, 400, 66, 31);
#endif
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioPlaySoundEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioUpdateCameraBody::EVENT_GUID); 	
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioExternalSpeakerEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioFEVolumeAdjustEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AudioUpdateEntityPositionEvent::EVENT_GUID);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent::GetEventId() );

		// Start up audio system

#ifdef AUDIO_FMODEX
#else
		AP::AudioWii::AudioSystem::Init(xiom::Memory::AUDIO_HEAP);
#endif

#ifdef AUDIO_FMODEX
		m_pAudioSystem = AP::AudioWii::AudioSystem_FMOD::GetInstance();
#else
		m_pAudioSystem = AP::AudioWii::AudioSystem_AX::GetInstance();
#endif
		
		AP_ASSERT(m_pAudioSystem!=NULL);
		m_pAudioSystem->RegisterCallback(this);
		m_pAudioSystem->Initialize(70);
	}

	void AudioComponent::AudioError(const char* message)
	{
#if !CORE_FINAL
    	// trim the message to the MAX MESSAGE LENGTH
		static const int MaxMessageLength = Axiom::EventData::MAX_EVENT_DATA_SIZE - 32;
		char TruncatedMessage[MaxMessageLength];
		Axiom::StringCopy(TruncatedMessage, message, MaxMessageLength-1);

		AP::AudioWii::Events::AudioRemotingGenericEvent remotingEvent(TruncatedMessage);
		m_ComponentMsgBox->SendEvent( &remotingEvent );
#endif
	}

	void AudioComponent::SendAudioMessage(Axiom::EventMsg* pMsg)
	{
		m_ComponentMsgBox->SendEvent( pMsg );
	}

	void AudioComponent::OnUpdate()
	{
		if (!sIsTimerStarted)
		{
			sTimer.Start();
			sIsTimerStarted = true;
		}
		
		HandleEvents();
		AP_ASSERTMESSAGE(m_pAudioSystem!=NULL, "Audio not created yet");	

		UpdateTime ();

		// Send output events
		m_ComponentMsgBox->ClearOutbox();
	}


	void AudioComponent::OnShutdown()
	{
		mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);

		AP_ASSERTMESSAGE(m_pAudioSystem!=NULL, "Audio not created yet");
		
		//m_pAudioSystem->Shutdown();
		m_pAudioSystem->Destroy();
	}

	void AudioComponent::UpdateTime ()
	{
		int  currTime = Axiom::TimeAbsolute::GetSystemTime().AsIntInMilliseconds();
		int  diffTime = currTime - sLastTimeInMS;
		
		if (m_pAudioSystem->IsInitialized() )
		{
			m_pAudioSystem->UpdateTime (diffTime);
		}
		sLastTimeInMS = currTime;
	}

	void AudioComponent::HandleEvents()
	{
		int numEvents = m_ComponentMsgBox->GetNumEvents();
#ifdef EVENT_TIMING_ON
		//int nowtime = Axiom::TimeAbsolute::GetSystemTime().AsIntInMilliseconds ();
		//Axiom::Log(LOGGING_CHANNEL, "Audio HandleEvents:time:%d", nowtime);
#endif

		for (int i = 0; i < numEvents; ++i)
		{
			const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
			
			if(pMsg->GetGuidID() == Events::AudioUpdateCameraBody::EVENT_GUID)
			{
				UpdateCameraBody(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioUpdateEntityPositionEvent::EVENT_GUID)
			{
				const Events::AudioUpdateEntityPositionEvent* pPositionEvent = static_cast<const Events::AudioUpdateEntityPositionEvent*>(pMsg);
				m_pAudioSystem->UpdateEntityLocation(pPositionEvent->mEntityGUID, pPositionEvent->mPosition);
			}
			else if(pMsg->GetGuidID() == Events::AudioExternalSpeakerEvent::EVENT_GUID)
			{
				const Events::AudioExternalSpeakerEvent* pSpeakerEvent = static_cast<const Events::AudioExternalSpeakerEvent*>(pMsg);
				AudioSystem_FMOD::GetInstance()->ExternalSpeakerControl(pSpeakerEvent->mSpeakerID, pSpeakerEvent->mEnabled); 
			}
			else if(pMsg->GetGuidID() == Events::AudioPlaySoundEvent::EVENT_GUID)
			{ 
#ifdef EVENT_TIMING_ON
				// testing only, be sure to delete this test
				int SentTime = pMsg->GetTimeSent ();
				int RecievedTime = pMsg->GetTimeReceived ();
				const Events::AudioPlaySoundEvent* Event = pMsg->GetClass<Events::AudioPlaySoundEvent>();

				Axiom::Log(LOGGING_CHANNEL, "Audio event play:Id:%d, time(sent:%dms; recd:%dms; diff:%dms)", 
					Event->m_AudioEventId, 
					SentTime, 
					RecievedTime, 
					RecievedTime-SentTime);
#endif
				PlaySoundEvent(pMsg);
			}
			else if (pMsg->GetGuidID() == Events::AudioFEVolumeAdjustEvent::EVENT_GUID)
			{
				const Events::AudioFEVolumeAdjustEvent* pVolumeEvent = static_cast<const Events::AudioFEVolumeAdjustEvent*>(pMsg);
				m_pAudioSystem->SetUserVolume(pVolumeEvent->mVolumeType, pVolumeEvent->mVolumeValue);
			}
			else if (pMsg->GetGuidID() == ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent::EVENT_GUID)
			{
				OnResourceLoaded(pMsg);
			}
		}
		m_ComponentMsgBox->ClearInbox();
	}


	void AudioComponent::UpdateCameraBody(const Axiom::EventMsg* pMsg)
	{
		if (m_pAudioSystem->IsInitialized())
		{
			const Events::AudioUpdateCameraBody *audioCameraEvent = pMsg->GetClass<Events::AudioUpdateCameraBody>();
			m_pAudioSystem->UpdateCamera(audioCameraEvent->m_Position, audioCameraEvent->m_Front, audioCameraEvent->m_Up);
		}
	}


	void AudioComponent::PlaySoundEvent(const Axiom::EventMsg* pMsg)
	{
		const Events::AudioPlaySoundEvent* Event = pMsg->GetClass<Events::AudioPlaySoundEvent>();
		//Axiom::Log("audiocomponent", "Recevied event '%s'", Event->m_EventPath.AsChar());
		if (m_pAudioSystem->IsInitialized())
		{
			
			m_pAudioSystem->PlayEvent(Event);						
		}
	}
	
	//-----------------------------------------------------------

	void	AudioComponent::OnResourceLoaded(const Axiom::EventMsg * msg)
	{
		const ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent* Event = msg->GetClass<ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent>();

		if(Playable::GetNumLoadsExpected() || m_pAudioSystem->GetNumLoadsExpected())
		{
			const Axiom::FileManager::FileInfo*	info = Event->m_FileInfo;
            m_pAudioSystem->OnLoadFinished(info);
			if(Playable::GetNumLoadsExpected() == 0)
			{
				Axiom::Log("audio", "Done loading audio assets");
			}
		}
	}
	
	//----------------------------------------------------------
}

}

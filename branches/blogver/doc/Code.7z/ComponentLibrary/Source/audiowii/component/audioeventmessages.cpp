#include "audiowii/audioeventmessages.h"
#include "audiowii/fmodex/audiosystem_fmodex.h"

using namespace AP::AudioWii::Events;

AP_TYPE(AudioPlaySoundEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Id", m_EntityID, "Identification of the object making the sound")
	AP_FIELD("ThreeD",	 m_Is3D,	"Play in 3D")
	AP_FIELD("PositionX", m_X, "Vector specifying the 3D position the sound should come from")
	AP_FIELD("PositionY", m_Y, "Vector specifying the 3D position the sound should come from")
	AP_FIELD("PositionZ", m_Z, "Vector specifying the 3D position the sound should come from")
	AP_FIELD("EventPath", m_EventPath, "The Event Path in the Event Hierarchy")
	AP_FIELD("ActorName", m_ActorName, "The Actor (Sound Source) of the event")
	AP_FIELD("VoiceID", m_VoiceID, "The Actor (Sound Source) of the event")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

AP_TYPE(AudioFEVolumeAdjustEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("VolumeType",		mVolumeType,	"Type of Volume to Change (Music, SFX, etc.)")
	AP_FIELD("VolumeValue",		mVolumeValue,	"Volume Level, 0 to 100")
AP_TYPE_END()

AP_TYPE(EUserVolumeType)
	AP_ENUM()
AP_TYPE_END()

#if !CORE_FINAL

AP_TYPE(AudioRemotingGenericEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Message", mMessage, "The Message...")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

AP_TYPE(AudioRemotingPlayEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("NodePath", mBankNodePath, "Path to the node that is Played")
	AP_FIELD("Volume", mVolume, "The calculated playback volume (includes group and spatialization volume")
	AP_FIELD("NotLoadedError", mNotLoaded, "If the asset wasn't loaded, but tried to playback")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

AP_TYPE(AudioRemotingBankNotFoundEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("NodePath", mBankNodePath, "Path to the node that is Played")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

AP_TYPE(AudioRemotingBankLoadEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("NodePath", mBankNodePath, "Path to the node that is Played")
	AP_FIELD("Asynchronous", mAsync, "Async Load?")
	AP_FIELD("Unloading", mUnload, "Unloading, not loading")
	AP_FIELD("Automatic", mAutomatic, "Automatic (not in repsonse to a Load Event - done by an async bank, etc.")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

AudioRemotingMemoryUpdateEvent::AudioRemotingMemoryUpdateEvent() : Axiom::EventMsg(EVENT_GUID)
{   			
	mNumKBFMOD  					= AudioSystem_FMOD::FMOD_MEMORY_SIZE >> 10; 
	mNumKBNative 					= (IN_MB(10) + IN_KB(640) - AudioSystem_FMOD::FMOD_MEMORY_SIZE) >> 10;  // *** update this whenever the heap size in wiimain.cpp is updated ***
	mNumKBLargestFreeChunkNative	= static_cast<unsigned short>(static_cast<int>(Axiom::Memory::GetLargestFreeChunkSize(Axiom::Memory::AUDIO_HEAP)) >> 10);

	int current, max;
	FMOD::Memory_GetStats(&current, &max);	
	mNumKBFMODCurrent	= static_cast<unsigned short>(static_cast<int>(current) >> 10); // divide by 1024 to get kb
	mNumKBFMODMax		= static_cast<unsigned short>(static_cast<int>(max) >> 10);	   // divide by 1024 to get kb

	mOutOfMemoryNative  = AudioSystem_FMOD::GetInstance()->mOutOfMemoryNative;
	mOutOfMemoryFMOD  	= AudioSystem_FMOD::GetInstance()->mOutOfMemoryFMOD;
}

AP_TYPE(AudioRemotingMemoryUpdateEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("AssetPath", 		mAssetPath, 		"Path to the node that is Played")
	AP_FIELD("SizeFMOD",  		mNumKBFMOD, 		"Number of bytes given to FMOD in total")
	AP_FIELD("SizeFMODCurrent", mNumKBFMODCurrent, 	"Number of bytes currently used by FMOD")
	AP_FIELD("SizeFMODMax",  	mNumKBFMODMax, 		"Max Number of bytes used by FMOD since init time")
	AP_FIELD("SizeNative",  	mNumKBNative, 		"Number of bytes total on the native audio heap")
	AP_FIELD("FreeChunkNative", mNumKBLargestFreeChunkNative, "Number of bytes available in the largest free chunk on the native heap")
	AP_FIELD("OutOfMemoryNative", mOutOfMemoryNative, "Sample (Native) memory is consumed.")
	AP_FIELD("OutOfMemoryFMOD",   mOutOfMemoryFMOD,   "Stream & Audio Object (FMOD) memory is consumed.")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()


AP_TYPE(AudioRemotingTriggerEvent)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("NodePath", mEventPath, "Path to the event received triggered")
	AP_FIELD("ActorName", mActorName, "Name of the Actor (sound source)")
	AP_FIELD("Handled", mHandled, "If the event is hanlded (event tree contains a path that matches")
	AP_EXPLICIT_PROXY("AcademyLibrary","AudioWii")
AP_TYPE_END()

#endif
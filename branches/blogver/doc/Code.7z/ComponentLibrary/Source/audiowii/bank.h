#ifndef _BANK_H
#define _BANK_H

#include <collections/list.h>
#include <core/autopointer.h>
#include <core/pointer.h>
#include <core/random.h>
#include <core/classedenum.h>
#include "audiowii/playable.h"
#include "audiowii/soundproperties.h"
#include "reflection/type.h"

using namespace Axiom::Collections;

namespace AP
{
	namespace AudioWii
	{
		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS AP_DECLARE_TYPE();

		// RANDOM     	- one started per Play() event, picked at random
		// SEQUENTIAL 	- one started per Play() event, picked sequentially
		CLASSEDENUM
		(
			PlaybackOrder, \
			CLASSEDENUM_ITEMSTART(PLAY_RANDOM) \
			CLASSEDENUM_ITEM(PLAY_SEQUENTIAL), \
			PLAY_RANDOM
		)

		// NORMAL		- Play() plays one sound in the bank (chosen based on playback order)
		// RANDOMFIRE   - Play() starts the bank randomly firing sounds in the bank at an interval 
		//   			  chosen at random between mRandomFireMinMS & mRandFireMaxMS
		CLASSEDENUM
		(
			PlaybackMode, \
			CLASSEDENUM_ITEMSTART(NORMAL) \
			CLASSEDENUM_ITEM(RANDOMFIRE), \
			NORMAL
		)   

		// NORMAL		- All sounds are loaded at load time
		// LOAD_SYNC	- One sound is loaded at a time, on demand, when Play() is called
		// LOAD_ASYNC   - Two sounds are loaded at a time, one pre-loaded and one ready to play (or playing)
		CLASSEDENUM
		(
			LoadingMode, \
			CLASSEDENUM_ITEMSTART(NORMAL) \
			CLASSEDENUM_ITEM(SYNCHRONOUS) \
			CLASSEDENUM_ITEM(ASYNCHRONOUS), \
			NORMAL
		)

		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS
		
		class Bank : public Playable
		{
			
		public:
			typedef ReflectedList< Axiom::AutoPointer<Playable> > AssetList;
			Bank();
			~Bank() {};

			// Implement Playable functionality
			// For a Sound Bank, most cases just forward the call on to each of the playables in mPlayableAssets
			virtual void Load(bool bAsync);		
			virtual void Unload();
			virtual void Play(int entityID, Vector3& position, float attackMS, float delayMS, bool unloadWhenDone);
			virtual void Stop(float releaseMS, bool unloadWhenDone, int entityID);  
			virtual void Pause(float releaseMS); 
			virtual void Resume(float attackMS, float delayMS, bool bForceStart);  
			virtual void Mute();
			virtual void UnMute(); 
			virtual void UpdateTime(int deltaMilliseconds);

			// Bank specific functionality
			int			 CountPlaying() const;
			AssetList& GetAssets() { return mPlayableAssets; }
			virtual bool IsActorSpecific() const { return mActorSpecific; }
			bool		 GetPlayAll() const { return mPlayAll; }
			void		 SetPlayAll(bool playAll);
			PlaybackMode GetPlaybackMode() const { return mPlaybackMode; }


		protected:
			DynamicList<bool>	mHasBeenPlayed;			// If mPlayAll is true, resize this to the number of playable assets
			AssetList			mPlayableAssets;		// Playable asset references
			static Axiom::Random		mRandomizer;	// to get a random next asset id
			Playable*			mPreloadedAsset;		// Pre-loaded asset ptr (for streambanks)
			Axiom::UInt16		mRandomFireMin;			// For PlaybackOrder::RANDOMFIRE, the minimum time for picking delay till the start of the next sound
			Axiom::UInt16		mRandomFireMax;			// For PlaybackOrder::RANDOMFIRE, the maximum time for picking delay till the start of the next sound
			Axiom::UInt16		mRandomFireDelay;		// For PlaybackOrder::RANDOMFIRE, time till startup of the next sound
			Axiom::UInt16		mRandomFireDelayElapsed;// For PlaybackOrder::RANDOMFIRE, keep track of time elapsed
			Axiom::UInt16		mAssetIDIndexRead;		// next id to pull from the asset list (not used when mode is PLAY_RANDOM)
			Axiom::UInt16		mCurrentAssetIDIndex;	// currently playing index
			PlaybackOrder		mPlaybackOrder;			// Sequential, Random, etc.
			PlaybackMode		mPlaybackMode;			// Normal (one played per Play()), or randomfire
			LoadingMode			mLoadingMode;			// Load All, One at a time, Async in background, etc.  		
			Axiom::Bool   		mActorSpecific;			// The actual node to play will be a subnode of this one (named w/ the character name)
			Axiom::Bool			mPlayAll;				// Play ALL Sounds in a bank before cycling through again (used/needed only for random playback)
			
			Playable*			GetNextAsset();

		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _BANK_H
#ifndef _SOUNDPROPERTIES_H
#define _SOUNDPROPERTIES_H

#include "reflection/type.h"
#include <core/random.h>
#include <core/classedenum.h>
#include <collections/list.h>

////////////////////////////////////////////////////////////////////////////
// SoundProperties Class & Associated structs
//
// Rendering attributes of a playable asset. Key, Pitch, Delay, Volume... etc.
// Each Playable asset will derive from this, or have one of these as a member.
///////////////////////////////////////////////////////////////////////////////

using namespace Axiom::Collections;

namespace AP
{
	namespace AudioWii
	{
		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS AP_DECLARE_TYPE();

		// Looping Mode Enum
		CLASSEDENUM
		(
			LoopingMode, \
			CLASSEDENUM_ITEMSTART(OFF) \
			CLASSEDENUM_ITEM(START_MID_END) \
			CLASSEDENUM_ITEM(MID_ONLY) \
			CLASSEDENUM_ITEM(START_MID) \
			CLASSEDENUM_ITEM(MID_END), \
			OFF
		)

		// Storage Mode Enum
		CLASSEDENUM
		(
			StorageMode, \
			CLASSEDENUM_ITEMSTART(MEMORY) \
			CLASSEDENUM_ITEM(STREAMING), \
			MEMORY
		)

		// Positioning Enum
		CLASSEDENUM
		(
			PositioningMode, \
			CLASSEDENUM_ITEMSTART(TWO_DIMENSIONAL) \
			CLASSEDENUM_ITEM(THREE_DIMENSIONAL), \
			TWO_DIMENSIONAL 
		)

		// Distance Attenuation Mode
		CLASSEDENUM
		(
			AttenuationMode, \
			CLASSEDENUM_ITEMSTART(LINEAR) \
			CLASSEDENUM_ITEM(LOG), \
			LINEAR 
		)

		// Curve Interpolation Type
		CLASSEDENUM
		(
			InterpolationMode, \
			CLASSEDENUM_ITEMSTART(LINEAR) \
			CLASSEDENUM_ITEM(POLYNOMIAL) \
			CLASSEDENUM_ITEM(SPLINE), \
			LINEAR 
		)
		

		#undef REFLECTENUMCLASS
		#define REFLECTENUMCLASS

		struct SoundFormat
		{
			int				mSampleRate;
			int				mChannels;
			AP_DECLARE_TYPE();
		};

		// Sound Properties class: 
		// Contains entries for rendering characteristics of sounds
		class SoundProperties
		{

		public:

			SoundProperties() :
								mMasterVolumeDB(0),
								mRandomAttenuation(0),
								mDelay(0),
								mPitch(0),
								mLoopingMode(LoopingMode::OFF),
								mStorageMode(StorageMode::MEMORY),
								mPositioningMode(PositioningMode::TWO_DIMENSIONAL),
								mAttenuationMode(AttenuationMode::LINEAR),
								mLoopStart(0),
								mLoopEnd(0),
								mStreamBufferSize(0),
								mExternalSpeaker(false),
								mApplyUserVolumeSFX(false),
								mApplyUserVolumeMusic(false),
								mDistAttenMin(10),
								mDistAttenMax(60),
								mSendReverb(-90.6f)
								{};


			virtual ~SoundProperties() {};
			
			SoundFormat	   	 			mFormat;			// Audio Format (Sample Rate, Channels, etc.)

			float			mMasterVolumeDB;	// Valid Range 0	-> -90.4 (dB)
			float			mRandomAttenuation;	// Valid Range 0    -> 90.4  (dB) - if > 0, volume will be randomly calculated to be (mMastervolumeDB - rand(RandomAtten)
			float			mRandomPitch;		// Vaild Range 0    -> 1200  (cents) - if > 0, pitch will be varied by rand(0 -> mRandomPitch)
			float			mRandomMissfire;	// Valie Range 0    -> 100   (%) Probability that the sound won't playback
			float			mDelay;				// Valid Range 0    -> Inf 	 (Seconds)
			float			mPitch;				// Valid Range -48  ->  48   (Semitones)
			float			mDistAttenMin;		// Distance Attenuation min distance
			float			mDistAttenMax;		// Distance Attenuation max distance
			int				mLoopStart;			// Loop Start, in frames
			int				mLoopEnd;			// Loop End, in frames
			bool			mExternalSpeaker;	// Play the sound out the external speaker
			float			mSendReverb;		// Reverb Send Level (-90.6 == OFF, 0 == 100%)
			bool			mApplyUserVolumeSFX;// Is this a sound effet that is influenced by the user-set FE SFX Volume?   
			bool			mApplyUserVolumeMusic;// Is this a sound effet that is influenced by the user-set FE SFX Volume?   

			LoopingMode	 	mLoopingMode;		// Looping Mode (off, mid-section, etc.)
			StorageMode		mStorageMode;		// Play from memory (default), or stream from disk
			PositioningMode mPositioningMode;	// 2D, 3D, etc.
			AttenuationMode mAttenuationMode; 	// linear, log

			int				mStreamBufferSize;	// Override the default Stream Buffer size for streams. 0 == ignore (use default 16384).
		
		public:
			AP_DECLARE_POLYMORPHIC_TYPE();
		};
	}
}

#endif // _SOUNDPROPERTIES_H

#include "core/core.h"
#include "assert.h"
#include <eventsystem/eventman.h>
#include "kernel/component.h"
#include "kernel/systemtimer.h"
#include "marshaller/eventbuffer.h"
#include "eventlogging/eventloggercomponent.h"
#include "eventlogging/eventloggermessages.h"
#include "kernel/messages.h"

using namespace AP::EventLogging::Events;

namespace AP
{

	EventLoggerComponent::EventLoggerComponent(Axiom::ConstStr name, Kernel* kernel)
	: Component(name,kernel)
	, m_ComponentMsgBox(NULL)
	{

	}

	EventLoggerComponent::~EventLoggerComponent()
	{

	}

	void EventLoggerComponent::OnInit()
	{
		m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("EventLogger");
		m_ComponentMsgBox->RegisterListenBroadcastEvent(LogCRCEvent::GetEventId());
	}

	void EventLoggerComponent::OnUpdate()
	{
		HandleEvents();
	}

	void EventLoggerComponent::OnShutdown()
	{
		mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
	}

	void EventLoggerComponent::HandleEvents()
	{
		int numEvents = m_ComponentMsgBox->GetNumEvents();

		for (int i = 0; i < numEvents; ++i)
		{
			const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

			if(pMsg->GetGuidID() == LogCRCEvent::EVENT_GUID)
			{
				OnLogCRCEvent(pMsg);
			}
		}

		m_ComponentMsgBox->ClearInbox();
	}

	void EventLoggerComponent::OnLogCRCEvent(const Axiom::EventMsg* pMsg)
	{
		UNUSED_PARAM(pMsg);
	}
}


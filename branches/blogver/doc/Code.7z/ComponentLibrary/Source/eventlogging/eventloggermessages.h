#ifndef __INPUTEVENT_EVENT_MESSAGES_H___
#define __INPUTEVENT_EVENT_MESSAGES_H___

#include "EventSystem/eventmsg.h"

namespace AP
{
	namespace EventLogging
	{
		namespace Events
		{
			class LogCRCEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(LogCRCEvent)//, Msg_LoggingFrameCRC)
					
				LogCRCEvent():Axiom::EventMsg(EVENT_GUID){}
				LogCRCEvent(int crc):Axiom::EventMsg(EVENT_GUID), mCRC(crc){}
				int mCRC;
				int mFrameTick;
			};
		}
	}
}
#endif

#ifndef __INPUTEVENT_EVENT_MESSAGES_H___
#define __INPUTEVENT_EVENT_MESSAGES_H___

#include "kernel/messages.h"

namespace AP
{
	namespace EventLogging
	{
		namespace Events
		{
			class LogCRCEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(StartMarshallingEvent);//, Msg_StartMarshalling)
					StartMarshallingEvent():Axiom::EventMsg(EVENT_GUID){}

			};

			class LogFrameEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(SyncFrameMarshallingEvent)//, Msg_SyncFrameMarshalling)
					
				SyncFrameMarshallingEvent():AP::EventMsg(EVENT_GUID),mFrameTick(0){}
				SyncFrameMarshallingEvent(int frame):Axiom::EventMsg(EVENT_GUID),mFrameTick(frame){}

				int mFrameTick;
			};

		}
	}

}
#endif

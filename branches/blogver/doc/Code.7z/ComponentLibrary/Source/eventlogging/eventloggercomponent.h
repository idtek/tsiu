#ifndef _EVENT_LOGGER_COMPONENT_H___
#define _EVENT_LOGGER_COMPONENT_H___

namespace AP
{
	class EventLoggerComponent: public Component
	{
	public:
		EventLoggerComponent(Axiom::ConstStr name, Kernel* kernel);
		~EventLoggerComponent();

		virtual void									OnInit();
		virtual void									OnUpdate();
		virtual void									OnShutdown();

	private:

		struct EventData 
		{	
			
			int mCRC;
			int mSimFrame;
		};

		Axiom::EventMsgBoxHandle						m_ComponentMsgBox;

		void											HandleEvents();
		void											OnLogCRCEvent(const Axiom::EventMsg* pMsg);
	};
}

#endif

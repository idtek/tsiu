#include "input/icontroller.h"
#include "input/x360buttons.h"
#include "input/wiibuttons.h"
#include "input/controllerfactory.h"
#include <math/apmath.h>
#include "xinput.h"

// begin direct input
#include <dinput.h>
#include <dinputd.h>
extern LPDIRECTINPUT8  g_pDI;
extern HWND g_hWnd;
LPDIRECTINPUTDEVICE8 g_pJoystick        = NULL;
LPDIRECTINPUTDEVICE8 g_pKeyBoard		= NULL;
DIDEVCAPS g_diDevCaps;

#define MONKEY_MASH CORE_YES

#if MONKEY_MASH
#include <core/random.h>
// Accessed from FE_Manager
bool use_monkey = false;
#endif

BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE*     
                                       pdidInstance, VOID* pContext)
{
    HRESULT hr;

	if ( !strncmp(pdidInstance->tszInstanceName, "PPJoy", 5))
	{
		// Obtain an interface to the enumerated joystick.
		hr = g_pDI->CreateDevice(pdidInstance->guidInstance,  
									&g_pJoystick, NULL);
		if(FAILED(hr)) 
			return DIENUM_CONTINUE;

//		return DIENUM_STOP;
		return DIENUM_CONTINUE;
	}
	else
		return DIENUM_CONTINUE;
}
// end direct input

namespace AP
{
	namespace Input
	{
		static const int DEADZONELEFT = XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
		static const int DEADZONERIGHT = XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE;
		static const int MAX_ANALOG = 32767;
		static const int MIN_ANALOG = -32768;
		static const float MAX_ANALOG_BUTTON_VALUE = 255.f;

		static const int DPAD_UP          = 0x00000001;
		static const int DPAD_DOWN        = 0x00000002;
		static const int DPAD_LEFT        = 0x00000004;
		static const int DPAD_RIGHT       = 0x00000008;
		static const int START            = 0x00000010;
		static const int BACK             = 0x00000020;
		static const int LEFT_THUMB       = 0x00000040;
		static const int RIGHT_THUMB      = 0x00000080;
		static const int LEFT_SHOULDER    = 0x00000100;
		static const int RIGHT_SHOULDER   = 0x00000200;
		static const int A                = 0x00001000;
		static const int B                = 0x00002000;
		static const int X                = 0x00004000;
		static const int Y                = 0x00008000;

		static const int LEFT_TRIGGER     = 0x00010000;
		static const int RIGHT_TRIGGER    = 0x00020000;

		static const int MAX_RUMBLE		  = 65535;

		class ControllerWin32pc: public IController
		{
			public:
				class ControllerData: public IControllerData
				{
					public:
						ControllerData();
						~ControllerData() {};

						ControllerData& operator=(const ControllerData& rightHandSide);

					protected:
						ControllerData(const ControllerData&);

					public:
						virtual const AnalogStick*		GetAnalogStick(const int index) const;
						virtual const AnalogButton*		GetAnalogButton(int index) const;
						virtual const DigitalButton*	GetDigitalButton(int index) const;
						virtual const Actuator*			GetActuator(int index) const;

					public:
						AnalogStick			m_AnalogSticks[EX360AnalogSticks::NumberOfItems];
						AnalogButton		m_AnalogButtons[EX360AnalogButtons::NumberOfItems];
						DigitalButton		m_DigitalButtons[EX360DigitalButtons::NumberOfItems];
						Actuator			m_Actuators[EX360Actuators::NumberOfItems];
				};

			public:
				ControllerWin32pc(int id);

				virtual void Update();

				virtual int						GetAnalogStickCount() const;
				virtual int						GetAnalogButtonCount() const;
				virtual int						GetDigitalButtonCount() const;
				virtual int						GetActuatorCount() const;

				virtual bool					IsConnected()const{ return m_Connected;}
				virtual const IControllerData*	GetPreviousControllerData() const { return &m_PreviousControllerData; }
				virtual const IControllerData*	GetCurrentControllerData() const { return &m_CurrentControllerData; }

				virtual void					EnablePointer( bool enable ) { }
				virtual void					EnableMotionPlus( bool enable ) { }
				virtual void					TareBalanceBoard() {}
				virtual void					TGCBalanceBoard() {}
				virtual void					ZeroMPLS() {}

			private:
				Axiom::Float			GetNorm(Axiom::Float value, int deadzone);

				int					m_Id;
				
				ControllerData		m_PreviousControllerData;
				ControllerData		m_CurrentControllerData;
				bool				m_Connected;
		};

		ControllerWin32pc::ControllerData::ControllerData()
		{
			m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonID			= DPAD_UP;
			m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonID			= DPAD_DOWN;
			m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonID			= DPAD_LEFT;
			m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonID			= DPAD_RIGHT;
			m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonID				= START;
			m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonID				= BACK;
			m_DigitalButtons[EX360DigitalButtons::LeftShoulder].m_ButtonID		= LEFT_SHOULDER;
			m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonID		= RIGHT_SHOULDER;
			m_DigitalButtons[EX360DigitalButtons::LeftThumb].m_ButtonID			= LEFT_THUMB;
			m_DigitalButtons[EX360DigitalButtons::RightThumb].m_ButtonID		= RIGHT_THUMB;
			m_DigitalButtons[EX360DigitalButtons::A].m_ButtonID					= A;
			m_DigitalButtons[EX360DigitalButtons::B].m_ButtonID		= B;
			m_DigitalButtons[EX360DigitalButtons::X].m_ButtonID					= X;
			m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonID					= Y;

			m_AnalogButtons[EX360AnalogButtons::LeftTrigger].m_ButtonID			= LEFT_TRIGGER;
			m_AnalogButtons[EX360AnalogButtons::RightTrigger].m_ButtonID		= RIGHT_TRIGGER;

			m_Actuators[EX360Actuators::LeftActuator].SetValue(0.f);
			m_Actuators[EX360Actuators::RightActuator].SetValue(0.f);
		}

		ControllerWin32pc::ControllerData& ControllerWin32pc::ControllerData::operator=(const ControllerData& rightHandSide)
		{
			m_AnalogSticks[EX360AnalogSticks::Left] = rightHandSide.m_AnalogSticks[EX360AnalogSticks::Left];
			m_AnalogSticks[EX360AnalogSticks::Right] = rightHandSide.m_AnalogSticks[EX360AnalogSticks::Right];

			m_DigitalButtons[EX360DigitalButtons::DPadUp] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadUp];
			m_DigitalButtons[EX360DigitalButtons::DPadDown] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadDown];
			m_DigitalButtons[EX360DigitalButtons::DPadLeft] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadLeft];
			m_DigitalButtons[EX360DigitalButtons::DPadRight] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadRight];
			m_DigitalButtons[EX360DigitalButtons::Start] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Start];
			m_DigitalButtons[EX360DigitalButtons::Back] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Back];
			m_DigitalButtons[EX360DigitalButtons::LeftShoulder] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::LeftShoulder];
			m_DigitalButtons[EX360DigitalButtons::RightThumb] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::RightThumb];
			m_DigitalButtons[EX360DigitalButtons::LeftThumb] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::LeftThumb];
			m_DigitalButtons[EX360DigitalButtons::RightShoulder] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::RightShoulder];
			m_DigitalButtons[EX360DigitalButtons::A] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::A];
			m_DigitalButtons[EX360DigitalButtons::B] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::B];
			m_DigitalButtons[EX360DigitalButtons::X] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::X];
			m_DigitalButtons[EX360DigitalButtons::Y] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Y];

			m_AnalogButtons[EX360AnalogButtons::LeftTrigger]	= rightHandSide.m_AnalogButtons[EX360AnalogButtons::LeftTrigger];
			m_AnalogButtons[EX360AnalogButtons::RightTrigger]   = rightHandSide.m_AnalogButtons[EX360AnalogButtons::RightTrigger];

			m_Actuators[EX360Actuators::LeftActuator].SetValue(rightHandSide.m_Actuators[EX360Actuators::LeftActuator].GetMagnitude());	
			m_Actuators[EX360Actuators::RightActuator].SetValue(rightHandSide.m_Actuators[EX360Actuators::RightActuator].GetMagnitude());

			return *this;
		};

		const IController::AnalogStick* ControllerWin32pc::ControllerData::GetAnalogStick(const int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360AnalogSticks::NumberOfItems, "ControllerData::GetAnalogStick - index out of range.");

			return &(m_AnalogSticks[index]);
		}

		const IController::AnalogButton* ControllerWin32pc::ControllerData::GetAnalogButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360AnalogButtons::NumberOfItems, "ControllerData::GetAnalogButton - index out of range.");

			return &(m_AnalogButtons[index]);
		}

		const IController::DigitalButton* ControllerWin32pc::ControllerData::GetDigitalButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360DigitalButtons::NumberOfItems, "ControllerData::GetDigitalButton - index out of range.");

			return &(m_DigitalButtons[index]);
		}

		const IController::Actuator* ControllerWin32pc::ControllerData::GetActuator(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360Actuators::NumberOfItems, "ControllerData::GetActuator - index out of range.");

			return &(m_Actuators[index]);
		}

		ControllerWin32pc::ControllerWin32pc(int id)
			:	m_Id(id)
			,	m_Connected(false)
		{
// begin direct input
			//g_pDI is an initialized pointer to IDirectInput8
			if ( g_pDI)
			{
			    HRESULT hr;

				g_pDI->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoysticksCallback,NULL, DIEDFL_ATTACHEDONLY);

				if(g_pJoystick)
				{
					hr = g_pJoystick->SetDataFormat(&c_dfDIJoystick2);

					hr = g_pJoystick->SetCooperativeLevel(g_hWnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND | DISCL_BACKGROUND);

					g_diDevCaps.dwSize = sizeof(DIDEVCAPS);
					hr = g_pJoystick->GetCapabilities(&g_diDevCaps);

// OPTIONAL					hr = g_pJoystick->EnumObjects(EnumAxesCallback, (VOID*)g_hWnd, DIDFT_AXIS);

					hr = g_pJoystick->Acquire();
				}
				
				g_pDI->CreateDevice(GUID_SysKeyboard, &g_pKeyBoard, NULL);
				if(g_pKeyBoard)
				{
					hr = g_pKeyBoard->SetDataFormat(&c_dfDIKeyboard);
					//if(FAILED(hr))
					//	D_FatalError("KeyBoard SetDataFormat failed");
					hr = g_pKeyBoard->SetCooperativeLevel(g_hWnd, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE );
					//if(FAILED(l_HR))
					//	D_FatalError("KeyBoard SetCooperativeLevel failed");
					hr = g_pKeyBoard->Acquire();
				}
			}
// end direct input
		}

		Axiom::Float ControllerWin32pc::GetNorm(Axiom::Float value, Axiom::Int32 deadzone)
		{
			const float one_over_max = 1.f/static_cast<float>(MAX_ANALOG - deadzone + 1);
			AP_ASSERT(value <= MAX_ANALOG);

			if(Axiom::Math::Fabs(value) <= deadzone)
				return 0.f;

			float newValue = (value<0)?value+deadzone:value-deadzone;

			newValue = newValue * one_over_max;

			// Removed this assert so that FE will not crash
			//AP_ASSERT(newValue>=-1.f && newValue<=1.f);

			return newValue;
		}

		void ControllerWin32pc::Update()
		{
			bool useDInput = false;
			bool useKB = false;

			if ( g_pJoystick != NULL)
			{
				HRESULT hr;

				if (m_Id == 0)
				{
					hr = g_pJoystick->Poll(); 
					if (FAILED(hr)) 
					{
						hr = g_pJoystick->Acquire();
					}

					if ( FAILED(hr))
					{
						useDInput = false;
					}
					else
					{
						useDInput = true;
					}
				}
			}

			if ( useDInput)
			{
// begin direct input
				m_PreviousControllerData = m_CurrentControllerData;
					
				HRESULT hr;
				DIJOYSTATE2 js;           // Direct Input joystick state 

				if (m_Id == 0)
				{
					// Poll the device to read the current state
					hr = g_pJoystick->GetDeviceState(sizeof(DIJOYSTATE2), &js);

					if (!FAILED(hr))

					{
						float leftX = js.lX / 32768.f -1;
						float leftY = js.lY / 32768.f -1;
						float rightX = js.lZ / 32768.f -1;
						float rightY = js.lRz / 32768.f -1;
						m_Connected = true;
						m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::Pointer].SetValue(leftX, leftY);//GetNorm(leftX, DEADZONELEFT),GetNorm(leftY, DEADZONELEFT));
						m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::NunchuckStick].SetValue(rightX, -rightY);//GetNorm(rightX, DEADZONERIGHT),GetNorm(rightY, DEADZONERIGHT));

						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadUp].m_ButtonState			= js.rgbButtons[0] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadDown].m_ButtonState		= js.rgbButtons[1] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadLeft].m_ButtonState		= js.rgbButtons[2] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadRight].m_ButtonState		= js.rgbButtons[3] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Plus].m_ButtonState			= js.rgbButtons[4] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Minus].m_ButtonState			= js.rgbButtons[5] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState			= js.rgbButtons[6] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonZ].m_ButtonState			= js.rgbButtons[7] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button1].m_ButtonState			= js.rgbButtons[8] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button2].m_ButtonState			= js.rgbButtons[9] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonA].m_ButtonState			= js.rgbButtons[10] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonNone].m_ButtonState		= js.rgbButtons[11] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonB].m_ButtonState			= js.rgbButtons[12] & 0x80 ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonHome].m_ButtonState		= js.rgbButtons[13] & 0x80 ? 1 : 0;

						m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::LeftTrigger].SetValue((js.lRx)/255.0f);
						m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::RightTrigger].SetValue((js.lRy)/255.0f);
					}
					else
					{
						m_Connected = false;
					}
				}
				else
				{
					m_Connected = false;
				}
// end direct input
			}
			else
			{
				m_PreviousControllerData = m_CurrentControllerData;

				XINPUT_STATE state;
				ZeroMemory( &state, sizeof(XINPUT_STATE) );

				// Simply get the state of the controller from XInput.
				DWORD dwResult = XInputGetState( m_Id, &state );

				if( dwResult == ERROR_SUCCESS )
				{
					useKB = false;

					m_Connected = true;
					//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].m_Vector.x                      = GetNorm(state.Gamepad.sThumbLX, DEADZONELEFT);
					//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].m_Vector.y                      = GetNorm(state.Gamepad.sThumbLY, DEADZONELEFT);
					//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].m_Vector.x                     = GetNorm(state.Gamepad.sThumbRX, DEADZONERIGHT);
					//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].m_Vector.y                     = GetNorm(state.Gamepad.sThumbRY, DEADZONERIGHT);

					m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].SetValue(GetNorm(state.Gamepad.sThumbLX, DEADZONELEFT),GetNorm(state.Gamepad.sThumbLY, DEADZONELEFT));
					m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].SetValue(GetNorm(state.Gamepad.sThumbRX, DEADZONERIGHT),GetNorm(state.Gamepad.sThumbRY, DEADZONERIGHT));

					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonState			= state.Gamepad.wButtons & DPAD_UP ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonState		= state.Gamepad.wButtons & DPAD_DOWN ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonState		= state.Gamepad.wButtons & DPAD_LEFT ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonState		= state.Gamepad.wButtons & DPAD_RIGHT ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonState			= state.Gamepad.wButtons & START ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonState			= state.Gamepad.wButtons & BACK ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftShoulder].m_ButtonState	= state.Gamepad.wButtons & LEFT_SHOULDER ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonState	= state.Gamepad.wButtons & RIGHT_SHOULDER ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftThumb].m_ButtonState	    = state.Gamepad.wButtons & LEFT_THUMB ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightThumb].m_ButtonState	    = state.Gamepad.wButtons & RIGHT_THUMB ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::A].m_ButtonState				= state.Gamepad.wButtons & A ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::B].m_ButtonState				= state.Gamepad.wButtons & B ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::X].m_ButtonState				= state.Gamepad.wButtons & X ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonState				= state.Gamepad.wButtons & Y ? 1 : 0;

					m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::LeftTrigger].SetValue(state.Gamepad.bLeftTrigger/255.0f);
					m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::RightTrigger].SetValue(state.Gamepad.bRightTrigger/255.0f);
					//m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::LeftTrigger].m_ButtonState		= static_cast<float>(state.Gamepad.bLeftTrigger)/MAX_ANALOG_BUTTON_VALUE;
					//m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::RightTrigger].m_ButtonState		= static_cast<float>(state.Gamepad.bRightTrigger)/MAX_ANALOG_BUTTON_VALUE;
				}																								
				else
				{
					m_Connected = false;
					// Controller is not connected 
					useKB = true;
				}


				//Actuator update
				XINPUT_VIBRATION vibrationStruct;
				float fMagnitude = m_CurrentControllerData.m_Actuators[EX360Actuators::LeftActuator].GetMagnitude();
				vibrationStruct.wLeftMotorSpeed = static_cast<WORD>(fMagnitude * MAX_RUMBLE);
				fMagnitude = m_CurrentControllerData.m_Actuators[EX360Actuators::RightActuator].GetMagnitude();
				vibrationStruct.wRightMotorSpeed = static_cast<WORD>(fMagnitude * MAX_RUMBLE);
				XInputSetState( m_Id, &vibrationStruct);
			}
			
			if(useKB)
			{
				if(g_pKeyBoard && m_Id == 0)
				{
					char     buffer[256]; 
					HRESULT  hr; 
					hr = g_pKeyBoard->GetDeviceState(sizeof(buffer),(LPVOID)&buffer); 

					float upLeft	= buffer[DIK_W] & 0x80 ? 1.f : (buffer[DIK_S] & 0x80 ? -1.f : 0.f);
					float rightLeft = buffer[DIK_D] & 0x80 ? 1.f : (buffer[DIK_A] & 0x80 ? -1.f : 0.f);
					float upRight	= buffer[DIK_T] & 0x80 ? 1.f : (buffer[DIK_G] & 0x80 ? -1.f : 0.f);
					float rightRight= buffer[DIK_H] & 0x80 ? 1.f : (buffer[DIK_F] & 0x80 ? -1.f : 0.f);
					m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].SetValue(rightLeft, upLeft);
					m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].SetValue(rightRight, upRight);

					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonState			= buffer[DIK_UP] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonState		= buffer[DIK_DOWN] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonState		= buffer[DIK_LEFT] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonState		= buffer[DIK_RIGHT] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonState			= buffer[DIK_RETURN] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonState			= buffer[DIK_SPACE] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftShoulder].m_ButtonState	= buffer[DIK_Q] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonState	= buffer[DIK_O] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftThumb].m_ButtonState	    = buffer[DIK_X] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightThumb].m_ButtonState	    = buffer[DIK_B] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::A].m_ButtonState				= buffer[DIK_K] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::B].m_ButtonState				= buffer[DIK_L] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::X].m_ButtonState				= buffer[DIK_J] & 0x80 ? 1 : 0;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonState				= buffer[DIK_I] & 0x80 ? 1 : 0;

					m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::LeftTrigger].SetValue(buffer[DIK_1] & 0x80 ? 1 : 0);
					m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::RightTrigger].SetValue(buffer[DIK_9] & 0x80 ? 1 : 0);
					m_Connected = true;
				}
			}

#if MONKEY_MASH
			if ( use_monkey)
			{
				if(m_Id > 1)
				{
					m_Connected = false;
					return;
				}
				m_Connected = true;
static	Axiom::Random	random;
				float rnd;
static float MONKEY_POINTERX_MIN = -1.0f;
static float MONKEY_POINTERX_MAX = 1.0f;
static float MONKEY_POINTERX_MAXCHANGEPERFRAME = 0.2f;
static float monkey_PointerX = 0.0f;
				rnd = random.RandFloat(-MONKEY_POINTERX_MAXCHANGEPERFRAME, MONKEY_POINTERX_MAXCHANGEPERFRAME);
				monkey_PointerX += rnd;
				monkey_PointerX = Axiom::Math::Clamp(monkey_PointerX, MONKEY_POINTERX_MIN, MONKEY_POINTERX_MAX);
static float MONKEY_POINTERY_MIN = -1.0f;
static float MONKEY_POINTERY_MAX = 1.0f;
static float MONKEY_POINTERY_MAXCHANGEPERFRAME = 0.2f;
static float monkey_PointerY = 0.0f;
				rnd = random.RandFloat(-MONKEY_POINTERY_MAXCHANGEPERFRAME, MONKEY_POINTERY_MAXCHANGEPERFRAME);
				monkey_PointerY += rnd;
				monkey_PointerY = Axiom::Math::Clamp(monkey_PointerY, MONKEY_POINTERY_MIN, MONKEY_POINTERY_MAX);			
				m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].SetValue(monkey_PointerX, monkey_PointerY);	// Wii pointer, does odd things when off screen...
// Note, following values are %ages.  so 1 = probably of being pressed once in 100 frames.  100 = probably of being pressed all the time.
static float MONKEY_PROB_UP = 0.1f;
static float MONKEY_PROB_DOWN = 0.1f;
static float MONKEY_PROB_LEFT = 0.1f;
static float MONKEY_PROB_RIGHT = 0.1f;
static float MONKEY_PROB_PLUS = 0.1f;
static float MONKEY_PROB_HOME = 0.0f;
static float MONKEY_PROB_MINUS = 0.0f;
static float MONKEY_PROB_A = 20.f;
static float MONKEY_PROB_B = 0.1f;
static float MONKEY_PROB_1 = 0.1f;
static float MONKEY_PROB_2 = 0.1f;
static float MONKEY_PROB_NUNCHUK = 99.9f;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonState 		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_UP;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_DOWN;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_LEFT;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_RIGHT;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_PLUS;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_MINUS;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::A].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_A;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::B].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_B;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::X].m_ButtonState   	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_1;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_2;

				//m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState  = random.RandFloat(0.0f, 1.0f) < MONKEY_PROB_NUNCHUK;

				//if ( m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState)
				{
static float MONKEY_STICKX_MIN = -1.0f;
static float MONKEY_STICKX_MAX = 1.0f;
static float MONKEY_STICKX_MAXCHANGEPERFRAME = 0.2f;
static float monkey_StickX = 0.0f;
					rnd = random.RandFloat(-MONKEY_STICKX_MAXCHANGEPERFRAME, MONKEY_STICKX_MAXCHANGEPERFRAME);
					monkey_StickX += rnd;
					monkey_StickX = Axiom::Math::Clamp(monkey_StickX, MONKEY_STICKX_MIN, MONKEY_STICKX_MAX);
static float MONKEY_STICKY_MIN = -1.0f;
static float MONKEY_STICKY_MAX = 1.0f;
static float MONKEY_STICKY_MAXCHANGEPERFRAME = 0.2f;
static float monkey_StickY = 0.0f;
					rnd = random.RandFloat(-MONKEY_STICKY_MAXCHANGEPERFRAME, MONKEY_STICKY_MAXCHANGEPERFRAME);
					monkey_StickY += rnd;
					monkey_StickY = Axiom::Math::Clamp(monkey_StickY, MONKEY_STICKY_MIN, MONKEY_STICKY_MAX);			
					m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].SetValue(monkey_StickX, monkey_StickY);
static float MONKEY_PROB_C = 0.1f;
static float MONKEY_PROB_Z = 0.0f;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_C;
					m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_Z;
				}
			}
#endif
		}

		int ControllerWin32pc::GetAnalogStickCount() const
		{
			return EX360AnalogSticks::NumberOfItems;
		}

		int ControllerWin32pc::GetAnalogButtonCount() const
		{
			return EX360AnalogButtons::NumberOfItems;
		}

		int ControllerWin32pc::GetDigitalButtonCount() const
		{
			return EX360DigitalButtons::NumberOfItems;
		}

		int ControllerWin32pc::GetActuatorCount() const
		{
			return EX360Actuators::NumberOfItems;
		}

		IController* ControllerFactory::CreateController(int controllerID)
		{
			return AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerWin32pc(controllerID));
		}
	}
}

#include <core/singleton.h>
#include <collections/dictionary.h>
#include <collections/booklet.h>
#include <thread/atomic.h>

#include "input/virtualcontrollermap.h"

using namespace Axiom::Thread;
namespace AP
{
	namespace Input
	{
		VirtualControllerMap::VirtualControllerMap():mNumSlotPerGroup(0),mNumGroups(0),mVirtualGroupId(0)
		{
		}

		VirtualControllerMap::~VirtualControllerMap()
		{
			mMap.Clear();
		}

		void VirtualControllerMap::SetMaxVirtualControllers( unsigned int numControllers )
		{
			mMap.Resize( Axiom::Memory::DEFAULT_HEAP, numControllers );
		}

		void VirtualControllerMap::Reset(Axiom::UInt32 numGroups, Axiom::UInt32 numSlotPerGroup )
		{
			mMap.Clear();
			mNumGroups = numGroups;
			mNumSlotPerGroup = numSlotPerGroup;
			AP_ASSERT( mNumGroups * mNumSlotPerGroup <= mMap.Capacity() );
		}

		int VirtualControllerMap::GetVirtualIdFromGroupSlot(Axiom::UInt32 group, Axiom::UInt32 slotInGroup)
		{
            AP_PRECONDITION( group < GetNumGroup() );
            AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() );
                
			AP_ASSERTMESSAGE(mMap.Count()>0, "Ensure that the map is set before access!!");
			int slotIdToFind = GetSlotIdFromGroupSlot(group, slotInGroup);
			
			for(unsigned int i=0;i<mMap.Count();i++)
			{
				if(mMap[i] == slotIdToFind)
				{
					return mMap.KeyAt(i);
				}
			}

			AP_ASSERTFAIL("Virtual Controller ID not assigned to map yet!!");
			return INVALID_VIRTUAL_CONTROLLER_ID;
		}

		Axiom::UInt32 VirtualControllerMap::GetSlotIdFromGroupSlot(Axiom::UInt32 group, Axiom::UInt32 slotInGroup)
		{
            AP_PRECONDITION( group < GetNumGroup() );
            AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() );
                
			return ( group * mNumSlotPerGroup ) + slotInGroup;
		}

		bool VirtualControllerMap::AssignControllerToSlot(int virtualControllerId, Axiom::UInt32 group, Axiom::UInt32 slotInGroup)
		{
            AP_PRECONDITION( group < GetNumGroup() );
            AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() );
			
			int key = ( group * mNumSlotPerGroup) + slotInGroup;
			int* pValue = mMap.TryGetValue(virtualControllerId);
			
			if(pValue != NULL)
			{
				return false;
			}
	
			mMap.Add(virtualControllerId, key);

			return true;
		}

		Axiom::UInt32 VirtualControllerMap::GetAssignSlotId(int virtualControllerId)
		{
			int* pValue = mMap.TryGetValue(virtualControllerId);
			
			if(pValue !=NULL)
			{
				return *pValue;
			}

			return INVALID_CONTROLLER_MAP_ID;
		}

		bool VirtualControllerMap::IsLocalVirtualControllerId(int virtualId)
		{
			int localStartIndex = mNumSlotPerGroup * AtomicRead(&mVirtualGroupId);
			int localEndIndex  = localStartIndex + mNumSlotPerGroup - 1;
			return (virtualId >= localStartIndex && virtualId<= localEndIndex);
		}

		Axiom::UInt32 VirtualControllerMap::GetVirtualIdFromControllerId(Axiom::UInt32 slotID)
		{
			AP_ASSERT(slotID>=0 && slotID< mMaxSlotId);

			AP_ASSERT( mNumSlotPerGroup > 0 && mNumGroups > 0);
			int vid = ( mNumSlotPerGroup *AtomicRead(&mVirtualGroupId) ) + slotID;

			AP_ASSERT(vid>=0 && vid<=static_cast<int>(mMap.Capacity()));
			return vid;
		}

		Axiom::UInt32 VirtualControllerMap::GetControllerIdFromVirtualId(Axiom::UInt32 virtualID)
		{
			AP_ASSERT(virtualID>=0 && virtualID<mMap.Capacity());
			AP_ASSERT(IsLocalVirtualControllerId(virtualID) == true);
			AP_ASSERT( mNumSlotPerGroup > 0 && mNumGroups > 0);
			int cid = virtualID - ( mNumSlotPerGroup *AtomicRead(&mVirtualGroupId) );

			AP_ASSERT(cid>=0 && cid<static_cast<int>(mMaxSlotId));
			return cid;
		}

		void VirtualControllerMap::AssignVirtualGroupId(Axiom::UInt32 virtualGroupId)
		{
			AtomicExchange(&mVirtualGroupId,virtualGroupId);
		}

		Axiom::UInt32 VirtualControllerMap::GetMaxNumSlots()const
		{
			return mNumGroups * mNumSlotPerGroup;
		}

		Axiom::UInt32 VirtualControllerMap::GetNumSlotPerGroup()const 
		{
			return mNumSlotPerGroup;
		}

		Axiom::UInt32 VirtualControllerMap::GetNumGroup()const 
		{ 
			return mNumGroups;
		}

		Axiom::UInt32 VirtualControllerMap::GetVirtualIdByIndex( unsigned int index) const
		{
			AP_ASSERT(index>=0 && index<mMap.Count());
			return mMap.KeyAt(index);
		}

		unsigned int VirtualControllerMap::GetIndexFromVirtualId( unsigned int virtualId )
		{
			for( unsigned int i = 0; i < mMap.Count(); ++i )
			{
				if( mMap[i] == static_cast<int>(virtualId) )
				{
					return i;
				}
			}

			return INVALID_CONTROLLER_MAP_ID;
		}

		int VirtualControllerMap::GetNumAssignedVirtualId() const
		{
			return mMap.Count();
		}

	}
}

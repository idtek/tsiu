#include "input/coreinputcomponent.h"
#include "input/icontroller.h"
#include "input/controllerfactory.h"
#include "input/iinputtranslator.h"
#include "core/core.h"
#include "assert.h"
#include "math/apmath.h"
#include "math/vector2.h"
#include "math/vector3.h"
#include "kernel/kernel.h"
#include "input/inputconst.h"
#include "input/inputeventmessages.h"
#include "collections/booklet.h"
#include "input/virtualcontrollermap.h"

#include "inputrecording/recordereventmessages.h"

#define RANDOM_INPUT	(0 && !(CORE_FINAL))

namespace AP
{	
namespace Input
{
	AP_TYPE(EButtonStates)
		AP_ENUM()
	AP_TYPE_END()
    //////////////////////////////////////////////////////

	CoreInputComponent::CoreInputComponent(Axiom::ConstStr name, Kernel* kernel) : 
		Component(name,kernel),
		m_pInputTranslator( 0 ),
		m_ComponentMsgBox( 0 )
	{
	}

	CoreInputComponent::~CoreInputComponent()
	{
	}

    //////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////////////
	// Public Interfaces
	////////////////////////////////////////////////////////////////////////////////////

	void CoreInputComponent::InstallInputTranslator(IInputTranslator* pInputTranslator)
	{
		m_pInputTranslator = pInputTranslator;
	}

	void CoreInputComponent::OnInit()
	{
		m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("CoreInput", Axiom::Memory::DEFAULT_HEAP, 16, 16, 10);
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputChangeRumbleLevelEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputEnableRumbleEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputEnablePointerEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputEnableMotionPlusEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputTareBalanceBoardEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputTGCBalanceBoardEvent::GetEventId());
		m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::InputZeroMotionPlusEvent::GetEventId());
		
			
		// ASF - I want to move this to the common main.
#if !FINAL
		AP::InputRecording::LogEvent_RecorderControllerSetup recorderSetControllersEvent(m_ControllerArray.Count(), &m_ControllerArray[0]);
		m_ComponentMsgBox->SendEvent(&recorderSetControllersEvent);

		AP::InputRecording::LogEvent_PlaybackControllerSetup playbackSetControllersEvent(m_ControllerArray.Count(), &m_ControllerArray[0]);
		m_ComponentMsgBox->SendEvent(&playbackSetControllersEvent);
		m_ComponentMsgBox->ClearOutbox();
#endif
	}

	void CoreInputComponent::PreInit( unsigned int maxNumControllers )
	{
		m_ControllerArray.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumControllers );

		for( unsigned int i = 0; i < maxNumControllers; ++i)
		{
			m_ControllerArray.AddDefault();
			m_ControllerArray.LastItem().Init(i);
		}
	}

	void CoreInputComponent::OnUpdate()
	{
		HandleEvents();

		if (!m_pInputTranslator )
		{
			return;
		}

		for( unsigned int i = 0; i < m_ControllerArray.Count(); ++i)
		{
			IController* pController = m_ControllerArray[i].GetController();
			m_ControllerArray[i].Update();

			if(m_ControllerArray[i].IsConnected())
			{
				m_pInputTranslator->EnsureVirtualControllerMapped();

				IInputTranslator::TranslationList list;

				HandleDigitalButtons( i, pController, list );
				HandleAnalogButtons( i, pController, list );
				HandleAnalogSticks( i, pController, list );

				m_pInputTranslator->TranslateInput( i, list );

				m_pInputTranslator->Update(i, &mEventMan);
			}

			m_pInputTranslator->UpdateConnectionInfo(i, m_ControllerArray[i].IsConnected());
		}
		m_pInputTranslator->SendHomeInfo(&mEventMan);
		m_pInputTranslator->SendConnectionInfo(&mEventMan);
	}

	void CoreInputComponent::OnShutdown()
	{
		mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
	}

	void CoreInputComponent::HandleDigitalButtons( int controllerId, const IController* controller, IInputTranslator::TranslationList& list )
	{
		const int digitalButtonCount = controller->GetDigitalButtonCount();
		const IController::IControllerData* pPreviousControllerData = controller->GetPreviousControllerData();
		const IController::IControllerData* pCurrentControllerData = controller->GetCurrentControllerData();

		for (int digitalButtonIterator = 0; digitalButtonIterator < digitalButtonCount; ++digitalButtonIterator)
		{
			const Input::IController::DigitalButton* pPreviousButton = pPreviousControllerData->GetDigitalButton(digitalButtonIterator);
			const Input::IController::DigitalButton* pCurrentButton = pCurrentControllerData->GetDigitalButton(digitalButtonIterator);

			EButtonStates state = EButtonStates::Off;			

			//Refactor.
			//Should this be part of the core input component?
			if (pCurrentButton->m_ButtonState == 0)
			{
				if (pPreviousButton->m_ButtonState > 0)
				{
					state = EButtonStates::OnToOff;
				}
				else
				{
					state = EButtonStates::Off;
				}
			}
			else
			{
				if (pPreviousButton->m_ButtonState == 0)
				{
					state = EButtonStates::OffToOn;
				}
				else
				{
					state =  EButtonStates::On;
				}
			}

#if RANDOM_INPUT
			if(digitalButtonIterator==8)
			{
				// Avoiding opening the cheat code window
				state = EButtonStates::Off;
			}
			else
			{
				switch(rand()%4) 
				{
				case 0:
					state = EButtonStates::OnToOff;
					break;
				case 1:
					state = EButtonStates::OffToOn;
					break;
				case 2:
					state = EButtonStates::On;
					break;
				case 3:
					state = EButtonStates::Off;
					break;
				}
			}
#endif // RANDOM_INPUT

			//Only notify is state change
			if( IsStateChange( state ) )
			{
				list.Add( IInputTranslator::TranslatableItem( IInputTranslator::TranslatableItem::DigitalButton, pCurrentButton->m_ButtonID, state ) );
			}
		}
	}

	void CoreInputComponent::HandleAnalogButtons( int controllerId, const IController* controller, IInputTranslator::TranslationList& list )
	{
		const int analogButtonCount = controller->GetAnalogButtonCount();
		for (int analogButtonIterator = 0; analogButtonIterator < analogButtonCount; ++analogButtonIterator)
		{
			const Input::IController::AnalogButton* pCurrentButton = controller->GetCurrentControllerData()->GetAnalogButton(analogButtonIterator);
#if !RANDOM_INPUT
			const Axiom::Math::Vector3 vec( pCurrentButton->GetNormalizeState(), 0.0f, 0.0f );
#else // !RANDOM_INPUT
			const Axiom::Math::Vector3 vec( (rand()%201)/100.0f-1.0f, 0.0f, 0.0f);
#endif  // !RANDOM_INPUT
			list.Add( IInputTranslator::TranslatableItem( IInputTranslator::TranslatableItem::AnalogButton, pCurrentButton->m_ButtonID, vec ) );
		}
	}			

	void CoreInputComponent::HandleAnalogSticks( int controllerId, const IController* controller, IInputTranslator::TranslationList& list )
	{
		const int analogStickCount = controller->GetAnalogStickCount();
		for (int analogStickIterator = 0; analogStickIterator < analogStickCount; analogStickIterator++)
		{
#if !RANDOM_INPUT
			const Input::IController::AnalogStick* pCurStick = controller->GetCurrentControllerData()->GetAnalogStick(analogStickIterator);
			const Axiom::Math::Vector3 vec( pCurStick->GetNormalizeX(), pCurStick->GetNormalizeY(), pCurStick->GetNormalizeZ() );
#else // !RANDOM_INPUT
			const Axiom::Math::Vector3 vec( (rand()%201)/100.0f-1.0f, (rand()%201)/100.0f-1.0f, (rand()%201)/100.0f-1.0f);
#endif // !RANDOM_INPUT
			list.Add( IInputTranslator::TranslatableItem( IInputTranslator::TranslatableItem::AnalogStick, analogStickIterator, vec ) );
		}
	}

	void CoreInputComponent::HandleEvents()
	{
		const unsigned int numEvents = m_ComponentMsgBox->GetNumEvents();

		for ( unsigned int i = 0; i < numEvents; ++i)
		{
			const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

			if(pMsg->GetGuidID() == Events::InputChangeRumbleLevelEvent::EVENT_GUID)
			{
				OnInputRumbleChangeEvent(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputEnableRumbleEvent::EVENT_GUID)
			{
				OnInputEnableRumbleEvent(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputEnablePointerEvent::EVENT_GUID)
			{
				OnInputEnablePointer(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputEnableMotionPlusEvent::EVENT_GUID)
			{
				OnInputEnableMotionPlus(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputTareBalanceBoardEvent::EVENT_GUID)
			{
				OnInputTareBalanceBoard(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputTGCBalanceBoardEvent::EVENT_GUID)
			{
				OnInputTGCBalanceBoard(pMsg);
			}
			else if(pMsg->GetGuidID() == Events::InputZeroMotionPlusEvent::EVENT_GUID)
			{
				OnInputZeroMotionPlus(pMsg);
			}
		}

		m_ComponentMsgBox->ClearInbox();
	}

	void CoreInputComponent::OnInputRumbleChangeEvent(const Axiom::EventMsg* pMsg)
	{
		const Events::InputChangeRumbleLevelEvent* pRumbleEvent = pMsg->GetClass<Events::InputChangeRumbleLevelEvent>();
		AP_ASSERT(pRumbleEvent != NULL);
		
		if(VirtualControllerMap::GetInstance()->IsLocalVirtualControllerId(pRumbleEvent->mControllerIndex))
		{
			unsigned int controllerIndex = VirtualControllerMap::GetInstance()->GetControllerIdFromVirtualId(pRumbleEvent->mControllerIndex);
					
			ControllerInterface* pController = &m_ControllerArray[controllerIndex];
			if(pController)
			{
				CRumbleEffect rumbleEffect; 
				rumbleEffect.actuatorLevel = pRumbleEvent->mFirstActuator.actuatorLevel;
				rumbleEffect.rampUpTime = pRumbleEvent->mFirstActuator.rampUpTime;
				rumbleEffect.rampDownTime = pRumbleEvent->mFirstActuator.rampDownTime;
				rumbleEffect.repetitions = pRumbleEvent->mFirstActuator.repetitions;
				rumbleEffect.duration = pRumbleEvent->mFirstActuator.duration;
				rumbleEffect.timePassed = 0;

				pController->PlayRumbleEffect(0, rumbleEffect);

				rumbleEffect.actuatorLevel = pRumbleEvent->mSecondActuator.actuatorLevel;
				rumbleEffect.rampUpTime = pRumbleEvent->mSecondActuator.rampUpTime;
				rumbleEffect.rampDownTime = pRumbleEvent->mSecondActuator.rampDownTime;
				rumbleEffect.repetitions = pRumbleEvent->mSecondActuator.repetitions;
				rumbleEffect.duration = pRumbleEvent->mSecondActuator.duration;
				rumbleEffect.timePassed = 0;

				pController->PlayRumbleEffect(1, rumbleEffect);
			}
		}
	}

	void CoreInputComponent::OnInputEnableRumbleEvent(const Axiom::EventMsg* pMsg)
	{
		const Events::InputEnableRumbleEvent* pRumbleEvent = pMsg->GetClass<Events::InputEnableRumbleEvent>();

		if(VirtualControllerMap::GetInstance()->IsLocalVirtualControllerId(pRumbleEvent->mControllerIndex))
		{
			unsigned int controllerIndex = VirtualControllerMap::GetInstance()->GetControllerIdFromVirtualId(pRumbleEvent->mControllerIndex);
					
			ControllerInterface* pController = &m_ControllerArray[controllerIndex];
			if(pController)
			{
				pController->EnableRumble(pRumbleEvent->mEnable);
			}
		}
	}

	void CoreInputComponent::OnInputEnablePointer(const Axiom::EventMsg* pMsg)
	{
		const Events::InputEnablePointerEvent* pPointerEvent = pMsg->GetClass<Events::InputEnablePointerEvent>();

		if(VirtualControllerMap::GetInstance()->IsLocalVirtualControllerId(pPointerEvent->mControllerIndex))
		{
			unsigned int controllerIndex = VirtualControllerMap::GetInstance()->GetControllerIdFromVirtualId(pPointerEvent->mControllerIndex);
					
			ControllerInterface* pController = &m_ControllerArray[controllerIndex];
			if(pController)
			{
				pController->EnablePointer(pPointerEvent->mEnable);
			}
		}
	}

	void CoreInputComponent::OnInputEnableMotionPlus(const Axiom::EventMsg* pMsg)
	{
		const Events::InputEnableMotionPlusEvent* pMplsEvent = pMsg->GetClass<Events::InputEnableMotionPlusEvent>();

		if(VirtualControllerMap::GetInstance()->IsLocalVirtualControllerId(pMplsEvent->mControllerIndex))
		{
			unsigned int controllerIndex = VirtualControllerMap::GetInstance()->GetControllerIdFromVirtualId(pMplsEvent->mControllerIndex);
					
			ControllerInterface* pController = &m_ControllerArray[controllerIndex];
			if(pController)
			{
				pController->EnableMotionPlus(pMplsEvent->mEnable);
			}
		}
	}
	
	void CoreInputComponent::OnInputTareBalanceBoard(const Axiom::EventMsg* pMsg)
	{
		unsigned int controllerIndex = 3; //WBC is always controller index 3
        ControllerInterface* pController = &m_ControllerArray[controllerIndex];
		if(pController)
		{
			pController->TareBalanceBoard();
		}
	}

	void CoreInputComponent::OnInputTGCBalanceBoard(const Axiom::EventMsg* pMsg)
	{
		unsigned int controllerIndex = 3; //WBC is always controller index 3
        ControllerInterface* pController = &m_ControllerArray[controllerIndex];
		if(pController)
		{
			pController->TGCBalanceBoard();
		}
	}

	void CoreInputComponent::OnInputZeroMotionPlus(const Axiom::EventMsg* pMsg)
	{
		const Events::InputZeroMotionPlusEvent* pMplsEvent = pMsg->GetClass<Events::InputZeroMotionPlusEvent>();
		unsigned int controllerIndex = pMplsEvent->mControllerIndex;
        ControllerInterface* pController = &m_ControllerArray[controllerIndex];
		if(pController)
		{
			pController->ZeroMPLS();
		}
	}
}
}


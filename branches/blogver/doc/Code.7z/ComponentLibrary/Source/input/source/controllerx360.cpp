#include "input/icontroller.h"
#include "input/x360buttons.h"
#include "input/controllerfactory.h"
#include <math/apmath.h>

#include "xbox/xbox.h"
#include "xbox/xffb.h"

namespace AP
{
	namespace Input
	{
		static const int DEADZONELEFT = XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
		static const int DEADZONERIGHT = XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE;
		static const int MAX_ANALOG = 32767;
		static const int MIN_ANALOG = -32768;
		static const float MAX_ANALOG_BUTTON_VALUE = 255.f;

		static const int DPAD_UP          = 0x00000001;
		static const int DPAD_DOWN        = 0x00000002;
		static const int DPAD_LEFT        = 0x00000004;
		static const int DPAD_RIGHT       = 0x00000008;
		static const int START            = 0x00000010;
		static const int BACK             = 0x00000020;
		static const int LEFT_THUMB       = 0x00000040;
		static const int RIGHT_THUMB      = 0x00000080;
		static const int LEFT_SHOULDER    = 0x00000100;
		static const int RIGHT_SHOULDER   = 0x00000200;
		static const int A                = 0x00001000;
		static const int B                = 0x00002000;
		static const int X                = 0x00004000;
		static const int Y                = 0x00008000;

		static const int LEFT_TRIGGER     = 0x00010000;
		static const int RIGHT_TRIGGER    = 0x00020000;

		static const int MAX_RUMBLE		  = 65535;
		
		class ControllerX360: public IController
		{
			public:
				class ControllerData: public IControllerData
				{
					public:
						ControllerData();
						~ControllerData() {};

						ControllerData& operator=(const ControllerData& rightHandSide);

					protected:
						ControllerData(const ControllerData&);

					public:
						virtual const AnalogStick*		GetAnalogStick(const int index) const;
						virtual const AnalogButton*		GetAnalogButton(int index) const;
						virtual const DigitalButton*	GetDigitalButton(int index) const;
						virtual const Actuator*			GetActuator(int index) const;

					public:
						AnalogStick			m_AnalogSticks[EX360AnalogSticks::NumberOfItems];
						AnalogButton		m_AnalogButtons[EX360AnalogButtons::NumberOfItems];
						DigitalButton		m_DigitalButtons[EX360DigitalButtons::NumberOfItems];
						Actuator			m_Actuators[EX360Actuators::NumberOfItems];
				};

			public:
				ControllerX360(Axiom::Int32 id);

				virtual void Update();

				virtual int						GetAnalogStickCount() const;
				virtual int						GetAnalogButtonCount() const;
				virtual int						GetDigitalButtonCount() const;
				virtual int						GetActuatorCount() const;
				virtual bool					IsConnected()const{ return m_Connected;}
				virtual const IControllerData*	GetPreviousControllerData() const { return &m_PreviousControllerData; }
				virtual const IControllerData*	GetCurrentControllerData() const { return &m_CurrentControllerData; }

			private:
				float				GetNorm(float value, int deadzone);

				int					m_Id;
				
				ControllerData		m_PreviousControllerData;
				ControllerData		m_CurrentControllerData;
				bool				m_Connected;
		};

		ControllerX360::ControllerData::ControllerData()
		{
			m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonID			= DPAD_UP;
			m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonID			= DPAD_DOWN;
			m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonID			= DPAD_LEFT;
			m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonID			= DPAD_RIGHT;
			m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonID				= START;
			m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonID				= BACK;
			m_DigitalButtons[EX360DigitalButtons::LeftShoulder].m_ButtonID		= LEFT_SHOULDER;
			m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonID		= RIGHT_SHOULDER;
			m_DigitalButtons[EX360DigitalButtons::LeftThumb].m_ButtonID			= LEFT_THUMB;
			m_DigitalButtons[EX360DigitalButtons::RightThumb].m_ButtonID		= RIGHT_THUMB;
			m_DigitalButtons[EX360DigitalButtons::A].m_ButtonID					= A;
			m_DigitalButtons[EX360DigitalButtons::B].m_ButtonID					= B;
			m_DigitalButtons[EX360DigitalButtons::X].m_ButtonID					= X;
			m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonID					= Y;

			m_AnalogButtons[EX360AnalogButtons::LeftTrigger].m_ButtonID			= LEFT_TRIGGER;
			m_AnalogButtons[EX360AnalogButtons::RightTrigger].m_ButtonID		= RIGHT_TRIGGER;

			m_Actuators[EX360Actuators::LeftActuator].SetValue(0.f);
			m_Actuators[EX360Actuators::RightActuator].SetValue(0.f);
		}

		ControllerX360::ControllerData& ControllerX360::ControllerData::operator=(const ControllerData& rightHandSide)
		{
			m_AnalogSticks[EX360AnalogSticks::Left] = rightHandSide.m_AnalogSticks[EX360AnalogSticks::Left];
			m_AnalogSticks[EX360AnalogSticks::Right] = rightHandSide.m_AnalogSticks[EX360AnalogSticks::Right];

			m_DigitalButtons[EX360DigitalButtons::DPadUp]        = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadUp];
			m_DigitalButtons[EX360DigitalButtons::DPadDown]      = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadDown];
			m_DigitalButtons[EX360DigitalButtons::DPadLeft]      = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadLeft];
			m_DigitalButtons[EX360DigitalButtons::DPadRight]     = rightHandSide.m_DigitalButtons[EX360DigitalButtons::DPadRight];
			m_DigitalButtons[EX360DigitalButtons::Start]         = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Start];
			m_DigitalButtons[EX360DigitalButtons::Back]          = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Back];
			m_DigitalButtons[EX360DigitalButtons::LeftShoulder]  = rightHandSide.m_DigitalButtons[EX360DigitalButtons::LeftShoulder];
			m_DigitalButtons[EX360DigitalButtons::RightShoulder] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::RightShoulder];
			m_DigitalButtons[EX360DigitalButtons::LeftThumb]     = rightHandSide.m_DigitalButtons[EX360DigitalButtons::LeftThumb];
			m_DigitalButtons[EX360DigitalButtons::RightThumb]    = rightHandSide.m_DigitalButtons[EX360DigitalButtons::RightThumb];

			m_DigitalButtons[EX360DigitalButtons::A] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::A];
			m_DigitalButtons[EX360DigitalButtons::B] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::B];
			m_DigitalButtons[EX360DigitalButtons::X] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::X];
			m_DigitalButtons[EX360DigitalButtons::Y] = rightHandSide.m_DigitalButtons[EX360DigitalButtons::Y];

			m_AnalogButtons[EX360AnalogButtons::LeftTrigger] = rightHandSide.m_AnalogButtons[EX360AnalogButtons::LeftTrigger];
			m_AnalogButtons[EX360AnalogButtons::RightTrigger] = rightHandSide.m_AnalogButtons[EX360AnalogButtons::RightTrigger];

			m_Actuators[EX360Actuators::LeftActuator].SetValue(rightHandSide.m_Actuators[EX360Actuators::LeftActuator].GetMagnitude());	
			m_Actuators[EX360Actuators::RightActuator].SetValue(rightHandSide.m_Actuators[EX360Actuators::RightActuator].GetMagnitude());

			return *this;
		};

		const IController::AnalogStick* ControllerX360::ControllerData::GetAnalogStick(const int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360AnalogSticks::NumberOfItems, "ControllerData::GetAnalogStick - index out of range.");

			return &(m_AnalogSticks[index]);
		}

		const IController::AnalogButton* ControllerX360::ControllerData::GetAnalogButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360AnalogButtons::NumberOfItems, "ControllerData::GetAnalogButton - index out of range.");

			return &(m_AnalogButtons[index]);
		}

		const IController::DigitalButton* ControllerX360::ControllerData::GetDigitalButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360DigitalButtons::NumberOfItems, "ControllerData::GetDigitalButton - index out of range.");

			return &(m_DigitalButtons[index]);
		}

		const IController::Actuator* ControllerX360::ControllerData::GetActuator(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EX360Actuators::NumberOfItems, "ControllerData::GetActuator - index out of range.");

			return &(m_Actuators[index]);
		}

		ControllerX360::ControllerX360(Axiom::Int32 id)
			:	m_Id(id),
			m_Connected(false)
		{

		}

		// Return a value between -1 and +1
		float ControllerX360::GetNorm(float value, int deadzone)
		{
			const float one_over_max = 1.f/static_cast<float>(MAX_ANALOG - deadzone + 1);
			AP_ASSERT(value <= MAX_ANALOG);
			
			if(Axiom::Math::Fabs(value) <= deadzone)
				return 0.f;

			float newValue = (value<0)?value+deadzone:value-deadzone;

			newValue = newValue * one_over_max;
			AP_ASSERT(newValue>=-1.f && newValue<=1.f);
			return newValue;
		}

		void ControllerX360::Update()
		{
			m_PreviousControllerData = m_CurrentControllerData;

			XINPUT_STATE state;
			ZeroMemory( &state, sizeof(XINPUT_STATE) );

			// Simply get the state of the controller from XInput.
			DWORD dwResult = XInputGetState( m_Id, &state );

			if( dwResult == ERROR_SUCCESS )
			{ 
				//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].m_X							= GetNorm(state.Gamepad.sThumbLX, DEADZONELEFT);
				//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].m_Y							= GetNorm(state.Gamepad.sThumbLY, DEADZONELEFT);
				//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].m_X						= GetNorm(state.Gamepad.sThumbRX, DEADZONERIGHT);
				//m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].m_Y						= GetNorm(state.Gamepad.sThumbRY, DEADZONERIGHT);

				m_Connected = true;
				m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Left].SetValue(GetNorm(state.Gamepad.sThumbLX, DEADZONELEFT),GetNorm(state.Gamepad.sThumbLY, DEADZONELEFT));
				m_CurrentControllerData.m_AnalogSticks[EX360AnalogSticks::Right].SetValue(GetNorm(state.Gamepad.sThumbRX, DEADZONERIGHT),GetNorm(state.Gamepad.sThumbRY, DEADZONERIGHT));

				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadUp].m_ButtonState			= state.Gamepad.wButtons & DPAD_UP ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadDown].m_ButtonState		= state.Gamepad.wButtons & DPAD_DOWN ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadLeft].m_ButtonState		= state.Gamepad.wButtons & DPAD_LEFT ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::DPadRight].m_ButtonState		= state.Gamepad.wButtons & DPAD_RIGHT ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Start].m_ButtonState			= state.Gamepad.wButtons & START ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Back].m_ButtonState			= state.Gamepad.wButtons & BACK ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftShoulder].m_ButtonState	= state.Gamepad.wButtons & LEFT_SHOULDER ? 1: 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightShoulder].m_ButtonState	= state.Gamepad.wButtons & RIGHT_SHOULDER ? 1: 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::LeftThumb].m_ButtonState		= state.Gamepad.wButtons & LEFT_THUMB ? 1: 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::RightThumb].m_ButtonState		= state.Gamepad.wButtons & RIGHT_THUMB ? 1: 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::A].m_ButtonState				= state.Gamepad.wButtons & A ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::B].m_ButtonState				= state.Gamepad.wButtons & B ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::X].m_ButtonState				= state.Gamepad.wButtons & X ? 1 : 0;
				m_CurrentControllerData.m_DigitalButtons[EX360DigitalButtons::Y].m_ButtonState				= state.Gamepad.wButtons & Y ? 1 : 0;
				
				m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::LeftTrigger].SetValue(state.Gamepad.bLeftTrigger);
				m_CurrentControllerData.m_AnalogButtons[EX360AnalogButtons::RightTrigger].SetValue(state.Gamepad.bRightTrigger);
			}
			else
			{
				m_Connected = false;
			}

			//Actuator update
			XINPUT_VIBRATION vibrationStruct;
			float fMagnitude = m_CurrentControllerData.m_Actuators[EX360Actuators::LeftActuator].GetMagnitude();
			vibrationStruct.wLeftMotorSpeed = static_cast<WORD>(fMagnitude * MAX_RUMBLE);
			fMagnitude = m_CurrentControllerData.m_Actuators[EX360Actuators::RightActuator].GetMagnitude();
			vibrationStruct.wRightMotorSpeed = static_cast<WORD>(fMagnitude * MAX_RUMBLE);
			XInputSetState( m_Id, &vibrationStruct);
			
		}

		int ControllerX360::GetAnalogStickCount() const
		{
			return EX360AnalogSticks::NumberOfItems;
		}

		int ControllerX360::GetAnalogButtonCount() const
		{
			return EX360AnalogButtons::NumberOfItems;
		}

		int ControllerX360::GetDigitalButtonCount() const
		{
			return EX360DigitalButtons::NumberOfItems;
		}

		int ControllerX360::GetActuatorCount() const
		{
			return EX360Actuators::NumberOfItems;
		}


		IController* ControllerFactory::CreateController(int controllerID)
		{
			return AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerX360(controllerID));
		}
	}
}

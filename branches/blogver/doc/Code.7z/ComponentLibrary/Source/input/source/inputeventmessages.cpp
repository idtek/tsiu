#include <input/inputeventmessages.h>

namespace AP
{
	namespace Input
	{
		namespace Events
		{			
 			AP_TYPE(SynchAbleInputEvent)
 				AP_BASE_TYPE(Axiom::EventMsg)
 				AP_DEFAULT_CREATE()
 				AP_FIELD("ControllerId", mControllerId, "Virtual ID of the current Controller")
 				AP_FIELD("ControllerIndex", mControllerId, "Virtual ID of the current Controller")
				AP_PROXY("ComponentLibrary")
 			AP_TYPE_END()

			AP_TYPE(InputChangeRumbleLevelEvent)
				AP_BASE_TYPE(Axiom::EventMsg)
				AP_DEFAULT_CREATE()
				AP_FIELD("ControllerIndex",		mControllerIndex,	"The index of the Controller on which to play the effect")
				AP_FIELD("ControllerId",		mControllerIndex,	"The index of the Controller on which to play the effect")
				AP_FIELD("FirstActuator",		mFirstActuator,		"The level of the first actuator")
				AP_FIELD("SecondActuator",		mSecondActuator,	"The level of the second actuator")
				AP_PROXY("ComponentLibrary")
			AP_TYPE_END()

			AP_TYPE(RumbleChangeStruct)
				AP_DEFAULT_CREATE()
				AP_FIELD("rampUpTime",			rampUpTime,			"The time to ramp up the effect")
				AP_FIELD("rampDownTime",			rampDownTime,		"The time to ramp up the effect")
				AP_FIELD("repetitions",			repetitions,		"The number of times to repeat the effect")
				AP_FIELD("duration",				duration,			"The duration of time at max level")
				AP_FIELD("actuatorLevel",		actuatorLevel,		"The max level of the actuator")
				AP_PROXY("ComponentLibrary")
			AP_TYPE_END()

			AP_TYPE(InputEnableRumbleEvent)
				AP_BASE_TYPE(Axiom::EventMsg)
				AP_DEFAULT_CREATE()
				AP_FIELD("ControllerId",		mControllerIndex,	"The index of the Controller to disable rumble")
				AP_FIELD("Enable",				mEnable,			"Flag to enable/disable the controller's rumble")
				AP_PROXY("ComponentLibrary")
			AP_TYPE_END()
			
			AP_TYPE(InputEnableMotionPlusEvent)
				AP_BASE_TYPE(Axiom::EventMsg)
				AP_DEFAULT_CREATE()
				AP_FIELD("ControllerId",		mControllerIndex,	"The index of the Controller to disable Motion Plus")
				AP_FIELD("Enable",				mEnable,			"Flag to enable/disable the controller's Motion Plus")
				AP_PROXY("ComponentLibrary")
			AP_TYPE_END()

			AP_TYPE(InputZeroMotionPlusEvent)
				AP_BASE_TYPE(Axiom::EventMsg)
				AP_DEFAULT_CREATE()
				AP_FIELD("ControllerId",		mControllerIndex,	"The index of the Controller to Zero the Wii Motion Plus")
				AP_PROXY("ComponentLibrary")
			AP_TYPE_END()
		}
	}
}

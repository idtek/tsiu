#include "input/icontroller.h"
#include "input/controllerfactory.h"
#include "input/inputconst.h"
#include "input/wiibuttons.h"

#include <memory/apmemory.h>
#include <math/apmath.h>
#include <revolution/kpad.h>
#include <math/vector3.h>
#if CORE_SHIP
#define MONKEY_MASH CORE_NO
#else
#define MONKEY_MASH CORE_YES
#endif

#if MONKEY_MASH
#include <revolution/vi.h>
#include <core/random.h>
// Accessed from FE_Manager
bool use_monkey = false;
#endif

namespace AP
{
	namespace Input
	{
		static KPADStatus	s_LastRead[WPAD_MAX_CONTROLLERS];
		static int			s_ControllerState[WPAD_MAX_CONTROLLERS];
		static int			s_ConnectTimer[WPAD_MAX_CONTROLLERS];
		int					g_ExtensionTimer[WPAD_MAX_CONTROLLERS];
		bool				g_EnableMpls[WPAD_MAX_CONTROLLERS];
		bool				g_EnableDPD[WPAD_MAX_CONTROLLERS];
		bool				g_HasMotionPlus[WPAD_MAX_CONTROLLERS];
		bool				g_BalanceBoardLastBatteryLow = false;
		bool				g_BalanceBoardBatteryLow = false;

		enum ControllerState
		{
			CONT_NOT_CONNECTED,
			CONT_JUST_CONNECTED,
			CONT_DETECTING_EXTENSION,
			CONT_CONNECTED
		};

		void MplsCallback(s32 chan, s32 reason)
		{
			if(reason == KPAD_STATE_CTRL_MPLS_FINISHED)
			{
				KPADResetMpls(chan);
				KPADEnableMplsAccRevise(chan);
				KPADEnableMplsDpdRevise(chan);
			}
			else if(reason != KPAD_STATE_CTRL_MPLS_START)
			{
				KPADDisableMpls(chan);
			}
		}

		void EnableMPLS(s32 chan)
		{
			if(g_EnableMpls[chan] && KPADGetMplsStatus(chan) == WPAD_MPLS_OFF)
			{
				KPADEnableMpls(chan, WPAD_MPLS_FS);
			}
		}
		
		void ExtensionCallback(s32 chan, s32 result)
		{
			g_ExtensionTimer[chan] = 45; //wait 5 frames before accepting new data.
			switch(result)
			{
				case WPAD_DEV_NOT_FOUND:
					s_ControllerState[chan] = CONT_NOT_CONNECTED;
					break;
				case WPAD_DEV_BALANCE_CHECKER:
					break;
				case WPAD_DEV_UNKNOWN: //controller is detecting extension
					if(s_ControllerState[chan] == CONT_JUST_CONNECTED)
					{
						s_ControllerState[chan] = CONT_DETECTING_EXTENSION;
					}
					break;
				default:
					EnableMPLS(chan);
					if(g_EnableDPD[chan])
					{
						KPADEnableDPD(chan);
					}
					s_ControllerState[chan] = CONT_CONNECTED;
					break;
		
			} // End
		}

		void ConnectCallback(s32 chan, s32 reason)
		{
			u32 type;
			if (reason != WPAD_ERR_NO_CONTROLLER)
			{
				switch(chan)
				{
				//channels 1 and 2 are valid.
				case WPAD_CHAN0:
				case WPAD_CHAN1:
					KPADSetControlMplsCallback( chan, MplsCallback );
					WPADSetExtensionCallback(chan, ExtensionCallback);
					s_ControllerState[chan] = CONT_JUST_CONNECTED;
					s_ConnectTimer[chan] = 2;
					break;
				//channel 2 is unused
				case WPAD_CHAN2:
					WPADDisconnect(chan);
					WPADStopMotor(chan);
					s_ControllerState[chan] = CONT_NOT_CONNECTED;
					return;
				//channel 3 is reserved for the balance board
				case WPAD_CHAN3:
					WPADProbe(chan, &type);
					if(type != WPAD_DEV_BALANCE_CHECKER)
					{
						WPADDisconnect(chan);
						WPADStopMotor(chan);
						s_ControllerState[chan] = CONT_NOT_CONNECTED;
						break;
					}
					s_ControllerState[chan] = CONT_CONNECTED;
					WPADSetExtensionCallback(chan, ExtensionCallback);
					break;
				default:
					WPADDisconnect(chan);
					WPADStopMotor(chan);
					break;
				}
			}
			else
			{
				s_ControllerState[chan] = CONT_NOT_CONNECTED;
			}
		}


	
		static const int DEADZONELEFT = 0x20;
		static const int DEADZONERIGHT = 0x20;
		static const int MAX_ANALOG = 0xFF;
		static const int MIN_ANALOG = 0;
/*
	ANALOG2AXIS1		NUNCHUKSTICK
	ANALOG2AXIS2		POINTER
	ANALOG2AXIS3		WIIMOTESWING
	ANALOG3AXIS1		WIIMOTEACCEL
	ANALOG3AXIS2		NUNCHUKACCEL
	ANALOG4AXIS1		MPLSANGLES
	ANALOG4AXIS2		MPLSVELOCITY
	DIGITALBUTTON01		DPADUP
	DIGITALBUTTON02		DPADDOWN
	DIGITALBUTTON03		DPADLEFT
	DIGITALBUTTON04		DPADRIGHT
	DIGITALBUTTON05		NONE
	DIGITALBUTTON06		HOME
	DIGITALBUTTON07		B1
	DIGITALBUTTON08		B2
	DIGITALBUTTON09		C
	DIGITALBUTTON10		Z
	DIGITALBUTTON11		A
	DIGITALBUTTON12		B
	DIGITALBUTTON13		PLUS
	DIGITALBUTTON14		MINUS
	DIGITALBUTTON15		GESTURE1
	DIGITALBUTTON16		GESTURE2
	DIGITALBUTTON17		GESTURE3
	DIGITALBUTTON18		MPLSCALIBRATED
	DIGITALBUTTON19		LOWBATT
	DIGITALBUTTON20		HASMOTIONPLUS
	DIGITALBUTTON21		HASNUNCHUK

	ANALOGBUTTON01		WEIGHTFR
	ANALOGBUTTON02		WEIGHTBR
	ANALOGBUTTON03		WEIGHTFL
	ANALOGBUTTON04		WEIGHTBL
	ANALOGBUTTON05		WEIGHTAVEFR
	ANALOGBUTTON06		WEIGHTAVEBR
	ANALOGBUTTON07		WEIGHTAVEFL
	ANALOGBUTTON08		WEIGHTAVEBL
	ANALOGBUTTON09		WEIGHTTGC
*/
		static const int DIGITALBUTTON01          	= 0x00000001;	// TODO: That has to be exposed somehow...
		static const int DIGITALBUTTON02        	= 0x00000002;
		static const int DIGITALBUTTON03        	= 0x00000004;
		static const int DIGITALBUTTON04		  	= 0x00000008;
		static const int DIGITALBUTTON05          	= 0x00000010;
		static const int DIGITALBUTTON06           	= 0x00000020;
		static const int DIGITALBUTTON07    	   	= 0x00000040;
		static const int DIGITALBUTTON08   		   	= 0x00000080;
		static const int DIGITALBUTTON09   		 	= 0x00000100;
		static const int DIGITALBUTTON10   			= 0x00000200;
		static const int DIGITALBUTTON11           	= 0x00001000;
		static const int DIGITALBUTTON12           	= 0x00002000;
		static const int DIGITALBUTTON13           	= 0x00004000;
		static const int DIGITALBUTTON14          	= 0x00008000;
		static const int DIGITALBUTTON15			= 0x00010000;
		static const int DIGITALBUTTON16			= 0x00020000;
		static const int DIGITALBUTTON17			= 0x00040000;
		static const int DIGITALBUTTON18			= 0x00080000;
		static const int DIGITALBUTTON19			= 0x00100000;
		static const int DIGITALBUTTON20			= 0x00200000;
		static const int DIGITALBUTTON21			= 0x00400000;

		static const int ANALOGBUTTON01				= 0x00800000;
		static const int ANALOGBUTTON02				= 0x01000000;
		static const int ANALOGBUTTON03				= 0x02000000;
		static const int ANALOGBUTTON04				= 0x04000000;
		static const int ANALOGBUTTON05				= 0x08000000;
		static const int ANALOGBUTTON06				= 0x10000000;
		static const int ANALOGBUTTON07				= 0x20000000;
		static const int ANALOGBUTTON08				= 0x40000000;
		static const int ANALOGBUTTON09				= 0x80000000;

		static const int ANALOG2AXIS1			= 0;		// TODO: That has to be exposed somehow...
		static const int ANALOG2AXIS2			= 1;
		static const int ANALOG3AXIS1			= 2;
		static const int ANALOG3AXIS2			= 3;
		static const int ANALOG4AXIS1			= 4;
		static const int ANALOG4AXIS2			= 5;

		// (Nobu) This class focused on the response. 
		// It is about 0.1 sec faster than the response of the past version class AccelerometerToSwinging4Ways.
		// If you want to get the analog direction, see it in the old revision on 3/20/2009.

		class AccelerometerToSwinging4Ways
		{
			public:
				AccelerometerToSwinging4Ways();
				virtual ~AccelerometerToSwinging4Ways();
				void UpdateSwingingDirection( const KPADStatus* kpads, int kpad_reads, Axiom::Math::Vector2& dir );
				float GetMixedAccX(const KPADStatus* kpad) const;
				float GetMixedAccY(const KPADStatus* kpad) const;
				float CalcMixedAcc(float a, float b) const;
			
			private:
				enum  { DT = 5 };
				enum  { IGNORE_INPUT_DURATION = 30 };
				
				float	last_kpad_x[DT];
				float	last_kpad_y[DT];
				int		ignore_input_time;
		};
		
		AccelerometerToSwinging4Ways::AccelerometerToSwinging4Ways()
		{
			for(int i=0;i<DT;i++)
			{
				last_kpad_x[i] = 0.0f;
				last_kpad_y[i] = 0.0f;
			}
			ignore_input_time = 0;
		}

		AccelerometerToSwinging4Ways::~AccelerometerToSwinging4Ways()
		{
		}
		
		float AccelerometerToSwinging4Ways::GetMixedAccX(const KPADStatus* kpad) const
		{
			return CalcMixedAcc(kpad->acc.x, kpad->ex_status.fs.acc.x);
		}

		float AccelerometerToSwinging4Ways::GetMixedAccY(const KPADStatus* kpad) const
		{
			return CalcMixedAcc(kpad->acc.y, kpad->ex_status.fs.acc.y);
		}
		
		float AccelerometerToSwinging4Ways::CalcMixedAcc(float a, float b) const
		{
			float rate;
			float abs_sum_a_b = Axiom::Math::Fabs(a) + Axiom::Math::Fabs(b);
			if ( abs_sum_a_b < 0.001f)
			{
				rate = 0.5f;	// Any number is possible.
			}
			else
			{
				rate = Axiom::Math::Fabs(a)/ abs_sum_a_b;
			}
			AP_ASSERT( 0.0f<=rate && rate<=1.0f );

			const float ret = a * rate + b * (1.0f-rate);
			return ret;
		}
	
		
		void AccelerometerToSwinging4Ways::UpdateSwingingDirection( const KPADStatus* kpads, int kpad_reads, Axiom::Math::Vector2& dir )
		{
			dir.Set(0.0f,0.0f);
			
			if(ignore_input_time<=0)
			{
				const static float VX_THRESHOLD  = 0.25f;
				const static float VY_THRESHOLD  = 0.20f;
				
				for(int i=kpad_reads-1;i>=0;i--)
				{
					float kpad_vx = 0.0f;
					float kpad_vy = 0.0f;
					
					if(i+DT>kpad_reads-1)
					{
						kpad_vx = (GetMixedAccX(&kpads[i])-last_kpad_x[i+DT-kpad_reads])/DT;
						kpad_vy = (GetMixedAccY(&kpads[i])-last_kpad_y[i+DT-kpad_reads])/DT;
					}
					else
					{
						kpad_vx = (GetMixedAccX(&kpads[i])-GetMixedAccX(&kpads[i+DT]))/DT;
						kpad_vy = (GetMixedAccY(&kpads[i])-GetMixedAccY(&kpads[i+DT]))/DT;
					}
			
					if(kpad_vy>VY_THRESHOLD) 
					{
						// down
						dir.Set(0.0f,-1.0f);
						ignore_input_time = IGNORE_INPUT_DURATION;
						break;
					}
					else if (kpad_vy<-VY_THRESHOLD)
					{
						// up
						dir.Set(0.0f,1.0f);
						ignore_input_time = IGNORE_INPUT_DURATION;
						break;
					}
					else if (kpad_vx>VX_THRESHOLD)
					{
						// right
						dir.Set(-1.0f,0.0f);
						ignore_input_time = IGNORE_INPUT_DURATION;
						break;
					}
					else if (kpad_vx<-VX_THRESHOLD)
					{
						// left
						dir.Set(1.0f,0.0f);
						ignore_input_time = IGNORE_INPUT_DURATION;
						break;
					}
				}
			}
			else
			{
				ignore_input_time--;
			}
			
			for(int i=0;i<DT;i++)
			{
				if(i<kpad_reads)
				{
					last_kpad_x[i] = GetMixedAccX(&kpads[i]);
					last_kpad_y[i] = GetMixedAccY(&kpads[i]);
				}
				else if (kpad_reads>=1)
				{
					last_kpad_x[i] = GetMixedAccX(&kpads[kpad_reads-1]);
					last_kpad_y[i] = GetMixedAccY(&kpads[kpad_reads-1]);
				}
			}
		}

		class ControllerWII: public IController
		{
			public:
				class ControllerData: public IControllerData
				{
					public:
						ControllerData();
						~ControllerData() {}

						ControllerData& operator=(const ControllerData& rightHandSide);

					protected:
						ControllerData(const ControllerData&);

					public:
						virtual const AnalogStick*		GetAnalogStick(const int index) const;
						virtual const AnalogButton*		GetAnalogButton(int index) const;
						virtual const DigitalButton*	GetDigitalButton(int index) const;
						virtual const Actuator*			GetActuator(int index) const;

					public:
						// For simplicity we treat all analogue sticks as 3 axis.
						AnalogStick3		m_AnalogSticks[EWiiAnalogSticks::NumberOfItems];
						AnalogButton		m_AnalogButtons[EWiiAnalogButtons::NumberOfItems];
						DigitalButton		m_DigitalButtons[EWiiDigitalButtons::NumberOfItems];
						Actuator			m_Actuators[EWiiActuators::NumberOfItems];
				};

			public:
				ControllerWII(Axiom::Int32 id);

				virtual void Update();

				virtual int						GetAnalogStickCount() const;
				virtual int						GetAnalogButtonCount() const;
				virtual int						GetDigitalButtonCount() const;
				virtual int						GetActuatorCount() const;

				virtual const IControllerData*	GetPreviousControllerData() const { return &m_PreviousControllerData; }
				virtual const IControllerData*	GetCurrentControllerData() const { return &m_CurrentControllerData; }
				virtual bool					IsConnected()const{ return m_Connected;}

				virtual void					EnablePointer( bool enable );
				virtual void					EnableMotionPlus( bool enable );
				virtual void					TareBalanceBoard();
				virtual void					TGCBalanceBoard();
				virtual void					ZeroMPLS();
			private:
				float							GetNorm(float value, int deadzone);

				int					m_Id;		// Controller ID
				OSTime				m_TimeLeftBoard; //used for detecting jumping
				
				ControllerData		m_PreviousControllerData;
				ControllerData		m_CurrentControllerData;
				AccelerometerToSwinging4Ways	m_AccelerometerToSwinging4Ways;

				bool				m_Connected;
				bool				m_EnableMpls;
		};

		ControllerWII::ControllerData::ControllerData()
		{

			m_DigitalButtons[EWiiDigitalButtons::DPadUp].m_ButtonID		= DIGITALBUTTON01;
			m_DigitalButtons[EWiiDigitalButtons::DPadDown].m_ButtonID	= DIGITALBUTTON02;
			m_DigitalButtons[EWiiDigitalButtons::DPadLeft].m_ButtonID	= DIGITALBUTTON03;
			m_DigitalButtons[EWiiDigitalButtons::DPadRight].m_ButtonID	= DIGITALBUTTON04;
			m_DigitalButtons[EWiiDigitalButtons::Plus].m_ButtonID		= DIGITALBUTTON13;
			m_DigitalButtons[EWiiDigitalButtons::Minus].m_ButtonID		= DIGITALBUTTON14;
			m_DigitalButtons[EWiiDigitalButtons::ButtonHome].m_ButtonID = DIGITALBUTTON06;
			m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonID = DIGITALBUTTON21;
			m_DigitalButtons[EWiiDigitalButtons::ButtonA].m_ButtonID	= DIGITALBUTTON11;
			m_DigitalButtons[EWiiDigitalButtons::ButtonB].m_ButtonID	= DIGITALBUTTON12;
			m_DigitalButtons[EWiiDigitalButtons::Button1].m_ButtonID	= DIGITALBUTTON07;
			m_DigitalButtons[EWiiDigitalButtons::Button2].m_ButtonID	= DIGITALBUTTON08;
			m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonID	= DIGITALBUTTON09;
			m_DigitalButtons[EWiiDigitalButtons::ButtonZ].m_ButtonID	= DIGITALBUTTON10;
			m_DigitalButtons[EWiiDigitalButtons::MPLSCalibrated].m_ButtonID	= DIGITALBUTTON18;
			m_DigitalButtons[EWiiDigitalButtons::LowBatt].m_ButtonID	= DIGITALBUTTON19;
			m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus].m_ButtonID	= DIGITALBUTTON20;

			m_AnalogButtons[EWiiAnalogButtons::WeightFR].m_ButtonID		= ANALOGBUTTON01;
			m_AnalogButtons[EWiiAnalogButtons::WeightBR].m_ButtonID		= ANALOGBUTTON02;
			m_AnalogButtons[EWiiAnalogButtons::WeightFL].m_ButtonID		= ANALOGBUTTON03;
			m_AnalogButtons[EWiiAnalogButtons::WeightBL].m_ButtonID		= ANALOGBUTTON04;
			m_AnalogButtons[EWiiAnalogButtons::WeightAveFR].m_ButtonID	= ANALOGBUTTON05;
			m_AnalogButtons[EWiiAnalogButtons::WeightAveBR].m_ButtonID	= ANALOGBUTTON06;
			m_AnalogButtons[EWiiAnalogButtons::WeightAveFL].m_ButtonID	= ANALOGBUTTON07;
			m_AnalogButtons[EWiiAnalogButtons::WeightAveBL].m_ButtonID	= ANALOGBUTTON08;
			m_AnalogButtons[EWiiAnalogButtons::WeightTGC].m_ButtonID	= ANALOGBUTTON09;
			
			m_Actuators[EWiiActuators::Vibrate].SetValue(0.f);
			m_Actuators[EWiiActuators::Sound].SetValue(0.f);
		}

		ControllerWII::ControllerData& ControllerWII::ControllerData::operator=(const ControllerData& rightHandSide)
		{
			m_AnalogSticks[EWiiAnalogSticks::NunchuckStick]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::NunchuckStick];
			m_AnalogSticks[EWiiAnalogSticks::Pointer]		= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::Pointer];
			m_AnalogSticks[EWiiAnalogSticks::WiimoteSwing]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::WiimoteSwing];
			m_AnalogSticks[EWiiAnalogSticks::WiimoteAccel]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::WiimoteAccel];
			m_AnalogSticks[EWiiAnalogSticks::NunchukAccel]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::NunchukAccel];
			m_AnalogSticks[EWiiAnalogSticks::MplsAngles]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::MplsAngles];
			m_AnalogSticks[EWiiAnalogSticks::MplsVelocity]	= rightHandSide.m_AnalogSticks[EWiiAnalogSticks::MplsVelocity];

			m_DigitalButtons[EWiiDigitalButtons::DPadUp] 	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::DPadUp];
			m_DigitalButtons[EWiiDigitalButtons::DPadDown]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::DPadDown];
			m_DigitalButtons[EWiiDigitalButtons::DPadLeft]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::DPadLeft];
			m_DigitalButtons[EWiiDigitalButtons::DPadRight]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::DPadRight];
			m_DigitalButtons[EWiiDigitalButtons::Plus]		= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::Plus];
			m_DigitalButtons[EWiiDigitalButtons::Minus]		= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::Minus];
			m_DigitalButtons[EWiiDigitalButtons::ButtonHome]= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::ButtonHome];
			m_DigitalButtons[EWiiDigitalButtons::HasNunchuk]= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk];
			m_DigitalButtons[EWiiDigitalButtons::ButtonA]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::ButtonA];
			m_DigitalButtons[EWiiDigitalButtons::ButtonB]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::ButtonB];
			m_DigitalButtons[EWiiDigitalButtons::Button1]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::Button1];
			m_DigitalButtons[EWiiDigitalButtons::Button2]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::Button2];
			m_DigitalButtons[EWiiDigitalButtons::ButtonC]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::ButtonC];
			m_DigitalButtons[EWiiDigitalButtons::ButtonZ]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::ButtonZ];
			m_DigitalButtons[EWiiDigitalButtons::LowBatt]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::LowBatt];
			m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus]	= rightHandSide.m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus];
			m_DigitalButtons[EWiiDigitalButtons::MPLSCalibrated] = rightHandSide.m_DigitalButtons[EWiiDigitalButtons::MPLSCalibrated];

			m_AnalogButtons[EWiiAnalogButtons::WeightFR]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightFR];
			m_AnalogButtons[EWiiAnalogButtons::WeightBR]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightBR];
			m_AnalogButtons[EWiiAnalogButtons::WeightFL]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightFL];
			m_AnalogButtons[EWiiAnalogButtons::WeightBL]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightBL];
			m_AnalogButtons[EWiiAnalogButtons::WeightAveFR]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightAveFR];
			m_AnalogButtons[EWiiAnalogButtons::WeightAveBR]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightAveBR];
			m_AnalogButtons[EWiiAnalogButtons::WeightAveFL]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightAveFL];
			m_AnalogButtons[EWiiAnalogButtons::WeightAveBL]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightAveBL];
			m_AnalogButtons[EWiiAnalogButtons::WeightTGC]	= rightHandSide.m_AnalogButtons[EWiiAnalogButtons::WeightTGC];

			m_Actuators[EWiiActuators::Vibrate].SetValue(rightHandSide.m_Actuators[EWiiActuators::Vibrate].GetMagnitude());
			m_Actuators[EWiiActuators::Sound].SetValue(rightHandSide.m_Actuators[EWiiActuators::Sound].GetMagnitude());

			return *this;
		};

		const IController::AnalogStick* ControllerWII::ControllerData::GetAnalogStick(const int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EWiiAnalogSticks::NumberOfItems, "ControllerData::GetAnalogStick - index out of range.");

			return &(m_AnalogSticks[index]);
		}

		const IController::AnalogButton* ControllerWII::ControllerData::GetAnalogButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EWiiAnalogButtons::NumberOfItems, "ControllerData::GetAnalogButton - index out of range.");
			return &(m_AnalogButtons[index]);
			
			return NULL;
		}

		const IController::DigitalButton* ControllerWII::ControllerData::GetDigitalButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EWiiDigitalButtons::NumberOfItems, "ControllerData::GetDigitalButton - index out of range.");

			return &(m_DigitalButtons[index]);
		}

		const IController::Actuator* ControllerWII::ControllerData::GetActuator(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EWiiActuators::NumberOfItems, "ControllerData::GetActuator - index out of range.");

			return &(m_Actuators[index]);
		}

		ControllerWII::ControllerWII(int id)
			: m_Id(id)
			, m_Connected(false)
		{
			KPADSetConnectCallback(id, ConnectCallback);
			g_EnableMpls[m_Id] = true;
			g_EnableDPD[m_Id] = false;
			g_ExtensionTimer[m_Id] = 0;

			//the connect callback doesn't seem to be called at the beginning of the game.
			u32 type;
			s32 status = WPADProbe( m_Id, &type );
			ConnectCallback(id, status);
			ExtensionCallback(id, type);
			EnableMPLS(id);
			m_TimeLeftBoard = 0;

	  		//same as the system menu
			KPADSetPosParam( id, 0.05f, 1.0f );
		}

		void ControllerWII::Update()
		{
			m_PreviousControllerData = m_CurrentControllerData;
			if(m_Id == 3)
			{
				g_BalanceBoardLastBatteryLow = g_BalanceBoardBatteryLow;
				g_BalanceBoardBatteryLow = 0;
			}
			
			KPADStatus platformInfo[KPAD_MAX_READ_BUFS];
			int reads = KPADRead( m_Id, platformInfo, KPAD_MAX_READ_BUFS );

			//caches the last good read
			for(int i = 0; i < reads; i++)
			{
				if(platformInfo[i].wpad_err == WPAD_ERR_NONE)
				{
					s_LastRead[m_Id] = platformInfo[i];
					break;
				}
			}
			platformInfo[0] = s_LastRead[m_Id];
			m_Connected = s_ControllerState[m_Id] == CONT_CONNECTED;
			if(s_ControllerState[m_Id] == CONT_JUST_CONNECTED)
			{
				//this gives the extension callback time to fire
				if(s_ConnectTimer[m_Id] > 0)
				{
					s_ConnectTimer[m_Id]--;
				}
				if(s_ConnectTimer[m_Id] == 0)
				{
					s_ControllerState[m_Id] = CONT_CONNECTED;
				}
			}

			//in extraordinarily rare cases, the controller could be stuck in detecting extension, because
			//the callbacks are occasionally fired manually, and WPADProbe is not reliable.
			if(s_ControllerState[m_Id] == CONT_DETECTING_EXTENSION)
			{
				if(platformInfo[0].dev_type != WPAD_DEV_UNKNOWN)
				{
					s_ControllerState[m_Id] = CONT_CONNECTED;
				}
			}

			//extension controller information is unreliable for a period after connecting them.
			if(g_ExtensionTimer[m_Id] > 0)
			{
				g_ExtensionTimer[m_Id]--;
			}

			//POPULATE CONTROLLER INFORMATION
			if(m_Connected)
			{
				//this is a failsafe, in case the balance board comes in here and it's not ready yet.
				if(m_Id == 3 && platformInfo[0].dev_type != WPAD_DEV_BALANCE_CHECKER)
				{
					m_Connected = false;
					return;
				}
				
				//WII BALANCE BOARD INFORMATION
				if(platformInfo[0].dev_type == WPAD_DEV_BALANCE_CHECKER )
				{
					//KPAD only returns 1 error code.  We need to do this to get accurate information
					//about whether someone is standing on the board or not.
					double weight[4];
					KPADUnifiedWpadStatus kpad_status;
					KPADGetUnifiedWpadStatus( m_Id, &kpad_status, 1 );
					int exists = WBCRead(&kpad_status.u.bl, weight, 4);
					
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightFR].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightBR].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightFL].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightBL].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveFR].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveBR].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveFL].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveBL].SetValue(0);
					m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightTGC].SetValue(platformInfo[0].ex_status.bl.tgc_weight);
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState  = 1;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState	= (exists == 1);
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button1].m_ButtonState	= platformInfo[0].ex_status.bl.weight_err == KPAD_WBC_ERR_SETUP;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button2].m_ButtonState	= platformInfo[0].ex_status.bl.tgc_weight_err;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::LowBatt].m_ButtonState = platformInfo[0].ex_status.bl.weight_err == KPAD_WBC_ERR_NO_BATTERY;
					g_BalanceBoardBatteryLow = platformInfo[0].ex_status.bl.weight_err == KPAD_WBC_ERR_NO_BATTERY;

					if(	m_PreviousControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState == 1 &&
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState == 0 )
					{
						m_TimeLeftBoard = OSGetTime();
					}
					
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus].m_ButtonState = 0;
					
					if( platformInfo[0].ex_status.bl.weight_err == KPAD_WBC_ERR_EXIST || platformInfo[0].ex_status.bl.weight_err == KPAD_WBC_ERR_NONE )
					{
						double w1,w2,w3,w4;
						double left,right,front,back;
                        double total;
						float x, y;

						w1 = platformInfo[0].ex_status.bl.weight[0];
						w2 = platformInfo[0].ex_status.bl.weight[1];
						w3 = platformInfo[0].ex_status.bl.weight[2];
						w4 = platformInfo[0].ex_status.bl.weight[3];

						left  = (w3 + w4);
						right = (w1 + w2);
						front = (w1 + w3);
						back  = (w4 + w2);
                        total = Axiom::Math::Max( 1.0, w1 + w2 + w3 + w4 );

						// Calculate a balance point.
						x = (right - left) / total;
						y = (front - back) / total;

						x = Axiom::Math::Clamp(x, -1.0f, 1.0f);
						y = Axiom::Math::Clamp(y, -1.0f, 1.0f);

						// checks for jumping
						// this uses raw time values, as we want the precise time for the jump, not the frame time, which could be out of synch or imprecise
						m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus].m_ButtonState = 0;
						if(	m_PreviousControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState == 0 &&
							m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState == 1 )
						{
							OSTime now = OSGetTime();
							OSTime diff = now - m_TimeLeftBoard;
							if(OSTicksToMilliseconds(diff) < 500 && total > 20.0f)
							{
								m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus].m_ButtonState = 1;
							}
						}

						m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::NunchuckStick].SetValue(x, y);
						
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightFR].SetValue(w1);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightBR].SetValue(w2);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightFL].SetValue(w3);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightBL].SetValue(w4);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveFR].SetValue(platformInfo[0].ex_status.bl.weight_ave[0]);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveBR].SetValue(platformInfo[0].ex_status.bl.weight_ave[1]);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveFL].SetValue(platformInfo[0].ex_status.bl.weight_ave[2]);
						m_CurrentControllerData.m_AnalogButtons[EWiiAnalogButtons::WeightAveBL].SetValue(platformInfo[0].ex_status.bl.weight_ave[3]);
					}
					return;
				}

				//NUNCHUK INFORMATION
				if(platformInfo[0].dev_type == WPAD_DEV_FREESTYLE || platformInfo[0].dev_type == WPAD_DEV_MPLS_FREESTYLE)
				{
					const float x = platformInfo[0].ex_status.fs.stick.x;
					const float y = platformInfo[0].ex_status.fs.stick.y;

					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::NunchuckStick].SetValue(x, y);
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_C;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonZ].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_Z;
				}

				//WII REMOTE ACCELEROMETER INFORMATION
				//the order and sign of these are changed to ensure compatibility with old WPAD code.
				{
					const float div = 3.4f;
					const float accX = Axiom::Math::Clamp((-platformInfo[0].acc.x / div), -1.0f, 1.0f);
					const float accY = Axiom::Math::Clamp(( platformInfo[0].acc.z / div), -1.0f, 1.0f);
					const float accZ = Axiom::Math::Clamp((-platformInfo[0].acc.y / div), -1.0f, 1.0f);
						
					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::WiimoteAccel].SetValue(accX, accY, accZ);
				}

				//WII REMOTE SWING DIRECTION INFORMATION
				{
					// Set the swinging data to mAnalogPos
					Axiom::Math::Vector2 swinging_dir;
					
					m_AccelerometerToSwinging4Ways.UpdateSwingingDirection(platformInfo, reads, swinging_dir);
					
					if(!swinging_dir.IsZero())
					{
						swinging_dir.Normalize();
					}
					// Normalize() uses sqrt ( is low accuracy ), so the vector need to be clamped.
					swinging_dir.X(Axiom::Math::Clamp(-swinging_dir.X(), -1.0f, 1.0f)); // - is necessary. The X+ of the stick is right.
					swinging_dir.Y(Axiom::Math::Clamp(swinging_dir.Y(), -1.0f, 1.0f));  // The Y+ of the stick is up.

					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::WiimoteSwing].SetValue(swinging_dir.X(), swinging_dir.Y(), 0.0f);
				}

				//WII REMOTE MOTION PLUS INFORMATION
				if((platformInfo[0].dev_type == WPAD_DEV_MPLS_FREESTYLE) && (KPADGetMplsStatus(m_Id) != WPAD_MPLS_OFF))
				{
					volatile float cal = KPADWorkMplsCalibration( m_Id );
					KPADMPStatus data = platformInfo[0].mpls;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::MPLSCalibrated].m_ButtonState = (cal < 0);

					//Velocity
					{
						const float div = Axiom::Math::PI;

						const float x = Axiom::Math::Clamp(data.mpls.x/div, -1.0f, 1.0f);
						const float y = Axiom::Math::Clamp(data.mpls.y/div, -1.0f, 1.0f);
						const float z = Axiom::Math::Clamp(data.mpls.z/div, -1.0f, 1.0f);

						m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::MplsVelocity].SetValue(x, y, z);
					}
					
					//Angles
					{
						const float div = Axiom::Math::PI;
						
						const float y = atan2f(data.dir.Z.x, data.dir.Z.z); 
						const float p = atan2f(data.dir.Z.y, Axiom::Math::SquareRoot(pow(data.dir.Z.x, 2) + pow(data.dir.Z.z, 2)));
						const float r = atan2f(data.dir.Y.x, data.dir.Y.y);

						m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::MplsAngles].SetValue(y/div, p/div, r/div);
					}
				}
				else
				{
					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::MplsAngles].SetValue(0.0f, 0.0f, 0.0f);
					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::MplsVelocity].SetValue(0.0f, 0.0f, 0.0f);
				}

				//WII REMOTE POINTER INFORMATION
				if( platformInfo[0].dpd_valid_fg > 0 )
				{
					float x = Axiom::Math::Clamp(-platformInfo[0].pos.x, -1.0f, 1.0f);
					float y = Axiom::Math::Clamp(-platformInfo[0].pos.y, -1.0f, 1.0f);

					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::Pointer].SetValue(x, y);
				}
				else
				{
					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::Pointer].SetValue(-1.0f, -1.0f); //hide the pointer.
				}

				//WII REMOTE BUTTON INFORMATION
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadUp].m_ButtonState 		= platformInfo[0].hold & KPAD_BUTTON_UP;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadDown].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_DOWN;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadLeft].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_LEFT;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadRight].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_RIGHT;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Plus].m_ButtonState		= platformInfo[0].hold & KPAD_BUTTON_PLUS;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonHome].m_ButtonState	= platformInfo[0].hold & KPAD_BUTTON_HOME;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Minus].m_ButtonState		= platformInfo[0].hold & KPAD_BUTTON_MINUS;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonA].m_ButtonState		= platformInfo[0].hold & KPAD_BUTTON_A;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonB].m_ButtonState		= platformInfo[0].hold & KPAD_BUTTON_B;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button1].m_ButtonState   	= platformInfo[0].hold & KPAD_BUTTON_1;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button2].m_ButtonState		= platformInfo[0].hold & KPAD_BUTTON_2;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState  = platformInfo[0].dev_type == WPAD_DEV_FREESTYLE || platformInfo[0].dev_type == WPAD_DEV_MPLS_FREESTYLE;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasMotionPlus].m_ButtonState = platformInfo[0].dev_type == WPAD_DEV_MPLS_FREESTYLE;
				g_HasMotionPlus[m_Id] = platformInfo[0].dev_type == WPAD_DEV_MPLS_FREESTYLE;


				//WII REMOTE RUMBLE CONTROL
				if(m_CurrentControllerData.m_Actuators[EWiiActuators::Vibrate].GetMagnitude() > 0.0f )
				{
					WPADStartMotor(m_Id);	
				}
				else
				{
					WPADStopMotor(m_Id);
				}
			}
			
#if MONKEY_MASH
			if ( use_monkey)
			{
				VIResetDimmingCount();
				if(m_Id > 1)
				{
					m_Connected = false;
					return;
				}
				m_Connected = true;
static	Axiom::Random	random;
				float rnd;
static float MONKEY_ACCEL_X_MIN = -1.0f;
static float MONKEY_ACCEL_X_MAX = 1.0f;
static float MONKEY_ACCEL_X_MAXCHANGEPERFRAME = 0.2f;
static float monkey_AccelX = 0.0f;
				rnd = random.RandFloat(-MONKEY_ACCEL_X_MAXCHANGEPERFRAME, MONKEY_ACCEL_X_MAXCHANGEPERFRAME);
				monkey_AccelX += rnd;
				monkey_AccelX = Axiom::Math::Clamp(monkey_AccelX, MONKEY_ACCEL_X_MIN, MONKEY_ACCEL_X_MAX);

static float MONKEY_ACCEL_Y_MIN = -1.0f;
static float MONKEY_ACCEL_Y_MAX = 1.0f;
static float MONKEY_ACCEL_Y_MAXCHANGEPERFRAME = 0.2f;
static float monkey_AccelY = 0.0f;
				rnd = random.RandFloat(-MONKEY_ACCEL_Y_MAXCHANGEPERFRAME, MONKEY_ACCEL_Y_MAXCHANGEPERFRAME);
				monkey_AccelY += rnd;
				monkey_AccelY = Axiom::Math::Clamp(monkey_AccelY, MONKEY_ACCEL_Y_MIN, MONKEY_ACCEL_Y_MAX);

static float MONKEY_ACCEL_Z_MIN = -1.0f;
static float MONKEY_ACCEL_Z_MAX = 1.0f;
static float MONKEY_ACCEL_Z_MAXCHANGEPERFRAME = 0.2f;
static float monkey_AccelZ = 0.0f;
				rnd = random.RandFloat(-MONKEY_ACCEL_X_MAXCHANGEPERFRAME, MONKEY_ACCEL_Z_MAXCHANGEPERFRAME);
				monkey_AccelZ += rnd;
				monkey_AccelZ = Axiom::Math::Clamp(monkey_AccelZ, MONKEY_ACCEL_Z_MIN, MONKEY_ACCEL_Z_MAX);

				m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::WiimoteAccel].SetValue(monkey_AccelX, monkey_AccelY, monkey_AccelZ);	// Wii pointer, does odd things when off screen...

static float MONKEY_POINTERX_MIN = -1.0f;
static float MONKEY_POINTERX_MAX = 1.0f;
static float MONKEY_POINTERX_MAXCHANGEPERFRAME = 0.2f;
static float monkey_PointerX = 0.0f;
				rnd = random.RandFloat(-MONKEY_POINTERX_MAXCHANGEPERFRAME, MONKEY_POINTERX_MAXCHANGEPERFRAME);
				monkey_PointerX += rnd;
				monkey_PointerX = Axiom::Math::Clamp(monkey_PointerX, MONKEY_POINTERX_MIN, MONKEY_POINTERX_MAX);
static float MONKEY_POINTERY_MIN = -1.0f;
static float MONKEY_POINTERY_MAX = 1.0f;
static float MONKEY_POINTERY_MAXCHANGEPERFRAME = 0.2f;
static float monkey_PointerY = 0.0f;
				rnd = random.RandFloat(-MONKEY_POINTERY_MAXCHANGEPERFRAME, MONKEY_POINTERY_MAXCHANGEPERFRAME);
				monkey_PointerY += rnd;
				monkey_PointerY = Axiom::Math::Clamp(monkey_PointerY, MONKEY_POINTERY_MIN, MONKEY_POINTERY_MAX);			
				m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::Pointer].SetValue(monkey_PointerX, monkey_PointerY);	// Wii pointer, does odd things when off screen...
// Note, following values are %ages.  so 1 = probably of being pressed once in 100 frames.  100 = probably of being pressed all the time.
static float MONKEY_PROB_UP = 0.1f;
static float MONKEY_PROB_DOWN = 0.1f;
static float MONKEY_PROB_LEFT = 0.1f;
static float MONKEY_PROB_RIGHT = 0.1f;
static float MONKEY_PROB_PLUS = 0.1f;
static float MONKEY_PROB_HOME = 0.0f;
static float MONKEY_PROB_MINUS = 0.0f;
static float MONKEY_PROB_A = 20.f;
static float MONKEY_PROB_B = 0.1f;
static float MONKEY_PROB_1 = 0.1f;
static float MONKEY_PROB_2 = 0.1f;
static float MONKEY_PROB_NUNCHUK = 99.9f;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadUp].m_ButtonState 		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_UP;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadDown].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_DOWN;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadLeft].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_LEFT;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::DPadRight].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_RIGHT;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Plus].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_PLUS;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonHome].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_HOME;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Minus].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_MINUS;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonA].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_A;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonB].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_B;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button1].m_ButtonState   	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_1;
				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::Button2].m_ButtonState		= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_2;

				m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState  = random.RandFloat(0.0f, 1.0f) < MONKEY_PROB_NUNCHUK;

				if ( m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::HasNunchuk].m_ButtonState)
				{
static float MONKEY_STICKX_MIN = -1.0f;
static float MONKEY_STICKX_MAX = 1.0f;
static float MONKEY_STICKX_MAXCHANGEPERFRAME = 0.2f;
static float monkey_StickX = 0.0f;
					rnd = random.RandFloat(-MONKEY_STICKX_MAXCHANGEPERFRAME, MONKEY_STICKX_MAXCHANGEPERFRAME);
					monkey_StickX += rnd;
					monkey_StickX = Axiom::Math::Clamp(monkey_StickX, MONKEY_STICKX_MIN, MONKEY_STICKX_MAX);
static float MONKEY_STICKY_MIN = -1.0f;
static float MONKEY_STICKY_MAX = 1.0f;
static float MONKEY_STICKY_MAXCHANGEPERFRAME = 0.2f;
static float monkey_StickY = 0.0f;
					rnd = random.RandFloat(-MONKEY_STICKY_MAXCHANGEPERFRAME, MONKEY_STICKY_MAXCHANGEPERFRAME);
					monkey_StickY += rnd;
					monkey_StickY = Axiom::Math::Clamp(monkey_StickY, MONKEY_STICKY_MIN, MONKEY_STICKY_MAX);			
					m_CurrentControllerData.m_AnalogSticks[EWiiAnalogSticks::NunchuckStick].SetValue(monkey_StickX, monkey_StickY);
static float MONKEY_PROB_C = 0.1f;
static float MONKEY_PROB_Z = 0.0f;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonC].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_C;
					m_CurrentControllerData.m_DigitalButtons[EWiiDigitalButtons::ButtonZ].m_ButtonState	= random.RandFloat(0.0f, 100.0f) < MONKEY_PROB_Z;
				}
			}
#endif
		}

		int ControllerWII::GetAnalogStickCount() const
		{
			return EWiiAnalogSticks::NumberOfItems;
		}

		int ControllerWII::GetAnalogButtonCount() const
		{
			return EWiiAnalogButtons::NumberOfItems;
		}

		int ControllerWII::GetDigitalButtonCount() const
		{
			return EWiiDigitalButtons::NumberOfItems;
		}

		int ControllerWII::GetActuatorCount() const
		{
			return EWiiActuators::NumberOfItems;
		}

		IController* ControllerFactory::CreateController(int controllerID)
		{
			return AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerWII(controllerID));
		}

		void ControllerWII::EnableMotionPlus( bool enable )
		{
			//Temporarily disabled for AoC submission.
			//We don't ever disable the MotionPlus, and this file
			//correctly autodetects whether it's connected or not.
			/*
			g_EnableMpls[m_Id] = enable;
			if(enable)
			{
				EnableMPLS(m_Id);
			}
			else
			{
				KPADDisableMpls(m_Id);
			}
			*/
		}

		void ControllerWII::EnablePointer( bool enable )
		{
			g_EnableDPD[m_Id] = enable;
			if(enable)
			{
				KPADEnableDPD(m_Id);
			}
			else
			{
				KPADDisableDPD(m_Id);
			}
		}

		void ControllerWII::TareBalanceBoard()
		{
			KPADResetWbcZeroPoint();
		}

		void ControllerWII::TGCBalanceBoard()
		{
			KPADResetWbcTgcWeight( );
		}

		void ControllerWII::ZeroMPLS()
		{
			KPADStartMplsCalibration( m_Id );
		}


	}
}

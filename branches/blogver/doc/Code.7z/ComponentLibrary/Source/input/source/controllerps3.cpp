#include "input/icontroller.h"
#include "input/ps3buttons.h"
#include "input/controllerfactory.h"
#include <memory/apmemory.h>
#include "input/inputconst.h"

#include <math/apmath.h>
#include <cell/pad.h> 
#include <cell/pad/pad_codes.h>

#define MAX_DIGITAL_VALUE 0x00FF

namespace AP
{
	namespace Input
	{
		static const int DEADZONELEFT = 0x20;
		static const int DEADZONERIGHT = 0x20;
		static const int MAX_ANALOG = 0xFF;
		static const int MIN_ANALOG = 0;

		static const int DPAD_UP          = 0x00000001;
		static const int DPAD_DOWN        = 0x00000002;
		static const int DPAD_LEFT        = 0x00000004;
		static const int DPAD_RIGHT       = 0x00000008;
		static const int START            = 0x00000010;
		static const int SELECT           = 0x00000020;
		static const int LEFT_THUMB       = 0x00000040;
		static const int RIGHT_THUMB      = 0x00000080;
		static const int LEFT_SHOULDER    = 0x00000100;
		static const int RIGHT_SHOULDER   = 0x00000200;
		static const int CROSS			  = 0x00001000;
		static const int CIRCLE			  = 0x00002000;
		static const int SQUARE           = 0x00004000;
		static const int TRIANGLE		  = 0x00008000;

		static const int LEFT_TRIGGER     = 0x00010000;
		static const int RIGHT_TRIGGER    = 0x00020000;

		// Note: I'm keeping light actuator equivalent to the x360 high freq. actuator which is on the right.
		static const int LEFT_ACTUATOR_MAX = 255;
		static const int RIGHT_ACTUATOR_MAX = 1;

		class ControllerPS3: public IController
		{
			public:
				class ControllerData: public IControllerData
				{
					public:
						ControllerData();
						~ControllerData() {};

						ControllerData& operator=(const ControllerData& rightHandSide);

					protected:
						ControllerData(const ControllerData&);

					public:
						virtual const AnalogStick*		GetAnalogStick(const int index) const;
						virtual const AnalogButton*		GetAnalogButton(int index) const;
						virtual const DigitalButton*	GetDigitalButton(int index) const;
						virtual const Actuator*			GetActuator(int index) const;

					public:
						AnalogStick			m_AnalogSticks[EPS3AnalogSticks::NumberOfItems];
						AnalogButton		m_AnalogButtons[EPS3AnalogButtons::NumberOfItems];
						DigitalButton		m_DigitalButtons[EPS3DigitalButtons::NumberOfItems];
						Actuator			m_Actuators[EPS3Actuators::NumberOfItems];
				};

			public:
				//  PS3 controllers - Must call cellPadInit (MAX_PAD) first before using
				ControllerPS3(Axiom::Int32 id);

				virtual void Update();

				virtual int						GetAnalogStickCount() const;
				virtual int						GetAnalogButtonCount() const;
				virtual int						GetDigitalButtonCount() const;
				virtual int						GetActuatorCount() const;

				virtual const IControllerData*	GetPreviousControllerData() const { return &m_PreviousControllerData; }
				virtual const IControllerData*	GetCurrentControllerData() const { return &m_CurrentControllerData; }
				virtual bool					IsConnected()const{ return m_Connected;}
			private:
				float				GetNorm(float value, int deadzone);

				int					m_Id;		// Controller ID
				
				ControllerData		m_PreviousControllerData;
				ControllerData		m_CurrentControllerData;

				bool				m_Connected;
		};

		ControllerPS3::ControllerData::ControllerData()
		{
			m_DigitalButtons[EPS3DigitalButtons::DPadUp].m_ButtonID				= DPAD_UP;
			m_DigitalButtons[EPS3DigitalButtons::DPadDown].m_ButtonID			= DPAD_DOWN;
			m_DigitalButtons[EPS3DigitalButtons::DPadLeft].m_ButtonID			= DPAD_LEFT;
			m_DigitalButtons[EPS3DigitalButtons::DPadRight].m_ButtonID			= DPAD_RIGHT;
			m_DigitalButtons[EPS3DigitalButtons::Start].m_ButtonID				= START;
			m_DigitalButtons[EPS3DigitalButtons::Select].m_ButtonID				= SELECT;
			m_DigitalButtons[EPS3DigitalButtons::LeftShoulder].m_ButtonID		= LEFT_SHOULDER;
			m_DigitalButtons[EPS3DigitalButtons::RightShoulder].m_ButtonID		= RIGHT_SHOULDER;
			m_DigitalButtons[EPS3DigitalButtons::CROSS].m_ButtonID				= CROSS;
			m_DigitalButtons[EPS3DigitalButtons::CIRCLE].m_ButtonID				= CIRCLE;
			m_DigitalButtons[EPS3DigitalButtons::SQUARE].m_ButtonID				= SQUARE;
			m_DigitalButtons[EPS3DigitalButtons::TRIANGLE].m_ButtonID			= TRIANGLE;

			m_AnalogButtons[EPS3AnalogButtons::LeftTrigger].m_ButtonID			= LEFT_TRIGGER;
			m_AnalogButtons[EPS3AnalogButtons::RightTrigger].m_ButtonID			= RIGHT_TRIGGER;

			m_Actuators[EPS3Actuators::LeftActuator].SetValue(0.f);
			m_Actuators[EPS3Actuators::RightActuator].SetValue(0.f);
		}

		ControllerPS3::ControllerData& ControllerPS3::ControllerData::operator=(const ControllerData& rightHandSide)
		{
			m_AnalogSticks[EPS3AnalogSticks::Left] = rightHandSide.m_AnalogSticks[EPS3AnalogSticks::Left];
			m_AnalogSticks[EPS3AnalogSticks::Right] = rightHandSide.m_AnalogSticks[EPS3AnalogSticks::Right];

			m_DigitalButtons[EPS3DigitalButtons::DPadUp] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::DPadUp];
			m_DigitalButtons[EPS3DigitalButtons::DPadDown] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::DPadDown];
			m_DigitalButtons[EPS3DigitalButtons::DPadLeft] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::DPadLeft];
			m_DigitalButtons[EPS3DigitalButtons::DPadRight] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::DPadRight];
			m_DigitalButtons[EPS3DigitalButtons::Start] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::Start];
			m_DigitalButtons[EPS3DigitalButtons::Select] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::Select];
			m_DigitalButtons[EPS3DigitalButtons::LeftShoulder] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::LeftShoulder];
			m_DigitalButtons[EPS3DigitalButtons::RightShoulder] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::RightShoulder];
			m_DigitalButtons[EPS3DigitalButtons::LeftThumb]     = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::LeftThumb];
			m_DigitalButtons[EPS3DigitalButtons::RightThumb]    = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::RightThumb];
			m_DigitalButtons[EPS3DigitalButtons::CROSS] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::CROSS];
			m_DigitalButtons[EPS3DigitalButtons::CIRCLE] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::CIRCLE];
			m_DigitalButtons[EPS3DigitalButtons::SQUARE] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::SQUARE];
			m_DigitalButtons[EPS3DigitalButtons::TRIANGLE] = rightHandSide.m_DigitalButtons[EPS3DigitalButtons::TRIANGLE];

			m_AnalogButtons[EPS3AnalogButtons::LeftTrigger] = rightHandSide.m_AnalogButtons[EPS3AnalogButtons::LeftTrigger];
			m_AnalogButtons[EPS3AnalogButtons::RightTrigger] = rightHandSide.m_AnalogButtons[EPS3AnalogButtons::RightTrigger];

			m_Actuators[EPS3Actuators::LeftActuator].SetValue(rightHandSide.m_Actuators[EPS3Actuators::LeftActuator].GetMagnitude());
			m_Actuators[EPS3Actuators::RightActuator].SetValue(rightHandSide.m_Actuators[EPS3Actuators::RightActuator].GetMagnitude());

			return *this;
		};

		const IController::AnalogStick* ControllerPS3::ControllerData::GetAnalogStick(const int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EPS3AnalogSticks::NumberOfItems, "ControllerData::GetAnalogStick - index out of range.");

			return &(m_AnalogSticks[index]);
		}

		const IController::AnalogButton* ControllerPS3::ControllerData::GetAnalogButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EPS3AnalogButtons::NumberOfItems, "ControllerData::GetAnalogButton - index out of range.");

			return &(m_AnalogButtons[index]);
		}

		const IController::DigitalButton* ControllerPS3::ControllerData::GetDigitalButton(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EPS3DigitalButtons::NumberOfItems, "ControllerData::GetDigitalButton - index out of range.");

			return &(m_DigitalButtons[index]);
		}

		const IController::Actuator* ControllerPS3::ControllerData::GetActuator(int index) const
		{
			AP_ASSERTMESSAGE(index >= 0 || index < EPS3Actuators::NumberOfItems, "ControllerData::GetActuator - index out of range.");

			return &(m_Actuators[index]);
		}
 
		ControllerPS3::ControllerPS3(int id)
			:	m_Id(id), m_Connected(false)
		{ 

		}

		float ControllerPS3::GetNorm(float value, int deadzone)
		{
			float MID_POINT = MAX_ANALOG/2;
			AP_ASSERTMESSAGE(value>=0.f && value <=MAX_ANALOG, "Ensure that value is from 0x0 to 0xFF." );
			
			const float one_over_max = 1.f/static_cast<float>(MID_POINT - deadzone + 1);
			float normRange = value-MID_POINT;

			if(Axiom::Math::Fabs(normRange) <= deadzone)
				return 0.f;

			float newValue = (normRange<0)?normRange+deadzone:normRange-deadzone;

			newValue = newValue * one_over_max;
			AP_ASSERT(newValue>=-1.f && newValue<=1.f);
			return newValue;


		}

		void ControllerPS3::Update()
		{
			m_PreviousControllerData = m_CurrentControllerData;

			CellPadInfo2		padInfo;	//  connection Pad Information buffer
			CellPadData			padData;	//  Gamapad data buffer
			int32_t ret = cellPadGetInfo2(&padInfo);

			if( ret ==0 )
			{ 
				m_Connected = true;
				if (padInfo.port_status[m_Id] == CELL_PAD_STATUS_DISCONNECTED) 
				{
					m_Connected = false;
				}

				ret = cellPadGetData(m_Id, &padData);

				if(ret == 0)
				{
					if (padData.len >0)
					{
					//m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Left].m_Vector.x					= GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_LEFT_X], DEADZONELEFT);
					//						m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Left].m_Vector.y					= -GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_LEFT_Y], DEADZONELEFT);
					//						m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Right].m_Vector.x					= GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_RIGHT_X], DEADZONERIGHT);
					//						m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Right].m_Vector.y					= -GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_RIGHT_Y], DEADZONERIGHT);
						m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Left].SetValue(	GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_LEFT_X], DEADZONELEFT),	-GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_LEFT_Y], DEADZONELEFT));
						m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Right].SetValue(	GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_RIGHT_X], DEADZONERIGHT),	-GetNorm(padData.button[CELL_PAD_BTN_OFFSET_ANALOG_RIGHT_Y], DEADZONERIGHT));

						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::DPadUp].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_UP ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::DPadDown].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_DOWN ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::DPadLeft].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_LEFT ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::DPadRight].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_RIGHT ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::Start].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_START ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::Select].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_SELECT ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::LeftShoulder].m_ButtonState	= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_L1 ? 1: 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::RightShoulder].m_ButtonState	= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_R1 ? 1: 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::LeftThumb].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_L3 ? 1: 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::RightThumb].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL1] & CELL_PAD_CTRL_R3 ? 1: 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::CROSS].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_CROSS ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::CIRCLE].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_CIRCLE ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::SQUARE].m_ButtonState			= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_SQUARE ? 1 : 0;
						m_CurrentControllerData.m_DigitalButtons[EPS3DigitalButtons::TRIANGLE].m_ButtonState		= padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_TRIANGLE ? 1 : 0;

						// There's a bug with the libpad with these two values of L2 and R2
						//m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::LeftTrigger].SetValue(padData.button[CELL_PAD_BTN_OFFSET_PRESS_L2]);
						//m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::RightTrigger].SetValue(padData.button[CELL_PAD_BTN_OFFSET_PRESS_R2]);

						m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::LeftTrigger].SetValue(padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_L2?255:0);
						m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::RightTrigger].SetValue(padData.button[CELL_PAD_BTN_OFFSET_DIGITAL2] & CELL_PAD_CTRL_R2?255:0);
					}
					
					const float fDeadZone = static_cast<float>(DEADZONELEFT)/static_cast<float>(MAX_ANALOG);
					
					Axiom::Math::Vector2 analogVector1 = Axiom::Math::Vector2( m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Left].GetNormalizeX(),m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Left].GetNormalizeY());
					Axiom::Math::Vector2 analogVector2 = Axiom::Math::Vector2( m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Right].GetNormalizeX(),m_CurrentControllerData.m_AnalogSticks[EPS3AnalogSticks::Right].GetNormalizeY());

					if(m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::LeftTrigger].GetNormalizeState() < fDeadZone)
						m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::LeftTrigger].SetValue(0);

					if(m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::RightTrigger].GetNormalizeState() < fDeadZone)
						m_CurrentControllerData.m_AnalogButtons[EPS3AnalogButtons::RightTrigger].SetValue(0);


				}
			}
		}

		int ControllerPS3::GetAnalogStickCount() const
		{
			return EPS3AnalogSticks::NumberOfItems;
		}

		int ControllerPS3::GetAnalogButtonCount() const
		{
			return EPS3AnalogButtons::NumberOfItems;
		}

		int ControllerPS3::GetDigitalButtonCount() const
		{
			return EPS3DigitalButtons::NumberOfItems;
		}

		int ControllerPS3::GetActuatorCount() const
		{
			CellPadInfo2		padInfo;	//  connection Pad Information buffer
			int32_t ret = cellPadGetInfo2(&padInfo);
			if ((ret == 0) && (padInfo.device_capability[m_Id] & CELL_PAD_CAPABILITY_ACTUATOR))
			{
				return EPS3Actuators::NumberOfItems;
			}
			else
			{
				return 0;
			}

		}

		IController* ControllerFactory::CreateController(int controllerID)
		{
			return AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerPS3(controllerID));
		}
	}
}

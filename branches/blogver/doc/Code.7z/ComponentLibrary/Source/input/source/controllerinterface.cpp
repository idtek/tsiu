#include "input/controllerinterface.h"
#include "input/controllerfactory.h"

namespace AP
{
	namespace Input
	{
	
		ControllerInterface::ControllerInterface() : m_State(CInterfaceState_NONE)
		{
			m_Buffer.analogButtons	= NULL;
			m_Buffer.analogSticks	= NULL;
			m_Buffer.digitalButtons	= NULL;
			m_Buffer.actuators		= NULL;
			m_pRumbleEffects		= NULL;
			m_EnableRumble			= true;
		}

		ControllerInterface::~ControllerInterface()
		{
			if (m_Buffer.analogButtons)
			{
				AP_DELETE(m_Buffer.analogButtons);
			}

			if (m_Buffer.analogSticks)
			{
				AP_DELETE(m_Buffer.analogSticks);
			}

			if (m_Buffer.digitalButtons)
			{
				AP_DELETE(m_Buffer.digitalButtons);
			}

			if (m_Buffer.actuators)
			{
				AP_DELETE(m_Buffer.actuators);
			}

			if(m_pRumbleEffects)
			{
				AP_DELETE(m_pRumbleEffects);
			}
		}

		void ControllerInterface::Init(Axiom::Int32 controllerId)
		{
			m_ControllerId = controllerId;
			m_IController = ControllerFactory::CreateController(controllerId);
			
			m_Buffer.numAnalogButtons = m_IController->GetAnalogButtonCount();
			m_Buffer.numAnalogSticks = m_IController->GetAnalogStickCount();
			m_Buffer.numDigitalButtons = m_IController->GetDigitalButtonCount();
			m_Buffer.numActuators = m_IController->GetActuatorCount();			

			m_Buffer.analogButtons	= AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogButton[m_Buffer.numAnalogButtons] );
			m_Buffer.analogSticks	= AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogStick[m_Buffer.numAnalogSticks] );
			m_Buffer.digitalButtons	= AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::DigitalButton[m_Buffer.numDigitalButtons] );
			m_Buffer.actuators		= AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::Actuator[m_Buffer.numActuators] );
			m_pRumbleEffects		= AP_NEW( Axiom::Memory::DEFAULT_HEAP, CRumbleEffect[m_Buffer.numActuators] );

			for(int i = 0; i < m_Buffer.numActuators; ++i)
			{
				m_pRumbleEffects[i].actuatorLevel = 0.0f;
				m_pRumbleEffects[i].duration = 0;
				m_pRumbleEffects[i].rampDownTime = 0;
				m_pRumbleEffects[i].rampUpTime = 0;
				m_pRumbleEffects[i].repetitions = 0;
				m_pRumbleEffects[i].timePassed = 0;
			}

			mTimer.Start();
		}

		void ControllerInterface::Update()
		{
			updateCurrentRumbleEffects();
			m_IController->Update();
			
			// Add virtual data to controller if playing back
			if (m_State == CInterfaceState_PLAYBACK)
			{
				// Lock m_Buffer for reading.
				m_Mutex.Lock();
			
				const IController::IControllerData* weavedData = m_IController->GetCurrentControllerData();

				// Weave buffered data into controller data (Digital buttons only)
				for (int i=0;i<m_Buffer.numDigitalButtons;i++)
				{
					IController::DigitalButton* d = const_cast<IController::DigitalButton*>(weavedData->GetDigitalButton(i));
					d->m_ButtonState = d->m_ButtonState | m_Buffer.digitalButtons[i].m_ButtonState;
				}

				for (int i=0;i<m_Buffer.numAnalogSticks;i++)
				{
					IController::AnalogStick* a = const_cast<IController::AnalogStick*>(weavedData->GetAnalogStick(i));
					a->SetValue(m_Buffer.analogSticks[i].GetRawX(),m_Buffer.analogSticks[i].GetRawY());

				}

				for (int i=0;i<m_Buffer.numAnalogButtons;i++)
				{
					IController::AnalogButton* a = const_cast<IController::AnalogButton*>(weavedData->GetAnalogButton(i));
					a->SetValue( m_Buffer.analogButtons[i].GetRawState());
				}

				for (int i=0;i<m_Buffer.numActuators;i++)
				{
					IController::Actuator* a = const_cast<IController::Actuator*>(weavedData->GetActuator(i));
					a->SetValue( m_Buffer.actuators[i].GetMagnitude());
				}

				// Unlock m_Buffer
				m_Mutex.Unlock();
			}

			// Log controller data to buffer
			else if (m_State == CInterfaceState_LOGGING)
			{
				// Mutex for writing
				if (!m_Mutex.TryLock())
				{
					return;
				}
				
				const IController::IControllerData *data = m_IController->GetCurrentControllerData();

				// Log controller data			
				for (int i=0;i<m_Buffer.numAnalogButtons;i++)
				{
					m_Buffer.analogButtons[i] = *(const_cast<AP::Input::IController::AnalogButton*>(data->GetAnalogButton(i)));
				}
							
				for (int i=0;i<m_Buffer.numAnalogSticks;i++)
				{
					m_Buffer.analogSticks[i] = *(const_cast<AP::Input::IController::AnalogStick*>(data->GetAnalogStick(i)));
				}
				
				for (int i=0;i<m_Buffer.numDigitalButtons;i++)
				{
					m_Buffer.digitalButtons[i] = *(const_cast<AP::Input::IController::DigitalButton*>(data->GetDigitalButton(i)));
				}

				for (int i=0;i<m_Buffer.numActuators;i++)
				{
					m_Buffer.actuators[i] = *(const_cast<AP::Input::IController::Actuator*>(data->GetActuator(i)));
				}

				m_Buffer.id   = m_ControllerId;				

				m_Mutex.Unlock();
			}
		}

		IController *ControllerInterface::GetController()
		{
			return m_IController;
		}

		void ControllerInterface::SetState(CInterfaceState state)
		{
			m_State = state;
		}

		void ControllerInterface::WriteData(const CInterfaceBuffer *data)
		{
			// Mutex for writing
			if (!m_Mutex.TryLock())
			{
				return;
			}

			// Write Data			
			for (int i=0;i<m_Buffer.numAnalogButtons;i++)
			{
				m_Buffer.analogButtons[i] = data->analogButtons[i];
			}
						
			for (int i=0;i<m_Buffer.numAnalogSticks;i++)
			{
				m_Buffer.analogSticks[i] = data->analogSticks[i];
			}
			
			for (int i=0;i<m_Buffer.numDigitalButtons;i++)
			{
				m_Buffer.digitalButtons[i] = data->digitalButtons[i];
			}

			for (int i=0;i<m_Buffer.numActuators;i++)
			{
				m_Buffer.actuators[i] = data->actuators[i];
			}

			m_Buffer.id   = m_ControllerId;

			// Unlock
			m_Mutex.Unlock();
		}

		void ControllerInterface::ReadData(CInterfaceBuffer *buffer)
		{
			// Mutex for reading!!!
			m_Mutex.Lock();

			buffer->id = m_Buffer.id;
			buffer->numAnalogButtons = m_Buffer.numAnalogButtons;
			buffer->numAnalogSticks = m_Buffer.numAnalogSticks;
			buffer->numDigitalButtons = m_Buffer.numDigitalButtons;
			buffer->numActuators = m_Buffer.numActuators;

			// Read valid Data
			for (int i=0;i<m_Buffer.numAnalogButtons;i++)
			{
				buffer->analogButtons[i] = m_Buffer.analogButtons[i];
			}
			
			for (int i=0;i<m_Buffer.numAnalogSticks;i++)
			{
				buffer->analogSticks[i] = m_Buffer.analogSticks[i];
			}
			
			for (int i=0;i<m_Buffer.numDigitalButtons;i++)
			{
				buffer->digitalButtons[i] = m_Buffer.digitalButtons[i];
			}

			for (int i=0;i<m_Buffer.numActuators;i++)
			{
				buffer->analogButtons[i] = m_Buffer.analogButtons[i];
			}

			// Unlock
			m_Mutex.Unlock();
		}

		void ControllerInterface::PlayRumbleEffect( unsigned int actuatorIndex, const CRumbleEffect & rumbleEffect )
		{
			if(m_pRumbleEffects)
			{
				CRumbleEffect *pControllerEffect = &m_pRumbleEffects[actuatorIndex];
				if(pControllerEffect)
				{
					pControllerEffect->actuatorLevel = rumbleEffect.actuatorLevel;
					pControllerEffect->duration = rumbleEffect.duration;
					pControllerEffect->rampDownTime = rumbleEffect.rampDownTime;
					pControllerEffect->rampUpTime = rumbleEffect.rampUpTime;
					pControllerEffect->repetitions = rumbleEffect.repetitions;
					pControllerEffect->timePassed = 0;
				}
			}
		}

		void ControllerInterface::EnableRumble( bool enable )
		{
			m_EnableRumble = enable;
		}

		void ControllerInterface::updateCurrentRumbleEffects()
		{
			unsigned int timePassed = 0;

			Axiom::Time currTime = mTimer.GetTime();
			timePassed = currTime.AsIntInMilliseconds();

			for(int i = 0; i < GetNumActuators(); ++i)
			{
				CRumbleEffect* pControllerEffect = &m_pRumbleEffects[i];
				IController::Actuator* pActuator = const_cast<IController::Actuator*>(this->GetController()->GetCurrentControllerData()->GetActuator(i));

				if(pControllerEffect)
				{
					unsigned int totalDuration = pControllerEffect->duration + pControllerEffect->rampUpTime + pControllerEffect->rampDownTime;
					unsigned int localDuration = 0;
					float actuatorValue = 0.0f;
					
					pControllerEffect->timePassed += timePassed;
					localDuration = pControllerEffect->timePassed;
					if(!m_EnableRumble || pControllerEffect->timePassed >= (totalDuration * pControllerEffect->repetitions))
					{
						pActuator->SetValue(0.0f);
						pControllerEffect->actuatorLevel = 0;
						pControllerEffect->duration = 0;
						pControllerEffect->rampDownTime = 0;
						pControllerEffect->rampUpTime = 0;
						pControllerEffect->repetitions = 0;
						pControllerEffect->timePassed = 0;
					}
					else 
					{
						if(pControllerEffect->timePassed >= totalDuration)
						{
							localDuration = pControllerEffect->timePassed % totalDuration;
						}

						if(localDuration < pControllerEffect->rampUpTime)
						{
							float ratio = 1.0f - (static_cast<float>(localDuration) / static_cast<float>(pControllerEffect->rampUpTime));
							actuatorValue = ratio * pControllerEffect->actuatorLevel;
							pActuator->SetValue(actuatorValue);
						}
						else if(localDuration < (pControllerEffect->rampUpTime + pControllerEffect->duration))
						{
							actuatorValue = pControllerEffect->actuatorLevel;
							pActuator->SetValue(actuatorValue);
						}
						else
						{
							unsigned int rampDownDuration = totalDuration - localDuration;

							float ratio = static_cast<float>(rampDownDuration) / static_cast<float>(pControllerEffect->rampDownTime);
							actuatorValue = ratio * pControllerEffect->actuatorLevel;
							pActuator->SetValue(actuatorValue);
						}
					}
				}
			}
			mTimer.Start();
		}
	}
}

#ifndef _ICONTROLLER_H
#define _ICONTROLLER_H

#include "math\Vector2.h"

namespace AP
{
	namespace Input
	{
		class IController
		{
			public:
				class AnalogButton
				{
					public:
						int		m_ButtonID;
						int		m_MaxButtonState;

						AnalogButton():
							m_ButtonID(0),
							m_MaxButtonState(0),
							m_ButtonState(0)
						{};

					// Assume that the value is between 0 and 255
					void SetValue(double value)
					{
						AP_STATIC_ASSERT(	sizeof(m_ButtonState) == sizeof(double), 
											Ensure_that_no_body_changes_the_char___If_they_do_then_ensure_the_logic_changes_too);

						m_ButtonState = value;
					}

					// Returns values between 0 to 1
					const float GetNormalizeState()const {return CastToFloat(m_ButtonState);}

					// value from 0 to 255
					const double GetRawState() const {return m_ButtonState;}
				private:
					double	m_ButtonState;
				};

				class DigitalButton
				{
					public:
						int	m_ButtonID;
						int	m_ButtonState;

						DigitalButton():
							m_ButtonID(0),
							m_ButtonState(0)
						{};
				};

				class AnalogStick
				{
					public:
						AnalogStick():
							m_X(0),m_Y(0)
						{};

							virtual ~AnalogStick(){}

							void SetValue(unsigned char x, unsigned char y)
							{
								m_X =  x;
								m_Y =  y;

							}
							// Assume that the value is between -1 and 1
							void SetValue(float x, float y)
							{
								AP_ASSERT(x>=-1 && x<=1 && y>=-1 && y<=1);
								AP_STATIC_ASSERT(sizeof(m_X) == sizeof(unsigned char), Ensure_that_no_body_changes_the_type);

								m_X =  static_cast<unsigned char>(x*127.f + 128.f);
								m_Y =  static_cast<unsigned char>(y*127.f + 128.f);

							}

							// Returns values between -1 to 1
							const float GetNormalizeX()const {return CastToFloat(m_X-128.f)/127.f;}
							const float GetNormalizeY()const{return CastToFloat(m_Y-128.f)/127.f;}
							
							virtual const float GetNormalizeZ() const {return 0.0f;}

							// value from 0 to 255 where 128 is REST point
							const unsigned char GetRawX() const {return m_X;}
							const unsigned char GetRawY() const {return m_Y;}

				private:
					unsigned char m_X;
					unsigned char m_Y;
				};

				// 3 axis extension to analstick, for now used for wii accelerometers.
				class AnalogStick3 : public AnalogStick
				{
					public:
						using AnalogStick::SetValue;
					
						AnalogStick3():
							m_Z(0)
						{	AnalogStick();
						};

						AnalogStick3(float x, float y, float z) : m_Z(0)
						{
							SetValue(x, y, z);
						}
							void SetValue(unsigned char x, unsigned char y, unsigned char z)
							{
								AnalogStick::SetValue( x, y);
								m_Z =  z;
							}
							
							// Assume that the value is between -1 and 1
							void SetValue(float x, float y, float z)
							{
								AP_ASSERT(x>=-1 && x<=1 && y>=-1 && y<=1 && z>=-1 && z<=1 );
								AP_STATIC_ASSERT(sizeof(m_Z) == sizeof(unsigned char), Ensure_that_no_body_changes_the_type);

								AnalogStick::SetValue(x, y);
								m_Z =  static_cast<unsigned char>(z*127.f + 128.f);
							}

							// Returns values between -1 to 1
							virtual const float GetNormalizeZ()const{return CastToFloat(m_Z-128.f)/127.f;}

							// value from 0 to 255 where 128 is REST point
							const unsigned char GetRawZ() const {return m_Z;}

				private:
					unsigned char m_Z;
				};

				class Actuator
				{
					public:
						Actuator():
							m_Magnitude(0.f)
						{};
							// Make sure that the value is between 0 and 1
							void SetValue(float magnitude)
							{
								if(magnitude < 0.f)
								{
									magnitude = 0.f;
								}
								else if(magnitude > 1.f)
								{
									magnitude = 1.f;
								}

								m_Magnitude = magnitude;
							}

							// value from 0 to 1 where 0 is no vibration and 1 is full vibration
							const float GetMagnitude() const {return m_Magnitude;}

				private:
					float m_Magnitude;
				};

				class IControllerData
				{
					public:
						virtual const AnalogStick*		GetAnalogStick(const int index) const = 0;
						virtual const AnalogButton*		GetAnalogButton(int index) const = 0;
						virtual const DigitalButton*	GetDigitalButton(int index) const = 0;
						virtual const Actuator*			GetActuator(int index) const = 0;

					protected:
						IControllerData() {};
						virtual ~IControllerData() {};

					protected:
						IControllerData(const IControllerData&);
						IControllerData& operator=(const IControllerData&);
				};

				virtual void Update() = 0;

				virtual int						GetAnalogStickCount() const = 0;
				virtual int						GetAnalogButtonCount() const = 0;
				virtual int						GetDigitalButtonCount() const = 0;
				virtual int						GetActuatorCount() const = 0;

				virtual const IControllerData*	GetPreviousControllerData() const = 0;
				virtual const IControllerData*	GetCurrentControllerData() const = 0;

				virtual bool					IsConnected()const = 0;
				virtual void					EnableMotionPlus( bool enable ) = 0;
				virtual void					EnablePointer( bool enable ) = 0;
				virtual void					TareBalanceBoard() = 0;
				virtual void					TGCBalanceBoard() = 0;
				virtual void					ZeroMPLS() = 0;
			public:
				virtual ~IController() {};

			protected:
				IController() {};

			protected:
				IController(const IController&);
				IController& operator=(const IController&);
		};
	}
}

#endif

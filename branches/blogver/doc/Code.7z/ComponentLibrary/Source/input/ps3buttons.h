#ifndef _PS3BUTTONS_H
#define _PS3BUTTONS_H

#include <core/classedenum.h>

namespace AP
{
	namespace Input
	{
		CLASSEDENUM	(	EPS3AnalogSticks,\
						CLASSEDENUM_ITEMWITHVALUE(Left,0) \
						CLASSEDENUM_ITEM(Right), \
						Left
					)

		CLASSEDENUM	(	EPS3DigitalButtons,\
						CLASSEDENUM_ITEMWITHVALUE(DPadUp,0) \
						CLASSEDENUM_ITEM(DPadDown) \
						CLASSEDENUM_ITEM(DPadLeft) \
						CLASSEDENUM_ITEM(DPadRight) \
						CLASSEDENUM_ITEM(Start) \
						CLASSEDENUM_ITEM(Select) \
						CLASSEDENUM_ITEM(LeftShoulder) \
						CLASSEDENUM_ITEM(RightShoulder) \
						CLASSEDENUM_ITEM(LeftThumb) \
						CLASSEDENUM_ITEM(RightThumb) \
						CLASSEDENUM_ITEM(CROSS) \
						CLASSEDENUM_ITEM(CIRCLE) \
						CLASSEDENUM_ITEM(SQUARE) \
						CLASSEDENUM_ITEM(TRIANGLE), \
						DPadUp
					)

		CLASSEDENUM	(	EPS3AnalogButtons,\
						CLASSEDENUM_ITEMWITHVALUE(LeftTrigger,0) \
						CLASSEDENUM_ITEM(RightTrigger), \
						LeftTrigger
					)
		
		CLASSEDENUM (	EPS3Actuators,\
						CLASSEDENUM_ITEMWITHVALUE(RightActuator,0) \
						CLASSEDENUM_ITEM(LeftActuator), \
						RightActuator
					)
	}
}

#endif

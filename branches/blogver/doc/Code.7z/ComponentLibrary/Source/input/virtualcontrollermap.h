#ifndef _VIRTUAL_CONTROLLER_H__
#define _VIRTUAL_CONTROLLER_H__

#include "thread/atomic.h"
#include "collections/booklet.h"
#include "core/singleton.h"

namespace AP
{
	namespace Input
	{
		class VirtualControllerMap:public Axiom::Singleton<VirtualControllerMap>
		{
		public:
			static const unsigned int INVALID_VIRTUAL_CONTROLLER_ID = 999999;
			static const unsigned int INVALID_CONTROLLER_MAP_ID = 999999;
			
			VirtualControllerMap();
			~VirtualControllerMap();
			
			void						SetMaxVirtualControllers		( unsigned int numControllers );
			void						Reset							(Axiom::UInt32 numGroups, Axiom::UInt32 numSlotPerGroup);
			
			Axiom::UInt32				GetNumGroup						()const;
            Axiom::UInt32				GetNumSlotPerGroup				()const;

			unsigned int				GetMaxNumVirtualControllers() const { return mMap.Capacity(); }
			
			// AP_PRECONDITION( group < GetNumGroup() )
			// AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() )
			bool						AssignControllerToSlot			(int virtualControllerId, Axiom::UInt32 group, Axiom::UInt32 slotInGroup);
			void 						AssignVirtualGroupId			(Axiom::UInt32 virtualGroupId);

			int							GetVirtualGroupId				() const { return mVirtualGroupId; }
            // AP_PRECONDITION( group < GetNumGroup() )
            // AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() )
			int							GetVirtualIdFromGroupSlot	    (Axiom::UInt32 group, Axiom::UInt32 slotInGroup);
			Axiom::UInt32				GetVirtualIdByIndex				( unsigned int index) const;
			Axiom::UInt32				GetVirtualIdFromControllerId	(Axiom::UInt32 controllerId) ;
			Axiom::UInt32				GetControllerIdFromVirtualId	(Axiom::UInt32 virtualID);
			unsigned int				GetIndexFromVirtualId			( unsigned int virtualId );
			int							GetNumAssignedVirtualId			()const;
			bool						IsLocalVirtualControllerId		(int virtualId);
			
            // AP_PRECONDITION( group < GetNumGroup() )
            // AP_PRECONDITION( slotInGroup < GetNumSlotPerGroup() )
			Axiom::UInt32				GetSlotIdFromGroupSlot			(Axiom::UInt32 group, Axiom::UInt32 slotInGroup);
			Axiom::UInt32				GetAssignSlotId					(int virtualControllerId);
			Axiom::UInt32				GetMaxNumSlots					()const;
		
			void						SetMaxSlotID( unsigned int slotId ) { mMaxSlotId = slotId; }

		private:
			
			Axiom::Collections::DynamicBooklet<int,int,void >  mMap;
			Axiom::Thread::Atomic< Axiom::UInt32 >  mNumSlotPerGroup;
			Axiom::Thread::Atomic< Axiom::UInt32 >  mNumGroups;
			Axiom::UInt32				            mVirtualGroupId;
			Axiom::Thread::Mutex		            mMyLock;
			unsigned int							mMaxSlotId;
		};
	}
}

#endif

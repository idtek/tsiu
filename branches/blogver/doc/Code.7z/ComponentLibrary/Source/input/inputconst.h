#ifndef _INPUT_CONSTS__H__
#define _INPUT_CONSTS__H__

namespace AP
{
	namespace Input
	{
		static const int INVALID_CONTROLLER_ID = -1;
        static const int BALANCE_BOARD_CONTROLLER_ID = 3;
		static const float	INPUT_HZ = 60.f;
		static const float	INPUT_TICK = 1.f/ INPUT_HZ;
	}
}
#endif

#ifndef _CONTROLLERFACTORY_H
#define _CONTROLLERFACTORY_H

namespace AP
{
	namespace Input
	{
		class IController;

		namespace ControllerFactory
		{
			IController* CreateController(Axiom::Int32 controllerID);
		}
	}
}

#endif

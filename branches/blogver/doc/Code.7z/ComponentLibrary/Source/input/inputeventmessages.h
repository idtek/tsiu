#ifndef __INPUT_MESSAGES_H___
#define __INPUT_MESSAGES_H___

#include "kernel/messages.h"
#include "input/inputconst.h"
#include <eventsystem/eventman.h>
namespace AP
{
	namespace Input
	{
		namespace Events
		{
			/////////////////////////////////////////////////////
			// Input Synable Event
			class SynchAbleInputEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID( SynchAbleInputEvent );

				SynchAbleInputEvent():Axiom::EventMsg(Axiom::INVALID_EVENT_ID){}

				SynchAbleInputEvent(const Axiom::EventMsgId guid_id, int controllerId): Axiom::EventMsg(guid_id), mControllerId( CastToUChar( controllerId )){}

				const int	GetControllerId() const {return CastToInt(mControllerId);}
				unsigned char mControllerId;

#if DEBUG_EVENT_TRACKING
				unsigned int mId;
#endif

 				AP_DECLARE_POLYMORPHIC_TYPE();
			};

			
			class SyncInputFrameEvent:public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(SyncInputFrameEvent )//Msg_InputFrameEvent
					SyncInputFrameEvent():Axiom::EventMsg(EVENT_GUID){}
			};

			class RumbleChangeStruct
			{
			public:
				unsigned int rampUpTime;
				unsigned int rampDownTime;
				unsigned int repetitions;
				unsigned int duration;
				float actuatorLevel;

				AP_DECLARE_TYPE();
			};

			class InputChangeRumbleLevelEvent:public Axiom::EventMsg
			{
			public:
				
				EVENT_MSG_GUID(InputChangeRumbleLevelEvent )//Msg_InputSetActuatorEvent

				InputChangeRumbleLevelEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputChangeRumbleLevelEvent(){}
				
				InputChangeRumbleLevelEvent(const unsigned int controllerIndex, const RumbleChangeStruct firstActuator, const RumbleChangeStruct secondActuator):Axiom::EventMsg(EVENT_GUID),
					mControllerIndex(controllerIndex), 
					mFirstActuator(firstActuator),
					mSecondActuator(secondActuator)
				{
				}

				AP_DECLARE_POLYMORPHIC_TYPE();

				unsigned int mControllerIndex;
				RumbleChangeStruct mFirstActuator;
				RumbleChangeStruct mSecondActuator;
			};

			class InputEnableRumbleEvent:public Axiom::EventMsg
			{
			public:
				
				EVENT_MSG_GUID(InputEnableRumbleEvent )

				InputEnableRumbleEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputEnableRumbleEvent(){}
				
				InputEnableRumbleEvent(const unsigned int controllerIndex, const bool enable):Axiom::EventMsg(EVENT_GUID),
					mControllerIndex(controllerIndex), 
					mEnable(enable)
				{
				}

				AP_DECLARE_POLYMORPHIC_TYPE();

				unsigned int mControllerIndex;
				bool         mEnable;
			};

			class InputEnablePointerEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(InputEnablePointerEvent )

				InputEnablePointerEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputEnablePointerEvent(){}
				
				InputEnablePointerEvent(const unsigned int controllerIndex, const bool enable):Axiom::EventMsg(EVENT_GUID),
					mControllerIndex(controllerIndex), 
					mEnable(enable)
				{
				}

				unsigned int mControllerIndex;
				bool         mEnable;
			};

			class InputEnableMotionPlusEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(InputEnableMotionPlusEvent )

				InputEnableMotionPlusEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputEnableMotionPlusEvent(){}
				
				InputEnableMotionPlusEvent(const unsigned int controllerIndex, const bool enable):Axiom::EventMsg(EVENT_GUID),
					mControllerIndex(controllerIndex), 
					mEnable(enable)
				{
				}

				AP_DECLARE_POLYMORPHIC_TYPE();

				unsigned int mControllerIndex;
				bool         mEnable;
			};

			class InputTareBalanceBoardEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(InputTareBalanceBoardEvent )

				InputTareBalanceBoardEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputTareBalanceBoardEvent(){}

			};

			class InputTGCBalanceBoardEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(InputTGCBalanceBoardEvent )

				InputTGCBalanceBoardEvent():Axiom::EventMsg(EVENT_GUID){}
				~InputTGCBalanceBoardEvent(){}

			};

			class InputZeroMotionPlusEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(InputZeroMotionPlusEvent )

				InputZeroMotionPlusEvent():Axiom::EventMsg(EVENT_GUID){}

				InputZeroMotionPlusEvent(const unsigned int controllerIndex ):Axiom::EventMsg(EVENT_GUID),
					mControllerIndex(controllerIndex)
				{
				}
				
				~InputZeroMotionPlusEvent(){}

				AP_DECLARE_POLYMORPHIC_TYPE();

				unsigned int mControllerIndex;

			};
		}
	}

}
#endif

#ifndef _AP_CONTROLLERINTERFACE_H
#define _AP_CONTROLLERINTERFACE_H

#include "input/icontroller.h"
#include "kernel/systemtimer.h"

namespace AP
{
	namespace Input
	{
		enum CInterfaceState
		{
			CInterfaceState_NONE = -1,
			CInterfaceState_LOGGING,
			CInterfaceState_PLAYBACK
		};

		struct CInterfaceBuffer
		{
			int										id;
			int										numAnalogButtons;
			int										numAnalogSticks;
			int										numDigitalButtons;
			int										numActuators;
			AP::Input::IController::AnalogButton	*analogButtons;
			AP::Input::IController::AnalogStick		*analogSticks;
			AP::Input::IController::DigitalButton	*digitalButtons;
			AP::Input::IController::Actuator		*actuators;
		};

		struct CRumbleEffect
		{
			unsigned int timePassed;
			unsigned int rampUpTime;
			unsigned int rampDownTime;
			unsigned int repetitions;
			unsigned int duration;
			float actuatorLevel;
		};

		class ControllerInterface 
		{
		public:
			ControllerInterface();
			~ControllerInterface();

			void			Init(int controllerId);
			void			Update();
			void			SetState(CInterfaceState state);
			IController*	GetController();
			Axiom::Int32	GetControllerId() {return m_ControllerId; };

			int				GetNumAnalogButtons() { return (GetController()->GetAnalogButtonCount()); };
			int				GetNumDigitalButtons() { return (GetController()->GetDigitalButtonCount()); };
			int				GetNumAnalogSticks() { return (GetController()->GetAnalogStickCount()); };
			int				GetNumActuators() { return (GetController()->GetActuatorCount()); };

			void			ReadData(CInterfaceBuffer *buffer);
			void			WriteData(const CInterfaceBuffer *data);
			const bool		IsConnected() { return m_IController->IsConnected(); };
			void			PlayRumbleEffect( unsigned int actuatorIndex, const CRumbleEffect & rumbleEffect );
			void			EnableRumble( bool enable );
			void			EnablePointer( bool enable ) {GetController()->EnablePointer(enable);}
			void			EnableMotionPlus( bool enable ) {GetController()->EnableMotionPlus(enable);}
			void			TareBalanceBoard() {GetController()->TareBalanceBoard();}
			void			TGCBalanceBoard() {GetController()->TGCBalanceBoard();}
			void			ZeroMPLS() {GetController()->ZeroMPLS();}
				
		private:
			CInterfaceState		m_State;
			IController			*m_IController;
			CInterfaceBuffer	m_Buffer;
			CRumbleEffect*		m_pRumbleEffects;
			Axiom::Int32			m_ControllerId;
			Axiom::Thread::Mutex	m_Mutex;

			Axiom::Timer		mTimer;
			bool				m_EnableRumble;

			void			updateCurrentRumbleEffects();

		};
	}
}
#endif

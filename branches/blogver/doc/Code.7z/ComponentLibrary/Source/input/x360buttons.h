#ifndef _X360BUTTONS_H
#define _X360BUTTONS_H

#include <core/classedenum.h>

namespace AP
{
	namespace Input
	{
		CLASSEDENUM	(	EX360AnalogSticks,\
						CLASSEDENUM_ITEMWITHVALUE(Left,0) \
						CLASSEDENUM_ITEM(Right), \
						Left
					)

		CLASSEDENUM	(	EX360DigitalButtons,\
						CLASSEDENUM_ITEMWITHVALUE(DPadUp,0) \
						CLASSEDENUM_ITEM(DPadDown) \
						CLASSEDENUM_ITEM(DPadLeft) \
						CLASSEDENUM_ITEM(DPadRight) \
						CLASSEDENUM_ITEM(Start) \
						CLASSEDENUM_ITEM(Back) \
						CLASSEDENUM_ITEM(LeftShoulder) \
						CLASSEDENUM_ITEM(RightShoulder) \
						CLASSEDENUM_ITEM(LeftThumb) \
						CLASSEDENUM_ITEM(RightThumb) \
						CLASSEDENUM_ITEM(A) \
						CLASSEDENUM_ITEM(B) \
						CLASSEDENUM_ITEM(X) \
						CLASSEDENUM_ITEM(Y), \
						DPadUp
					)

		CLASSEDENUM	(	EX360AnalogButtons,\
						CLASSEDENUM_ITEMWITHVALUE(LeftTrigger,0) \
						CLASSEDENUM_ITEM(RightTrigger), \
						LeftTrigger
					)

		CLASSEDENUM (	EX360Actuators,\
						CLASSEDENUM_ITEMWITHVALUE(LeftActuator,0) \
						CLASSEDENUM_ITEM(RightActuator), \
						LeftActuator
					)
	}
}

#endif

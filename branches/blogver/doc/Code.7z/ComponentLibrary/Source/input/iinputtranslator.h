#ifndef _INPUTTRANSLATOR_H
#define _INPUTTRANSLATOR_H

#include <core/classedenum.h>
#include <input/icontroller.h>
#include <math/vector3.h>

namespace Axiom
{
	class EventMan;
}

namespace AP
{
	namespace Input
	{
		CLASSEDENUM_REFLECTED	(	EButtonStates,
						CLASSEDENUM_ITEM(Off)
						CLASSEDENUM_ITEM(OffToOn)
						CLASSEDENUM_ITEM(On)
						CLASSEDENUM_ITEM(OnToOff)
						CLASSEDENUM_ITEM(OnChanged),
						Off
					);

		inline bool IsStateChange( EButtonStates state ) { return ( state == EButtonStates::OnToOff || state == EButtonStates::OffToOn ); }

		class IInputTranslator
		{
		public:

			/**
				@class TranslatableItem
				Item that can be translated.  Contains info about a button
			*/

			class TranslatableItem
			{
			public:
				enum ItemType
				{
					DigitalButton,
					AnalogButton,
					AnalogStick,					
				};

				TranslatableItem( ItemType type, int id, EButtonStates state ) :
					mType( type ),
					mId( id ),
					mState( state )
				{
				}

				TranslatableItem( ItemType type, int id, const Axiom::Math::Vector3& analog ) :
					mType( type ),
					mId( id ),
					mAnalog( analog )
				{
				}

				ItemType						GetItemType() const {return mType;}
				int								GetId() const {return mId;}

				EButtonStates					GetButtonState() const { AP_ASSERT( mType == DigitalButton ); return mState;}
				const Axiom::Math::Vector3&		GetAnalog() const { AP_ASSERT( mType == AnalogButton || mType == AnalogStick ); return mAnalog; }

			private:

				ItemType				mType;		///< Type of button
				int						mId;		///< Id of the button, valid for all
				EButtonStates			mState;		///< State of the button, only valid for Digital
				Axiom::Math::Vector3	mAnalog;	///< Analog value of the button, good for all analog (x,y for stick, x for button)
			};

			static const unsigned int MaxNumItemsToTranslate = 30;
			typedef Axiom::Collections::StaticList< TranslatableItem, MaxNumItemsToTranslate >	TranslationList;

			public:
				IInputTranslator() {};
				virtual ~IInputTranslator() {};

				virtual void EnsureVirtualControllerMapped(){};
				virtual void Update(const int controllerId, Axiom::EventMan *pEventMan) {UNUSED_PARAM(controllerId); UNUSED_PARAM(pEventMan);}
				
				virtual void TranslateInput(const int controllerId, const TranslationList& translationList ) = 0;
				
				virtual void UpdateConnectionInfo(const int controllerId, bool IsConnected) = 0;
				virtual void SendConnectionInfo(Axiom::EventMan* pEventManager) = 0;

				virtual void SendHomeInfo(Axiom::EventMan* pEventManager) = 0;
		};
	}
}// namespace AP

#endif

#ifndef __CORE_INPUTCOMPONENT__
#define __CORE_INPUTCOMPONENT__

#include "kernel/component.h"
#include "input/controllerinterface.h"
#include "input/inputconst.h"
#include "input/iinputtranslator.h"

namespace AP
{	
	namespace Input
	{
		class IInputTranslator;
		class IController;
		
		class CoreInputComponent: public Component
		{
		public:
			CoreInputComponent(Axiom::ConstStr name, Kernel* kernel);
			~CoreInputComponent();

			void										OnInit();
			void										OnUpdate();
			void										OnShutdown();

			void										InstallInputTranslator(IInputTranslator* pInputTranslator);

			void										PreInit( unsigned int maxNumControllers );

		private:
			
			IInputTranslator*											m_pInputTranslator;
			Axiom::Collections::DynamicList< ControllerInterface >		m_ControllerArray;
			Axiom::EventMsgBoxHandle									m_ComponentMsgBox;

		private:

			void											HandleEvents();
			void											OnInputRumbleChangeEvent(const Axiom::EventMsg* pMsg);
			void											OnInputEnableRumbleEvent(const Axiom::EventMsg* pMsg);
			void											OnInputEnablePointer(const Axiom::EventMsg* pMsg);
			void											OnInputEnableMotionPlus(const Axiom::EventMsg* pMsg);
			void											OnInputTareBalanceBoard(const Axiom::EventMsg* pMsg);
			void											OnInputTGCBalanceBoard(const Axiom::EventMsg* pMsg);
			void											OnInputZeroMotionPlus(const Axiom::EventMsg* pMsg);

			void											HandleDigitalButtons( int controllerId, const IController* controller, IInputTranslator::TranslationList& list );
			void											HandleAnalogButtons( int controllerId, const IController* controller, IInputTranslator::TranslationList& list );
			void											HandleAnalogSticks( int controllerId, const IController* controller, IInputTranslator::TranslationList& list );
		};
	}
}
#endif

#ifndef _WIIBUTTONS_H
#define _WIIBUTTONS_H

#include <core/classedenum.h>

namespace AP
{
	namespace Input
	{	
		// Stick and pointer are 2 axis, accelerometers are 3 axis.
		CLASSEDENUM	(	EWiiAnalogSticks, \
						CLASSEDENUM_ITEMWITHVALUE(NunchuckStick,0) \
						CLASSEDENUM_ITEM(Pointer) \
						CLASSEDENUM_ITEM(WiimoteSwing) \
						CLASSEDENUM_ITEM(WiimoteAccel) \
						CLASSEDENUM_ITEM(NunchukAccel) \
						CLASSEDENUM_ITEM(MplsAngles) \
						CLASSEDENUM_ITEM(MplsVelocity), \
						NunchuckStick
					)

		CLASSEDENUM	(	EWiiDigitalButtons, \
						CLASSEDENUM_ITEMWITHVALUE(DPadUp,0) \
						CLASSEDENUM_ITEM(DPadDown) \
						CLASSEDENUM_ITEM(DPadLeft) \
						CLASSEDENUM_ITEM(DPadRight) \
						CLASSEDENUM_ITEM(Plus) \
						CLASSEDENUM_ITEM(Minus) \
						CLASSEDENUM_ITEM(ButtonC) \
						CLASSEDENUM_ITEM(ButtonZ) \
						CLASSEDENUM_ITEM(Button1) \
						CLASSEDENUM_ITEM(Button2) \
						CLASSEDENUM_ITEM(ButtonA) \
						CLASSEDENUM_ITEM(ButtonNone) \
						CLASSEDENUM_ITEM(ButtonB) \
						CLASSEDENUM_ITEM(ButtonHome) \
						CLASSEDENUM_ITEM(LowBatt) \
						CLASSEDENUM_ITEM(HasNunchuk) \
						CLASSEDENUM_ITEM(HasMotionPlus) \
						CLASSEDENUM_ITEM(MPLSCalibrated), \
						DPadUp								
					)

		CLASSEDENUM	(	EWiiAnalogButtons,\
						CLASSEDENUM_ITEMWITHVALUE(WeightFR,0) \
						CLASSEDENUM_ITEM(WeightBR) \
						CLASSEDENUM_ITEM(WeightFL) \
						CLASSEDENUM_ITEM(WeightBL) \
						CLASSEDENUM_ITEM(WeightAveFR) \
						CLASSEDENUM_ITEM(WeightAveBR) \
						CLASSEDENUM_ITEM(WeightAveFL) \
						CLASSEDENUM_ITEM(WeightAveBL) \
						CLASSEDENUM_ITEM(WeightTGC), \
						WeightFR
					)
		
		CLASSEDENUM (	EWiiActuators,\
						CLASSEDENUM_ITEMWITHVALUE(Vibrate,0) \
						CLASSEDENUM_ITEM(Sound), \
						Vibrate
					)
	}
}

#endif

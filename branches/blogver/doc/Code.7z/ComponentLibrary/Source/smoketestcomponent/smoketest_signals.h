#ifndef __SMOKE__TEST__SIGNAL_LIST_H__
#define __SMOKE__TEST__SIGNAL_LIST_H__

#include "kernel/coreglobalsignallist.h"

#define SMOKE_TEST_SIGNAL_LIST()\
	SIGNAL_LIST_ITEM( SigSmokeTestChannel,			SIGNAL_TYPE_GENERICEVENT, AP::SIGNALFLAG_DEFAULT )\

namespace AP
{
	namespace SmokeTest
	{

		class SmokeTestSignalList
		{
			public:
// 				#ifndef SIGNAL_LIST_ITEM
// 				#define SIGNAL_LIST_ITEM(sig, sigType, flag) DECLARE_SIGNAL(sig, sigType)
// 							SMOKE_TEST_SIGNAL_LIST()
// 				#endif
// 				#undef SIGNAL_LIST_ITEM
		};

	} //namespace SmokeTest
} //namespace AP

#endif

// class header
#include "smoketestcomponent/smoketest_signals.h"

// other includes

namespace AP
{
	namespace SmokeTest
	{

// 		#define SMOKETEST_SIGNAL_CREATE_STATIC(sig, flag) AP::SmokeTest::SmokeTestSignalList::sig(flag);
// 		#ifndef SIGNAL_LIST_ITEM
// 		#define SIGNAL_LIST_ITEM(sig, sigType,flag) sigType SMOKETEST_SIGNAL_CREATE_STATIC(sig, flag)
// 				SMOKE_TEST_SIGNAL_LIST()
// 		#endif
// 		#undef SIGNAL_LIST_ITEM

	} //namespace SmokeTest
} //namespace AP

// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	smoktestcomponent.cpp
//!	@brief	a component that creates an indirection layer from internal events, it maintains its own event pipeline
//
//	created:	10:22:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================

#include "smoketestcomponent/smoketesteventmessages.h"
#include "smoketestcomponent/smoketestcomponent.h"

namespace AP
{
	namespace SmokeTest
	{
		
		SmokeTestComponent::SmokeTestComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name, kernel)
		{
			m_DelegateEventHandler = NULL;
		}

		SmokeTestComponent::~SmokeTestComponent()
		{
		}

		// Component required stuff:
		void SmokeTestComponent::OnInit( )
		{	
			m_InternalEventsMsgBox = mEventMan.RegisterAndCreateEventMsgBox("InternalGameEvents");
			m_InternalEventsMsgBox->RegisterListenBroadcastEvent( SmokeTest_MiniGameLaunchEvent::EVENT_GUID	);
			m_InternalEventsMsgBox->RegisterListenBroadcastEvent( SmokeTest_MiniGameStopEvent::EVENT_GUID	);
		}

		void SmokeTestComponent::OnUpdate( )
		{
			HandleMapInternalEvents();
		}

		void SmokeTestComponent::HandleMapInternalEvents()
		{		
			//DAY 7/16/2008 2:31:30 PM  Just as easy to just handle all the messages in the delegate handler
			//And then clear in and outbox.  We can happily clear without checking for content
			m_DelegateEventHandler(m_InternalEventsMsgBox);
				
			m_InternalEventsMsgBox->ClearOutbox();
			m_InternalEventsMsgBox->ClearInbox();
		}

		void SmokeTestComponent::OnShutdown( )
		{
		}

		void SmokeTestComponent::RegisterDelegate(DelegateFunction pFunc)
		{
			m_DelegateEventHandler = pFunc;
		}

	} //namespace SmokeTest
}  // namespace  AP

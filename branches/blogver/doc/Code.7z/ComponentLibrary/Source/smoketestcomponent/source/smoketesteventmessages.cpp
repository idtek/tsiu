// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	smoketesteventmessages.cpp
//!	@brief	Event messages that are used for the smoke testing system on soccer
//
//	created:	7:19:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include "smoketestcomponent/smoketesteventmessages.h"

namespace AP
{
	namespace SmokeTest
	{

		AP_TYPE(SmokeTest_MiniGameLaunchEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
			AP_FIELD("GameIdentifier", m_GameIdentifier, "Identifier of the game to launch(99 character max)");
		AP_TYPE_END()

		AP_TYPE(SmokeTest_MiniGameLaunchedEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
		AP_TYPE_END()

		AP_TYPE(SmokeTest_MiniGameStopEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
		AP_TYPE_END()

		AP_TYPE(SmokeTest_MiniGameStoppedEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
		AP_TYPE_END()

		AP_TYPE(SmokeTest_GoalScoredEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
		AP_TYPE_END()

		AP_TYPE(SmokeTest_PingEvent)
			AP_BASE_TYPE(Axiom::EventMsg)
			AP_DEFAULT_CREATE()
		AP_TYPE_END()
			
	}	// namespace SmokeTest
}	// namespace AP


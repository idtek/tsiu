#ifndef ___SMOKE__TEST_COMPONENT_H__
#define ___SMOKE__TEST_COMPONENT_H__

#include "kernel/component.h"

namespace AP
{
	namespace SmokeTest
	{ 
		typedef bool (*DelegateFunction) (Axiom::EventMsgBoxHandle& pMsgBox);

		class SmokeTestComponent: public AP::Component
		{
			public:
				SmokeTestComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~SmokeTestComponent();

			public:  
				// component methods:
				virtual void		OnInit( );
				virtual void		OnUpdate( );
				virtual void		OnShutdown( );
				
				void				RegisterDelegate(DelegateFunction pFunc);
				
			private:  //methods
				void				HandleMapInternalEvents();
				
			private:
				DelegateFunction				m_DelegateEventHandler;
				Axiom::EventMsgBoxHandle		m_InternalEventsMsgBox;
		};

	} //namespace SmokeTest
}  // namespace  AP

#endif

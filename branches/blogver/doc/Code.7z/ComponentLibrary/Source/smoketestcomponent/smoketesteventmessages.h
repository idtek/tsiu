#ifndef _SMOKE_TEST_EVENT_MESSAGES_H___
#define _SMOKE_TEST_EVENT_MESSAGES_H___

#include "EventSystem/eventmsg.h"
#include "kernel/messages.h"
#include <eventsystem/eventman.h>

namespace AP
{
	namespace SmokeTest
	{
	
// 		class SmokeTest_MiniGameLaunchEvent: public Axiom::EventMsg
// 		{
// 			public:
// 				EVENT_MSG_GUID( SmokeTest_MiniGameLaunchEvent)
// 
// 					SmokeTest_MiniGameLaunchEvent():EventMsg(EVENT_GUID){}
// 				
// 			public:
// 				AP_DECLARE_POLYMORPHIC_TYPE();
// 		};	
		typedef Axiom::StaticString<100>	STGameIdentifier;

		class SmokeTest_MiniGameLaunchEvent: public Axiom::EventMsg
		{
			public:

				EVENT_MSG_GUID(SmokeTest_MiniGameLaunchEvent);

				SmokeTest_MiniGameLaunchEvent() : Axiom::EventMsg(EVENT_GUID) {}

				STGameIdentifier	m_GameIdentifier;

				AP_DECLARE_POLYMORPHIC_TYPE();
		};


		class SmokeTest_MiniGameLaunchedEvent: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SmokeTest_MiniGameLaunchedEvent)

				SmokeTest_MiniGameLaunchedEvent():EventMsg(EVENT_GUID){}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};	

		class SmokeTest_MiniGameStopEvent: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SmokeTest_MiniGameStopEvent)

					SmokeTest_MiniGameStopEvent():EventMsg(EVENT_GUID){}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class SmokeTest_MiniGameStoppedEvent: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SmokeTest_MiniGameStoppedEvent)

					SmokeTest_MiniGameStoppedEvent():EventMsg(EVENT_GUID){}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class SmokeTest_GoalScoredEvent: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SmokeTest_GoalScoredEvent )

					SmokeTest_GoalScoredEvent():EventMsg(EVENT_GUID) {}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class SmokeTest_PingEvent: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SmokeTest_PingEvent )

				SmokeTest_PingEvent():EventMsg(EVENT_GUID) {}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

	} //namespace SmokeTest
}// namespace AP

#endif

#ifndef _COMPONENTLIBRARY_ASYNCLOADER_ASYNCLOADERMESSAGES_H
#define _COMPONENTLIBRARY_ASYNCLOADER_ASYNCLOADERMESSAGES_H

#include <eventsystem/eventmsg.h>
#include <files/fileinfo.h>

namespace Axiom
{
	namespace FileManager
	{
		class UserDataList;
	}
}

namespace ComponentLibrary
{
	namespace AsyncLoader
	{
		namespace Events
		{
			class AsyncLoaderRequestEvent: public Axiom::EventMsg
			{
				public:
					EVENT_MSG_GUID(AsyncLoaderRequestEvent);

					AsyncLoaderRequestEvent() : 
						Axiom::EventMsg(EVENT_GUID),
						m_FileInfo( 0 ),
						m_pBuffer( 0 ),
						m_Priority( -1 )
					{
					}

					const Axiom::FileManager::FileInfo*	m_FileInfo;
					void*								m_pBuffer;

					int									m_Priority;
			};

			class AsyncLoaderRequestCompletedEvent: public Axiom::EventMsg
			{
				public:
					EVENT_MSG_GUID(AsyncLoaderRequestCompletedEvent)

					AsyncLoaderRequestCompletedEvent(): Axiom::EventMsg(EVENT_GUID) {}

					const Axiom::FileManager::FileInfo*	m_FileInfo;
			};

			class AsyncUserSaveRequest : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(AsyncUserSaveRequest)

				AsyncUserSaveRequest( Axiom::FileManager::UserDataList* list ): Axiom::EventMsg(EVENT_GUID), mList( list ) {}

				Axiom::FileManager::UserDataList* mList;
			};

			class AsyncUserSaveComplete : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(AsyncUserSaveComplete)

				AsyncUserSaveComplete( unsigned int id = 0): Axiom::EventMsg(EVENT_GUID), mId( id ) {}

				unsigned int mId;
			};
		}
	}
}

#endif

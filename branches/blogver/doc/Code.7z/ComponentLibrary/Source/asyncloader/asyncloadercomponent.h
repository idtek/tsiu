#ifndef _COMPONENTLIBRARY_ASYNCLOADER_ASYNCLOADERCOMPONENT_H
#define _COMPONENTLIBRARY_ASYNCLOADER_ASYNCLOADERCOMPONENT_H

#include <kernel/component.h>
#include <collections/linkedlistarray.h>

namespace Axiom
{
	namespace FileManager
	{
		class FileManager;
		class FileInfo;
	}
}

namespace ComponentLibrary
{
	namespace AsyncLoader
	{
		class AsyncRequestNode
		{
			public:
				const Axiom::FileManager::FileInfo*		m_FileInfo;
				void*									m_pBuffer;
				int										m_Priority;
		};

		class AsyncLoaderComponent: public AP::Component
		{
			public:
				AsyncLoaderComponent(Axiom::ConstStr name, AP::Kernel* kernel);

				void				PreInit( Axiom::FileManager::FileManager* pFileManager );

				void		OnInit();
				void		OnUpdate();
				void		OnShutdown();

			private:
				
				void						HandleFileUpdate();
				void						HandleEvents();

				void						OnAsyncLoaderRequestEvent(const Axiom::EventMsg* pMsg);
				void						OnAsyncUserSaveRequestEvent(const Axiom::EventMsg* pMsg);

			private:

				//DAY 5/30/2008 3:30:29 PM  Should this be dynamic?
				typedef Axiom::Collections::StaticLinkedListArray<AsyncRequestNode, 950>			AsyncRequestNodeListArray;

				Axiom::EventMsgBoxHandle	m_ComponentMsgBox;
				
				Axiom::FileManager::FileManager*	m_pFileManager;
				AsyncRequestNodeListArray			m_AsyncRequestNodeListArray;				
				int									m_NumPendingRequests;
		};
	}
}

#endif

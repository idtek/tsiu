#include "asyncloader/asyncloadercomponent.h"

#include <files/filemanager.h>

#include "asyncloader/asyncloadermessages.h"

namespace ComponentLibrary
{
	namespace AsyncLoader
	{
		AsyncLoaderComponent::AsyncLoaderComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: AP::Component(name,kernel)
			, m_ComponentMsgBox(NULL)
			, m_NumPendingRequests(0)
			, m_pFileManager(0)
		{
		}

		void AsyncLoaderComponent::PreInit( Axiom::FileManager::FileManager* pFileManager)
		{
			m_pFileManager = pFileManager;
		}

		// ----------------------------------------------------------------------------------------------------------------
		void AsyncLoaderComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("AsyncLoaderComponent", Axiom::Memory::DEFAULT_HEAP, 610, 200, 5);
			m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AsyncLoaderRequestEvent::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(Events::AsyncUserSaveRequest::GetEventId());
		}

		// ----------------------------------------------------------------------------------------------------------------
		void AsyncLoaderComponent::OnUpdate()
		{
			AP_ASSERT( m_pFileManager );

			HandleEvents();
			HandleFileUpdate();

			if (!m_AsyncRequestNodeListArray.IsEmpty())
			{
				if (m_pFileManager->IsLoadingAsynchronously())
				{
					while (m_AsyncRequestNodeListArray.Count() && m_pFileManager->LoadFileAsynchronousComplete( *m_AsyncRequestNodeListArray.Item(0).m_FileInfo) )
					{
						Events::AsyncLoaderRequestCompletedEvent asyncLoaderRequestCompletedEvent;
						asyncLoaderRequestCompletedEvent.m_FileInfo = m_AsyncRequestNodeListArray.Item(0).m_FileInfo;

						m_ComponentMsgBox->SendEvent(&asyncLoaderRequestCompletedEvent);

						m_AsyncRequestNodeListArray.Remove(0);
						m_NumPendingRequests--;
					}
				}

				while (	m_pFileManager->NumAsyncLoadsOpen() &&
						m_NumPendingRequests < static_cast<int>(m_AsyncRequestNodeListArray.Count()))
				{
					AsyncRequestNode& asyncRequestNode = m_AsyncRequestNodeListArray.Item(m_NumPendingRequests);
					m_pFileManager->LoadFileAsynchronous( *asyncRequestNode.m_FileInfo, asyncRequestNode.m_pBuffer );
					m_NumPendingRequests++;
				}
			}

			m_ComponentMsgBox->ClearOutbox();
		}

		// ----------------------------------------------------------------------------------------------------------------
		void AsyncLoaderComponent::OnShutdown()
		{	
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}

		void AsyncLoaderComponent::HandleFileUpdate()
		{
			//Platform specific stuff
			unsigned int value = 0;

			if( m_pFileManager->UpdateFileInfo( value ) == Axiom::FileManager::FileManager::UserSaveComplete )
			{
				Events::AsyncUserSaveComplete myEvt( value );
				m_ComponentMsgBox->SendEvent( &myEvt );
			}
		}

		void AsyncLoaderComponent::HandleEvents()
		{
			const Axiom::UInt numEvents = m_ComponentMsgBox->GetNumEvents();

			for (Axiom::UInt i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

				if(pMsg->GetGuidID() == Events::AsyncLoaderRequestEvent::EVENT_GUID)
				{
					OnAsyncLoaderRequestEvent(pMsg);
				}
				else if( pMsg->GetGuidID() == Events::AsyncUserSaveRequest::EVENT_GUID )
				{
					OnAsyncUserSaveRequestEvent(pMsg);
				}
			}

			m_ComponentMsgBox->ClearInbox();
		}

		void AsyncLoaderComponent::OnAsyncUserSaveRequestEvent(const Axiom::EventMsg* pMsg)
		{
			const Events::AsyncUserSaveRequest* theEvt = pMsg->GetClass< Events::AsyncUserSaveRequest >();
			m_pFileManager->SaveUserFiles( *theEvt->mList );
		}

		void AsyncLoaderComponent::OnAsyncLoaderRequestEvent(const Axiom::EventMsg* pMsg)
		{
			const Events::AsyncLoaderRequestEvent* pRequest = pMsg->GetClass<Events::AsyncLoaderRequestEvent>();

			AsyncRequestNode node;
			node.m_FileInfo = pRequest->m_FileInfo;
			node.m_pBuffer = pRequest->m_pBuffer;
			node.m_Priority = pRequest->m_Priority;

			AP_ASSERT( pRequest->m_pBuffer );

			if( pRequest->m_Priority == -1 || m_AsyncRequestNodeListArray.IsEmpty() )
			{
				m_AsyncRequestNodeListArray.Add( node );
			}
			else
			{
				for( unsigned int i = 1; i < m_AsyncRequestNodeListArray.Count(); ++i )
				{
					if( m_AsyncRequestNodeListArray[ i ].m_Priority < pRequest->m_Priority )
					{
						m_AsyncRequestNodeListArray.Insert( i, node );
						return;
					}
				}

				//DAY 7/2/2008 4:32:54 PM  If you get here, it's all your priority
				m_AsyncRequestNodeListArray.Add( node );
			}
		}
	}
}

#include "inputrecording/inputlogcomponent.h"

#include <files/filemanager.h>

namespace AP
{
	namespace InputRecording
	{
		static const char* LOGGING_CHANNEL = "InputLogging";
		
		InputLogComponent::InputLogComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name,kernel)
			, m_ComponentMsgBox(NULL)
		{
			m_ControllerCount = NO_CONTROLLERS;
			m_OutFileNameStr = "";
			m_pControllers = NULL;
			m_LoggerActivationState = ActivationState_NONE;
			m_LoggingState = LogState_Idle;
			m_WasInit = true;
		}

		InputLogComponent::~InputLogComponent()
		{
			Cleanup();
		}

		// Component required stuff:
		void InputLogComponent::OnInit( )
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("InputLog");
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_StartLogging::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_StopLogging::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_PauseLogging::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_RecorderControllerSetup::GetEventId());

			m_LoggingState = LogState_Idle;
			m_LoggerActivationState = ActivationState_NONE;
		}

		void InputLogComponent::OnUpdate( )
		{
			HandleEvents();

			switch(m_LoggerActivationState)
			{
				case (ActivationState_RecorderActivate):
					{
						ActivateControllerRecording(true);
						AP_ASSERTMESSAGE(m_OutFileNameStr!="", "Attempt to activate logging before a valid log file is defined!");
						
						WriteLogHeaderInfo();   // serialize out headers:

						m_LoggerActivationState = ActivationState_NONE;
						m_LoggingState = LogState_Recording;
						break;
					}
					
				case (ActivationState_RecorderDeactivate):
					{ 
						WriteInputBufferToLogFile();
						
						if (m_LoggingState != LogState_Idle)
						{
							m_LoggingState = LogState_Idle;
						}
						m_LoggerActivationState = ActivationState_NONE;
						break;
					}
				default:
					break;
			}

			switch(m_LoggingState)
			{
				case (LogState_Recording):
					{
						if ( (m_InputBuffer.IsFull()) ) 
						{
							WriteInputBufferToLogFile();
						}

						for ( unsigned int i=0; i<m_ControllerCount; ++i)
						{
							if (m_pControllers[i].pCInterface->IsConnected() == true)
							{
								m_pControllers[i].pCInterface->ReadData( &m_pControllers[i].data );

								PackedControllerData inputPacket;
								inputPacket.Pack(m_pControllers[i].data);
								m_InputBuffer.Add(inputPacket);
							}
						}
						break;
					}
				default:
					break;
			}
		}

		void InputLogComponent::SetControllerInterfaces(int nControllers, ControllerInterface* controllerInterfaces)
		{
			//allocate the local controller reference list
			m_ControllerCount = nControllers;
			m_pControllers = AP_NEW(Axiom::Memory::DEFAULT_HEAP, LoggableController[m_ControllerCount]);
			for ( unsigned int i=0; i<m_ControllerCount; ++i)
			{
				m_pControllers[i].pCInterface = &controllerInterfaces[i];

				AP::Input::IController* iController = controllerInterfaces[i].GetController();
				m_pControllers[i].data.id = controllerInterfaces[i].GetControllerId();

				int numAnalogButtons = iController->GetAnalogButtonCount();
				int numAnalogSticks = iController->GetAnalogStickCount();
				int numDigitalButtons = iController->GetDigitalButtonCount();
				m_pControllers[i].data.numAnalogButtons = numAnalogButtons;
				m_pControllers[i].data.numAnalogSticks = numAnalogSticks;
				m_pControllers[i].data.numDigitalButtons = numDigitalButtons;

				m_pControllers[i].data.analogButtons = AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogButton[numAnalogButtons] );
				m_pControllers[i].data.analogSticks = AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogStick[numAnalogSticks] );
				m_pControllers[i].data.digitalButtons = AP_NEW( Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::DigitalButton[numDigitalButtons] );
			}
		}

		void InputLogComponent::OnShutdown( )
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
			Cleanup();
		}

		void InputLogComponent::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

				if(pMsg->GetGuidID() == LogEvent_StartLogging::EVENT_GUID)
				{
					OnLogEvent_StartLogging(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_StopLogging::EVENT_GUID)
				{
					OnLogEvent_StopLogging(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_PauseLogging::EVENT_GUID)
				{
					OnLogEvent_PauseLogging(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_RecorderControllerSetup::EVENT_GUID)
				{
					OnLogEvent_RecorderControllerSetup(pMsg);
				}
			}

			m_ComponentMsgBox->ClearInbox();
		}

		void InputLogComponent::OnLogEvent_StartLogging(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to start log input with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to start log input with no controllers Attached!");
			const LogEvent_StartLogging* pLogEvent_StartLogging = pMsg->GetClass<LogEvent_StartLogging>();
			if ( SetOutFileName(pLogEvent_StartLogging->m_FileNameStr) )
			{
				ActivateLogging(true);
			}
		}

		void InputLogComponent::OnLogEvent_StopLogging(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to stop log input with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to stop log input with no controllers Attached!");
			const LogEvent_StopLogging* pLogEvent_StopLogging = pMsg->GetClass<LogEvent_StopLogging>();
			UNUSED_PARAM(pLogEvent_StopLogging);
			ActivateLogging(false);
			Axiom::Log(LOGGING_CHANNEL, "Input Recording Stopped.\n");
		}

		void InputLogComponent::OnLogEvent_PauseLogging(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to pause log input with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to pause log input with no controllers Attached!");
			const LogEvent_PauseLogging* pLogEvent_PauseLogging = pMsg->GetClass<LogEvent_PauseLogging>();
			PauseLogging(pLogEvent_PauseLogging->m_Pause);
		}

		void InputLogComponent::OnLogEvent_RecorderControllerSetup(const Axiom::EventMsg* pMsg)
		{
			const LogEvent_RecorderControllerSetup* pControllerSetup = pMsg->GetClass<LogEvent_RecorderControllerSetup>();
			
			AP_ASSERTMESSAGE(pControllerSetup->m_ControllerInterfaces != NULL, "OnLogEvent_RecorderControllerSetup: Attempt to register a nill list of controllers!");
			AP_ASSERTMESSAGE(m_pControllers == NULL, "OnLogEvent_RecorderControllerSetup: Controllers are already registered!");
			
			SetControllerInterfaces(pControllerSetup->m_ControllerCount, pControllerSetup->m_ControllerInterfaces);
			Axiom::Log(LOGGING_CHANNEL, "InputLogComponent Controllers Registered = %d", pControllerSetup->m_ControllerCount);
		}

		void InputLogComponent::PauseLogging(bool pauseOn)
		{
			if (pauseOn)
			{
				Axiom::Log(LOGGING_CHANNEL, "Input Recording Paused.\n");
			}
			else
			{
				Axiom::Log(LOGGING_CHANNEL, "Input Recording Resumed.\n");
			}
		}

		// Recording interface stuff:
		void InputLogComponent::Cleanup( )
		{
			if (m_WasInit)
			{
				WriteInputBufferToLogFile();				
				
				// wipe out the temp data buffers.
				if(m_pControllers)
				{
					AP::Input::CInterfaceBuffer* iControllerData = NULL;
					for ( unsigned int i=0; i<m_ControllerCount; ++i)
					{
						iControllerData = &m_pControllers[i].data;
						if (iControllerData->analogButtons)
						{
							AP_DELETE(iControllerData->analogButtons);
						}

						if (iControllerData->analogSticks)
						{
							AP_DELETE(iControllerData->analogSticks);
						}

						if (iControllerData->digitalButtons)
						{
							AP_DELETE(iControllerData->digitalButtons);
						}
					}
					AP_DELETE(m_pControllers);
				}

				m_WasInit = false;
			}
		}

		void InputLogComponent::WriteInputBufferToLogFile( )
		{
			Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();			
			Axiom::FileManager::FileInfo info = fileManager->GetFileInfo( m_OutFileName ); 

			unsigned int offset = info.GetSize();

			for (size_t i=0; i < m_InputBuffer.Count(); ++i)
			{
				offset += fileManager->SaveFileChunkSynchronous( info, m_InputBuffer.Item(i).GetRawBytes(), offset, m_InputBuffer.Item(i).GetDataSize() );
			}
				
			m_InputBuffer.Clear();
		}

		//Write out header information for the file:
		//ncontrollers(16b), [id1, nanalogstix1, nanalogbuttons1, ndigitalbuttons1], [id2,.., ndigitalbuttons2], ... 
		void InputLogComponent::WriteLogHeaderInfo( )
		{
			using AP::Input::CInterfaceBuffer;

			Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();			
			Axiom::FileManager::FileInfo info = fileManager->GetFileInfo( m_OutFileName ); 

			WritePlatformHeader();

			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "tried to log input: no controllers available to log");

			// pack number of controllers to a Byte
			AP_ASSERTMESSAGE(m_ControllerCount <= 255, "WOAH!  too many controllers attached to this machine.  over 255?  how?");
			Axiom::UInt16 nControllersByte = (Axiom::UInt16)m_ControllerCount;

			
			unsigned int offset = sizeof( Axiom::UInt16 );
			offset += fileManager->SaveFileChunkSynchronous( info, &nControllersByte, offset, sizeof( nControllersByte ) );

			HeaderPacket packedHeaderInfo = 0U;
			CInterfaceBuffer* controller = NULL;

			for( unsigned int i=0; i<m_ControllerCount; ++i)
			{
				controller = &m_pControllers[i].data;
				PackedControllerData::PackHeaderInfo(controller->id, controller->numAnalogButtons, controller->numAnalogSticks, controller->numDigitalButtons, packedHeaderInfo);

				offset += fileManager->SaveFileChunkSynchronous( info, &packedHeaderInfo, offset, sizeof(packedHeaderInfo) );
				packedHeaderInfo = 0U;
			}
		}

		void InputLogComponent::ActivateControllerRecording(bool turnOn)
		{
			for ( unsigned int i=0; i<m_ControllerCount; ++i)
			{
				if (turnOn)
				{
					m_pControllers[i].pCInterface->SetState(AP::Input::CInterfaceState_LOGGING);
					Axiom::Log(LOGGING_CHANNEL, "InputLogComponent Controller %d recording ACTIVATED", m_pControllers[i].data.id);
				}
				else
				{
					m_pControllers[i].pCInterface->SetState(AP::Input::CInterfaceState_NONE);
					Axiom::Log(LOGGING_CHANNEL, "InputLogComponent Controller %d recording DEACTIVATED", m_pControllers[i].data.id);
				}
			}
		}

		void InputLogComponent::ActivateLogging(bool activateOn)
		{
			if (activateOn)
			{
				AP_ASSERTMESSAGE(m_LoggingState == LogState_Idle, "m_LoggingState != LogState_Idle, trying to activate logging twice");
				AP_ASSERTMESSAGE(m_pControllers != NULL, "Controllers have not been initialized.  Can't log!");
				if (m_LoggingState == LogState_Idle)
				{
					m_LoggerActivationState = ActivationState_RecorderActivate;
					Axiom::Log(LOGGING_CHANNEL, "Input Recording ACTIVATED Recording to file '%s'", m_OutFileNameStr.AsChar());
				}
			}
			else
			{
				AP_ASSERTMESSAGE(m_LoggingState == LogState_Recording, "m_LoggingState != LogState_Recording, trying to activate logging twice");
				if (m_LoggingState == LogState_Recording)
				{
					m_LoggerActivationState = ActivationState_RecorderDeactivate;
					Axiom::Log(LOGGING_CHANNEL, "Input Recording DEACTIVATED");
				}
			}
		}

		bool InputLogComponent::SetOutFileName(Axiom::ShortString outName)
		{
			AP_ASSERTMESSAGE(!outName.IsEmpty(), "no log file name passed in.");

			Axiom::ShortString longFileName = "data:";
			longFileName += outName;

			bool isNameVerified = VerifyFileNameUnique(longFileName);
			if (isNameVerified)
			{
				m_OutFileNameStr = outName;
				m_OutFileName = longFileName.AsChar();
			}

			return isNameVerified;
		}

		bool InputLogComponent::VerifyFileNameUnique(Axiom::ShortString fName)
		{
			UNUSED_PARAM(fName);
			// TODO:  rui, add support for actually testing the file's existence here.
			return true;
		}

		void InputLogComponent::WritePlatformHeader( )
		{
			Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();			
			Axiom::FileManager::FileInfo info = fileManager->GetFileInfo( m_OutFileName ); 

			LoggedConsoleType console = LCT_ERROR;	//(16bits)

			#if CORE_WIN32
				console = LCT_WIN32;

			#elif CORE_XBOX360
				console = LCT_XBOX360;

			#elif CORE_PS3
				console = LCT_PS3;

			#elif CORE_WII
				console = LCT_WII;
				
			#elif CORE_TOOLS
				console = LCT_TOOLS;

			#elif CORE_DIRECTX
				console = LCT_DIRECTX;

			#endif

			Axiom::UInt16 consolePack = static_cast<Axiom::UInt16>(console);
			info.SetSize(sizeof( Axiom::UInt16 ));
			fileManager->SaveFileSynchronous( info, &consolePack );
		}

	} //namespace InputRecording
}  // namespace  AP

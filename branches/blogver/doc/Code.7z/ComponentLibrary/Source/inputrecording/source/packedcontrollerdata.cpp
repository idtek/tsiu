#include "inputrecording/packedcontrollerdata.h"

using namespace Axiom;
namespace AP
{
	namespace InputRecording
	{
		PackedControllerData::PackedControllerData()
		{
			for (unsigned int i=0; i<MAX_CONTROLLER_PACKETS; ++i)
			{
				m_PackedData[i] = 0;
			}
		}

		PackedControllerData::PackedControllerData(const Axiom::Byte* byteData)
		{
			for (unsigned int i=0; i < MAX_CONTROLLER_PACKETS; ++i)
			{
				m_PackedData[i] = byteData[i];
			}
		}

		// packet structure (in Bytes):
		// id, AnalogButton1 | AnalogButton2, AnalogStick1.x | AnalogStick1.y, AnalogStick2.x | AnalogStick2.y, digitalButtonStateBits1 | digitalButtonStateBits1, (1B padding)
		void PackedControllerData::Pack(const AP::Input::CInterfaceBuffer& unpackedData)
		{
			int byte = 0;

			// Pack controller ID:
			AP_ASSERTMESSAGE(unpackedData.id <= 255, "Controller Id out of range (0 <= id <= 255)");
			m_PackedData[byte] = (Axiom::Byte)unpackedData.id;
			++byte;
			
			// Pack Analog Buttons states:
			AP_ASSERTMESSAGE(unpackedData.numAnalogButtons <= 2, "Ensure we only have two ANALOG BUTTON!!!");
			for (int btn = 0; btn < unpackedData.numAnalogButtons; ++btn)
			{
				const Input::IController::AnalogButton* pCurrentButton = &unpackedData.analogButtons[btn];	
				m_PackedData[byte] = static_cast<Axiom::Byte>(static_cast<float>(pCurrentButton->GetNormalizeState()*255.f));
				++byte;
			}

			// Pack Analog Stick states:
			AP_ASSERTMESSAGE(unpackedData.numAnalogSticks <=2, "Ensure that we only have two analog sticks!!");
			for (int stick = 0; stick < unpackedData.numAnalogSticks; ++stick)
			{
				const Input::IController::AnalogStick* pCurStick = &unpackedData.analogSticks[stick];

				Axiom::Byte testX = static_cast<Axiom::Byte>(static_cast<float>(pCurStick->GetNormalizeX()*127.f+128.f));
				Axiom::Byte testY = static_cast<Axiom::Byte>(static_cast<float>(pCurStick->GetNormalizeY()*127.f+128.f));
				//AP_ASSERT( testX >=0 && testX < 255);
				//AP_ASSERT( testY >=0 && testY < 255);
				
				m_PackedData[byte++] = testX;//static_cast<Axiom::Byte>(static_cast<float>(pCurStick->GetNormalizeX()));
				m_PackedData[byte++] = testY;//static_cast<Axiom::Byte>(static_cast<float>(pCurStick->GetNormalizeY()*127.f+128.f));

			}

			// Pack Digital Button states:
			AP_ASSERTMESSAGE(unpackedData.numDigitalButtons< 16, "ENSURE WE HAVE LESS THAN 2 BYTES of BITS to SET.");

			Axiom::UInt16* pByte = reinterpret_cast<Axiom::UInt16*>(&m_PackedData[byte]);
			for(int btn = 0; btn < unpackedData.numDigitalButtons; ++btn)
			{
				const Input::IController::DigitalButton* pCurrentButton = &unpackedData.digitalButtons[btn];

				if(pCurrentButton->m_ButtonState==0)
				{
					*pByte &= ~(0x01 << btn);
				}
				else
				{
					*pByte |= (0x01 << btn);
				}
			}

			// Clear remaining padding bits:
			m_PackedData[9] = 0xff;

		}

		void PackedControllerData::Unpack(AP::Input::CInterfaceBuffer* unpackedData)
		{
			int byte = 0;

			// Unpack controller ID:
			unpackedData->id = (int)m_PackedData[byte];
			++byte;
			
			// Unpack Analog Buttons:
			for (int btn=0; btn<unpackedData->numAnalogButtons; ++btn)
			{
				unpackedData->analogButtons[btn].SetValue(static_cast<char>(m_PackedData[byte++]));
			}

			// Unpack Analog Sticks:
			for (int stick=0; stick<unpackedData->numAnalogSticks; ++stick)
			{
				float testX = (float)(m_PackedData[byte++] - 128.f)/128.f;
				float testY = (float)(m_PackedData[byte++] - 128.f)/128.f;

				AP_ASSERT(testX >=-1.f && testX <= 1.f);
				AP_ASSERT(testY >=-1.f && testY<= 1.f);
				
				unpackedData->analogSticks[stick].SetValue(testX, testY);
			}

			// Unpack Digital Buttons states:
			Axiom::UInt16* pByte = reinterpret_cast<Axiom::UInt16*>(&m_PackedData[byte]);
			for (int btn=0; btn<unpackedData->numDigitalButtons; ++btn)
			{
				if (*pByte & (0x01 << btn) )
				{
					unpackedData->digitalButtons[btn].m_ButtonState = 1;
				}
				else
				{
					unpackedData->digitalButtons[btn].m_ButtonState = 0;
				}
			}
		}

		//File Header packing STATIC
		void PackedControllerData::PackHeaderInfo(const int id, const int nAnalogButtons, const int nAnalogSticks, const int nDigitalButtons, HeaderPacket& packedHeader)
		{
			// id, numAnalogButtons, numAnalogSticks, and numDigitalButtons all packed into one UInt32
			Axiom::Byte* pByte = reinterpret_cast<Axiom::Byte*>(&packedHeader);
			pByte[0] = (Axiom::Byte)id;
			pByte[1] = (Axiom::Byte)nAnalogButtons;
			pByte[2] = (Axiom::Byte)nAnalogSticks;
			pByte[3] = (Axiom::Byte)nDigitalButtons;
		}

		void PackedControllerData::UnpackHeaderInfo(const HeaderPacket& packedHeader, int& id, int& nAnalogButtons, int& nAnalogSticks, int& nDigitalButtons)
		{
			const Axiom::Byte* pByte = reinterpret_cast<const Axiom::Byte*>(&packedHeader);
			id = (int)pByte[0];
			nAnalogButtons = (int)pByte[1];
			nAnalogSticks = (int)pByte[2];
			nDigitalButtons = (int)pByte[3];
		}

		int PackedControllerData::GetControllerID()
		{
			return ( (int)m_PackedData[0] );
		}
	} //namespace InputRecording
}  // namespace  AP

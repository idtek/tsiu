// class header
#include "inputrecording/recordersignals.h"

// other includes

namespace AP
{
	namespace InputRecording
	{

// 		#define TEST_CREATE_STATIC(sig, flag) AP::InputRecording::InputRecorderUnitTestSignalList::sig(flag);
// 		#ifndef SIGNAL_LIST_ITEM
// 		#define SIGNAL_LIST_ITEM(sig, sigType,flag) sigType TEST_CREATE_STATIC(sig, flag)
// 				RECORDER_SIGNAL_LIST()
// 		#endif
// 		#undef SIGNAL_LIST_ITEM

	} //namespace InputRecording
} //namespace AP

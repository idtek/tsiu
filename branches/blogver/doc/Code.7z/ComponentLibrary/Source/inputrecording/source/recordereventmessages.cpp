// =========================================================================
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//
//!	@file 	recordereventmessages.cpp
//!	@brief	Exposing these events so that they can be created and sent from Streaker via reflection.
//
//	created:	7:5:2007
//
//	Copyright (c) 2007 by Action Pants Inc
// =========================================================================
#include "inputrecording/recordereventmessages.h"

using namespace AP::InputRecording;

// Logging Events:
AP_TYPE(LogEvent_StartLogging)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("LogFileName", m_FileNameStr, "the complete path and name of the file to log input to.")
	AP_COMMAND(SetFile, "set the log file name.  needs full path.");
AP_TYPE_END()

AP_TYPE(LogEvent_StopLogging)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LogEvent_PauseLogging)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Pause", m_Pause, "True to pause, False to unPause.")
AP_TYPE_END()

// Playback Events:
AP_TYPE(LogEvent_StartPlayback)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("LogFileName", m_FileNameStr, "the complete path and name of the file to read input from.")
AP_TYPE_END()

AP_TYPE(LogEvent_StopPlayback)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(LogEvent_PausePlayback)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
	AP_FIELD("Pause", m_Pause, "True to pause, False to unPause.")
AP_TYPE_END()

AP_TYPE(LogEvent_PlaybackFinished)
	AP_BASE_TYPE(Axiom::EventMsg)
	AP_DEFAULT_CREATE()
AP_TYPE_END()

#include "inputrecording/inputplaybackcomponent.h"

#include <files/filemanager.h>

namespace AP
{
	namespace InputRecording
	{ 
		static const char* LOGGING_CHANNEL = "InputLogging";

		InputPlaybackComponent::InputPlaybackComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name, kernel),
			m_ControllerCount(NO_CONTROLLERS),
			m_pControllers(NULL),
			m_PlaybackState(PlaybackState_Idle),
			m_PlaybackActivationState(Playback_ActivationState_NONE),
			m_Current(0),
			m_WasInit(true),
			m_ComponentMsgBox(NULL)
		{
		}

		InputPlaybackComponent::~InputPlaybackComponent()
		{
			Cleanup();
		}

		void InputPlaybackComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("InputPlayback");
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_StartPlayback::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_StopPlayback::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_PausePlayback::GetEventId());
			m_ComponentMsgBox->RegisterListenBroadcastEvent(LogEvent_PlaybackControllerSetup::GetEventId());

			m_FileManager = Axiom::FileManager::FileManager::GetInstance();
		}

		void InputPlaybackComponent::OnUpdate()
		{
			HandleEvents();

			switch(m_PlaybackActivationState)
			{
				case (Playback_ActivationState_PlaybackActivate):
				{
					ActivateControllerPlayback(true);
					if (!m_LoggedData.IsEmpty())
					{
						m_LoggedData.Clear();
					}
					
					ReadInputLogFile();  //TODO rui this should read in in chunks instead of one fell swoop.
					
					m_Current = 0;
					m_PlaybackActivationState = Playback_ActivationState_NONE;
					m_PlaybackState = PlaybackState_Playback;
					Axiom::Log(LOGGING_CHANNEL, "No Data was there to READ.  Bad log file!");
					AP_ASSERTMESSAGE(m_LoggedData.Count()>0, "No Data was there to READ.  Bad log file!");
					break;
				}

				case (Playback_ActivationState_PlaybackDeactivate):
				{
					m_PlaybackActivationState = Playback_ActivationState_NONE;
					if (m_PlaybackState != PlaybackState_Idle)
					{
						m_PlaybackState = PlaybackState_Idle;
						ActivateControllerPlayback(false);
						m_LoggedData.Clear();
					}
					break;
				}

				default:
					break;
			}

			if (m_PlaybackState == PlaybackState_Playback)
			{
				// grab controller data from the buffer and pass it to the appropriate controller interface:
				// bump the index to the next Item in the list.
				m_pCurrentData = &m_LoggedData.Item(m_Current);
				for (Axiom::uint controller=0; controller<m_ControllerCount; ++controller)
				{
					if (m_pControllers[controller]->GetControllerId() == m_pCurrentData->GetControllerID())
					{
						m_ControllerDataBuffer.id = m_pCurrentData->GetControllerID();
						m_pCurrentData->Unpack(&m_ControllerDataBuffer);

						m_pControllers[controller]->WriteData( &m_ControllerDataBuffer );
						break;
					}
				}
				++m_Current;
				//TODO rui, rewrite this so that it handles reading the file in chunks
				if ( m_Current >= m_LoggedData.Count() )
				{
					Axiom::Log(LOGGING_CHANNEL, "Input Playback completed!\n");
					ActivatePlayback(false);
				}
			}
		}


		void InputPlaybackComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
			Cleanup();
		}

		void InputPlaybackComponent::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

				if(pMsg->GetGuidID() == LogEvent_StartPlayback::EVENT_GUID)
				{
					OnLogEvent_StartPlayback(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_StopPlayback::EVENT_GUID)
				{
					OnLogEvent_StopPlayback(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_PausePlayback::EVENT_GUID)
				{
					OnLogEvent_PausePlayback(pMsg);
				}
				else if(pMsg->GetGuidID() == LogEvent_PlaybackControllerSetup::EVENT_GUID)
				{
					OnLogEvent_PlaybackControllerSetup(pMsg);
				}
			}

			m_ComponentMsgBox->ClearInbox();
		}


		void InputPlaybackComponent::OnLogEvent_StartPlayback(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to start input playback with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to start input playback input with no controllers Attached!");
			const LogEvent_StartPlayback* pStartPlaying = pMsg->GetClass<LogEvent_StartPlayback>();
			if (SetPlaybackFileName(pStartPlaying->m_FileNameStr))
			{
				ActivatePlayback(true);
			}
		}

		void InputPlaybackComponent::OnLogEvent_StopPlayback(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to stop input playback with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to stop input playback input with no controllers Attached!");
			
			UNUSED_PARAM(pMsg);
			ActivatePlayback(false);
		}

		void InputPlaybackComponent::OnLogEvent_PausePlayback(const Axiom::EventMsg* pMsg)
		{
			AP_ASSERTMESSAGE(m_pControllers != NULL, "Attempt to pause input playback with no controllers registered!");
			AP_ASSERTMESSAGE(m_ControllerCount != NO_CONTROLLERS, "Attempt to pause input playback input with no controllers Attached!");
			const LogEvent_PausePlayback* pPausePlaying = pMsg->GetClass<LogEvent_PausePlayback>();

			PausePlayback(pPausePlaying->m_Pause);
		}

		void InputPlaybackComponent::OnLogEvent_PlaybackControllerSetup(const Axiom::EventMsg* pMsg)
		{
			const LogEvent_PlaybackControllerSetup* pSetupEvent = pMsg->GetClass<LogEvent_PlaybackControllerSetup>();
			
			AP_ASSERTMESSAGE(pSetupEvent->m_ControllerInterfaces != NULL, "OnLogEvent_PlaybackControllerSetup:  Attempt to register a nill list of controllers!");
			AP_ASSERTMESSAGE(m_pControllers == NULL, "OnLogEvent_PlaybackControllerSetup: Controllers are already registered!");
			
			SetControllerInterfaces(pSetupEvent->m_ControllerCount, pSetupEvent->m_ControllerInterfaces);
			Axiom::Log(LOGGING_CHANNEL, "Input Playback Controllers Registered = %d", pSetupEvent->m_ControllerCount);
		}


		void InputPlaybackComponent::SetControllerInterfaces(int nControllers, ControllerInterface* controllerInterfaces)
		{
			m_ControllerCount = nControllers;
			m_pControllers = AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerInterface*[m_ControllerCount]);
			for (Axiom::uint i=0; i<m_ControllerCount; ++i)
			{
				m_pControllers[i] = &controllerInterfaces[i];
			}
		}

		void InputPlaybackComponent::ActivatePlayback(bool activateOn)
		{
			if (activateOn)
			{
				if (m_PlaybackState == PlaybackState_Idle)
				{
					m_PlaybackActivationState = Playback_ActivationState_PlaybackActivate;
					Axiom::Log(LOGGING_CHANNEL, "Input Playback ACTIVATED.  Now playing back from file: %s", m_LogFileName.AsChar());
				}
			}
			else
			{
				if (m_PlaybackState == PlaybackState_Playback)
				{
					m_PlaybackActivationState = Playback_ActivationState_PlaybackDeactivate;
					LogEvent_PlaybackFinished playbackFinished(false);
					m_ComponentMsgBox->SendEvent(&playbackFinished);
					m_ComponentMsgBox->ClearOutbox();
					Axiom::Log(LOGGING_CHANNEL, "Input Playback DEACTIVATED.\n");
				}
			}
		}

		void InputPlaybackComponent::PausePlayback(bool pauseOn)
		{
			if (pauseOn)
			{
				Axiom::Log(LOGGING_CHANNEL, "InputLogComponent Paused\n");
			}
			else
			{
				Axiom::Log(LOGGING_CHANNEL, "InputLogComponent Resumed\n");
			}
		}

		bool InputPlaybackComponent::SetPlaybackFileName( const Axiom::ShortString& logName)
		{
			Axiom::ShortString longFileName = "data:";
			longFileName += logName;

			bool bVerified = VerifyFileExists(longFileName);
			if (bVerified)
			{
				m_LogFileName = longFileName.AsChar();
			}
			return bVerified;
		}

		void InputPlaybackComponent::ActivateControllerPlayback(bool turnOn)
		{
			for (Axiom::uint i=0; i<m_ControllerCount; ++i)
			{
				if (turnOn)
				{
					m_pControllers[i]->SetState(AP::Input::CInterfaceState_PLAYBACK);
					Axiom::Log(LOGGING_CHANNEL, "Controller Playback ACTIVATED");
				}
				else
				{
					m_pControllers[i]->SetState(AP::Input::CInterfaceState_NONE);
					Axiom::Log(LOGGING_CHANNEL, "Controller Playback DEACTIVATED");
				}
			}
		}

		bool InputPlaybackComponent::VerifyFileExists( const Axiom::ShortString& fileName)
		{
			return m_FileManager->DoesFileExist(fileName.AsChar());
		}

		void InputPlaybackComponent::VerifyPlatformInfo(LoggedConsoleType console)
		{
			#if CORE_WIN32
				AP_ASSERTMESSAGE(console == LCT_WIN32, "Attempt to load non WIN32 console log file");

			#elif CORE_XBOX360
				AP_ASSERTMESSAGE(console == LCT_XBOX360, "Attempt to load non XBOX360 console log file");

			#elif CORE_PS3
				AP_ASSERTMESSAGE(console == LCT_PS3, "Attempt to load non PS3 console log file");

			#elif CORE_WII
				AP_ASSERTMESSAGE(console == LCT_WII, "Attempt to load non PS3 console log file");
				
			#elif CORE_TOOLS
				AP_ASSERTMESSAGE(console == LCT_TOOLS, "Attempt to load non TOOLS console log file");

			#elif CORE_DIRECTX
				AP_ASSERTMESSAGE(console == LCT_DIRECTX, "Attempt to load non DIRECTX console log file");

			#endif
		}

		void InputPlaybackComponent::ReadInputLogFile()
		{
			Axiom::FileManager::FileInfo info = m_FileManager->GetFileInfo( m_LogFileName.AsChar() );
			AP_ASSERT( info.IsValid() );

			size_t sizePacketsRead = 0;
			size_t MAX_BUFFER_SIZE = info.GetSize();
			AP_ASSERTMESSAGE(MAX_BUFFER_SIZE >= (sizeof(Axiom::UInt32)*2), "file is invalid");

			// load file:
			Axiom::Byte* fileBuffer = AP_NEW(Axiom::Memory::DEFAULT_HEAP, Axiom::Byte[MAX_BUFFER_SIZE]);
			m_FileManager->LoadFileSynchronous( info, fileBuffer );
			m_LoggedData.Resize(Axiom::Memory::DEFAULT_HEAP, MAX_BUFFER_SIZE);

			// read platform info:
			const Axiom::UInt16* pPacket = reinterpret_cast<const Axiom::UInt16*>(&fileBuffer[0]);
			Axiom::UInt16 consolePack = pPacket[0];
			sizePacketsRead += sizeof(consolePack);

			LoggedConsoleType console = (LoggedConsoleType)consolePack;
			VerifyPlatformInfo(console);

			// controller count:
			Axiom::UInt16 controllerCount = pPacket[1];
			Axiom::uint nControllers = (Axiom::uint)pPacket[1];
			sizePacketsRead += sizeof(controllerCount);

			AP_ASSERTMESSAGE(nControllers<=m_ControllerCount, "read more controllers than are connected");

			// controller info packets (0..n):
			ControllerVerificationPack* verificationPack = AP_NEW(Axiom::Memory::DEFAULT_HEAP, ControllerVerificationPack[nControllers]);
			const HeaderPacket* pHeader = reinterpret_cast<const HeaderPacket*>(&fileBuffer[sizePacketsRead]);
			for(Axiom::uint i=0; i<m_ControllerCount; ++i)
			{
				PackedControllerData::UnpackHeaderInfo(pHeader[i], verificationPack[i].id, verificationPack[i].numAnalogButtons, verificationPack[i].numAnalogSticks, verificationPack[i].numDigitalButtons);
				sizePacketsRead += sizeof(HeaderPacket);
			}
			AP_ASSERTMESSAGE(VerifyControllers(verificationPack), "loading invalid log file, controller data does not match current controller configuration.");

			// all cool, allocate our controller data buffer:
			// ASSUMES all controllers have same button and stick counts.
			m_ControllerDataBuffer.id = 0;
			m_ControllerDataBuffer.numAnalogButtons = verificationPack[0].numAnalogButtons;
			m_ControllerDataBuffer.numAnalogSticks = verificationPack[0].numAnalogSticks;
			m_ControllerDataBuffer.numDigitalButtons = verificationPack[0].numDigitalButtons;
			m_ControllerDataBuffer.analogButtons = AP_NEW(Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogButton[verificationPack[0].numAnalogButtons] );
			m_ControllerDataBuffer.analogSticks= AP_NEW(Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::AnalogStick[verificationPack[0].numAnalogSticks] );
			m_ControllerDataBuffer.digitalButtons = AP_NEW(Axiom::Memory::DEFAULT_HEAP, AP::Input::IController::DigitalButton[verificationPack[0].numDigitalButtons] );

			delete verificationPack;

			// process the controllers byte stream:
			Axiom::Byte* pControllerPacket = &fileBuffer[sizePacketsRead];
			while (sizePacketsRead < MAX_BUFFER_SIZE)
			{
				PackedControllerData* controllerData = AP_NEW( Axiom::Memory::DEFAULT_HEAP, PackedControllerData(pControllerPacket) );
				m_LoggedData.Add(*controllerData);

				sizePacketsRead += controllerData->GetDataSize();
				pControllerPacket = &fileBuffer[sizePacketsRead];
			}

			m_Current = 0;
			delete fileBuffer;
		}

		bool InputPlaybackComponent::VerifyControllers(const ControllerVerificationPack* controllerInfos)
		{
			bool bVerified = false;
			for (Axiom::uint i=0; i<m_ControllerCount; ++i)
			{
				for (Axiom::uint j=0; j<m_ControllerCount; ++j)
				{
					if (m_pControllers[j]->GetControllerId() == controllerInfos[i].id )
					{
						bVerified = (controllerInfos[i].numAnalogButtons == m_pControllers[j]->GetNumAnalogButtons());
						bVerified = (controllerInfos[i].numAnalogSticks == m_pControllers[j]->GetNumAnalogSticks());
						bVerified = (controllerInfos[i].numDigitalButtons == m_pControllers[j]->GetNumDigitalButtons());
						break;
					}
					if (!bVerified)
					{
						break;
					}
				}
			}

			return bVerified;
		}

		void InputPlaybackComponent::Cleanup()
		{
			m_LoggedData.Clear();
			delete m_pControllers;
			m_pControllers = NULL;
		}

	} //namespace InputRecording
}  // namespace  AP

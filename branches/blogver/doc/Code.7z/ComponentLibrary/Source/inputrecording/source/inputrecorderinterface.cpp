#include "inputrecording/inputrecorderinterface.h"
#include "core/random.h"
#include "kernel/componentmanager.h"

namespace AP
{
	namespace InputRecording
	{

		InputRecorderInterface::InputRecorderInterface()
		{
			Reflection::Script::Register("InputRecorderInterface", Reflection::Instance(this), "Event Recorder Remote");
		}

		InputRecorderInterface::~InputRecorderInterface()
		{
			Reflection::Script::Unregister("InputRecorderInterface");
		}

		// return false if failed to set logfileName, true otherwise
		bool InputRecorderInterface::StartRecording(const char* logFileName)
		{
			UNUSED_PARAM(logFileName);
			AP_ASSERTFAIL("deprecated InputRecorderInterface::StartRecording");
			return false;
		}

		// return as string "success|filename|location|size"
		const char* InputRecorderInterface::StopRecording()
		{
			AP_ASSERTFAIL("deprecated InputRecorderInterface::StopRecording");
			return NULL;
		}

		void InputRecorderInterface::AbortRecording()
		{
			AP_ASSERTFAIL("deprecated InputRecorderInterface::AbortRecording");
		}

		bool InputRecorderInterface::StartPlayback(const char* logFileName)
		{
			UNUSED_PARAM(logFileName);
			AP_ASSERTFAIL("deprecated InputRecorderInterface::StartPlayback");
			return false;
		}

		void InputRecorderInterface::StopPlayback()
		{
			AP_ASSERTFAIL("deprecated InputRecorderInterface::StopPlayback");
		}

		// false == not in recording mode:
		// true == in recording mode
		bool InputRecorderInterface::RecordingStatus()
		{
// 			AP_ASSERTFAIL("deprecated InputRecorderInterface::RecordingStatus");
			return false;
		}

		// false == not in playback mode:
		// true == in playback mode
		bool InputRecorderInterface::PlaybackStatus()
		{
// 			AP_ASSERTFAIL("deprecated InputRecorderInterface::PlaybackStatus");
			return true;
		}
		
		int	InputRecorderInterface::TestRandomFakeFPS()
		{
			using Axiom::Random;
			Random random;
#if !DEBUG_SIM_RAND
			int randomFPS = random.RandInt(10, 120);
#else
			int randomFPS = random.RandInt(10, 120, __FILE__, __LINE__, true,AP::ComponentManager::GetInstance()->GetCurrentThreadId() );

#endif
			return randomFPS;
		}

		// Reflection:
		AP_TYPE(InputRecorderInterface)
			AP_COMMAND(StartRecording, "Activate event Logging, returns true if successful.  Usage: StartRecording(logName)")
			AP_COMMAND(StopRecording, "Deactivate event Logging. Returns file info when the recording is finished. Usage: StopRecording()")
			AP_COMMAND(AbortRecording, "Kill and active event Logging dumps the buffer to the log.  Usage: AbortRecording()")
			AP_COMMAND(StartPlayback, "Activate event Playback.  Usage: StartPlayback(fileName)")
			AP_COMMAND(StopPlayback, "Deactivate event Playback.  Usage: StopPlayback()")
			AP_COMMAND(RecordingStatus, "Returns true if currently in recording mode, false otherwise.")
			AP_COMMAND(PlaybackStatus, "Returns true if currently in playback mode, false otherwise.")
			AP_COMMAND(TestRandomFakeFPS, "Returns true if currently in playback mode, false otherwise.")
		AP_TYPE_END()

	} //namespace InputRecording
}  // namespace  AP

#ifndef _INPUTLOG_COMPONENT_H__
#define _INPUTLOG_COMPONENT_H__

#include "input/controllerinterface.h"
#include "inputrecording/packedcontrollerdata.h"
#include "inputrecording/recordereventmessages.h"

#include <files/common.h>
#include "kernel/component.h"
#include "collections/list.h"
#include "string/string.h"

namespace AP
{
	namespace InputRecording
	{ 
		using AP::Input::ControllerInterface;
		using AP::Input::CInterfaceBuffer;
		using AP::Input::CInterfaceState;

		// 	Facade class.  (maintains internal Has-A relationships that should not be publicly exposed.)
		// 
		// 	take all raw controller input at specified time slice intervals and dump that to a file
		// 	this file will later be piped back into the game for replay.
		class InputLogComponent: public AP::Component
		{
			public:
				InputLogComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~InputLogComponent();

			public:  
				// component methods:
				virtual void		OnInit( );
				virtual void		OnUpdate( );
				virtual void		OnShutdown( );

				static const unsigned int NO_CONTROLLERS = 0;

				enum InputLoggerState
				{
					LogState_Idle = -1,
					LogState_Recording,
					LogState_Paused,
				};

				enum InputLoggerActivationState
				{
					ActivationState_NONE = -1,
					ActivationState_RecorderActivate,
					ActivationState_RecorderDeactivate,
					ActivationState_PlayerActivate,
					ActivationState_PlayerDeactivate,
				};

				// logging functions:
				void				SetControllerInterfaces(int nControllers, ControllerInterface* controllerInterfaces);

			private:  //methods
				void				ActivateLogging(bool activateOn);
				void				ActivateControllerRecording(bool turnOn);
				void				PauseLogging(bool pauseOn);

				bool				SetOutFileName(Axiom::ShortString logName);
				void				WritePlatformHeader( );
				void				WriteLogHeaderInfo( );
				void				WriteInputBufferToLogFile( );
				bool				VerifyFileNameUnique(Axiom::ShortString fName);
// 				Axiom::String		GetLastLoggedFileInfo( );

				void				Cleanup( );

			private:  // members
				static const size_t		INPUT_BUFFER_SIZE = 1200;  //frame count before dump
				typedef					Axiom::Collections::StaticList<PackedControllerData, INPUT_BUFFER_SIZE> InputBufferType;

				struct LoggableController
				{
						ControllerInterface*				pCInterface;
						AP::Input::CInterfaceBuffer			data;
				};

				InputLoggerActivationState	m_LoggerActivationState;
				InputLoggerState			m_LoggingState;

				// logging
				bool						m_WasInit;

				InputBufferType				m_InputBuffer;

				unsigned int				m_ControllerCount;
				LoggableController*			m_pControllers;

				Axiom::ShortString										m_OutFileNameStr;
				Axiom::FileManager::VirtualFilePathString				m_OutFileName;
				
				// playback
				Axiom::EventMsgBoxHandle	m_ComponentMsgBox;
				void						HandleEvents();

				void						OnLogEvent_StartLogging(const Axiom::EventMsg* pMsg);
				void						OnLogEvent_StopLogging(const Axiom::EventMsg* pMsg);
				void						OnLogEvent_PauseLogging(const Axiom::EventMsg* pMsg);
				void						OnLogEvent_RecorderControllerSetup(const Axiom::EventMsg* pMsg);
		};

	} //namespace InputRecording
}  // namespace  AP

#endif

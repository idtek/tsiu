#ifndef _PACKED_CONTROLLER_DATA_H__
#define _PACKED_CONTROLLER_DATA_H__

#include "input/controllerinterface.h"

namespace AP
{
	namespace InputRecording
	{ 
		enum LoggedConsoleType 
		{ 
			LCT_ERROR=-1, 
			LCT_WIN32, 
			LCT_XBOX360, 
			LCT_PS3, 
			LCT_WII,
			LCT_TOOLS, 
			LCT_DIRECTX 
		};

		typedef Axiom::UInt32	HeaderPacket;

		class  PackedControllerData
		{
			public:

				PackedControllerData();
				PackedControllerData(const Axiom::Byte* byteData);

				void			Pack(const AP::Input::CInterfaceBuffer& unpackedData);
				void			Unpack(AP::Input::CInterfaceBuffer* unpackedData);

				static void			PackHeaderInfo(const int id, const int nAnalogButtons, const int nAnalogSticks, const int nDigitalButtons, HeaderPacket& packedHeader);
				static void			UnpackHeaderInfo(const HeaderPacket& packedHeader, int& id, int& nAnalogButtons, int& nAnalogSticks, int& nDigitalButtons);

				int					GetControllerID();
				const Axiom::Byte*	GetRawBytes() const { return ( reinterpret_cast<const Axiom::Byte*>(m_PackedData) ); };
				const size_t		GetDataSize() const { return (sizeof(m_PackedData)); };

				static const Axiom::uint		MAX_CONTROLLER_PACKETS = 10;

			private:
				Axiom::Byte					m_PackedData[MAX_CONTROLLER_PACKETS];
		}; // class PackedControllerData

	} //namespace InputRecording
}  // namespace  AP

#endif

#ifndef __INPUTRECORDING_SIGNAL_LIST_H__
#define __INPUTRECORDING_SIGNAL_LIST_H__

#include "kernel/coreglobalsignallist.h"

#define RECORDER_SIGNAL_LIST()\
	SIGNAL_LIST_ITEM( SigRecorderChannel						,SIGNAL_TYPE_GENERICEVENT, AP::SIGNALFLAG_DEFAULT )	\
	SIGNAL_LIST_ITEM( SigPlaybackChannel						,SIGNAL_TYPE_GENERICEVENT, AP::SIGNALFLAG_DEFAULT )	\
	SIGNAL_LIST_ITEM( SigStreakerReturnChannel						,SIGNAL_TYPE_GENERICEVENT, AP::SIGNALFLAG_DEFAULT )	\

namespace AP
{
	namespace InputRecording
	{

		class InputRecorderUnitTestSignalList
		{
			public:
// 				#ifndef SIGNAL_LIST_ITEM
// 				#define SIGNAL_LIST_ITEM(sig, sigType, flag) DECLARE_SIGNAL(sig,sigType)
// 							RECORDER_SIGNAL_LIST()
// 				#endif
// 				#undef SIGNAL_LIST_ITEM
		};

	} //namespace InputRecording
} //namespace AP

#endif

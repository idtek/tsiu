#ifndef _INPUTPLAYBACK_COMPONENT_H__
#define _INPUTPLAYBACK_COMPONENT_H__

#include "input/controllerinterface.h"
#include "inputrecording/packedcontrollerdata.h"
#include "inputrecording/recordereventmessages.h"

#include "kernel/component.h"
#include "collections/list.h"
#include "string/string.h"
#include <files/common.h>
#include <files/handle.h>

namespace Axiom
{
	namespace FileManager
	{
		class FileManager;
	}
}

namespace AP
{
	namespace InputRecording
	{ 
		using AP::Input::ControllerInterface;
		using AP::Input::CInterfaceBuffer;
		using AP::Input::CInterfaceState;

		class InputPlaybackComponent: public AP::Component
		{
			public:
				InputPlaybackComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~InputPlaybackComponent();

			public:   // component methods:
				virtual void		OnInit( );
				virtual void		OnUpdate( );
				virtual void		OnShutdown( );

				enum InputPlaybackState
				{
					PlaybackState_Idle = -1,
					PlaybackState_Playback,
					PlaybackState_Paused
				};

				enum InputPlaybackActivationState
				{
					Playback_ActivationState_NONE = -1,
					Playback_ActivationState_PlaybackActivate,
					Playback_ActivationState_PlaybackDeactivate,
				};

				void				SetControllerInterfaces(int nControllers, ControllerInterface* controllerInterfaces);

			private: //methods
				struct				ControllerVerificationPack;  //predeclare

				void				ActivatePlayback(bool activateOn);
				void				PausePlayback(bool pauseOn);
				void				ActivateControllerPlayback(bool turnOn);

				bool				SetPlaybackFileName( const Axiom::ShortString& logName);
				bool				VerifyFileExists( const Axiom::ShortString& fileName);
				void				ReadInputLogFile( );
				void				VerifyPlatformInfo(LoggedConsoleType console);
				bool				VerifyControllers(const ControllerVerificationPack* controllerInfos);

				void				Cleanup( );

			private:  //members
				static const unsigned int NO_CONTROLLERS = 0;
				
				struct ControllerVerificationPack
				{
					int						id;
					int						numAnalogSticks;
					int						numDigitalButtons;
					int						numAnalogButtons;
				};

				Axiom::uint										m_ControllerCount;
				ControllerInterface**							m_pControllers;
				Axiom::Collections::DynamicList<PackedControllerData> 	m_LoggedData;

				InputPlaybackState								m_PlaybackState;
				InputPlaybackActivationState					m_PlaybackActivationState;

				Axiom::FileManager::VirtualFilePathString		m_LogFileName;
				Axiom::FileManager::FileManager*				m_FileManager;
				
				AP::Input::CInterfaceBuffer						m_ControllerDataBuffer;

				size_t											m_Current;
				PackedControllerData*							m_pCurrentData;

				bool											m_WasInit;

				Axiom::EventMsgBoxHandle						m_ComponentMsgBox;
				void											HandleEvents();

				void											OnLogEvent_StartPlayback(const Axiom::EventMsg* pMsg);
				void											OnLogEvent_StopPlayback(const Axiom::EventMsg* pMsg);
				void											OnLogEvent_PausePlayback(const Axiom::EventMsg* pMsg);
				void											OnLogEvent_PlaybackControllerSetup(const Axiom::EventMsg* pMsg);
		};  //Class InputPlaybackComponent

	} //namespace InputRecording
}  // namespace  AP

#endif

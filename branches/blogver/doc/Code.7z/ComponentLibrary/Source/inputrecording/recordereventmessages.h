#ifndef _INPUTRECORDING_EVENT_MESSAGES_H___
#define _INPUTRECORDING_EVENT_MESSAGES_H___

#ifndef __INPUTRECORDING_MESSAGES_H
# include "kernel/messages.h"
#endif
#include <eventsystem/eventman.h>
#include "string/string.h"
#include "input/controllerinterface.h"

namespace AP
{
	namespace InputRecording
	{

		using Axiom::Log;
		using Axiom::Warn;
		using Axiom::Error;

		static const int FILE_NAME_SIZE = 50;

		class LogEvent_StartLogging : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_StartLogging )
					
				LogEvent_StartLogging():EventMsg(EVENT_GUID)
				{
				}
				
				LogEvent_StartLogging(const char* pFileName) : 
					EventMsg(EVENT_GUID)
				{
					m_FileNameStr = pFileName;
				}


				void SetFile(const char* pFileName)
				{
					m_FileNameStr = pFileName;
				}

				Axiom::ShortString 	m_FileNameStr;

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_StopLogging : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_StopLogging);//, Msg_Recorder_StopLogging )

				LogEvent_StopLogging() : 
					EventMsg(EVENT_GUID)
				{
				}

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_PauseLogging : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_PauseLogging);//, Msg_Recorder_PauseLogging )

				LogEvent_PauseLogging():EventMsg(EVENT_GUID){}

				LogEvent_PauseLogging(bool pauseOn) : 
					EventMsg(EVENT_GUID),
						m_Pause(pauseOn)
				{
				}

				bool m_Pause;
				
			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_RecorderControllerSetup: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_RecorderControllerSetup)//, Msg_Recorder_ControllerSetup )

				LogEvent_RecorderControllerSetup():	EventMsg(EVENT_GUID){}

				LogEvent_RecorderControllerSetup(int controllerCount, AP::Input::ControllerInterface* controllerInterfaces) : 
					EventMsg(EVENT_GUID)
				{
					m_ControllerCount = controllerCount;
					m_ControllerInterfaces = controllerInterfaces;
				}

				int									m_ControllerCount;
				AP::Input::ControllerInterface*		m_ControllerInterfaces;
		};

		//Playback events:
		class LogEvent_StartPlayback : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_StartPlayback);//, Msg_Recorder_StartPlayback )

				LogEvent_StartPlayback():EventMsg(EVENT_GUID){}

				LogEvent_StartPlayback(const char* pFileName) : 
					EventMsg(EVENT_GUID)
				{
					m_FileNameStr = pFileName;
				}

				Axiom::ShortString	m_FileNameStr;

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_StopPlayback : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_StopPlayback);//, Msg_Recorder_StopPlayback )

				LogEvent_StopPlayback() : 
					EventMsg(EVENT_GUID)
				{
				}
				
			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_PausePlayback : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_PausePlayback);//, Msg_Recorder_PausePlayback )

				LogEvent_PausePlayback():EventMsg(EVENT_GUID){}

				LogEvent_PausePlayback(bool pauseOn) : 
					EventMsg(EVENT_GUID),
						m_Pause(pauseOn)
				{
				}

				bool m_Pause;

			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		// this event should be created by the game and sent out to Streaker.
		class LogEvent_PlaybackFinished : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_PlaybackFinished);//, Msg_Recorder_PlaybackFinished )

				LogEvent_PlaybackFinished():EventMsg(EVENT_GUID){ m_error = false; }

				LogEvent_PlaybackFinished(bool error) : 
					EventMsg(EVENT_GUID),
						m_error(error)
				{
				}

				bool m_error;
				
			public:
				AP_DECLARE_POLYMORPHIC_TYPE();
		};

		class LogEvent_PlaybackControllerSetup: public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( LogEvent_PlaybackControllerSetup);//, Msg_Playback_ControllerSetup )

				LogEvent_PlaybackControllerSetup():	EventMsg(EVENT_GUID){}

				LogEvent_PlaybackControllerSetup(int controllerCount, AP::Input::ControllerInterface* controllerInterfaces) : 
					EventMsg(EVENT_GUID)
				{
					m_ControllerCount = controllerCount;
					m_ControllerInterfaces = controllerInterfaces;
				}

				int									m_ControllerCount;
				AP::Input::ControllerInterface*		m_ControllerInterfaces;
		};

	} //namespace InputRecording
}// namespace AP
#endif

#ifndef	_INPUTLOG_INTERFACE_H__
#define _INPUTLOG_INTERFACE_H__

#include "kernel/component.h"
#include "kernel/systemtimer.h"
#include "collections/list.h"
#include "string/string.h"
#include "core/singleton.h"
#include "reflection/script.h"
#include "kernel/messages.h"

/* 
	singleton class that exposes the Input recording and playback funtionality to 
	reflection for use in Streaker
*/
namespace AP
{
	namespace InputRecording
	{

		class InputRecorderInterface : public Axiom::Singleton<InputRecorderInterface>
		{
			AP_NON_COPYABLE( InputRecorderInterface );
			public:
				AP_DECLARE_TYPE();

				bool			StartRecording(const char* logFileName);
				const char*	StopRecording();
				void			AbortRecording();

				bool			StartPlayback(const char* logFileName);
				void			StopPlayback();

				bool			RecordingStatus();
				bool			PlaybackStatus();

				int				TestRandomFakeFPS();
				
			protected:
				friend class Axiom::Singleton<InputRecorderInterface>;
				InputRecorderInterface();
				~InputRecorderInterface();
		};

	} //namespace InputRecording
}  // namespace  AP
#endif

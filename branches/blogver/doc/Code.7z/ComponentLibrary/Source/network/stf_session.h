
#ifndef _STF_SESSION_H_
#define _STF_SESSION_H_

#include "network/networksession.h"

namespace Network
{

class STF_Session : public Network::Session
{
public:
	// C-tor
	STF_Session()
	{
		// 
	};

	// D-tor
	virtual ~STF_Session()
	{
		// 
	}

private:

	// Give session slice of CPU time
	virtual void Process()
	{
	}

	// Host session on local station.
	virtual bool HostSessionLocally_Impl(void)
	{
		return false;
	}

	// Create new session by joining session hosted on remote host.
	virtual bool Connect_Impl(const Network::Address& addr)
	{
		UNUSED_PARAM(addr);
		return false;
	}

	// Shutdown the session asynchronously.
	virtual void Shutdown_Impl(void)
	{
		return;
	}
};

} // namespace Network

#endif // _STF_SESSION_H_

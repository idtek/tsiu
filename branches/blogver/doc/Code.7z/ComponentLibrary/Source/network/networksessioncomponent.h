
#ifndef _NETWORKSESSIONCOMPONENT_H_
#define _NETWORKSESSIONCOMPONENT_H_

#include <kernel/component.h>
#include <marshaller/eventbuffer.h>
#include <marshaller/marshallereventmessages.h>

#include "network/networksession.h"
#include "network/barrier.h"

#define GAMEMARSHALLER_NBCACHEDEVENTS_MAX 25
#define MAX_EVENT_BUFFER_COUNT 5

namespace Network
{

//! This class implements Network Session Component. This component implements 
//! fully connected Peer-to-peer networked session used to create networked multi-player game.
class NetworkSessionComponent : public AP::Component
{
public:

	//! C-tor
	NetworkSessionComponent (Axiom::ConstStr name, AP::Kernel* kernel);		

	//! D-tor
	virtual	~NetworkSessionComponent();

	// Component methods:
	virtual void	OnInit();	
	//
	virtual void	OnUpdate();
	// 
	virtual void	OnShutdown();

private:

	// 
	void HandleEvents();
	// 
	void OnSessionInitializationEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnSessionPeerConnectionEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnSessionPeerDisconnectionEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnGameDatanEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnStartGameRoundEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	//
	void OnRemoteSimCrcEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnBarrierEnterEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	//
	void OnBarrierResetEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	//
	void OnGameInfoUpdateEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);
	// 
	void OnRemotePlayerInfoEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent);

	void PushFrameEvents();
	//
	void SyncGameInfoData();

	void HandleData( const Axiom::Char* data, Axiom::UInt size );
	void SendBufferedData();
	
	// Component's message box
	Axiom::EventMsgBoxHandle m_ComponentMsgBox;

	// Cache class prototype:
	template<typename T> class EventCache
	{
	public:

		EventCache(void);

		// Public methods
		void			AddRawEvent(T&);
		T*				GetNextEvent(void);
		inline Axiom::UInt	GetCount(void) const {return m_Count;}

	private:

		// Private data
		T	m_EventBufferCache[GAMEMARSHALLER_NBCACHEDEVENTS_MAX];
		Axiom::UInt m_BeginIndex;
		Axiom::UInt m_EndIndex;
		Axiom::UInt m_Count;
	};

	template< class T, typename CountMarkType, Axiom::UInt maxNum >
	class Buffer
	{
		AP_NON_COPYABLE( Buffer );

		//TODO - Do we have anything like std::numeric_traits to get the max value of an integer type?
		static const Axiom::UInt maxSize = sizeof( CountMarkType) * 256;
	public:

		Buffer()
		{
			Clear();
		}

		const CountMarkType	GetDataSize() const { return static_cast< CountMarkType >( mCurrent - mBuffer );}

		Axiom::UInt GetMaxSize() const { return maxSize; }

		Axiom::Bool CanFit( Axiom::UInt sizeOfData ) const
		{
			return ( mCount < maxNum && 
					( GetDataSize() + sizeOfData ) < GetMaxSize() );
		}

		Axiom::Bool Empty() const {return (mCurrent == mBuffer); }
	
		void Clear() 
		{ 
			mCount = 0;
			mCurrent = mBuffer;
			Axiom::MemorySet( mBuffer, 0, sizeof( mBuffer ) );
			Axiom::MemorySet( &mSizeMarks[ 0 ], 0, sizeof( mSizeMarks ) );
		}

		void Write( const T* data, Axiom::UInt sizeOfData )
		{
			AP_ASSERT( CanFit( sizeOfData ) );
			
			Axiom::MemoryCopy( mCurrent, data, sizeOfData );
			mCurrent += sizeOfData;

			mSizeMarks[ mCount ] = static_cast< Axiom::UChar >( sizeOfData );	// mSizeMarks[i] is the size of the ith chunk
			mCount++;

			AP_ASSERT( mCurrent < &mBuffer[ GetMaxSize() - 1 ] );
		}

		Axiom::UInt FillData( T* data )
		{
			AP_ASSERT( !Empty() );
			const T* startData = data;

			Axiom::MemoryCopy( data, &mCount, sizeof( mCount ) );
			data += sizeof( mCount );

			Axiom::MemoryCopy( data, &mSizeMarks[ 0 ], sizeof( mSizeMarks[ 0 ] ) * mCount );
			data += sizeof( mSizeMarks[ 0 ] ) * mCount;

			Axiom::MemoryCopy( data, mBuffer, GetDataSize() );
			data += GetDataSize();

			return static_cast< Axiom::UInt >( data - startData );
		}

	private:
		//Again, see above TODO
		T		mBuffer[ maxSize ];	///< buffer of data
		T*		mCurrent;			///< current position in buffer

		CountMarkType	mCount;		///< number of data chunks written
		Axiom::Collections::StaticArray< CountMarkType, maxNum > mSizeMarks;		///< begining of each data chunk
	};

	// Cache where all incoming events will be stored. 
	EventCache<AP::Marshaller::FrameEvent> m_RemoteEventCache;
	
	// Version of GameInfo after last update was sent out to remote stations.
	Axiom::UInt		m_nLastSentUpdateVer;
	// Game Info Version number after last update from remote station was applied.
	Axiom::UInt		m_nLastReceivedUpdateVer;
	// DataBuffer to buffer send data
	Buffer< Axiom::Char, Axiom::UChar, MAX_EVENT_BUFFER_COUNT > mDataBuffer;
	// Last time buffer sent
	Axiom::TimeAbsolute mLastTimeSent;
};


} // namespace Network

#endif // _NETWORKSESSIONCOMPONENT_H_



#ifndef _NETWORKSESSIONEVENTS_H_
#define _NETWORKSESSIONEVENTS_H_

#include <eventsystem/eventman.h>
#include <core/types.h>
#include "network/networksessioncomponent.h"

namespace Network
{

//! This file defines set of Event Messages used by Network Session Component.
namespace Events
{	
	// This is a request to Network Session Component to start hosting new network session.
	class SessionInitialize : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionInitialize)
		//! Default c-tor
		SessionInitialize() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
		// If this address is set, session will be created by joining host it points to.
		Network::Address	m_address;
	};

	// This is a request to Network Session Component to start hosting new network session.
	class SessionInitializationEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionInitializationEvent)
		//! Default c-tor
		SessionInitializationEvent() 
			: EventMsg(EVENT_GUID), 
			m_bStatus(true)
		{
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
		
		// 
		bool	m_bStatus;
	};


	// This is a request to Network Session Component to shutdown.
	class SessionShutdown : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionShutdown)
		//! Default c-tor
		SessionShutdown() : EventMsg(EVENT_GUID)
		{
			// 
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
	};	

	// This is a request to Network Session Component to shutdown.
	class SessionNewDataEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionNewDataEvent)
		//! Default c-tor
		SessionNewDataEvent() 
			: EventMsg(EVENT_GUID), 
			m_uiChannel(0)
		{
			// 
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
		// Channel on which data were received.
		unsigned int	m_uiChannel;
	};	


	// 
	class SessionPeerConnectionEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionPeerConnectionEvent)
			//! Default c-tor
			SessionPeerConnectionEvent() 
			: EventMsg(EVENT_GUID),
			m_bStatus(true),
			m_bIsLocal(false),
			m_bIsHost(false)
		{
			// 
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
		// Connection status.
		bool	m_bStatus;
		// Is this event for local peer?
		bool	m_bIsLocal;
		// Is this event for host?
		bool	m_bIsHost;
	};


	// 
	class SessionPeerDisconnectionEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionPeerDisconnectionEvent)
			//! Default c-tor
		SessionPeerDisconnectionEvent() 
			: EventMsg(EVENT_GUID),
			m_bStatus(true),
			m_bIsLocal(false),
			m_bIsHost(false)
		{
			// 
		}
		AP_DECLARE_POLYMORPHIC_TYPE();
		// Connection status.
		bool	m_bStatus;
		// Is this event for local peer?
		bool	m_bIsLocal;
		// Is this event for host?
		bool	m_bIsHost;
	};


	// Notifies network session component that game can be started.
	class SessionStartGameRound : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionStartGameRound)

		//! Default c-tor
		SessionStartGameRound() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();

		// Reserved string value.
		Axiom::StaticString<100>	mGameIdentifier;
		int							mGameType;
	};


	// This event will be send to game component to tell it when new on-line match can be started.
	class SessionStartOnlineMatchEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(SessionStartOnlineMatchEvent)

		//! Default c-tor
		SessionStartOnlineMatchEvent() 
			: EventMsg(EVENT_GUID),
			m_bStatus(true)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();
		// Reserved string value.
		// Axiom::StaticString<32, char> m_strReserved;
		bool						m_bStatus;
		Axiom::StaticString<100>	mGameIdentifier;
		int							mGameType;
	};


	// Notifies when distributed barrier condition is satisfied.
	class WaitOnDistributedBarrier : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(WaitOnDistributedBarrier);

		//! Default c-tor
		WaitOnDistributedBarrier() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();
		// Barrier's name
		Axiom::ShortString	m_name;
	};


	// Notifies when distributed barrier condition is satisfied.
	class BarrierEnterEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(BarrierEnterEvent)

		//! Default c-tor
		BarrierEnterEvent() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();
		// Barrier's name
		Axiom::ShortString	m_name;
	};


	// Notifies when distributed barrier was reset.
	class BarrierResetEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(BarrierResetEvent)

		//! Default c-tor
		BarrierResetEvent()
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();
		// Barrier's name
		Axiom::ShortString	m_name;
		//
		int					m_status;
	};

	// Delivers CRC from remote station.
	class RemoteSyncFrameCrcEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(RemoteSyncFrameCrcEvent)

		//! Default c-tor
		RemoteSyncFrameCrcEvent() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();

		// Calculated CRC value _after_ frame was simulated
		unsigned int	mCRC;
		// Number of corresponding simulation frame.
		int				mFrameTick;
		// Seed value _after_ frame was simulated.
		int				mSeed;
		// Id for station on which frame was simulated.
		Axiom::UInt64	m_nSrcStationId;
	};

	// 
	class GameInfoUpdateEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(GameInfoUpdateEvent)

		//! Default c-tor
		GameInfoUpdateEvent() 
			: EventMsg(EVENT_GUID)
		{
			// 
		}

		AP_DECLARE_POLYMORPHIC_TYPE();
		
		// Current version of GameInfo.
		Axiom::UInt m_nGameInfoVersion;
	};	

	class NetworkPauseEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(NetworkPauseEvent)

		//! Default c-tor
		NetworkPauseEvent() 
			: EventMsg(EVENT_GUID),
			mControllerID( -1 )
		{
		}

		NetworkPauseEvent( Axiom::Int vid ) 
			: EventMsg(EVENT_GUID),
			mControllerID( vid )
		{
		}

		Axiom::Int GetControllerId() const { return mControllerID;}

	private:
		Axiom::Int mControllerID;
	};

	class NetworkResumeEvent : public Axiom::EventMsg
	{
	public:
		EVENT_MSG_GUID(NetworkResumeEvent)

		NetworkResumeEvent() 
			: EventMsg(EVENT_GUID)
		{
		}
	};

} // end of namespace Events

} // end of namespace Network


#endif // _NETWORKSESSIONEVENTS_H_

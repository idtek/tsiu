
#ifndef _NETWORK_SESSION_H_
#define _NETWORK_SESSION_H_

#include <eventsystem/eventman.h>
#include "network/networksessionmanager.h"

#include "core/uuid.h"
#include "core/referenced.h"

#include "collections/queue.h"
#include "collections/array.h"

namespace Network
{

// 64 bit integer that will uniquely identify station within single network session.
typedef Axiom::UInt64 StationId;

//! Internal message types.
enum MsgTypeId
{
	MSG_INVALID				= 0x0,
	MSG_DISCONNECT			= 0x1,	// disconnection request
	MSG_DISCONNECT_ACK		= 0x2, 
	MSG_GAMEDATA			= 0x3,
	MSG_BARRIER_OPERATION	= 0x4, // Operation on distributed barrier.
	MSG_START_GAMEROUND		= 0x5,
	MSG_SIMCRC				= 0x6,
	MSG_GAMEINFO_UPDATE		= 0x8,
	MSG_PLAYERINFO			= 0x9,
	// Not used
	ENSURE8BIT				= 0x7F
};


// This class implements fully connected Peer-to-peer networked session used in multi-player mode.
class Session 
{
public:

	//! 
	enum SessionType
	{
		DEFAULT_SESSION_TYPE,
		// ...
	};

	//!
	enum ConnectionStatus
	{
		STATUS_SUCCESS			= 0x0,
		STATUS_ERROR			= 0x1,
		STATUS_FAILURE			= 0x2
	};

	// Internal events used by Network Session.
	class InternalEvent : public Axiom::Referenced
	{
	public:
		//!  
		enum EvtType
		{
			SE_INVALID				= 0x0,
			SE_NEWDATAEVENT			= 0x1,
			SE_CONNECTIONEVENT		= 0x2,
			SE_DISCONNECTIONEVENT	= 0x3,
			SE_ERROREVENT			= 0x4,
			SE_STATUSCHANGEEVENT	= 0x5,	//!< Status change, occurs when station changes its status from client to host.
			SE_INITEVENT			= 0x7,
			SE_GAMEDATA				= 0x8,
			SE_BARRIERRESET			= 0x9,
			SE_BARRIERENTER			= 0xA,
			SE_STARTGAMEROUND		= 0xB,
			SE_REMOTESIMCRC			= 0xC,
			SE_GAMEINFOUPDATE		= 0xD,
			SE_REMOTEPLAYERINFO		= 0xE,

		};

		// C-tor
		InternalEvent(EvtType evttype) : m_type(evttype)
		{
			// 
		};

		// D-tor
		virtual ~InternalEvent()
		{
			// Do nothing
		};

		EvtType TypeOf() const
		{
			return m_type;
		}

	private:
		// 
		EvtType	m_type;
	};


	// Default c-tor
	Session();

	// D-tor
	virtual ~Session();

	// Give session slice of CPU time
	void Update();

	//! Send <size> bytes from buffer <data> to station <to>.
	virtual bool Send(MsgTypeId type, const Axiom::Char* data, Axiom::UInt size ) = 0;

	//! 
	virtual bool BarrierWait(const char* szName) = 0;
	//!
	virtual void ResetBarrier(const char* szName) = 0;
	
	// Shutdown the session asynchronously.
	virtual void Shutdown(void) = 0; 

	//!	Returns next SessionEvent
	Axiom::SmartPtr<Network::Session::InternalEvent> GetEvent(void)
	{
		if (!m_eventQueue.IsEmpty())
			return m_eventQueue.PopFront();
		else
			return Axiom::SmartPtr<Network::Session::InternalEvent>(0);
	};

	//! Virtual C-tor for the session.
	static Network::Session* Create(SessionType sessionType, const Network::Address& address);

	//! Returns number of active peers in session.
	virtual int GetNumSessionMembers() = 0;

	//! Returns station Id for local station.
	virtual int GetSessionMyMemberId() = 0;

	//! Returns station id of i-th station.
	virtual int GetSessionMemberId(int index) = 0;

protected:

	//! Places SessionEvent into internal event queue
	void PostEvent(Network::Session::InternalEvent* pEvent)
	{
		// Conversion c-tor will place pEvent into SmartPtr<Network::SessionEvent>
		m_eventQueue.PushBack(pEvent);
		AP_ASSERT(!m_eventQueue.IsFull());
	}

private:
	
	// Give session slice of CPU time
	virtual void Process() = 0;

	// Internal event queue.
	Axiom::Collections::Queue<Network::Session::InternalEvent*, SESSION_INTERNAL_QUEUE_SIZE> m_eventQueue;
};


#define MAKE_NETWORK_FACTORY_METHOD(session) \
	Network::Session* Network::Session::Create(Network::Session::SessionType sessionTypeType) { return AP_NEW( Axiom::Memory::ONLINE_HEAP, session ); }


//
class SessionInitializationEvent : public Network::Session::InternalEvent
{
public:
	SessionInitializationEvent(bool bStatus)
		: Network::Session::InternalEvent(SE_INITEVENT),
		m_bStatus(bStatus)
	{
		// Do nothing
	}

	bool	m_bStatus;
};


// Specific Session's Internal Events
class ConnectionEvent : public Network::Session::InternalEvent
{
public:
	// C-tor
	ConnectionEvent(StationId station, bool bStatus, bool bLocal, bool bHost, Axiom::Collections::Array<char>& peerData)
		: Network::Session::InternalEvent(SE_CONNECTIONEVENT),
		m_stationId(station),
		m_bStatus(bStatus),
		m_bIsLocal(bLocal),
		m_bIsHost(bHost),
		m_customPeerData(peerData)
	{
		// Do nothing	 
	}

	// Station Id for newly connected station.
	StationId					m_stationId;
	// Connection status.
	bool						m_bStatus;
	// Is this a connection event for local station.
	bool						m_bIsLocal;
	//! Is this a connection event for host.
	bool						m_bIsHost;
	// Custom peer data, received from remote station as part of connection request.
	Axiom::Collections::Array<char> m_customPeerData;
};


// 
class DisconnectionEvent : public Network::Session::InternalEvent
{
public:
	// C-tor
	DisconnectionEvent(StationId station, bool bStatus, bool bLocal, bool bHost) 
		: Network::Session::InternalEvent(SE_DISCONNECTIONEVENT),
		m_stationId(station),
		m_bStatus(bStatus),
		m_bIsLocal(bLocal),
		m_bIsHost(bHost)
	{
		// Do nothing
	}

	// Station Id for newly connected station.
	StationId					m_stationId;
	// Connection status.
	bool						m_bStatus;
	// Is this a connection event for local station.
	bool						m_bIsLocal;
	//! Is this a connection event for host.
	bool						m_bIsHost;

};

class DataEvent : public Session::InternalEvent
{
public:
	DataEvent( InternalEvent::EvtType eventType, StationId station, const char* pData, size_t dataSize ) : 
		Network::Session::InternalEvent( eventType ),
		m_stationId( station )
	{
		AP_ASSERT(dataSize <= sizeof(m_data));
		m_payloadSize = ( dataSize < sizeof(m_data) ) ? dataSize : sizeof(m_data);
		Axiom::MemoryCopy(m_data, pData, m_payloadSize);	
	}

	virtual ~DataEvent(){}

	const Axiom::Char*	GetData() const {return m_data;}
	size_t				GetDataSize() const {return m_payloadSize;}
	StationId			GetStationId() const {return m_stationId;}

private:
	// Station Id for newly connected station.
	StationId					m_stationId;
	//
	Axiom::Char					m_data[8192];
	//
	size_t						m_payloadSize;

};

//!
class GameDataEvent : public DataEvent
{
public:
	// C-tor
	GameDataEvent( StationId station, const char* pData, size_t dataSize ) : 
		DataEvent( SE_GAMEDATA, station, pData, dataSize )
	{		
	}
};


//!
class StartGameRoundEvent : public DataEvent
{
public:
	// C-tor
	StartGameRoundEvent( StationId station, const char* pData, size_t dataSize ) 
		: DataEvent( SE_STARTGAMEROUND, station, pData, dataSize )
	{
	}
};

//!
class GameInfoUpdateEvent : public DataEvent
{
public:
	// C-tor
	GameInfoUpdateEvent( StationId station, const char* pData, size_t dataSize ) 
		: DataEvent( SE_GAMEINFOUPDATE, station, pData, dataSize )
	{
	}
};

//!
class RemoteSimCrcEvent : public DataEvent
{
public:
	// C-tor
	RemoteSimCrcEvent( StationId station, const char* pData, size_t dataSize ) 
		: DataEvent( SE_REMOTESIMCRC, station, pData, dataSize )
	{
	}
};

//!
class RemotePlayerInfoEvent : public DataEvent
{
public:
	// C-tor
	RemotePlayerInfoEvent( StationId station, const char* pData, size_t dataSize ) 
		: DataEvent( SE_REMOTEPLAYERINFO, station, pData, dataSize )
	{
	}
};

} // namespace Network

#endif // _NETWORK_SESSION_H_

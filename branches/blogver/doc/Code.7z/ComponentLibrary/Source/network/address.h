
#ifndef _ADDRESS_H_
#define _ADDRESS_H_

#include "Network/configuration.h"

namespace Network
{
	// Address base class
	class Address
	{
	public:
		
		// This maybe questionable, because it is a dupe for dynamic type identification.
		enum AddressType
		{
		INVALID_ADDR_TYPE	= 0x0,
		ADDR_TYPE_INET		= 0x1,	// Internet address
		ADDR_TYPE_XNA		= 0x2,	// MS Live 360 secure address
		ADDR_TYPE_AGORA		= 0x3,

		ENSURE32BIT			= 0x7FFFFFFF
		};		

		//! Returns address type.
		virtual AddressType TypeOf() const
		{
			return m_addressType;
		};

		virtual bool IsLocal() const
		{
			return m_bLocal;
		}

		//! Returns address size
		size_t Size() const
		{
			return m_addressType;
		};

		//! D-tor
		virtual ~Address()
		{
			// do nothing
		};

		//! Returns hash for address.
		unsigned long hash();

	public:
		//! c-tor
		Address(AddressType type = INVALID_ADDR_TYPE, bool bLocal = true) 
			: m_addressType(type),
			m_ulSerializedAddressSize(0),
			m_bLocal(bLocal)
		{
			// 
		}

	protected:

		// Address type.
		AddressType		m_addressType;
		// Address size
		size_t			m_ulSerializedAddressSize;
		//
		char			m_abSerializedAddress[90];
		//
		bool			m_bLocal;
	};

	//  
	static Address Null_Address(Address::INVALID_ADDR_TYPE);

#ifdef NETWORK_HAS_WINSOCK2 

	// Internet address
	class AddrINET : public Network::Address
	{
	public:
		//! C-tor, creates address from string formatted as "10.10.10.2:5667"
		AddrINET(const char* cpAddressString);
		//! Creates address from ip specified as unsigned long and port number
		AddrINET(unsigned long ip, unsigned short port);
	private:
	};

#endif

#ifdef NETWORK_HAS_MSLIVE360

	// MS Live secure address
	class AddrXNET : public Network::Address
	{
	public:
		//! Creates address from ip specified as unsigned long and port number
		AddrXNET(const XNADDR& xnaddr, const XNKID& kid, const XNKEY& knkey)
			: Address(ADDR_TYPE_XNA)
		{
			// TODO: Serialize
		}
	private:
		// 
	};

#endif // NETWORK_HAS_MSLIVE360

} // namespace Network

#endif // _ADDRESS_H_

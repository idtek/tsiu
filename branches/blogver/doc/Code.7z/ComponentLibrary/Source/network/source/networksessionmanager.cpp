
#include "network/networksessionmanager.h"
#include "network/networksession.h"
#include "network/stf_session.h"

namespace Network
{

NetworkSessionManager* NetworkSessionManager::m_pSingletonInstance = 0;

// C-tor
NetworkSessionManager::NetworkSessionManager()
{
	m_pCurrentSession = 0;	
	m_nGameInfoVersion = 0;
	m_nActualGameInfoSize = 0;
}

// Returns instance of singleton object. This function uses Double-Checked Locking Optimization pattern.
NetworkSessionManager* NetworkSessionManager::Instance()
{
	if (NetworkSessionManager::m_pSingletonInstance == 0)
	{
		// We only acquire lock per singleton instantiation.
		static Axiom::Thread::Mutex singletonMutex;
		if (!singletonMutex.TryLock())
			return 0;

		if (NetworkSessionManager::m_pSingletonInstance == 0)
		{
			NetworkSessionManager::m_pSingletonInstance = AP_NEW(Axiom::Memory::ONLINE_HEAP, NetworkSessionManager());
		}
	}

	return NetworkSessionManager::m_pSingletonInstance;
};


//! 
bool NetworkSessionManager::Initialize(/* config parameters ?*/)
{
	// TODO: Global network session manager initialization code, may include reading config 
	// parameters from config file, checking for command line options, reading 
	// version number from application and calculating CRC of data or executable etc.
	return true;
}


// Transfers the ownership of session to Session Manager. 
bool NetworkSessionManager::CreateSession(const Network::Address& addr)
{
	Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);

	if (m_pCurrentSession == 0)
	{
		// AP_ASSERT(m_pCurrentSession == 0);
		m_pCurrentSession = Network::Session::Create(Network::Session::DEFAULT_SESSION_TYPE, addr);
		// TODO: call Open on session and give it pointer to SessionManager (itself).
		// Reset GameInfo version number for each new session.
		m_nGameInfoVersion = 0;

		return (m_pCurrentSession != 0);
	}
	else
	{
		AP_ASSERT(0);
		// m_pCurrentSession->Shutdown();
		return false;
	}	
}


// 
bool NetworkSessionManager::Update()
{
	if (m_pCurrentSession != 0)
	{
		m_pCurrentSession->Update();
	}

	return true;
}


//! Destroys all active sessions.
void NetworkSessionManager::ResetAll()
{
	Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
	AP_DELETE(m_pCurrentSession);	
	m_pCurrentSession = NULL;
};


// 
void NetworkSessionManager::SetGameInfo(const char* pData, size_t nDataSize, int nVersion)
{
	UNUSED_PARAM(nVersion);
	AP_ASSERT(nDataSize > 0 && nDataSize <= MAX_GAME_INFO_SIZE);
	Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);

	++m_nGameInfoVersion;

	// TODO: Merge conflicting updates.
	m_nActualGameInfoSize = nDataSize;
	Axiom::MemoryCopy(&m_GameInfoRawData[0], pData, nDataSize);
}


//
bool NetworkSessionManager::GameInfo(char* pData, size_t* pDataSize) const
{
	AP_ASSERT(pData != 0 && *pDataSize >= m_nActualGameInfoSize);
	Axiom::Thread::ScopedLock<Axiom::Thread::Mutex> slock(m_pSessionMutex);
	if (m_nActualGameInfoSize > 0)
	{
		Axiom::MemoryCopy(pData, &m_GameInfoRawData[0], m_nActualGameInfoSize);
		*pDataSize = m_nActualGameInfoSize;
		return true;
	}
	else
	{
		return false;
	}		
}

} // namespace Network

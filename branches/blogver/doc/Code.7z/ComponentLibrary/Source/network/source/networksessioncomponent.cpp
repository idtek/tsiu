
#include "network/networksessioncomponent.h"
#include "network/networksessionevents.h"
#include "network/networksessionmanager.h"
#include "network/networksession.h"

#include "lobby/lobbyevents.h"

#include "marshaller/marshallereventmessages.h"
#include "input/virtualcontrollermap.h"

namespace Network
{

// C-tor
NetworkSessionComponent::NetworkSessionComponent( Axiom::ConstStr name, AP::Kernel* kernel ) : 
	Component( name, kernel ),
    m_ComponentMsgBox( NULL ),
	m_nLastSentUpdateVer( 0 ),
	m_nLastReceivedUpdateVer( 0 )
{
	mLastTimeSent = Axiom::TimeAbsolute::GetSystemTime();
}


// D-tor
NetworkSessionComponent::~NetworkSessionComponent()
{
}


void NetworkSessionComponent::OnInit()
{
	m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Network");
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionInitialize::EVENT_GUID);		
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionShutdown::EVENT_GUID);

	// Lobby Events:
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyInitializationEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyEnterSessionEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbySessionExitEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Lobby::Events::LobbyPlayerInfoEvent::EVENT_GUID);

	// Marshaller events:
	m_ComponentMsgBox->RegisterListenBroadcastEvent(AP::Marshaller::Events::LocalMarshallFrameEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(AP::Marshaller::Events::RemotePauseEvent::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(AP::Marshaller::Events::SyncFrameCRCEvent::EVENT_GUID);	
	m_ComponentMsgBox->RegisterListenBroadcastEvent(AP::Marshaller::Events::MarshallerFrameInfoEvent::EVENT_GUID);	

	// Distributed Barrier events:
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::WaitOnDistributedBarrier::EVENT_GUID);
	m_ComponentMsgBox->RegisterListenBroadcastEvent(Network::Events::SessionStartGameRound::EVENT_GUID);	

	// Game flow events
	m_ComponentMsgBox->RegisterListenBroadcastEvent( Events::NetworkResumeEvent::EVENT_GUID );
}


void NetworkSessionComponent::HandleEvents()
{
	const Axiom::UInt numEvents = m_ComponentMsgBox->GetNumEvents();

	for( Axiom::UInt i = 0; i < numEvents; ++i )
	{
		const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);		
		const Axiom::EventMsgId msgId = pMsg->GetGuidID();

		if (msgId == Network::Events::SessionInitialize::EVENT_GUID)
		{
			// Initialization:			
			const Network::Events::SessionInitialize* pInitRequest = pMsg->GetClass<Network::Events::SessionInitialize>();
			if (pInitRequest != 0)
			{
				AP_ASSERT(pInitRequest->m_address.TypeOf() == Network::Address::ADDR_TYPE_AGORA);
				Axiom::Log("session", "%s session initialization requested.", (pInitRequest->m_address.IsLocal() ? "Local" : "Remote"));
				if (Network::NetworkSessionManager::Instance()->CreateSession(pInitRequest->m_address))
				{
					AP::Marshaller::Events::MarshallerOnlineStatusEvent evt( true );
					m_ComponentMsgBox->SendEvent(&evt);
				}
				else
				{					
					Network::Events::SessionInitializationEvent evt;
					evt.m_bStatus = false;
					m_ComponentMsgBox->SendEvent(&evt);
				}
			}			
		}				
		else if (msgId == Lobby::Events::LobbyEnterSessionEvent::EVENT_GUID)
		{
			// Initialization:
			const Lobby::Events::LobbyEnterSessionEvent* pEntryEvent = pMsg->GetClass<Lobby::Events::LobbyEnterSessionEvent>();
			if (pEntryEvent != 0 && pEntryEvent->m_bStatus == true)
			{				
				Axiom::Log("session", "%s session entry notification received.", (pEntryEvent->m_SessionHostAddress.IsLocal() ? "Local" : "Remote"));
				Network::NetworkSessionManager::Instance()->CreateSession(pEntryEvent->m_SessionHostAddress);
			}			

			AP::Marshaller::Events::MarshallerOnlineStatusEvent evt( pEntryEvent->m_bStatus );
			m_ComponentMsgBox->SendEvent(&evt);
		}		
		else if (msgId == Network::Events::SessionStartGameRound::EVENT_GUID)
		{
			const Network::Events::SessionStartGameRound* pStartEvent = pMsg->GetClass<Network::Events::SessionStartGameRound>();
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();
			Axiom::Log("session", "Start game round request received.");
			if (pSession != 0)
			{
				// TODO: Get configuration for MP game session. i.e Network::NetworkSessionManager::Instance()->CurrentSessionConfig()
				char dummy_config[] = "********** DUMMY CONFUGURATION DATA ********";
				pSession->Send(MSG_START_GAMEROUND, dummy_config, sizeof(dummy_config));

				Network::Events::SessionStartOnlineMatchEvent startGameEvent;
				startGameEvent.m_bStatus = true;
				startGameEvent.mGameIdentifier = pStartEvent->mGameIdentifier;
				startGameEvent.mGameType = pStartEvent->mGameType;
				m_ComponentMsgBox->SendEvent(&startGameEvent);	

				//Make sure the marshaller knows we are online
				AP::Marshaller::Events::MarshallerOnlineStatusEvent evt( true );
				m_ComponentMsgBox->SendEvent(&evt);
			}
			else
			{
				AP_ASSERT(0); // - need session to start multi-player game!
				Network::Events::SessionStartOnlineMatchEvent startGameEvent;
				startGameEvent.m_bStatus = false;
				m_ComponentMsgBox->SendEvent(&startGameEvent);	
			}
		}
		else if (msgId == Lobby::Events::LobbyPlayerInfoEvent::EVENT_GUID)
		{
			const Lobby::Events::LobbyPlayerInfoEvent* pPlayerInfoEvt = pMsg->GetClass<Lobby::Events::LobbyPlayerInfoEvent>();
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();
			if (pSession != 0)
			{
				pSession->Send(MSG_PLAYERINFO, reinterpret_cast<const char*>(&pPlayerInfoEvt->m_acRawData[0]), pPlayerInfoEvt->m_nRawDataSize);
			}	
			else
			{
				AP_ASSERT(0);
			}
		}
		else if (msgId == Network::Events::WaitOnDistributedBarrier::EVENT_GUID)
		{
			const Network::Events::WaitOnDistributedBarrier* pWaitRequest = pMsg->GetClass<Network::Events::WaitOnDistributedBarrier>();
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();
			AP_ASSERT(!pWaitRequest->m_name.IsEmpty());

			if (pSession != 0 && pSession->BarrierWait(pWaitRequest->m_name.AsChar()))
			{								
				// Do nothing, 
			}
			else
			{			
				Axiom::Log("session", "Station entering distributed barrier \"%s\".", pWaitRequest->m_name.AsChar());
				Network::Events::BarrierEnterEvent evt;
				evt.m_name = pWaitRequest->m_name.AsChar();
				m_ComponentMsgBox->SendEvent(&evt);				
			}
		}
		// Sending marshaller frame:
		else if (msgId == AP::Marshaller::Events::LocalMarshallFrameEvent::EVENT_GUID)
		{
			const AP::Marshaller::Events::LocalMarshallFrameEvent* nextMarshFrame = pMsg->GetClass<AP::Marshaller::Events::LocalMarshallFrameEvent>();
			
			AP_ASSERT(nextMarshFrame->mFrameEvent->IsWriteLock() != 0);

			HandleData( reinterpret_cast< const Axiom::Char*>( nextMarshFrame->mFrameEvent->mStartAddr ), nextMarshFrame->mFrameEvent->mSize );

			nextMarshFrame->mFrameEvent->SetWriteLock( 0 );
			
		}
		// CRC Event generated by local Core Simulation Component.
		else if (msgId == AP::Marshaller::Events::SyncFrameCRCEvent::EVENT_GUID)
		{
			const AP::Marshaller::Events::SyncFrameCRCEvent* crcEvent = pMsg->GetClass<AP::Marshaller::Events::SyncFrameCRCEvent>();
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();
			if (pSession != 0)
			{	
				char temp_[128] = {0};
				unsigned int wPos = 0;

				//DAY 3/28/2008 10:06:02 AM
				AP_ASSERT( sizeof(crcEvent->mCRC) + sizeof(crcEvent->mFrameTick) + sizeof(crcEvent->mSeed) < 128 );

				Axiom::MemoryCopy(&temp_[wPos], &crcEvent->mCRC, sizeof(crcEvent->mCRC)); wPos += sizeof(crcEvent->mCRC);
				Axiom::MemoryCopy(&temp_[wPos], &crcEvent->mFrameTick, sizeof(crcEvent->mFrameTick)); wPos += sizeof(crcEvent->mFrameTick);
				Axiom::MemoryCopy(&temp_[wPos], &crcEvent->mSeed, sizeof(crcEvent->mSeed)); wPos += sizeof(crcEvent->mSeed);
				pSession->Send(MSG_SIMCRC, &temp_[0], wPos);
			}		
		}
		else if (msgId == Lobby::Events::LobbySessionExitEvent::EVENT_GUID)
		{			
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();			
			if (pSession != 0)
			{
				Axiom::Log("session", "Session exit notification received.");
				pSession->Shutdown();

				//Make sure the marshaller knows we are offline
				AP::Marshaller::Events::MarshallerOnlineStatusEvent evt( false );
				m_ComponentMsgBox->SendEvent(&evt);
			}
		}
		else if (msgId == Lobby::Events::LobbyInitializationEvent::EVENT_GUID)
		{
			Axiom::Log("session", "Lobby initialization event received.");
		}
		else if (msgId == Network::Events::SessionShutdown::EVENT_GUID)
		{
			// Shutdown:
			Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();			
			if (pSession != 0)
			{
				Axiom::Log("session", "Shutdown request received, executing...");
				pSession->Shutdown();

				//Make sure the marshaller knows we are online
				AP::Marshaller::Events::MarshallerOnlineStatusEvent evt( false );
				m_ComponentMsgBox->SendEvent(&evt);
			}
			else
			{
				Axiom::Log("session", "Shutdown request received, no active sessions.");
				// There is no active lobby in a system - just send completion event.
				Network::Events::SessionInitializationEvent evt;

				evt.m_bStatus = false;
				m_ComponentMsgBox->SendEvent(&evt);
			}
		}	
		else if( msgId == AP::Marshaller::Events::RemotePauseEvent::EVENT_GUID )
		{
			const AP::Marshaller::Events::RemotePauseEvent* remPause = pMsg->GetClass< AP::Marshaller::Events::RemotePauseEvent >();
			const Axiom::Bool isRemotePause = !AP::Input::VirtualControllerMap::GetInstance()->IsLocalVirtualControllerId( remPause->GetControllerId() );

			if( isRemotePause )
			{				
				Network::Events::NetworkPauseEvent pauseEvent( remPause->GetControllerId() );
				m_ComponentMsgBox->SendEvent( &pauseEvent );

				AP::Marshaller::Events::MarshallerPauseEvent marPauseEvent( isRemotePause );
				m_ComponentMsgBox->SendEvent( &marPauseEvent );
			}
		}
		else if( msgId == Network::Events::NetworkResumeEvent::EVENT_GUID )
		{
			AP::Marshaller::Events::MarshallerResumeEvent resEvent;
			m_ComponentMsgBox->SendEvent( &resEvent );
		}
		else if( msgId == AP::Marshaller::Events::MarshallerFrameInfoEvent::EVENT_GUID )
		{
			//const AP::Marshaller::Events::MarshallerFrameInfoEvent* theEvent = pMsg->GetClass< AP::Marshaller::Events::MarshallerFrameInfoEvent >();
		}
	}	

	m_ComponentMsgBox->ClearOutbox();
	m_ComponentMsgBox->ClearInbox();
}


// This method called on every tick.
void NetworkSessionComponent::OnUpdate()
{
	// Handle all incoming Axiom events
	HandleEvents();

	// Send GameInfo if changed since last time.
	SyncGameInfoData();

	// Give some CPU time to lobby
	Network::NetworkSessionManager::Instance()->Update(); 

	Network::Session* pSession = 0;
	// Poll internal lobby events from active lobby object and process them
	while ((pSession = Network::NetworkSessionManager::Instance()->CurrentSession()) != 0)
	{	
		Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent = pSession->GetEvent();		
		if (ptrEvent.IsValid())
		{
			Network::Session::InternalEvent::EvtType sessionEvtType = ptrEvent->TypeOf();
			switch(sessionEvtType)
			{
			case Network::Session::InternalEvent::SE_INITEVENT:
				OnSessionInitializationEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_CONNECTIONEVENT:
				OnSessionPeerConnectionEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_DISCONNECTIONEVENT:
				OnSessionPeerDisconnectionEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_GAMEDATA:
				OnGameDatanEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_BARRIERENTER:
				OnBarrierEnterEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_BARRIERRESET:
				OnBarrierResetEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_STARTGAMEROUND:
				OnStartGameRoundEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_REMOTESIMCRC:
				OnRemoteSimCrcEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_GAMEINFOUPDATE:
				OnGameInfoUpdateEvent(ptrEvent);
				break;
			case Network::Session::InternalEvent::SE_REMOTEPLAYERINFO:
				OnRemotePlayerInfoEvent(ptrEvent);
				break;
			default:
				AP_ASSERT(0);
			}
		}
		else
		{
			break;
		}
	}

	PushFrameEvents();
	m_ComponentMsgBox->ClearOutbox();

	//Check for send buffered data
	const Axiom::TimeAbsolute now = Axiom::TimeAbsolute::GetSystemTime();

	//We want to send data 30 times a second.  ( every other frame if 60 FPS )

	if( !mDataBuffer.Empty() && ( now - mLastTimeSent ) > Axiom::TimeRelative::CreateFromSeconds( 1.0f / 30.0f ) )
	{
		SendBufferedData();
	}
}


// Synchronize GameInfo data stations in session. Update logic is based on version number.
void NetworkSessionComponent::SyncGameInfoData()
{
	const Axiom::UInt nCurrentGameInfoVer = Network::NetworkSessionManager::Instance()->GetGameInfoVer();
	if (m_nLastSentUpdateVer != nCurrentGameInfoVer && m_nLastReceivedUpdateVer != nCurrentGameInfoVer)
	{
		char temp_[MAX_GAME_INFO_SIZE] = {0};
		size_t ulGameInfoSize = sizeof(temp_);

		Network::Session* pSession = Network::NetworkSessionManager::Instance()->CurrentSession();		
		if (pSession != 0 && Network::NetworkSessionManager::Instance()->GameInfo(&temp_[0], &ulGameInfoSize))
		{
			AP_ASSERT(ulGameInfoSize > 0);
			pSession->Send(MSG_GAMEINFO_UPDATE, &temp_[0], ulGameInfoSize);
			m_nLastSentUpdateVer = nCurrentGameInfoVer;
		}	
		// else do nothing
	}
}


// 
void NetworkSessionComponent::OnShutdown()
{
	// Do nothing
}


// Player info event sent by remote host just after connection. It containes serialized user information
// for players registered on that host so that it can be used to query/report stats.
void NetworkSessionComponent::OnRemotePlayerInfoEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{	
	Network::RemotePlayerInfoEvent* pPlayerInfoEvent = static_cast<Network::RemotePlayerInfoEvent*>(ptrEvent.pVal());
	if (pPlayerInfoEvent != 0)
	{	
		Lobby::Events::LobbyPlayerInfoEvent evt;

		AP_ASSERT(pPlayerInfoEvent->GetDataSize() <= sizeof(evt.m_acRawData));
		Axiom::MemoryCopy( &evt.m_acRawData, pPlayerInfoEvent->GetData(), pPlayerInfoEvent->GetDataSize() ); 
		evt.m_nRawDataSize = pPlayerInfoEvent->GetDataSize();
		m_ComponentMsgBox->SendEvent(&evt);
	}
	else
	{
		AP_ASSERT(0);
	}
}


// 
void NetworkSessionComponent::OnRemoteSimCrcEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::RemoteSimCrcEvent* pSimCrcEvent = static_cast<Network::RemoteSimCrcEvent*>(ptrEvent.pVal());
	if (pSimCrcEvent != 0)
	{	
		// TODO: make sim component to pack multiple CRCs into single event to reduce overhead.
		// TODO: make raw block transfer a generic function.
		const Axiom::Byte* pData = reinterpret_cast<const Axiom::Byte*>(pSimCrcEvent->GetData());
		int readPos = 0;
		// Network::Events::Remote
		Network::Events::RemoteSyncFrameCrcEvent syncFrameCrcEvent;
		syncFrameCrcEvent.m_nSrcStationId = 0L;
		
		Axiom::MemoryCopy(&syncFrameCrcEvent.mCRC, &pData[readPos], sizeof(syncFrameCrcEvent.mCRC)); readPos += sizeof(syncFrameCrcEvent.mCRC);
		Axiom::MemoryCopy(&syncFrameCrcEvent.mFrameTick, &pData[readPos], sizeof(syncFrameCrcEvent.mFrameTick)); readPos += sizeof(syncFrameCrcEvent.mFrameTick);
		Axiom::MemoryCopy(&syncFrameCrcEvent.mSeed, &pData[readPos], sizeof(syncFrameCrcEvent.mSeed)); readPos += sizeof(syncFrameCrcEvent.mSeed);
		
		m_ComponentMsgBox->SendEvent(&syncFrameCrcEvent);	
	}
	else
	{
		AP_ASSERT(0);
	}
}


//
void NetworkSessionComponent::OnGameDatanEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{	
	Network::GameDataEvent* pDataEvent = static_cast<Network::GameDataEvent*>(ptrEvent.pVal());
	
	if (pDataEvent != 0)
	{
		const Axiom::Byte* pData = reinterpret_cast< const Axiom::Byte*>(pDataEvent->GetData());

		//UChar is template class on dataBuffer.
			
		const Axiom::UChar numFrames = *(reinterpret_cast<const Axiom::UChar*>(pData));
		AP_ASSERT( numFrames != 0 );

		pData += sizeof( numFrames );

		Axiom::Collections::StaticArray< Axiom::UChar, MAX_EVENT_BUFFER_COUNT > sizeMarks;

		Axiom::MemorySet( &sizeMarks[0], 0, sizeof( sizeMarks ) );
		Axiom::MemoryCopy( &sizeMarks[0], pData, sizeof( Axiom::UChar ) * numFrames );
		pData += sizeof( Axiom::UChar ) * numFrames;

		for( Axiom::UInt i = 0; i < numFrames; ++i )
		{
			const Axiom::Int iFrameTick = *(reinterpret_cast<const Axiom::Int*>(pData));
			AP_ASSERT(iFrameTick >= 0);

			AP::Marshaller::FrameEvent frameEvent;
			frameEvent.SetData( pData, sizeMarks[ i ] );
			frameEvent.SetFrameTick( iFrameTick );

			pData += sizeMarks[ i ];

			frameEvent.SetWriteLock(1);
			m_RemoteEventCache.AddRawEvent( frameEvent );
			frameEvent.SetWriteLock(0);
		}
	}
	else
	{
		AP_ASSERT(0);
	}
};


// 
void NetworkSessionComponent::OnStartGameRoundEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::StartGameRoundEvent* pDataEvent = static_cast<Network::StartGameRoundEvent*>(ptrEvent.pVal());
	if (pDataEvent != 0)
	{
		// TODO: Unpack configuration data and save them with Network Session manager so they can be obtained when game starts.
		Network::Events::SessionStartOnlineMatchEvent startGameEvent;
		m_ComponentMsgBox->SendEvent(&startGameEvent);	
	}	
}


// Send component events notifying about new frame events in buffer.
void NetworkSessionComponent::PushFrameEvents()
{
	// Frames from remote station stored inside m_RemoteEventCache. Here we generate single RemoteMarshallFrameEvent
	// for each frame in m_RemoteEventCache and send it to Marshaller.
	for( Axiom::UInt i = 0 ; i < m_RemoteEventCache.GetCount(); ++i )
	{	
		AP::Marshaller::FrameEvent* pFrameEvent = m_RemoteEventCache.GetNextEvent();
		AP_ASSERT(pFrameEvent != NULL);
		AP_ASSERT(pFrameEvent->IsWriteLock() == 1);

		AP::Marshaller::Events::RemoteMarshallFrameEvent frameEvent(pFrameEvent, pFrameEvent->GetFrameTick());
		m_ComponentMsgBox->SendEvent(&frameEvent);
	}	
}


// 
void NetworkSessionComponent::OnSessionInitializationEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{	
	Network::SessionInitializationEvent* pInitEvent = static_cast<Network::SessionInitializationEvent*>(ptrEvent.pVal());
	if (pInitEvent != 0) 
	{		
		Axiom::Log("session", "Session initialization internal event, status= %d", pInitEvent->m_bStatus);
		// If session shutdown completed we can safely destroy it!
		if (pInitEvent->m_bStatus == false)		
		{
			Axiom::Log("session", "Destroying current session object.");
			Network::NetworkSessionManager::Instance()->ResetAll();
		}

		Network::Events::SessionInitializationEvent evt;
		evt.m_bStatus = pInitEvent->m_bStatus;
		m_ComponentMsgBox->SendEvent(&evt);
	}		
}


//
void NetworkSessionComponent::OnSessionPeerConnectionEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::ConnectionEvent* pConnectEvent = static_cast<Network::ConnectionEvent*>(ptrEvent.pVal());
	if (pConnectEvent != 0) 
	{		
		Axiom::Log("session", "Internal peer connection event, status= %d, local= %d, host= %d.", pConnectEvent->m_bStatus, pConnectEvent->m_bIsLocal, pConnectEvent->m_bIsHost);
		Network::Events::SessionPeerConnectionEvent evt;
		evt.m_bStatus = pConnectEvent->m_bStatus;
		evt.m_bIsLocal = pConnectEvent->m_bIsLocal;
		evt.m_bIsHost = pConnectEvent->m_bIsHost;
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


//
void NetworkSessionComponent::OnGameInfoUpdateEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::GameInfoUpdateEvent* pUpdateEvent = static_cast<Network::GameInfoUpdateEvent*>(ptrEvent.pVal());
	if (pUpdateEvent != 0) 
	{	
		Axiom::Log("network", "game info update");
		++m_nLastReceivedUpdateVer;

		NetworkSessionManager::Instance()->SetGameInfo(pUpdateEvent->GetData(), pUpdateEvent->GetDataSize(), m_nLastReceivedUpdateVer);
		Network::Events::GameInfoUpdateEvent evt;
		evt.m_nGameInfoVersion = m_nLastReceivedUpdateVer = NetworkSessionManager::Instance()->GetGameInfoVer();

		m_ComponentMsgBox->SendEvent(&evt);
	}
}


//
void NetworkSessionComponent::OnBarrierEnterEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::BarrierEnterEvent* pEntryEvent = static_cast<Network::BarrierEnterEvent*>(ptrEvent.pVal());
	if (pEntryEvent != 0) 
	{	
		Axiom::Log("session", "Current session entered barrier \"%s\"", pEntryEvent->m_strName.AsChar());
		Network::Events::BarrierEnterEvent evt;
		evt.m_name = pEntryEvent->m_strName.AsChar();
		m_ComponentMsgBox->SendEvent(&evt);
	}	
}


//
void NetworkSessionComponent::OnBarrierResetEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::BarrierResetEvent* pBarrierResetEvent = static_cast<Network::BarrierResetEvent*>(ptrEvent.pVal());
	if (pBarrierResetEvent != 0) 
	{	
		Axiom::Log("session", "FAiled to enter barrier \"%s\", status= %d.", pBarrierResetEvent->m_strName.AsChar(), pBarrierResetEvent->m_nStatusCode);
		Network::Events::BarrierResetEvent evt;
		evt.m_name = pBarrierResetEvent->m_strName.AsChar();
		evt.m_status = pBarrierResetEvent->m_nStatusCode;		
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


// 
void NetworkSessionComponent::OnSessionPeerDisconnectionEvent(Axiom::SmartPtr<Network::Session::InternalEvent> ptrEvent)
{
	Network::DisconnectionEvent* pConnectEvent = static_cast<Network::DisconnectionEvent*>(ptrEvent.pVal());
	if (pConnectEvent != 0) 
	{		
		Network::Events::SessionPeerDisconnectionEvent evt;
		evt.m_bStatus = pConnectEvent->m_bStatus;
		evt.m_bIsLocal = pConnectEvent->m_bIsLocal;
		evt.m_bIsHost = pConnectEvent->m_bIsHost;
		m_ComponentMsgBox->SendEvent(&evt);
	}
}


void NetworkSessionComponent::HandleData( const Axiom::Char* data, Axiom::UInt size )
{	
	if( !mDataBuffer.CanFit( size ) )
	{
		Axiom::Log( "network", "full buffer triggering buffered network send" );
		SendBufferedData();
	}
	
	mDataBuffer.Write( data, size );
}

void NetworkSessionComponent::SendBufferedData()
{
	Network::Session* session = Network::NetworkSessionManager::Instance()->CurrentSession();

	if( session )
	{
		Axiom::Char buffer[ 500 ];

		const Axiom::UInt dataSize = mDataBuffer.FillData( buffer );
		
		session->Send( MSG_GAMEDATA, buffer, dataSize );
		mDataBuffer.Clear();

		mLastTimeSent = Axiom::TimeAbsolute::GetSystemTime();
	}
}

// Constructor & destructor
template<typename T> 
NetworkSessionComponent::EventCache<T>::EventCache() : 
	m_BeginIndex(0), 
	m_EndIndex(0), 
	m_Count(0)
{ 
}

// Public methods
template<typename T> 
void NetworkSessionComponent::EventCache<T>::AddRawEvent(T &rNewEvent)
{	
	AP_ASSERT( m_Count < GAMEMARSHALLER_NBCACHEDEVENTS_MAX);
	AP_ASSERT( rNewEvent.IsWriteLock() == 1);
	AP_ASSERT( m_EventBufferCache[m_EndIndex].IsWriteLock() == 0);

	m_EventBufferCache[m_EndIndex] = rNewEvent;
	m_EventBufferCache[m_EndIndex].SetWriteLock(0);

	// Circular buffer
	m_EndIndex = (m_EndIndex + 1) % GAMEMARSHALLER_NBCACHEDEVENTS_MAX;
	m_Count++;

	AP_ASSERT(m_EndIndex != m_BeginIndex);
}


//  
template<typename T> 
T* NetworkSessionComponent::EventCache<T>::GetNextEvent(void)
{
	if( m_Count <= 0 )
	{
		return NULL;
	}

	const Axiom::UInt iIndex = m_BeginIndex; 

	AP_ASSERT( iIndex >=0 && iIndex < GAMEMARSHALLER_NBCACHEDEVENTS_MAX);
	AP_ASSERT( m_EventBufferCache[iIndex].IsWriteLock()== 0);

	m_EventBufferCache[iIndex].SetWriteLock(1);

	// Circular buffer
	m_BeginIndex = (m_BeginIndex + 1) % GAMEMARSHALLER_NBCACHEDEVENTS_MAX;		
	m_Count--;

	AP_ASSERT( (m_BeginIndex + m_Count) % GAMEMARSHALLER_NBCACHEDEVENTS_MAX == m_EndIndex);
	AP_ASSERT( iIndex < GAMEMARSHALLER_NBCACHEDEVENTS_MAX );

	return &m_EventBufferCache[iIndex];
}

}	//namespace Network


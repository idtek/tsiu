
#include "network/networksessionevents.h"

using namespace Network::Events;

AP_TYPE(SessionInitializationEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Status", m_bStatus, "Session initializaqtion status.")
AP_TYPE_END()

AP_TYPE(SessionInitialize)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(SessionShutdown)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()

AP_TYPE(SessionPeerConnectionEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("IsLocal", m_bIsLocal, "Is this an event for local station?")
AP_FIELD("IsHost", m_bIsHost, "Is this an event for host station?.")
AP_TYPE_END()


AP_TYPE(SessionPeerDisconnectionEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("IsLocal", m_bIsLocal, "Is this an event for local station?")
AP_FIELD("IsHost", m_bIsHost, "Is this an event for host station?.")
AP_TYPE_END()


AP_TYPE(SessionStartGameRound)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Reserved", mGameIdentifier, "Reserved string value.")
AP_TYPE_END()


AP_TYPE(SessionStartOnlineMatchEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Status", m_bStatus, "Session initializaqtion status.")
AP_TYPE_END()


AP_TYPE(WaitOnDistributedBarrier)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Name", m_name, "Barrier's name.")
AP_TYPE_END()


AP_TYPE(BarrierResetEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Name", m_name, "Barrier's name.")
AP_FIELD("Status", m_status, "Barrier's reset reason code.")
AP_TYPE_END()


AP_TYPE(BarrierEnterEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Name", m_name, "Barrier's name.")
AP_TYPE_END()


AP_TYPE(RemoteSyncFrameCrcEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_TYPE_END()


AP_TYPE(GameInfoUpdateEvent)
AP_BASE_TYPE(Axiom::EventMsg)
AP_DEFAULT_CREATE()
AP_FIELD("Version", m_nGameInfoVersion, "GameInfo version number.")
AP_TYPE_END()


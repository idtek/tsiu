
#include "network/networksession.h"
#include "network/networksessionmanager.h"
#include "network/address.h"

namespace Network
{

//
Session::Session()
{
}


Session::~Session()
{
	m_eventQueue.Clear();
}


// Give session slice of CPU time
void Session::Update()
{
	Process();
}


} // namespace Network

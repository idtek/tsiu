
#ifndef _NETWORKSESSIONMANAGER_H_
#define _NETWORKSESSIONMANAGER_H_

#include "thread/mutex.h"
#include "network/address.h"

namespace Network
{

// Forward declarations:
class Session;

#define MAX_GAME_INFO_SIZE 1024

// Network Session manager global singleton. Responsible for life time of Network Session objects.
class NetworkSessionManager
{
public:
		
	// D-tor
	~NetworkSessionManager()
	{
		// Make sure all sessions have been properly shut down before Session Manager destroyed.
		AP_ASSERT(m_pCurrentSession == 0);
	}

	// Returns instance of singleton object. This function uses Double-Checked Locking Optimization pattern.
	static NetworkSessionManager* Instance();

	//! 
	bool Initialize(/* config parameters ? */);

	// Returns pointer to current session, NULL if session does not exists.
	Network::Session* CurrentSession(void)
	{
		return m_pCurrentSession;
	}

	// Creates new session ...
	bool CreateSession(const Network::Address& addr);

	//! Creates new session object and connects it to session hosted elsewhere.
	bool JoinRemoteSession(const Network::Address& addr);

	//! Destroys all active sessions.
	void ResetAll();

	// Give Session Manage r slice of CPU time.
	bool Update();

	// Sets the contents of GameInfo structure that will be transferred to remote station.
	void SetGameInfo(const char* pData, size_t nDataSize, int nVersion);

	// Read latest version of GameInfo data. 
	bool GameInfo(char* pData, size_t* pDataSize) const;

	// Returns version of GameInfo structure.
	Axiom::UInt GetGameInfoVer() const
	{
		return m_nGameInfoVersion;
	}

protected:

	// Default c-tor.
	NetworkSessionManager();

	// Static singleton instance
	static NetworkSessionManager*	m_pSingletonInstance;

	// Guards session(s)
	mutable Axiom::Thread::Mutex	m_pSessionMutex;

	// We can have more than one session object in future, but right now we only support one.
	Network::Session*				m_pCurrentSession;

	//
	Axiom::UInt						m_nGameInfoVersion;
	// Raw GameInfo data.
	Axiom::Char						m_GameInfoRawData[MAX_GAME_INFO_SIZE];
	// Actual size of GameInfo data in buffer.
	size_t							m_nActualGameInfoSize;
};

} // namespace Network

#endif

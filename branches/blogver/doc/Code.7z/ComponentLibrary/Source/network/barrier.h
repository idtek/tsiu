
#ifndef _BARRIER_H_
#define _BARRIER_H_

#include "string/staticstring.h"
#include "collections/list.h"
#include "network/networksession.h"

namespace Network
{

// Constants:
#define MAX_BARRIER_ENTRIES	16

// 
enum BarrierStatus
{
	BARRIER_STATUS_CANCELLED	= 0x1,
	BARRIER_STATUS_TIMEDOUT		= 0x2,
	BARRIER_STATUS_DISCONNECTED = 0x3
};


//! Event generated when Barrier condition is satisfied. Barriers used as an extension to
//! Network Session implementations. 
class BarrierEnterEvent : public Network::Session::InternalEvent
{
public:
	//! 
	BarrierEnterEvent(const Axiom::ShortString& name)
		: Network::Session::InternalEvent(SE_BARRIERENTER),
		m_strName(name)
	{
		// Do nothing
	}

	// Name of barrier.
	Axiom::ShortString	m_strName;
};


//! Event generated when Barrier condition is satisfied.
class BarrierResetEvent : public Network::Session::InternalEvent
{
public:

	//! 
	BarrierResetEvent(const Axiom::ShortString& name)
		: Network::Session::InternalEvent(SE_BARRIERRESET),
		m_strName(name),
		m_nStatusCode(0)
	{
		// Do nothing
	}

	// Name of barrier.
	Axiom::ShortString	m_strName;
	//
	int					m_nStatusCode;
};


} // namespace Network

#endif

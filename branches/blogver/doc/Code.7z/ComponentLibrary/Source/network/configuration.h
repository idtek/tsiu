
#ifndef _CONFIGURATION_H_
#define _CONFIGURATION_H_

//! Set it to 1 if you want to build against AGORA library
#define USE_AGORA_LIBRARY 1
//! Session's internal event queue size.
#define SESSION_INTERNAL_QUEUE_SIZE 1024

#if CORE_PS3
#define NETWORK_HAS_BSDSOCKET 1
#elif CORE_XBOX360
#include <winsockx.h>
#define NETWORK_HAS_MSLIVE360 1
#elif CORE_WIN32
#include <winsock2.h>
#define NETWORK_HAS_WINSOCK2 1
#endif

#endif

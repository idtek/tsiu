#ifndef _EVENT_BUFFER_H___
#define _EVENT_BUFFER_H___

#include <collections/list.h>
#include <collections/circularbuffer.h>
#include <eventsystem/eventman.h>

#include "marshaller/marshallerconst.h"

namespace AP
{
	namespace Marshaller
	{
		static const int INVALID_FRAME_TICK = -1;

		////////////////////////////////////////////////////////////////////////////////////////
		//  Stores 1 frame of events
		//  Format: frameTick(4 bytes) | event[0] .. event[n]
		class FrameEvent
		{
		public:

			FrameEvent();
			FrameEvent(const FrameEvent&);
			~FrameEvent();

			void						Clear				();

			bool						Add					(const Axiom::EventMsg *pEvent);

			Axiom::EventMsg*			TranslatePointer	(Axiom::Byte *pData);

			void						SetFrameTick		(const int frame);
			void						SetData				(const Axiom::Byte *pData, const Axiom::UInt dataSize);
			void						SetWriteLock		(Axiom::UInt32 b);

			const Axiom::Byte*			GetData				() const					{ return mData; }
			const int					GetDataSize			() const					{ return mDataSize; }
			const unsigned int			GetCount			() const					{ return mEventList.Count(); }
			int							GetFrameTick		()							{ return mFrameTick; }
			Axiom::EventMsg*			GetEventByIndex		(const unsigned int index)	{ return mEventList[index]; }

			Axiom::UInt32				IsWriteLock			();


			FrameEvent&					operator=			(const FrameEvent& rhs)
			{
				mLock = 0;
				SetData(rhs.GetData(), rhs.GetDataSize());
				mFrameTick = rhs.mFrameTick;
				mLock = rhs.mLock;
				return *this;
			}

			Axiom::EventMsg*			operator[]			(const unsigned int index)
			{
				AP_ASSERT(index < mEventList.Count()); 
				return mEventList[index]; 
			}

		private:

			Axiom::Collections::StaticList<Axiom::EventMsg*,
										   MAX_NUM_EVENT_PER_FAME>	mEventList;	
			int														mFrameTick;
			Axiom::UInt												mDataSize;
			Axiom::Byte												mData[MAX_FRAMEEVENT_SIZE];
			Axiom::Byte*											mNextPtr;
			Axiom::UInt32											mLock;
		};

		///////////////////////////////////////////////////////////////////////////////////////////////////////
		// Event Buffer
		///////////////////////////////////////////////////////////////////////////////////////////////////////
		class FrameEventContainer
		{
		public:
			FrameEventContainer(): 
				mFrameTick(INVALID_FRAME_TICK), 
				mSize(0),
				mWriteLock(0), 
				mStartAddr(NULL),
				mEndAddr(NULL) 
			{
			}

			void						Clear();
			void						SetWriteLock(Axiom::UInt32 b);
			Axiom::UInt32				IsWriteLock();

			int							mFrameTick;
			unsigned int				mSize;
			Axiom::UInt32				mWriteLock;

			Axiom::Byte*				mStartAddr;
			Axiom::Byte*				mEndAddr;

		};

		class EventBuffer
		{
		public:
			EventBuffer( unsigned int maxNumFrames, unsigned int bufferSize );
			~EventBuffer();

			void						Clear();
			void						ReadNextFrame					(FrameEvent &eventFrame);
			void						AddEventFrame					(FrameEvent &eventFrame);

			unsigned int				GetNumEntries					()const {return mLookUpTable.Count();}

			const bool					FrameExist						(int frameTick) const;

			Axiom::UInt32				IsWriteLock						(int frameTick) const;
			bool						IsEmpty							()const {return mLookUpTable.IsEmpty();}
			bool						IsBufferFull					()const {return mLookUpTable.IsFull(); }

			FrameEventContainer*		AcquireLockNextFrameContainer	(int frameTick);

		private:
			const FrameEventContainer*	GetFrameEventContainer			(int frameTick) const;
			void						WriteData						(int frameTick, const Axiom::Byte *pData, const unsigned int size);
			
			Axiom::Byte*				NextAddr						();
			const Axiom::Byte*			NextAddr						() const;

			FrameEventContainer&		GetListHead();
			const FrameEventContainer&	GetListHead() const;

		private:

			Axiom::Collections::DynamicCircularList< FrameEventContainer >	mLookUpTable;
			Axiom::Byte*													mpRawData;

			unsigned int				mBufferSize;

			AP_NON_COPYABLE( EventBuffer );
		};
	}
}
#endif

#include <core/core.h>
#include "assert.h"
#include <collections/list.h>
#include "collections/list.h"
#include "marshaller/eventbuffer.h"
#include "marshaller/DebugEventLogger.h"
#include "kernel/componentmanager.h"

#include <files/filemanager.h>

using namespace Axiom;
namespace AP
{
	namespace Marshaller
	{	
		DebugEventLogger::DebugEventLogger() :
			mStartFrameTick( -1 ),
			mNumSlots( 0 ),
			mMode( LM_Logging ),
			mLastReportedCRCFrame( -1 ),
			mLogUpToFrame( -1 )			
		{
			mFileManager = Axiom::FileManager::FileManager::GetInstance();
		}

		DebugEventLogger::~DebugEventLogger()
		{
			if(mMode != LM_LogWithNoFileSave)
			{
				AP_ASSERTMESSAGE(!mLogHandle.IsValid(), "Ensure you close the log file before turning off!");
			}
		}

		void DebugEventLogger::StartLog(const Axiom::FileManager::VirtualFilePathString& filename, LogMode mode, int startFrameTick, int lastFrameTick, int maxSlots)
		{
			ComponentManager::GetInstance()->EnterExclusiveMode();
			{
				mLogFileName = filename;
				mLogUpToFrame = lastFrameTick;
				mNumSlots  = maxSlots;
				AP_ASSERTMESSAGE(mNumSlots > 0 && mNumSlots<=MAX_NUM_VIRTUAL_CONTROLLER_SLOT , "Ensure you set the number slop per frame before this");
				
				if(mMode!=LM_LogWithNoFileSave && mLogHandle.IsValid() )
				{
					mFileManager->CloseFile( mLogHandle );
				}
	
				mStartFrameTick = startFrameTick;
				Axiom::MemorySet(&mLog[0],0,sizeof(EventEntry) * MAX_NUM_LOG_EVENTS);
				mLastReportedCRCFrame = -1;

				if(mode == LM_Logging)
				{
					Axiom::FileManager::FileInfo info = mFileManager->GetFileInfo( mLogFileName.AsChar() );
					mLogHandle = mFileManager->OpenFile( info, Axiom::FileManager::FileManager::EOpenMode_WriteCreate );
					AP_ASSERT( mLogHandle.IsValid() );
					Log("EventLogger","START LOGGING");

				}
				else if(mode == LM_Playback)
				{
					mLastReportedCRCFrame = lastFrameTick;

					Axiom::FileManager::FileInfo info = mFileManager->GetFileInfo( mLogFileName.AsChar() );
					mLogHandle = mFileManager->OpenFile( info, Axiom::FileManager::FileManager::EOpenMode_Read );
					AP_ASSERT( mLogHandle.IsValid() && info.IsValid() );

					ReadFromFile();
		
					Log("EventLogger","START PLAYBAK");
				}
			}
			ComponentManager::GetInstance()->LeaveExclusiveMode();
		}

		void DebugEventLogger::EndLog()
		{
			AP_ASSERTMESSAGE(mNumSlots > 0, "Ensure you set the number slop per frame before this");

			int numEntries = mLastReportedCRCFrame - mStartFrameTick + 1;
			AP_ASSERT(numEntries>0 && numEntries<=MAX_NUM_LOG_EVENTS);

			mStartFrameTick = mLastReportedCRCFrame;
			
			if(mMode != LM_LogWithNoFileSave)
			{
				AP_ASSERTMESSAGE(mLogHandle.IsValid(),"Ensure that we have an open log file");
				WriteToFile(numEntries);
				mFileManager->CloseFile( mLogHandle );
				Log("EventLogger","END LOGGING");
			}

		}

		void DebugEventLogger::WriteToFile(int numEntries)
		{
			AP_ASSERT(mMode != LM_LogWithNoFileSave);
			AP_ASSERT(numEntries >0 && numEntries <=MAX_NUM_LOG_EVENTS);
	
			ComponentManager::GetInstance()->EnterExclusiveMode();
			{
				Axiom::FileManager::FileInfo info = mFileManager->GetFileInfo( mLogFileName.AsChar() );
				info.SetSize(sizeof( EventEntry ) * numEntries);
				mFileManager->SaveFileSynchronous( mLogHandle, info, &mLog[ 0 ] );
			}
			ComponentManager::GetInstance()->LeaveExclusiveMode();
		}

		bool DebugEventLogger::ReadFromFile()
		{
			Axiom::FileManager::FileInfo info = mFileManager->GetFileInfo( mLogFileName.AsChar() );
			AP_ASSERT( info.IsValid() );		

			const unsigned int bytesRead = mFileManager->LoadFileSynchronous( mLogHandle, info, &mLog[0] );
			const bool result = ( bytesRead == static_cast< unsigned int >( info.GetSize() ) );
			AP_ASSERT( result );
			return result;
		}

		void DebugEventLogger::LogFrameEventData( int frameTick, unsigned int slot, FrameEvent *pFrameEvent)
		{
			AP_ASSERTMESSAGE(!IsLoggingCompleted(),"Ensure that we don't pass the end of the last frame to log");
			int index = frameTick-mStartFrameTick;
	
			// End of buffer, now we log it..
			if(index == MAX_NUM_LOG_EVENTS)
			{
				int numEntries = mLastReportedCRCFrame - mStartFrameTick + 1;
				AP_ASSERT(numEntries>0 && numEntries<MAX_NUM_LOG_EVENTS);

				WriteToFile(numEntries);

				int numEntryWithNoCRC = MAX_NUM_LOG_EVENTS-numEntries;
				for(int i=1;i<=numEntryWithNoCRC;i++)
				{
					Axiom::MemoryCopy(&mLog[i-1],&mLog[numEntries-1+i],sizeof(EventEntry));
				}

				mStartFrameTick = mLastReportedCRCFrame+1;
				Axiom::MemorySet(&mLog[numEntryWithNoCRC],0,sizeof(EventEntry) * (MAX_NUM_LOG_EVENTS-numEntryWithNoCRC));
		
				index = frameTick-mStartFrameTick;
			}

			AP_ASSERTMESSAGE(mMode == LM_Logging,"Ensure that we only add on logging mode!");
			AP_ASSERTMESSAGE(mNumSlots > 0 && slot>=0 && slot <mNumSlots && mNumSlots<=MAX_NUM_VIRTUAL_CONTROLLER_SLOT, "Ensure you set the number slop per frame before this");
			AP_ASSERTMESSAGE(mStartFrameTick>=0 && mStartFrameTick<=frameTick, "MUST START THE EVENT LOGGER FIRST!!");
			AP_ASSERT(index>=0 && index<MAX_NUM_LOG_EVENTS);
			
			mLog[index].mDataSlot[slot].mDataSize = pFrameEvent->GetDataSize();
			
			Axiom::MemoryCopy(mLog[index].mDataSlot[slot].mData,(void*)pFrameEvent,sizeof(FrameEvent));
		}

		void DebugEventLogger::LogFrameEventData( int frameTick, unsigned int crc)
		{
 			AP_ASSERTMESSAGE(!IsLoggingCompleted(),"Ensure that we don't pass the end of the last frame to log");

			AP_ASSERTMESSAGE(mMode == LM_Logging,"Ensure that we only add on logging mode!");
			AP_ASSERTMESSAGE(mNumSlots > 0 && mNumSlots<=MAX_NUM_VIRTUAL_CONTROLLER_SLOT, "Ensure you set the number slop per frame before this");
			AP_ASSERTMESSAGE(mStartFrameTick>=0 && mStartFrameTick<=frameTick, "MUST START THE EVENT LOGGER FIRST!!");

			int index = frameTick-mStartFrameTick;
			AP_ASSERT(index>=0 && index<MAX_NUM_LOG_EVENTS);
			AP_ASSERTMESSAGE(mLog[index].mCRC==0,"Ensure that there is no CRC on this yet!!");
			mLog[index].mCRC = crc;
		
			mLastReportedCRCFrame = frameTick;
		}

		bool DebugEventLogger::GetFrameEventData(int frameTick, EventEntry &eventEntry)
		{	
			AP_ASSERTMESSAGE(mNumSlots > 0 && mNumSlots<=MAX_NUM_VIRTUAL_CONTROLLER_SLOT, "Ensure you set the number slop per frame before this");
			AP_ASSERTMESSAGE(mStartFrameTick>=0, "MUST START THE EVENT LOGGER FIRST!!");
			
			int index = frameTick-mStartFrameTick;

			if(index<0 || index>=MAX_NUM_LOG_EVENTS)
				return false;

			Axiom::MemoryCopy((void*)(&eventEntry),(void*)&mLog[index],sizeof(EventEntry));

			if((mMode != LM_LogWithNoFileSave) &&(index  == MAX_NUM_LOG_EVENTS-1))
			{	
				bool result = false;
				ComponentManager::GetInstance()->EnterExclusiveMode();
				{
					result = ReadFromFile();
				}
				ComponentManager::GetInstance()->LeaveExclusiveMode();

				if( result )
				{
					mStartFrameTick = frameTick+1;
				}
				else
				{
					mFileManager->CloseFile( mLogHandle );
				}

				return (result);
			}

			return true;
		}
	}
}

#include <core/core.h>
#include <collections/list.h>
#include <eventsystem/eventman.h>
#include "marshaller/eventbuffer.h"
#include "marshaller/marshallereventmessages.h"
#include <eventsystem/eventmsgdictionary.h>
#include <thread/atomic.h>

namespace AP
{
	namespace Marshaller
	{
		FrameEvent::FrameEvent() : 
			mLock(0)
		{
			Clear(); 
		}

		FrameEvent::FrameEvent(const FrameEvent& rhs)
		{
			mLock = 0;
			SetData(rhs.GetData(), rhs.GetDataSize());
			mFrameTick = rhs.mFrameTick;
			mLock = rhs.mLock;
		}
		
		FrameEvent::~FrameEvent(void)
		{
			Clear();
		}

		void FrameEvent::Clear(void)
		{ 	
			mEventList.Clear();
			mNextPtr = mData;
			mDataSize = 0;
			mFrameTick = INVALID_FRAME_TICK;
			mLock = 0;
		}

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Event Entry
		////////////////////////////////////////////////////////////////////////////////////////////////////
		void FrameEvent::SetFrameTick(const int frame)
		{
			AP_ASSERT(!Axiom::Thread::AtomicRead(&mLock));

			Axiom::MemoryCopy(mData, (void*)(&frame), sizeof(int));
			mFrameTick = frame;

			if(mData == mNextPtr)
			{
				mDataSize +=sizeof(int);
				mNextPtr  +=sizeof(int);
			}
		}

		bool FrameEvent::Add(const Axiom::EventMsg *pEvent)
		{
			AP_ASSERT(!Axiom::Thread::AtomicRead(&mLock));

			const unsigned int size = pEvent->GetSize();
			
			if(mData == mNextPtr)
			{
				mDataSize +=sizeof(int);
				mNextPtr  +=sizeof(int);
			}

			AP_ASSERTMESSAGE((int)mNextPtr >= (int)mData + static_cast<int>(sizeof(int)), "Ensure we don't override the frame Tick");
			
			if(mDataSize + size >= MAX_FRAMEEVENT_SIZE*sizeof(Axiom::Byte) || mEventList.Count() > MAX_NUM_EVENT_PER_FAME)
			{
				AP_ASSERT(0);
				return false;
			}

			Axiom::MemoryCopy(mNextPtr,pEvent,size);
			mEventList.Add(const_cast<Axiom::EventMsg*>(pEvent));
			mNextPtr = mNextPtr + size;
			mDataSize +=size;

			return true;	
		}

		Axiom::EventMsg* FrameEvent::TranslatePointer(Axiom::Byte* pData)
		{
			const Axiom::EventMsg* pTemp = reinterpret_cast<const Axiom::EventMsg*>(pData);
			AP_ASSERTMESSAGE(pTemp!=NULL, "Ensure that base pointer is still good!");

			const Axiom::EventMsgId eventGuid = pTemp->GetGuidID();
			const Axiom::EventMsg* translatedEvent = Axiom::EventMsgDictionary::GetInstance()->CreateEvent( eventGuid, pData );

			return const_cast<Axiom::EventMsg*>( translatedEvent );
		}

		void FrameEvent::SetData( const Axiom::Byte* pData, const Axiom::UInt dataSize)
		{
			AP_ASSERT(dataSize<=MAX_FRAMEEVENT_SIZE);
			AP_ASSERT(!Axiom::Thread::AtomicRead(&mLock));

			Clear();

			// Assumes data format: frameTick(4bytes)|data(dataSize bytes)
			Axiom::MemoryCopy( mData, pData, dataSize );
			mDataSize += dataSize;

			mFrameTick = *(reinterpret_cast<int*>(mNextPtr));
			AP_ASSERT(mFrameTick!=INVALID_FRAME_TICK);

			mNextPtr += sizeof(int);
			Axiom::UInt totalSize = sizeof(int);
			
			if( totalSize < dataSize )
			{
				Axiom::EventMsg* pEvent = TranslatePointer(mNextPtr);
				AP_ASSERT( pEvent );

				mEventList.Add(pEvent);
				totalSize += pEvent->GetSize();

				while( totalSize < mDataSize)
				{
					const Axiom::UInt size = pEvent->GetSize();
					mNextPtr = reinterpret_cast<Axiom::Byte*>((int)mNextPtr + size);

					pEvent = TranslatePointer(mNextPtr);
					AP_ASSERTMESSAGE(pEvent!=NULL,"Ensure that our events are valid!");

					totalSize += pEvent->GetSize();
					AP_ASSERTMESSAGE(totalSize<=mDataSize,"Ensure that the total size is no more than data size!");

					mEventList.Add(pEvent);
				}
			}
		}

		void FrameEvent::SetWriteLock(Axiom::UInt32 b)
		{
			AP_ASSERT(b == 0 || b==1);
			Axiom::Thread::AtomicExchange(&mLock,b);
		}

		Axiom::UInt32 FrameEvent::IsWriteLock()
		{
			return Axiom::Thread::AtomicRead(&mLock);
		}

		void FrameEventContainer::SetWriteLock(Axiom::UInt32 b)
		{	
			AP_ASSERT(b == 0 || b==1);
			Axiom::Thread::AtomicExchange(&mWriteLock, b);
		}

		Axiom::UInt32 FrameEventContainer::IsWriteLock()
		{
			return Axiom::Thread::AtomicRead(&mWriteLock);
		}

		void FrameEventContainer::Clear()
		{
			mFrameTick=INVALID_FRAME_TICK;
			SetWriteLock(0);
			mStartAddr=NULL;
			mEndAddr=NULL;
			mSize=0;
		}

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Event Buffer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		EventBuffer::EventBuffer( unsigned int maxNumFrames, unsigned int bufferSize ) :
			mBufferSize( bufferSize )
		{	
			mpRawData = AP_NEW( Axiom::Memory::DEFAULT_HEAP, Axiom::Byte[ mBufferSize ] );
			Axiom::MemorySet(mpRawData,0, sizeof(Axiom::Byte) * mBufferSize );

			mLookUpTable.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumFrames );

			Clear();
		}

		EventBuffer::~EventBuffer()
		{	
			AP_DELETE( mpRawData );
		}

		void EventBuffer::Clear()
		{
			mLookUpTable.Clear();
		}

		FrameEventContainer& EventBuffer::GetListHead()
		{
			return mLookUpTable.FirstItem();
		}

		const FrameEventContainer&	EventBuffer::GetListHead() const
		{
			return mLookUpTable.FirstItem();
		}

		Axiom::Byte* EventBuffer::NextAddr()
		{
			return mLookUpTable.LastItem().mEndAddr;
		}

		const Axiom::Byte* EventBuffer::NextAddr() const
		{
			return mLookUpTable.LastItem().mEndAddr;
		}

		void EventBuffer::WriteData( int frameTick, const Axiom::Byte *pData, const unsigned int size )
		{
			AP_ASSERT( frameTick != INVALID_FRAME_TICK );
			AP_ASSERT( !mLookUpTable.IsFull() );

			if( mLookUpTable.IsEmpty() )
			{
				mLookUpTable.PushDefault();
				FrameEventContainer& item = mLookUpTable.FirstItem();

				item.mStartAddr = mpRawData;
				
				Axiom::MemoryCopy( item.mStartAddr, pData, size);
				item.mEndAddr = item.mStartAddr + size-1;
				item.mSize = size;
				item.mFrameTick = frameTick;
			}
			else
			{	
				//DAY 10/16/2008 6:49:36 PM  The magic is in the fact that the buffer
				//is always big enough to hold the max amount of largest events, ie
				// bufferSize = max event size * max num events

				const unsigned int BufferSize = sizeof(Axiom::Byte) * mBufferSize;
				const Axiom::Byte* pEndRawDataAddr = (mpRawData + BufferSize);

				const Axiom::Byte* nextAddress = NextAddr();

				AP_ASSERT( nextAddress < pEndRawDataAddr && nextAddress > mpRawData );

				const unsigned int freeSize = pEndRawDataAddr - nextAddress;

				FrameEventContainer frame;
				frame.mFrameTick = frameTick;
				frame.mSize = size;

				if( size < freeSize )
				{
					frame.mStartAddr = NextAddr();
					frame.mStartAddr++;		
				}
				else
				{
					frame.mStartAddr = mpRawData;
				}							

				Axiom::MemoryCopy( frame.mStartAddr, pData, size);
				frame.mEndAddr = frame.mStartAddr + size - 1;

				mLookUpTable.Push( frame );
			}
		}

		void EventBuffer::ReadNextFrame(FrameEvent &eventFrame)
		{
			const FrameEventContainer& frame = mLookUpTable.FirstItem();
			
			eventFrame.SetData( frame.mStartAddr, frame.mSize );
			eventFrame.SetFrameTick( frame.mFrameTick );

			mLookUpTable.Pop();
			
			if( mLookUpTable.IsEmpty() )
			{
				Clear();
			}
		}

		const FrameEventContainer* EventBuffer::GetFrameEventContainer(int frameTick) const
		{
			if( mLookUpTable.IsEmpty() ) 
			{
				return 0;
			}

			const FrameEventContainer& startFrame = mLookUpTable.FirstItem();

			AP_ASSERT( startFrame.mStartAddr );	
	
			const int firstFrameTick = startFrame.mFrameTick;
			AP_ASSERT(frameTick>=firstFrameTick);

			const int index = frameTick - firstFrameTick;

			const FrameEventContainer* pFrameCon = &mLookUpTable[ index ];
			AP_ASSERT(pFrameCon && frameTick==pFrameCon->mFrameTick);

			return pFrameCon;
		}

		const bool EventBuffer::FrameExist(int frameTick) const
		{
			if( mLookUpTable.IsEmpty() )
			{
				return false;
			}

			const int firstFrameTick = mLookUpTable.FirstItem().mFrameTick;
			const int lastFrameTick = mLookUpTable.LastItem().mFrameTick;
			
			return ( frameTick >= firstFrameTick && frameTick <= lastFrameTick );
		}

		Axiom::UInt32 EventBuffer::IsWriteLock(int frameTick) const
		{
			FrameEventContainer* pFrameCon = const_cast<FrameEventContainer*>(GetFrameEventContainer(frameTick));

			if(pFrameCon==NULL)
			{
				return 0;
			}

			return pFrameCon->IsWriteLock();
		
		}

		FrameEventContainer*  EventBuffer::AcquireLockNextFrameContainer( int frameTick )
		{
			FrameEventContainer* pFrameCon = const_cast<FrameEventContainer*>(GetFrameEventContainer(frameTick));

			if(pFrameCon)
			{
				AP_ASSERT(pFrameCon->IsWriteLock()==0);	
				pFrameCon->SetWriteLock(1);
			}

			return pFrameCon;
		}

		void EventBuffer::AddEventFrame(FrameEvent &eventFrame)
		{
			WriteData(eventFrame.GetFrameTick(), eventFrame.GetData(), eventFrame.GetDataSize());
		}
	}
}

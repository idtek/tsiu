#include <core/core.h>
#include <core/utils.h>
#include <debug/log.h>
#include <collections/booklet.h>
#include <collections/list.h>
#include <eventsystem/eventman.h>
#include <math/apmath.h>

#include "marshaller/marshallercomponent.h"

#include "kernel/component.h"
#include "kernel/systemtimer.h"
#include "marshaller/debugeventlogger.h"
#include "marshaller/marshallereventmessages.h"
#include "input/inputeventmessages.h"
#include "input/virtualcontrollermap.h"

#if CORE_DEBUG
#include "network/networksessionmanager.h"
#endif

static const int LAST_LOG_FRAME = 300;

#define TEST_DESYNC 1
//#define ONLINE_DEBUGGING_DISPLAY_EVENTS_SEND 1

namespace AP
{
	namespace Marshaller
	{
		namespace Events
		{
			AP_TYPE( RemotePauseEvent )
				AP_BASE_TYPE(AP::Input::Events::SynchAbleInputEvent)
				AP_DEFAULT_CREATE()
			AP_TYPE_END();
		}

		MarshallerComponent::MarshallerComponent(Axiom::ConstStr name, Kernel* kernel) : 
			Component(name,kernel),
			mOnline( false ),
			mSimFrame( -1 ),
			mSyncedFrame( -1 ),	
			mRunMode( RM_Normal ),
			mDebugEventLogger( 0 ),
			mLogFileName( "file:\\evenlog.del" ),
			m_ComponentMsgBox( NULL ),
			mPauseState( E_NoPause )
		{
		}

		MarshallerComponent::~MarshallerComponent()
		{
			AP_DELETE( mDebugEventLogger );
		}

		void MarshallerComponent::PreInit( unsigned int maxNumSyncAbleEvents, unsigned int maxNumVirtualControllers, unsigned int maxNumFrames, unsigned int maxEventBufferSize )
		{
			mSyncAbleEvents.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumSyncAbleEvents );
			mEventLog.Resize( Axiom::Memory::DEFAULT_HEAP, maxNumVirtualControllers );

			mMaxNumFrames = maxNumFrames;
			mMaxEventBufferSize = maxEventBufferSize;
		}

		void MarshallerComponent::AddSyncAbleEvent(Axiom::EventMsgId eventId)
		{
			mSyncAbleEvents.Add( eventId );
			}

		bool MarshallerComponent::IsSyncAbleEvent(Axiom::EventMsgId eventId) const
		{
			return( mSyncAbleEvents.Contains( eventId ) );
		}

		void MarshallerComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}

		bool MarshallerComponent::IsStarted() const
		{
			return(mSimFrame>=0);
		}

		void MarshallerComponent::Reset()
		{
			mSimFrame = 0;
			mSyncedFrame = 0;	
			mPauseState = E_NoPause;
			}

		void MarshallerComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Marshaller");
			m_ComponentMsgBox->OverrideFilterAndListenAllEvents(true);
		}

		void MarshallerComponent::BroadCastEvent( const Axiom::EventMsg* pEventMsg)
		{
			const_cast<Axiom::EventMsg*>(pEventMsg)->SetSenderComponentId(Axiom::INVALID_SENDER_COMPONENT_ID);
			PushEventToListeners(pEventMsg,true);
		}

		void MarshallerComponent::StartEventLogger()
		{
			if(mRunMode == RM_Normal)
			{
				return;
			}
			
			if( !mDebugEventLogger )
			{	
				mDebugEventLogger = AP_NEW( Axiom::Memory::DEFAULT_HEAP, DebugEventLogger );
			}
			
			switch(mRunMode)
			{
				case RM_LogEvents:
					mDebugEventLogger->StartLog(mLogFileName.AsChar(), DebugEventLogger::LM_Logging, mSimFrame, LAST_LOG_FRAME, mEventLog.Count());
					break;
				case RM_PlaybackEventLog:
					mDebugEventLogger->StartLog(mLogFileName.AsChar(), DebugEventLogger::LM_Playback, mSimFrame, LAST_LOG_FRAME, mEventLog.Count());
					break;
				case RM_Normal:
					mDebugEventLogger->StartLog(mLogFileName.AsChar(), DebugEventLogger::LM_LogWithNoFileSave, mSimFrame, LAST_LOG_FRAME, mEventLog.Count());
					break;
				default:
					break;
			}
		}

		bool MarshallerComponent::IsOnline() const
		{
			return mOnline;		
		}

		bool MarshallerComponent::IsDesyncCRCTestOn() const
		{
			return (IsOnline() && TEST_DESYNC);	
		}
	
		void MarshallerComponent::UpdateWithNoFrameSync()
		{
			AP_ASSERTMESSAGE(!IsOnline(), "Not in online mode!!  No sync");

			if(mRunMode != RM_PlaybackEventLog)
			{
				// Send a sync marshaling event
				Events::SyncFrameMarshallingEvent frameSyncEvent =  Events::SyncFrameMarshallingEvent(mSimFrame);
				BroadCastEvent(&frameSyncEvent);
				
				for( unsigned int i = 0; i < mEventLog.Count(); i++ )
				{
					EventBufferEntry& eventBufEntry = *mEventLog[i];

					eventBufEntry.mUnCompleteFrame.SetFrameTick(mSimFrame);

					if( eventBufEntry.mUnCompleteFrame.GetCount() ==0 )
					{
						Events::EmptyMarshallFrameEvent emptyFrame( eventBufEntry.mVirtualControllerId );
						eventBufEntry.mUnCompleteFrame.Add( &emptyFrame );
					}

					eventBufEntry.mEventBuffer.AddEventFrame( eventBufEntry.mUnCompleteFrame);

					if(mRunMode==RM_LogEvents && !mDebugEventLogger->IsLoggingCompleted() && mSimFrame<=LAST_LOG_FRAME)
					{
						mDebugEventLogger->LogFrameEventData(mSimFrame, i, &eventBufEntry.mUnCompleteFrame);
					}

					FrameEvent eventFrame;
					eventBufEntry.mUnCompleteFrame.Clear();
					eventBufEntry.mEventBuffer.ReadNextFrame(eventFrame);

					for(unsigned int i=0;i<eventFrame.GetCount();i++)
					{
						BroadCastEvent(eventFrame[i]);
					}
				}
			}
			else
			{
				AP_ASSERT(mDebugEventLogger);
				DebugEventLogger::EventEntry eventEntry;
				
				if(mSimFrame>=0 && mSimFrame <=LAST_LOG_FRAME && mDebugEventLogger->GetFrameEventData(mSimFrame, eventEntry))
				{
					Events::SyncFrameMarshallingEvent frameSyncEvent =  Events::SyncFrameMarshallingEvent(mSimFrame);
					BroadCastEvent(&frameSyncEvent);

					for( unsigned int i = 0; i < mEventLog.Count(); ++i)
					{
						FrameEvent * pFrame = eventEntry.GetFrame(i);

						for( unsigned int j = 0; j < pFrame->GetCount(); ++j )
						{
							BroadCastEvent((*pFrame)[j]);
						}
					}
				}				
			}

			mSimFrame++;
		}

		// UpdateWithFrameSync() called in networked multi-player mode.
		void MarshallerComponent::UpdateWithFrameSync()
		{	
			Input::VirtualControllerMap *pVirMap = Input::VirtualControllerMap::GetInstance();

			bool simFrame = true;
			bool sentEvents = false;

			for( unsigned int playerInd = 0; playerInd < mEventLog.Count(); ++playerInd )
			{
				// if it is a local virtual id, store it
				if(pVirMap->IsLocalVirtualControllerId(mEventLog[playerInd]->mVirtualControllerId))
				{
					mEventLog[playerInd]->mUnCompleteFrame.SetFrameTick( mSimFrame );
				
					AP_ASSERT( !mEventLog[playerInd]->mEventBuffer.IsBufferFull() );
				
					if( !mEventLog[playerInd]->mEventBuffer.IsBufferFull() && Axiom::Math::Abs(mSimFrame - mSyncedFrame)<=6 )
					{
						if( mEventLog[playerInd]->mUnCompleteFrame.GetCount() == 0 )
						{
							Events::EmptyMarshallFrameEvent emptyFrame(mEventLog[playerInd]->mVirtualControllerId);
							mEventLog[playerInd]->mUnCompleteFrame.Add(&emptyFrame);
						}

						mEventLog[playerInd]->mEventBuffer.AddEventFrame(mEventLog[playerInd]->mUnCompleteFrame);

						FrameEventContainer* pEventCon = mEventLog[playerInd]->mEventBuffer.AcquireLockNextFrameContainer(mSimFrame);

						AP_ASSERT(pEventCon !=NULL);
#if ONLINE_DEBUGGING_DISPLAY_EVENTS_SEND
						Axiom::Log("Marshaller","SEND: F[%d] size[%d] num[%d]",pEventCon->mFrameTick, pEventCon->mSize,mEventLog[playerInd]->mUnCompleteFrame.GetCount());
#endif
						Events::LocalMarshallFrameEvent nextMarshallEvent(pEventCon);
						BroadCastEvent(&nextMarshallEvent);

						mEventLog[playerInd]->mUnCompleteFrame.Clear();
						mSimFrame++;
						sentEvents = true;
					}
				}

				if( !mEventLog[playerInd]->mEventBuffer.FrameExist( mSyncedFrame ) || 
					mEventLog[playerInd]->mEventBuffer.IsWriteLock( mSyncedFrame ) )
				{
					simFrame = false;
				}
			}

			if( sentEvents && mPauseState == E_PauseQueued )
			{
				Axiom::Log("Marshaller","pausing on send here");
				mPauseState = E_PauseSent;
			}

			if( simFrame && !IsPaused() )
			{
				Events::SyncFrameMarshallingEvent frameSyncEvent = Events::SyncFrameMarshallingEvent( mSyncedFrame );
				BroadCastEvent(&frameSyncEvent);

				for( unsigned int playerInd = 0 ;playerInd < mEventLog.Count(); playerInd++)
				{
					FrameEvent eventFrame;
					mEventLog[playerInd]->mEventBuffer.ReadNextFrame(eventFrame);

					AP_ASSERT(eventFrame.GetFrameTick() == mSyncedFrame);

					for(unsigned int frameInd = 0; frameInd < eventFrame.GetCount(); frameInd++)
					{
						BroadCastEvent(eventFrame[frameInd]);
					}
				}

				mSyncedFrame++;
			}
		}

		void MarshallerComponent::OnUpdate()
		{	
			HandleEvents();

			// Check if we can start marshalling
			if( mEventLog.IsEmpty() || !IsStarted() )
			{
				return;
			}

			//Ensure proper online status
#if CORE_DEBUG
			if( IsOnline() )
			{
				AP_ASSERT( Network::NetworkSessionManager::Instance()->CurrentSession() );
			}
			else
			{
				AP_ASSERT( !Network::NetworkSessionManager::Instance()->CurrentSession() );
			}
#endif

			if(!IsOnline())
			{				
				UpdateWithNoFrameSync();
			}
			else if( !IsPaused() )
			{
				UpdateWithFrameSync();
			}
		}

		bool MarshallerComponent::IsPaused() const
		{
			return ( mPauseState == E_PauseSent );
		}

		void MarshallerComponent::OnPauseEvent( const Axiom::EventMsg* pMsg )
		{
			const Events::MarshallerPauseEvent* pauseMsg = pMsg->GetClass< Events::MarshallerPauseEvent >();			
			
			if( pauseMsg->IsRemote() )
			{
				Axiom::Log( "marshaller", "pausing" );
				mPauseState = E_PauseSent;
			}
		}

		void MarshallerComponent::OnResumeEvent()
		{
			Axiom::Log( "marshaller", "resuming" );
			mPauseState = E_NoPause;
		}

		void MarshallerComponent::HandleEvents()
		{
			const unsigned int numEvents = m_ComponentMsgBox->GetNumEvents();

			for ( unsigned int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);

				if(pMsg->GetGuidID() == Events::AssignVirtualControllers::EVENT_GUID)
				{
					OnAssignVirtualControllers(pMsg);
				}
				else if(pMsg->GetGuidID() == Events::StartMarshallingEvent::EVENT_GUID)
				{
					OnStartMarshallingEvent(pMsg);
				}
				else if( pMsg->GetGuidID() == Events::StopMarshallingEvent::EVENT_GUID )
				{
					OnStopMarshallingEvent( pMsg );
				}
				else if(pMsg->GetGuidID() == Events::SyncFrameMarshallingEvent::EVENT_GUID)
				{
					OnSyncFrameMarshallingEvent(pMsg);
				}
				else if(pMsg->GetGuidID() == Events::RemoteMarshallFrameEvent::EVENT_GUID)
				{
					OnRemoteMarshallFrameEvent(pMsg);
				}
				else if(pMsg->GetGuidID() == Events::SyncFrameCRCEvent::EVENT_GUID)
				{
					OnSyncFrameCRCEvent(pMsg);
				}
				else if( pMsg->GetGuidID() == Events::MarshallerResumeEvent::EVENT_GUID )
				{
					OnResumeEvent();
				}
				else if( pMsg->GetGuidID() == Events::MarshallerPauseEvent::EVENT_GUID )
				{
					OnPauseEvent( pMsg );
				}
				else if( pMsg->GetGuidID() == Events::MarshallerOnlineStatusEvent::EVENT_GUID )
				{
					OnMarshallerOnlineStatusEvent( pMsg );
				}
				else 
				{
					OnOtherEvent(pMsg);
				}
			}

			m_ComponentMsgBox->ClearInbox();
			m_ComponentMsgBox->ClearOutbox();
		}

		void MarshallerComponent::OnAssignVirtualControllers(const Axiom::EventMsg* pMsg)
		{
			const Events::AssignVirtualControllers* pAssignConEvent = pMsg->GetClass< Events::AssignVirtualControllers >();
			const unsigned int numVirtControllers = pAssignConEvent->mNumControllers;

			AP_ASSERT( numVirtControllers > 0 );

			for( unsigned int i = 0; i < mEventLog.Count(); ++i )
			{
				AP_DELETE( mEventLog[ i ] );
			}

			mEventLog.Clear();

			for( unsigned int i = 0; i < numVirtControllers; ++i )
			{
				mEventLog.Add( AP_NEW( Axiom::Memory::DEFAULT_HEAP, EventBufferEntry( pAssignConEvent->mVirtualControllers[i], mMaxNumFrames, mMaxEventBufferSize ) ) );
			}
		}

		void MarshallerComponent::OnStartMarshallingEvent(const Axiom::EventMsg* pMsg)
		{
			UNUSED_PARAM(pMsg);

			AP_ASSERT( !mEventLog.IsEmpty() );

			// Start the event logger as the game starts
			Reset();
			StartEventLogger();	
		}

		void MarshallerComponent::OnStopMarshallingEvent(const Axiom::EventMsg* pMsg)
		{
			UNUSED_PARAM(pMsg);

			Reset();

			mSimFrame = -1;
			mSyncedFrame = -1;
		}

		void MarshallerComponent::OnSyncFrameMarshallingEvent(const Axiom::EventMsg* pMsg)
		{
			UNUSED_PARAM(pMsg);
		}

		void MarshallerComponent::OnRemoteMarshallFrameEvent(const Axiom::EventMsg* pMsg)
		{
			const Events::RemoteMarshallFrameEvent* remoteEvent =  pMsg->GetClass<Events::RemoteMarshallFrameEvent>();
			AP_ASSERT(remoteEvent->mFrameEvent && remoteEvent->mFrameEvent->IsWriteLock()==1 && remoteEvent->mFrameEvent->GetCount()>0);
			AP_ASSERT(remoteEvent->mConfirmFrameTick == remoteEvent->mFrameEvent->GetFrameTick());

#if ONLINE_DEBUGGING_DISPLAY_EVENTS_SEND
			Axiom::Log("marshaller", "Received frame event, frame tick =[%d], frame event size =[%d], frame count= [%d].",
				remoteEvent->mFrameEvent->GetFrameTick(), remoteEvent->mFrameEvent->GetDataSize(), remoteEvent->mFrameEvent->GetCount());
#endif

			//DAY 10/16/2008 5:53:46 PM  Sigh.
			FrameEvent tempFrames[ 8 ];
			AP_ASSERT( mEventLog.Count() < 8 );

			for(unsigned int i = 0; i < remoteEvent->mFrameEvent->GetCount(); i++)
			{
				Axiom::EventMsg *pEventMsg = reinterpret_cast<Axiom::EventMsg*>((*(remoteEvent->mFrameEvent))[i]);
				if(pEventMsg->GetGuidID() == Events::SyncFrameCRCEvent::EVENT_GUID)
				{
					const Events::SyncFrameCRCEvent *pSyncFrameCrc =  pEventMsg->GetClass<Events::SyncFrameCRCEvent>();
					DebugEventLogger::EventEntry eventEntry;
					
					if(mDebugEventLogger && pSyncFrameCrc->mFrameTick>=mDebugEventLogger->GetStartTick() && pSyncFrameCrc->mFrameTick <= mDebugEventLogger->GetLastTickToLog())
					{
						mDebugEventLogger->GetFrameEventData(pSyncFrameCrc->mFrameTick, eventEntry);

						Axiom::Log("Marshaller","PLAYBACK tick[%d] log_crc:%u == sim_crc:%u", pSyncFrameCrc->mFrameTick, eventEntry.mCRC, pSyncFrameCrc->mCRC);
						AP_ASSERTMESSAGE(eventEntry.mCRC == pSyncFrameCrc->mCRC,"EVENT_LOGGER: DESYNC DETECTED!!");

						if( pSyncFrameCrc->mFrameTick == LAST_LOG_FRAME)
						{
							Axiom::Log("EventLogger","PLAYBACK FINISHED - NO DESYNCS!!!");			
						}
					}
				}
				else
				{
					Input::Events::SynchAbleInputEvent* pControllerSyncMsg = reinterpret_cast<Input::Events::SynchAbleInputEvent*>(pEventMsg);
					const Axiom::UInt32 virtualConId = static_cast<Axiom::UInt32>(pControllerSyncMsg->GetControllerId());

					for( unsigned int j = 0; j < mEventLog.Count(); j++ )
					{												
						if( mEventLog[j]->mVirtualControllerId == virtualConId )
						{	
							tempFrames[j].SetFrameTick( remoteEvent->mFrameEvent->GetFrameTick() );
							tempFrames[j].Add( pControllerSyncMsg );						
						}
					}
				}
			}	

			for( unsigned int i=0; i < mEventLog.Count(); i++)
			{
				if( tempFrames[i].GetCount() > 0 )
				{
					mEventLog[i]->mEventBuffer.AddEventFrame( tempFrames[i] );
				}

				AP_ASSERTMESSAGE(Axiom::Math::Abs(mEventLog[i]->mLastFrameTickStored - remoteEvent->mConfirmFrameTick)==1, "Desync Detected!!");
				mEventLog[i]->mLastFrameTickStored = remoteEvent->mConfirmFrameTick;
			}

			remoteEvent->mFrameEvent->SetWriteLock(0);
		}

		void MarshallerComponent::OnSyncFrameCRCEvent(const Axiom::EventMsg* pMsg)
		{
			if((IsStarted() && mRunMode != RM_Normal))
			{
				AP_ASSERT(mDebugEventLogger);
				
				const Events::SyncFrameCRCEvent *pSyncFrameCrc =  pMsg->GetClass<Events::SyncFrameCRCEvent>();

				if(( mRunMode == RM_LogEvents && !mDebugEventLogger->IsLoggingCompleted()) || IsDesyncCRCTestOn())
				{			
					int crc = pSyncFrameCrc->mCRC;
					int frameTick = pSyncFrameCrc->mFrameTick;
					AP_ASSERT((frameTick +1) <=mSimFrame);

					mDebugEventLogger->LogFrameEventData(frameTick,crc);
					
					Axiom::Log("Marshaller", "LOGGING tick[%d] sim_crc:%u\n", frameTick, crc);

					if( mDebugEventLogger->IsLoggingCompleted())
					{
						mDebugEventLogger->EndLog();
						Axiom::Log("EventLogger","LOGGING FINISHED!!!");	
					}
				}
				else if(mRunMode == RM_PlaybackEventLog)
				{
					AP_ASSERT(mDebugEventLogger);
					
					DebugEventLogger::EventEntry eventEntry;
					if(pSyncFrameCrc->mFrameTick>=mDebugEventLogger->GetStartTick() && 
					   pSyncFrameCrc->mFrameTick <= mDebugEventLogger->GetLastTickToLog())
					{
						mDebugEventLogger->GetFrameEventData(pSyncFrameCrc->mFrameTick, eventEntry);

						Axiom::Log("Marshaller","PLAYBACK tick[%d] log_crc:%u == sim_crc:%u", pSyncFrameCrc->mFrameTick, eventEntry.mCRC, pSyncFrameCrc->mCRC);
						AP_ASSERTMESSAGE(eventEntry.mCRC == pSyncFrameCrc->mCRC,"EVENT_LOGGER: DESYNC DETECTED!!");

						if( pSyncFrameCrc->mFrameTick == LAST_LOG_FRAME)
						{
							Axiom::Log("EventLogger","PLAYBACK FINISHED - NO DESYNCS!!!");
						}

					}
				}
			}
		}			

		void MarshallerComponent::OnMarshallerOnlineStatusEvent(const Axiom::EventMsg* pMsg)
		{
			const Events::MarshallerOnlineStatusEvent* evt = pMsg->GetClass< Events::MarshallerOnlineStatusEvent >();
			mOnline = evt->IsOnline();

			Axiom::Log( "Marshaller", "marshaller is %s", mOnline ? "now ONLINE" : "now OFFLINE" );

			Events::MarshallerFrameInfoEvent myEvt;
			BroadCastEvent( &myEvt );
		}

		void MarshallerComponent::OnOtherEvent(const Axiom::EventMsg* pMsg)
		{
			if( !IsSyncAbleEvent( pMsg->GetGuidID() ) )
			{
				BroadCastEvent( pMsg );
			}
			else
			{
				if( pMsg->GetGuidID() == Events::RemotePauseEvent::EVENT_GUID )
				{
					mPauseState = E_PauseQueued;
				}

#if DEBUG_EVENT_TRACKING
				if( Axiom::StringFindString( pMsg->GetName(), "GameIntention" ) )
				{
					const Input::Events::SynchAbleInputEvent* pControllerSyncMsg = static_cast< const Input::Events::SynchAbleInputEvent* >( pMsg );

					if( pControllerSyncMsg->mId < Axiom::DebugEventTracking::gMarshallerTimes.Capacity() )
					{
						Axiom::DebugEventTracking::gMarshallerTimes[ pControllerSyncMsg->mId ] = Axiom::TimeAbsolute::GetSystemTime().AsInt64InMicroseconds();
					}
				}
#endif
					

				// If Marshalling is started, then we buffer the events 
				if(IsStarted() && mRunMode !=RM_PlaybackEventLog)
				{
					const Input::Events::SynchAbleInputEvent* pControllerSyncMsg = static_cast< const Input::Events::SynchAbleInputEvent* >( pMsg );
					const Axiom::UInt32 virtualConId = static_cast< Axiom::UInt >( pControllerSyncMsg->GetControllerId() );

					for( unsigned int i=0; i<mEventLog.Count(); i++)
					{
						if( mEventLog[i]->mVirtualControllerId == virtualConId )
						{
							mEventLog[i]->mUnCompleteFrame.Add(pControllerSyncMsg);			
						}
					}
				}
			}
		}
	}
}

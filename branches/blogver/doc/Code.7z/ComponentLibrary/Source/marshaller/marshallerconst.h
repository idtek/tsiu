#ifndef _MARSHALLER_CONST_H__
#define _MARSHALLER_CONST_H__

namespace AP
{

	namespace Marshaller
	{
		// Number of frames per event to make an frame event
		#define	MAX_NUM_EVENT_PER_FAME 12

		// right now these match whats passed into marshaller pre init.  I want to get rid of these
#if CORE_WII
		#define	MAX_FRAMEEVENT_SIZE 512//6 * 1024 / 24
#else
		#define	MAX_FRAMEEVENT_SIZE 512//6 * 1024 / 24
#endif
	}
}
#endif


#ifndef __MARSHALLEREVENT_MESSAGES_H___
#define __MARSHALLEREVENT_MESSAGES_H___

#include <collections/array.h>
#include <input/inputeventmessages.h>

namespace AP
{
	namespace Marshaller
	{
		class FrameEvent;
		class FrameEventContainer;

		namespace Events
		{
			class EmptyMarshallFrameEvent : public AP::Input::Events::SynchAbleInputEvent
			{
			public:
				EVENT_MSG_GUID(EmptyMarshallFrameEvent )

				//unsigned char	GetControllerId() {return ControllerEvent::GetControllerId();}
				EmptyMarshallFrameEvent() :
					AP::Input::Events::SynchAbleInputEvent(EVENT_GUID,0)
				{
					// Empty method body
				}

				EmptyMarshallFrameEvent(int virtualControllerId) :
					AP::Input::Events::SynchAbleInputEvent(EVENT_GUID,virtualControllerId)
				{
					// Empty method body
				}
			};

			class RemoteMarshallFrameEvent: public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(RemoteMarshallFrameEvent)//Msg_RemoteMarshallFrameEvent

				RemoteMarshallFrameEvent() : 
					Axiom::EventMsg(EVENT_GUID),mConfirmFrameTick(0),mFrameEvent(NULL)
				{
					// Empty method body
				}

				RemoteMarshallFrameEvent(AP::Marshaller::FrameEvent *pFrameEvent,int frameTick) : 
					Axiom::EventMsg(EVENT_GUID),
					mConfirmFrameTick( frameTick ),
					mFrameEvent( pFrameEvent )
				{
				}

				int							mConfirmFrameTick;
				AP::Marshaller::FrameEvent* mFrameEvent;
			};

			class LocalMarshallFrameEvent: public Axiom::EventMsg
			{
				public:
					EVENT_MSG_GUID(LocalMarshallFrameEvent)
				
					LocalMarshallFrameEvent():Axiom::EventMsg(EVENT_GUID),mFrameEvent(NULL){}
					
					LocalMarshallFrameEvent(AP::Marshaller::FrameEventContainer *pFrameEvent):Axiom::EventMsg(EVENT_GUID)
					{
						mFrameEvent = pFrameEvent;
					}

					AP::Marshaller::FrameEventContainer* mFrameEvent;
			};

			class AssignVirtualControllers : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(AssignVirtualControllers)

				AssignVirtualControllers() : 
					Axiom::EventMsg(EVENT_GUID),
					mNumControllers( 0 )
				{
					Axiom::MemorySet( &mVirtualControllers[0], 0, sizeof( mVirtualControllers ) );
				}

				unsigned int mNumControllers;
				Axiom::Collections::StaticArray< unsigned int, 8 > mVirtualControllers;
			};

			class StartMarshallingEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(StartMarshallingEvent)
					
				StartMarshallingEvent():Axiom::EventMsg(EVENT_GUID){}
			};

			class StopMarshallingEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(StopMarshallingEvent)
					
				StopMarshallingEvent():Axiom::EventMsg(EVENT_GUID){}
			};

			class SyncFrameMarshallingEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(SyncFrameMarshallingEvent)
					
				SyncFrameMarshallingEvent():Axiom::EventMsg(EVENT_GUID),mFrameTick(0){}
				SyncFrameMarshallingEvent(int frame):Axiom::EventMsg(EVENT_GUID),mFrameTick(frame){}

				int mFrameTick;
			};
	
			class SyncFrameCRCEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(SyncFrameCRCEvent)

				SyncFrameCRCEvent():Axiom::EventMsg(EVENT_GUID){}
				SyncFrameCRCEvent(unsigned int crc, int frameTick, int seed):Axiom::EventMsg(EVENT_GUID), mCRC(crc), mFrameTick(frameTick), mSeed(seed){}
				unsigned int mCRC;
				int mFrameTick;
				int mSeed;
			};

			class MarshallerPauseEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(MarshallerPauseEvent);

				MarshallerPauseEvent( Axiom::Bool isRemote ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mIsRemote( isRemote )
				{
				}

				Axiom::Bool IsRemote() const {return mIsRemote;}

			private:
				Axiom::Bool	mIsRemote;
			};

			class MarshallerOnlineStatusEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(MarshallerOnlineStatusEvent)

				MarshallerOnlineStatusEvent( Axiom::Bool isOnline ) : 
					Axiom::EventMsg( EVENT_GUID ),
					mIsOnline( isOnline )
				{
				}

				Axiom::Bool IsOnline() const {return mIsOnline;}

			private:
				Axiom::Bool	mIsOnline;
			};

			class MarshallerResumeEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(MarshallerResumeEvent)

				MarshallerResumeEvent():Axiom::EventMsg(EVENT_GUID){}
			};

			class RemotePauseEvent : public AP::Input::Events::SynchAbleInputEvent
			{
			public:
				EVENT_MSG_GUID( RemotePauseEvent )

				RemotePauseEvent() :
					AP::Input::Events::SynchAbleInputEvent(EVENT_GUID,0)
				{
				}

				RemotePauseEvent( int virtualControllerId ) :
					AP::Input::Events::SynchAbleInputEvent(EVENT_GUID, virtualControllerId)
				{
				}


				AP_DECLARE_POLYMORPHIC_TYPE();
			};

			//The info needed to establish a frame factory conforming to the marshallers setup

			class MarshallerFrameInfoEvent : public Axiom::EventMsg
			{
			public:
				EVENT_MSG_GUID(MarshallerFrameInfoEvent)

				MarshallerFrameInfoEvent( ) : 
					Axiom::EventMsg( EVENT_GUID )
				{
				}

				unsigned int mMaxNumEvents;
				unsigned int mMaxEventSize;
			};
		}
	}

}
#endif

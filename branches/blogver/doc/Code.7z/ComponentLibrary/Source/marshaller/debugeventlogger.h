#ifndef _EVENT_LOGGER_H___
#define _EVENT_LOGGER_H___

#include <files/common.h>
#include <files/handle.h>

#include <collections/array.h>

namespace Axiom
{
	namespace FileManager
	{
		class FileManager;
	}
}

namespace AP
{
	namespace Marshaller
	{	
		//Temp.
		static const unsigned int MAX_NUM_VIRTUAL_CONTROLLER_SLOT = 16;

		class DebugEventLogger
		{
		public:
			static const int MAX_NUM_LOG_EVENTS = 300;
			static const int DATA_SIZE = sizeof(FrameEvent);
			
			enum LogMode
			{
				LM_Logging,
				LM_Playback,
				LM_LogWithNoFileSave
			};

			struct DataSlot
			{
				int mDataSize;
				Axiom::Byte mData[DATA_SIZE];
			};

			struct EventEntry
			{
				EventEntry():mCRC(0){ Axiom::MemorySet(mDataSlot,0,MAX_NUM_VIRTUAL_CONTROLLER_SLOT*sizeof(DataSlot));}

				FrameEvent* GetFrame(int slot)
				{
					FrameEvent* pEvent =  AP_PLACEMENT_NEW((void*)mDataSlot[slot].mData) FrameEvent(*(FrameEvent*)mDataSlot[slot].mData);
					AP_ASSERTMESSAGE(pEvent!=NULL, "Ensure that frame event exist..");
					pEvent->SetData(pEvent->GetData(), pEvent->GetDataSize());
					return pEvent;
				}

				unsigned int mCRC;
				DataSlot	mDataSlot[MAX_NUM_VIRTUAL_CONTROLLER_SLOT];
			};

			DebugEventLogger();
			~DebugEventLogger();

			// Start a log and open a log file
			void StartLog( const Axiom::FileManager::VirtualFilePathString& filename, LogMode mode, int startFrameTick, int lastFrameTick, int maxSlots);

			// End the log, write to file, and close file
			void EndLog();

			// Log the event, and write event buffer to file up to the last valid reported CRC
			void LogFrameEventData( int frameTick, unsigned int slot, FrameEvent *pFrameEvent);
			
			// Write back CRC
			void LogFrameEventData( int frameTick, unsigned int mCRC);

			// Accessors
			bool GetFrameEventData(int frameTick, EventEntry &eventEntry);
			int	 GetStartTick() const		{return mStartFrameTick;}
			int  GetLastTickToLog()const	{return mLogUpToFrame;}
			int  GetLastFullFrame()const	{return mLastReportedCRCFrame;}
			bool IsLoggingCompleted()		{AP_ASSERT(mMode ==LM_Logging); return (mLastReportedCRCFrame == mLogUpToFrame);}

		protected:
			void WriteToFile(int numEntries);
			bool ReadFromFile();

		private:
			Axiom::Collections::StaticArray< EventEntry, MAX_NUM_LOG_EVENTS > mLog;
			int						mStartFrameTick;
			unsigned int			mNumSlots;

			Axiom::FileManager::VirtualFilePathString			mLogFileName;	
			Axiom::FileManager::Handle							mLogHandle;
			Axiom::FileManager::FileManager*					mFileManager;
			
			LogMode					mMode;
			int						mLastReportedCRCFrame;
			int						mLogUpToFrame;
		};
	}
}
#endif

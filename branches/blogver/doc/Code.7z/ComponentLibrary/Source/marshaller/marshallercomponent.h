#ifndef _MARSHALLER_COMPONENT_H__
#define _MARSHALLER_COMPONENT_H__

#include "collections/list.h"
#include "kernel/component.h"

#include "marshaller/eventbuffer.h"

namespace AP
{
	namespace Marshaller
	{
		class DebugEventLogger;

		class MarshallerComponent: public Component
		{
		public:

			enum RunMode
			{	
				RM_Normal,
				RM_LogEvents,
				RM_PlaybackEventLog,
				RM_OnlineEventLog

			};

			MarshallerComponent(Axiom::ConstStr name, Kernel* kernel);
			~MarshallerComponent();

			void									OnInit();
			void									OnUpdate();
			void									OnShutdown();
			
			void									SetRunMode(RunMode mode){mRunMode = mode;}
			void									OverrideLogFileName(const char* name) {mLogFileName = name;}
			void									Reset();
			void									AddSyncAbleEvent(Axiom::EventMsgId eventId);

			void									PreInit( unsigned int maxNumSyncAbleEvents, unsigned int maxNumVirtualControllers, unsigned int maxNumFrames, unsigned int maxEventBufferSize );

		protected:
			bool									IsSyncAbleEvent(Axiom::EventMsgId eventId) const;																			
			void									BroadCastEvent( const Axiom::EventMsg *pEvent);
			bool									IsStarted() const;
			
			void									StartEventLogger();
			bool									IsOnline() const;
			bool									IsDesyncCRCTestOn() const;
			void									UpdateWithNoFrameSync();
			void									UpdateWithFrameSync();

		private:

			class EventBufferEntry
			{
			public:

				Axiom::UInt32									mVirtualControllerId;
				EventBuffer										mEventBuffer;
				FrameEvent										mUnCompleteFrame;

				int												mLastFrameTickStored;

				EventBufferEntry( unsigned int controllerId, unsigned int maxNumFrames, unsigned int bufferSize  ) :
					mVirtualControllerId( controllerId ),
					mEventBuffer( maxNumFrames, bufferSize ),
					mLastFrameTickStored( -1 )
				{
				}

			private:
				AP_NON_COPYABLE( EventBufferEntry );

			};

			bool												mOnline;
		
			Axiom::Collections::DynamicList< Axiom::EventMsgId >	mSyncAbleEvents;
			//List with event buffer data for each virtual controller in the game
			Axiom::Collections::DynamicList< EventBufferEntry* >		mEventLog;

			int													mSimFrame;
			int													mSyncedFrame;

			unsigned int 										mMaxNumFrames;
			unsigned int 										mMaxEventBufferSize;
			
			//debug event logger stuff

			RunMode												mRunMode;
			DebugEventLogger*									mDebugEventLogger;
			Axiom::ShortString									mLogFileName;
			
			Axiom::EventMsgBoxHandle							m_ComponentMsgBox;
			
			enum E_PauseEventState
			{
				E_NoPause,
				E_PauseQueued,
				E_PauseSent
			};

			E_PauseEventState									mPauseState;

		private:

			bool												IsPaused() const;

			void												OnPauseEvent( const Axiom::EventMsg* pMsg );
			void												OnResumeEvent();

			void												HandleEvents();

			void												OnAssignVirtualControllers(const Axiom::EventMsg* pMsg);
			void												OnStartMarshallingEvent(const Axiom::EventMsg* pMsg);
			void												OnStopMarshallingEvent(const Axiom::EventMsg* pMsg);
			void												OnSyncFrameMarshallingEvent(const Axiom::EventMsg* pMsg);
			void												OnRemoteMarshallFrameEvent(const Axiom::EventMsg* pMsg);
			void												OnMarshallerOnlineStatusEvent(const Axiom::EventMsg* pMsg);
			void												OnSyncFrameCRCEvent(const Axiom::EventMsg* pMsg);
			void												OnOtherEvent(const Axiom::EventMsg* pMsg);							
		};
	}
	
}
#endif

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef _COMPONENT_LIBRARY_UNIT_TEST_STDAFX_H__
#define _COMPONENT_LIBRARY_UNIT_TEST_STDAFX_H__
#include <core/core.h>

// TODO: reference additional headers your program requires here
#endif

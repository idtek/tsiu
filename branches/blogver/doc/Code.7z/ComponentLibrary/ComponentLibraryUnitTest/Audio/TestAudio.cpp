#include "eventsystem/eventman.h"
#include "audio/audioeventmessages.h"
#include "audio/audio.h"
#include "AudioTestEvents.h"
#include "TestAudio.h"

using namespace AP;

namespace AP
{
	AP_TYPE(EAudioMixes)
		AP_ENUM()
	AP_TYPE_END()
	
	
	//-------------------------------------------------------------------------------
	void AudioTriggers::Init()
	{
		if (mInstance == NULL)
		{
			mInstance = AP_NEW (Axiom::Memory::AUDIO_HEAP, AudioTriggers) ;
		}
		AP::Audio::AudioSystem::GetInstance ()->SetAudioEvents (mInstance);
		AP_ASSERTMESSAGE(mInstance != NULL, "Error allocating memory for the audio trigger list");
	} 

	int AudioTriggers::GetEventCount() 
	{
		return EAudioTestEvents::NumberOfItems;
	}

	const char*	AudioTriggers::GetEventName(int eventId)
	{
		return EAudioTestEvents::StringValue (eventId);
	}

	bool AudioTriggers::GetNYsyncMusicGroup(int which, AP::Audio::AudioSystem* audio)
	{
		UNUSED_PARAM(which);
		UNUSED_PARAM(audio);

		/*if (which == 0)
		{
			int IndicesForFE [] = {
								EAudioEventList::FEMusic_Play, 
								EAudioEventList::FEMusic_Level2, 
								EAudioEventList::FEMusic_Level3, 
								EAudioEventList::FEMusic_GenLoad};
			audio->CreateMusicTransitionGroup(IndicesForFE, 4);
			return true;
		}*/

		// not implemented as unit test yet
		return false;
	}
	//-------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------

	void	AudioMixes::Init ()
	{
		if (mInstance == NULL)
		{
			mInstance = AP_NEW (Axiom::Memory::AUDIO_HEAP, AudioMixes) ;
			AP::Audio::AudioSystem::GetInstance ()->SetAudioMixes (mInstance);
		}
	}

	int AudioMixes::GetMixCount() 
	{
		return EAudioMixes::NumberOfItems;
	}

	const char*	AudioMixes::GetMixName(int mixId)
	{
		return EAudioMixes::StringValue (mixId);
	}

	//-------------------------------------------------------------------------------
}

// ComonentLibraryUnitTest.cpp : Defines the entry point for the application.
//
// Desc: 
//
// This test sets up a 3 component graph and injects sleeps into that thread structure
// it then measures if the threads are deadlocking or not by tracking signals sent to signals
// received.
//-------------------------------------------------------------------------------------
#include <kernel/kernel.h>
#include <kernel/componentmanager.h>
#include <unittesting.h>
#include "AudioTestEvents.h"
#include "TestAudio.h"
#include "AudioDriverComponent.h"

using namespace AP;
using namespace AP::AudioComponentUnitTest;

#if CORE_WII

#include <audiowii/audiocomponent.h>
#include <audiowii/audioeventmessages.h>

using namespace AP::AudioWii;

#else

#include <audio/audiocomponent.h>
#include <audio/audioeventmessages.h>

using namespace AP::Audio;

#endif

#define AUDIO_COMPONENT_TEST_KERNELID 0

BEGIN_UNITTESTGROUP( AudioComponentTestGroup )
{
	KernelConfig kernelConfig;
	kernelConfig.AddKernel(AUDIO_COMPONENT_TEST_KERNELID, "AudioTestKernel", 0, Axiom::Thread::TP_HIGH, Axiom::Memory::DEFAULT_HEAP);

	AP::ComponentManager::Init(Axiom::Memory::DEFAULT_HEAP);
	AP::ComponentManager *pComponentManager = AP::ComponentManager::GetInstance();
	pComponentManager->InitComponentManager(Axiom::Memory::DEFAULT_HEAP, 1, 4);
	pComponentManager->InitKernels(kernelConfig);

	AudioComponent* 		pAudioComponent 		= pComponentManager->CreateComponent<AudioComponent>(      "COMPONENT_AUDIO",	     AUDIO_COMPONENT_TEST_KERNELID);
	AudioDriverComponent*	pAudioDriverComponent	= pComponentManager->CreateComponent<AudioDriverComponent>("COMPONENT_AUDIO_DRIVER", AUDIO_COMPONENT_TEST_KERNELID);
	
	// Create the topology... pretty simple. Driver sends messages at
	// certain intervals to the audio component
	pComponentManager->Connect(pAudioDriverComponent, pAudioComponent);

	// Register for events
#if CORE_WII
	pAudioComponent->RegisterListenEvent( AP::AudioWii::Events::AudioPlaySoundEvent::EVENT_GUID );
#else
	pAudioComponent->RegisterListenEvent( AP::Events::AudioPlaySoundEvent::EVENT_GUID );
#endif

	BEGIN_UNITTEST( AudioInitTest )
	{
		// Initialize all components
		pComponentManager->InitializeAllComponents();

		 // Start all components
	    pComponentManager->StartAllComponents();
	}
	END_UNITTEST

	BEGIN_UNITTEST( AudioSoundTest ) // Test Audio playback from Memory
	{
		pAudioDriverComponent->TestSounds();
		
		// Give the component test thread some time to execute
		Axiom::Thread::Sleep(5000);

		// For now, listen to make sure we hear sounds?
		
	}
	END_UNITTEST
	
	BEGIN_UNITTEST( AudioStreamTest )
	{
	    pAudioDriverComponent->TestStreams();
		
		// Give the component test thread some time to execute
		Axiom::Thread::Sleep(5000);

		// For now, listen to make sure we hear sounds?
	}
	END_UNITTEST

	//Not as much a test as a need to do

	BEGIN_UNITTEST( AudioShutdownTest)
	{
		pComponentManager->RequestShutdown();

		Axiom::Int32 ShutdownTimeoutMs = 500;
		Axiom::Int32 MsElapsed = 0;
		while(pComponentManager->IsAllComponentActive())
		{
			Axiom::Thread::Sleep(50);
			MsElapsed += 50;
			UTF_CHECK(MsElapsed < ShutdownTimeoutMs)
		}
	}
	END_UNITTEST
	
	AP::ComponentManager::Destroy();
}
END_UNITTESTGROUP( AudioComponentTestGroup )



#ifndef AUDIO_DRIVER_COMPONENT_H__
#define AUDIO_DRIVER_COMPONENT_H__

#include <kernel/component.h>
#include <kernel/systemtimer.h>
#include <collections/list.h>
#include "AudioTestEvents.h"

// test class that increments a counter during it's update and sends an event out with the counters new value
// a listener class will pick that event up and report it.
namespace AP
{
	namespace AudioComponentUnitTest
	{
		static const float TEST_PERIODICITY = 2.0f;
		
		class AudioDriverComponent : public AP::Component
		{
			public:
				AudioDriverComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~AudioDriverComponent();

				virtual void	OnInit();
				virtual void	OnUpdate();
				virtual void	OnShutdown();
				virtual void	HandleEvents();

				void			ReportTestsResults();

				// Actual Audio Tests:
				void			TestStreams();
				void			TestSounds();
				void			TestStress();
				void 			TestSurround();
				
			private:
				void 						InitTestCases();
				
				Axiom::EventMsgBoxHandle	m_ComponentMsgBox;
				AP::System::Timer			m_Timer;
				bool						m_Quit;
		};
	}
}

#endif // AUDIO_DRIVER_COMPONENT_H__

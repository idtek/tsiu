#include <audio/audioeventmessages.h>
#include <audio/audio.h>
#include "TestAudio.h"
#include "AudioDriverComponent.h"

//#include <string>
//[rui]#include <iostream>

// Driver Class
// this will inject the sleeps into the system defined for these unit tests

using namespace AP::Audio;

namespace AP
{
	namespace AudioComponentUnitTest
	{

		AudioDriverComponent::AudioDriverComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name,kernel)
            , m_ComponentMsgBox( NULL )
		{
		   m_Quit = false;
		}

		AudioDriverComponent::~AudioDriverComponent()
		{
		
		}

		void AudioDriverComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Driver");
			m_Timer.Start();
			InitTestCases();
			
		}

		void AudioDriverComponent::InitTestCases()
		{
		  
		}

		void AudioDriverComponent::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				//const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
			}
		}

		void AudioDriverComponent::OnUpdate()
		{
			HandleEvents();
			
			if (!m_Quit)
			{
				if(m_Timer.GetElapseTime() > TEST_PERIODICITY)
				{
					m_Timer.Start();

					// AlexE : this needs to be revisited. Decide which audio component to use at a later time.
					
					//Events::AudioPlaySoundEvent PlaySound1(EAudioTestEvents::AudioTestEvent01, 1.00f, 0, 0, 0);
					//int id = EAudioTestEvents::AudioTestEvent01;
					//Events::AudioPlaySoundEvent PlaySound2(EAudioTestEventList::AudioTestEvent02, 1.00f, 0, 0, 0);
					//Events::AudioPlaySoundEvent PlaySound3(EAudioTestEventList::AudioTestEvent01, 1.00f, 0, 0, 0);
					//mEventMan.DistributeEvent(&PlaySound1);
					//mEventMan.DistributeEvent(&PlaySound2);
					//mEventMan.DistributeEvent(&PlaySound3);

					Axiom::Log("audiotest", "Dispatched PlaySoundEvent");
				}
			}
		}

		void AudioDriverComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}

		void AudioDriverComponent::TestStreams()
		{
			
		}

		void AudioDriverComponent::TestSounds()
		{

		}

		void AudioDriverComponent::TestSurround()
		{

		}

		void AudioDriverComponent::TestStress()
		{

		}
		

	}  // namespace ComponentLibraryUnitTest

}  // namespace AP


#ifndef _TEST_AUDIO_H
#define _TEST_AUDIO_H

namespace AP
{

#include "core/classedenum.h"
#undef REFLECTENUMCLASS
#define REFLECTENUMCLASS AP_DECLARE_TYPE();

CLASSEDENUM (EAudioMixes, \
				CLASSEDENUM_ITEMSTART(AudioTestDefaultMix)\
				CLASSEDENUM_ITEM(AudioTestMix01) \
				CLASSEDENUM_ITEM(AudioTestMix02), \
				AudioTestDefaultMix \
			)

CLASSEDENUM (EAudioTestEvents, \
				CLASSEDENUM_ITEMSTART(AudioTestEvent01)\
				CLASSEDENUM_ITEM(AudioTestEvent02) \
				CLASSEDENUM_ITEM(AudioTestEvent03) \
				CLASSEDENUM_ITEM(AudioTestEvent04), \
				AudioTestEvent01 \
			)
}

#endif // _TEST_AUDIO_H

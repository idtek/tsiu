#ifndef AUDIOEVENTS_H___
#define AUDIOEVENTS_H___

#ifndef __MESSAGES_H
# include "kernel/messages.h"
#endif
#include <eventsystem/eventman.h>

namespace AP
{
	namespace AudioComponentUnitTest
	{
		// Test events sent from the AudioDriverComponent to the AudioComponent

		// Play a sound (in memory)
		class AudioTestEvent_SoundStart : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID(AudioTestEvent_SoundStart);

				AudioTestEvent_SoundStart(): Axiom::EventMsg( EVENT_GUID ) {}
		};

	
		// Stop playing a sound (in memory)
		 class AudioTestEvent_SoundStop : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID(AudioTestEvent_SoundStop);

				AudioTestEvent_SoundStop(): Axiom::EventMsg( EVENT_GUID ) {}
		};

		// Start playing a stream (on disk/dvd)
		 class AudioTestEvent_StreamStart : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID(AudioTestEvent_StreamStart);

				AudioTestEvent_StreamStart(): Axiom::EventMsg( EVENT_GUID ) {}
		};

		// Stop playing a sound (on disk/dvd)
		 class AudioTestEvent_StreamStop : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID(AudioTestEvent_StreamStop);

				AudioTestEvent_StreamStop(): Axiom::EventMsg( EVENT_GUID ) {}
		};
		
	} // namespace AudioComponentUnitTest
}
#endif

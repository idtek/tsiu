#include "TestEventTransceiverComponent.h"
#include "testeventmessages.h"

namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		TestEventTransceiverComponent::TestEventTransceiverComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: TestComponent(name,kernel)
		{
		}

		TestEventTransceiverComponent::~TestEventTransceiverComponent()
		{
		}

		void TestEventTransceiverComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Main");
			m_ComponentMsgBox->RegisterListenBroadcastEvent(TestEvent_IntData::EVENT_GUID);
			m_ComponentMsgBox->RegisterListenBroadcastEvent(SleepBEvent::EVENT_GUID);
		}

		void TestEventTransceiverComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}
		
		void TestEventTransceiverComponent::OnUpdate()
		{
			HandleEvents();
			
			if (m_Sleep)
			{
				//Axiom::Log("[TRANSCEIVER]", "Sleep for %d ms", m_SleepTime);
				Axiom::Thread::Sleep(m_SleepTime);
				m_Sleep = false;
			}
			HandleUpdate();
		}

		void TestEventTransceiverComponent::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
	
				if (pMsg->GetGuidID() == TestEvent_IntData::EVENT_GUID)
				{
					//const TestEvent_IntData* smallDataEvent = baseMsg->GetClass<TestEvent_IntData>();
					//printf("[TRANSCEIVER] < CountEvent %d\n", smallDataEvent.mCount);
					//SetEventHandled(eventId);
				}
				else if (pMsg->GetGuidID() == SleepBEvent::EVENT_GUID)
				{
					const SleepBEvent* sleepEvent = pMsg->GetClass<SleepBEvent>();
					//Axiom::Log("[TRANSCEIVER]", "Received SleepB");
					m_Sleep = true;
					m_SleepTime = sleepEvent->m_Time;
					SetEventHandled(pMsg->GetGuidID());
				}
			}  	
		}

	}  // end namespace ComponentLibraryTest

}// end namespace AP

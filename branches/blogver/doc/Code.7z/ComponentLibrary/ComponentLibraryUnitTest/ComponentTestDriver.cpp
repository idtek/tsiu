#include "ComponentTestDriver.h"
//#include <string>
//[rui]#include <iostream>

// Driver Class
// this will inject the sleeps into the system defined for these unit tests
namespace AP
{
	namespace ComponentLibraryUnitTest
	{

		ComponentTestDriver::ComponentTestDriver(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name,kernel)
		{
			m_TestsPerformed = 0;
			m_TestsVerified = 0;
			m_SentTestCount = 0;
			m_ReceivedTestCount = 0;
			m_Quit = false;
			m_TestsRunning = false;
		}

		ComponentTestDriver::~ComponentTestDriver()
		{
		}

		void ComponentTestDriver::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Main");
			m_ComponentMsgBox->RegisterListenBroadcastEvent( EventVerification::EVENT_GUID ); 
			m_Timer.Start();
			InitTestCases();
			m_TestsPerformed = m_TestCases.Count();
			m_TestsRunning = true;
		}

		void ComponentTestDriver::InitTestCases()
		{
			// define the test cases here:
			TestCase testCases[] = 
			{
				{ 10, SleepBEvent::EVENT_GUID },
				{ 40, SleepAEvent::EVENT_GUID },
				{ 20, SleepCEvent::EVENT_GUID },
				{ 5, SleepBEvent::EVENT_GUID },
				{ 10, SleepCEvent::EVENT_GUID },
				{ 30, SleepCEvent::EVENT_GUID },
				{ 10, SleepBEvent::EVENT_GUID },
				{ 5, SleepBEvent::EVENT_GUID },
				{ 40, SleepBEvent::EVENT_GUID },
				{ 10, SleepCEvent::EVENT_GUID },
				{ 20, SleepBEvent::EVENT_GUID },
				{ 30, SleepCEvent::EVENT_GUID },
				{ 5, SleepAEvent::EVENT_GUID },
				{ 40, SleepCEvent::EVENT_GUID },
				{ 10, SleepAEvent::EVENT_GUID },
				{ 20, SleepCEvent::EVENT_GUID },
				{ 30, SleepAEvent::EVENT_GUID },
			};
			Axiom::uint testSize = sizeof(testCases)/sizeof(TestCase);

			// copy test case to member data:
			for( Axiom::uint i=0; i != testSize; ++i )
			{
				m_TestCases.Add(testCases[i]);
			}
		}

		void ComponentTestDriver::DispatchTestCase(const TestCase& testCase)
		{
			Axiom::EventMsgId EventId = Axiom::INVALID_EVENT_ID;
			Axiom::StaticString<128> name = "";
			
			if (testCase.sleepMsg == SleepAEvent::EVENT_GUID)
			{
				name = "SleepA";
				SleepAEvent sleepA(testCase.sleepTime);
				mEventMan.DistributeEvent(&sleepA);
				EventId = sleepA.GetGuidID();
			}

			else if (testCase.sleepMsg == SleepBEvent::EVENT_GUID)
			{
				name = "SleepB";
				SleepBEvent sleepB(testCase.sleepTime);
				mEventMan.DistributeEvent(&sleepB);
				EventId = sleepB.GetGuidID();
			}

			else if (testCase.sleepMsg == SleepCEvent::EVENT_GUID)
			{
				name = "SleepC";
				SleepCEvent sleepC(testCase.sleepTime);
				mEventMan.DistributeEvent(&sleepC);
				EventId = sleepC.GetGuidID();
			}
			
			else
			{
				name = "SleepB";
				SleepBEvent sleepB(testCase.sleepTime);
				EventId = sleepB.GetGuidID();
				mEventMan.DistributeEvent(&sleepB);
			}


			//Axiom::Log("[DRIVER]", "Sent msg %s (id %d), time %d ms", name, EventId, testCase.sleepTime);
			if (EventId != Axiom::INVALID_EVENT_ID)
			{
				m_SentTests.Add(EventId);
				++m_SentTestCount;
			}
		}

		void ComponentTestDriver::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
	
				if (pMsg->GetGuidID() == EventVerification::EVENT_GUID)
				{
					const EventVerification* myEvent = pMsg->GetClass<EventVerification>();
					m_ReceivedTests.Add(myEvent->m_ReceivedEventGUID);
					++m_ReceivedTestCount;
				}
			}
		}

		void ComponentTestDriver::OnUpdate()
		{
			HandleEvents();
			
			if (!m_Quit)
			{
				ProcessReceivedTests();
				if (m_TestsRunning)
				{
					if(m_Timer.GetElapseTime() > TEST_PERIODICITY)
					{
						if (m_TestCases.Count() != 0)
						{
							m_Timer.Start();
							DispatchTestCase(m_TestCases[0]);
							//Axiom::Log("comptest", "Dispatched Event %d", m_TestCases[0].sleepMsg);
							m_TestCases.RemoveAt(0);
						}
						else
						{
							m_Timer.Start();
							m_TestsRunning = false;
						}
					}
				}
				else
				{
					if (m_Timer.GetElapseTime() > DELAY_FOR_RESULT)
					{
						m_Quit = true;
					}
				}
			}
		}

		void ComponentTestDriver::ReportTestsResults()
		{
			//[rui]std::cout << "Sleep Tests Done.  Tests Performed: " << m_TestsPerformed << ", Tests Verified: " << m_TestsVerified << std::endl;
			if (m_TestsVerified == m_TestsPerformed)
			{
				//[rui]std::cout << "TESTS PASSED" << std::endl;
			}
			else
			{
				//[rui]std::cout << "TESTS FAILED" << std::endl;
			}
		}

		void ComponentTestDriver::ProcessReceivedTests()
		{
			if (m_SentTests.Count() != 0) 
			{
				size_t receivedTestsNum = m_ReceivedTests.Count();
				if (receivedTestsNum > 0)
				{
					for (size_t i = 0; i != receivedTestsNum; ++i)
					{
						if ( m_SentTests.Remove( m_ReceivedTests[i] ) )
						{
							m_ReceivedTests.RemoveAt(i);
							--m_ReceivedTestCount;
							--m_SentTestCount;
							++m_TestsVerified;
							break;
						}
					}
				}
			}
		}

		void ComponentTestDriver::OnShutdown()
		{
			m_TestCases.Clear();
			m_SentTests.Clear();
			m_ReceivedTests.Clear();
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}

	}  // namespace ComponentLibraryUnitTest

}  // namespace AP

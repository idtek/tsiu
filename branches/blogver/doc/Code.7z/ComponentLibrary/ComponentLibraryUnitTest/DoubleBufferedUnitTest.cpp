#include <kernel/kernel.h>
#include <kernel/componentmanager.h>
#include <audio/audiocomponent.h>
#include <unittesting.h>
//#include "audio\double_buffered_data.h"
#include <audio/double_buffered_data.h>
//#include "audio/source/double_buffered_data.h"


DECLARE_UNITTESTGROUP(DoubleBufferSmallGroup)
/*DECLARE_UNITTESTGROUP(DoubleBufferMediumGroup)
DECLARE_UNITTESTGROUP(DoubleBufferLargeGroup)
DECLARE_UNITTESTGROUP(DoubleBuffer2KReadsFrom128KWritesGroup)
DECLARE_UNITTESTGROUP(DoubleBufferReadsTooLargeGroup)*/

BEGIN_UNITTESTGROUP(DoubleBufferGroup)
{
	RUN_UNITTESTSUBGROUP(DoubleBufferSmallGroup);
	/*RUN_UNITTESTSUBGROUP(DoubleBufferMediumGroup);
	RUN_UNITTESTSUBGROUP(DoubleBufferLargeGroup);
	RUN_UNITTESTSUBGROUP(DoubleBuffer2KReadsFrom128KWritesGroup);
	RUN_UNITTESTSUBGROUP(DoubleBufferReadsTooLargeGroup);*/
}
END_UNITTESTGROUP(DoubleBufferGroup)


BEGIN_UNITTESTGROUP(DoubleBufferSmallGroup)
{
	const int TotalBufferSize = 8*1024;
	Axiom::DoubleBufferedData <TotalBufferSize> Source;
	int* Buffer;
	// Testing basic behavior
	BEGIN_UNITTEST(Constructors)
	{
		Axiom::DoubleBufferedData <> Test1;
	}
	END_UNITTEST

	BEGIN_UNITTEST(PushingData)
	{
		const int Size = TotalBufferSize / 2;
		Buffer = AP_NEW (Axiom::Memory::AUDIO_HEAP, int[Size]);
		for (int i=0; i<Size; i++)
		{
			Buffer[i] = i;
		}
		Source.AddDataToBuffer (Buffer, Size);
		//UTF_CHECK (false);
		// unit tests do not work apparently for Component library. 5 hours of work have yielded nothing.
		// Sadly, no one else seems able to help either. - MickeyK
		//UTF_CHECKASSERT (AP_SIMPLEASSERTMESSAGE (0 == 1, "Crap"));
		//UTF_CHECKASSERT(Source.AddDataToBuffer (Buffer, Size));// this would add too much data
	}
	END_UNITTEST

		//UTF_CHECK (
}
END_UNITTESTGROUP( DoubleBufferSmallGroup );
#ifndef TEST_UPDATE_TRANSRECEIVER_COMPONENT_H__
#define TEST_UPDATE_TRANSRECEIVER_COMPONENT_H__

#include "TestComponent.h"

// test class that increments a counter during it's update and sends an event out with the counters new value
// a listener class will pick that event up and report it.
namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		class TestEventTransceiverComponent: public TestComponent
		{
			public:

				TestEventTransceiverComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~TestEventTransceiverComponent();

				virtual void	OnInit();
				virtual void	OnShutdown();
				virtual void	OnUpdate();
				virtual void	OnPostUpdate(){}
				virtual void	HandleEvents();

		};
	}
}
#endif

#if !defined( TEST_LOAD_COMPONENT_H )
#define TEST_LOAD_COMPONENT_H

#include <kernel/component.h>
#include <eventsystem/eventman.h>
#include "resource/rescommon.h"

#include "collections/booklet.h"

namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		class Group
		{
		public:
			
			const static Axiom::UInt maxElementsPerGroup = 10;
		
			class Element
			{
			public:
				Axiom::ShortString	mFileName;
				Axiom::Char*		mBuffer;
			};

		public:		

			Group( const Axiom::Char* name, Axiom::Resource::GroupId id ) :
				mId( id ),
				mName( name )
			{
			}

			Element& AddFile( const Axiom::Char* filename );

			Axiom::Bool operator==( const Group& group ) const
			{
				return ( mId == group.mId );
			}

			Axiom::Resource::GroupId				mId;
			Axiom::ShortString						mName;

			Axiom::Collections::StaticList< Element, maxElementsPerGroup > mElements;
		};

		class TestLoadComponent : public AP::Component
		{
			AP_NON_COPYABLE( TestLoadComponent );
		public:

			TestLoadComponent(Axiom::ConstStr name, AP::Kernel* kernel);
			~TestLoadComponent();

			void	OnInit();
			void	OnShutdown();
			void	OnUpdate();

			Axiom::Bool	IsWaitingForLoad() const {return mWaitingForLoad;}

			void AddElement( const Axiom::Char* name, const Axiom::Char* groupName );

			void SendRecycles( Axiom::Bool force = false );
			void SendFinalRecycle();

			Axiom::UInt	GetNumberOfGroups() const { return mGroups.Count(); }

			void Reset();

		private:

			void HandleEvents();

			Group* GetGroup( Axiom::Resource::GroupId id );

		private:

			Axiom::Bool					mRequestedLoad;
			Axiom::Bool					mWaitingForLoad;
			Axiom::UInt					mLoadedGroups;
			Axiom::EventMsgBoxHandle	m_ComponentMsgBox;

			const static Axiom::UInt maxGroups = 20;

			Axiom::Collections::StaticList< Group, maxGroups > mGroups;

			Axiom::Collections::StaticBooklet< Axiom::ShortString, Axiom::Collections::StaticList< Axiom::ShortString, Group::maxElementsPerGroup >, void, maxGroups > mFileNames;
			
		};
	}
}
#endif	//TEST_LOAD_COMPONENT_H

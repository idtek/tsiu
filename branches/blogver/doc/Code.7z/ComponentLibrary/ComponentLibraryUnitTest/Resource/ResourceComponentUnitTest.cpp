#include <kernel/kernel.h>
#include <kernel/componentmanager.h>

#include <unittesting.h>

#include "resource/resourcecomponent.h"
#include "resource/resourcemessages.h"
#include "resource/resourceinfotable.h"

#include "asyncloader/asyncloadercomponent.h"
#include "asyncloader/asyncloadermessages.h"

#include "testloadcomponent.h"
#include "files/filemanager.h"

using namespace AP;

#if CORE_WIN_BASED_OS

enum KernelType
{
	KernelLoader = 0,
	KernelSim,
};

#else

enum KernelType
{
	KernelSim = 0,
};

#endif


BEGIN_UNITTESTGROUP( ResourceComponentTestGroup )
{
	KernelConfig kernelConfig;
	kernelConfig.AddKernel( KernelSim, "ResourceTestKernel", 0, Axiom::Thread::TP_HIGH, Axiom::Memory::DEFAULT_HEAP );

#if CORE_WIN_BASED_OS
	kernelConfig.AddKernel( KernelLoader, "ResourceLoadKernel", 0, Axiom::Thread::TP_HIGH, Axiom::Memory::DEFAULT_HEAP );
#endif

	AP::ComponentManager::Init( Axiom::Memory::DEFAULT_HEAP );
	AP::ComponentManager* pComponentManager = AP::ComponentManager::GetInstance();
	pComponentManager->InitComponentManager( Axiom::Memory::DEFAULT_HEAP, 2, 4 );
	pComponentManager->InitKernels(kernelConfig);

#if CORE_WIN_BASED_OS
	Axiom::Resource::ResourceComponent* pNewResComp = pComponentManager->CreateComponent< Axiom::Resource::ResourceComponent >( "NEW_RESOURCE_COMPONENT", KernelLoader );
	ComponentLibrary::AsyncLoader::AsyncLoaderComponent* pAsyncComponent = pComponentManager->CreateComponent< ComponentLibrary::AsyncLoader::AsyncLoaderComponent >( "ASYNC_COMPONENT", KernelLoader );
#else
	Axiom::Resource::ResourceComponent* pNewResComp = pComponentManager->CreateComponent< Axiom::Resource::ResourceComponent >( "NEW_RESOURCE_COMPONENT", KernelSim );
	ComponentLibrary::AsyncLoader::AsyncLoaderComponent* pAsyncComponent = pComponentManager->CreateComponent< ComponentLibrary::AsyncLoader::AsyncLoaderComponent >( "ASYNC_COMPONENT", KernelSim );
#endif

	ComponentLibraryUnitTest::TestLoadComponent* pTestComponent =  pComponentManager->CreateComponent< ComponentLibraryUnitTest::TestLoadComponent >( "TEST_LOAD_COMP", KernelSim );

	pComponentManager->Connect( pNewResComp, pTestComponent, CT_BI_DIRECTION );		
	pComponentManager->Connect( pNewResComp, pAsyncComponent, CT_BI_DIRECTION );

	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::CreateResourceGroupEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::CloseResourceGroupEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::AddFilesToResourceGroupEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::MarkResourceGroupForRecycleEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::RecycleResourcesEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( Axiom::Resource::Events::ResourcesAllocatedForGroupEvent::EVENT_GUID );
	pNewResComp->RegisterListenEvent( ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestCompletedEvent::EVENT_GUID );

	pAsyncComponent->RegisterListenEvent( ComponentLibrary::AsyncLoader::Events::AsyncLoaderRequestEvent::EVENT_GUID );

	Axiom::FileManager::FileManager* fileManager = Axiom::FileManager::FileManager::GetInstance();

	pAsyncComponent->PreInit( fileManager );
	pNewResComp->PreInit( fileManager, IN_MB( 45 ), 20, 40 );

	pTestComponent->RegisterListenEvent( Axiom::Resource::Events::ResourceGroupCreatedEvent::EVENT_GUID );
	pTestComponent->RegisterListenEvent( Axiom::Resource::Events::ResourceGroupLoadedEvent::EVENT_GUID );
	pTestComponent->RegisterListenEvent( Axiom::Resource::Events::DeallocateResourceEvent::EVENT_GUID );
	pTestComponent->RegisterListenEvent( Axiom::Resource::Events::AllocateResourcesForGroupEvent::EVENT_GUID );

	//Bad filenames.  Should actually write out files for this.
	pTestComponent->AddElement( "media:\\Superstar.lua", "test" );
	pTestComponent->AddElement( "media:\\debugEnabler.txt", "test" );
	pTestComponent->AddElement( "media:\\anim\\test.anm", "test" );

	//Another group
	pTestComponent->AddElement( "media:\\anim\\handlers.anim", "anotherTest" );

	Axiom::Resource::InfoTable::Init( Axiom::Memory::DEFAULT_HEAP );
	Axiom::Resource::InfoTable::GetInstance()->PreInit( fileManager );

	BEGIN_UNITTEST( ResourceInitTest )
	{
		// Initialize all components
		pComponentManager->InitializeAllComponents();

		UTF_CHECK( pTestComponent->IsWaitingForLoad() );

		 // Start all components
	    pComponentManager->StartAllComponents();
	}
	END_UNITTEST

	BEGIN_UNITTEST( ResourceWaitForLoadTest )
	{
		while( pTestComponent->IsWaitingForLoad() )
		{
			Axiom::Thread::Sleep(50);
		}

		UTF_CHECK( !pTestComponent->IsWaitingForLoad() );
		
	}
	END_UNITTEST

	BEGIN_UNITTEST( ResourceRecycleTest )
	{
		const Axiom::UInt count = pNewResComp->GroupCount();

		pTestComponent->SendRecycles();

		Axiom::Thread::Sleep( 2000 );

		//show we didn't stop tracking anything
		UTF_CHECK( pNewResComp->GroupCount() == count );

		pTestComponent->SendFinalRecycle();

		Axiom::Thread::Sleep( 6000 );

		UTF_CHECK( pNewResComp->GroupCount() == 0 );
		UTF_CHECK( pTestComponent->GetNumberOfGroups() == 0 );
	}
	END_UNITTEST

	BEGIN_UNITTEST( ResourceForceRecycleTest )
	{
		UTF_CHECK( pNewResComp->GroupCount() == 0 );
		pTestComponent->Reset();

		pTestComponent->AddElement( "media:\\Superstar.lua", "thirdTest" );
		pTestComponent->AddElement( "media:\\debugEnabler.txt", "thirdTest" );
		pTestComponent->AddElement( "media:\\anim\\test.anm", "thirdTest" );

		while( pTestComponent->IsWaitingForLoad() )
		{
			Axiom::Thread::Sleep(50);
		}

		UTF_CHECK( pNewResComp->GroupCount() == 1 );

		//force recylces
		pTestComponent->SendRecycles( true );
		
		// no final send, forced recycle
		Axiom::Thread::Sleep(50);		

		//show we have no resources left
		UTF_CHECK( pNewResComp->GroupCount() == 0 );

		Axiom::Thread::Sleep( 100 );	//for events to come back to test component

		UTF_CHECK( pTestComponent->GetNumberOfGroups() == 0 );
	}
	END_UNITTEST

		
	//Not as much a test as a need to do

	BEGIN_UNITTEST( ResourceShutdownTest)
	{
		pComponentManager->RequestShutdown();

		const Axiom::Int32 ShutdownTimeoutMs = 500;
		Axiom::Int32 MsElapsed = 0;
		while(pComponentManager->IsAllComponentActive())
		{
			Axiom::Thread::Sleep(50);
			MsElapsed += 50;
			UTF_CHECK(MsElapsed < ShutdownTimeoutMs)
		}
	}
	END_UNITTEST
	
	AP::ComponentManager::Destroy();
}
END_UNITTESTGROUP( ResourceComponentTestGroup )



#include "TestLoadComponent.h"

#include "resource/resourcemessages.h"
#include "resource/resourceinfotable.h"

namespace AP
{
	namespace ComponentLibraryUnitTest
	{	
		using namespace Axiom::Resource;
		using namespace Axiom::Resource::Events;

		Group::Element& Group::AddFile( const Axiom::Char* filename )
		{
			Element el;
			el.mFileName = filename;
			el.mBuffer = 0;

			mElements.Add( el );	

			return mElements.LastItem();
		}

		TestLoadComponent::TestLoadComponent(Axiom::ConstStr name, AP::Kernel* kernel) :
			AP::Component( name, kernel ),
			mRequestedLoad( false ),
			mWaitingForLoad( true ),
			mLoadedGroups( 0 ),
            m_ComponentMsgBox( NULL )
		{
		}

		TestLoadComponent::~TestLoadComponent()
		{
		}

		void TestLoadComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("TestLoadComponent");
			
			m_ComponentMsgBox->RegisterListenBroadcastEvent( ResourceGroupCreatedEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( ResourceGroupLoadedEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( DeallocateResourceEvent::GetEventId() );
			m_ComponentMsgBox->RegisterListenBroadcastEvent( AllocateResourcesForGroupEvent::GetEventId() );
		}

		void TestLoadComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox( m_ComponentMsgBox );
		}

		void TestLoadComponent::OnUpdate()
		{
			if( !mRequestedLoad )
			{
				for( Axiom::UInt i = 0; i < mFileNames.Count(); ++i )
				{
					CreateResourceGroupEvent myEvt( mFileNames.KeyAt( i ).AsChar(), GetClassHashId() );
					m_ComponentMsgBox->SendEvent( &myEvt );
				}				

				mRequestedLoad = true;
			}

			HandleEvents();

			m_ComponentMsgBox->ClearInbox();
			m_ComponentMsgBox->ClearOutbox();
		}

		void TestLoadComponent::HandleEvents()
		{
			for( Axiom::UInt i = 0; i < m_ComponentMsgBox->GetNumEvents(); ++i )
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent( i );

				if( pMsg->GetGuidID() == ResourceGroupCreatedEvent::EVENT_GUID )
				{
					const ResourceGroupCreatedEvent* theEvent = pMsg->GetClass< ResourceGroupCreatedEvent >();
					
					Group group( theEvent->GetGroupName().AsChar(), theEvent->GetGroupId() );

					Axiom::Collections::StaticList< Axiom::ShortString, Group::maxElementsPerGroup >& list = *mFileNames.Item( group.mName );
					AddFilesToResourceGroupEvent addFilesEvent( group.mId );
					
					AddFilesToResourceGroupEvent::FilesList* filesList = AP_NEW( Axiom::Memory::DEFAULT_HEAP, AddFilesToResourceGroupEvent::FilesList );
					filesList->Resize( Axiom::Memory::DEFAULT_HEAP, list.Count() );			

					for( Axiom::UInt j = 0; j < list.Count(); ++ j )
					{
						Group::Element& el = group.AddFile( list[ j ].AsChar() );
						filesList->Add( Axiom::Pair< Axiom::Resource::Filename, Axiom::UInt >( el.mFileName.AsChar(), el.mFileName.GetHashID() ) );						
					}

					addFilesEvent.SetFilesList( filesList );
					m_ComponentMsgBox->SendEvent( &addFilesEvent );

					mGroups.Add( group );

					CloseResourceGroupEvent closeEvent( group.mId );
					m_ComponentMsgBox->SendEvent( &closeEvent );
				}
				else if( pMsg->GetGuidID() == ResourceGroupLoadedEvent::EVENT_GUID )
				{
					AP_ASSERT_SUPPORTASSIGN(const ResourceGroupLoadedEvent* theEvent, pMsg->GetClass< ResourceGroupLoadedEvent >());

					AP_ASSERT( GetGroup( theEvent->GetGroupId() ) != 0 );

					mLoadedGroups++;

					if( mLoadedGroups == mGroups.Count() )
					{
						mWaitingForLoad = false;
					}
				}
				else if( pMsg->GetGuidID() == DeallocateResourceEvent::EVENT_GUID )
				{
					const DeallocateResourceEvent* theEvent = pMsg->GetClass< DeallocateResourceEvent >();

					Group* group = GetGroup( theEvent->GetGroupId() );
					AP_ASSERT( group );

					for( Axiom::UInt j = 0; j < group->mElements.Count(); ++j )
					{
						if( group->mElements[ j ].mBuffer == theEvent->GetBuffer() )
						{
							AP_FREE( group->mElements[ j ].mBuffer );
							group->mElements.QuickRemoveAt( j );
						}
					}

					if( group->mElements.IsEmpty() )
					{
						mGroups.QuickRemove( *group );
					}
				}
				else if( pMsg->GetGuidID() == AllocateResourcesForGroupEvent::EVENT_GUID )
				{
					const AllocateResourcesForGroupEvent* theEvent = pMsg->GetClass< AllocateResourcesForGroupEvent >();

					ResourcesAllocatedForGroupEvent allocEvent( theEvent->GetGroupId() );

					Group* group = GetGroup( theEvent->GetGroupId() );

					for( unsigned int i = 0; i < theEvent->GetNumberOfResources(); ++i )
					{
						const unsigned int uniqueId = theEvent->GetUniqueId( i );

						for( unsigned int j = 0; j < group->mElements.Count(); ++j )
						{
							Group::Element& el = group->mElements[ j ];

							if( el.mFileName.GetHashID() == uniqueId )
							{
								const Axiom::UInt fileSize = InfoTable::GetInstance()->GetFileSize( el.mFileName.AsChar() );
								el.mBuffer = static_cast< Axiom::Char*>( AP_ALLOC( Axiom::Memory::DEFAULT_HEAP, fileSize ) );

								allocEvent.AddAllocation( el.mBuffer, theEvent->GetFileId( i ) );
							}
						}
					}

					m_ComponentMsgBox->SendEvent( &allocEvent );
				}
			}
		}

		void TestLoadComponent::SendRecycles( Axiom::Bool force )
		{
			for( Axiom::UInt i = 0; i < mGroups.Count(); ++i )
			{
				MarkResourceGroupForRecycleEvent myEvt( mGroups[ i ].mId, force );
				m_ComponentMsgBox->SendEvent( &myEvt );
			}
		}

		void TestLoadComponent::SendFinalRecycle()
		{
			RecycleResourcesEvent myEvt;
			m_ComponentMsgBox->SendEvent( &myEvt );
		}

		void TestLoadComponent::AddElement( const Axiom::Char* name, const Axiom::Char* groupName )
		{
			if( !mFileNames.ContainsKey( groupName ) )
			{
				mFileNames.AddDefault( groupName );
			}

			mFileNames.Item( groupName )->Add( name );
		}

		Group* TestLoadComponent::GetGroup( Axiom::Resource::GroupId id )
		{
			for( Axiom::UInt i = 0; i < mGroups.Count(); ++i )
			{
				if( mGroups[ i ].mId == id )
				{
					return &mGroups[ i ];
				}
			}

			return 0;
		}

		void TestLoadComponent::Reset()
		{
			mRequestedLoad = false; 
			mWaitingForLoad = true; 
			mLoadedGroups = 0; 
			
			mFileNames.Clear();
		}

	}	//namespace ComponentLibraryUnitTest
}	//namespace AP


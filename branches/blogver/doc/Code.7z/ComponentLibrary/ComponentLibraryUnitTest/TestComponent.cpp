#include "TestComponent.h"
#include "testeventmessages.h"
#include <eventsystem/eventman.h>

namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		TestComponent::TestComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: Component(name,kernel)
		{
			m_Sleep = false;
			m_SleepTime = 0;
			m_EventHandled = false;
			m_LastEventGUID = Axiom::INVALID_EVENT_ID;
		}

		TestComponent::~TestComponent()
		{
		}

		void TestComponent::OnInit()
		{
		}

		void TestComponent::ShutDown()
		{
		}

		void TestComponent::OnUpdate()
		{
		}

		void TestComponent::HandleUpdate()
		{
			if (m_EventHandled)
			{
				//printf("<< event processed: %d\n", m_LastEventGUID);
				EventVerification receipt(m_LastEventGUID);

				mEventMan.DistributeEvent(&receipt);
				m_EventHandled = false;
				m_LastEventGUID = Axiom::INVALID_EVENT_ID;
			}
		}

		void TestComponent::SetEventHandled(Axiom::EventMsgId guid)
		{
			m_EventHandled = true;
			m_LastEventGUID = guid;
			//Axiom::Log("comptest", "Event %d handled by component %s", m_LastEventGUID, Name());
		}

	}  // namespace ComponentLibraryTests
}  // namespace AP

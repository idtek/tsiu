#ifndef TEST_UPDATE_RECEIVER_COMPONENT_H__
#define TEST_UPDATE_RECEIVER_COMPONENT_H__

#include "TestComponent.h"

// test class that acts as a listener class for the event sender
// it will pick that event up and report it.
namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		// test class that increments a counter during it's update and sends an event out with the counters new value
		// a listener class will pick that event up and report it.
		class TestEventReceiverComponent: public TestComponent
		{
			public:

				TestEventReceiverComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~TestEventReceiverComponent();

				virtual void			OnInit();
				virtual void			OnUpdate();
				virtual void			OnPostUpdate(){}
				virtual void			HandleEvents();
				virtual void			OnShutdown();

		};

	}
}
#endif

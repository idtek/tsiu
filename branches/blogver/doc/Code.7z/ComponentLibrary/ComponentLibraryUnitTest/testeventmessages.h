#ifndef TESTEVENT_H___
#define TESTEVENT_H___

#ifndef __MESSAGES_H
# include "kernel/messages.h"
#endif
#include <eventsystem/eventman.h>

namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		/*enum TestEventMsg
		{
			Msg_NONE = -1,
			Msg_TestEvent_IntData,
			Msg_TestEvent_BigData,
			Msg_TestEvent_SleepA,
			Msg_TestEvent_SleepB,
			Msg_TestEvent_SleepC,
			Msg_TestEvent_Verify,
		};*/

		class TestEvent_IntData : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( TestEvent_IntData);//, Msg_TestEvent_IntData )

				TestEvent_IntData():EventMsg(EVENT_GUID){}

				TestEvent_IntData(int count):EventMsg(EVENT_GUID),
						mCount(count)
				{
				}

			int mCount;
		};

		class TestEvent_BigData : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( TestEvent_BigData);//, Msg_TestEvent_BigData )

				TestEvent_BigData():EventMsg(EVENT_GUID){}

				TestEvent_BigData(int count) : 
					EventMsg(EVENT_GUID),
						mCount(count)

				{
				}

			int mCount;
		};

		class SleepAEvent : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SleepAEvent);//, Msg_TestEvent_SleepA )

				SleepAEvent():EventMsg(EVENT_GUID){}
				SleepAEvent(int time) : 
					EventMsg(EVENT_GUID),
						m_Time(time)
				{
				}

			int m_Time;
		};

		class SleepBEvent : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SleepBEvent);//, Msg_TestEvent_SleepB )
					
				SleepBEvent():EventMsg(EVENT_GUID){}
				SleepBEvent(int time) : 
					EventMsg(EVENT_GUID),
						m_Time(time)
				{
				}

			int m_Time;
		};

		class SleepCEvent : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( SleepCEvent);//, Msg_TestEvent_SleepC )
				
				SleepCEvent():EventMsg(EVENT_GUID){}

				SleepCEvent(int time) : 
					EventMsg(EVENT_GUID),
						m_Time(time)
				{
				}

			int m_Time;
		};

		class EventVerification : public Axiom::EventMsg
		{
			public:
				EVENT_MSG_GUID( EventVerification);//, Msg_TestEvent_Verify )
					
				EventVerification():EventMsg(EVENT_GUID){}

				EventVerification(Axiom::EventMsgId eventReceived) : 
					Axiom::EventMsg(EVENT_GUID),
						m_ReceivedEventGUID(eventReceived)
				{
				}

			Axiom::EventMsgId	m_ReceivedEventGUID;
		};
	}
}
#endif

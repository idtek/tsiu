#ifndef TEST_COMPONENT_DRIVER_COMPONENT_H__
#define TEST_COMPONENT_DRIVER_COMPONENT_H__

#include <kernel/component.h>
#include <kernel/systemtimer.h>
#include <collections/list.h>
#include "testeventmessages.h"

// test class that increments a counter during it's update and sends an event out with the counters new value
// a listener class will pick that event up and report it.
namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		static const float TEST_PERIODICITY = 5.0f; // time (s) between firing events off
		static const float DELAY_FOR_RESULT = 2.0f; // time (s) to wait until events return ?
		
		class ComponentTestDriver: public AP::Component
		{
			public:
				ComponentTestDriver(Axiom::ConstStr name, AP::Kernel* kernel);
				~ComponentTestDriver();

				virtual void	OnInit();
				virtual void	OnUpdate();
				virtual void	OnShutdown();
				virtual void	HandleEvents();

				bool			TestingComplete() const { return m_Quit; }
				void			ReportTestsResults();


			private:
				static const Axiom::uint	NUM_TESTS = 64;

				struct TestCase
				{
					int					sleepTime;
					Axiom::EventMsgId	sleepMsg;
				};

				typedef Axiom::Collections::StaticList<TestCase, NUM_TESTS> TestCaseListType;
				typedef Axiom::Collections::StaticList<Axiom::EventMsgId, NUM_TESTS> EventGUIDListType;

				int							m_TestsPerformed;
				int							m_TestsVerified;
				AP::System::Timer			m_Timer;
				Axiom::EventMsgBoxHandle	m_ComponentMsgBox;

				int						m_SentTestCount;
				int						m_ReceivedTestCount;

				TestCaseListType		m_TestCases;		//list of test cases to execute
				EventGUIDListType		m_SentTests;		//log the sent events
				EventGUIDListType		m_ReceivedTests;	//log event receipts for later review

				bool					m_Quit;
				bool					m_TestsRunning;

				void InitTestCases();
				void DispatchTestCase(const TestCase& testCase);
				void ProcessReceivedTests();
		};
	}
}


#endif

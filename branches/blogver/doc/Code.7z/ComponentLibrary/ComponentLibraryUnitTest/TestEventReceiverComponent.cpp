#include "TestEventReceiverComponent.h"
#include "testeventmessages.h"

namespace AP
{
	namespace ComponentLibraryUnitTest
	{

		TestEventReceiverComponent::TestEventReceiverComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: TestComponent(name,kernel)
		{
		}

		TestEventReceiverComponent::~TestEventReceiverComponent()
		{
		}

		void TestEventReceiverComponent::OnInit()
		{
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Main");
			m_ComponentMsgBox->RegisterListenBroadcastEvent(SleepCEvent::EVENT_GUID); 
			m_ComponentMsgBox->RegisterListenBroadcastEvent(TestEvent_IntData::EVENT_GUID); 
		}

		void TestEventReceiverComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}
		
		void TestEventReceiverComponent::OnUpdate()
		{
			HandleEvents();
			
			if (m_Sleep)
			{
				//printf("[RECEIVER] Sleep for %d\n", m_SleepTime);
				Axiom::Thread::Sleep(m_SleepTime);
				m_Sleep = false;
				m_SleepTime = 0;
			}

			HandleUpdate();
		}

		void TestEventReceiverComponent::HandleEvents()
		{
		    int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
	
				if (pMsg->GetGuidID() == TestEvent_IntData::EVENT_GUID)
				{
					//TestEvent_IntData myEvent = baseMsg->GetClass<TestEvent_IntData>();
					//printf("[RECEIVER] < CountEvent %d\n", myEvent.mCount);
					//SetEventHandled(eventId);
				}
				else if(pMsg->GetGuidID() == SleepCEvent::EVENT_GUID)
				{
					const SleepCEvent *sleepEvent = pMsg->GetClass<SleepCEvent>();
					//printf("[RECEIVER] < SleepC\n");
					m_Sleep = true;
					m_SleepTime = sleepEvent->m_Time;
					SetEventHandled(pMsg->GetGuidID());
				}
			}
		}

	}  // namespace ComponentLibraryTests

}  // namespace AP

#ifndef TEST_UPDATE_SENDER_COMPONENT_H__
#define TEST_UPDATE_SENDER_COMPONENT_H__

#include <kernel/systemtimer.h>
#include "TestComponent.h"

// test class that increments a counter during it's update and sends an event out with the counters new value
// a listener class will pick that event up and report it.
namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		class TestEventSenderComponent: public TestComponent
		{
			public:

				TestEventSenderComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~TestEventSenderComponent();

			    virtual void	OnInit();
				virtual void	OnShutdown();
				virtual void	OnUpdate();
				virtual void	OnPostUpdate(){}
				virtual void	HandleEvents();
	
			private:
				int				m_Counter;
		};

	}
}
#endif

#include "TestEventSenderComponent.h"
#include "testeventmessages.h"

namespace AP
{
	namespace ComponentLibraryUnitTest
	{

		TestEventSenderComponent::TestEventSenderComponent(Axiom::ConstStr name, AP::Kernel* kernel)
			: TestComponent(name,kernel)
		{
		}

		TestEventSenderComponent::~TestEventSenderComponent()
		{
		}

		void TestEventSenderComponent::OnInit()
		{
			m_Counter = 0;
			m_ComponentMsgBox = mEventMan.RegisterAndCreateEventMsgBox("Main");
			m_ComponentMsgBox->RegisterListenBroadcastEvent(SleepAEvent::EVENT_GUID); 
		}

		void TestEventSenderComponent::OnShutdown()
		{
			mEventMan.UnRegisterEventMsgBox(m_ComponentMsgBox);
		}

		void TestEventSenderComponent::OnUpdate()
		{		   
			HandleEvents();
			 
			if (m_Sleep)
			{
				Axiom::Thread::Sleep(m_SleepTime);
				m_Sleep = false;
				m_SleepTime = 0;
			}
			else
			{
				++m_Counter;
				if(m_Counter % 100==0)
				{
					TestEvent_IntData smallDataEvent(m_Counter);
					mEventMan.DistributeEvent(&smallDataEvent);
					//Axiom::Log("[SENDER]", "Sent CountEvent %d\n", m_Counter);
				}
			}
			HandleUpdate();
		}

		void TestEventSenderComponent::HandleEvents()
		{
			int numEvents = m_ComponentMsgBox->GetNumEvents();

			for (int i = 0; i < numEvents; ++i)
			{
				const Axiom::EventMsg* pMsg = m_ComponentMsgBox->GetEvent(i);			
	
				if (pMsg->GetGuidID() == SleepAEvent::EVENT_GUID)
				{
					const SleepAEvent *sleepEvent = pMsg->GetClass<SleepAEvent>();
					//Axiom::Log("[SENDER]", "Received SleepA");
					m_Sleep = true;
					m_SleepTime = sleepEvent->m_Time;
					SetEventHandled(pMsg->GetGuidID());
				}
			}
		}

	}  // namespace ComponentLibraryUnitTest

}  // namespace AP

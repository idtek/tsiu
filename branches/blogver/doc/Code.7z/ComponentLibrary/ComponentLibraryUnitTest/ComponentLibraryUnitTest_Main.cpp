// ComonentLibraryUnitTest.cpp : Defines the entry point for the application.
//
// Desc: 
//
// This test sets up a 3 component graph and injects sleeps into that thread structure
// it then measures if the threads are deadlocking or not by tracking signals sent to signals
// received.
//-------------------------------------------------------------------------------------
#include <unittesting.h>
#include <kernel/kernel.h>
#include "debug/assert.h"
#include "files/filemanager.h"

#if CORE_WIN32
	#include <conio.h>
#endif

#if CORE_WII == CORE_YES
#include <revolution.h>
#include <revolution/wpad.h>
#include <string.h>
#include <demo.h>
#endif

using namespace AP::UnitTestingFramework;
USING_UNITTESTGROUP(ComponentLibraryTestGroup)
USING_UNITTESTGROUP(AudioComponentTestGroup)
USING_UNITTESTGROUP(ResourceComponentTestGroup)
USING_UNITTESTGROUP(DoubleBufferGroup)

void AllocateHeaps()
{
	// Todo: Probably not necessary to create so many heaps.
	Axiom::Memory::Init(PLATFORM_MAXALLOC);
	Axiom::Memory::RESERVED_CORE_HEAP		= Axiom::Memory::CreateHeap("RESERVED_CORE_HEAP",		IN_MB(14) );
	Axiom::Memory::RESERVED_DEBUG_HEAP		= Axiom::Memory::CreateHeap("RESERVED_DEBUG_HEAP",	   	IN_MB(1) );
	Axiom::Memory::RESERVED_SYSTEMS_HEAP	= Axiom::Memory::CreateHeap("RESERVED_SYSTEMS_HEAP",	IN_MB(1) );
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(60) );
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_MB(41) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_KB(512) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(2) );
}

void ComponentLibraryUnitTest(Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(ComponentLibraryTestGroup, output)
}

void AudioComponentUnitTest(Win32OutputObject& output)
{
	RUN_UNITTESTGROUP(AudioComponentTestGroup, output)
}

void ResourceComponentUnitTest(Win32OutputObject& output)
{
	RUN_UNITTESTGROUP( ResourceComponentTestGroup, output )
}

void DoubleBufferUnitTest(Win32OutputObject& output)
{
	RUN_UNITTESTGROUP( DoubleBufferGroup, output )
}

void RunAllComponentTests()
{
	Win32OutputObject output;

	UNITTEST_HEADER("Component Library Unit Tests", output);
	
	DoubleBufferUnitTest (output);

	ComponentLibraryUnitTest(output);	 

	AudioComponentUnitTest(output);

	ResourceComponentUnitTest( output );

	UNITTEST_FOOTER("Component Library Unit Tests", output);
}

void InitializeFileSystem()
{
	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	Axiom::FileManager::FileManager * fileManager = Axiom::FileManager::FileManager::GetInstance();

	//DAY 6/2/2008 10:26:07 AM  Boy, this is a lot of platform ifdefs.
	//Can we clean this up?

#if CORE_WII
	fileManager->AddPathAlias("platform_audio:", "file:/MediaWii/Sounds");
#elif CORE_XBOX360
	fileManager->AddPathAlias("platform_audio:", "file:/MediaX360/Sounds");
#elif CORE_WIN32
	fileManager->AddPathAlias("platform_audio:", "file:/MediaPC/Sounds");
#elif CORE_PS3
	fileManager->AddPathAlias("platform_audio:", "file:/MediaPS3/Sounds");
#endif
	
	fileManager->AddPathAlias("media:",	 "file:/Media");	//DAY 5/21/2008 3:57:57 PM.  Here, or somewhere else?

#if CORE_XBOX360
	fileManager->SetDiskAliasPath("game:");
#elif CORE_PS3
	fileManager->SetDiskAliasPath("/app_home");
#elif CORE_WIN32
	static char szBuffer[MAX_PATH] = {0};
	GetCurrentDirectory( MAX_PATH, szBuffer );
	fileManager->SetDiskAliasPath(szBuffer);
#elif CORE_WII
	//DAY 5/21/2008 5:03:48 PM
	//Dan, I have no idea what to put here.  Please feel free to add the proper path.  Or move this whole block somewhere better
	//How do I knw you'll see this?  Call it a hunch
#endif
}

int main(int, char**)
{
#if CORE_WII
	OSInit();
#endif 

	AllocateHeaps();
	AP::Reflection::Script::Init();
	Axiom::InitLogging(Axiom::Memory::DEFAULT_HEAP,  NULL);

	InitializeFileSystem();

	RunAllComponentTests();

	//Shutdown

	Axiom::DestroyLogging();
	Axiom::FileManager::FileManager::Destroy();
	AP::Reflection::Script::Destroy();
	Axiom::Memory::Destroy();
	
#if CORE_WII
	OSRebootSystem();
#endif 
	
	return 0;
}



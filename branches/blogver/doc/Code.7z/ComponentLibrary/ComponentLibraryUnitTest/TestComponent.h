#ifndef TEST_COMPONENT_H__
#define TEST_COMPONENT_H__

#include <kernel/component.h>
#include <eventsystem/eventman.h>

// test class that acts as a listener class for the event sender
// it will pick that event up and report it.
namespace AP
{
	namespace ComponentLibraryUnitTest
	{
		// Abstract Super Class that defines the common behaviour for all of the TestComponents.
		class TestComponent: public AP::Component
		{
			public:

				TestComponent(Axiom::ConstStr name, AP::Kernel* kernel);
				~TestComponent();

				virtual void				OnInit();
				virtual void				ShutDown();
				virtual void				OnUpdate();
				void 						HandleUpdate();
			protected:
				void						SetEventHandled(Axiom::EventMsgId guid);
				
				bool						m_Sleep;
				int							m_SleepTime;
				bool						m_EventHandled;
				Axiom::EventMsgId			m_LastEventGUID;
				Axiom::EventMsgBoxHandle	m_ComponentMsgBox;
		};
	}
}
#endif

// ComonentLibraryUnitTest.cpp : Defines the entry point for the application.
//
// Desc: 
//
// This test sets up a 3 component graph and injects sleeps into that thread structure
// it then measures if the threads are deadlocking or not by tracking signals sent to signals
// received.
//-------------------------------------------------------------------------------------
#include <kernel/kernel.h>
#include <kernel/componentmanager.h>

#include "TestSignals.h"
#include "TestEventReceiverComponent.h"
#include "TestEventSenderComponent.h"
#include "TestEventTransceiverComponent.h"
#include "ComponentTestDriver.h"
#include <unittesting.h>

using namespace AP;
using namespace AP::ComponentLibraryUnitTest;

enum KernelType
{
	KernelType_TestA,
	NumKernelType
};

AP::Kernel* gKernel[NumKernelType];

BEGIN_UNITTESTGROUP( ComponentLibraryTestGroup )
{
	KernelConfig kernelConfig;
	kernelConfig.AddKernel(KernelType_TestA, "KernelType_TestA", 0, Axiom::Thread::TP_HIGH, Axiom::Memory::DEFAULT_HEAP);

	AP::ComponentManager::Init(Axiom::Memory::DEFAULT_HEAP);
	AP::ComponentManager *pComponentManager = AP::ComponentManager::GetInstance();
	pComponentManager->InitComponentManager(Axiom::Memory::DEFAULT_HEAP, 1, 4);
	pComponentManager->InitKernels(kernelConfig);

	TestEventSenderComponent *senderComponent			= pComponentManager->CreateComponent<TestEventSenderComponent>(			"SENDER_TEST_COMPONENT_A",			KernelType_TestA);
	TestEventTransceiverComponent *transceiverComponent	= pComponentManager->CreateComponent<TestEventTransceiverComponent>(	"TRANSCEIVER_TEST_COMPONENT_C",		KernelType_TestA);
	TestEventReceiverComponent *receiverComponent		= pComponentManager->CreateComponent<TestEventReceiverComponent>(		"RECEIVER_TEST_COMPONENT_B",		KernelType_TestA);
	ComponentTestDriver *driverComponent				= pComponentManager->CreateComponent<ComponentTestDriver>(				"TEST_DRIVER_COMPONENT",			KernelType_TestA);

	// Create the topology
	pComponentManager->Connect(driverComponent,			senderComponent					,CT_BI_DIRECTION				);
	pComponentManager->Connect(senderComponent,			transceiverComponent											);
	pComponentManager->Connect(driverComponent,			transceiverComponent			,CT_BI_DIRECTION				);
	pComponentManager->Connect(transceiverComponent,	receiverComponent												);
	pComponentManager->Connect(driverComponent,			receiverComponent				,CT_BI_DIRECTION				);

	// Registering Events
	senderComponent->RegisterListenEvent			(	SleepAEvent::EVENT_GUID 									);
	
	transceiverComponent->RegisterListenEvent		(	TestEvent_IntData::EVENT_GUID								);
	transceiverComponent->RegisterListenEvent		(	SleepBEvent::EVENT_GUID										);

	receiverComponent->RegisterListenEvent			(	TestEvent_IntData::EVENT_GUID 								);
	receiverComponent->RegisterListenEvent			(	SleepCEvent::EVENT_GUID 									);

	driverComponent->RegisterListenEvent			(	EventVerification::EVENT_GUID 								);
	
	BEGIN_UNITTEST( ComponentInitTest)
	{
		// Initialize all components
		pComponentManager->InitializeAllComponents();
	}
	END_UNITTEST

	BEGIN_UNITTEST( ComponentRunTest)
	{
		// Start all components
	    pComponentManager->StartAllComponents();

		// Give the component test thread some time to execute
		Axiom::Thread::Sleep(5000);

		// now do the all the UTF_CHECKS on the individual components
		// i.e. make sure components received (or didn't receive) events they subscribed (or not) to
		
	}
	END_UNITTEST
	
	BEGIN_UNITTEST( ComponentShutdownTest)
	{
		pComponentManager->RequestShutdown();

		Axiom::Int32 ShutdownTimeoutMs = 500;
		Axiom::Int32 MsElapsed = 0;
		while(pComponentManager->IsAllComponentActive())
		{
			Axiom::Thread::Sleep(50);
			MsElapsed += 50;
			UTF_CHECK(MsElapsed < ShutdownTimeoutMs)
		}
	}
	END_UNITTEST
	
	AP::ComponentManager::Destroy();

}
END_UNITTESTGROUP( ComponentLibraryTestGroup )



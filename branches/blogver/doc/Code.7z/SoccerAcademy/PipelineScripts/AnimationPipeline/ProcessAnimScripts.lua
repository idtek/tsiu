-- -s C:\Projects\SoccerSuperstar\Soccer\PipelineScripts\AnimationPipeline -a "C:/TEMP/Trousers/temp/processedAnimFiles.txt, C:/TEMP/TrousersOutput/Soccer/Media/anim/test.anm"
LoadNamespace("System.IO");
Globals.Directory = ImportType("System.IO.Directory");
Globals.Path = ImportType("System.IO.Path");

-- DEBUGGING default to these if none given
Globals.DEFAULT_SRC_PATH = "C:\\TEMP\\Trousers\\temp\\processedAnimFiles.txt";
Globals.CONSOLE_ANIM_FILE = "game:\\Media\\anim\\test.anm";
Globals.DESTINATION_ANIM_FILE_NAME = "C:\\TEMP\\TrousersOutput\\Soccer\\Media\\anim\\test.anm";

function ReportUnusedAnims()
	local animListScript = ""
				.. " local clipManager = Animation.Loco.ClipManager;" 
				.. " local editor = Animation.Loco "
				.. " local animList = {};" 
				.. " local unUsedList = {};" 
				.. " for i = 0, clipManager.NumClips() - 1 do " 
				.. "   unUsedList[i] = clipManager.ClipName(i);" 
				.. " end " 
				.. " local result = table.getn(unUsedList) .. ' total animations' "
				.. " for key, value in ipairs(editor.Handlers) do " 
				.. "   	local handler = value.Ptr;" 
				.. "   	if type(value.Ptr) == 'CompositeAnimHandler' then  " 
				.. "     local handlerCount = handler.NumOfHandlers() " 
				.. "     for i = 0,handlerCount-1 do " 
				.. "        local handlerName = handler.HandlerNameAtIndex(i) " 
				.. "        local subHandler = editor.FindHandler(editor.FindByName(handlerName)) "
				.. "        for j = 0, subHandler.NumberOfClips()-1 do "
				.. "       		local clipId = subHandler.GetClip(j); "
				.. "       		animList[clipId] = clipManager.ClipName(clipId);"
				.. "       		unUsedList[clipId] = nil;" 
				.. "       	end "
				.. "      end " 
				.. "   end " 				
				.. "   for i = 0, handler.NumberOfClips() - 1 do " 
				.. "       local clipId = handler.GetClip(i);" 
				.. "       animList[clipId] = clipManager.ClipName(clipId);"
				.. "       unUsedList[clipId] = nil;" 
				.. "   end " 
				.. " end " 
				.. " for key, value in pairs(unUsedList) do " 
				.. "   if result == nil then " 
				.. "       result = value;" 
				.. "   else " 
				.. "       result = result .. ',' .. value " 
				.. "   end " 
				.. " end " 
				.. " return result;";
	
	local resultStr = ExecuteGetString(animListScript);
	local unUsedAnimsTbl = Split(resultStr, ',');
	local animCount = table.remove(unUsedAnimsTbl, 1);	-- pop the total anim count
	local unusedCount = table.getn(unUsedAnimsTbl);
	
	if (unusedCount > 0) then
		TestBot.Report("*WARNING: Unused Animations Found: ".. unusedCount .." unused of ".. animCount);
		local count = 1;
		for anim in EachItemOf(unUsedAnimsTbl) do
			TestBot.Report("**Unused ".. count ..": ".. anim);
			count = count + 1;
		end
	end
end

function GenerateFileNameTable(srcPath)
	local fileNamesTbl = nil;
	if (IsDirectory(srcPath)) then
		TestBot.Report("> Processing as DIRECTORY <");
		local dirStr = SharpScript.StringArrayToString(Globals.Directory.GetFiles(srcPath, "*.lua"));
		fileNamesTbl = Split(dirStr, ',');
		
	elseif (IsFile(srcPath)) then
		TestBot.Report("> Processing as FILE <");
		fileNamesTbl = Split(FileToString(srcPath), '\r\n');
	end
	return fileNamesTbl;
end

function ProcessAnimFiles(srcPath)
	TestBot.Report("> Processing from: "..srcPath .."<");
	local failureCount = 0;
	local processOK = false;
	local fileNamesTbl = GenerateFileNameTable(srcPath);

	if not NilOrEmpty(fileNamesTbl) then
		for animFile in EachItemOf(fileNamesTbl) do
			TestBot.Report("> got '"..animFile.."' <");
			if (not NilOrEmpty(animFile)) then
				TestBot.Report("> executing '"..animFile.."' <");
				processOK = ExecuteReflectionScriptFile(animFile);
				TestBot.Verify(processOK, "processed: '"..animFile.."'" );
				if not processOK then failureCount = failureCount + 1 end
			end
		end
	else
		TestBot.ReportFailure("FATAL ERROR!  source arg: "..sourcePath.." does not resolve to a real filesystem entity!  ENDING EXECUTION NOW!");
		failureCount = 1;
	end
	Wait(100);
	
	local success = (failureCount == 0);
	return success;
end

function GenerateFinalAnimFile(destinationFile)
	TestBot.Report("Generate file: "..destinationFile);
	local fileGenerated = ExecuteGetString("return ClipManager.Save().AsChar();");
	local fileName = fileGenerated or "[NULL FILE NAME]";
	TestBot.Verify(not NilOrEmpty(fileGenerated), "DONE generating '"..fileName.."'");
	TestBot.Report("TRY copying: "..Globals.CONSOLE_ANIM_FILE.." To: ".. destinationFile);
	local copiedOK = CopyFileFromConsole(Globals.CONSOLE_ANIM_FILE, destinationFile);
	TestBot.Verify(copiedOK, "DONE copying: "..Globals.CONSOLE_ANIM_FILE.." To: ".. destinationFile);
end


function main (argv)
	-- local sourcePath = Globals.DEFAULT_SRC_PATH;
	-- local destinationFile = Globals.DESTINATION_ANIM_FILE_NAME;
	local sourcPath = nil;
	local destinationFile = nil;
	if (argv) then 
		if (not NilOrEmpty(argv[1])) then sourcePath = argv[1] end
		if (not NilOrEmpty(argv[2])) then destinationFile = argv[2] end
	end
	
	TestBot.TestGroupInit("------------- Animation batch process -------------");
	ReportUnusedAnims();
	
	TestBot.Verify(not NilOrEmpty(sourcePath), "Has valid Source file path");
	TestBot.Verify(not NilOrEmpty(destinationFile), "Has valid Destination file path");
	if (not NilOrEmpty(sourcePath)) and (not NilOrEmpty(destinationFile)) then
		local generateAnimFile = ProcessAnimFiles(sourcePath);
		if generateAnimFile then
			GenerateFinalAnimFile(destinationFile);
		else
			TestBot.ReportFailure("Can not generate destination file due to failed animations!");
		end
	else
		TestBot.Report("EXECUTION ABORTED bad sourcePath or bad destinationFile designations!");
	end
	TestBot.TestGroupSummary();
end

function Cleanup()
	-- clean up the functions:
	ReportUnusedAnims = nil;
	GenerateFileNameTable = nil;
	ProcessAnimFiles = nil;
	GenerateFinalAnimFile = nil;
end


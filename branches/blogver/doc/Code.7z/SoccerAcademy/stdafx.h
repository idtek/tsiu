// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef __SOCCER_STDAFX_H
#define __SOCCER_STDAFX_H

// TODO: reference additional headers your program requires here
#include <core/core.h>

using Axiom::Log;
using Axiom::Warn;
using Axiom::Error;

#endif // __SOCCER_STDAFX_H

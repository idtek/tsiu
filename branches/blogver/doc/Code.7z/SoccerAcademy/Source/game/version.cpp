#include "version.h"	 
#include <files/filemanager.h>
#include <debug/log.h>

static char buildid[] = BUILDID;

namespace Soccer
{
	AP_TYPE(BuildInfo)
		AP_FIELD("ChangeNumber",m_changeNumber,"Change List Number .")
		AP_FIELD("BuildId",m_buildId,"Build identifier.")
		AP_FIELD("CId",m_CId,"Configuration Item identifier.")
		AP_FIELD("CIdSet",m_CIdSet,"is Configuration Item identifier Set ?")

		AP_TYPE_END()

		BuildInfo::BuildInfo():m_changeNumber(CHANGE_NUMBER),m_buildId(buildid), m_CId("DEV"),m_CIdSet(false),m_IsDisplay(false)
	{
		AP::Reflection::Script::Register("BuildInfo", AP::Reflection::Instance(this), "BuildInfo Version");
	}


	BuildInfo::~BuildInfo()
	{
		AP::Reflection::Script::Unregister("BuildInfo");
	}

	bool BuildInfo::IsDevBuild()
	{	
		return (m_buildId == Axiom::StaticString<21>("DEV"));
	}

	bool BuildInfo::IsCIdSet()
	{
		if (m_CIdSet == false)
		{
			if (Axiom::FileManager::FileManager::GetInstance()->DoesFileExist("home:CId.lua"))
			{
				AP::Reflection::Script::Result r;

				m_CIdSet = true;

				r = AP::Reflection::Script::ExecuteFile("home:CId.lua");

				if (AP::Reflection::Script::SUCCESS != r.Error())
				{
					Axiom::Log("Script", r.ToString());
				}
			}
            if (m_IsDisplay == false)
			{
				m_IsDisplay = true;
			    Axiom::Log ("Identification","CId %s BuildId %s Change %i",m_CId.AsChar(),m_buildId.AsChar(),m_changeNumber);
			}
            //if (IsDevBuild() == true)
			//{ 
			//    Axiom::Log ("Identification","DEV");
			//}
            
		}
		return m_CIdSet; 
	}


}


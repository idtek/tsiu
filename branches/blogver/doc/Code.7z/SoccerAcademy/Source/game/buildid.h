#ifndef _BUILDID_H_
#define _BUILDID_H_

#define BUILDID "20090617-132342-3452"
#define CHANGE_NUMBER 132342

#endif

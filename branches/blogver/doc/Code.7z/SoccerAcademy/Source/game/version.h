//--------------------------------------------------------------------------
//    _   ___ _____ ___ ___  _  _   ___  _   _  _ _____ ___   ___ _  _  ___ 
//   /_\ / __|_   _|_ _/ _ \| \| | | _ \/_\ | \| |_   _/ __| |_ _| \| |/ __|
//  / _ \ (__  | |  | | (_) | .` | |  _/ _ \| .` | | | \__ \  | || .` | (__ 
// /_/ \_\___| |_| |___\___/|_|\_| |_|/_/ \_\_|\_| |_| |___/ |___|_|\_|\___|
//  
// Copyright (c) 2007 by Action Pants Inc
//
// Lib:   Version Control File
// Class: BuildInfo
// Desc:  Contains version of the game and build ID of data required to run
// Auth:  KevinF
//
//--------------------------------------------------------------------------
#ifndef BUILD_ID_VERSION_H__
#define BUILD_ID_VERSION_H__
#include <core/singleton.h>
#include <string/string.h>
#include <reflection/script.h>
#include "buildid.h"

namespace Soccer
{
	class BuildInfo : public Axiom::Singleton<BuildInfo>
	{
		AP_NON_COPYABLE(BuildInfo);

	private:
		int m_changeNumber;
		Axiom::StaticString<21> m_buildId; //YYYYMMDD-CCCCCC-BBBBB
	    Axiom::StaticString<21> m_CId;
		bool m_CIdSet;
	    bool m_IsDisplay;
	 
	public:

		BuildInfo();
		~BuildInfo();

		bool IsDevBuild();
		bool IsCIdSet();
		int GetChangeNumber(){ return m_changeNumber; }
		const char * GetBuildId(){ return m_buildId.AsChar(); }
        const char * GetCId(){ return m_CId.AsChar(); }

		AP_DECLARE_TYPE();
	};
}

#endif

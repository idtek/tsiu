////////////////////////////////////////////////////////////////////
//
// SoccerSuperstar.spa.h
//
// Auto-generated on Wednesday, 16 April 2008 at 11:03:37
// XLAST project version 1.0.121.0
// SPA Compiler version 2.0.6534.3
//
////////////////////////////////////////////////////////////////////

#ifndef __SUPERSTAR_SPA_H__
#define __SUPERSTAR_SPA_H__

#ifdef __cplusplus
extern "C" {
#endif

//
// Title info
//

#define TITLEID_SUPERSTAR                           0x555307FB

//
// Context ids
//
// These values are passed as the dwContextId to XUserSetContext.
//


//
// Context values
//
// These values are passed as the dwContextValue to XUserSetContext.
//

// Values for X_CONTEXT_PRESENCE

#define CONTEXT_PRESENCE_X_STRINGID_PRESENCEMODE_AVAILABLE 0
#define CONTEXT_PRESENCE_X_STRINGID_PRESENCEMODE_BUSY 1

// Values for X_CONTEXT_GAME_MODE

#define CONTEXT_GAME_MODE_DEFAULT_GAME_MODE         0

//
// Property ids
//
// These values are passed as the dwPropertyId value to XUserSetProperty
// and as the dwPropertyId value in the XUSER_PROPERTY structure.
//

#define PROPERTY_SESSIONSEARCHPARAM                 0x10000001
#define PROPERTY_SESSIONNUMBER                      0x10000006
#define PROPERTY_MULTIPLAYERGAMEMODE                0x1000000D
#define PROPERTY_TEAMTYPE                           0x1000000E
#define PROPERTY_TIMELIMIT                          0x1000000F
#define PROPERTY_SESSIONSEARCHPARAM2                0x10000010
#define PROPERTY_SESSIONSEARCHPARAM3                0x10000011
#define PROPERTY_SESSIONSEARCHPARAM4                0x10000012
#define PROPERTY_CHATENABLED                        0x10000013
#define PROPERTY_CRESTPLATE                         0x10000015
#define PROPERTY_NOOFGUESTS                         0x10000016
#define PROPERTY_TRUESKILLHINT                      0x10000017
#define PROPERTY_EXTRATIME                          0x10000018
#define PROPERTY_PENALTYKICKS                       0x10000019
#define PROPERTY_TOURNAMENTLEVEL                    0x1000001A
#define PROPERTY_DIVISION                           0x1000001D
#define PROPERTY_PLAYERRATING                       0x20000009
#define PROPERTY_WINS                               0x2000000A
#define PROPERTY_LOSSES                             0x2000000B
#define PROPERTY_GAMESPLAYED                        0x2000000C
#define PROPERTY_GLOBALPLAYERRANK                   0x20000014
#define PROPERTY_LONGESTSTREAK                      0x2000001B
#define PROPERTY_CURRENTSTREAK                      0x2000001C

//
// Achievement ids
//
// These values are used in the dwAchievementId member of the
// XUSER_ACHIEVEMENT structure that is used with
// XUserWriteAchievements and XUserCreateAchievementEnumerator.
//

#define ACHIEVEMENT_ACV_KEEPRISCOOL                 14
#define ACHIEVEMENT_ACV_UNSTOPPABLE                 16
#define ACHIEVEMENT_ACV_CORDIALLY_INVITED           17
#define ACHIEVEMENT_ACV_THE_HERMIT                  18
#define ACHIEVEMENT_ACV_HALLOWEED_GROUNDS           19
#define ACHIEVEMENT_ACV_CONQUEROR                   20
#define ACHIEVEMENT_ACV_ELITENESS                   21
#define ACHIEVEMENT_ACV_I_AM_RICH                   22
#define ACHIEVEMENT_ACV_MERC_BRIGADE                23
#define ACHIEVEMENT_ACV_CREATION_ELATION            24
#define ACHIEVEMENT_ACV_ART_MAJOR                   25
#define ACHIEVEMENT_ACV_WET_YOUR_APPETITE           26
#define ACHIEVEMENT_ACV_ENTER_THE_ARENA             27
#define ACHIEVEMENT_ACV_USURPER                     28
#define ACHIEVEMENT_ACV_WARLORD                     29
#define ACHIEVEMENT_ACV_AMATEUR                     30
#define ACHIEVEMENT_ACV_PROFESSIONAL                32
#define ACHIEVEMENT_ACV_GODSEND                     33
#define ACHIEVEMENT_ACV_INITIATION                  34
#define ACHIEVEMENT_ACV_YOU_ARE_DOG                 35
#define ACHIEVEMENT_ACV_FEED_THE_PUPS               36
#define ACHIEVEMENT_ACV_BEAT_THE_BEST               37
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH1              38
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH2              39
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH3              40
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH4              41
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH5              42
#define ACHIEVEMENT_ACV_TOP_DOG_PITCH6              43
#define ACHIEVEMENT_ACV_RANK_1                      45
#define ACHIEVEMENT_ACV_RANK_2                      46
#define ACHIEVEMENT_ACV_RANK_3                      47
#define ACHIEVEMENT_ACV_RANK_4                      48
#define ACHIEVEMENT_ACV_RANK_5                      49
#define ACHIEVEMENT_ACV_RANK_6                      50
#define ACHIEVEMENT_ACV_RANK_7                      51
#define ACHIEVEMENT_ACV_RANK_8                      52
#define ACHIEVEMENT_ACV_RANK_9                      53
#define ACHIEVEMENT_ACV_RANK_10                     54
#define ACHIEVEMENT_ACV_P_TARGET_MAN                55
#define ACHIEVEMENT_ACV_P_FINISHER                  56
#define ACHIEVEMENT_ACV_P_WINGER                    57
#define ACHIEVEMENT_ACV_P_PLAYMAKER                 58
#define ACHIEVEMENT_ACV_P_HOLDING_MIDFIELD          60
#define ACHIEVEMENT_ACV_P_ATTACKING_MIDFIELD        61
#define ACHIEVEMENT_ACV_P_WINGBACK                  62
#define ACHIEVEMENT_ACV_P_STOPPER                   63
#define ACHIEVEMENT_ACV_P_SWEEPER                   64
#define ACHIEVEMENT_ACV_P_NO10INTHEHOLE             65
#define ACHIEVEMENT_ACV_IGOTFIVEONIT                66
#define ACHIEVEMENT_ACV_TOPOFPOPS                   67

//
// Stats view ids
//
// These are used in the dwViewId member of the XUSER_STATS_SPEC structure
// passed to the XUserReadStats* and XUserCreateStatsEnumerator* functions.
//

// Skill leaderboards for ranked game modes

#define STATS_VIEW_SKILL_RANKED_DEFAULT_GAME_MODE   0xFFFF0000

// Skill leaderboards for unranked (standard) game modes

#define STATS_VIEW_SKILL_STANDARD_DEFAULT_GAME_MODE 0xFFFE0000

// Title defined leaderboards

#define STATS_VIEW_GLOBALLEADERBOARD                2
#define STATS_VIEW_LONGESTSTREAKLEADERBOARD         3
#define STATS_VIEW_WINSLEADERBOARD                  4
#define STATS_VIEW_LOSSESLEADERBOARD                5

//
// Stats view column ids
//
// These ids are used to read columns of stats views.  They are specified in
// the rgwColumnIds array of the XUSER_STATS_SPEC structure.  Rank, rating
// and gamertag are not retrieved as custom columns and so are not included
// in the following definitions.  They can be retrieved from each row's
// header (e.g., pStatsResults->pViews[x].pRows[y].dwRank, etc.).
//

// Column ids for GLOBALLEADERBOARD

#define STATS_COLUMN_GLOBALLEADERBOARD_GAMES        3
#define STATS_COLUMN_GLOBALLEADERBOARD_WINS         2
#define STATS_COLUMN_GLOBALLEADERBOARD_LOSSES       1
#define STATS_COLUMN_GLOBALLEADERBOARD_LONGESTSTREAK 4
#define STATS_COLUMN_GLOBALLEADERBOARD_CURRENTSTREAK 5
#define STATS_COLUMN_GLOBALLEADERBOARD_DIVISION     6
#define STATS_COLUMN_GLOBALLEADERBOARD_GLOBALPLAYERRANK 7

// Column ids for LONGESTSTREAKLEADERBOARD

#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_PLAYER_RATING 5
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_GAMES 4
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_WINS  1
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_LOSSES 3
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_CURRENTSTREAK 2
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_DIVISION 6
#define STATS_COLUMN_LONGESTSTREAKLEADERBOARD_GLOBALPLAYERRANK 7

// Column ids for WINSLEADERBOARD

#define STATS_COLUMN_WINSLEADERBOARD_PLAYERRATING   1
#define STATS_COLUMN_WINSLEADERBOARD_GAMESPLAYED    2
#define STATS_COLUMN_WINSLEADERBOARD_LOSSES         3
#define STATS_COLUMN_WINSLEADERBOARD_LONGESTSTREAK  4
#define STATS_COLUMN_WINSLEADERBOARD_CURRENTSTREAK  5
#define STATS_COLUMN_WINSLEADERBOARD_DIVISION       6
#define STATS_COLUMN_WINSLEADERBOARD_GLOBALPLAYERRANK 7

// Column ids for LOSSESLEADERBOARD

#define STATS_COLUMN_LOSSESLEADERBOARD_PLAYERRATING 1
#define STATS_COLUMN_LOSSESLEADERBOARD_GAMESPLAYED  6
#define STATS_COLUMN_LOSSESLEADERBOARD_WINS         2
#define STATS_COLUMN_LOSSESLEADERBOARD_LONGESTSTREAK 4
#define STATS_COLUMN_LOSSESLEADERBOARD_CURRENTSTREAK 5
#define STATS_COLUMN_LOSSESLEADERBOARD_DIVISION     7
#define STATS_COLUMN_LOSSESLEADERBOARD_GLOBALPLAYERRANK 8

//
// Matchmaking queries
//
// These values are passed as the dwProcedureIndex parameter to
// XSessionSearch to indicate which matchmaking query to run.
//

#define SESSION_MATCH_QUERY_ALLSESSION              0
#define SESSION_MATCH_QUERY_BYSESSIONSEARCHPARAM    1
#define SESSION_MATCH_QUERY_BYTWOSEARCHPARAMS       2
#define SESSION_MATCH_QUERY_BYTHREESEARCHPARAMS     3
#define SESSION_MATCH_QUERY_BYFOURSEARCHPARAMS      4
#define SESSION_MATCH_QUERY_BYFIVESESSIONSEARCHPARAMS 5
#define SESSION_MATCH_QUERY_BYSIXSESSIONSEARCHPARAMS 6

//
// Gamer pictures
//
// These ids are passed as the dwPictureId parameter to XUserAwardGamerTile.
//



#ifdef __cplusplus
}
#endif

#endif // __SUPERSTAR_SPA_H__



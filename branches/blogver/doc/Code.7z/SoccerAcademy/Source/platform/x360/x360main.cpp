
#include "kernel/componentmanager.h"
#include "kernel/kernel.h"
#include "input/coreinputcomponent.h"
#include "coreprescomponent.h"
#include "coresimcomponent.h"
#include "audio/audiocomponent.h"
#include "applicationcomponent.h"

#include "input/ssinputtranslator.h"
#include "resource/resourcemanager.h"

#include "system/gamedebug.h"
#include "system/system.h"
#include "reflection/script.h"
#include "commonmain.h"

#include <input/virtualcontrollermap.h>
#include "version.h"
#include "system/kernelconfig.h"
#include <jobmanager/jobmanager.h>
#if !CORE_FINAL
#include "inputrecording/inputrecorderinterface.h"
#endif !CORE_FINAL
#include <memory/reflectedmemoryinterface.h>
#include <kernel/componentmanager.h>

#include "lobby/agora_lobby.h"
#include "network/agora_session.h"
#include "debug/debugdraw.h"
#include "SoccerSuperstar.spa.h"

#include "files/filemanager.h"

#include <academylibrary.h>
#include <xfilecache.h>

namespace Soccer
{
	namespace Debug
	{
		extern bool sDebugInfoEnabled;
	}
}

//--------------------------------------------------------------------------------------
// Name: main()
// Desc: Entry poInt to the program
//--------------------------------------------------------------------------------------
void __cdecl main(int argc, char *argv[])
{
	Log("System","START GAME");

	// Note: It is not necessary to initialise all heaps at this point, you could potentially create heaps within
	// init functions for manager classes etc.
	// I have defaulted to initialsing the memory using PLATFORM_MAXALLOC but you can change this to whatever you
	// like as long as it is big enough to deal with all the heaps.
	// If you want to lock a heap to a specific thread (i.e. only that thread can allocate to it) then call
	// SetThreadAllowed function.
	Axiom::Memory::Init(SOCCER_SUPERSTAR_PLATFORM_MAXALLOC);
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(63) );
	Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_MB(4) );
	Axiom::Memory::PHYSICS_HEAP				= Axiom::Memory::CreateHeap("PHYSICS_HEAP",				IN_MB(4) );
	Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_MB(2) );
	Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_MB(10) );
	Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_MB(30) );
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_MB(30) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_MB(270) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(1) );
	Log("System","INIT MEMORY MANAGER");

	Axiom::FileManager::FileManager * fileManager = 0;
	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	fileManager = Axiom::FileManager::FileManager::GetInstance();
	fileManager->AddPathAlias("anim:",				"file:\\Media\\anim");
	fileManager->AddPathAlias("effects:",			"file:\\Media\\Effects");
	fileManager->AddPathAlias("fe:",				"file:\\Media\\fe");
	fileManager->AddPathAlias("presentation:",		"file:\\Media\\presentation");
	fileManager->AddPathAlias("scripts:",			"file:\\Media\\scripts");
	fileManager->AddPathAlias("platform_audio:",	"file:\\MediaX360\\Sounds");
	fileManager->AddPathAlias("platform_graphics:",	"file:\\MediaX360\\Graphics");
	fileManager->AddPathAlias("tables:",			"file:\\MediaX360\\Tables");
	fileManager->AddPathAlias("audio:",				"file:\\Media\\sounds");
	fileManager->AddPathAlias("graphics:",			"file:\\Media\\graphics");
	fileManager->AddPathAlias("debug:",				"file:\\Debug");
	fileManager->AddPathAlias("data:",				"file:\\Data");
	fileManager->AddPathAlias("asset:",				"file:\\Asset");
	fileManager->AddPathAlias("home:",				"file:");
	fileManager->AddPathAlias("media:",				"file:\\Media");
	fileManager->SetDiskAliasPath("game:");

#if CORE_DEBUG == CORE_NO
	XFileCacheInit(XFILECACHE_CLEAR_ALL|XFILECACHE_OPPORTUNISTIC_OFF, 0, 3, 1*1024*1024, 1);

	const char * data[] = 
	{
		"game:\\MediaX360\\Sounds\\Vox_PlayerDin_Gen.fsb",
		"game:\\MediaX360\\Sounds\\Mus_Venue_Milan.fsb",
		"game:\\MediaX360\\Sounds\\FE_Music_L01.fsb"
	};

	XFileCachePreloadFiles(XFILECACHE_STARTUP_FILES, data, 3 );
#endif
	
#if CORE_FINAL
	//GetCommandLine does not work in a retail environment, just pass the hard coded name of final executable
	fileManager->InitExecutableFilename("SoccerSuperstar.xex");
#else
	//Get the command line string and chop off the arguments, keeping only the executable filename
	LPSTR commandLine = GetCommandLine();
	char executableFilename[256];
	int len = Axiom::StringLength(commandLine);
	const char* spaceChar = Axiom::StringFindChar(commandLine, ' ');
	if (spaceChar!=NULL)
		len = spaceChar - commandLine;
	Axiom::StringCopy(executableFilename, commandLine, len);
	executableFilename[len] = 0;
	if (executableFilename[0]=='\"') //Chop start quote character
	{
		Axiom::StringCopy(executableFilename, executableFilename+1, len-1);
		len--;
		executableFilename[len] = 0;
	}
	if (executableFilename[len-1]=='\"') //Chop end quote character
	{
		len--;
		executableFilename[len] = 0;
	}
	fileManager->InitExecutableFilename(executableFilename);
#endif

#if CORE_FINAL == CORE_NO
	if( fileManager->DoesFileExist("file:\\media\\debugEnabler.txt") )
	{
		Soccer::Debug::sDebugInfoEnabled = true;
	}

#endif

	Soccer::InitSystems(Axiom::Handle(reinterpret_cast<void*>(NULL)),"game:\\");

	AP::Reflection::Type::LogInitialization();

	AP::Debug::DebugDraw::Init( Axiom::Memory::AI_HEAP );

	while(Soccer::UpdateSystems()){}

	Soccer::ShutdownSystems();
}


// Implementation of "Virtual C-tor" for lobby object. (Can it be a template?) or MAKE_LOBBY_FACTORY_METHOD(Agora_Lobby)
Lobby::LobbyObj* Lobby::LobbyObj::Create(Lobby::LobbyObj::LobbyType lobbyType) { return AP_NEW(Axiom::Memory::ONLINE_HEAP, Soccer::LobbyImpl::Agora_Lobby( TITLEID_SUPERSTAR )); }

// Implementation of "Virtual C-tor" for network session object. (ALEXEI: Can it be a template?) or MAKE_NETWORK_FACTORY_METHOD(Agora_Session())
Network::Session* Network::Session::Create(Network::Session::SessionType sessionType, const Network::Address& addr) 
{ 
	if (addr.TypeOf() == Network::Address::ADDR_TYPE_AGORA)
	{		
		return AP_NEW(Axiom::Memory::ONLINE_HEAP, Agora_Session(reinterpret_cast<const Agora_Address&>(addr)));
	}
	else
	{
		AP_ASSERTFAIL("unknown network type");
		return 0;
	}
}


#ifndef _PS3SNTUNER_H___
#define _PS3SNTUNER_H___

namespace Soccer
{
	void StartProfiler();
	void StartMarker();
	void StopMarker();

}

#endif


#include "animation/animationmanager.h"
#include "animation/collapsehierarchy.h"
#include "animation/motionblender.h"
#include <system/system.h>

#include <math/apmath.h>
#include <kernel/kernel.h>

#include "reflection/script.h"
#include "applicationcomponent.h"
#include "coreprescomponent.h"
#include "coresimcomponent.h"
#include "input/coreinputcomponent.h"
#include <marshaller/eventbuffer.h>
#include <marshaller/marshallereventmessages.h>
#include <marshaller/marshallercomponent.h>

#include "input/ssinputtranslator.h"
#include "resource/resourcemanager.h"
#include "system/gamedebug.h"
#include "presentation/presentationmessages.h"

#include <memory/apmemory.h>
#include <kernel/kernel.h>
#include <kernel/componentmanager.h>
#include "coresimcomponent.h"
#include "coreprescomponent.h"
#include "commonmain.h"
#include "ps3profiler.h"

#include <sys/process.h>
#include <cell/sysmodule.h>
#include <string/string.h>
#include <cell/cell_fs.h>
#include <jobmanager/jobmanager.h>

#include <netex/libnetctl.h>
#include <np.h>

//#include "version.h"
#include "system/kernelconfig.h"
#include <collections/booklet.h>
#include <input/virtualcontrollermap.h>
#include <memory/reflectedmemoryinterface.h>

#include "lobby/agora_lobby.h"
#include "network/agora_session.h"
#include "debug/debugdraw.h"
#include "debug/log.h"

#include <files/filemanager.h>

#include <academylibrary.h>

// Enable this only if u want to emulate the BLUE-RAY DISC
//#define BD_EMULATE 1 

#define THREAD_MAIN_PRIORITY 1002
#define NP_POOL_SIZE (128*1024)

// Set Stack Size of main thread on PPU
// 0 to 3071
SYS_PROCESS_PARAM(THREAD_MAIN_PRIORITY,0x30000);

using namespace Axiom::System;
using namespace AP::Input;
using namespace AP::Marshaller::Events;
using namespace AP::Input::Events;

// Global variable: NP pool.
uint8_t g_np_sample_pool[NP_POOL_SIZE];

void InitModules()
{
	if (cellSysmoduleLoadModule(CELL_SYSMODULE_FS)) {
		Log("System","FAIL TO LOAD FILE SYSTEM WITH cellSysmoduleLoadModule()");
		AP_ASSERTFAIL("FAIL TO LOAD FILE SYSTEM");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_AUDIO) != CELL_OK)
	{
		Log("System","FAIL TO LOAD AUDIO SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD AUDIO SYS MODULE");
	}
	
	if(cellSysmoduleLoadModule(CELL_SYSMODULE_FS) != CELL_OK)
	{
		Log("System","FAIL TO LOAD FILE SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD FILE SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_AVCONF_EXT) != CELL_OK)
	{
		Log("System","FAIL TO LOAD AUX VIDEO SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD AUX VIDEO SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_SYSUTIL_NP) != CELL_OK)
	{
		Log("System","FAIL TO LOAD NP SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD NP SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_RTC) != CELL_OK)
	{
		Log("System","FAIL TO LOAD RTC SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD RTC SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_NET) != CELL_OK)
	{
		Log("System","FAIL TO LOAD NET SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD NET SYS MODULE");
	}

	if(cellSysmoduleLoadModule(CELL_SYSMODULE_L10N) != CELL_OK)
	{
		Log("System","FAIL TO LOAD L10N SYS MODULE");
		AP_ASSERTFAIL("FAIL TO LOAD L10N SYS MODULE");
	}
}


void InitNetwork()
{
	if (cellNetCtlInit()<0)
	{
		Log("System", "FAIL TO INITIALIZE NETCTL");
		AP_ASSERTFAIL("FAIL TO INITIALIZE NETCTL");
	}

	if (sceNpInit (NP_POOL_SIZE, g_np_sample_pool)<0)
	{
		Log("System", "FAIL TO INITIALIZE NP");
		AP_ASSERTFAIL("FAIL TO INITIALIZE NP");
	}	
}



Axiom::FileManager::FileManager*		pFileManager = 0;

namespace Soccer
{
	namespace Debug
	{
		extern bool sDebugInfoEnabled;
	}
}

#include <cell/cell_fs.h>

int main(int argc, char *argv[])
{	
	InitModules();

	Log("System","START GAME");

	//Soccer::StartProfiler();
	//Log("System","START PROFILER\n");

	// Note: It is not necessary to initialise all heaps at this point, you could potentially create heaps within
	// init functions for manager classes etc. 
	// I have defaulted to initialsing the memory using PLATFORM_MAXALLOC but you can change this to whatever you
	// like as long as it is big enough to deal with all the heaps.
	// If you want to lock a heap to a specific thread (i.e. only that thread can allocate to it) then call
	// SetThreadAllowed function.

	Axiom::Memory::Init(SOCCER_SUPERSTAR_PLATFORM_MAXALLOC);
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(60) );
	Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_MB(4) );
	Axiom::Memory::PHYSICS_HEAP				= Axiom::Memory::CreateHeap("PHYSICS_HEAP",				IN_MB(4) );
	Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_MB(2) );
	Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_MB(1) );
	Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_MB(30) );
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_MB(36) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_MB(42) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(1) );

	InitModules();

	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	Axiom::FileManager::FileManager * fileManager = Axiom::FileManager::FileManager::GetInstance();
	fileManager->AddPathAlias("anim:",				"file:\\Media\\anim");
	fileManager->AddPathAlias("effects:",			"file:\\Media\\Effects");
	fileManager->AddPathAlias("fe:",				"file:\\Media\\fe");
	fileManager->AddPathAlias("presentation:",		"file:\\Media\\presentation");
	fileManager->AddPathAlias("scripts:",			"file:\\Media\\scripts");
	fileManager->AddPathAlias("platform_audio:",	"file:\\MediaPS3\\Sounds");
	fileManager->AddPathAlias("platform_graphics:",	"file:\\MediaPS3\\Graphics");
	fileManager->AddPathAlias("tables:",			"file:\\MediaPS3\\Tables");
	fileManager->AddPathAlias("audio:",				"file:\\Media\\sounds");
	fileManager->AddPathAlias("graphics:",			"file:\\Media\\graphics");
	fileManager->AddPathAlias("debug:",				"file:\\Debug");
	fileManager->AddPathAlias("data:",				"file:\\Data");
	fileManager->AddPathAlias("asset:",				"file:\\Asset");
	fileManager->AddPathAlias("media:",				"file:\\Media");
	fileManager->AddPathAlias("home:",				"file:");
	fileManager->SetDiskAliasPath("/app_home");

	//Trim the /app_home/ off the front of the executable filename
	const char* executableFilename = argv[0];
	const char* forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
	while (forwardSlashChar!=NULL)
	{
		executableFilename = forwardSlashChar+1;
		forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
	}
	fileManager->InitExecutableFilename(executableFilename);

	Log("System","INIT MEMORY MANAGER");

	//FMOD needs a couple of PRX's loaded
	Log("System","LOADING PS3 MODULES");

	AP_ASSERTMESSAGE(argc >=1 && argv[0]!=NULL, "Ensure we have good arguments!!");
	Log("System","INIT FILE SYSTEM");

	//CellFsErrno result = cellFsAioInit(pFileManager->m_DiskAliasPath.AsChar());

	Soccer::Debug::sDebugInfoEnabled = true;

	InitNetwork();
	Log("System","INIT NP SYSTEM");
	
	// Work out the mount point
	// Get the root directory from PS3
	const int MAX_PATH = 260;
	static char szBuffer[MAX_PATH];

#if BD_EMULATE
	Axiom::StringCopy(szBuffer,"/dev_bdvd/PS3_GAME/USRDIR",MAX_PATH);
	fileManager->SetDiskAliasPath(szBuffer);
#else
	Axiom::ConstStr firstPos = Axiom::StringFindChar(argv[0],'/');
	Axiom::ConstStr nextPos = Axiom::StringFindChar(argv[0]+1,'/');
	Axiom::String path;
	path.Extract(firstPos, nextPos);
	// Check to see if you are on the Blue-ray Disc
	if(Axiom::StringCompare(path.CStr(),"/dev_bdvd", 10) == 0 )
	{
		path << "/PS3_GAME/USRDIR";
	}
	Axiom::StringCopy(szBuffer,path.CStr(),MAX_PATH);
	fileManager->SetDiskAliasPath(szBuffer);
#endif

	// Temporary init async io here..
	CellFsErrno err = cellFsAioInit(szBuffer);

	if(err != CELL_FS_SUCCEEDED)
	{
		AP_ASSERTMESSAGE(err == CELL_FS_SUCCEEDED, "FAIL TO START THE CELLFSAIOINIT CALL!!");
	}

	Soccer::InitSystems(Axiom::Handle(reinterpret_cast<void*>(NULL)),szBuffer);

	AP::Reflection::Type::LogInitialization();

	AP::Debug::DebugDraw::Init( Axiom::Memory::AI_HEAP );
	
	while(true)
	{
		if (!Soccer::UpdateSystems())
		{
			break;
		}
	}
	
	Soccer::ShutdownSystems();

	return 0;
}


// Implementation of "Virtual C-tor" for lobby object. (Can it be a template?) or MAKE_LOBBY_FACTORY_METHOD(Agora_Lobby)
Lobby::LobbyObj* Lobby::LobbyObj::Create(Lobby::LobbyObj::LobbyType lobbyType) { return AP_NEW(Axiom::Memory::ONLINE_HEAP, Soccer::LobbyImpl::Agora_Lobby()); }
// Implementation of "Virtual C-tor" for network session object. (ALEXEI: Can it be a template?) or MAKE_NETWORK_FACTORY_METHOD(Agora_Session())
Network::Session* Network::Session::Create(Network::Session::SessionType sessionType, const Network::Address& addr) 
{ 
	if (addr.TypeOf() == Network::Address::ADDR_TYPE_AGORA)
	{		
		return AP_NEW(Axiom::Memory::ONLINE_HEAP, Agora_Session(reinterpret_cast<const Agora_Address&>(addr)));
	}
	else
	{
		AP_ASSERTFAIL("Unknown type");
		return 0;
	}
}

#include "ps3profiler.h"
#include <libsntuner.h>
#include <libsn.h>

namespace Soccer
{
	void StartProfiler()
	{
		//snTunerInit();
	}

	void StartMarker()
	{
		// We are not using Markers until we decide what to do with profiling
		//snStartMarker(0,"HELLOWORLD");
		AP_ASSERTMESSAGE(0,"NEED TO IMPLEMENT!!");
	}

	void StopMarker()
	{
		// We are not using Markers until we decide what to do with profiling
		//snStopMarker(0);
		AP_ASSERTMESSAGE(0,"NEED TO IMPLEMENT!!");
	}


}

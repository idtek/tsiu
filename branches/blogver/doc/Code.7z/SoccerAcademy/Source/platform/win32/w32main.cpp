#include <core/system.h>

#include "math/apmath.h"
#include "kernel/kernel.h"
#include "kernel/componentmanager.h"

#include "reflection/script.h"
#include "system/system.h"

#include "testbed.h"
#include "resource/resource.h"
#include "coreprescomponent.h"
#include "coresimcomponent.h"
#include "audio/audiocomponent.h"
#include <input/coreinputcomponent.h>

#include "input/ssinputtranslator.h"
#include "resource/resourcemanager.h"
#include "system/gamedebug.h"

#include <string/string.h>

#include "commonmain.h"
#include "version.h"
#include "system/kernelconfig.h"

#include <collections/booklet.h>
#include <input/virtualcontrollermap.h>
#include <memory/reflectedmemoryinterface.h>
#include "lobby/lobby.h"

#if !CORE_FINAL
#include "inputrecording/inputrecorderinterface.h"
#endif !CORE_FINAL

//#include "lobby/agora_lobby.h"
//#include "network/agora_session.h"
#include "debug/debugdraw.h"

#include <academylibrary.h>
#include <files/filemanager.h>

using namespace AP::System;

UINT_PTR IDT_TIMER1 = 0x1;

// Direct input global pointer.
#include <dinput.h>
#include <dinputd.h>
LPDIRECTINPUT8  g_pDI;
HWND g_hWnd;

//------------------------------------------------------------------------------
// PROTOTYPES
//------------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
				   LPSTR lpCmdLine, int nCmdShow);
LRESULT CALLBACK WindowProc(HWND hWnd, Axiom::uint msg, WPARAM wParam, LPARAM lParam);
void init(HWND);
void shutDown(void);
void update(void);
void render(void);


namespace Soccer
{
	namespace Debug
	{
		extern bool sDebugInfoEnabled;
	}
}

//------------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry poInt
//------------------------------------------------------------------------------
int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR     lpCmdLine,
					int       nCmdShow )
{
	UNUSED_PARAM(lpCmdLine); 
	UNUSED_PARAM(hPrevInstance);

	// Note: It is not necessary to initialise all heaps at this point, you could potentially create heaps within
	// init functions for manager classes etc.
	// I have defaulted to initialsing the memory using PLATFORM_MAXALLOC but you can change this to whatever you
	// like as long as it is big enough to deal with all the heaps.
	// If you want to lock a heap to a specific thread (i.e. only that thread can allocate to it) then call
	// SetThreadAllowed function.
	Axiom::Memory::Init(PLATFORM_MAXALLOC); // SOCCER_ACADEMY_PLATFORM_MAXALLOC);
	Axiom::Memory::DEFAULT_HEAP				= Axiom::Memory::CreateHeap("DEFAULT_HEAP",				IN_MB(178), IN_MB(5) );
	Axiom::Memory::AI_HEAP					= Axiom::Memory::CreateHeap("AI_HEAP",					IN_MB(4) );
	Axiom::Memory::PHYSICS_HEAP				= Axiom::Memory::CreateHeap("PHYSICS_HEAP",				IN_MB(4) );
	Axiom::Memory::PRESENTATION_HEAP		= Axiom::Memory::CreateHeap("PRESENTATION_HEAP",		IN_MB(2) );
	Axiom::Memory::ONLINE_HEAP				= Axiom::Memory::CreateHeap("ONLINE_HEAP",				IN_MB(1) );
	Axiom::Memory::ANIM_HEAP				= Axiom::Memory::CreateHeap("ANIM_HEAP",				IN_MB(8)+IN_KB(512) ); // danc: please keep this the same as Wiimain
	Axiom::Memory::AUDIO_HEAP				= Axiom::Memory::CreateHeap("AUDIO_HEAP",				IN_MB(41) );
	Axiom::Memory::RENDER_HEAP				= Axiom::Memory::CreateHeap("RENDER_HEAP",				IN_MB(126) );
	Axiom::Memory::INPUTEVENT_HEAP			= Axiom::Memory::CreateHeap("INPUTEVENT_HEAP",			IN_MB(1) );
	Axiom::Memory::RESERVED_DEBUG_HEAP = Axiom::Memory::DEFAULT_HEAP; //This heap ID is used for all Streaker allocations


	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	Axiom::FileManager::FileManager* fileManager	= Axiom::FileManager::FileManager::GetInstance();
	fileManager->AddPathAlias("anim:",				"file:\\Common\\anim");
	fileManager->AddPathAlias("effects:",			"file:\\Common\\Effects");
	fileManager->AddPathAlias("fe:",				"file:\\PC\\fe");
	fileManager->AddPathAlias("presentation:",		"file:\\Common\\presentation");
	fileManager->AddPathAlias("scripts:",			"file:\\Common\\scripts");
	fileManager->AddPathAlias("audio:",				"file:\\Common\\sounds");
	fileManager->AddPathAlias("graphics:",			"file:\\Common\\graphics");
	fileManager->AddPathAlias("platform_audio:",	"file:\\PC\\Sounds");
	fileManager->AddPathAlias("platform_graphics:",	"file:\\PC\\Graphics");
	fileManager->AddPathAlias("tables:",			"file:\\PC\\Tables");
	fileManager->AddPathAlias("debug:",				"file:\\Debug");
	fileManager->AddPathAlias("data:",				"file:\\Data");
	fileManager->AddPathAlias("asset:",				"file:\\Asset");
	fileManager->AddPathAlias("media:",				"file:\\Common");
	fileManager->AddPathAlias("home:",				"file:");
	fileManager->AddPathAlias("save:",				"file:\\Common\\Save");
	fileManager->AddPathAlias("movies:",			"file:\\Common\\movies");

	char szBuffer[MAX_PATH] = {0};
	GetCurrentDirectory( MAX_PATH, szBuffer );

//	*Axiom::StringRevFindChar(szBuffer, '\\') = 0;
//	Axiom::StringConcat(szBuffer, "\\RuntimeMedia", Axiom::StringLength("\\RuntimeMedia"));
	fileManager->SetDiskAliasPath(szBuffer);

	Soccer::Debug::sDebugInfoEnabled = false;

#if CORE_FINAL == CORE_NO
	if (fileManager->DoesFileExist("file:\\Common\\debugEnabler.txt"))
	{
		Soccer::Debug::sDebugInfoEnabled = true;
	}
#endif

	//Get the command line string and chop off the arguments, keeping only the executable filename
	LPSTR commandLine = GetCommandLine();
	char executableFilename[256];
	int len = Axiom::StringLength(commandLine);
	const char* ext = Axiom::StringFindString(commandLine, ".exe");
	if (ext!=NULL)
	{
		int executableLen = (ext + 4) - commandLine;
		if (len != executableLen)
			len = executableLen;
	}
	Axiom::StringCopy(executableFilename, commandLine, len);
	executableFilename[len] = 0;
	if (executableFilename[0] == '\"') //Chop start quote character
	{
		Axiom::StringCopy(executableFilename, executableFilename+1, len-1);
		len--;
		executableFilename[len] = 0;
	}
	if (executableFilename[len-1] == '\"') //Chop end quote character
	{
		len--;
		executableFilename[len] = 0;
	}
	fileManager->InitExecutableFilename(executableFilename);

	// Create window class
	WNDCLASSEX winClass;
	MSG        uMsg;

    Axiom::MemorySet(&uMsg, 0, sizeof(uMsg));
    
	winClass.lpszClassName	= TEXT("AP_WINDOWS_CLASS");
	winClass.cbSize			= sizeof(WNDCLASSEX);
	winClass.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	winClass.lpfnWndProc	= static_cast<WNDPROC>(WindowProc);
	winClass.hInstance		= hInstance;
	winClass.hIcon			= LoadIcon(NULL, reinterpret_cast<LPCTSTR>(IDI_DIRECTX_ICON));
    winClass.hIconSm		= LoadIcon(NULL, reinterpret_cast<LPCTSTR>(IDI_DIRECTX_ICON));
	winClass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	winClass.hbrBackground	= reinterpret_cast<HBRUSH>(COLOR_BACKGROUND);		// NULL; 							
	winClass.lpszMenuName	= NULL;
	winClass.cbClsExtra		= 0;
	winClass.cbWndExtra		= 0;
	
	if( !RegisterClassEx(&winClass) )
	{
		return E_FAIL;
	}

	HWND hWnd = CreateWindowEx(	WS_EX_APPWINDOW, TEXT("AP_WINDOWS_CLASS"), TEXT("SoccerAcademy"),
								WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN /*WS_OVERLAPPEDWINDOW | WS_VISIBLE*/,
								0, 0, 640, 480, NULL, NULL, hInstance, NULL );


	//The game doesn't like to play nice with other programs.  This should fix that.
	if(!SetPriorityClass(GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS))
	{
		printf("Failed to set priority mode (%d)\n", GetLastError());
	}


	if( hWnd == NULL )
	{
		return E_FAIL;
	}
	
	HRESULT hr; 

	// Make global copies of the windows handles so the input system can hook up with direct input.
	g_hWnd = hWnd;

	hr = DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, reinterpret_cast<void**>(&g_pDI), NULL); 
	if FAILED(hr) 
	{			
		g_pDI = NULL;// DirectInput not available; take appropriate action 
	} 

	// Work out the working directory path name
	
	Axiom::StringConcat(szBuffer, "\\", array_count(szBuffer));
	Soccer::InitSystems(static_cast<Axiom::Handle>(hWnd), szBuffer);
	
	AP::Reflection::Type::LogInitialization();

	AP::Debug::DebugDraw::Init( Axiom::Memory::AI_HEAP );

	while( uMsg.message != WM_QUIT )
	{
		if(!Soccer::UpdateSystems())
		{
			break;
		}
	
		if( PeekMessage( &uMsg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &uMsg );
			DispatchMessage( &uMsg );
		}

		Axiom::Thread::Sleep(0);
	}

	Soccer::ShutdownSystems();
    UnregisterClass( TEXT("MY_WINDOWS_CLASS"), winClass.hInstance );

	return static_cast<int>(uMsg.wParam);
}

//------------------------------------------------------------------------------
// Name: WindowProc()
// Desc: The window's message handler
//------------------------------------------------------------------------------
LRESULT CALLBACK WindowProc( HWND hWnd, Axiom::uint msg, WPARAM wParam, LPARAM lParam )
{
	static POINT ptLastMousePosit;
	static POINT ptCurrentMousePosit;
	static bool bMousing;

	switch( msg )
	{	
		case WM_CLOSE:
        case WM_DESTROY:
		{
			PostQuitMessage(0);
		}
        break;

		default:
		{
			return DefWindowProc( hWnd, msg, wParam, lParam );
		}
		break;
	}

	return 0;
}

// Implementation of "Virtual C-tor" for lobby object. (Can it be a template?) or MAKE_LOBBY_FACTORY_METHOD(Agora_Lobby)
Lobby::LobbyObj* Lobby::LobbyObj::Create(Lobby::LobbyObj::LobbyType lobbyType) 
{ 
	AP_ASSERTFAIL("Not implemented"); 
	return NULL; 
}

// Implementation of "Virtual C-tor" for network session object. (ALEXEI: Can it be a template?) or MAKE_NETWORK_FACTORY_METHOD(Agora_Session())
Network::Session* Network::Session::Create(Network::Session::SessionType sessionType, const Network::Address& addr) 
{ 
	AP_ASSERTFAIL("Not implemented");
	return NULL;
}

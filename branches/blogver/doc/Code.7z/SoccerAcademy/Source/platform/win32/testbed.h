#ifndef _TESTBED_H
#define _TESTBED_H

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

extern LPDIRECT3DDEVICE9  g_pd3dDevice;

#endif //_TESTBED_H


#include "animation/animationmanager.h"
#include <system/system.h>

#include <math/apmath.h>
#include <kernel/kernel.h>

#include "reflection/script.h"
#include "applicationcomponent.h"
#include "coreprescomponent.h"
#include "coresimcomponent.h"
#include "AI/gamelogicrepository.h"
#include "input/coreinputcomponent.h"
#include <marshaller/eventbuffer.h>
#include <marshaller/marshallereventmessages.h>
#include <marshaller/marshallercomponent.h>

#include "input/ssinputtranslator.h"
#include "resource/resourcemanager.h"
#include "system/gamedebug.h"
#include "presentation/presentationmessages.h"

#include <memory/apmemory.h>
#include <kernel/kernel.h>
#include <kernel/componentmanager.h>
#include "coresimcomponent.h"
#include "coreprescomponent.h"
#include "commonmain.h"

#include <resource/resourcecomponent.h>
#include <resource/resourcemessages.h>

#include <string/string.h>


#include "system/kernelconfig.h"
#include "commonmain.h"
#include <collections/booklet.h>
#include <input/virtualcontrollermap.h>
#include <memory/reflectedmemoryinterface.h>

#include "debug/debugdraw.h"
#include "debug/log.h"

#include <files/filemanager.h>

#include <Academylibrary.h>

#include <revolution/kpad.h>

#include "system/wiisystems.h"
#include "presentation/bootscreens.h"

#include "graphics/graphics.h"
#include "fe/fe.h"

using namespace AP::Input;
using namespace AP::Marshaller::Events;
using namespace AP::Input::Events;


Axiom::FileManager::FileManager*		pFileManager = 0;

namespace Soccer
{
	namespace Debug
	{
		extern bool sDebugInfoEnabled;
	}
}

#define BASIC_DEFAULT_HEAP_SIZE	(IN_MB(14)+IN_KB(224))
#define BASIC_OVERFLOW_HEAP_SIZE	(IN_MB(5))

#if CORE_FINAL
#  if CORE_SHIP
#    define DEFAULT_HEAP_SIZE		BASIC_DEFAULT_HEAP_SIZE+IN_MB(1)
#  else
#    define DEFAULT_HEAP_SIZE		BASIC_DEFAULT_HEAP_SIZE
#  endif
#  if LARGE_REPLAY_BUFFER
#    error
#  endif
#  define SOCCER_ACADEMY_PLATFORM_MAXMEM1ALLOC (IN_MB(15)+IN_KB(896))
#  if PROFILER_ENABLED
#    define SOCCER_ACADEMY_PLATFORM_MAXALLOC (IN_MB(74))
#    define OVERFLOW_HEAP_SIZE	BASIC_OVERFLOW_HEAP_SIZE+IN_MB(12)
#  else
#    define SOCCER_ACADEMY_PLATFORM_MAXALLOC (IN_MB(52))
#    define OVERFLOW_HEAP_SIZE	BASIC_OVERFLOW_HEAP_SIZE
#  endif // profiler_enabled
#else
#  define OVERFLOW_HEAP_SIZE	BASIC_OVERFLOW_HEAP_SIZE
#  if PROFILER_ENABLED
#    error
#  endif
#  define SOCCER_ACADEMY_PLATFORM_MAXMEM1ALLOC	(IN_MB(6))
#  define SOCCER_ACADEMY_PLATFORM_MAXALLOC 		(IN_MB(100))
#  if LARGE_REPLAY_BUFFER
#    define DEFAULT_HEAP_SIZE	BASIC_DEFAULT_HEAP_SIZE+IN_MB(6)
#  else
#    define DEFAULT_HEAP_SIZE	BASIC_DEFAULT_HEAP_SIZE+IN_MB(1)
#  endif
#endif

int main(int argc, char *argv[])
{	
	Log("System","START GAME");

	// Note: It is not necessary to initialise all heaps at this point, you could potentially create heaps within
	// init functions for manager classes etc. 
	// I have defaulted to initialsing the memory using PLATFORM_MAXALLOC but you can change this to whatever you
	// like as long as it is big enough to deal with all the heaps.
	// If you want to lock a heap to a specific thread (i.e. only that thread can allocate to it) then call
	// SetThreadAllowed function.

#if SCREENSHOT_ENABLED
	Graphics::Renderer::sScreenshotEnabled = true;
#endif


	Log("System","INIT MEMORY MANAGER");
	Axiom::Memory::Init(SOCCER_ACADEMY_PLATFORM_MAXALLOC, SOCCER_ACADEMY_PLATFORM_MAXMEM1ALLOC);

																	// Name					Size	 			SBA Size	Flags
#if CORE_FINAL
	Axiom::Memory::DEFAULT_HEAP		 	= Axiom::Memory::CreateHeap("DEFAULT_HEAP",			DEFAULT_HEAP_SIZE	, IN_MB(6)	, HEAPFLAG_USEASGLOBALSBA|HEAPFLAG_USEALTERNATEMEM ); // Lua allocation should probably be in an independent script heap
#else
	Axiom::Memory::DEFAULT_HEAP		 	= Axiom::Memory::CreateHeap("DEFAULT_HEAP",			DEFAULT_HEAP_SIZE	, IN_MB(6)	, HEAPFLAG_USEASGLOBALSBA ); // Lua allocation should probably be in an independent script heap
#endif
	Axiom::Memory::OVERFLOW_HEAP		= Axiom::Memory::CreateHeap("OVERFLOW_HEAP",		OVERFLOW_HEAP_SIZE	, 0 );
	Axiom::Memory::ANIM_HEAP			= Axiom::Memory::CreateHeap("ANIM_HEAP",			IN_MB( 8)			, 0 ); // danc: please keep this the same as w32main.cpp
	Axiom::Memory::AUDIO_HEAP			= Axiom::Memory::CreateHeap("AUDIO_HEAP",			IN_MB(10) + IN_KB(640), 0 );
	Axiom::Memory::RENDER_HEAP			= Axiom::Memory::CreateHeap("RENDER_HEAP",			IN_MB(28) + IN_KB(384), 0 );
	Axiom::Memory::THREAD_HEAP			= Axiom::Memory::CreateHeap("THREAD_HEAP",			IN_KB(288)			, 0			, HEAPFLAG_USEALTERNATEMEM );
	

#if !CORE_FINAL
	Axiom::Memory::RESERVED_DEBUG_HEAP	= Axiom::Memory::CreateHeap("DEBUG_HEAP",			IN_MB(23)			, IN_MB(5));
	Axiom::Memory::RSO_HEAP				= Axiom::Memory::CreateHeap("RSO_HEAP",				IN_MB(5)			, IN_MB(1)	, HEAPFLAG_USEALTERNATEMEM );
#endif
	// TOTAL SIZES												FINAL NO PROFILE			13MB mem1 	52 mem2
	//															FINAL PROFILE				13MB mem1	66 mem2

	//Wii specific items
#if CORE_SHIP
	Soccer::InitWiiSystems(false);
	Soccer::BootScreens::EnableEpilepsy(false);
#else
	Soccer::InitWiiSystems(true);
#endif

	for(int i = 0; i < argc; i++)
	{
		//we are doing string finds, since the MPLS video player will actually pass the arguments back
		//in the first arg, spaces and all.
		if(Axiom::StringFindString(argv[i], "eu"))
		{
			Soccer::FE_Manager::SetRegion(Soccer::FE_Manager::FERegionEurope);
		}
		if(Axiom::StringFindString(argv[i], "noepilepsy"))
		{
			Soccer::BootScreens::EnableEpilepsy(false);
		}
		if(Axiom::StringFindString(argv[i], "use_debug_bb"))
		{
			Soccer::GameLogicRepository::m_UseDebugBalanceBoardControls = true;
		}
	}

	Log("System","INIT FILE SYSTEM");

	Axiom::FileManager::FileManager::Init(Axiom::Memory::DEFAULT_HEAP);
	Axiom::FileManager::FileManager * fileManager = Axiom::FileManager::FileManager::GetInstance();
	fileManager->AddPathAlias("anim:",				"file:\\Common\\anim");
	fileManager->AddPathAlias("effects:",			"file:\\Common\\Effects");
	fileManager->AddPathAlias("fe:",				"file:\\WII\\fe");
	fileManager->AddPathAlias("presentation:",		"file:\\Common\\presentation");
	fileManager->AddPathAlias("scripts:",			"file:\\Common\\scripts");
	fileManager->AddPathAlias("audio:",				"file:\\Common\\sounds");
	fileManager->AddPathAlias("graphics:",			"file:\\Common\\graphics");
	fileManager->AddPathAlias("platform_audio:",	"file:\\WII\\Sounds");
	fileManager->AddPathAlias("platform_graphics:",	"file:\\WII\\Graphics");
	fileManager->AddPathAlias("tables:",			"file:\\WII\\Tables");
	fileManager->AddPathAlias("debug:",				"file:\\Debug");
	fileManager->AddPathAlias("data:",				"file:\\Data");
	fileManager->AddPathAlias("asset:",			    "file:\\Asset");
	fileManager->AddPathAlias("media:",				"file:\\Common");
	fileManager->AddPathAlias("home:",				"file:");
	fileManager->AddPathAlias("save:",				"save:");
	fileManager->AddPathAlias("hbm:",				"file:\\WII\\HomeButton2");
	fileManager->AddPathAlias("movies:",			"file:\\Common\\movies");
	fileManager->SetDiskAliasPath("");

	//This is to initialize Streaker
	if(argc)
	{
		const char* executableFilename = argv[0];
		const char* forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
		while (forwardSlashChar!=NULL)
		{
			executableFilename = forwardSlashChar+1;
			forwardSlashChar = Axiom::StringFindChar(executableFilename, '/');
		}
		fileManager->InitExecutableFilename(executableFilename);
	}


	Soccer::Debug::sDebugInfoEnabled = true;

	Log("System","INIT NP SYSTEM");
	
	Soccer::InitSystems(Axiom::Handle(reinterpret_cast<void*>(NULL)),"");

	AP::Reflection::Type::LogInitialization();

	AP::Debug::DebugDraw::Init( Axiom::Memory::AI_HEAP );
	
	while(true)
	{
		if (!Soccer::UpdateSystems())
		{
			break;
		}
		Soccer::UpdateWiiSystems();
	}
	
	Soccer::ShutdownSystems();

	return 0;
}


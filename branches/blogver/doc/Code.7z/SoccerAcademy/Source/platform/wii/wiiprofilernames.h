/*-------------------------------------------------*
  Project: WiiProfiler
  File:    wiiprofilernames.h
  Authors: Steve Rabin and Mark Jawad

   
  Copyright 2008 Nintendo of America Inc.
  All rights reserved.
 *-------------------------------------------------*/
 

//////////////////////////////////////////////////////////////
// Register the names of your REL/RSO code in this file,
// using the REGISTER_RELOCATABLE() convention as shown below.
// Use very short names, since they appear before each
// function name in the profile results.
//
// Register the names of values to track in this file,
// using the REGISTER_TRACKING_NAME() convention as shown below.
//
// Notes: 
// * Do not use quotes.
// * Do not use semi-colons.
// * Name can't contain spaces (must follow C/C++ rules for enum name).
// * Maximum of 64 names can be registered using REGISTER_RELOCATABLE().
// * Maximum of 64 names can be registered using REGISTER_TRACKING_NAME().
// * Only create one name for each REL/RSO map file that exists.
//
//
// Example:
// REGISTER_RELOCATABLE(REL_Level1)
// REGISTER_RELOCATABLE(REL_Level2)
// REGISTER_RELOCATABLE(REL_Level3)
//
// Example:
// REGISTER_RELOCATABLE(RSO_BossOne)
// REGISTER_RELOCATABLE(RSO_BossTwo)
// REGISTER_RELOCATABLE(RSO_BossThree)
// REGISTER_RELOCATABLE(RSO_BossFour)
//
// Example:
// REGISTER_TRACKING_NAME(EVENT_ParticleEffect)
// REGISTER_TRACKING_NAME(EVENT_PlayerKilled)
// REGISTER_TRACKING_NAME(EVENT_PathfindingRequest)
//






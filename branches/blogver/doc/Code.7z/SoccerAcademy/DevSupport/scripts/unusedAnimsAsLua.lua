function Test.Setup()
	animListScript = ""
				.. " local clipManager = Animation.Loco.ClipManager;" 
				.. " local editor = Animation.Loco "
				.. " local animList = {};" 
				.. " local unUsedList = {};" 
				.. " for i = 0, clipManager.NumClips() - 1 do " 
				.. "   unUsedList[i] = clipManager.ClipName(i);" 
				.. " end " 
				.. " local result = table.getn(unUsedList) .. ' total animations' "
				.. " for key, value in ipairs(editor.Handlers) do " 
				.. "   	local handler = value.Ptr;" 
				.. "   	if type(value.Ptr) == 'CompositeAnimHandler' then  " 
				.. "     local handlerCount = handler.NumOfHandlers() " 
				.. "     for i = 0,handlerCount-1 do " 
				.. "        local handlerName = handler.HandlerNameAtIndex(i) " 
				.. "        local subHandler = editor.FindHandler(editor.FindByName(handlerName)) "
				.. "        for j = 0, subHandler.NumberOfClips()-1 do "
				.. "       		local clipId = subHandler.GetClip(j); "
				.. "       		animList[clipId] = clipManager.ClipName(clipId);"
				.. "       		unUsedList[clipId] = nil;" 
				.. "       	end "
				.. "      end " 
				.. "   end " 				
				.. "   for i = 0, handler.NumberOfClips() - 1 do " 
				.. "       local clipId = handler.GetClip(i);" 
				.. "       animList[clipId] = clipManager.ClipName(clipId);"
				.. "       unUsedList[clipId] = nil;" 
				.. "   end " 
				.. " end " 
				.. " for key, value in pairs(unUsedList) do " 
				.. "   if result == nil then " 
				.. "       result = value;" 
				.. "   else " 
				.. "       result = result .. ',' .. value " 
				.. "   end " 
				.. " end " 
				.. " return result;";
end

function Test.Main ()
	TestBot.TestGroupInit("------------- Unused Animations Test -------------");

	local resultStr = ExecuteGetString(animListScript);
	local unUsedAnimsTbl = Split(resultStr, ',');
	local animCount = table.remove(unUsedAnimsTbl, 1) or -1;	-- pop the total anim count
	
	if (animCount == -1) then 
		TestBot.ReportFailure("GAME NOT RESPONDING");
		
	else
		local unusedCount = table.getn(unUsedAnimsTbl);
		if (unusedCount == 0) then
			TestBot.ReportSucess("No unused Animations found.  of ".. animCount .." total anims:");
		else
			TestBot.ReportWarning("****Unused Animations Found **** ".. unusedCount .." unused of ".. animCount);
			local count = 1;
			TestBot.Report("local unused animsTbl = {");
			for anim in EachItemOf(unUsedAnimsTbl) do
				TestBot.Report("{ anim = ".. anim.."},");
				count = count + 1;
			end
			TestBot.Report("}");
			TestBot.Report("*** DONE report ****");
		end
	end

	TestBot.TestGroupSummary();
end

function Test.Cleanup()
	animListScript = nil;
	-- clean up the functions:
	ReportUnusedAnims = nil;
end


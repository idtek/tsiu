-- Launch and Verify tests for mini games:
-- FE to BE, BE to FE
--
-- launches and test minigames sequentially from a list of minigames
-- each minigame launch is verified, then fps is verified, then minigame shutdown is verified
Test.FPS_TARGET = 30;

Test.MiniGameTestTable = {
	{title = "Wii5on5MiniGame", miniGame = "scripts:Wii5on5MiniGame.lua"},
---	{title = "WiiTestMiniGame", miniGame = "scripts:WiiTestMiniGame.lua"},
}

function Test.Main()
	TestBot.TestGroupInit("Multiple Minigame launch test");
	
	for test in EachItemOf(Test.MiniGameTestTable) do
		if (test) then
			Test.MiniGameSmokeTest(test.title, test.miniGame);
		end
	end
	
	TestBot.TestGroupSummary();
end

function Test.MiniGameSmokeTest(title, game)
	TestBot.TestCaseInit(title.." test");
	
	local result = LaunchMiniGameTest(game);
	TestBot.Verify(result, "Launched "..title);
	Wait(2000);
	
	TestSimFrameRate(Test.FPS_TARGET);		-- averages 100 samples over 1 second
	Wait(1000);
	
	result = StopMiniGameTest();
	TestBot.Verify(result, "Stopped "..title);
	
	TestBot.TestCaseSummary();
	Wait(1000);
end

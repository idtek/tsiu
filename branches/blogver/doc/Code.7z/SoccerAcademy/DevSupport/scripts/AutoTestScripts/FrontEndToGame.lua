-- Go to the game


function Test.Main()
      TestBot.TestGroupInit("running game test");
	TestBot.TestCaseInit("test");
	
	PrintLine("Starting Time - " .. os.date("%X"));

      Wait(10000)

      local id = ExecuteGetString(" return BuildInfo.CId.Value;");
      PrintLine("CID :" .. id);

      Wait(5000)
      State1()
	TestBot.Verify(true, "FE ");
      Wait(5000)
      State2()
      
	TestBot.Verify(true, "Game");

	Wait(10000)

      TestBot.TestCaseSummary();

	TestBot.TestGroupSummary();
end


function State1()
	local script = " local game = GameFEChangeStateEvent() "
		.. " game.State = 1; "
		.. " game.Option = 0; "
		.. " ComponentManager.SendMessage(game); "
	ExecuteReflectionScript(script);
end

function State2()
	local script = " local game = GameFEChangeStateEvent() "
		.. " game.State = 1; "
		.. " game.Option = 8; "
		.. " ComponentManager.SendMessage(game); "
	ExecuteReflectionScript(script);
end

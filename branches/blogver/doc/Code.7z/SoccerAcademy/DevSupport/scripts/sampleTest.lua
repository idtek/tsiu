FPS_TARGET = 30;

function main()
	TestBot.TestGroupInit("Sample FPS test");
	Wait(2000);		-- 2 seconds
	
	local fps = tonumber(GetSimFrameRate());
	TestBot.Verify(fps >= FPS_TARGET, "fps >= "..tostring(FPS_TARGET)..".  actual = "..tostring(fps));
	
	TestBot.TestGroupSummary();
end
